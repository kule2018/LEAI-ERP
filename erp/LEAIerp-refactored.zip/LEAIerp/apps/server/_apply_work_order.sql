USE erp;
CREATE TABLE IF NOT EXISTS work_order (
  id BIGINT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  tenant_id BIGINT NOT NULL DEFAULT 1,
  created_by BIGINT DEFAULT 0,
  created_at DATETIME(3) DEFAULT CURRENT_TIMESTAMP(3),
  updated_by BIGINT DEFAULT 0,
  updated_at DATETIME(3) DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  is_deleted TINYINT(1) DEFAULT 0,
  remark VARCHAR(500) DEFAULT NULL,
  order_no VARCHAR(64) NOT NULL COMMENT 'work order no',
  product_id BIGINT NOT NULL COMMENT 'product',
  bom_id BIGINT DEFAULT NULL COMMENT 'bom',
  qty DECIMAL(18,3) DEFAULT 0 COMMENT 'qty',
  plan_qty DECIMAL(18,3) DEFAULT 0 COMMENT 'plan qty',
  produced_qty DECIMAL(18,3) DEFAULT 0 COMMENT 'produced qty',
  plan_start DATETIME(3) DEFAULT NULL,
  plan_end DATETIME(3) DEFAULT NULL,
  status TINYINT DEFAULT 0 COMMENT '0 pending 1 ready 2 producing 3 done 4 closed',
  UNIQUE KEY uk_work_order (tenant_id, order_no),
  INDEX idx_wo_status (tenant_id, status, plan_end)
) COMMENT='work order';
SHOW TABLES LIKE 'work_order';
