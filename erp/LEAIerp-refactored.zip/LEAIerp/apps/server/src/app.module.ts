/**
 * 根模块：连接 MySQL，注册全部业务模块（文档 2.3 目录结构）。
 * 说明：本轮不引入 @nestjs/config，改用一段扁平代码加载 .env，
 * 让本地调试与 docker-compose 注入的环境变量都能生效。
 */
import './load-env';
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { EventEmitterModule } from '@nestjs/event-emitter';
import { ScheduleModule } from '@nestjs/schedule';
import { AuthSystemModule } from './modules/auth-system/auth.module';
import { InventoryModule } from './modules/inventory/inventory.module';
import { SalesModule } from './modules/sales/sales.module';
import { PurchaseModule } from './modules/purchase/purchase.module';
import { FinanceModule } from './modules/finance/finance.module';
import { PrintModule } from './modules/print/print.module';
import { AiModule } from './modules/ai/ai.module';
import { BpmModule } from './modules/bpm/bpm.module';
import { BiModule } from './modules/bi/bi.module';
import { CrmModule } from './modules/crm/crm.module';
import { WmsModule } from './modules/wms/wms.module';
import { MesModule } from './modules/mes/mes.module';
import { ApsModule } from './modules/aps/aps.module';
import { ShopModule } from './modules/shop/shop.module';
import { MobileModule } from './modules/mobile/mobile.module';
import { UxModule } from './modules/ux/ux.module';
import { RealtimeModule } from './modules/realtime/realtime.module';
import { UploadModule } from './modules/upload/upload.module';
import { ObservabilityModule } from './common/observability';
import { IntegrationsModule } from './modules/integrations/integrations.module';
import { SalesExtModule } from './modules/sales-ext/sales-ext.module';

@Module({
  imports: [
    TypeOrmModule.forRoot({
      type: 'mysql',
      host: process.env.DB_HOST || '127.0.0.1',
      port: Number(process.env.DB_PORT || 3306),
      username: process.env.DB_USER || 'erp',
      password: process.env.DB_PASS || 'erp123456',
      database: process.env.DB_NAME || 'erp',
      synchronize: false, // 表结构由 sql/01_schema.sql 迁移管理
      autoLoadEntities: false,
      logging: false,
    }),
    EventEmitterModule.forRoot(),
    ScheduleModule.forRoot(),
    // 基础业务模块
    AuthSystemModule,
    InventoryModule,
    SalesModule,
    PurchaseModule,
    FinanceModule,
    PrintModule,
    AiModule,
    // 扩展域模块（文档 14~19 章）
    BpmModule,
    BiModule,
    CrmModule,
    WmsModule,
    MesModule,
    ApsModule,
    ShopModule,
    MobileModule,
    // UX 体验增强基座（文档 24~35 章，17 张体验表通用 CRUD）
    UxModule,
    // 深度功能：SSE 实时推送、分片上传、可观测
    RealtimeModule,
    UploadModule,
    ObservabilityModule,
    // 外部集成适配器（OAuth / 支付 / 物流 / 发票 / 银行 / 节假日）
    IntegrationsModule,
    // 销售客户扩展：必须放在通用 CRM 之后，避免通配路由抢占具体路由
    SalesExtModule,
  ],
})
export class AppModule {}
