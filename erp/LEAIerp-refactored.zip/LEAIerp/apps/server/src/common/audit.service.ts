/**
 * 审计日志服务：所有写操作（新增/修改/作废/审核/登录）都要留痕。
 * 只追加、不更新、不删除；写失败只记录告警，不阻断主流程。
 * 深度增强：writeDiff 记录变更前/后 JSON，敏感字段单独写 audit_field_log。
 */
import { Injectable, Logger } from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';
import { DataSource } from 'typeorm';
import { currentContext } from './common';

/** 敏感字段的中文展示名，写字段审计时更可读 */
const SENSITIVE_FIELD_NAMES: Record<string, string> = {
  cost: '成本价', price: '售价', avg_cost: '加权成本', unit_price: '单价',
  total_amount: '单据金额', phone: '手机号', tel: '联系电话', id_no: '证件号码',
  id_card: '身份证号', bank_account: '银行账户', credit_limit: '信用额度',
};

@Injectable()
export class AuditService {
  private readonly logger = new Logger('Audit');

  constructor(@InjectDataSource() private readonly dataSource: DataSource) {}

  /**
   * 写一条审计日志
   * @param action 动作：CREATE / UPDATE / VOID / AUDIT / LOGIN / PRINT / AI
   * @param bizType 业务类型，如 SALE_ORDER
   * @param bizId 业务主键
   * @param detail 变更内容（建议放 before/after 的 JSON 串）
   */
  async write(action: string, bizType: string, bizId?: number, bizNo?: string, detail?: string, latencyMs?: number) {
    try {
      const ctx = currentContext();
      await this.dataSource.query(
        `INSERT INTO sys_audit_log (tenant_id, user_id, username, module, action, biz_type, biz_id, biz_no, detail, ip, latency_ms)
         VALUES (?,?,?,?,?,?,?,?,?,?,?)`,
        [ctx.tenantId, ctx.userId, ctx.username, bizType || 'system', action, bizType, bizId || null, bizNo || null,
          (detail || '').slice(0, 1900), ctx.ip, latencyMs || null],
      );
    } catch (e: any) {
      this.logger.warn(`审计日志写入失败：${e?.message}`);
    }
  }

  /** 把对象收敛到合理长度，避免大明细撑爆审计字段 */
  private brief(value: any): any {
    if (value === undefined || value === null) return null;
    if (Array.isArray(value)) return value.slice(0, 20).map((v) => this.brief(v));
    if (typeof value === 'object') {
      const out: any = {};
      for (const k of Object.keys(value).slice(0, 40)) out[k] = this.brief(value[k]);
      return out;
    }
    const text = String(value);
    return text.length > 500 ? text.slice(0, 500) : text;
  }

  /**
   * 带前后值的审计：before/after 同时写 detail 与结构化列；
   * 发生变化的敏感字段额外写一条 audit_field_log（不阻断主流程）。
   * @param sensitiveFields 需要单独留痕的字段名，如 ['cost','phone']
   */
  async writeDiff(
    action: string,
    bizType: string,
    bizId: number,
    bizNo: string,
    before: any,
    after: any,
    sensitiveFields: string[] = [],
  ) {
    const ctx = currentContext();
    const beforeJson = JSON.stringify(this.brief(before));
    const afterJson = JSON.stringify(this.brief(after));
    const detail = JSON.stringify({ before: this.brief(before), after: this.brief(after) });

    try {
      // 09_deep_schema.sql 会补 before_json/after_json 两列；未迁移时降级到 detail
      await this.dataSource.query(
        `INSERT INTO sys_audit_log
          (tenant_id, user_id, username, module, action, biz_type, biz_id, biz_no, detail, ip, before_json, after_json)
         VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`,
        [ctx.tenantId, ctx.userId, ctx.username, bizType || 'system', action, bizType, bizId || null,
          bizNo || null, detail.slice(0, 1900), ctx.ip, beforeJson.slice(0, 4000), afterJson.slice(0, 4000)],
      );
    } catch {
      await this.write(action, bizType, bizId, bizNo, detail);
    }

    for (const field of sensitiveFields || []) {
      const beforeValue = before == null ? undefined : before[field];
      const afterValue = after == null ? undefined : after[field];
      if (JSON.stringify(beforeValue ?? null) === JSON.stringify(afterValue ?? null)) continue;
      try {
        await this.dataSource.query(
          `INSERT INTO audit_field_log
            (tenant_id, created_by, biz_type, biz_id, field_code, field_name, before_value, after_value, is_sensitive, operator)
           VALUES (?,?,?,?,?,?,?,?,1,?)`,
          [ctx.tenantId, ctx.userId, bizType, bizId || 0, field, SENSITIVE_FIELD_NAMES[field] || field,
            beforeValue == null ? null : String(beforeValue).slice(0, 1000),
            afterValue == null ? null : String(afterValue).slice(0, 1000),
            ctx.username || String(ctx.userId)],
        );
      } catch (e: any) {
        this.logger.warn(`敏感字段审计写入失败：${field} ${e?.message}`);
      }
    }
  }
}
