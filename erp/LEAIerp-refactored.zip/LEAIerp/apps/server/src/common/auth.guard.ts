import { CanActivate, ExecutionContext, Injectable, UnauthorizedException } from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { JwtService } from '@nestjs/jwt';
import { Request } from 'express';
import { PERM_KEY } from './require-perm.decorator';
import { runWithUser } from './tenant.context';
import { JwtPayload } from './types';

/**
 * 全局鉴权守卫。
 * 职责：
 * 1. 从 Authorization: Bearer <token> 解析 JWT；
 * 2. 把用户信息写入租户上下文（供所有查询自动带 tenant_id）；
 * 3. 若接口标注了 @RequirePerm，校验权限码是否包含。
 * 说明：骨架里挂了全局守卫，用 @Public() 可跳过（见 public.decorator）。
 */
@Injectable()
export class AuthGuard implements CanActivate {
  constructor(
    private readonly jwtService: JwtService,
    private readonly reflector: Reflector,
  ) {}

  canActivate(context: ExecutionContext): boolean {
    const request = context.switchToHttp().getRequest<Request>();
    const authHeader = request.headers.authorization || '';

    // 放行登录接口：无 token 时不报错，交给业务接口自行判断（骨架简化处理）
    const isPublic = this.reflector.getAllAndOverride<boolean>('is_public', [
      context.getHandler(),
      context.getClass(),
    ]);

    const token = authHeader.replace('Bearer ', '').trim();
    if (!token) {
      if (isPublic) {
        return true;
      }
      // 骨架为了能直接用浏览器/脚本跑通，无 token 时回落为租户 1 的演示用户
      const demoUser: JwtPayload = { sub: 1, tenantId: 1, username: 'demo', perms: [] };
      runWithUser(demoUser, () => undefined);
      return true;
    }

    let payload: JwtPayload;
    try {
      payload = this.jwtService.verify<JwtPayload>(token);
    } catch (err) {
      throw new UnauthorizedException('登录凭证无效或已过期');
    }

    runWithUser(payload, () => undefined);

    // 权限码校验
    const needPerm = this.reflector.getAllAndOverride<string>(PERM_KEY, [
      context.getHandler(),
      context.getClass(),
    ]);
    if (needPerm && payload.perms && !payload.perms.includes(needPerm)) {
      throw new UnauthorizedException(`缺少权限：${needPerm}`);
    }
    return true;
  }
}
