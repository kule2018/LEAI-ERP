/**
 * 公共层：请求上下文、权限装饰器与守卫、响应包装、异常过滤、数据权限、审计工具。
 * 设计说明：
 *  - tenantId / userId 由 JWT 解析后写入 AsyncLocalStorage，Service 层无需层层传参即可自动补租户条件；
 *  - @RequirePerm 只声明权限码，校验统一在 PermissionsGuard，避免每个 Controller 写 if；
 *  - @DataScope 声明行级数据权限级别，由 buildDataScopeWhere 翻译成 SQL 片段。
 */
import {
  CallHandler,
  CanActivate,
  createParamDecorator,
  ExecutionContext,
  Injectable,
  Logger,
  NestInterceptor,
  ExceptionFilter,
  HttpException,
  HttpStatus,
  SetMetadata,
} from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { AsyncLocalStorage } from 'node:async_hooks';
import type { Request, Response } from 'express';
import { map } from 'rxjs/operators';
import { BizCode } from '@erp/shared';
// 统一从公共层转发导出，业务模块无需各自直接依赖 @erp/shared
export { BizCode };

/** 请求上下文：租户与操作人，贯穿一次 HTTP 请求 */
export interface RequestContext {
  tenantId: number;
  userId: number;
  username: string;
  deptId: number;
  orgId: number;
  ip: string;
  roles: string[];
  perms: string[];
  dataScope: string;
  /** true 表示来自真实 JWT；false 表示无 token 的演示上下文 */
  authenticated?: boolean;
}

export const als = new AsyncLocalStorage<RequestContext>();

/** 取当前请求上下文；非 HTTP 场景（定时任务）返回系统上下文 */
export function currentContext(): RequestContext {
  const ctx = als.getStore();
  return ctx || systemContext(1);
}

/** 定时任务/内部事件使用的系统上下文：拥有全部权限，便于跨租户批处理 */
export function systemContext(tenantId = 1): RequestContext {
  return {
    tenantId, userId: 0, username: 'system', deptId: 0, orgId: 0,
    ip: '127.0.0.1', roles: ['SYSTEM'], perms: ['*'], dataScope: 'ALL', authenticated: false,
  };
}

/**
 * 从 HTTP 请求构建上下文：JWT 载荷需携带 dataScope / deptId / orgId / tenantId。
 * verify 由入口层注入（与登录签发共用同一个密钥），避免这里硬编码 JWT 配置。
 * 返回 null 表示带了非法 token，调用方应直接返回 401。
 */
export function buildRequestContext(req: any, verify: (token: string) => any): RequestContext | null {
  const token = String(req.headers?.authorization || '').replace(/^Bearer\s+/i, '').trim();
  const ip = String(req.ip || req.socket?.remoteAddress || '127.0.0.1');
  if (!token) {
    // 无 token 时保留演示上下文：与原有「默认租户 1」行为一致，方便本地调试
    return {
      tenantId: 1, userId: 1, username: 'demo', deptId: 0, orgId: 0,
      ip, roles: ['ADMIN'], perms: ['*'], dataScope: 'ALL', authenticated: false,
    };
  }
  let payload: any;
  try {
    payload = verify(token);
  } catch {
    return null;
  }
  if (!payload || payload.sub === undefined || payload.sub === null) return null;
  return {
    tenantId: Number(payload.tenantId || 1),
    userId: Number(payload.sub || 0),
    username: payload.username || '',
    deptId: Number(payload.deptId || 0),
    orgId: Number(payload.orgId || 0),
    ip,
    roles: Array.isArray(payload.roles) ? payload.roles : [],
    perms: Array.isArray(payload.perms) ? payload.perms : [],
    dataScope: payload.dataScope || 'ALL',
    authenticated: true,
  };
}

export const PERM_KEY = 'require_perm';
/** 声明接口所需权限码，例：@RequirePerm('sales:order:create') */
export const RequirePerm = (...codes: string[]) => SetMetadata(PERM_KEY, codes);

export const DATASCOPE_KEY = 'data_scope';
/** 声明行级数据权限：SELF 只看自己 / DEPT 本部门 / ORG 本组织 / ALL 全部 */
export const DataScope = (level: 'SELF' | 'DEPT' | 'ORG' | 'ALL') => SetMetadata(DATASCOPE_KEY, level);

export const PUBLIC_KEY = 'is_public';
/** 标记接口免登录 */
export const Public = () => SetMetadata(PUBLIC_KEY, true);

/** 从请求中取出 JWT 载荷 */
export const CurrentUser = createParamDecorator((field: keyof RequestContext | undefined, ctx: ExecutionContext) => {
  const req = ctx.switchToHttp().getRequest<Request & { user?: any }>();
  const user = req.user || {};
  return field ? user[field] : user;
});

/** 业务异常：带错误码，便于前端精确处理（如库存不足单独弹窗） */
export class BizException extends HttpException {
  constructor(public readonly bizCode: BizCode, message: string, httpStatus = HttpStatus.OK) {
    super({ code: bizCode, message }, httpStatus);
  }
}

@Injectable()
export class AuthGuard implements CanActivate {
  constructor(private readonly reflector: Reflector) {}

  canActivate(context: ExecutionContext): boolean {
    const isPublic = this.reflector.getAllAndOverride<boolean>(PUBLIC_KEY, [context.getHandler(), context.getClass()]);
    if (isPublic) return true;
    const req = context.switchToHttp().getRequest<Request & { user?: any }>();
    if (!req.user?.tenantId) {
      throw new BizException(BizCode.UNAUTHORIZED, '未登录或令牌已过期', HttpStatus.UNAUTHORIZED);
    }
    return true;
  }
}

@Injectable()
export class PermissionsGuard implements CanActivate {
  constructor(private readonly reflector: Reflector) {}

  canActivate(context: ExecutionContext): boolean {
    const req = context.switchToHttp().getRequest<Request & { user?: any }>();
    const isPublic = this.reflector.getAllAndOverride<boolean>(PUBLIC_KEY, [context.getHandler(), context.getClass()]);
    if (isPublic) return true;
    const need = this.reflector.getAllAndOverride<string[]>(PERM_KEY, [context.getHandler(), context.getClass()]) || [];
    if (need.length === 0) return true;
    const perms: string[] = req.user?.perms || [];
    if (perms.includes('*')) return true;
    const ok = need.some((code) => perms.includes(code));
    if (!ok) throw new BizException(BizCode.FORBIDDEN, `缺少权限：${need.join(' / ')}`, HttpStatus.FORBIDDEN);
    return true;
  }
}

/** 统一响应包装：成功返回 { code:0, data, message }；SSE / 手写 res 响应原样放行 */
@Injectable()
export class TransformInterceptor implements NestInterceptor {
  intercept(ctx: ExecutionContext, next: CallHandler) {
    const res = ctx.switchToHttp().getResponse<{ headersSent?: boolean; writableEnded?: boolean }>();
    return next.handle().pipe(
      map((data) => {
        // 手动接管响应（SSE 流 / @Res() res.json）时不重复包装
        if (res?.headersSent || res?.writableEnded) return data;
        // 已经是 { code, ... } 结构（如 copilot 手写）不重复包装
        if (data && typeof data === 'object' && 'code' in data) return data;
        return { code: 0, data, message: 'ok' };
      }),
    );
  }
}

@Injectable()
export class AllExceptionsFilter implements ExceptionFilter {
  private readonly logger = new Logger('Exception');

  catch(exception: unknown, host: ExecutionContext) {
    const res = host.switchToHttp().getResponse<Response>();
    const req = host.switchToHttp().getRequest<Request & { originalUrl?: string }>();
    let code = BizCode.SERVER_ERROR;
    let message = '服务器内部错误';
    let httpStatus = HttpStatus.OK;

    if (exception instanceof BizException) {
      const payload = exception.getResponse() as { code: number; message: string };
      code = payload.code;
      message = payload.message;
      httpStatus = exception.getStatus();
    } else if (exception instanceof HttpException) {
      const payload = exception.getResponse();
      code = BizCode.PARAM_INVALID;
      message = typeof payload === 'string' ? payload : ((payload as any).message || '请求失败');
      if (Array.isArray(message)) message = message.join('; ');
      httpStatus = exception.getStatus();
    } else if (exception instanceof Error) {
      message = exception.message || message;
      this.logger.error(`${req.method} ${req.originalUrl || req.url} ${message}`, exception.stack);
    }

    res.status(httpStatus).json({ code, data: null, message });
  }
}

/**
 * 把 @DataScope 声明翻译成查询条件片段（行级数据权限）。
 * 规则：
 *  - 用户自身 dataScope=ALL 时直通（管理员/演示上下文看全部）；
 *  - 否则取「接口声明级别」与「用户级别」中更严格的一个；
 *  - SELF：创建人 = 当前用户；
 *  - DEPT/ORG：优先用表上的 dept_id/org_id 列；没有该列时按创建人反查 sys_user/sys_dept。
 * opts 用于告诉函数业务表上到底有哪些列，避免写死字段名。
 */
const SCOPE_RANK: Record<string, number> = { SELF: 1, DEPT: 2, ORG: 3, ALL: 4 };

export interface DataScopeColumns {
  deptCol?: string;
  orgCol?: string;
  creatorCol?: string;
}

export function buildDataScopeWhere(
  level: string,
  ctx: RequestContext,
  alias = 't',
  opts: DataScopeColumns = {},
): { sql: string; params: any[] } {
  if (!ctx || ctx.dataScope === 'ALL') return { sql: '', params: [] };
  const declared = SCOPE_RANK[level] ?? 4;
  const owned = SCOPE_RANK[ctx.dataScope] ?? 4;
  const effective = Math.min(declared, owned);
  if (effective >= 4) return { sql: '', params: [] };

  const creatorCol = opts.creatorCol || 'created_by';
  const tenant = ctx.tenantId;

  if (effective <= 1) {
    return { sql: ` AND ${alias}.${creatorCol} = ? `, params: [ctx.userId] };
  }

  if (effective === 2) {
    if (opts.deptCol) return { sql: ` AND ${alias}.${opts.deptCol} = ? `, params: [ctx.deptId] };
    // 业务表没有部门列：按创建人所属部门过滤
    return {
      sql: ` AND ${alias}.${creatorCol} IN (SELECT id FROM sys_user WHERE tenant_id=? AND dept_id=?) `,
      params: [tenant, ctx.deptId],
    };
  }

  if (opts.orgCol) return { sql: ` AND ${alias}.${opts.orgCol} = ? `, params: [ctx.orgId] };
  // ORG：优先按部门树里的组织归属，退化到用户表 org_id
  if (opts.deptCol) {
    return {
      sql: ` AND ${alias}.${opts.deptCol} IN (SELECT id FROM sys_dept WHERE tenant_id=? AND org_id=?) `,
      params: [tenant, ctx.orgId],
    };
  }
  return {
    sql: ` AND ${alias}.${creatorCol} IN (SELECT id FROM sys_user WHERE tenant_id=? AND org_id=?) `,
    params: [tenant, ctx.orgId],
  };
}

/** 把 buildDataScopeWhere 的结果安全追加到 where 数组与参数数组（兼容 join(' AND ') 写法） */
export function appendDataScope(where: string[], args: any[], scope: { sql: string; params: any[] }) {
  const cond = String(scope?.sql || '').replace(/^\s*AND\s+/i, '').trim();
  if (!cond) return;
  where.push(cond);
  args.push(...(scope?.params || []));
}

/** 敏感字段 → 查看权限码映射；用于响应字段级裁剪 */
const SENSITIVE_FIELD_PERMS: Record<string, string> = {
  cost: 'field:cost:view', cost_price: 'field:cost:view', costPrice: 'field:cost:view',
  avg_cost: 'field:cost:view', avgCost: 'field:cost:view',
  phone: 'field:phone:view', mobile: 'field:phone:view', customer_phone: 'field:phone:view',
  supplier_phone: 'field:phone:view', tel: 'field:phone:view',
  id_no: 'field:idno:view', idNo: 'field:idno:view', id_card: 'field:idno:view', idCard: 'field:idno:view',
  bank_account: 'field:bank:view', bankAccount: 'field:bank:view',
};

/** 按权限裁剪单个对象中的敏感字段（递归处理数组/嵌套对象，最多 6 层防止环引用） */
export function maskSensitiveFields(data: any, ctx: RequestContext, depth = 0): any {
  if (!data || typeof data !== 'object' || depth > 6) return data;
  // 管理员（含演示上下文）持有 *，不做裁剪
  const perms = ctx?.perms || [];
  if (perms.includes('*')) return data;
  if (Array.isArray(data)) return data.map((item) => maskSensitiveFields(item, ctx, depth + 1));
  const out: any = {};
  for (const [key, value] of Object.entries(data)) {
    const need = SENSITIVE_FIELD_PERMS[key];
    if (need && !perms.includes(need)) continue; // 无权限：整个字段从响应中剔除
    out[key] = maskSensitiveFields(value, ctx, depth + 1);
  }
  return out;
}

/** 全局响应字段级权限拦截器：对所有出参统一裁剪敏感字段 */
@Injectable()
export class FieldMaskInterceptor implements NestInterceptor {
  intercept(_ctx: ExecutionContext, next: CallHandler) {
    return next.handle().pipe(map((data) => maskSensitiveFields(data, currentContext())));
  }
}

/** 分页参数标准化：页码从 1 开始，单页上限 200，防止一次拉爆内存 */
export function normalizePage(page?: number | string, pageSize?: number | string) {
  const p = Math.max(1, Number(page) || 1);
  const s = Math.min(200, Math.max(1, Number(pageSize) || 20));
  return { page: p, pageSize: s, skip: (p - 1) * s };
}

/** 构造分页返回体，与文档约定 { list, total, page, pageSize } 一致 */
export function pageResult<T>(list: T[], total: number, page: number, pageSize: number) {
  return { list, total, page, pageSize };
}
