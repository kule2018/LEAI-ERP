import Decimal from 'decimal.js';

/**
 * 金额/数量计算工具。
 * 文档全局约束：金额 DECIMAL(14,2)、数量 DECIMAL(14,3)，前端用字符串传递，
 * 禁止 JS 浮点直接运算，一律走 decimal.js。
 * 这里统一收口：所有加减乘除返回字符串，避免精度丢失。
 */

// 金额加法，返回保留 2 位的字符串
export function addMoney(a: string | number, b: string | number): string {
  return new Decimal(a).plus(new Decimal(b)).toFixed(2);
}

// 金额减法
export function subMoney(a: string | number, b: string | number): string {
  return new Decimal(a).minus(new Decimal(b)).toFixed(2);
}

// 数量 × 单价 = 金额（数量 3 位、金额 2 位）
export function calcAmount(qty: string | number, price: string | number): string {
  return new Decimal(qty).times(new Decimal(price)).toFixed(2);
}

// 数量比较：a >= b 返回 true，用于库存充足校验
export function qtyGte(a: string | number, b: string | number): boolean {
  return new Decimal(a).gte(new Decimal(b));
}

// 数量减法，返回 3 位字符串
export function subQty(a: string | number, b: string | number): string {
  return new Decimal(a).minus(new Decimal(b)).toFixed(3);
}

// 数量加法
export function addQty(a: string | number, b: string | number): string {
  return new Decimal(a).plus(new Decimal(b)).toFixed(3);
}
