import { randomUUID } from 'crypto';

/**
 * 极简内存仓储（骨架专用，替代 MySQL + TypeORM）。
 *
 * 设计说明：
 * - 真实项目里这一层是 TypeORM Repository，并按 tenant_id 自动过滤；
 * - 这里用 Map 存数据，字段结构与文档 5.2 的表一致，方便后续平滑替换为真实表；
 * - 每条记录都要求带 tenantId，查询一律按租户隔离，模拟多租户逻辑隔离。
 */
export class InMemoryRepository<T extends { id?: number; tenantId?: number }> {
  // 表名，仅用于日志与报错定位
  private readonly store = new Map<number, T>();
  private autoId = 1;

  constructor(private readonly tableName: string) {}

  // 新增：自动分配自增主键，写入前补上租户
  create(data: Partial<T>, tenantId: number): T {
    const entity = { ...data, id: this.autoId++, tenantId } as T;
    this.store.set(entity.id, entity);
    return entity;
  }

  // 按主键查（带租户校验，跨租户查不到）
  findOne(id: number, tenantId: number): T | null {
    const entity = this.store.get(id);
    if (!entity || entity.tenantId !== tenantId) {
      return null;
    }
    return entity;
  }

  // 按条件查列表（带租户过滤）
  findMany(tenantId: number, predicate?: (item: T) => boolean): T[] {
    const result: T[] = [];
    for (const entity of this.store.values()) {
      if (entity.tenantId !== tenantId) {
        continue;
      }
      if (predicate && !predicate(entity)) {
        continue;
      }
      result.push(entity);
    }
    return result;
  }

  // 更新：只改传入字段，租户不匹配返回 null
  update(id: number, tenantId: number, patch: Partial<T>): T | null {
    const entity = this.findOne(id, tenantId);
    if (!entity) {
      return null;
    }
    const merged = { ...entity, ...patch, id: entity.id, tenantId: entity.tenantId };
    this.store.set(id, merged);
    return merged;
  }

  // 骨架里不做物理删除：业务单据一律作废（软删除），此处仅演示删除能力
  delete(id: number, tenantId: number): boolean {
    const entity = this.findOne(id, tenantId);
    if (!entity) {
      return false;
    }
    return this.store.delete(id);
  }

  // 清空：仅供种子数据重置使用
  clear(): void {
    this.store.clear();
    this.autoId = 1;
  }

  // 生成一个业务流水号（如 SL_0001），骨架用随机后缀避免重复
  static nextNo(prefix: string): string {
    return `${prefix}_${randomUUID().slice(0, 6).toUpperCase()}`;
  }
}
