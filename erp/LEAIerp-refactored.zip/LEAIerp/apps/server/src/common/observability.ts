/**
 * 轻量可观测：结构化 JSON 日志（逐行 stdout）、进程/请求指标（Prometheus 文本格式）、
 * 全局未捕获异常统一日志。不引入任何新依赖。
 */
import { Controller, Get, Header, Injectable, LoggerService, Module } from '@nestjs/common';

/** 输出一行 JSON 日志 */
function jsonLine(level: string, message: string, meta: Record<string, any> = {}) {
  const record = { ts: new Date().toISOString(), level, msg: message, ...meta };
  try { process.stdout.write(`${JSON.stringify(record)}\n`); } catch { /* stdout 不可写时忽略 */ }
}

/** Nest 日志门面：所有框架日志统一成 JSON 行 */
@Injectable()
export class JsonLogger implements LoggerService {
  private meta(args: any[]): Record<string, any> {
    const last = args[args.length - 1];
    if (last && typeof last === 'object' && !(last instanceof Error)) return last;
    return args.length ? { context: String(args[0]) } : {};
  }
  log(message: any, ...args: any[]) { jsonLine('info', String(message), this.meta(args)); }
  error(message: any, ...args: any[]) {
    const err = message instanceof Error ? message : null;
    jsonLine('error', String(err?.message || message), { ...this.meta(args), ...(err ? { stack: err.stack } : {}) });
  }
  warn(message: any, ...args: any[]) { jsonLine('warn', String(message), this.meta(args)); }
  debug(message: any, ...args: any[]) { jsonLine('debug', String(message), this.meta(args)); }
  verbose(message: any, ...args: any[]) { jsonLine('debug', String(message), this.meta(args)); }
}

/** 安装进程级未捕获异常日志（只记录，不改变原有崩溃/继续策略） */
export function installGlobalErrorLogging() {
  process.on('uncaughtException', (err: any) => {
    jsonLine('fatal', 'uncaughtException', { error: String(err?.stack || err) });
  });
  process.on('unhandledRejection', (reason: any) => {
    jsonLine('error', 'unhandledRejection', { error: String(reason?.stack || reason) });
  });
}

/** 转义 Prometheus 标签值 */
function esc(value: string): string {
  return String(value).replace(/\\/g, '\\\\').replace(/"/g, '\\"').replace(/\n/g, '\\n');
}

@Injectable()
export class MetricsService {
  private readonly startedAt = Date.now();
  private readonly counters = new Map<string, number>();
  private readonly durations = new Map<string, { count: number; sum: number; max: number }>();

  private inc(key: string, value = 1) {
    this.counters.set(key, (this.counters.get(key) || 0) + value);
  }

  /** 由入口中间件调用：记录一次 HTTP 请求的状态与耗时 */
  observe(method: string, path: string, status: number, durationMs: number) {
    const route = path || 'unknown';
    this.inc(`erp_http_requests_total{method="${esc(method)}",path="${esc(route)}",status="${status}"}`);
    if (status >= 500) this.inc('erp_http_server_errors_total');
    const key = `{method="${esc(method)}",path="${esc(route)}"}`;
    const stat = this.durations.get(key) || { count: 0, sum: 0, max: 0 };
    stat.count += 1;
    stat.sum += Math.max(0, durationMs);
    stat.max = Math.max(stat.max, durationMs);
    this.durations.set(key, stat);
  }

  /** 业务侧可手工递增自定义计数器 */
  increment(name: string, value = 1) { this.inc(name, value); }

  /** 输出 Prometheus 文本格式快照 */
  snapshot(): string {
    const mem = process.memoryUsage();
    const lines: string[] = [
      '# HELP erp_process_uptime_seconds 进程运行秒数',
      '# TYPE erp_process_uptime_seconds gauge',
      `erp_process_uptime_seconds ${((Date.now() - this.startedAt) / 1000).toFixed(3)}`,
      '# HELP erp_process_memory_rss_bytes 进程常驻内存字节数',
      '# TYPE erp_process_memory_rss_bytes gauge',
      `erp_process_memory_rss_bytes ${mem.rss}`,
      '# HELP erp_process_heap_used_bytes V8 堆已用字节数',
      '# TYPE erp_process_heap_used_bytes gauge',
      `erp_process_heap_used_bytes ${mem.heapUsed}`,
      '# HELP erp_http_requests_total HTTP 请求总数',
      '# TYPE erp_http_requests_total counter',
    ];
    for (const [key, value] of this.counters) {
      if (key.startsWith('erp_http_requests_total')) lines.push(`${key} ${value}`);
    }
    lines.push('# HELP erp_http_server_errors_total HTTP 5xx 错误数', '# TYPE erp_http_server_errors_total counter');
    lines.push(`erp_http_server_errors_total ${this.counters.get('erp_http_server_errors_total') || 0}`);
    lines.push('# HELP erp_http_request_duration_seconds HTTP 请求耗时', '# TYPE erp_http_request_duration_seconds summary');
    for (const [key, stat] of this.durations) {
      lines.push(`erp_http_request_duration_seconds_sum${key} ${(stat.sum / 1000).toFixed(6)}`);
      lines.push(`erp_http_request_duration_seconds_count${key} ${stat.count}`);
      lines.push(`erp_http_request_duration_seconds_max${key} ${(stat.max / 1000).toFixed(6)}`);
    }
    // 业务自定义计数器（排除内置项）
    lines.push('# HELP erp_custom_total 业务自定义计数器', '# TYPE erp_custom_total counter');
    for (const [key, value] of this.counters) {
      if (key.startsWith('erp_http_')) continue;
      lines.push(`${key} ${value}`);
    }
    return `${lines.join('\n')}\n`;
  }
}

@Controller('api/v1')
export class MetricsController {
  constructor(private readonly metricsService: MetricsService) {}

  @Get('metrics')
  @Header('Content-Type', 'text/plain; version=0.0.4; charset=utf-8')
  getMetrics() { return this.metricsService.snapshot(); }
}

@Module({
  controllers: [MetricsController],
  providers: [MetricsService, JsonLogger],
  exports: [MetricsService, JsonLogger],
})
export class ObservabilityModule {}
