import { SetMetadata, CustomDecorator } from '@nestjs/common';

/**
 * 公开接口装饰器：标注后跳过 JWT 强校验（如登录、健康检查）。
 */
export function Public(): CustomDecorator {
  return SetMetadata('is_public', true);
}
