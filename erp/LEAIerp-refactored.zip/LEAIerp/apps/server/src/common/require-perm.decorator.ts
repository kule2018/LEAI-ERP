import { SetMetadata, CustomDecorator } from '@nestjs/common';

/**
 * 权限码装饰器：后端 @RequirePerm() 与前端 v-perm 指令双重校验。
 * 用法：@RequirePerm('sales:order:create')
 */
export const PERM_KEY = 'require_perm';

export function RequirePerm(perm: string): CustomDecorator {
  return SetMetadata(PERM_KEY, perm);
}
