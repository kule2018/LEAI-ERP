/**
 * 单据编码服务 / 规则执行器：
 *  - 规则：前缀 + 日期段 + 流水（长度可配）+ 重置周期（DAY/MONTH/YEAR/NEVER）+ 跳号步长 + 补号池；
 *  - 并发安全：流水递增用 MySQL 的 UPDATE ... current_no = current_no + seq_step 行锁；
 *  - 补号：作废单据调用 release() 把尾号放回 gap_pool，下次 next() 优先消费，避免断号。
 */
import { Injectable } from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';
import { DataSource } from 'typeorm';
import { currentContext } from './common';

@Injectable()
export class SequenceService {
  constructor(@InjectDataSource() private readonly dataSource: DataSource) {}

  /** 规则列表（当前租户） */
  async listRules() {
    const ctx = currentContext();
    return this.dataSource.query(
      `SELECT * FROM sys_sequence WHERE tenant_id=? ORDER BY biz_type, org_id`, [ctx.tenantId],
    );
  }

  /** 新增/修改编码规则；按 (tenant, biz_type, org_id) 幂等 */
  async saveRule(dto: any) {
    const ctx = currentContext();
    const bizType = String(dto.bizType || dto.biz_type || '').toUpperCase();
    if (!bizType) throw new Error('业务类型不能为空');
    const orgId = Number(dto.orgId || dto.org_id || 0);
    const prefix = String(dto.prefix ?? `${bizType}_`);
    const dateFormat = String(dto.dateFormat || dto.date_format || 'YYYYMMDD');
    const padLength = Math.min(10, Math.max(1, Number(dto.padLength ?? dto.pad_length ?? 4)));
    const resetRule = ['DAY', 'MONTH', 'YEAR', 'NEVER'].includes(dto.resetRule || dto.reset_rule)
      ? (dto.resetRule || dto.reset_rule) : 'DAY';
    const seqStep = Math.min(100, Math.max(1, Number(dto.seqStep ?? dto.seq_step ?? 1)));
    const remark = String(dto.remark || '').slice(0, 255);

    if (dto.id) {
      await this.dataSource.query(
        `UPDATE sys_sequence SET prefix=?, date_format=?, pad_length=?, reset_rule=?, seq_step=?, remark=?
          WHERE id=? AND tenant_id=?`,
        [prefix, dateFormat, padLength, resetRule, seqStep, remark, dto.id, ctx.tenantId],
      );
      return { id: Number(dto.id) };
    }
    const res: any = await this.dataSource.query(
      `INSERT INTO sys_sequence (tenant_id, biz_type, org_id, prefix, date_format, pad_length, reset_rule, seq_step, remark)
       VALUES (?,?,?,?,?,?,?,?,?)
       ON DUPLICATE KEY UPDATE prefix=VALUES(prefix), date_format=VALUES(date_format), pad_length=VALUES(pad_length),
         reset_rule=VALUES(reset_rule), seq_step=VALUES(seq_step), remark=VALUES(remark)`,
      [ctx.tenantId, bizType, orgId, prefix, dateFormat, padLength, resetRule, seqStep, remark],
    );
    return { id: Number(res.insertId || 0) };
  }

  /** 删除规则（含其流水），只允许删本租户 */
  async deleteRule(id: number) {
    const ctx = currentContext();
    await this.dataSource.query(`DELETE FROM sys_sequence WHERE id=? AND tenant_id=?`, [id, ctx.tenantId]);
    return { id };
  }

  /**
   * 补号：把已作废单据的流水尾号放回补号池。
   * 只接受末尾数字，例如 SO_202611170012 → 12。
   */
  async release(bizType: string, no: string, orgId = 0) {
    const ctx = currentContext();
    const match = String(no || '').match(/(\d+)$/);
    if (!match) return { released: false };
    const noNum = Number(match[1]);
    if (!Number.isFinite(noNum) || noNum <= 0) return { released: false };
    await this.ensureRule(bizType, orgId);
    const rows: any[] = await this.dataSource.query(
      `SELECT id, gap_pool FROM sys_sequence WHERE tenant_id=? AND biz_type=? AND org_id=?`,
      [ctx.tenantId, bizType, orgId],
    );
    const row = rows[0];
    if (!row) return { released: false };
    const pool = String(row.gap_pool || '').split(',').filter(Boolean).map(Number);
    if (!pool.includes(noNum)) pool.push(noNum);
    pool.sort((a, b) => a - b);
    await this.dataSource.query(`UPDATE sys_sequence SET gap_pool=? WHERE id=?`, [pool.join(','), row.id]);
    return { released: true, no: noNum };
  }

  /** 确保规则行存在（首次取号时按默认规则建行） */
  private async ensureRule(bizType: string, orgId: number) {
    const ctx = currentContext();
    await this.dataSource.query(
      `INSERT IGNORE INTO sys_sequence
        (tenant_id, biz_type, org_id, prefix, date_format, pad_length, reset_rule, seq_step)
       VALUES (?,?,?,?, 'YYYYMMDD', 4, 'DAY', 1)`,
      [ctx.tenantId, bizType, orgId, `${bizType}_`],
    );
  }

  /** 根据重置周期计算当前周期标识 */
  private periodKey(rule: any, d: Date): string {
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    switch (rule.reset_rule) {
      case 'MONTH': return `${y}${m}`;
      case 'YEAR': return `${y}`;
      case 'NEVER': return 'FOREVER';
      default: return `${y}${m}${day}`;
    }
  }

  /** 根据 date_format 生成日期段；NONE 表示不插日期 */
  private datePart(format: string, d: Date): string {
    const y = String(d.getFullYear());
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    switch (String(format || '').toUpperCase()) {
      case 'YYYYMM': return `${y}${m}`;
      case 'YYYY': return y;
      case 'YYMMDD': return `${y.slice(-2)}${m}${day}`;
      case 'NONE': case '': return '';
      default: return `${y}${m}${day}`;
    }
  }

  /** 取下一个单号，如 SO_202611170001 */
  async next(bizType: string, orgId = 0): Promise<string> {
    const ctx = currentContext();
    const tenantId = ctx.tenantId;
    await this.ensureRule(bizType, orgId);

    const rows: any[] = await this.dataSource.query(
      `SELECT id, prefix, date_format, pad_length, reset_rule, seq_step, current_no, period_key, gap_pool
         FROM sys_sequence WHERE tenant_id=? AND biz_type=? AND org_id=?`,
      [tenantId, bizType, orgId],
    );
    const rule = rows[0] || {};
    const now = new Date();
    const key = this.periodKey(rule, now);

    // 周期变化：流水归零并清空补号池（NEVER 永不重置）
    if (rule.period_key && rule.period_key !== key && rule.reset_rule !== 'NEVER') {
      await this.dataSource.query(
        `UPDATE sys_sequence SET current_no=0, gap_pool='', period_key=? WHERE tenant_id=? AND biz_type=? AND org_id=?`,
        [key, tenantId, bizType, orgId],
      );
    } else if (!rule.period_key) {
      await this.dataSource.query(
        `UPDATE sys_sequence SET period_key=? WHERE tenant_id=? AND biz_type=? AND org_id=?`,
        [key, tenantId, bizType, orgId],
      );
    }

    let no: number | null = null;
    // 补号优先：带条件的 UPDATE 保证并发下只有一个请求拿到同一个补号
    const pool = String(rule.gap_pool || '').split(',').filter(Boolean).map(Number).sort((a, b) => a - b);
    for (const candidate of pool) {
      const nextPool = pool.filter((n) => n !== candidate).join(',');
      const res: any = await this.dataSource.query(
        `UPDATE sys_sequence SET gap_pool=? WHERE tenant_id=? AND biz_type=? AND org_id=? AND gap_pool=?`,
        [nextPool, tenantId, bizType, orgId, String(rule.gap_pool || '')],
      );
      if (Number(res?.affectedRows || 0) > 0) { no = candidate; break; }
    }

    if (no === null) {
      const step = Math.max(1, Number(rule.seq_step || 1));
      await this.dataSource.query(
        `UPDATE sys_sequence SET current_no = current_no + ? WHERE tenant_id=? AND biz_type=? AND org_id=?`,
        [step, tenantId, bizType, orgId],
      );
      const fresh: any[] = await this.dataSource.query(
        `SELECT current_no FROM sys_sequence WHERE tenant_id=? AND biz_type=? AND org_id=?`,
        [tenantId, bizType, orgId],
      );
      no = Number(fresh[0]?.current_no || 1);
    }

    const prefix = String(rule.prefix ?? `${bizType}_`);
    const padLength = Math.max(1, Number(rule.pad_length || 4));
    return `${prefix}${this.datePart(rule.date_format, now)}${String(no).padStart(padLength, '0')}`;
  }
}
