import { AsyncLocalStorage } from 'async_hooks';
import { JwtPayload } from './types';

/**
 * 租户上下文。
 * 文档约定：tenant_id 由 JWT 注入，所有查询自动追加租户过滤。
 * 这里用 AsyncLocalStorage 在整条请求链路里透传当前登录用户，
 * 这样 Service 层不用层层传参也能拿到 tenantId，模拟 TypeORM 全局 Subscriber 的效果。
 */
const storage = new AsyncLocalStorage<JwtPayload>();

// 在守卫鉴权成功后调用，把用户信息写入本次请求上下文
export function runWithUser<T>(user: JwtPayload, fn: () => T): T {
  return storage.run(user, fn);
}

// 取当前用户；未登录场景返回 null（如公开接口）
export function currentUser(): JwtPayload | null {
  return storage.getStore() || null;
}

// 取当前租户 id；骨架里未登录默认落到租户 1（演示种子数据）
export function currentTenantId(): number {
  const user = storage.getStore();
  return user ? user.tenantId : 1;
}
