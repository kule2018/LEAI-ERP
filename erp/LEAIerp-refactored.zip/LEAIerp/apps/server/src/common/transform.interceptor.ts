import { CallHandler, ExecutionContext, Injectable, NestInterceptor } from '@nestjs/common';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

/**
 * 统一成功响应拦截器：所有返回包成 { code: 0, data, message }。
 * 已经是该结构（如手动返回）则不重复包装。
 */
@Injectable()
export class TransformInterceptor implements NestInterceptor {
  intercept(context: ExecutionContext, next: CallHandler): Observable<any> {
    return next.handle().pipe(
      map((data) => {
        if (data && typeof data === 'object' && 'code' in data) {
          return data;
        }
        return { code: 0, data, message: 'ok' };
      }),
    );
  }
}
