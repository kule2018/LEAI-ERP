/**
 * 全局通用类型定义。
 * 统一接口返回结构 { code, data, message } 与分页结构 { list, total, page, pageSize }。
 */

// 统一分页查询参数
export interface PageQuery {
  page: number;
  pageSize: number;
  keyword?: string;
}

// 统一分页结果
export interface PageResult<T> {
  list: T[];
  total: number;
  page: number;
  pageSize: number;
}

// JWT 载荷：登录态里始终带租户/部门/组织/数据权限，供 Guard 注入上下文
export interface JwtPayload {
  sub: number; // 用户 id
  tenantId: number; // 租户 id
  username: string;
  perms: string[]; // 权限码集合
  deptId?: number; // 部门 id（行级数据权限用）
  orgId?: number; // 组织 id（行级数据权限用）
  dataScope?: string; // SELF/DEPT/ORG/ALL，取用户所有角色中最宽松的一档
  roles?: string[]; // 角色编码
}
