/**
 * 环境变量引导模块：必须在任何业务模块之前 import。
 * ES Module 的 import 会提升并按依赖顺序求值，因此把 .env 读取独立成模块，
 * 由 main.ts 与 app.module.ts 在首行 import，确保 JWT_SECRET / DB_* 等常量
 * 在模块顶层求值时 already 就绪，避免签名/验签密钥不一致导致全站 401。
 */
import { readFileSync } from 'node:fs';

try {
  const text = readFileSync('.env', 'utf8');
  for (const line of text.split(/\r?\n/)) {
    const match = line.match(/^\s*([\w.-]+)\s*=\s*(.*?)\s*$/);
    if (!match) continue;
    const key = match[1];
    if (process.env[key]) continue;
    process.env[key] = match[2].replace(/^(['"])(.*)\1$/, '$2');
  }
} catch {
  // 无 .env 时依赖部署环境注入的变量，属正常情况
}

/** 统一的 JWT 密钥来源：签名与验签必须使用同一值 */
export const JWT_SECRET = process.env.JWT_SECRET || 'erp-dev-secret';
