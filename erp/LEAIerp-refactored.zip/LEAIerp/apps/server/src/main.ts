import { JWT_SECRET } from './load-env';
import 'reflect-metadata';
import { NestFactory } from '@nestjs/core';
import { json } from 'express';
import { ValidationPipe } from '@nestjs/common';
import { SwaggerModule, DocumentBuilder } from '@nestjs/swagger';
import { JwtService } from '@nestjs/jwt';
import { AppModule } from './app.module';
import { AllExceptionsFilter, TransformInterceptor, FieldMaskInterceptor, als, buildRequestContext } from './common/common';
import { JsonLogger, MetricsService, installGlobalErrorLogging } from './common/observability';

/** 启动入口：全局管道、拦截器、过滤器、Swagger、CORS */
async function bootstrap() {
  installGlobalErrorLogging();
  const app = await NestFactory.create(AppModule, { cors: true });
  app.use('/api/v1/ai/ocr', json({ limit: '1400kb' }));
  app.useLogger(app.get(JsonLogger));
  // 所有控制器已写全 api/v1 前缀，这里不再设置全局前缀，避免路径重复
  app.useGlobalPipes(new ValidationPipe({ whitelist: true, transform: true }));

  // 数据权限与租户隔离：JWT 解析后写入 AsyncLocalStorage，整条请求链路自动带 tenant/dataScope
  const jwtVerifier = new JwtService({ secret: JWT_SECRET });
  const metrics = app.get(MetricsService);
  app.use((req: any, res: any, next: () => void) => {
    const started = Date.now();
    res.on('finish', () => metrics.observe(req.method, req.route?.path || req.path || 'unknown', res.statusCode, Date.now() - started));
    const ctx = buildRequestContext(req, (token) => jwtVerifier.verify(token));
    if (!ctx) {
      res.status(401).json({ code: 401, data: null, message: '登录凭证无效或已过期' });
      return;
    }
    // CurrentUser 装饰器与权限守卫都读 req.user，中间件必须同步赋值（此前只写 ALS 导致恒空）
    req.user = ctx;
    als.run(ctx, () => next());
  });

  app.useGlobalInterceptors(new TransformInterceptor(), new FieldMaskInterceptor());
  app.useGlobalFilters(new AllExceptionsFilter());
  const swagger = new DocumentBuilder().setTitle('LEO ERP API').setVersion('1.0').addBearerAuth().build();
  // createDocument 是同步方法，直接取值后再注册 Swagger UI
  const doc = SwaggerModule.createDocument(app, swagger);
  SwaggerModule.setup('api-docs', app as any, doc as any);
  const port = Number(process.env.PORT || 3000);
  await app.listen(port, '0.0.0.0');
  console.log(JSON.stringify({ ts: new Date().toISOString(), level: 'info', msg: 'ERP 服务端已启动', port, docs: '/api-docs', metrics: '/api/v1/metrics' }));
}

bootstrap().catch((err: any) => {
  process.stderr.write(`${JSON.stringify({ ts: new Date().toISOString(), level: 'fatal', msg: 'ERP 服务端启动失败', error: String(err?.stack || err) })}\n`);
  process.exit(1);
});
