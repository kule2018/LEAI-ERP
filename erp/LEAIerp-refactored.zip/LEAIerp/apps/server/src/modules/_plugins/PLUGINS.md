# 扩展域插件说明（文档 14~19 章）

## 当前状态：已实现

七个扩展域已由「接口契约占位」升级为**可用实现**，全部采用单文件 `Module + Controller + Service + 原生 SQL` 风格，并在 `app.module.ts` 中注册。表结构见 `sql/03_ext_modules.sql`，种子数据见 `sql/04_ext_seed.sql`。

| 域 | 源码 | 主要路由 | 实现要点 |
|---|---|---|---|
| BPM 审批流 | `bpm/bpm.module.ts` | `GET/POST /api/v1/bpm/definitions`、`POST /start`、`GET /tasks/todo|done`、`POST /tasks/:id/handle`、`POST /instances/:id/cancel`、`GET /instances/:id|logs` | 流程定义/实例/待办/会签/委托，任务处理写流转日志 |
| BI 自定义报表 | `bi/bi.module.ts` | `GET/POST /api/v1/bi/reports`、`POST /reports/:id/run`、`GET /bi/dashboard`、`GET/POST /bi/subscriptions` | 维度指标取数、看板聚合、报表订阅 |
| CRM 深化 | `crm/crm.module.ts` | `GET/POST /api/v1/crm/leads|opportunities|follows|quotations` | 线索评分、商机推进、跟进记录、报价 |
| WMS 深化 | `wms/wms.module.ts` | `GET/POST /api/v1/wms/putaways|waves|stocktakes|transfers|crossdocks` | 波次拣货、上架、盘点、调拨、越库，盘点盈亏回写库存 |
| MES 深化 | `mes/mes.module.ts` | `GET/POST /api/v1/mes/routings|mrp|workorders|qc|equipment|reports` | 工艺路线、MRP 运算、工单、质检、设备 |
| 商城集成 | `shop/shop.module.ts` | `GET/POST /api/v1/shop/stores|goods-maps|orders`、`POST /stores/:id/sync`、`/orders/:id/convert|ship` | 多平台店铺、商品映射、订单同步并转销售单 |
| 移动端 | `mobile/mobile.module.ts` | `POST /api/v1/mobile/scan`、`/batch-stocktake`、`/approvals/:id` | 扫码、离线盘点批量提交、移动审批，复用同一套鉴权 |

## 启用方式

- 默认全部启用：`app.module.ts` 的 `imports` 数组已注册全部七个模块。
- 按需关闭：注释掉对应模块的 import 与注册项即可，不影响其他模块编译。
- 权限码由 `sql/04_ext_seed.sql` 写入 `sys_permission`，管理员角色已授权。

## 已知的后续增强项

- `sql/03_ext_modules.sql` 中 `mobile_scan_log` 有重复定义（幂等建表语句重复一次，不影响执行结果）。
- 文档中列出的部分深化表（如 `fin_invoice`、`crm_customer`、`wms_location`）尚未建表，可按同一范式扩展到新的迁移脚本。
- 扩展域的接口以单文件模块实现，若后续业务复杂化，可再拆分为 entity / dto / service 多文件结构。
