/**
 * AI 能力中枢（文档第 12 章）
 * 统一入口 POST /api/v1/ai/{capability}；支持 SSE 流式；无 API Key / 超时 → 本地规则引擎兜底。
 * 每次调用写 ai_audit_log（token、耗时、是否降级、是否采纳）。
 */
import { Body, Controller, Get, Injectable, Module, Param, Post, Query, Req, Res } from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';
import { DataSource } from 'typeorm';
import { BizException, BizCode, RequirePerm, currentContext } from '../../common/common';
import { AuditService } from '../../common/audit.service';
import Decimal from 'decimal.js';

interface LlmReply { text: string; model: string; fallback: boolean; promptTokens: number; completionTokens: number; latencyMs: number; }

@Injectable()
export class AiService {
  constructor(@InjectDataSource() private readonly dataSource: DataSource, private readonly audit: AuditService) {}

  /**
   * 模型网关：有 API Key 调远端，无 Key 或失败走规则兜底
   * @param capability 能力码，如 ai.copilot
   * @param prompt 已渲染的提示词
   * @param userMsg 用户输入（兜底规则用）
   */
  async chat(capability: string, prompt: string, userMsg: string, modelCode?: string, imageUrl?: string): Promise<LlmReply> {
    const started = Date.now();
    const content = imageUrl
      ? [{ type: 'text', text: userMsg }, { type: 'image_url', image_url: { url: imageUrl } }]
      : userMsg;
    const cfg = await this.modelConfig(modelCode);
    if (!cfg.apiKey) {
      return this.fallback(capability, userMsg, started, '未配置 AI API Key');
    }
    try {
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), Number(cfg.timeout || 20000));
      const resp = await fetch(String(cfg.baseUrl || 'https://api.deepseek.com').replace(/\/$/, '') + '/chat/completions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${cfg.apiKey}` },
        body: JSON.stringify({
          model: cfg.model || 'deepseek-chat',
          temperature: Number(cfg.temperature ?? 0.2),
          messages: [{ role: 'system', content: prompt }, { role: 'user', content }],
        }),
        signal: controller.signal,
      });
      clearTimeout(timer);
      if (!resp.ok) throw new Error(`模型接口返回 ${resp.status}`);
      const json: any = await resp.json();
      const text = json?.choices?.[0]?.message?.content || '';
      return { text, model: String(cfg.model || 'deepseek-chat'), fallback: false,
        promptTokens: json?.usage?.prompt_tokens || 0, completionTokens: json?.usage?.completion_tokens || 0,
        latencyMs: Date.now() - started };
    } catch (err: any) {
      return this.fallback(capability, userMsg, started, err?.message || '模型调用失败');
    }
  }

  /** 写审计日志（不阻断主流程） */
  async auditLog(capability: string, reply: LlmReply, request: string, accepted = 0) {
    const ctx = currentContext();
    await this.audit.write('AI', capability, 0, '', `model=${reply.model} fallback=${reply.fallback} accepted=${accepted}`);
    await this.dataSource.query(
      `INSERT INTO ai_audit_log (tenant_id, capability, user_id, model, prompt_tokens, completion_tokens, latency_ms, accepted, fallback, request, response)
       VALUES (?,?,?,?,?,?,?,?,?,?,?)`,
      [ctx?.tenantId || 1, capability, ctx?.userId || 0, reply.model, reply.promptTokens, reply.completionTokens,
        reply.latencyMs, accepted, reply.fallback ? 1 : 0, String(request).slice(0, 2000), String(reply.text).slice(0, 4000)])
      .catch(() => undefined);
  }

  /** 取提示词模板：优先用 ai_prompt_version 中已启用的版本，未迁移时回退 ai_prompt */
  async prompt(code: string, vars: Record<string, string> = {}) {
    const ctx = currentContext();
    const tenant = ctx?.tenantId || 1;
    const versions = await this.safeQuery(
      `SELECT * FROM ai_prompt_version WHERE tenant_id=? AND code=? AND is_deleted=0
        ORDER BY is_active DESC, version DESC LIMIT 1`, [tenant, code]);
    const legacy = versions.length ? [] : await this.safeQuery(
      `SELECT * FROM ai_prompt WHERE tenant_id=? AND code=? AND is_deleted=0 ORDER BY version DESC LIMIT 1`, [tenant, code]);
    const row = versions[0] || legacy[0] || {};
    let content = String(row.content || `你是企业 ERP 助手，请用简洁中文回答。数据：{{data}}`);
    for (const [k, v] of Object.entries(vars)) content = content.split(`{{${k}}}`).join(v);
    return { content, model: row.model || null,
      temperature: Number(row.temperature ?? 0.2), version: Number(row.version || 1) };
  }

  /** 表未迁移时不让核心能力报错，统一降级为空结果 */
  private async safeQuery(sql: string, params: any[] = []): Promise<any[]> {
    try { return await this.dataSource.query(sql, params); } catch { return []; }
  }

  /**
   * 知识库上传（文档 12.6 POST /ai/rag/upload）。
   * 文档正文写入 knowledge_doc.content，供 rag/query 做关键词召回。
   * @param dto.title 文档标题
   * @param dto.content 文档正文
   */
  async uploadDoc(dto: { title: string; content: string }) {
    const ctx = currentContext();
    if (!dto.title || !dto.content) throw new BizException(BizCode.PARAM_INVALID, '标题和内容不能为空');
    const res: any = await this.dataSource.query(
      `INSERT INTO knowledge_doc (tenant_id, title, content, status, created_by) VALUES (?,?,?,1,?)`,
      [ctx.tenantId, dto.title, String(dto.content).slice(0, 20000), ctx.userId]);
    await this.audit.write('CREATE', 'KNOWLEDGE_DOC', res.insertId, dto.title, '知识库文档上传');
    return { id: res.insertId };
  }

  /** 读取模型配置：密钥只回传是否已配置，不明文外泄 */
  async getConfig() {
    const rows: any[] = await this.dataSource.query(`SELECT cfg_key, cfg_value FROM sys_config WHERE cfg_key LIKE 'ai_%'`);
    const map: Record<string, string> = {};
    for (const r of rows) map[r.cfg_key] = r.cfg_value;
    return {
      model: map.ai_model || 'deepseek-chat',
      baseUrl: map.ai_base_url || 'https://api.deepseek.com',
      timeout: Number(map.ai_timeout || 20000),
      temperature: Number(map.ai_temperature ?? 0.2),
      hasApiKey: !!map.ai_api_key,
    };
  }

  /** 保存模型配置：逐项 upsert sys_config，并留审计痕迹 */
  async saveConfig(dto: any) {
    const ctx = currentContext();
    const keys = ['ai_model', 'ai_api_key', 'ai_base_url', 'ai_timeout', 'ai_temperature'];
    for (const key of keys) {
      if (dto[key] === undefined) continue;
      await this.dataSource.query(
        `INSERT INTO sys_config (tenant_id, cfg_key, cfg_value, created_by) VALUES (?,?,?,?)
         ON DUPLICATE KEY UPDATE cfg_value=VALUES(cfg_value), updated_by=VALUES(created_by)`,
        [ctx.tenantId, key, String(dto[key]), ctx.userId]);
    }
    await this.audit.write('UPDATE', 'AI_CONFIG', 0, '', 'AI 模型配置变更');
    return this.getConfig();
  }

  /** 解析密钥别名（形如 AI_API_KEY 或 env:AI_API_KEY），不返回明文配置 */
  private resolveSecret(alias?: string): string | null {
    if (!alias) return null;
    return process.env[String(alias).replace(/^env:/i, '')] || null;
  }

  /**
   * 模型配置解析：ai_model 注册表优先（支持按 modelCode 选择），
   * 未配置/未迁移时回退 sys_config + 环境变量，保证无密钥仍能规则兜底。
   */
  private async modelConfig(modelCode?: string) {
    const tenant = currentContext()?.tenantId || 1;
    const legacyRows: any[] = await this.safeQuery(
      `SELECT cfg_key, cfg_value FROM sys_config WHERE cfg_key IN ('ai_model','ai_api_key','ai_base_url','ai_timeout','ai_temperature')`);
    const map: Record<string, string> = {};
    for (const r of legacyRows) map[r.cfg_key] = r.cfg_value;
    const pick = (a?: string, b?: string) => a || b || null;
    const base = {
      model: pick(map.ai_model, process.env.AI_MODEL) || 'deepseek-chat',
      apiKey: pick(map.ai_api_key, process.env.AI_API_KEY),
      baseUrl: pick(map.ai_base_url, process.env.AI_BASE_URL) || 'https://api.deepseek.com',
      timeout: pick(map.ai_timeout, process.env.AI_TIMEOUT) || 20000,
      temperature: pick(map.ai_temperature, process.env.AI_TEMPERATURE) ?? 0.2,
      modelCode: null as string | null,
      contextLength: 0,
      mock: false,
    };

    const models = modelCode
      ? await this.safeQuery(`SELECT * FROM ai_model WHERE tenant_id=? AND code=? AND is_deleted=0`, [tenant, modelCode])
      : await this.safeQuery(
          `SELECT * FROM ai_model WHERE tenant_id=? AND enabled=1 AND is_deleted=0
            ORDER BY is_default DESC, id DESC LIMIT 1`, [tenant]);
    const row = models[0];
    if (!row) return base;
    // 本地规则引擎永远不请求远端：即使系统里配了全局密钥也强制走兜底
    if (row.code === 'local-rule') {
      return { ...base, model: 'local-rule', apiKey: null, modelCode: 'local-rule',
        contextLength: Number(row.context_length || 4096), mock: true };
    }
    const params = this.safeJson(row.default_params_json);
    const secret = this.resolveSecret(row.secret_alias) || base.apiKey;
    return {
      model: row.model_name || base.model,
      apiKey: secret,
      baseUrl: row.endpoint || base.baseUrl,
      timeout: Number(row.timeout_sec || base.timeout),
      temperature: Number(params.temperature ?? base.temperature),
      modelCode: row.code || null,
      contextLength: Number(row.context_length || 0),
      mock: !secret,
    };
  }

  private safeJson(value: any): any {
    if (!value) return {};
    if (typeof value === 'object') return value;
    try { return JSON.parse(value); } catch { return {}; }
  }

  // ---------------- 模型注册 / 提示词版本 / 工具 / MCP 配置 ----------------

  listModels() {
    const ctx = currentContext();
    return this.safeQuery(
      `SELECT id, code, provider, model_name, endpoint, secret_alias, context_length,
              default_params_json, enabled, is_default, health_status, last_check_at, status
         FROM ai_model WHERE tenant_id=? AND is_deleted=0 ORDER BY is_default DESC, id`, [ctx.tenantId]);
  }

  /** 注册/更新模型；isDefault=1 时先清掉其他默认模型 */
  async saveModel(dto: any) {
    const ctx = currentContext();
    const code = String(dto.code || '').trim();
    if (!code) throw new BizException(BizCode.PARAM_INVALID, '模型编码不能为空');
    if (Number(dto.isDefault || 0) === 1) {
      await this.safeQuery(`UPDATE ai_model SET is_default=0 WHERE tenant_id=?`, [ctx.tenantId]);
    }
    await this.safeQuery(
      `INSERT INTO ai_model
        (tenant_id, code, provider, model_name, endpoint, secret_alias, context_length,
         default_params_json, timeout_sec, enabled, is_default, status, created_by)
       VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)
       ON DUPLICATE KEY UPDATE provider=VALUES(provider), model_name=VALUES(model_name),
         endpoint=VALUES(endpoint), secret_alias=VALUES(secret_alias), context_length=VALUES(context_length),
         default_params_json=VALUES(default_params_json), timeout_sec=VALUES(timeout_sec),
         enabled=VALUES(enabled), is_default=VALUES(is_default), status=VALUES(status)`,
      [ctx.tenantId, code, dto.provider || 'OPENAI_COMPATIBLE', dto.modelName || dto.model_name || code,
        dto.endpoint || null, dto.secretAlias || dto.secret_alias || null,
        Number(dto.contextLength || dto.context_length || 4096),
        typeof dto.defaultParams === 'string' ? dto.defaultParams : JSON.stringify(dto.defaultParams || {}),
        Number(dto.timeoutSec || dto.timeout_sec || 20000), dto.enabled ?? 1, dto.isDefault ?? 0,
        dto.status || 'ACTIVE', ctx.userId],
    );
    await this.audit.write('UPDATE', 'AI_MODEL', 0, code, '模型注册配置变更');
    return { code };
  }

  /** 健康检查：无 endpoint/密钥时返回模拟结果，不阻断配置保存 */
  async checkModel(id: number) {
    const rows: any[] = await this.safeQuery(
      `SELECT * FROM ai_model WHERE id=? AND tenant_id=? AND is_deleted=0`, [id, currentContext().tenantId]);
    const row = rows[0];
    if (!row) throw new BizException(BizCode.NOT_FOUND, '模型不存在');
    const started = Date.now();
    const secret = this.resolveSecret(row.secret_alias);
    let ok = false; let message = ''; let mock = false;
    if (!row.endpoint || !secret) {
      mock = true; message = '未配置 endpoint 或密钥别名对应的环境变量，模拟健康检查通过';
      ok = true;
    } else {
      try {
        const controller = new AbortController();
        const timer = setTimeout(() => controller.abort(), 3000);
        const resp = await fetch(String(row.endpoint).replace(/\/$/, '') + '/models', {
          headers: { Authorization: `Bearer ${secret}` }, signal: controller.signal,
        });
        clearTimeout(timer);
        ok = resp.ok; message = `模型端点返回 ${resp.status}`;
      } catch (e: any) {
        message = String(e?.message || e);
      }
    }
    const latencyMs = Date.now() - started;
    await this.safeQuery(`UPDATE ai_model SET health_status=?, last_check_at=NOW(3) WHERE id=?`,
      [ok ? 'HEALTHY' : 'UNHEALTHY', id]);
    return { id, ok, mock, message, latencyMs };
  }

  listPromptVersions(code?: string) {
    const ctx = currentContext();
    return this.safeQuery(
      `SELECT * FROM ai_prompt_version WHERE tenant_id=? AND is_deleted=0 ${code ? 'AND code=?' : ''}
        ORDER BY code, version DESC`, code ? [ctx.tenantId, code] : [ctx.tenantId]);
  }

  /** 保存提示词新版本：自动递增版本号，同时兼容写入 ai_prompt */
  async savePromptVersion(dto: any) {
    const ctx = currentContext();
    const code = String(dto.code || '').trim();
    if (!code) throw new BizException(BizCode.PARAM_INVALID, '提示词编码不能为空');
    const maxRows: any[] = await this.safeQuery(
      `SELECT COALESCE(MAX(version),0) v FROM ai_prompt_version WHERE tenant_id=? AND code=?`, [ctx.tenantId, code]);
    const version = Number(dto.version || 0) || Number(maxRows[0]?.v || 0) + 1;
    const content = String(dto.content || '');
    await this.safeQuery(
      `INSERT INTO ai_prompt_version
        (tenant_id, code, name, content, model, temperature, version, is_active, change_log, created_by)
       VALUES (?,?,?,?,?,?,?,?,?,?)`,
      [ctx.tenantId, code, dto.name || code, content, dto.model || null,
        Number(dto.temperature ?? 0.2), version, dto.isActive ?? 0,
        String(dto.changeLog || dto.change_log || '').slice(0, 500), ctx.userId],
    );
    await this.safeQuery(
      `INSERT INTO ai_prompt (tenant_id, code, name, content, model, temperature, version, is_active)
       VALUES (?,?,?,?,?,?,?,?)
       ON DUPLICATE KEY UPDATE content=VALUES(content), temperature=VALUES(temperature), is_active=VALUES(is_active)`,
      [ctx.tenantId, code, dto.name || code, content, dto.model || null,
        Number(dto.temperature ?? 0.2), version, dto.isActive ?? 0],
    );
    await this.audit.write('CREATE', 'AI_PROMPT', 0, code, `提示词版本 v${version}`);
    return { code, version };
  }

  /** 启用指定版本：同 code 的其他版本全部停用 */
  async activatePromptVersion(id: number) {
    const ctx = currentContext();
    const rows: any[] = await this.safeQuery(
      `SELECT code, version FROM ai_prompt_version WHERE id=? AND tenant_id=?`, [id, ctx.tenantId]);
    if (!rows[0]) throw new BizException(BizCode.NOT_FOUND, '提示词版本不存在');
    await this.safeQuery(`UPDATE ai_prompt_version SET is_active=0 WHERE tenant_id=? AND code=?`, [ctx.tenantId, rows[0].code]);
    await this.safeQuery(`UPDATE ai_prompt_version SET is_active=1 WHERE id=?`, [id]);
    await this.safeQuery(`UPDATE ai_prompt SET is_active=CASE WHEN version=? THEN 1 ELSE 0 END WHERE tenant_id=? AND code=?`,
      [rows[0].version, ctx.tenantId, rows[0].code]);
    await this.audit.write('AUDIT', 'AI_PROMPT', id, rows[0].code, `启用提示词版本 v${rows[0].version}`);
    return { id, code: rows[0].code, version: Number(rows[0].version) };
  }

  /** 轻量文本 diff：逐行比较，返回新增/删除行，不引入 diff 依赖 */
  async promptDiff(code: string, v1: number, v2: number) {
    const ctx = currentContext();
    const rows: any[] = await this.safeQuery(
      `SELECT version, content FROM ai_prompt_version
        WHERE tenant_id=? AND code=? AND version IN (?,?) ORDER BY version`, [ctx.tenantId, code, v1, v2]);
    const left = rows.find((r) => Number(r.version) === Number(v1));
    const right = rows.find((r) => Number(r.version) === Number(v2));
    if (!left || !right) throw new BizException(BizCode.NOT_FOUND, '对比版本不存在');
    const a = String(left.content).split(/\r?\n/);
    const b = String(right.content).split(/\r?\n/);
    return {
      code, v1, v2, changed: String(left.content) !== String(right.content),
      added: b.filter((line) => !a.includes(line)),
      removed: a.filter((line) => !b.includes(line)),
      left: left.content, right: right.content,
    };
  }

  listFunctions() {
    const ctx = currentContext();
    return this.safeQuery(
      `SELECT id, name, description, parameters_json, endpoint, permission_code, enabled, status
         FROM ai_function_tool WHERE tenant_id=? AND is_deleted=0 ORDER BY id`, [ctx.tenantId]);
  }

  async saveFunction(dto: any) {
    const ctx = currentContext();
    const name = String(dto.name || '').trim();
    if (!name) throw new BizException(BizCode.PARAM_INVALID, '工具名称不能为空');
    await this.safeQuery(
      `INSERT INTO ai_function_tool
        (tenant_id, name, description, parameters_json, endpoint, permission_code, enabled, status, created_by)
       VALUES (?,?,?,?,?,?,?,?,?)
       ON DUPLICATE KEY UPDATE description=VALUES(description), parameters_json=VALUES(parameters_json),
         endpoint=VALUES(endpoint), permission_code=VALUES(permission_code), enabled=VALUES(enabled), status=VALUES(status)`,
      [ctx.tenantId, name, dto.description || null,
        typeof dto.parameters === 'string' ? dto.parameters : JSON.stringify(dto.parameters || { type: 'object', properties: {} }),
        dto.endpoint || null, dto.permissionCode || dto.permission_code || null,
        dto.enabled ?? 1, dto.status || 'ACTIVE', ctx.userId],
    );
    await this.audit.write('UPDATE', 'AI_FUNCTION', 0, name, 'Function 工具注册变更');
    return { name };
  }

  listMcpServers() {
    const ctx = currentContext();
    return this.safeQuery(
      `SELECT id, code, name, transport, endpoint, capabilities_json, status, enabled, last_check_at
         FROM ai_mcp_server WHERE tenant_id=? AND is_deleted=0 ORDER BY id`, [ctx.tenantId]);
  }

  async saveMcpServer(dto: any) {
    const ctx = currentContext();
    const code = String(dto.code || '').trim();
    if (!code) throw new BizException(BizCode.PARAM_INVALID, 'MCP Server 编码不能为空');
    await this.safeQuery(
      `INSERT INTO ai_mcp_server
        (tenant_id, code, name, transport, endpoint, capabilities_json, status, enabled, created_by)
       VALUES (?,?,?,?,?,?,?,?,?)
       ON DUPLICATE KEY UPDATE name=VALUES(name), transport=VALUES(transport), endpoint=VALUES(endpoint),
         capabilities_json=VALUES(capabilities_json), status=VALUES(status), enabled=VALUES(enabled)`,
      [ctx.tenantId, code, dto.name || code, dto.transport || 'STDIO', dto.endpoint || null,
        typeof dto.capabilities === 'string' ? dto.capabilities : JSON.stringify(dto.capabilities || []),
        dto.status || 'ACTIVE', dto.enabled ?? 1, ctx.userId],
    );
    await this.audit.write('UPDATE', 'AI_MCP_SERVER', 0, code, 'MCP Server 配置变更');
    return { code };
  }

  /** 模拟 MCP 工具调用：校验权限、写审计日志，未配置真实端点时返回 mock 数据 */
  async callMcp(dto: any) {
    const ctx = currentContext();
    const serverCode = String(dto.server || dto.serverCode || '').trim();
    const tool = String(dto.tool || dto.toolName || '').trim();
    if (!serverCode || !tool) throw new BizException(BizCode.PARAM_INVALID, 'server 与 tool 必填');
    const servers: any[] = await this.safeQuery(
      `SELECT * FROM ai_mcp_server WHERE tenant_id=? AND code=? AND enabled=1 AND is_deleted=0`,
      [ctx.tenantId, serverCode]);
    if (!servers[0]) throw new BizException(BizCode.NOT_FOUND, `MCP Server 不存在或未启用：${serverCode}`);
    const tools: any[] = await this.safeQuery(
      `SELECT * FROM ai_function_tool WHERE tenant_id=? AND name=? AND enabled=1 AND is_deleted=0`,
      [ctx.tenantId, tool]);
    const perm = tools[0]?.permission_code;
    if (perm && !(ctx?.perms || []).includes('*') && !(ctx?.perms || []).includes(perm)) {
      throw new BizException(BizCode.FORBIDDEN, `调用工具缺少权限：${perm}`);
    }
    const caps = this.safeJson(servers[0].capabilities_json);
    const capabilityList = Array.isArray(caps) ? caps : (caps.tools || []);
    const mock = !servers[0].endpoint;
    const result = {
      server: serverCode, tool, mock,
      capabilities: capabilityList,
      arguments: dto.arguments || {},
      content: [{ type: 'text', text: `模拟 MCP 工具 ${serverCode}/${tool} 调用成功` }],
      at: new Date().toISOString(),
    };
    const reply: LlmReply = { text: JSON.stringify(result), model: `mcp:${serverCode}`, fallback: true,
      promptTokens: 0, completionTokens: 0, latencyMs: 0 };
    await this.auditLog(`mcp.${serverCode}.${tool}`, reply, JSON.stringify(dto.arguments || {}), 1);
    await this.audit.write('AI', 'AI_MCP_CALL', 0, `${serverCode}/${tool}`, `MCP 调用 mock=${mock}`);
    return result;
  }

  // ---------------- 规则引擎兜底 ----------------

  private async fallback(capability: string, userMsg: string, started: number, reason: string): Promise<LlmReply> {
    let text = '';
    if (capability === 'ai.forecast' || capability === 'ai.recommend') text = await this.ruleForecast();
    else if (capability === 'ai.anomaly') text = await this.ruleAnomaly();
    else if (capability === 'ai.copilot' || capability === 'ai.report') text = await this.ruleCopilot(userMsg);
    else if (capability === 'ai.doc.parse' || capability === 'ai.ocr') text = JSON.stringify({ ok: false, message: '规则引擎暂不支持图片解析，请配置 AI API Key 后重试', fields: [] });
    else if (capability === 'ai.subject.match') text = await this.ruleSubject(userMsg);
    else if (capability === 'ai.label') text = await this.ruleLabel(userMsg);
    else if (capability === 'ai.cs') text = await this.ruleCs(userMsg);
    else if (capability === 'ai.resume') text = await this.ruleResume(userMsg);
    else text = `（本地规则兜底：${reason}）系统已收到您的问题：“${userMsg}”。配置 AI 模型密钥后可获得完整智能回答。`;
    return { text, model: 'local-rule', fallback: true, promptTokens: 0, completionTokens: 0, latencyMs: Date.now() - started };
  }

  private async ruleCopilot(msg: string) {
    const tenantId = currentContext()?.tenantId || 1;
    if (msg.includes('库存') || msg.includes('预警')) {
      const rows = await this.dataSource.query(
        `SELECT p.name, b.qty_on_hand, b.qty_occupied, (b.qty_on_hand - b.qty_occupied) AS available
           FROM stock_balance b JOIN product p ON p.id=b.product_id
          WHERE b.tenant_id=? AND (b.qty_on_hand - b.qty_occupied) <= 0 LIMIT 20`, [tenantId]);
      if (!rows.length) return '当前所有产品库存均为正，暂无缺货预警。';
      return '以下产品可用量已 ≤ 0（本地规则）：\n' + rows.map((r: any, i: number) => `${i + 1}. ${r.name}：可用 ${r.available}`).join('\n');
    }
    if (msg.includes('应收') || msg.includes('欠款') || msg.includes('客户')) {
      const rows = await this.dataSource.query(
        `SELECT c.name, SUM(r.amount - r.received_amount) AS unpaid FROM receivable r JOIN customer c ON c.id=r.customer_id
          WHERE r.tenant_id=? AND r.status <> 2 GROUP BY c.id ORDER BY unpaid DESC LIMIT 10`, [tenantId]);
      return '客户应收未结 TOP（本地规则）：\n' + rows.map((r: any, i: number) => `${i + 1}. ${r.name}：${r.unpaid}`).join('\n');
    }
    return '我可以帮您：查库存预警、查客户应收、生成补货建议。请换一种问法，例如“哪些产品缺货？”';
  }

  /** 安全库存补货建议：可用量低于安全库存时建议补货 */
  private async ruleForecast() {
    const tenantId = currentContext()?.tenantId || 1;
    const rows = await this.dataSource.query(
      `SELECT p.id, p.name, p.code, IFNULL(SUM(b.qty_on_hand - b.qty_occupied),0) AS available,
              IFNULL(MAX(s.safe_qty),0) AS safe_qty
         FROM product p
         LEFT JOIN stock_balance b ON b.product_id=p.id AND b.tenant_id=p.tenant_id
         LEFT JOIN stock_alert_rule s ON s.product_id=p.id AND s.tenant_id=p.tenant_id AND s.is_active=1
        WHERE p.tenant_id=? AND p.is_deleted=0 AND p.type <> 4
        GROUP BY p.id, p.name, p.code`, [tenantId]);
    const items = rows
      .filter((r: any) => Number(r.safe_qty) > 0 && Number(r.available) < Number(r.safe_qty))
      .map((r: any) => ({ productCode: r.code, productName: r.name, predictQty: 0,
        suggestPurchaseQty: new Decimal(r.safe_qty).minus(r.available).toString(),
        reason: `可用量 ${r.available} 低于安全库存 ${r.safe_qty}（本地规则）` }));
    return JSON.stringify({ items });
  }

  private async ruleAnomaly() {
    const tenantId = currentContext()?.tenantId || 1;
    const negative: any[] = await this.dataSource.query(
      `SELECT p.name, (b.qty_on_hand - b.qty_occupied) AS available FROM stock_balance b
        JOIN product p ON p.id=b.product_id WHERE b.tenant_id=? AND (b.qty_on_hand - b.qty_occupied) < 0 LIMIT 20`, [tenantId]);
    const overdue: any[] = await this.dataSource.query(
      `SELECT c.name, r.due_date, (r.amount - r.received_amount) AS unpaid FROM receivable r
        JOIN customer c ON c.id=r.customer_id
        WHERE r.tenant_id=? AND r.status <> 2 AND r.due_date < CURDATE() ORDER BY r.due_date LIMIT 20`, [tenantId]);
    const risk = [
      ...negative.map((r) => ({ level: '高', type: '负库存', detail: `${r.name} 可用量 ${r.available}` })),
      ...overdue.map((r) => ({ level: '中', type: '应收逾期', detail: `${r.name} 逾期未收 ${r.unpaid}，到期 ${r.due_date}` })),
    ];
    return JSON.stringify({ risks: risk });
  }

  private async ruleSubject(summary: string) {
    const map: Array<[string[], string, string]> = [
      [['办公', '文具', '打印'], '6602', '管理费用'],
      [['差旅', '交通', '住宿'], '6602', '管理费用'],
      [['工资', '薪酬', '社保'], '6602', '职工薪酬'],
      [['采购', '进货', '原材料'], '1403', '原材料'],
      [['销售', '收入', '出货'], '6001', '主营业务收入'],
      [['银行', '利息', '手续费'], '6603', '财务费用'],
    ];
    for (const [keys, code, name] of map) {
      if (keys.some((k) => summary.includes(k))) return JSON.stringify({ code, name, confidence: 0.8, source: '本地规则' });
    }
    return JSON.stringify({ code: null, name: null, confidence: 0, source: '本地规则', message: '无法匹配科目' });
  }

  /**
   * 标签识别规则兜底：从产品名称推断分类与规格，并生成模拟 EAN-13 条码建议。
   * 仅有图片而无名称时不编造识别结果；若分类表存在匹配项则回填真实分类主键。
   * @param name 产品名称（图片场景由调用方传入占位文本）
   * @returns JSON 字符串：{ productName, category, categoryId, categoryCode, specs, barcode, confidence, source, message? }
   */
  private async ruleLabel(name: string) {
    const ctx = currentContext();
    if (!name || /^\[图片|请识别图片/.test(name)) {
      return JSON.stringify({ productName: '', category: null, specs: [], barcode: null, confidence: 0,
        source: '本地规则', message: '规则引擎无法直接识别图片，请配置 AI API Key 或补充产品名称后重试' });
    }
    const keywordMap: Array<[string[], string, string]> = [
      [['手机', '平板', '电脑', '笔记本', '显示器'], '电子产品', 'ELEC'],
      [['衣服', '服装', '鞋', '帽', 'T恤'], '服装鞋帽', 'CLOTH'],
      [['食品', '饮料', '零食', '牛奶', '饼干'], '食品饮料', 'FOOD'],
      [['文具', '笔', '本', '纸张', '打印纸'], '办公用品', 'OFFICE'],
      [['化妆品', '护肤', '洗发', '沐浴'], '个护美妆', 'BEAUTY'],
      [['家具', '桌椅', '柜', '沙发'], '家具家居', 'HOME'],
    ];
    const hit = keywordMap.find(([keys]) => keys.some((k) => name.includes(k)));
    let category = hit ? hit[1] : '其他';
    let categoryId: number | null = null;
    try {
      const rows: any[] = await this.dataSource.query(
        `SELECT id, name FROM category WHERE tenant_id=? AND is_deleted=0 LIMIT 100`, [ctx.tenantId]);
      const dbHit = rows.find((r) => name.includes(String(r.name)) || String(r.name).includes(name.slice(0, 2)));
      if (dbHit) { categoryId = Number(dbHit.id); category = dbHit.name; }
    } catch { /* 分类表暂无数据时保留关键词映射结果 */ }
    const specs: Array<{ name: string; value: string }> = [];
    const specRe = /(\d+(?:\.\d+)?)\s*(ml|l|kg|g|gb|tb|寸|英寸|mm|cm|m|片|支|瓶|盒|包)/gi;
    let m: RegExpExecArray | null;
    while ((m = specRe.exec(name)) !== null) specs.push({ name: '规格', value: m[0].replace(/\s+/g, '') });
    const seed = Array.from(name).reduce((s, c) => (s * 31 + c.charCodeAt(0)) >>> 0, 7);
    const digits = String(seed).padStart(12, '0').slice(-12);
    let sum = 0;
    for (let i = 0; i < 12; i++) sum += Number(digits[i]) * (i % 2 === 0 ? 1 : 3);
    const barcode = digits + String((10 - (sum % 10)) % 10);
    return JSON.stringify({ productName: name.slice(0, 200), category, categoryId,
      categoryCode: hit ? hit[2] : 'OTHER', specs, barcode,
      confidence: hit ? 0.8 : 0.4, source: '本地规则', message: '条码为本地模拟值，入库前请校验唯一性' });
  }

  /**
   * 智能客服规则兜底：按关键词给出标准话术，价格/库存类问题直接查本租户数据。
   * @param question 客户提问原文
   * @returns JSON 字符串：{ answer, products?, confidence, source }
   */
  private async ruleCs(question: string) {
    const ctx = currentContext();
    if (!question || !question.trim()) {
      return JSON.stringify({ answer: '您好，请描述您想咨询的产品或问题。', confidence: 0, source: '本地规则' });
    }
    if (/价格|报价|多少钱|优惠|便宜/.test(question)) {
      try {
        const rows: any[] = await this.dataSource.query(
          `SELECT id, name, code, price FROM product WHERE tenant_id=? AND is_deleted=0 ORDER BY id LIMIT 5`, [ctx.tenantId]);
        const products = rows.map((r) => ({ id: Number(r.id), name: r.name, code: r.code,
          price: Number(r.price || 0), suggestPrice: new Decimal(r.price || 0).mul(0.95).toDecimalPlaces(2).toString() }));
        return JSON.stringify({ answer: products.length
          ? `以下为可报价产品（本地规则，建议价按 95 折）：\n${products.map((p, i) => `${i + 1}. ${p.name} ￥${p.suggestPrice}`).join('\n')}`
          : '当前暂无可报价产品，请联系人工客服。', products, confidence: 0.7, source: '本地规则' });
      } catch { /* 查库失败时继续走通用话术 */ }
    }
    if (/库存|有货|现货|发货|交期|多久/.test(question)) {
      try {
        const rows: any[] = await this.dataSource.query(
          `SELECT p.name, (b.qty_on_hand - b.qty_occupied) AS available FROM stock_balance b
            JOIN product p ON p.id=b.product_id WHERE b.tenant_id=? ORDER BY available DESC LIMIT 10`, [ctx.tenantId]);
        return JSON.stringify({ answer: rows.length
          ? `现货情况（本地规则）：\n${rows.map((r, i) => `${i + 1}. ${r.name} 可用 ${r.available}`).join('\n')}`
          : '当前无库存数据，请咨询人工客服确认交期。', confidence: 0.7, source: '本地规则' });
      } catch { /* 查库失败时继续走通用话术 */ }
    }
    if (/售后|退货|换货|保修|维修/.test(question)) {
      return JSON.stringify({ answer: '您好，本店支持 7 天无理由退换，质保期内非人为损坏可免费维修。请提供订单号，我们将尽快为您处理。', confidence: 0.8, source: '本地规则' });
    }
    return JSON.stringify({ answer: '您好，我是智能客服助手。可为您查询产品价格、库存现货与售后政策；如需人工服务请回复“转人工”。', confidence: 0.5, source: '本地规则' });
  }

  /**
   * 简历解析规则兜底：用正则抽取姓名/联系方式/学历/年限/技能/公司/期望薪资。
   * @param text 简历纯文本
   * @returns JSON 字符串：候选人结构化字段与置信度
   */
  private async ruleResume(text: string) {
    const raw = String(text || '').slice(0, 20000);
    if (!raw.trim()) {
      return JSON.stringify({ name: null, skills: [], confidence: 0, source: '本地规则', message: '简历内容为空' });
    }
    const pick = (re: RegExp) => { const m = raw.match(re); return m ? m[1].trim() : null; };
    const firstLine = raw.split(/\r?\n/)[0].trim();
    const name = pick(/(?:姓名|名字)\s*[:：]\s*([^\s,，;；\n]{1,20})/)
      || (/^[\u4e00-\u9fa5]{2,4}$/.test(firstLine) ? firstLine : null);
    const phone = raw.match(/1[3-9]\d{9}/)?.[0] || null;
    const email = raw.match(/[\w.+-]+@[\w-]+\.[\w.-]+/)?.[0] || null;
    const education = ['博士', '硕士', '研究生', '本科', '大专', '高中'].find((e) => raw.includes(e)) || null;
    const yearMatch = raw.match(/(\d{1,2})\s*年(?:工作)?经验/) || raw.match(/(?:工作|经验)\s*(\d{1,2})\s*年/);
    const workYears = Number(yearMatch?.[1] || 0);
    const skillDict = ['Java', 'Python', 'Vue', 'React', 'TypeScript', 'Node.js', 'Spring', 'MySQL',
      'Redis', 'ERP', '财务', '销售', '采购', '仓储', '人力资源', 'Excel', 'PHP', 'Go', 'C++'];
    const skills = skillDict.filter((s) => raw.toLowerCase().includes(s.toLowerCase()));
    const companies = Array.from(new Set(
      (raw.match(/[\u4e00-\u9fa5A-Za-z0-9]{2,20}(?:有限公司|科技|集团|研究院)/g) || []).map((c) => c.trim()))).slice(0, 10);
    const expectedSalary = pick(/期望薪资\s*[:：]?\s*(\d+(?:\.\d+)?\s*[kK万])/)
      || raw.match(/(\d+(?:\.\d+)?\s*[kK万])/)?.[0] || null;
    const hits = [name, phone, email, education, workYears ? 1 : null,
      skills.length ? 1 : null, companies.length ? 1 : null, expectedSalary].filter(Boolean).length;
    return JSON.stringify({ name, phone, email, education, workYears, skills, companies, expectedSalary,
      confidence: Math.min(1, Number((hits / 8).toFixed(2))), source: '本地规则' });
  }
}

@Controller('api/v1/ai')
class AiController {
  // 审计服务独立注入，提示词保存也需要留痕
  constructor(private readonly service: AiService, private readonly audit: AuditService) {}

  @Post('copilot')
  @RequirePerm('ai:chat')
  async copilot(@Body() body: { message: string; stream?: boolean }, @Res() res: any) {
    const p = await this.service.prompt('copilot', { data: body.message });
    const reply = await this.service.chat('ai.copilot', p.content, body.message);
    await this.service.auditLog('ai.copilot', reply, body.message);
    if (body.stream) {
      // SSE 逐字输出，前端 EventSource/fetch 读取
      res.set({ 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache', Connection: 'keep-alive' });
      res.flushHeaders?.();
      const chunkSize = 16;
      for (let i = 0; i < reply.text.length; i += chunkSize) {
        res.write(`data: ${JSON.stringify({ delta: reply.text.slice(i, i + chunkSize), fallback: reply.fallback })}\n\n`);
      }
      res.write(`data: ${JSON.stringify({ done: true, model: reply.model, fallback: reply.fallback })}\n\n`);
      res.end();
      return;
    }
    return res.json({ code: 0, data: { text: reply.text, model: reply.model, fallback: reply.fallback } });
  }

  @Post('doc-parse')
  @RequirePerm('ai:doc:parse')
  async docParse(@Body() body: { content: string }) {
    const p = await this.service.prompt('doc_parse', { data: body.content || '' });
    const reply = await this.service.chat('ai.doc.parse', p.content, body.content || '');
    await this.service.auditLog('ai.doc.parse', reply, body.content || '');
    return { text: reply.text, fallback: reply.fallback };
  }

  @Post('ocr')
  @RequirePerm('ai:ocr', 'ai:ocr:use')
  async ocr(@Body() body: { imageBase64: string }) {
    const image = String(body.imageBase64 || '');
    if (image.length > 1_350_000 || !/^data:image\/(jpeg|png|webp);base64,[A-Za-z0-9+/]+={0,2}$/.test(image)) {
      throw new BizException(BizCode.PARAM_INVALID, '请选择 1 MB 以内的 JPG、PNG 或 WebP 图片');
    }
    const reply = await this.service.chat('ai.ocr', '提取图片中的文字和单据字段，输出 JSON。无法辨认的字段留空。',
      '请识别所附图片。', undefined, image);
    await this.service.auditLog('ai.ocr', reply, 'image');
    return { text: reply.text, fallback: reply.fallback };
  }

  @Post('recommend')
  @RequirePerm('ai:recommend')
  async recommend(@Body() body: { customerId?: number; productId?: number }) {
    const p = await this.service.prompt('recommend', { data: JSON.stringify(body) });
    const reply = await this.service.chat('ai.recommend', p.content, JSON.stringify(body));
    await this.service.auditLog('ai.recommend', reply, JSON.stringify(body));
    return { text: reply.text, fallback: reply.fallback };
  }

  @Post('forecast/run')
  @RequirePerm('ai:recommend')
  async forecastRun() {
    const p = await this.service.prompt('forecast', { horizon: '3', data: '' });
    const reply = await this.service.chat('ai.forecast', p.content, '请生成未来 3 期补货建议');
    await this.service.auditLog('ai.forecast', reply, 'run');
    let items: any[] = [];
    try { items = JSON.parse(reply.text)?.items || []; } catch { items = []; }
    for (const it of items) {
      await this.dataSourceQuery(it);
    }
    return { items, fallback: reply.fallback, model: reply.model };
  }

  private async dataSourceQuery(it: any) {
    const ctx = currentContext();
    await (this.service as any).dataSource.query(
      `INSERT INTO forecast_result (tenant_id, product_id, warehouse_id, period, predict_qty, suggest_purchase_qty, model, reason)
       VALUES (?,?,?,?,?,?,?,?)`,
      [ctx.tenantId, it.productId || null, it.warehouseId || 0, it.period || new Date().toISOString().slice(0, 7),
        it.predictQty || 0, it.suggestPurchaseQty || 0, 'local-rule', String(it.reason || '').slice(0, 500)])
      .catch(() => undefined);
  }

  @Get('forecast/result')
  @RequirePerm('ai:recommend')
  async forecastResult(@Query('period') period?: string) {
    const ctx = currentContext();
    const rows = await (this.service as any).dataSource.query(
      `SELECT f.*, p.name AS product_name FROM forecast_result f LEFT JOIN product p ON p.id=f.product_id
        WHERE f.tenant_id=? ${period ? 'AND f.period=?' : ''} ORDER BY f.id DESC LIMIT 100`,
      period ? [ctx.tenantId, period] : [ctx.tenantId]);
    return rows;
  }

  @Post('anomaly/scan')
  @RequirePerm('ai:report')
  async anomaly() {
    const reply = await this.service.chat('ai.anomaly', '输出风险清单 JSON', '扫描库存、价格、账期异常');
    await this.service.auditLog('ai.anomaly', reply, 'scan');
    try { return JSON.parse(reply.text); } catch { return { risks: [], raw: reply.text, fallback: reply.fallback }; }
  }

  @Post('reconcile')
  @RequirePerm('ai:report')
  async reconcile(@Body() body: { billA: any[]; billB: any[] }) {
    const reply = await this.service.chat('ai.reconcile', '对比两组账单，输出差异及原因 JSON', JSON.stringify(body).slice(0, 3000));
    await this.service.auditLog('ai.reconcile', reply, 'reconcile');
    return { text: reply.text, fallback: reply.fallback };
  }

  @Post('subject-match')
  @RequirePerm('ai:chat')
  async subjectMatch(@Body() body: { summary: string }) {
    const p = await this.service.prompt('subject_match', { data: body.summary || '' });
    const reply = await this.service.chat('ai.subject.match', p.content, body.summary || '');
    await this.service.auditLog('ai.subject.match', reply, body.summary || '');
    try { return JSON.parse(reply.text); } catch { return { text: reply.text, fallback: reply.fallback }; }
  }

  @Post('report/insight')
  @RequirePerm('ai:report')
  async reportInsight(@Body() body: { metrics: any }) {
    const p = await this.service.prompt('report_insight', { data: JSON.stringify(body.metrics || {}) });
    const reply = await this.service.chat('ai.report', p.content, JSON.stringify(body.metrics || {}));
    await this.service.auditLog('ai.report', reply, 'report');
    return { text: reply.text, fallback: reply.fallback };
  }

  /**
   * 标签识别（文档 12.2）：产品图/名称 → 分类、规格、条码建议。
   * @param body.name 产品名称；body.imageBase64 图片（无名称时规则兜底给出提示）
   */
  @Post('label')
  @RequirePerm('ai:chat')
  async label(@Body() body: { name?: string; imageBase64?: string }) {
    const input = String(body.name || '').slice(0, 200) || (body.imageBase64 ? '[图片]' : '');
    const p = await this.service.prompt('label', { data: input });
    const reply = await this.service.chat('ai.label', p.content, input);
    await this.service.auditLog('ai.label', reply, input);
    try { return { ...JSON.parse(reply.text), fallback: reply.fallback, model: reply.model }; }
    catch { return { text: reply.text, fallback: reply.fallback }; }
  }

  /**
   * 智能客服（文档 12.2）：客户提问 → 回复与报价建议。
   * @param body.question 客户提问原文
   */
  @Post('cs')
  @RequirePerm('ai:chat')
  async cs(@Body() body: { question: string; customerId?: number }) {
    const question = String(body.question || '').slice(0, 2000);
    const p = await this.service.prompt('cs', { data: question });
    const reply = await this.service.chat('ai.cs', p.content, question);
    await this.service.auditLog('ai.cs', reply, question);
    try { return { ...JSON.parse(reply.text), fallback: reply.fallback, model: reply.model }; }
    catch { return { text: reply.text, fallback: reply.fallback }; }
  }

  /**
   * 简历解析（文档 12.2）：简历文本 → 候选人结构化字段。
   * @param body.text 简历纯文本
   */
  @Post('resume')
  @RequirePerm('ai:chat')
  async resume(@Body() body: { text: string }) {
    const text = String(body.text || '').slice(0, 20000);
    const p = await this.service.prompt('resume', { data: text });
    const reply = await this.service.chat('ai.resume', p.content, text);
    await this.service.auditLog('ai.resume', reply, text);
    try { return { ...JSON.parse(reply.text), fallback: reply.fallback, model: reply.model }; }
    catch { return { text: reply.text, fallback: reply.fallback }; }
  }

  @Post('rag/query')
  @RequirePerm('ai:chat')
  async ragQuery(@Body() body: { question: string }) {
    const ctx = currentContext();
    // 简易关键词召回：按知识文档标题/内容片段命中（不依赖向量库）
    let context = '';
    try {
      const rows: any[] = await (this.service as any).dataSource.query(
        `SELECT title, content FROM knowledge_doc WHERE tenant_id=? AND is_deleted=0 AND status=1 LIMIT 50`, [ctx.tenantId]);
      context = rows.filter((r) => body.question.split('').some((c) => String(r.content || r.title).includes(c)))
        .slice(0, 3).map((r) => `【${r.title}】${String(r.content || '').slice(0, 400)}`).join('\n');
    } catch { /* 表可能暂无内容 */ }
    const p = await this.service.prompt('rag', { data: `${context}\n问题：${body.question}` });
    const reply = await this.service.chat('ai.rag', p.content, body.question);
    await this.service.auditLog('ai.rag', reply, body.question);
    return { text: reply.text, sources: context ? context.slice(0, 200) : '', fallback: reply.fallback };
  }

  /** 知识库上传：POST /api/v1/ai/rag/upload */
  @Post('rag/upload')
  @RequirePerm('ai:config')
  async ragUpload(@Body() body: { title: string; content: string }) {
    return this.service.uploadDoc(body);
  }

  /** 模型配置：GET/POST /api/v1/ai/config（文档 12.6） */
  @Get('config')
  @RequirePerm('ai:config')
  async config() {
    return this.service.getConfig();
  }

  @Post('config')
  @RequirePerm('ai:config')
  async saveConfig(@Body() body: any) {
    return this.service.saveConfig(body);
  }

  @Get('audits')
  @RequirePerm('system:audit:view')
  async audits(@Query('capability') capability?: string) {
    const ctx = currentContext();
    return (this.service as any).dataSource.query(
      `SELECT id, capability, user_id, model, prompt_tokens, completion_tokens, latency_ms, accepted, fallback, created_at
         FROM ai_audit_log WHERE tenant_id=? ${capability ? 'AND capability=?' : ''} ORDER BY id DESC LIMIT 100`,
      capability ? [ctx.tenantId, capability] : [ctx.tenantId]);
  }

  @Get('prompts')
  @RequirePerm('ai:config')
  async prompts() {
    const ctx = currentContext();
    return (this.service as any).dataSource.query(
      `SELECT * FROM ai_prompt WHERE tenant_id=? ORDER BY code, version DESC`, [ctx.tenantId]);
  }

  @Post('prompts')
  @RequirePerm('ai:config')
  async savePrompt(@Body() dto: any) {
    return this.service.savePromptVersion(dto);
  }

  @Get('prompts/versions') @RequirePerm('ai:config')
  promptVersions(@Query('code') code?: string) { return this.service.listPromptVersions(code); }

  @Post('prompts/activate') @RequirePerm('ai:config')
  activatePrompt(@Body() dto: any) { return this.service.activatePromptVersion(Number(dto.id || 0)); }

  @Get('prompts/diff') @RequirePerm('ai:config')
  promptDiff(@Query('code') code: string, @Query('v1') v1: string, @Query('v2') v2: string) {
    return this.service.promptDiff(String(code || ''), Number(v1 || 1), Number(v2 || 2));
  }

  // ---------------- 模型注册 / 工具 / MCP ----------------

  @Get('models') @RequirePerm('ai:config')
  models() { return this.service.listModels(); }

  @Post('models') @RequirePerm('ai:config')
  saveModel(@Body() dto: any) { return this.service.saveModel(dto); }

  @Post('models/:id/check') @RequirePerm('ai:config')
  checkModel(@Param('id') id: string) { return this.service.checkModel(Number(id)); }

  @Get('functions') @RequirePerm('ai:config')
  functions() { return this.service.listFunctions(); }

  @Post('functions') @RequirePerm('ai:config')
  saveFunction(@Body() dto: any) { return this.service.saveFunction(dto); }

  @Get('mcp/servers') @RequirePerm('ai:config')
  mcpServers() { return this.service.listMcpServers(); }

  @Post('mcp/servers') @RequirePerm('ai:config')
  saveMcpServer(@Body() dto: any) { return this.service.saveMcpServer(dto); }

  @Post('mcp/call') @RequirePerm('ai:chat')
  mcpCall(@Body() dto: any) { return this.service.callMcp(dto); }
}

@Module({ controllers: [AiController], providers: [AiService, AuditService], exports: [AiService] })
export class AiModule {}
