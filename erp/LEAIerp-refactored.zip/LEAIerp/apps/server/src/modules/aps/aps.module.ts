/**
 * 生产计划与排产（APS）
 * ---------------------------------------------------------------------------
 * 功能：生产计划、排产运算（有限/无限产能 + 正排/倒排 + 工作日历）、工序任务、
 *       产能负荷、齐套检查、异常预警与运算记录。
 * 设计：沿用本仓库「单文件 Module + Controller + Service + 原生 SQL」风格，
 *       表结构由 sql/21_aps_planning_ext.sql 管理（synchronize=false 不自动建表）。
 * 排产公式：工序工时 = 准备工时/60 + 数量×单件分钟/60/设备效率；
 *           逐工序在工作日历的可用工时内寻找空档，已占用工时按有限产能策略扣减。
 */
import { Body, Controller, Get, Injectable, Module, Param, Patch, Post, Query } from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';
import { DataSource } from 'typeorm';
import { RequirePerm, currentContext } from '../../common/common';
import { AuditService } from '../../common/audit.service';

/** 通用 CRUD 资源白名单：列名来自常量，避免把请求字段直接拼进 SQL */
const RESOURCES: Record<string, { table: string; cols: string[] }> = {
  plans: { table: 'aps_plan', cols: ['plan_no', 'plan_name', 'source_type', 'source_no', 'product_id', 'product_name', 'qty', 'priority', 'due_date', 'plan_start', 'plan_end', 'work_center', 'status', 'schedule_no', 'remark'] },
  runs: { table: 'aps_run', cols: ['run_no', 'strategy', 'direction', 'plan_count', 'task_count', 'late_count', 'overload_count', 'status'] },
  tasks: { table: 'aps_task', cols: ['task_no', 'plan_id', 'plan_no', 'product_name', 'seq_no', 'process_name', 'work_center', 'qty', 'work_hours', 'plan_start', 'plan_end', 'predecessor', 'priority', 'status', 'late_flag', 'run_id'] },
  resources: { table: 'aps_resource', cols: ['code', 'name', 'workshop', 'shift_hours', 'efficiency', 'daily_capacity', 'manager', 'status'] },
  calendars: { table: 'aps_calendar', cols: ['calendar_date', 'work_center', 'shift_type', 'available_hours', 'is_working', 'reason'] },
  loads: { table: 'aps_load', cols: ['load_date', 'work_center', 'available_hours', 'planned_hours', 'load_rate', 'task_count', 'level', 'bottleneck'] },
  materials: { table: 'aps_material_check', cols: ['check_no', 'plan_no', 'material_name', 'require_qty', 'available_qty', 'short_qty', 'status', 'checked_at'] },
  alerts: { table: 'aps_alert', cols: ['alert_type', 'level', 'title', 'detail', 'biz_no', 'status'] },
};

/** 默认工序模板：与前端 Mock 排产引擎保持同一工时口径 */
const PROCESS_TEMPLATE = [
  { seqNo: 10, processName: '下料', workCenter: '数控加工中心', stdMinutes: 1.2, setupMinutes: 30 },
  { seqNo: 20, processName: '焊接', workCenter: '焊接工作站', stdMinutes: 1.8, setupMinutes: 20 },
  { seqNo: 30, processName: '总装调试', workCenter: '总装线', stdMinutes: 2.4, setupMinutes: 15 },
];
/** 默认 BOM：齐套检查按产品展开物料需求 */
const MATERIALS: Record<string, Array<{ name: string; per: number; fallback: number }>> = {
  智能温控器: [{ name: '温控芯片', per: 1, fallback: 150 }, { name: '铝合金外壳', per: 1, fallback: 86 }],
  无线网关: [{ name: '网关主控板', per: 1, fallback: 200 }, { name: '天线组件', per: 1, fallback: 320 }],
  工控主板: [{ name: 'PCB 空板', per: 1, fallback: 90 }, { name: '芯片组', per: 1, fallback: 60 }],
};

/** camelCase ↔ snake_case 转换，保证前端字段风格与数据库一致 */
const snake = (s: string): string => s.replace(/[A-Z]/g, (c) => `_${c.toLowerCase()}`);
const camel = (s: string): string => s.replace(/_([a-z])/g, (_, c: string) => c.toUpperCase());
function toCamel(row: any): any {
  const out: any = {};
  for (const [k, v] of Object.entries(row || {})) out[camel(k)] = v;
  return out;
}
function apsDate(d: Date): string {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}
function apsClock(hour: number): string {
  const total = Math.max(0, Math.round(hour * 60));
  return `${String(Math.floor(total / 60)).padStart(2, '0')}:${String(total % 60).padStart(2, '0')}`;
}
function apsTime(date: string, hour: number): string { return `${date} ${apsClock(hour)}`; }

@Injectable()
export class ApsService {
  constructor(@InjectDataSource() private readonly dataSource: DataSource, private readonly audit: AuditService) {}

  /** 通用列表查询：支持 status / keyword 与资源白名单，行字段转为 camelCase */
  async list(resource: string, query: any = {}): Promise<any[]> {
    const def = RESOURCES[resource];
    if (!def) throw new Error(`未知的 APS 资源：${resource}`);
    const args: any[] = [currentContext().tenantId];
    let where = 'tenant_id=? AND is_deleted=0';
    if (query.status !== undefined && query.status !== '') { where += ' AND status=?'; args.push(query.status); }
    if (query.workCenter) { where += ' AND work_center=?'; args.push(query.workCenter); }
    if (query.planNo) { where += ' AND plan_no=?'; args.push(query.planNo); }
    if (query.keyword) { where += ' AND (plan_name LIKE ? OR product_name LIKE ? OR code LIKE ?)'; const kw = `%${query.keyword}%`; args.push(kw, kw, kw); }
    const rows = await this.dataSource.query(`SELECT * FROM ${def.table} WHERE ${where} ORDER BY id DESC LIMIT 500`, args);
    return rows.map(toCamel);
  }

  /** 通用新增/更新：只写白名单列，不存在 id 时新增 */
  async save(resource: string, dto: any): Promise<{ id: number }> {
    const def = RESOURCES[resource];
    if (!def) throw new Error(`未知的 APS 资源：${resource}`);
    const ctx = currentContext();
    const payload: any = {};
    for (const col of def.cols) {
      const key = camel(col);
      if (dto[key] !== undefined || dto[col] !== undefined) payload[col] = dto[key] !== undefined ? dto[key] : dto[col];
    }
    const keys = Object.keys(payload);
    if (dto.id) {
      const sets = keys.map((k) => `${k}=?`).concat('updated_by=?');
      await this.dataSource.query(`UPDATE ${def.table} SET ${sets.join(',')} WHERE id=? AND tenant_id=?`,
        [...keys.map((k) => payload[k]), ctx.userId, dto.id, ctx.tenantId]);
      return { id: Number(dto.id) };
    }
    const cols = ['tenant_id', ...keys, 'created_by'];
    const marks = ['?', ...keys.map(() => '?'), '?'];
    const res: any = await this.dataSource.query(
      `INSERT INTO ${def.table} (${cols.join(',')}) VALUES (${marks.join(',')})`,
      [ctx.tenantId, ...keys.map((k) => payload[k]), ctx.userId]);
    return { id: res.insertId };
  }

  /** 工作台汇总指标 */
  async overview(): Promise<any> {
    const ctx = currentContext();
    const one = async (sql: string, args: any[] = [ctx.tenantId]) => Number((await this.dataSource.query(sql, args))[0]?.v || 0);
    return {
      plans: await one('SELECT COUNT(*) v FROM aps_plan WHERE tenant_id=? AND is_deleted=0'),
      confirmed: await one("SELECT COUNT(*) v FROM aps_plan WHERE tenant_id=? AND is_deleted=0 AND status='CONFIRMED'"),
      scheduled: await one("SELECT COUNT(*) v FROM aps_plan WHERE tenant_id=? AND is_deleted=0 AND status IN ('SCHEDULED','ISSUED')"),
      tasks: await one('SELECT COUNT(*) v FROM aps_task WHERE tenant_id=? AND is_deleted=0'),
      pendingTasks: await one("SELECT COUNT(*) v FROM aps_task WHERE tenant_id=? AND is_deleted=0 AND status='SCHEDULED'"),
      lateTasks: await one("SELECT COUNT(*) v FROM aps_task WHERE tenant_id=? AND is_deleted=0 AND late_flag=1 AND status<>'DONE'"),
      overloads: await one("SELECT COUNT(*) v FROM aps_load WHERE tenant_id=? AND is_deleted=0 AND level='OVER'"),
      openAlerts: await one("SELECT COUNT(*) v FROM aps_alert WHERE tenant_id=? AND is_deleted=0 AND status='OPEN'"),
      shortMaterials: await one("SELECT COUNT(*) v FROM aps_material_check WHERE tenant_id=? AND is_deleted=0 AND status='SHORT'"),
    };
  }

  /** 工作日历可用工时：未维护日历时按工作日 8 小时兜底 */
  private available(calendars: any[], center: string, date: string): number {
    const row = calendars.find((c) => c.work_center === center && String(c.calendar_date).slice(0, 10) === date);
    if (row) return Number(row.is_working) ? Number(row.available_hours || 0) : 0;
    return [0, 6].includes(new Date(`${date}T00:00:00`).getDay()) ? 0 : 8;
  }

  /** 逐日分配工序工时，返回起止时间；finite=true 时扣减工作中心已有占用 */
  private allocate(center: string, hours: number, from: string, direction: string, finite: boolean,
    extra: Map<string, number>, calendars: any[], tasks: any[]): { start: string; end: string } | null {
    let remain = Math.max(0.1, Number(hours));
    const base = new Date(`${from}T00:00:00`);
    type Slot = { date: string; startHour: number; endHour: number };
    let startSlot: Slot | null = null;
    let endSlot: Slot | null = null;
    for (let i = 0; i < 90 && remain > 0.001; i++) {
      const date = apsDate(new Date(base.getTime() + (direction === 'BACKWARD' ? -i : i) * 86400000));
      const available = this.available(calendars, center, date);
      if (available <= 0) continue;
      const stored = finite ? tasks.filter((t) => t.work_center === center && String(t.plan_start).slice(0, 10) === date && t.status !== 'DONE')
        .reduce((sum, t) => sum + Number(t.work_hours || 0), 0) : 0;
      const used = stored + (extra.get(`${date}|${center}`) || 0);
      const free = Math.max(0, available - used);
      if (free <= 0.001) continue;
      const take = Math.min(remain, free);
      const slot: Slot = direction === 'BACKWARD'
        ? { date, startHour: 8 + free - take, endHour: 8 + free }
        : { date, startHour: 8 + used, endHour: 8 + used + take };
      if (direction === 'BACKWARD') { if (!endSlot) endSlot = slot; startSlot = slot; }
      else { if (!startSlot) startSlot = slot; endSlot = slot; }
      extra.set(`${date}|${center}`, used + take);
      remain -= take;
    }
    if (!startSlot || !endSlot) return null;
    return { start: apsTime(startSlot.date, startSlot.startHour), end: apsTime(endSlot.date, endSlot.endHour) };
  }

  /** 重算产能负荷派生表：按日期×工作中心汇总未完成工序 */
  async rebuildLoads(): Promise<void> {
    const ctx = currentContext();
    const tasks = await this.dataSource.query(
      `SELECT work_center, DATE_FORMAT(plan_start,'%Y-%m-%d') d, SUM(work_hours) hours, COUNT(*) cnt
         FROM aps_task WHERE tenant_id=? AND is_deleted=0 AND status<>'DONE' GROUP BY work_center, d`, [ctx.tenantId]);
    const calendars = await this.dataSource.query('SELECT * FROM aps_calendar WHERE tenant_id=? AND is_deleted=0', [ctx.tenantId]);
    await this.dataSource.query('DELETE FROM aps_load WHERE tenant_id=?', [ctx.tenantId]);
    for (const t of tasks) {
      const available = this.available(calendars, t.work_center, t.d);
      const hours = Math.round(Number(t.hours || 0) * 10) / 10;
      const rate = available > 0 ? Math.round((hours / available) * 1000) / 10 : 100;
      const level = rate > 100 ? 'OVER' : rate >= 85 ? 'WARN' : rate <= 20 ? 'IDLE' : 'NORMAL';
      await this.dataSource.query(
        `INSERT INTO aps_load (tenant_id, load_date, work_center, available_hours, planned_hours, load_rate, task_count, level, bottleneck, created_by)
         VALUES (?,?,?,?,?,?,?,?,?,?)`,
        [ctx.tenantId, t.d, t.work_center, available, hours, rate, Number(t.cnt || 0), level, rate > 100 ? 1 : 0, ctx.userId]);
    }
  }

  /** 写预警：同类型 + 同关联单号只保留一条 OPEN 记录 */
  private async alert(type: string, level: string, title: string, detail: string, bizNo: string): Promise<void> {
    const ctx = currentContext();
    const exists: any[] = await this.dataSource.query(
      `SELECT id FROM aps_alert WHERE tenant_id=? AND is_deleted=0 AND alert_type=? AND biz_no=? AND status='OPEN' LIMIT 1`,
      [ctx.tenantId, type, bizNo]);
    if (exists.length) return;
    await this.dataSource.query(
      `INSERT INTO aps_alert (tenant_id, alert_type, level, title, detail, biz_no, status, created_by) VALUES (?,?,?,?,?,?, 'OPEN', ?)`,
      [ctx.tenantId, type, level, title, detail, bizNo, ctx.userId]);
  }

  /** 执行排产运算：展开工序 → 日历分配 → 落任务 → 重算负荷 → 生成预警 */
  async runSchedule(dto: any = {}): Promise<any> {
    const ctx = currentContext();
    const strategy = dto.strategy === 'INFINITE' ? 'INFINITE' : 'FINITE';
    const direction = dto.direction === 'BACKWARD' ? 'BACKWARD' : 'FORWARD';
    let plans: any[] = await this.dataSource.query(
      `SELECT * FROM aps_plan WHERE tenant_id=? AND is_deleted=0 AND status='CONFIRMED' ORDER BY priority, due_date`, [ctx.tenantId]);
    if (Array.isArray(dto.planIds) && dto.planIds.length) plans = plans.filter((p) => dto.planIds.map(Number).includes(Number(p.id)));
    if (!plans.length) throw new Error('没有可排产的「已确认」计划，请先确认计划');
    const resources: any[] = await this.dataSource.query('SELECT * FROM aps_resource WHERE tenant_id=? AND is_deleted=0', [ctx.tenantId]);
    const calendars: any[] = await this.dataSource.query('SELECT * FROM aps_calendar WHERE tenant_id=? AND is_deleted=0', [ctx.tenantId]);
    const tasks: any[] = await this.dataSource.query('SELECT * FROM aps_task WHERE tenant_id=? AND is_deleted=0', [ctx.tenantId]);
    const runNo = `APS${Date.now().toString().slice(-10)}`;
    const run: any = await this.dataSource.query(
      `INSERT INTO aps_run (tenant_id, run_no, strategy, direction, plan_count, status, created_by) VALUES (?,?,?,?,?, 'RUNNING', ?)`,
      [ctx.tenantId, runNo, strategy, direction, plans.length, ctx.userId]);
    const runId = run.insertId;
    const extra = new Map<string, number>();
    let taskCount = 0;
    let lateCount = 0;
    try {
      for (const plan of plans) {
        const res = resources.find((r) => r.name === plan.work_center);
        const efficiency = Math.max(50, Number(res?.efficiency || 90)) / 100;
        let previous = direction === 'BACKWARD' ? String(plan.due_date || plan.plan_start) : String(plan.plan_start || apsDate(new Date()));
        let prevNo = '';
        let firstStart = '';
        for (const proc of PROCESS_TEMPLATE) {
          const hours = Math.round((proc.setupMinutes / 60 + Number(plan.qty || 0) * proc.stdMinutes / 60 / efficiency) * 10) / 10;
          const slot = this.allocate(proc.workCenter, hours, previous, direction, strategy === 'FINITE', extra, calendars, tasks);
          if (!slot) throw new Error(`工作中心 ${proc.workCenter} 在计划期内没有可用工作日`);
          const endDay = String(slot.end).slice(0, 10);
          const late = endDay > String(plan.due_date || '9999-12-31') ? 1 : 0;
          if (late) lateCount++;
          const taskNo = `APT${String(++taskCount).padStart(4, '0')}`;
          const inserted: any = await this.dataSource.query(
            `INSERT INTO aps_task (tenant_id, task_no, plan_id, plan_no, product_name, seq_no, process_name, work_center, qty, work_hours, plan_start, plan_end, predecessor, priority, status, late_flag, run_id, created_by)
             VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?, 'SCHEDULED', ?, ?, ?)`,
            [ctx.tenantId, taskNo, plan.id, plan.plan_no, plan.product_name, proc.seqNo, proc.processName, proc.workCenter,
              plan.qty, hours, slot.start, slot.end, prevNo, plan.priority || 'P3', late, runId, ctx.userId]);
          tasks.push({ work_center: proc.workCenter, plan_start: slot.start, work_hours: hours, status: 'SCHEDULED', id: inserted.insertId });
          if (!firstStart) firstStart = slot.start;
          prevNo = taskNo;
          previous = endDay;
          if (late) await this.alert('DUE', 'HIGH', `${plan.plan_no} 交期风险`,
            `排产完工 ${endDay} 晚于需求日期 ${plan.due_date}，建议加急或调整优先级`, plan.plan_no);
        }
        await this.dataSource.query(
          `UPDATE aps_plan SET status='SCHEDULED', plan_start=?, plan_end=?, schedule_no=?, updated_by=? WHERE id=? AND tenant_id=?`,
          [String(firstStart).slice(0, 10), previous, runNo, ctx.userId, plan.id, ctx.tenantId]);
      }
      await this.rebuildLoads();
      const loads: any[] = await this.dataSource.query("SELECT * FROM aps_load WHERE tenant_id=? AND is_deleted=0 AND level='OVER'", [ctx.tenantId]);
      for (const l of loads) await this.alert('CAPACITY', 'HIGH', `${l.work_center} ${String(l.load_date).slice(0, 10)} 产能超载 ${Math.round(Number(l.load_rate) - 100)}%`,
        `可用 ${l.available_hours} 小时，已排 ${l.planned_hours} 小时，建议分流或调整班次`, String(l.load_date).slice(0, 10));
      await this.dataSource.query(`UPDATE aps_run SET status='DONE', task_count=?, late_count=?, overload_count=? WHERE id=?`, [taskCount, lateCount, loads.length, runId]);
      await this.audit.write('RUN', 'APS_SCHEDULE', runId, runNo, `排产完成：${plans.length} 张计划 / ${taskCount} 道工序 / ${lateCount} 项交期风险`);
      return { runId, runNo, planCount: plans.length, taskCount, lateCount, overloadCount: loads.length, status: 'DONE' };
    } catch (e) {
      await this.dataSource.query(`UPDATE aps_run SET status='FAILED' WHERE id=?`, [runId]);
      throw e;
    }
  }

  /** 齐套检查：按默认 BOM 核对库存，缺料自动写预警 */
  async materialCheck(planId?: number): Promise<any> {
    const ctx = currentContext();
    let plans: any[] = await this.dataSource.query(
      `SELECT * FROM aps_plan WHERE tenant_id=? AND is_deleted=0 AND status<>'CANCELLED'`, [ctx.tenantId]);
    if (planId) plans = plans.filter((p) => Number(p.id) === Number(planId));
    if (!plans.length) throw new Error('没有可检查的生产计划');
    const checkNo = `QK${Date.now().toString().slice(-10)}`;
    let shortCount = 0;
    for (const plan of plans) {
      const items = MATERIALS[String(plan.product_name)] || [{ name: plan.product_name, per: 1, fallback: 0 }];
      for (const it of items) {
        const bal: any[] = await this.dataSource.query(
          `SELECT COALESCE(SUM(b.qty_on_hand),0) hand, COALESCE(SUM(b.qty_occupied),0) occupied
             FROM stock_balance b JOIN product p ON p.id=b.product_id
            WHERE b.tenant_id=? AND p.name=?`, [ctx.tenantId, it.name]);
        const available = bal.length ? Number(bal[0].hand || 0) - Number(bal[0].occupied || 0) : it.fallback;
        const require = Number(plan.qty || 0) * Number(it.per || 1);
        const short = Math.max(0, require - available);
        if (short > 0) shortCount++;
        await this.dataSource.query(
          `INSERT INTO aps_material_check (tenant_id, check_no, plan_no, material_name, require_qty, available_qty, short_qty, status, checked_at, created_by)
           VALUES (?,?,?,?,?,?,?,?,NOW(3),?)`,
          [ctx.tenantId, checkNo, plan.plan_no, it.name, require, available, short, short > 0 ? 'SHORT' : 'OK', ctx.userId]);
        if (short > 0) await this.alert('MATERIAL', short > require * 0.3 ? 'HIGH' : 'MED',
          `${plan.plan_no} 缺少${it.name} ${short} 件`, `需求 ${require} 件，可用 ${available} 件，建议加急采购或调整开工日期`, plan.plan_no);
      }
    }
    await this.audit.write('RUN', 'APS_MATERIAL_CHECK', 0, checkNo, `齐套检查完成，缺料 ${shortCount} 项`);
    return { checkNo, planCount: plans.length, shortCount };
  }

  /** 生产计划状态动作；下达时同步生成生产工单 */
  async planAction(id: number, action: string): Promise<any> {
    const ctx = currentContext();
    const rows: any[] = await this.dataSource.query('SELECT * FROM aps_plan WHERE id=? AND tenant_id=? AND is_deleted=0', [id, ctx.tenantId]);
    if (!rows.length) throw new Error('生产计划不存在');
    const plan = rows[0];
    const statusMap: Record<string, string> = { confirm: 'CONFIRMED', cancel: 'CANCELLED', issue: 'ISSUED', complete: 'COMPLETED' };
    const status = statusMap[action];
    if (!status) throw new Error(`未知计划动作：${action}`);
    if (action === 'confirm' && plan.status !== 'DRAFT') throw new Error('只有草稿计划可以确认');
    if (action === 'issue' && plan.status !== 'SCHEDULED') throw new Error('计划需先完成排产才能下达工单');
    await this.dataSource.query(`UPDATE aps_plan SET status=?, updated_by=? WHERE id=? AND tenant_id=?`, [status, ctx.userId, id, ctx.tenantId]);
    if (action === 'issue') {
      const exists: any[] = await this.dataSource.query('SELECT id FROM work_order WHERE tenant_id=? AND order_no=? AND is_deleted=0', [ctx.tenantId, plan.plan_no]);
      if (!exists.length) await this.dataSource.query(
        `INSERT INTO work_order (tenant_id, order_no, product_id, qty, plan_qty, plan_start, plan_end, status, created_by) VALUES (?,?,?,?,?,?,?,0,?)`,
        [ctx.tenantId, plan.plan_no, plan.product_id || 1, plan.qty, plan.qty, plan.plan_start, plan.plan_end, ctx.userId]);
    }
    await this.audit.write('ACTION', 'APS_PLAN', id, plan.plan_no, `生产计划执行「${action}」，状态变更为 ${status}`);
    return { ok: true, status };
  }

  /** 工序完工：推进同计划下一道工序，全部完工后回写计划状态 */
  async completeTask(id: number): Promise<any> {
    const ctx = currentContext();
    const rows: any[] = await this.dataSource.query('SELECT * FROM aps_task WHERE id=? AND tenant_id=? AND is_deleted=0', [id, ctx.tenantId]);
    if (!rows.length) throw new Error('工序任务不存在');
    const task = rows[0];
    await this.dataSource.query(`UPDATE aps_task SET status='DONE', updated_by=? WHERE id=?`, [ctx.userId, id]);
    const rest: any[] = await this.dataSource.query(
      `SELECT * FROM aps_task WHERE tenant_id=? AND plan_id=? AND is_deleted=0 AND status<>'DONE' ORDER BY seq_no LIMIT 1`, [ctx.tenantId, task.plan_id]);
    if (rest.length) await this.dataSource.query(`UPDATE aps_task SET status='RUNNING' WHERE id=?`, [rest[0].id]);
    else await this.dataSource.query(`UPDATE aps_plan SET status='COMPLETED', updated_by=? WHERE id=?`, [ctx.userId, task.plan_id]);
    await this.rebuildLoads();
    await this.audit.write('ACTION', 'APS_TASK', id, task.task_no, '工序任务完工，后续工序已推进');
    return { ok: true };
  }

  /** 手动调整工序后重算负荷并重新判定交期风险 */
  async patchTask(id: number, dto: any): Promise<any> {
    await this.save('tasks', { ...dto, id });
    const ctx = currentContext();
    const rows: any[] = await this.dataSource.query(
      `SELECT t.*, p.due_date FROM aps_task t LEFT JOIN aps_plan p ON p.id=t.plan_id WHERE t.id=? AND t.tenant_id=?`, [id, ctx.tenantId]);
    if (rows.length) {
      const late = String(rows[0].plan_end).slice(0, 10) > String(rows[0].due_date || '9999-12-31') ? 1 : 0;
      await this.dataSource.query('UPDATE aps_task SET late_flag=? WHERE id=?', [late, id]);
    }
    await this.rebuildLoads();
    return { ok: true };
  }

  /** 批量生成工作日历：周末自动停产，已有日期不重复写入 */
  async batchCalendar(dto: any): Promise<any> {
    const ctx = currentContext();
    const centers: string[] = dto.workCenters?.length ? dto.workCenters
      : (await this.dataSource.query('SELECT name FROM aps_resource WHERE tenant_id=? AND is_deleted=0', [ctx.tenantId])).map((r: any) => r.name);
    const start = new Date(`${dto.startDate || apsDate(new Date())}T00:00:00`);
    const days = Math.min(90, Number(dto.days || 14));
    const hours = Number(dto.defaultHours || 8);
    let created = 0;
    for (let i = 0; i < days; i++) {
      const date = apsDate(new Date(start.getTime() + i * 86400000));
      const weekend = [0, 6].includes(new Date(`${date}T00:00:00`).getDay());
      for (const center of centers) {
        const exists: any[] = await this.dataSource.query(
          'SELECT id FROM aps_calendar WHERE tenant_id=? AND calendar_date=? AND work_center=?', [ctx.tenantId, date, center]);
        if (exists.length) continue;
        await this.dataSource.query(
          `INSERT INTO aps_calendar (tenant_id, calendar_date, work_center, shift_type, available_hours, is_working, reason, created_by)
           VALUES (?,?,?,?,?,?,?,?)`,
          [ctx.tenantId, date, center, weekend ? '停产' : '白班', weekend ? 0 : hours, weekend ? 0 : 1, weekend ? '周末休息' : '正常班次', ctx.userId]);
        created++;
      }
    }
    return { created };
  }

  /** 处理预警 */
  async resolveAlert(id: number): Promise<any> {
    await this.dataSource.query(`UPDATE aps_alert SET status='RESOLVED', updated_by=? WHERE id=?`, [currentContext().userId, id]);
    return { ok: true };
  }
}

@Controller('api/v1/aps')
class ApsController {
  constructor(private readonly service: ApsService) {}

  @Get('overview') @RequirePerm('aps:schedule:view') overview() { return this.service.overview(); }
  @Post('schedule/run') @RequirePerm('aps:schedule:run') run(@Body() dto: any) { return this.service.runSchedule(dto || {}); }
  @Post('material-check') @RequirePerm('aps:material:view') materialCheck(@Body() dto: any) { return this.service.materialCheck(dto?.planId ? Number(dto.planId) : undefined); }
  @Post('loads/rebuild') @RequirePerm('aps:schedule:run') rebuild() { return this.service.rebuildLoads(); }
  @Post('calendars/batch') @RequirePerm('aps:resource:edit') batchCalendar(@Body() dto: any) { return this.service.batchCalendar(dto || {}); }
  @Post('plans/:id/:action') @RequirePerm('aps:plan:edit') planAction(@Param('id') id: string, @Param('action') action: string) { return this.service.planAction(Number(id), action); }
  @Post('tasks/:id/complete') @RequirePerm('aps:schedule:edit') completeTask(@Param('id') id: string) { return this.service.completeTask(Number(id)); }
  @Post('tasks/:id') @RequirePerm('aps:schedule:edit') patchTask(@Param('id') id: string, @Body() dto: any) { return this.service.patchTask(Number(id), dto || {}); }
  @Patch('tasks/:id') @RequirePerm('aps:schedule:edit') patchTaskStd(@Param('id') id: string, @Body() dto: any) { return this.service.patchTask(Number(id), dto || {}); }
  @Post('alerts/:id/resolve') @RequirePerm('aps:schedule:edit') resolve(@Param('id') id: string) { return this.service.resolveAlert(Number(id)); }
  @Get('plans') @RequirePerm('aps:plan:view', 'aps:schedule:view', 'aps:material:view', 'aps:plan:edit') listPlans(@Query() q: any) { return this.service.list('plans', q); }
  @Get('resources') @RequirePerm('aps:resource:view', 'aps:plan:view', 'aps:schedule:view') listResources(@Query() q: any) { return this.service.list('resources', q); }
  @Get('material-check') @RequirePerm('aps:material:view') listMaterials(@Query() q: any) { return this.service.list('materials', q); }
  @Get('schedule/runs') @RequirePerm('aps:schedule:view') listRuns(@Query() q: any) { return this.service.list('runs', q); }
  @Get(':resource') @RequirePerm('aps:schedule:view') list(@Param('resource') resource: string, @Query() query: any) { return this.service.list(resource, query); }
  @Post(':resource') @RequirePerm('aps:plan:edit') save(@Param('resource') resource: string, @Body() dto: any) { return this.service.save(resource, dto || {}); }
  @Patch(':resource/:id') @RequirePerm('aps:plan:edit') update(@Param('resource') resource: string, @Param('id') id: string, @Body() dto: any) { return this.service.save(resource, { ...dto, id: Number(id) }); }
}

@Module({ controllers: [ApsController], providers: [ApsService, AuditService], exports: [ApsService] })
export class ApsModule {}
