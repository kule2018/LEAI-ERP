/**
 * 鉴权与平台底座（文档 13 章）：登录/JWT、用户、角色、权限、字典、系统参数、通知、审计日志
 */
import { Body, Controller, Delete, Get, Injectable, Module, Param, ParseIntPipe, Post, Query } from '@nestjs/common';
import { JwtModule, JwtService } from '@nestjs/jwt';
import { InjectDataSource } from '@nestjs/typeorm';
import { DataSource } from 'typeorm';
import * as bcrypt from 'bcryptjs';
import { BizException, BizCode, DataScope, Public, RequirePerm, currentContext, normalizePage, pageResult } from '../../common/common';
import { AuditService } from '../../common/audit.service';
import { SequenceService } from '../../common/sequence.service';

import { JWT_SECRET } from '../../load-env';
const JWT_EXPIRES = process.env.JWT_EXPIRES || '2h';

@Injectable()
export class AuthService {
  constructor(
    @InjectDataSource() private readonly dataSource: DataSource,
    private readonly jwt: JwtService,
    private readonly audit: AuditService,
  ) {}

  /** 登录：校验密码 → 查角色权限 → 签发 JWT；登录日志只追加 */
  async login(dto: { username: string; password: string }) {
    const rows: any[] = await this.dataSource.query(
      `SELECT * FROM sys_user WHERE username=? AND is_deleted=0`, [dto.username]);
    const user = rows[0];
    if (!user) throw new BizException(BizCode.UNAUTHORIZED, '用户名或密码错误');
    const ok = await bcrypt.compare(dto.password, user.password);
    await this.dataSource.query(`INSERT INTO sys_login_log (tenant_id, user_id, username, ip, success, fail_reason)
      VALUES (?,?,?,?,?,?)`, [user.tenant_id, user.id, user.username, null, ok ? 1 : 0, ok ? null : '密码错误']);
    if (!ok) throw new BizException(BizCode.UNAUTHORIZED, '用户名或密码错误');
    if (Number(user.status) !== 1) throw new BizException(BizCode.UNAUTHORIZED, '账号已停用');
    await this.dataSource.query(`UPDATE sys_user SET last_login_at=NOW() WHERE id=?`, [user.id]);

    const perms: any[] = await this.dataSource.query(
      `SELECT DISTINCT p.code FROM sys_user_role ur
        JOIN sys_role_permission rp ON rp.role_id = ur.role_id
        JOIN sys_permission p ON p.id = rp.permission_id AND p.is_deleted=0
       WHERE ur.user_id=? AND ur.tenant_id=?`, [user.id, user.tenant_id]);
    const roles: any[] = await this.dataSource.query(
      `SELECT r.code, r.data_scope FROM sys_user_role ur JOIN sys_role r ON r.id=ur.role_id
        WHERE ur.user_id=? AND ur.tenant_id=?`, [user.id, user.tenant_id]);
    // 多角色取最宽松的数据范围：ALL > ORG > DEPT > SELF
    const rank: Record<string, number> = { SELF: 1, DEPT: 2, ORG: 3, ALL: 4 };
    const dataScope = roles.reduce((best, r) => (rank[r.data_scope] || 1) > (rank[best] || 1) ? r.data_scope : best, 'SELF');
    const token = await this.jwt.signAsync(
      {
        sub: user.id, tenantId: user.tenant_id, username: user.username,
        perms: perms.map((p) => p.code),
        deptId: user.dept_id || 0, orgId: user.org_id || 0,
        dataScope, roles: roles.map((r) => r.code),
      },
      { secret: JWT_SECRET, expiresIn: JWT_EXPIRES });
    await this.audit.write('LOGIN', 'USER', user.id, user.username, '登录成功');
    return { token, userInfo: { id: user.id, username: user.username, realName: user.real_name, tenantId: user.tenant_id,
      roles: roles.map((r) => r.code), permissions: perms.map((p) => p.code) } };
  }

  /**
   * 退出登录：JWT 为无状态令牌，服务端不做黑名单，仅记录登出审计；
   * 前端收到成功后自行丢弃本地 Token。
   */
  async logout() {
    const ctx = currentContext();
    await this.audit.write('LOGOUT', 'USER', ctx.userId, ctx.username, '退出登录');
    return { ok: true };
  }

  /** 刷新 Token：原 Token 未过期时才可刷新（前端在快过期时调用） */
  async refresh(raw: string) {
    const payload = await this.jwt.verifyAsync(raw, { secret: JWT_SECRET }).catch(() => null);
    if (!payload) throw new BizException(BizCode.UNAUTHORIZED, 'Token 无效或已过期，请重新登录');
    const token = await this.jwt.signAsync(
      {
        sub: payload.sub, tenantId: payload.tenantId, username: payload.username,
        perms: payload.perms || [], deptId: payload.deptId || 0, orgId: payload.orgId || 0,
        dataScope: payload.dataScope || 'ALL', roles: payload.roles || [],
      },
      { secret: JWT_SECRET, expiresIn: JWT_EXPIRES });
    return { token };
  }
}

@Injectable()
export class SystemService {
  constructor(
    @InjectDataSource() private readonly dataSource: DataSource,
    private readonly audit: AuditService,
    private readonly seq: SequenceService,
  ) {}

  listUsers(query: any) {
    const { page, pageSize, skip } = normalizePage(query.page, query.pageSize);
    const args: any[] = [currentContext().tenantId];
    let where = 'u.tenant_id = ? AND u.is_deleted = 0';
    if (query.keyword) { where += ' AND (u.username LIKE ? OR u.real_name LIKE ?)'; args.push(`%${query.keyword}%`, `%${query.keyword}%`); }
    return this.dataSource.query(
      `SELECT u.id, u.username, u.real_name, u.phone, u.dept_id, u.status, u.last_login_at, d.name AS dept_name
         FROM sys_user u LEFT JOIN sys_dept d ON d.id=u.dept_id
        WHERE ${where} ORDER BY u.id DESC LIMIT ? OFFSET ?`, [...args, pageSize, skip]).then(async (list) => {
      const totalRows: any[] = await this.dataSource.query(`SELECT COUNT(*) c FROM sys_user u WHERE ${where}`, args);
      return pageResult(list, Number(totalRows[0]?.c || 0), page, pageSize);
    });
  }

  async saveUser(dto: any, id?: number) {
    const ctx = currentContext();
    if (id) {
      const beforeRows: any[] = await this.dataSource.query(
        `SELECT real_name, phone, dept_id, status FROM sys_user WHERE id=? AND tenant_id=?`, [id, ctx.tenantId]);
      const before = beforeRows[0] || null;
      await this.dataSource.query(`UPDATE sys_user SET real_name=?, phone=?, dept_id=?, status=? WHERE id=? AND tenant_id=?`,
        [dto.realName, dto.phone || null, dto.deptId || null, dto.status ?? 1, id, ctx.tenantId]);
      const after = { real_name: dto.realName, phone: dto.phone || null, dept_id: dto.deptId || null, status: dto.status ?? 1 };
      await this.audit.writeDiff('UPDATE', 'USER', id, dto.username || '', before, after, ['phone']);
      return { id };
    }
    const password = await bcrypt.hash(dto.password || 'admin123', 10);
    const res: any = await this.dataSource.query(
      `INSERT INTO sys_user (tenant_id, username, password, real_name, phone, dept_id) VALUES (?,?,?,?,?,?)`,
      [ctx.tenantId, dto.username, password, dto.realName || dto.username, dto.phone || null, dto.deptId || null]);
    if (dto.roleIds?.length) {
      for (const roleId of dto.roleIds) {
        await this.dataSource.query(`INSERT IGNORE INTO sys_user_role (tenant_id, user_id, role_id) VALUES (?,?,?)`, [ctx.tenantId, res.insertId, roleId]);
      }
    }
    const after = { username: dto.username, real_name: dto.realName || dto.username, phone: dto.phone || null, dept_id: dto.deptId || null };
    await this.audit.writeDiff('CREATE', 'USER', res.insertId, dto.username, null, after, ['phone']);
    return { id: res.insertId };
  }

  listRoles() {
    return this.dataSource.query(`SELECT * FROM sys_role WHERE tenant_id=? AND is_deleted=0 ORDER BY id`, [currentContext().tenantId]);
  }

  listPermissions() {
    return this.dataSource.query(`SELECT * FROM sys_permission WHERE is_deleted=0 ORDER BY sort, id`);
  }

  /**
   * 权限树：从 sys_permission 读取菜单/按钮权限，按 parent_id 组装成树，供权限配置页渲染。
   * @returns 根节点数组，每个节点含 id/code/name/type/parentId/sort/children
   */
  async permissionTree() {
    const rows: any[] = await this.dataSource.query(
      `SELECT id, code, name, type, parent_id, sort FROM sys_permission WHERE is_deleted=0 ORDER BY sort, id`);
    const nodes = rows.map((r) => ({
      id: Number(r.id), code: r.code, name: r.name, type: Number(r.type),
      parentId: Number(r.parent_id || 0), sort: Number(r.sort || 0), children: [] as any[],
    }));
    const map = new Map<number, any>(nodes.map((n) => [n.id, n]));
    const roots: any[] = [];
    for (const n of nodes) {
      const parent = map.get(n.parentId);
      if (parent && parent !== n) parent.children.push(n);
      else roots.push(n);
    }
    return roots;
  }

  async saveRole(dto: any, id?: number) {
    const ctx = currentContext();
    if (id) {
      await this.dataSource.query(`UPDATE sys_role SET name=?, data_scope=? WHERE id=? AND tenant_id=?`, [dto.name, dto.dataScope || 'SELF', id, ctx.tenantId]);
    } else {
      const res: any = await this.dataSource.query(`INSERT INTO sys_role (tenant_id, code, name, data_scope) VALUES (?,?,?,?)`,
        [ctx.tenantId, dto.code, dto.name, dto.dataScope || 'SELF']);
      id = res.insertId;
    }
    if (Array.isArray(dto.permissionIds)) {
      await this.dataSource.query(`DELETE FROM sys_role_permission WHERE tenant_id=? AND role_id=?`, [ctx.tenantId, id]);
      for (const pid of dto.permissionIds) {
        await this.dataSource.query(`INSERT IGNORE INTO sys_role_permission (tenant_id, role_id, permission_id) VALUES (?,?,?)`, [ctx.tenantId, id, pid]);
      }
    }
    await this.audit.write(id ? 'UPDATE' : 'CREATE', 'ROLE', id, dto.code || '', `角色授权：${JSON.stringify(dto.permissionIds || [])}`);
    return { id };
  }

  getDict(code: string) {
    return this.dataSource.query(`SELECT label, value, sort FROM sys_dict_item WHERE tenant_id=? AND dict_code=? AND is_deleted=0 ORDER BY sort`,
      [currentContext().tenantId, code]);
  }

  listDicts() {
    return this.dataSource.query(`SELECT * FROM sys_dict WHERE tenant_id=? AND is_deleted=0`, [currentContext().tenantId]);
  }

  getConfigs() {
    return this.dataSource.query(`SELECT * FROM sys_config WHERE tenant_id=?`, [currentContext().tenantId]);
  }

  async saveConfig(key: string, value: string) {
    const ctx = currentContext();
    await this.dataSource.query(
      `INSERT INTO sys_config (tenant_id, cfg_key, cfg_value) VALUES (?,?,?)
       ON DUPLICATE KEY UPDATE cfg_value = VALUES(cfg_value)`, [ctx.tenantId, key, value]);
    await this.audit.write('UPDATE', 'CONFIG', 0, key, `修改系统参数：${key}`);
    return { key, value };
  }

  listOrgs() {
    return this.dataSource.query(`SELECT * FROM sys_dept WHERE tenant_id=? AND is_deleted=0 ORDER BY parent_id, id`, [currentContext().tenantId]);
  }

  listNotify() {
    return this.dataSource.query(`SELECT * FROM sys_notify WHERE tenant_id=? AND user_id=? ORDER BY id DESC LIMIT 50`,
      [currentContext().tenantId, currentContext().userId]);
  }

  async readNotify(id: number) {
    await this.dataSource.query(`UPDATE sys_notify SET is_read=1 WHERE id=? AND tenant_id=? AND user_id=?`,
      [id, currentContext().tenantId, currentContext().userId]);
    return { id };
  }

  listAuditLogs(query: any) {
    const { page, pageSize, skip } = normalizePage(query.page, query.pageSize);
    const args: any[] = [currentContext().tenantId];
    let where = 'tenant_id = ?';
    if (query.module) { where += ' AND module = ?'; args.push(query.module); }
    if (query.bizType) { where += ' AND biz_type = ?'; args.push(query.bizType); }
    return this.dataSource.query(`SELECT * FROM sys_audit_log WHERE ${where} ORDER BY id DESC LIMIT ? OFFSET ?`, [...args, pageSize, skip])
      .then(async (list) => {
        const totalRows: any[] = await this.dataSource.query(`SELECT COUNT(*) c FROM sys_audit_log WHERE ${where}`, args);
        return pageResult(list, Number(totalRows[0]?.c || 0), page, pageSize);
      });
  }

  listLoginLogs() {
    return this.dataSource.query(`SELECT * FROM sys_login_log WHERE tenant_id=? ORDER BY id DESC LIMIT 100`, [currentContext().tenantId]);
  }

  // ---------------- 编码规则 CRUD（委托 SequenceService 执行） ----------------
  listSequences() {
    return this.seq.listRules();
  }
  saveSequence(dto: any) {
    return this.seq.saveRule(dto);
  }
  deleteSequence(id: number) {
    return this.seq.deleteRule(id);
  }
  releaseSequence(dto: any) {
    return this.seq.release(dto.bizType, dto.no, Number(dto.orgId || 0));
  }
}

@Controller('api/v1/auth')
class AuthController {
  constructor(private readonly service: AuthService) {}
  @Post('login') @Public()
  login(@Body() dto: any) { return this.service.login(dto); }
  @Post('refresh') @Public()
  refresh(@Body() body: { token: string }) { return this.service.refresh(body.token); }
  @Post('logout')
  logout() { return this.service.logout(); }
}

@Controller('api/v1/system')
class SystemController {
  constructor(private readonly service: SystemService) {}

  @Get('users') @RequirePerm('system:user:view') listUsers(@Query() q: any) { return this.service.listUsers(q); }
  @Post('users') @RequirePerm('system:user:edit') saveUser(@Body() dto: any) { return this.service.saveUser(dto); }
  @Get('roles') @RequirePerm('system:role:view') listRoles() { return this.service.listRoles(); }
  @Post('roles') @RequirePerm('system:role:edit') saveRole(@Body() dto: any) { return this.service.saveRole(dto); }
  @Get('permissions/tree') @RequirePerm('system:role:view') permissionTree() { return this.service.permissionTree(); }
  @Get('permissions') @RequirePerm('system:role:view') listPermissions() { return this.service.listPermissions(); }
  @Get('orgs') @RequirePerm('system:user:view') listOrgs() { return this.service.listOrgs(); }
  @Get('dicts') listDicts() { return this.service.listDicts(); }
  @Get('dicts/:code') getDict(@Param('code') code: string) { return this.service.getDict(code); }
  @Get('configs') @RequirePerm('system:config:view') getConfigs() { return this.service.getConfigs(); }
  @Post('configs') @RequirePerm('system:config:edit') saveConfig(@Body() dto: any) { return this.service.saveConfig(dto.key, dto.value); }
  @Get('notifies') listNotify() { return this.service.listNotify(); }
  @Post('notifies/:id/read') readNotify(@Param('id', ParseIntPipe) id: number) { return this.service.readNotify(id); }
  @Get('audit-logs') @RequirePerm('system:audit:view') listAuditLogs(@Query() q: any) { return this.service.listAuditLogs(q); }
  @Get('login-logs') @RequirePerm('system:audit:view') listLoginLogs() { return this.service.listLoginLogs(); }

  @Get('sequences') @RequirePerm('system:sequence:view') listSequences() { return this.service.listSequences(); }
  @Post('sequences') @RequirePerm('system:sequence:edit') saveSequence(@Body() dto: any) { return this.service.saveSequence(dto); }
  @Delete('sequences/:id') @RequirePerm('system:sequence:edit') deleteSequence(@Param('id', ParseIntPipe) id: number) { return this.service.deleteSequence(id); }
  @Post('sequences/release') @RequirePerm('system:sequence:edit') releaseSequence(@Body() dto: any) { return this.service.releaseSequence(dto); }
}

@Module({
  imports: [JwtModule.register({ secret: JWT_SECRET, signOptions: { expiresIn: JWT_EXPIRES } })],
  controllers: [AuthController, SystemController],
  providers: [AuthService, SystemService, AuditService, SequenceService],
  exports: [AuthService, SystemService],
})
export class AuthSystemModule {}
