import { Body, Controller, Get, Post } from '@nestjs/common';
import { Public } from '../../common/public.decorator';
import { AuthService, LoginDto } from './auth.service';

/**
 * 认证控制器：登录与健康检查。
 */
@Controller('api/v1/auth')
export class AuthController {
  constructor(private readonly authService: AuthService) {}

  // 登录接口：POST /api/v1/auth/login
  @Public()
  @Post('login')
  login(@Body() dto: LoginDto) {
    return this.authService.login(dto);
  }

  // 健康检查：GET /api/v1/auth/ping
  @Public()
  @Get('ping')
  ping() {
    return { pong: true, time: new Date().toISOString() };
  }
}
