import { Module } from '@nestjs/common';
import { JwtModule } from '@nestjs/jwt';
import { AuthService } from './auth.service';
import { AuthController } from './auth.controller';

/**
 * 认证模块：注册 JWT 能力并导出 AuthService 供守卫复用。
 */
@Module({
  imports: [
    JwtModule.register({
      secret: 'erp-demo-secret', // 骨架写死，生产应放系统配置且不明文落库
      signOptions: { expiresIn: '2h' },
    }),
  ],
  controllers: [AuthController],
  providers: [AuthService],
  exports: [AuthService, JwtModule],
})
export class AuthModule {}
