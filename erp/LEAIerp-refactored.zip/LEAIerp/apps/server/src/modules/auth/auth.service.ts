import { Injectable, UnauthorizedException } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import * as bcrypt from 'bcryptjs';
import { InMemoryRepository } from '../../common/in-memory.repository';
import { JwtPayload } from '../../common/types';

// 用户实体（对应 sys_user，骨架只保留登录所需字段）
export interface SysUser {
  id?: number;
  tenantId?: number;
  username: string;
  passwordHash: string;
  realName: string;
  perms: string[];
}

export interface LoginDto {
  username: string;
  password: string;
}

/**
 * 认证服务。
 * 职责：校验账号密码 → 签发 JWT（载荷带 tenant_id 与权限码）。
 * 种子账号：admin / admin123（密码 bcrypt 存储，绝不落明文）。
 */
@Injectable()
export class AuthService {
  // 租户 1 的种子用户仓储
  private readonly userRepo = new InMemoryRepository<SysUser>('sys_user');

  constructor(private readonly jwtService: JwtService) {
    this.initSeedUser();
  }

  // 初始化种子用户：幂等，服务启动时写入一次
  private initSeedUser(): void {
    const exists = this.userRepo.findMany(1, (u) => u.username === 'admin');
    if (exists.length > 0) {
      return;
    }
    this.userRepo.create(
      {
        username: 'admin',
        passwordHash: bcrypt.hashSync('admin123', 10),
        realName: '系统管理员',
        perms: [
          'product:list',
          'product:create',
          'stock:view',
          'sales:order:list',
          'sales:order:create',
        ],
      },
      1,
    );
  }

  // 登录：校验密码并返回 token + 基本信息
  async login(dto: LoginDto): Promise<{ token: string; username: string; realName: string; perms: string[] }> {
    const list = this.userRepo.findMany(1, (u) => u.username === dto.username);
    const user = list[0];
    if (!user) {
      throw new UnauthorizedException('账号或密码错误');
    }

    const matched = bcrypt.compareSync(dto.password, user.passwordHash);
    if (!matched) {
      throw new UnauthorizedException('账号或密码错误');
    }

    const payload: JwtPayload = {
      sub: user.id,
      tenantId: user.tenantId,
      username: user.username,
      perms: user.perms,
    };

    const token = this.jwtService.sign(payload);
    return { token, username: user.username, realName: user.realName, perms: user.perms };
  }
}
