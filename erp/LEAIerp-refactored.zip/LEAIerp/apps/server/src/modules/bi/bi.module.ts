/**
 * 报表与 BI 看板（文档第 15 章）
 * 能力：自定义报表定义（维度 + 指标）→ 受控取数（表白名单 + 租户过滤）→ 图表数据；报表订阅。
 * 安全：source_table 必须在白名单内，字段必须出现在 dimensions/metrics 定义中，防止任意 SQL 注入。
 */
import { Body, Controller, Get, Injectable, Module, Param, ParseIntPipe, Post, Query } from '@nestjs/common';
import { Cron } from '@nestjs/schedule';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { InjectDataSource } from '@nestjs/typeorm';
import { DataSource } from 'typeorm';
import { BizCode, BizException, RequirePerm, currentContext, als, systemContext } from '../../common/common';
import { AuditService } from '../../common/audit.service';
import { AiService } from '../ai/ai.module';
import { AiModule } from '../ai/ai.module';

/** 允许取数的表白名单：只暴露报表常用事实表 */
const TABLE_WHITELIST = ['sale_order', 'purchase_order', 'stock_balance', 'receivable', 'payable'];
/** 允许的时间维度字段 */
const DATE_FIELDS = ['order_date', 'created_at', 'due_date'];

/** 极简 cron 字段匹配：支持星号、步长、逗号列表与区间写法，不引入新的 cron 依赖 */
function cronFieldMatch(field: string, value: number, weekday = false): boolean {
  if (field === '*') return true;
  for (const part of field.split(',')) {
    if (part.startsWith('*/')) {
      const step = Number(part.slice(2));
      if (step > 0 && value % step === 0) return true;
      continue;
    }
    if (part.includes('-')) {
      const [a, b] = part.split('-').map(Number);
      if (value >= a && value <= b) return true;
      // 周日既可写 0 也可写 7
      if (weekday && value === 0 && b === 7 && a <= 7) return true;
      continue;
    }
    if (Number(part) === value) return true;
    if (weekday && value === 0 && Number(part) === 7) return true;
  }
  return false;
}

/** 判断五段 cron 在当前分钟是否命中 */
function cronMatches(expr: string, d: Date): boolean {
  const fields = String(expr || '').trim().split(/\s+/);
  if (fields.length < 5) return false;
  return cronFieldMatch(fields[0], d.getMinutes())
    && cronFieldMatch(fields[1], d.getHours())
    && cronFieldMatch(fields[2], d.getDate())
    && cronFieldMatch(fields[3], d.getMonth() + 1)
    && cronFieldMatch(fields[4], d.getDay(), true);
}

@Injectable()
export class BiService {
  constructor(
    @InjectDataSource() private readonly dataSource: DataSource,
    private readonly audit: AuditService,
    private readonly ai: AiService,
    private readonly events: EventEmitter2,
  ) {}

  listDefinitions() {
    return this.dataSource.query(`SELECT * FROM rpt_definition WHERE tenant_id=? AND is_deleted=0 ORDER BY id DESC`, [currentContext().tenantId]);
  }

  async saveDefinition(dto: any) {
    const ctx = currentContext();
    if (!TABLE_WHITELIST.includes(dto.sourceTable || dto.source_table)) {
      throw new BizException(BizCode.PARAM_INVALID, `取数表仅支持：${TABLE_WHITELIST.join(' / ')}`);
    }
    const dims = typeof dto.dimensions === 'string' ? JSON.parse(dto.dimensions) : (dto.dimensions || []);
    const metrics = typeof dto.metrics === 'string' ? JSON.parse(dto.metrics) : (dto.metrics || []);
    if (!metrics.length) throw new BizException(BizCode.PARAM_INVALID, '至少选择一个指标');
    if (dto.id) {
      await this.dataSource.query(
        `UPDATE rpt_definition SET name=?, source_table=?, dimensions_json=?, metrics_json=?, chart_type=? WHERE id=? AND tenant_id=?`,
        [dto.name, dto.sourceTable || dto.source_table, JSON.stringify(dims), JSON.stringify(metrics), dto.chartType || dto.chart_type || 'bar', dto.id, ctx.tenantId]);
      return { id: dto.id };
    }
    const res: any = await this.dataSource.query(
      `INSERT INTO rpt_definition (tenant_id, code, name, source_table, dimensions_json, metrics_json, chart_type, created_by)
       VALUES (?,?,?,?,?,?,?,?)`,
      [ctx.tenantId, dto.code || `RPT_${Date.now()}`, dto.name, dto.sourceTable || dto.source_table,
        JSON.stringify(dims), JSON.stringify(metrics), dto.chartType || dto.chart_type || 'bar', ctx.userId]);
    await this.audit.write('CREATE', 'RPT_DEFINITION', res.insertId, dto.name, '新建自定义报表');
    return { id: res.insertId };
  }

  /**
   * 执行报表：按定义拼 SELECT 维度, 聚合指标 FROM 白名单表 WHERE tenant_id=? GROUP BY 维度。
   * @param query 支持 __date 按天/月聚合（仅对时间维度生效）
   */
  async run(reportId: number, query: any) {
    const ctx = currentContext();
    const rows: any[] = await this.dataSource.query(`SELECT * FROM rpt_definition WHERE id=? AND tenant_id=?`, [reportId, ctx.tenantId]);
    const def = rows[0];
    if (!def) throw new BizException(BizCode.NOT_FOUND, '报表定义不存在');
    const dims = typeof def.dimensions_json === 'string' ? JSON.parse(def.dimensions_json) : def.dimensions_json;
    const metrics = typeof def.metrics_json === 'string' ? JSON.parse(def.metrics_json) : def.metrics_json;

    const selectParts: string[] = [];
    const groupParts: string[] = [];
    for (const d of dims || []) {
      if (DATE_FIELDS.includes(d.field) && query.dateGrain === 'month') {
        selectParts.push(`DATE_FORMAT(${d.field},'%Y-%m') AS \`${d.label || d.field}\``);
        groupParts.push(`DATE_FORMAT(${d.field},'%Y-%m')`);
      } else if (DATE_FIELDS.includes(d.field) && query.dateGrain === 'day') {
        selectParts.push(`DATE(${d.field}) AS \`${d.label || d.field}\``);
        groupParts.push(`DATE(${d.field})`);
      } else {
        selectParts.push(`${d.field} AS \`${d.label || d.field}\``);
        groupParts.push(d.field);
      }
    }
    const aggMap: Record<string, string> = { SUM: 'SUM', COUNT: 'COUNT', AVG: 'AVG' };
    for (const m of metrics || []) {
      const agg = aggMap[String(m.agg || 'SUM').toUpperCase()] || 'SUM';
      selectParts.push(`${agg}(${m.field}) AS \`${m.label || m.field}\``);
    }
    if (!groupParts.length) groupParts.push('1');

    const args: any[] = [ctx.tenantId];
    let where = 'tenant_id = ? AND is_deleted = 0';
    if (query.startDate) { where += ` AND ${this.dateField(dims)} >= ?`; args.push(query.startDate); }
    if (query.endDate) { where += ` AND ${this.dateField(dims)} <= ?`; args.push(query.endDate); }
    const sql = `SELECT ${selectParts.join(', ')} FROM ${def.source_table} WHERE ${where} GROUP BY ${groupParts.join(', ')} ORDER BY ${groupParts[0]} LIMIT 500`;
    const data = await this.dataSource.query(sql, args);
    return {
      definition: { id: def.id, name: def.name, chartType: def.chart_type },
      columns: [...(dims || []).map((d: any) => d.label || d.field), ...(metrics || []).map((m: any) => m.label || m.field)],
      rows: data,
    };
  }

  /** 找出定义里的日期维度，用于时间范围过滤；没有则返回 created_at */
  private dateField(dims: any[]): string {
    const hit = (dims || []).find((d) => DATE_FIELDS.includes(d.field));
    return hit ? hit.field : 'created_at';
  }

  /** 经营驾驶舱：KPI + 近 6 个月销售趋势，供首页与「经营简报」打印 */
  async dashboard() {
    const ctx = currentContext();
    const t = ctx.tenantId;
    const one = async (sql: string) => {
      const rows: any[] = await this.dataSource.query(sql, [t]);
      return Number(rows[0]?.v || 0);
    };
    const todaySale = await one(`SELECT COALESCE(SUM(total_amount),0) v FROM sale_order WHERE tenant_id=? AND is_deleted=0 AND DATE(order_date)=CURDATE()`);
    const monthSale = await one(`SELECT COALESCE(SUM(total_amount),0) v FROM sale_order WHERE tenant_id=? AND is_deleted=0 AND order_date>=DATE_FORMAT(CURDATE(),'%Y-%m-01')`);
    const unpaid = await one(`SELECT COALESCE(SUM(amount-received_amount),0) v FROM receivable WHERE tenant_id=? AND is_deleted=0`);
    const unpurchased = await one(`SELECT COALESCE(SUM(amount-paid_amount),0) v FROM payable WHERE tenant_id=? AND is_deleted=0`);
    const lowStock = await one(`SELECT COUNT(*) v FROM stock_balance WHERE tenant_id=? AND qty_on_hand<=0`);
    const trend: any[] = await this.dataSource.query(
      `SELECT DATE_FORMAT(order_date,'%Y-%m') m, SUM(total_amount) v FROM sale_order
        WHERE tenant_id=? AND is_deleted=0 AND order_date>=DATE_SUB(CURDATE(), INTERVAL 6 MONTH) GROUP BY m ORDER BY m`, [t]);
    const topProducts: any[] = await this.dataSource.query(
      `SELECT p.name, SUM(l.amount) v FROM sale_order_line l JOIN sale_order o ON o.id=l.order_id
        JOIN product p ON p.id=l.product_id
        WHERE o.tenant_id=? AND o.is_deleted=0 AND o.order_date>=DATE_SUB(CURDATE(), INTERVAL 30 DAY)
        GROUP BY p.name ORDER BY v DESC LIMIT 10`, [t]);
    return { todaySale, monthSale, unpaid, unpurchased, lowStock, trend, topProducts };
  }

  listSubscriptions() {
    return this.dataSource.query(`SELECT * FROM rpt_subscription WHERE tenant_id=? AND is_deleted=0 ORDER BY id DESC`, [currentContext().tenantId]);
  }

  async saveSubscription(dto: any) {
    const ctx = currentContext();
    if (dto.id) {
      await this.dataSource.query(`UPDATE rpt_subscription SET report_id=?, cron=?, channel=?, receiver=?, status=? WHERE id=? AND tenant_id=?`,
        [dto.reportId, dto.cron, dto.channel || 'INBOX', dto.receiver || null, dto.status ?? 1, dto.id, ctx.tenantId]);
      return { id: dto.id };
    }
    const res: any = await this.dataSource.query(
      `INSERT INTO rpt_subscription (tenant_id, report_id, cron, channel, receiver) VALUES (?,?,?,?,?)`,
      [ctx.tenantId, dto.reportId, dto.cron || '0 8 * * 1', dto.channel || 'INBOX', dto.receiver || null]);
    return { id: res.insertId };
  }

  /**
   * 每分钟扫描订阅：命中 cron 且本分钟未跑过时，生成报表记录 + AI 摘要 + 推送日志。
   * 定时任务没有 HTTP 上下文，用 als.run(systemContext) 注入租户，复用现有 run() 逻辑。
   */
  @Cron('* * * * *')
  async runSubscriptions() {
    const now = new Date();
    const subs: any[] = await this.dataSource.query(
      `SELECT * FROM rpt_subscription WHERE status=1 AND is_deleted=0 AND report_id IS NOT NULL`);
    for (const sub of subs) {
      try {
        if (!cronMatches(sub.cron, now)) continue;
        // 同一分钟不重复执行
        if (sub.last_run_at && new Date(sub.last_run_at).getMinutes() === now.getMinutes()
          && new Date(sub.last_run_at).getHours() === now.getHours()) continue;

        const tenantId = Number(sub.tenant_id);
        const result: any = await als.run(systemContext(tenantId), () => this.run(Number(sub.report_id), {}));
        const rows = Array.isArray(result?.rows) ? result.rows : [];
        const sample = JSON.stringify(rows.slice(0, 20)).slice(0, 2000);
        let aiSummary = `报表「${result?.definition?.name || sub.report_id}」执行完成，共 ${rows.length} 行数据。`;
        try {
          const reply = await this.ai.chat('bi.report.summary',
            '你是企业 ERP 报表助手，请用一句简洁中文总结数据要点。',
            `报表名称：${result?.definition?.name || ''}\n数据：${sample}`);
          aiSummary = reply.text || aiSummary;
          await this.ai.auditLog('bi.report.summary', reply, sample, 1);
        } catch {
          // AI 不可用时保留规则摘要，不影响订阅落库
        }

        const runRes: any = await this.dataSource.query(
          `INSERT INTO rpt_run_log (tenant_id, subscription_id, report_id, period, row_count, ai_summary, summary_json, status)
           VALUES (?,?,?,?,?,?,?, 'SUCCESS')`,
          [tenantId, sub.id, sub.report_id, `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')} ${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`,
            rows.length, String(aiSummary).slice(0, 2000), sample],
        );
        await this.dataSource.query(
          `INSERT INTO rpt_push_log (tenant_id, subscription_id, run_id, channel, receiver, status)
           VALUES (?,?,?,?,?, 'SUCCESS')`,
          [tenantId, sub.id, runRes.insertId, sub.channel || 'INBOX', sub.receiver || null],
        );
        await this.dataSource.query(`UPDATE rpt_subscription SET last_run_at=NOW(3) WHERE id=?`, [sub.id]);
        this.events.emit('realtime.dashboard', {
          tenantId, title: '报表订阅已生成',
          data: { subscriptionId: sub.id, reportId: sub.report_id, runId: runRes.insertId, aiSummary },
        });
      } catch (err: any) {
        // 单个订阅失败不影响其他订阅
        await this.dataSource.query(
          `INSERT INTO rpt_push_log (tenant_id, subscription_id, channel, receiver, status, error)
           VALUES (?,?,?,?, 'FAILED', ?)`,
          [sub.tenant_id, sub.id, sub.channel || 'INBOX', sub.receiver || null, String(err?.message || err).slice(0, 500)],
        ).catch(() => undefined);
      }
    }
  }
}

@Controller('api/v1/bi')
class BiController {
  constructor(private readonly service: BiService) {}

  @Get('reports') @RequirePerm('bi:report:view') list() { return this.service.listDefinitions(); }
  @Post('reports') @RequirePerm('bi:report:edit') save(@Body() dto: any) { return this.service.saveDefinition(dto); }
  @Post('reports/:id/run') @RequirePerm('bi:report:view') run(@Param('id', ParseIntPipe) id: number, @Body() body: any) { return this.service.run(id, body || {}); }
  @Get('dashboard') @RequirePerm('bi:report:view') dashboard() { return this.service.dashboard(); }
  @Get('subscriptions') @RequirePerm('bi:subscription:edit') subs() { return this.service.listSubscriptions(); }
  @Post('subscriptions') @RequirePerm('bi:subscription:edit') saveSub(@Body() dto: any) { return this.service.saveSubscription(dto); }
}

@Module({ imports: [AiModule], controllers: [BiController], providers: [BiService, AuditService], exports: [BiService] })
export class BiModule {}
