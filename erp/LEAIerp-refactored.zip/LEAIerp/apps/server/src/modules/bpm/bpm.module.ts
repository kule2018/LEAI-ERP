/**
 * BPM 审批流引擎（文档第 14 章）
 * 能力：流程定义 → 实例发起 → 待办/已办 → 通过/驳回/转办/撤回/委托 → 流转日志
 * 路由规则：节点可配置金额区间 amountMin/amountMax 与角色 roleCode，发起时按金额挑选审批节点。
 * 说明：不引入 Camunda/Flowable，基于 flow_* 表 + 状态机自研轻量实现，满足单据审批闭环。
 */
import { Body, Controller, Get, Injectable, Module, Param, ParseIntPipe, Post, Query } from '@nestjs/common';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { InjectDataSource } from '@nestjs/typeorm';
import { DataSource } from 'typeorm';
import { BizCode, BizException, RequirePerm, currentContext, normalizePage, pageResult } from '../../common/common';
import { AuditService } from '../../common/audit.service';

/** 流程节点定义结构 */
interface FlowNode {
  key: string;
  type: 'START' | 'APPROVAL' | 'CC' | 'END';
  name: string;
  assigneeType?: 'ROLE' | 'USER';
  roleCode?: string;
  assigneeId?: number;
  amountMin?: number;
  amountMax?: number;
}

@Injectable()
export class BpmService {
  constructor(
    @InjectDataSource() private readonly dataSource: DataSource,
    private readonly audit: AuditService,
    private readonly events: EventEmitter2,
  ) {}

  // ---------------- 流程定义 ----------------

  listDefinitions() {
    return this.dataSource.query(
      `SELECT * FROM flow_definition WHERE tenant_id=? AND is_deleted=0 ORDER BY id DESC`, [currentContext().tenantId]);
  }

  async saveDefinition(dto: any) {
    const ctx = currentContext();
    if (!dto.code || !dto.name) throw new BizException(BizCode.PARAM_INVALID, '流程编码与名称必填');
    const nodes = typeof dto.nodes === 'string' ? JSON.parse(dto.nodes) : (dto.nodes || []);
    if (!nodes.some((n: FlowNode) => n.type === 'APPROVAL')) throw new BizException(BizCode.PARAM_INVALID, '流程至少需要一个审批节点');
    if (dto.id) {
      await this.dataSource.query(
        `UPDATE flow_definition SET name=?, biz_type=?, nodes_json=?, status=? WHERE id=? AND tenant_id=?`,
        [dto.name, dto.biz_type || dto.bizType || null, JSON.stringify(nodes), dto.status ?? 1, dto.id, ctx.tenantId]);
      await this.audit.write('UPDATE', 'FLOW_DEFINITION', dto.id, dto.code, '更新流程定义');
      return { id: dto.id };
    }
    const res: any = await this.dataSource.query(
      `INSERT INTO flow_definition (tenant_id, code, name, biz_type, nodes_json, status, created_by) VALUES (?,?,?,?,?,?,?)`,
      [ctx.tenantId, dto.code, dto.name, dto.biz_type || dto.bizType || null, JSON.stringify(nodes), dto.status ?? 1, ctx.userId]);
    await this.audit.write('CREATE', 'FLOW_DEFINITION', res.insertId, dto.code, '新建流程定义');
    return { id: res.insertId };
  }

  // ---------------- 实例与任务 ----------------

  /**
   * 发起审批：找到绑定 bizType 的启用流程，按金额匹配审批节点，生成首条待办。
   * 没有匹配定义时返回 null，由调用方决定是否「免审批直接通过」。
   */
  async start(dto: { bizType: string; bizId: number; bizNo?: string; title?: string; amount?: number }) {
    const ctx = currentContext();
    const defs: any[] = await this.dataSource.query(
      `SELECT * FROM flow_definition WHERE tenant_id=? AND biz_type=? AND status=1 AND is_deleted=0 ORDER BY version DESC LIMIT 1`,
      [ctx.tenantId, dto.bizType]);
    const def = defs[0];
    if (!def) return null;
    const nodes: FlowNode[] = typeof def.nodes_json === 'string' ? JSON.parse(def.nodes_json) : def.nodes_json;
    const firstApproval = this.pickNode(nodes, Number(dto.amount || 0));
    if (!firstApproval) return null;

    const ins: any = await this.dataSource.query(
      `INSERT INTO flow_instance (tenant_id, definition_id, biz_type, biz_id, biz_no, title, amount, status, current_node, created_by)
       VALUES (?,?,?,?,?,?,?,1,?,?)`,
      [ctx.tenantId, def.id, dto.bizType, dto.bizId, dto.bizNo || null, dto.title || `${dto.bizType} 审批`, Number(dto.amount || 0),
        firstApproval.key, ctx.userId]);
    const instanceId = ins.insertId;
    await this.createTask(instanceId, firstApproval);
    await this.writeLog(instanceId, 'START', `${ctx.username} 发起审批，金额 ${dto.amount || 0}`);
    await this.audit.write('START', 'FLOW_INSTANCE', instanceId, dto.bizNo, '发起审批');
    this.events.emit('realtime.approval', {
      tenantId: ctx.tenantId, title: '新的审批待办',
      data: { instanceId, bizType: dto.bizType, bizId: dto.bizId, bizNo: dto.bizNo, node: firstApproval.key, status: 'PENDING' },
    });
    return { instanceId, node: firstApproval.key };
  }

  /** 按金额区间挑选首个审批节点；无区间限制的节点作为兜底 */
  private pickNode(nodes: FlowNode[], amount: number): FlowNode | null {
    for (const n of nodes) {
      if (n.type !== 'APPROVAL') continue;
      const minOk = n.amountMin === undefined || amount >= Number(n.amountMin);
      const maxOk = n.amountMax === undefined || amount < Number(n.amountMax);
      if (minOk && maxOk) return n;
    }
    return nodes.find((n) => n.type === 'APPROVAL') || null;
  }

  private async createTask(instanceId: number, node: FlowNode) {
    const ctx = currentContext();
    let assigneeId: number | null = null;
    if (node.assigneeType === 'USER') {
      assigneeId = Number(node.assigneeId || 0) || null;
    } else if (node.roleCode) {
      const rows: any[] = await this.dataSource.query(
        `SELECT u.id FROM sys_user u JOIN sys_role r ON r.id IN (
           SELECT role_id FROM sys_user_role WHERE user_id=u.id)
         WHERE u.tenant_id=? AND r.tenant_id=? AND r.code=? AND u.is_deleted=0 LIMIT 1`,
        [ctx.tenantId, ctx.tenantId, node.roleCode]);
      assigneeId = rows[0]?.id || 1;
    }
    await this.dataSource.query(
      `INSERT INTO flow_task (tenant_id, instance_id, node_key, node_name, assignee_id, assignee_role, status) VALUES (?,?,?,?,?,?,1)`,
      [ctx.tenantId, instanceId, node.key, node.name, assigneeId || 1, node.roleCode || null]);
  }

  /** 待办：本人 + 委托人的任务 */
  async todoTasks(query: any) {
    const ctx = currentContext();
    const { page, pageSize, skip } = normalizePage(query.page, query.pageSize);
    const delegated: any[] = await this.dataSource.query(
      `SELECT from_user_id FROM flow_delegation WHERE tenant_id=? AND to_user_id=? AND status=1
         AND (start_date IS NULL OR start_date<=CURDATE()) AND (end_date IS NULL OR end_date>=CURDATE())`,
      [ctx.tenantId, ctx.userId]);
    const userIds = [ctx.userId, ...delegated.map((d) => d.from_user_id)];
    const placeholders = userIds.map(() => '?').join(',');
    const where = `t.tenant_id=? AND t.status=1 AND t.assignee_id IN (${placeholders})`;
    const args = [ctx.tenantId, ...userIds];
    const list = await this.dataSource.query(
      `SELECT t.*, i.biz_type, i.biz_id, i.biz_no, i.title, i.amount, i.created_by AS apply_by, i.created_at AS apply_at
         FROM flow_task t JOIN flow_instance i ON i.id=t.instance_id
        WHERE ${where} ORDER BY t.id DESC LIMIT ? OFFSET ?`, [...args, pageSize, skip]);
    const total: any[] = await this.dataSource.query(`SELECT COUNT(*) c FROM flow_task t WHERE ${where}`, args);
    return pageResult(list, Number(total[0]?.c || 0), page, pageSize);
  }

  doneTasks(query: any) {
    const ctx = currentContext();
    const { page, pageSize, skip } = normalizePage(query.page, query.pageSize);
    const where = `tenant_id=? AND handled_by=? AND status<>1`;
    const args = [ctx.tenantId, ctx.userId];
    return this.dataSource.query(`SELECT * FROM flow_task WHERE ${where} ORDER BY handled_at DESC LIMIT ? OFFSET ?`, [...args, pageSize, skip])
      .then(async (list) => {
        const total: any[] = await this.dataSource.query(`SELECT COUNT(*) c FROM flow_task WHERE ${where}`, args);
        return pageResult(list, Number(total[0]?.c || 0), page, pageSize);
      });
  }

  instanceDetail(instanceId: number) {
    return this.dataSource.query(
      `SELECT i.*, t.id AS task_id, t.node_key, t.node_name, t.status AS task_status, t.assignee_id, t.comment, t.handled_at
         FROM flow_instance i LEFT JOIN flow_task t ON t.instance_id=i.id
        WHERE i.id=? AND i.tenant_id=? ORDER BY t.id`, [instanceId, currentContext().tenantId]);
  }

  logs(instanceId: number) {
    return this.dataSource.query(`SELECT * FROM flow_task_log WHERE instance_id=? AND tenant_id=? ORDER BY id`,
      [instanceId, currentContext().tenantId]);
  }

  /**
   * 处理任务：通过 / 驳回 / 转办
   * 通过：当前任务完成，取下一审批节点生成新任务；没有下一节点则实例通过。
   * 驳回：任务标记驳回，实例置为驳回。
   */
  async handle(taskId: number, dto: { type: 'APPROVE' | 'REJECT' | 'TRANSFER'; comment?: string; assigneeId?: number }) {
    const ctx = currentContext();
    const rows: any[] = await this.dataSource.query(`SELECT * FROM flow_task WHERE id=? AND tenant_id=?`, [taskId, ctx.tenantId]);
    const task = rows[0];
    if (!task) throw new BizException(BizCode.NOT_FOUND, '审批任务不存在');
    if (task.status !== 1) throw new BizException(BizCode.PARAM_INVALID, '该任务已处理');

    if (dto.type === 'TRANSFER') {
      await this.dataSource.query(`UPDATE flow_task SET assignee_id=? WHERE id=?`, [dto.assigneeId || ctx.userId, taskId]);
      await this.writeLog(task.instance_id, 'TRANSFER', `转办给 ${dto.assigneeId}，原因：${dto.comment || ''}`);
      return { status: '转办成功' };
    }

    if (dto.type === 'REJECT') {
      await this.dataSource.query(`UPDATE flow_task SET status=3, handle_type='REJECT', comment=?, handled_by=?, handled_at=NOW(3) WHERE id=?`,
        [dto.comment || '驳回', ctx.userId, taskId]);
      await this.dataSource.query(`UPDATE flow_instance SET status=3, current_node=NULL WHERE id=?`, [task.instance_id]);
      await this.writeLog(task.instance_id, 'REJECT', `${ctx.username} 驳回：${dto.comment || ''}`);
      await this.audit.write('REJECT', 'FLOW_TASK', taskId, String(task.instance_id), dto.comment);
      this.events.emit('realtime.approval', {
        tenantId: ctx.tenantId, userIds: [Number(task.created_by || 0)].filter(Boolean), title: '审批被驳回',
        data: { instanceId: task.instance_id, taskId, status: 'REJECTED', comment: dto.comment },
      });
      return { status: 'REJECTED', instanceId: task.instance_id };
    }

    // 通过
    await this.dataSource.query(`UPDATE flow_task SET status=2, handle_type='APPROVE', comment=?, handled_by=?, handled_at=NOW(3) WHERE id=?`,
      [dto.comment || '同意', ctx.userId, taskId]);
    await this.writeLog(task.instance_id, 'APPROVE', `${ctx.username} 通过：${dto.comment || ''}`);

    const defRows: any[] = await this.dataSource.query(`SELECT * FROM flow_definition WHERE id=(SELECT definition_id FROM flow_instance WHERE id=?)`, [task.instance_id]);
    const nodes: FlowNode[] = defRows[0] ? (typeof defRows[0].nodes_json === 'string' ? JSON.parse(defRows[0].nodes_json) : defRows[0].nodes_json) : [];
    const idx = nodes.findIndex((n) => n.key === task.node_key);
    const next = nodes.slice(idx + 1).find((n) => n.type === 'APPROVAL');
    if (next) {
      await this.createTask(task.instance_id, next);
      await this.dataSource.query(`UPDATE flow_instance SET current_node=? WHERE id=?`, [next.key, task.instance_id]);
      await this.writeLog(task.instance_id, 'NEXT', `流转到 ${next.name}`);
      this.events.emit('realtime.approval', {
        tenantId: ctx.tenantId, title: '审批流转到下一节点',
        data: { instanceId: task.instance_id, status: 'PENDING', node: next.key },
      });
      return { status: 'PENDING', instanceId: task.instance_id, node: next.key };
    }
    await this.dataSource.query(`UPDATE flow_instance SET status=2, current_node=NULL WHERE id=?`, [task.instance_id]);
    await this.writeLog(task.instance_id, 'PASS', '审批流程结束，已通过');
    await this.audit.write('APPROVE', 'FLOW_TASK', taskId, String(task.instance_id), '审批通过');
    this.events.emit('realtime.approval', {
      tenantId: ctx.tenantId, userIds: [Number(task.created_by || 0)].filter(Boolean), title: '审批已通过',
      data: { instanceId: task.instance_id, status: 'APPROVED' },
    });
    return { status: 'APPROVED', instanceId: task.instance_id };
  }

  /** 撤回：仅发起人可撤回审批中的实例 */
  async cancel(instanceId: number) {
    await this.dataSource.query(`UPDATE flow_task SET status=4, handle_type='CANCEL', handled_by=? WHERE instance_id=? AND status=1`,
      [currentContext().userId, instanceId]);
    await this.dataSource.query(`UPDATE flow_instance SET status=4 WHERE id=?`, [instanceId]);
    await this.writeLog(instanceId, 'CANCEL', '发起人撤回');
    return { status: 'CANCELLED' };
  }

  saveDelegation(dto: any) {
    const ctx = currentContext();
    return this.dataSource.query(
      `INSERT INTO flow_delegation (tenant_id, from_user_id, to_user_id, start_date, end_date) VALUES (?,?,?,?,?)`,
      [ctx.tenantId, ctx.userId, dto.toUserId, dto.startDate || null, dto.endDate || null]);
  }

  private writeLog(instanceId: number, action: string, detail: string) {
    const ctx = currentContext();
    return this.dataSource.query(
      `INSERT INTO flow_task_log (tenant_id, instance_id, action, operator_id, operator_name, comment) VALUES (?,?,?,?,?,?)`,
      [ctx.tenantId, instanceId, action, ctx.userId, ctx.username, detail.slice(0, 490)]);
  }
}

@Controller('api/v1/bpm')
class BpmController {
  constructor(private readonly service: BpmService) {}

  @Get('definitions') @RequirePerm('bpm:flow:view') listDefinitions() { return this.service.listDefinitions(); }
  @Post('definitions') @RequirePerm('bpm:flow:view') saveDefinition(@Body() dto: any) { return this.service.saveDefinition(dto); }
  @Post('start') @RequirePerm('bpm:task:view') start(@Body() dto: any) { return this.service.start(dto); }
  @Get('tasks/todo') @RequirePerm('bpm:task:view') todo(@Query() q: any) { return this.service.todoTasks(q); }
  @Get('tasks/done') @RequirePerm('bpm:task:view') done(@Query() q: any) { return this.service.doneTasks(q); }
  @Post('tasks/:id/handle') @RequirePerm('bpm:task:handle') handle(@Param('id', ParseIntPipe) id: number, @Body() dto: any) { return this.service.handle(id, dto); }
  @Post('instances/:id/cancel') @RequirePerm('bpm:task:handle') cancel(@Param('id', ParseIntPipe) id: number) { return this.service.cancel(id); }
  @Get('instances/:id') @RequirePerm('bpm:task:view') detail(@Param('id', ParseIntPipe) id: number) { return this.service.instanceDetail(id); }
  @Get('instances/:id/logs') @RequirePerm('bpm:task:view') logs(@Param('id', ParseIntPipe) id: number) { return this.service.logs(id); }
  @Post('delegations') @RequirePerm('bpm:delegate:edit') delegate(@Body() dto: any) { return this.service.saveDelegation(dto); }
}

@Module({ controllers: [BpmController], providers: [BpmService, AuditService], exports: [BpmService] })
export class BpmModule {}
