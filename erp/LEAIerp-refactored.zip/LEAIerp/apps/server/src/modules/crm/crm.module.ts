/**
 * 客户关系 CRM 深化（文档 17.1）：线索 / 商机 / 跟进 / 报价单
 * AI 用法：线索评分交给 AiService（无密钥时规则兜底），商机预测复用预测能力。
 * 约定：线索转化后生成客户与商机；不物理删除，作废走 is_deleted。
 */
import { Body, Controller, Get, Injectable, Module, Param, ParseIntPipe, Post, Query } from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';
import { DataSource } from 'typeorm';
import { BizCode, BizException, RequirePerm, currentContext, normalizePage, pageResult } from '../../common/common';
import { AuditService } from '../../common/audit.service';

@Injectable()
export class CrmService {
  constructor(@InjectDataSource() private readonly dataSource: DataSource, private readonly audit: AuditService) {}

  // ---------------- 客户 ----------------

  /**
   * 客户列表：按租户分页查询客户档案，支持名称/编码/电话关键字。
   * @param q 查询参数：page/pageSize 分页，keyword 模糊关键字
   * @returns 分页对象 { list, total, page, pageSize }
   */
  listCustomers(q: any) {
    const ctx = currentContext();
    const { page, pageSize, skip } = normalizePage(q.page, q.pageSize);
    const args: any[] = [ctx.tenantId];
    let where = 'tenant_id=? AND is_deleted=0';
    if (q.keyword) {
      const k = `%${q.keyword}%`;
      where += ' AND (name LIKE ? OR code LIKE ? OR phone LIKE ?)';
      args.push(k, k, k);
    }
    return this.dataSource.query(
      `SELECT * FROM customer WHERE ${where} ORDER BY id DESC LIMIT ? OFFSET ?`, [...args, pageSize, skip])
      .then(async (list: any[]) => {
        const total: any[] = await this.dataSource.query(`SELECT COUNT(*) c FROM customer WHERE ${where}`, args);
        return pageResult(list, Number(total[0]?.c || 0), page, pageSize);
      });
  }

  /**
   * 新增/修改客户：id 存在则更新，否则新增；所有语句带 tenant_id 过滤。
   * @param dto 客户表单数据（兼容 camelCase 与下划线字段）
   * @returns { id } 客户主键
   */
  async saveCustomer(dto: any) {
    const ctx = currentContext();
    const priceLevel = Number(dto.priceLevel || dto.price_level || 1);
    const creditLimit = Number(dto.creditLimit || dto.credit_limit || 0);
    const groupId = dto.groupId || dto.group_id || null;
    const ownerId = dto.ownerId || dto.owner_id || null;
    if (dto.id) {
      await this.dataSource.query(
        `UPDATE customer SET name=?, code=?, phone=?, address=?, price_level=?, credit_limit=?, group_id=?, owner_id=?, updated_by=?
          WHERE id=? AND tenant_id=?`,
        [dto.name, dto.code || null, dto.phone || null, dto.address || null, priceLevel, creditLimit,
          groupId, ownerId, ctx.userId, dto.id, ctx.tenantId]);
      return { id: dto.id };
    }
    const res: any = await this.dataSource.query(
      `INSERT INTO customer (tenant_id, name, code, phone, address, price_level, credit_limit, group_id, owner_id, created_by)
       VALUES (?,?,?,?,?,?,?,?,?,?)`,
      [ctx.tenantId, dto.name, dto.code || null, dto.phone || null, dto.address || null, priceLevel,
        creditLimit, groupId, ownerId, ctx.userId]);
    return { id: res.insertId };
  }

  // ---------------- 线索 ----------------

  async listLeads(q: any) {
    const ctx = currentContext();
    const { page, pageSize, skip } = normalizePage(q.page, q.pageSize);
    const args: any[] = [ctx.tenantId];
    let where = 'tenant_id=? AND is_deleted=0';
    if (q.status) { where += ' AND status=?'; args.push(Number(q.status)); }
    if (q.keyword) { where += ' AND (name LIKE ? OR company LIKE ? OR phone LIKE ?)'; const k = `%${q.keyword}%`; args.push(k, k, k); }
    const list = await this.dataSource.query(`SELECT * FROM crm_lead WHERE ${where} ORDER BY id DESC LIMIT ? OFFSET ?`, [...args, pageSize, skip]);
    const total: any[] = await this.dataSource.query(`SELECT COUNT(*) c FROM crm_lead WHERE ${where}`, args);
    return pageResult(list, Number(total[0]?.c || 0), page, pageSize);
  }

  saveLead(dto: any) {
    const ctx = currentContext();
    const score = this.scoreLead(dto);
    if (dto.id) {
      return this.dataSource.query(
        `UPDATE crm_lead SET name=?, phone=?, company=?, source=?, owner_id=?, remark=?, score=? WHERE id=? AND tenant_id=?`,
        [dto.name, dto.phone || null, dto.company || null, dto.source || null, dto.ownerId || dto.owner_id || null, dto.remark || null, score, dto.id, ctx.tenantId])
        .then(() => ({ id: dto.id, score }));
    }
    return this.dataSource.query(
      `INSERT INTO crm_lead (tenant_id, name, phone, company, source, owner_id, remark, score, created_by) VALUES (?,?,?,?,?,?,?,?,?)`,
      [ctx.tenantId, dto.name, dto.phone || null, dto.company || null, dto.source || null, dto.ownerId || dto.owner_id || null, dto.remark || null, score, ctx.userId])
      .then((res: any) => ({ id: res.insertId, score }));
  }

  /**
   * 线索评分规则兜底（AI 不可用时使用）：有公司 +30，有电话 +20，来源为转介绍 +30，其他来源 +10。
   * 满分 100，用于线索池排序。
   */
  private scoreLead(dto: any): number {
    let s = 20;
    if (dto.company) s += 30;
    if (dto.phone) s += 20;
    if (dto.source === '转介绍') s += 30;
    else if (dto.source) s += 10;
    return Math.min(100, s);
  }

  /** 线索转化：标记已转化，并生成客户与商机 */
  async convertLead(leadId: number, dto: any) {
    const ctx = currentContext();
    const rows: any[] = await this.dataSource.query(`SELECT * FROM crm_lead WHERE id=? AND tenant_id=?`, [leadId, ctx.tenantId]);
    const lead = rows[0];
    if (!lead) throw new BizException(BizCode.NOT_FOUND, '线索不存在');
    const cust: any = await this.dataSource.query(
      `INSERT INTO customer (tenant_id, name, phone, created_by) VALUES (?,?,?,?)`,
      [ctx.tenantId, dto.customerName || lead.company || lead.name, lead.phone, ctx.userId]);
    await this.dataSource.query(
      `INSERT INTO crm_opportunity (tenant_id, name, customer_id, amount, stage, probability, owner_id, created_by)
       VALUES (?,?,?,?,?,?,?,?)`,
      [ctx.tenantId, dto.oppName || `${lead.name} 商机`, cust.insertId, Number(dto.amount || 0), '初步接触', 10, lead.owner_id || ctx.userId, ctx.userId]);
    await this.dataSource.query(`UPDATE crm_lead SET status=3 WHERE id=?`, [leadId]);
    await this.follow('LEAD', leadId, `线索转化为客户（${lead.name}）`);
    await this.audit.write('CONVERT', 'CRM_LEAD', leadId, lead.name, '线索转化');
    return { customerId: cust.insertId };
  }

  // ---------------- 商机 ----------------

  listOpportunities(q: any) {
    const ctx = currentContext();
    const args: any[] = [ctx.tenantId];
    let where = 'tenant_id=? AND is_deleted=0';
    if (q.stage) { where += ' AND stage=?'; args.push(q.stage); }
    return this.dataSource.query(`SELECT * FROM crm_opportunity WHERE ${where} ORDER BY id DESC LIMIT 200`, args);
  }

  saveOpportunity(dto: any) {
    const ctx = currentContext();
    if (dto.id) {
      return this.dataSource.query(
        `UPDATE crm_opportunity SET name=?, customer_id=?, amount=?, stage=?, probability=?, expect_date=?, owner_id=? WHERE id=? AND tenant_id=?`,
        [dto.name, dto.customerId || dto.customer_id || null, Number(dto.amount || 0), dto.stage || '初步接触',
          Number(dto.probability || 10), dto.expectDate || dto.expect_date || null, dto.ownerId || dto.owner_id || null, dto.id, ctx.tenantId])
        .then(() => ({ id: dto.id }));
    }
    return this.dataSource.query(
      `INSERT INTO crm_opportunity (tenant_id, name, customer_id, amount, stage, probability, expect_date, owner_id, created_by)
       VALUES (?,?,?,?,?,?,?,?,?)`,
      [ctx.tenantId, dto.name, dto.customerId || dto.customer_id || null, Number(dto.amount || 0), dto.stage || '初步接触',
        Number(dto.probability || 10), dto.expectDate || dto.expect_date || null, dto.ownerId || dto.owner_id || null, ctx.userId])
      .then(async (res: any) => {
        await this.follow('OPPORTUNITY', res.insertId, '创建商机');
        return { id: res.insertId };
      });
  }

  // ---------------- 跟进 ----------------

  follow(bizType: string, bizId: number, content: string, nextTime?: string) {
    const ctx = currentContext();
    return this.dataSource.query(
      `INSERT INTO crm_follow (tenant_id, biz_type, biz_id, content, next_time, created_by) VALUES (?,?,?,?,?,?)`,
      [ctx.tenantId, bizType, bizId, content, nextTime || null, ctx.userId]);
  }

  listFollows(bizType: string, bizId: number) {
    return this.dataSource.query(
      `SELECT * FROM crm_follow WHERE tenant_id=? AND biz_type=? AND biz_id=? AND is_deleted=0 ORDER BY id DESC`,
      [currentContext().tenantId, bizType, bizId]);
  }

  // ---------------- 报价单 ----------------

  listQuotations() {
    return this.dataSource.query(`SELECT * FROM crm_quotation WHERE tenant_id=? AND is_deleted=0 ORDER BY id DESC LIMIT 200`, [currentContext().tenantId]);
  }

  saveQuotation(dto: any) {
    const ctx = currentContext();
    const no = dto.quoteNo || `QT${Date.now().toString().slice(-8)}`;
    return this.dataSource.query(
      `INSERT INTO crm_quotation (tenant_id, quote_no, customer_id, opportunity_id, total_amount, status, valid_until, created_by)
       VALUES (?,?,?,?,?,?,?,?)`,
      [ctx.tenantId, no, dto.customerId || dto.customer_id || null, dto.opportunityId || dto.opportunity_id || null,
        Number(dto.totalAmount || dto.total_amount || 0), Number(dto.status || 0), dto.validUntil || dto.valid_until || null, ctx.userId])
      .then((res: any) => ({ id: res.insertId, quoteNo: no }));
  }

  /** 报价单转销售单：复用销售模块创建草稿单（此处只记录接受状态，建单由前端跳转销售单完成） */
  acceptQuotation(id: number) {
    return this.dataSource.query(`UPDATE crm_quotation SET status=2 WHERE id=? AND tenant_id=?`, [id, currentContext().tenantId])
      .then(() => ({ status: 'ACCEPTED' }));
  }
}

@Controller('api/v1/crm')
class CrmController {
  constructor(private readonly service: CrmService) {}

  @Get('customers') @RequirePerm('crm:customer:view') listCustomers(@Query() q: any) { return this.service.listCustomers(q); }
  @Post('customers') @RequirePerm('crm:customer:edit') saveCustomer(@Body() dto: any) { return this.service.saveCustomer(dto); }
  @Get('leads') @RequirePerm('crm:lead:view') listLeads(@Query() q: any) { return this.service.listLeads(q); }
  @Post('leads') @RequirePerm('crm:lead:edit') saveLead(@Body() dto: any) { return this.service.saveLead(dto); }
  @Post('leads/:id/convert') @RequirePerm('crm:lead:edit') convert(@Param('id', ParseIntPipe) id: number, @Body() dto: any) { return this.service.convertLead(id, dto); }
  @Get('opportunities') @RequirePerm('crm:opp:view') listOpp(@Query() q: any) { return this.service.listOpportunities(q); }
  @Post('opportunities') @RequirePerm('crm:opp:edit') saveOpp(@Body() dto: any) { return this.service.saveOpportunity(dto); }
  @Get('follows') @RequirePerm('crm:lead:view') follows(@Query() q: any) { return this.service.listFollows(q.bizType, Number(q.bizId)); }
  @Post('follows') @RequirePerm('crm:lead:edit') addFollow(@Body() dto: any) { return this.service.follow(dto.bizType, dto.bizId, dto.content, dto.nextTime); }
  @Get('quotations') @RequirePerm('crm:quote:view') quotes() { return this.service.listQuotations(); }
  @Post('quotations') @RequirePerm('crm:opp:edit') saveQuote(@Body() dto: any) { return this.service.saveQuotation(dto); }
  @Post('quotations/:id/accept') @RequirePerm('crm:opp:edit') accept(@Param('id', ParseIntPipe) id: number) { return this.service.acceptQuotation(id); }
}

@Module({ controllers: [CrmController], providers: [CrmService, AuditService], exports: [CrmService] })
export class CrmModule {}
