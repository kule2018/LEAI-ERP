/**
 * 财务结算模块：科目 / 凭证 / 收付款 / 核销 / 期间 / 报表
 * 自动凭证通过事件 finance.autoVoucher 接收业务模块推送（销售、采购）。
 */
import { Body, Controller, Get, Injectable, Module, OnModuleInit, Param, ParseIntPipe, Post, Query } from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';
import { DataSource } from 'typeorm';
import { EventEmitter2, OnEvent } from '@nestjs/event-emitter';
import { BizException, BizCode, RequirePerm, currentContext, normalizePage, pageResult, buildDataScopeWhere, appendDataScope } from '../../common/common';
import { AuditService } from '../../common/audit.service';
import { SequenceService } from '../../common/sequence.service';
import Decimal from 'decimal.js';

@Injectable()
export class FinanceService {
  constructor(
    @InjectDataSource() private readonly dataSource: DataSource,
    private readonly seq: SequenceService,
    private readonly audit: AuditService,
    private readonly events: EventEmitter2,
  ) {}

  listSubjects() {
    return this.dataSource.query(
      `SELECT * FROM account_subject WHERE tenant_id=? AND is_deleted=0 ORDER BY code`, [currentContext().tenantId]);
  }

  async saveSubject(dto: any, id?: number) {
    const ctx = currentContext();
    if (id) {
      await this.dataSource.query(
        `UPDATE account_subject SET name=?, category=?, direction=?, parent_id=? WHERE id=? AND tenant_id=?`,
        [dto.name, dto.category || '资产', dto.direction || 1, dto.parentId || 0, id, ctx.tenantId]);
      return { id };
    }
    const res: any = await this.dataSource.query(
      `INSERT INTO account_subject (tenant_id, code, name, parent_id, category, direction) VALUES (?,?,?,?,?,?)`,
      [ctx.tenantId, dto.code, dto.name, dto.parentId || 0, dto.category || '资产', dto.direction || 1]);
    return { id: res.insertId };
  }

  listAccounts() {
    return this.dataSource.query(`SELECT * FROM account WHERE tenant_id=? AND is_deleted=0 ORDER BY id`, [currentContext().tenantId]);
  }

  async saveAccount(dto: any, id?: number) {
    const ctx = currentContext();
    if (id) {
      await this.dataSource.query(`UPDATE account SET name=?, type=? WHERE id=? AND tenant_id=?`, [dto.name, dto.type || 'BANK', id, ctx.tenantId]);
      return { id };
    }
    const res: any = await this.dataSource.query(
      `INSERT INTO account (tenant_id, code, name, type) VALUES (?,?,?,?)`, [ctx.tenantId, dto.code || null, dto.name, dto.type || 'BANK']);
    return { id: res.insertId };
  }

  /** 凭证列表 */
  async listVouchers(query: any) {
    const ctx = currentContext();
    const { page, pageSize, skip } = normalizePage(query.page, query.pageSize);
    const where: string[] = ['v.tenant_id = ?'];
    const args: any[] = [ctx.tenantId];
    if (query.status !== undefined && query.status !== '') { where.push('v.status = ?'); args.push(query.status); }
    if (query.keyword) { where.push('v.voucher_no LIKE ?'); args.push(`%${query.keyword}%`); }
    appendDataScope(where, args, buildDataScopeWhere('ORG', ctx, 'v', { creatorCol: 'created_by' }));
    const list = await this.dataSource.query(
      `SELECT v.* FROM voucher v WHERE ${where.join(' AND ')} ORDER BY v.id DESC LIMIT ? OFFSET ?`, [...args, pageSize, skip]);
    const totalRows: any[] = await this.dataSource.query(`SELECT COUNT(*) c FROM voucher v WHERE ${where.join(' AND ')}`, args);
    return pageResult(list, Number(totalRows[0]?.c || 0), page, pageSize);
  }

  async voucherDetail(id: number) {
    const ctx = currentContext();
    const rows: any[] = await this.dataSource.query(`SELECT * FROM voucher WHERE id=? AND tenant_id=?`, [id, ctx.tenantId]);
    if (!rows[0]) throw new BizException(BizCode.NOT_FOUND, '凭证不存在');
    const entries = await this.dataSource.query(
      `SELECT e.*, s.name AS subject_name, s.code AS subject_code FROM voucher_entry e
        LEFT JOIN account_subject s ON s.id=e.subject_id WHERE e.voucher_id=? AND e.tenant_id=?`, [id, ctx.tenantId]);
    return { ...rows[0], entries };
  }

  /**
   * 新建凭证：借贷必须平衡，否则拒绝保存
   * @param dto.entries 分录数组 {subjectId, debit, credit, summary}
   */
  async saveVoucher(dto: any) {
    const ctx = currentContext();
    const entries: any[] = (dto.entries || []).filter((e) => Number(e.debit || 0) > 0 || Number(e.credit || 0) > 0);
    if (entries.length < 2) throw new BizException(BizCode.PARAM_INVALID, '凭证至少需要一借一贷两行分录');
    let debit = new Decimal(0); let credit = new Decimal(0);
    for (const e of entries) { debit = debit.plus(e.debit || 0); credit = credit.plus(e.credit || 0); }
    if (!debit.equals(credit)) throw new BizException(BizCode.PARAM_INVALID, `借贷不平衡：借 ${debit} / 贷 ${credit}`);
    await this.checkPeriod(dto.voucherDate);
    const voucherNo = dto.voucherNo || await this.seq.next('VOUCHER');
    const res: any = await this.dataSource.query(
      `INSERT INTO voucher (tenant_id, voucher_no, voucher_date, source_type, source_id, status, total_debit, total_credit, remark, created_by)
       VALUES (?,?,?,?,?,?,?,?,?,?)`,
      [ctx.tenantId, voucherNo, dto.voucherDate || new Date(), dto.sourceType || 'MANUAL', dto.sourceId || null,
        dto.status ?? 0, debit.toDecimalPlaces(4).toString(), credit.toDecimalPlaces(4).toString(), dto.remark || null, ctx.userId]);
    for (const e of entries) {
      await this.dataSource.query(
        `INSERT INTO voucher_entry (tenant_id, voucher_id, subject_id, summary, debit, credit) VALUES (?,?,?,?,?,?)`,
        [ctx.tenantId, res.insertId, e.subjectId, e.summary || null,
          new Decimal(e.debit || 0).toDecimalPlaces(4).toString(), new Decimal(e.credit || 0).toDecimalPlaces(4).toString()]);
    }
    await this.audit.writeDiff('CREATE', 'VOUCHER', res.insertId, voucherNo, null,
      { voucher_no: voucherNo, total_debit: debit.toDecimalPlaces(4).toString(),
        total_credit: credit.toDecimalPlaces(4).toString(), source_type: dto.sourceType || 'MANUAL' },
      ['total_debit']);
    return { id: res.insertId, voucherNo };
  }

  /** 过账：草稿 → 已过账，同时更新科目发生额 */
  async postVoucher(id: number) {
    const v = await this.voucherDetail(id);
    if (Number(v.status) !== 0) throw new BizException(BizCode.STATUS_ILLEGAL, '仅草稿凭证可过账');
    await this.dataSource.query(`UPDATE voucher SET status=1 WHERE id=? AND tenant_id=?`, [id, currentContext().tenantId]);
    await this.audit.write('AUDIT', 'VOUCHER', id, v.voucher_no, '凭证过账');
    return { id };
  }

  /** 作废：草稿可直接作废；已过账需先红字冲销；软删除仅置状态，记录保留可追溯 */
  async voidVoucher(id: number) {
    const v = await this.voucherDetail(id);
    if (Number(v.status) === 2) return { id, message: '凭证已作废' };
    if (Number(v.status) === 1) throw new BizException(BizCode.STATUS_ILLEGAL, '已过账凭证不可直接作废，请先红字冲销');
    await this.dataSource.query(`UPDATE voucher SET status=2 WHERE id=? AND tenant_id=?`, [id, currentContext().tenantId]);
    await this.audit.write('AUDIT', 'VOUCHER', id, v.voucher_no, '凭证作废（软删除，记录保留）');
    return { id, message: '凭证已作废（记录保留可追溯）' };
  }

  /**
   * 收付款单：确认后自动核销未结账单（先进先出），并生成资金凭证
   * direction：1 收款（客户） / 2 付款（供应商）
   */
  async savePayment(dto: any, id?: number) {
    const ctx = currentContext();
    const amount = new Decimal(dto.amount || 0);
    if (amount.lte(0)) throw new BizException(BizCode.PARAM_INVALID, '金额必须大于 0');
    if (id) {
      await this.dataSource.query(
        `UPDATE payment SET partner_id=?, account_id=?, amount=?, pay_date=?, remark=? WHERE id=? AND tenant_id=? AND status=0`,
        [dto.partnerId, dto.accountId || null, amount.toDecimalPlaces(4).toString(), dto.payDate || new Date(), dto.remark || null, id, ctx.tenantId]);
      return { id };
    }
    const payNo = await this.seq.next('PAY');
    const res: any = await this.dataSource.query(
      `INSERT INTO payment (tenant_id, pay_no, direction, partner_id, account_id, amount, pay_date, status, remark, created_by)
       VALUES (?,?,?,?,?,?,?,0,?,?)`,
      [ctx.tenantId, payNo, dto.direction, dto.partnerId, dto.accountId || null,
        amount.toDecimalPlaces(4).toString(), dto.payDate || new Date(), dto.remark || null, ctx.userId]);
    await this.audit.write('CREATE', 'PAYMENT', res.insertId, payNo, `新建收付款，金额 ${amount.toString()}`);
    return { id: res.insertId, payNo };
  }

  /** 确认收付款：核销账单 + 资金账户变动 + 凭证 + 回写销售单收款状态 */
  async confirmPayment(id: number) {
    const ctx = currentContext();
    const rows: any[] = await this.dataSource.query(`SELECT * FROM payment WHERE id=? AND tenant_id=?`, [id, ctx.tenantId]);
    const pay = rows[0];
    if (!pay) throw new BizException(BizCode.NOT_FOUND, '收付款单不存在');
    if (Number(pay.status) !== 0) throw new BizException(BizCode.STATUS_ILLEGAL, '单据已确认或已作废');

    await this.dataSource.query('START TRANSACTION');
    try {
      const billTable = Number(pay.direction) === 1 ? 'receivable' : 'payable';
      const partnerCol = Number(pay.direction) === 1 ? 'customer_id' : 'supplier_id';
      let remain = new Decimal(pay.amount);
      // 按到期日从小到大自动核销
      const bills: any[] = await this.dataSource.query(
        `SELECT * FROM ${billTable} WHERE tenant_id=? AND ${partnerCol}=? AND is_deleted=0 AND status <> 2
          ORDER BY IFNULL(due_date,'9999-12-31'), id`, [ctx.tenantId, pay.partner_id]);
      for (const bill of bills) {
        if (remain.lte(0)) break;
        const billRemain = new Decimal(bill.amount).minus(bill.received_amount ?? bill.paid_amount ?? 0);
        if (billRemain.lte(0)) continue;
        const writeoffAmount = Decimal.min(remain, billRemain);
        await this.dataSource.query(
          `INSERT INTO writeoff (tenant_id, payment_id, bill_type, bill_id, amount) VALUES (?,?,?,?,?)`,
          [ctx.tenantId, id, billTable === 'receivable' ? 'RECEIVABLE' : 'PAYABLE', bill.id, writeoffAmount.toDecimalPlaces(4).toString()]);
        const newReceived = new Decimal(bill.received_amount ?? bill.paid_amount ?? 0).plus(writeoffAmount);
        const col = billTable === 'receivable' ? 'received_amount' : 'paid_amount';
        const newStatus = newReceived.greaterThanOrEqualTo(new Decimal(bill.amount)) ? 2 : 1;
        await this.dataSource.query(`UPDATE ${billTable} SET ${col}=?, status=? WHERE id=?`, [newReceived.toDecimalPlaces(4).toString(), newStatus, bill.id]);
        // 回写销售单收款状态
        if (billTable === 'receivable' && bill.source_type === 'SALE_ORDER') {
          const agg: any[] = await this.dataSource.query(
            `SELECT o.total_amount, IFNULL(SUM(w.amount),0) paid FROM sale_order o
              LEFT JOIN receivable r ON r.source_type='SALE_ORDER' AND r.source_id=o.id AND r.is_deleted=0
              LEFT JOIN writeoff w ON w.bill_type='RECEIVABLE' AND w.bill_id=r.id
             WHERE o.id=? GROUP BY o.id`, [bill.source_id]);
          if (agg[0]) {
            const paid = new Decimal(agg[0].paid);
            const payStatus = paid.lte(0) ? 0 : (paid.greaterThanOrEqualTo(new Decimal(agg[0].total_amount)) ? 2 : 1);
            await this.dataSource.query(`UPDATE sale_order SET paid_amount=?, pay_status=? WHERE id=?`, [paid.toDecimalPlaces(4).toString(), payStatus, bill.source_id]);
          }
        }
        remain = remain.minus(writeoffAmount);
      }
      // 资金账户余额变动：按本次实际收付款金额与方向更新，而非核销后的剩余额
      if (pay.account_id) {
        const amount = new Decimal(pay.amount || 0);
        const delta = Number(pay.direction) === 1 ? amount : amount.negated();
        await this.dataSource.query(`UPDATE account SET balance = balance + ? WHERE id=?`, [delta.toDecimalPlaces(4).toString(), pay.account_id]);
        await this.audit.write('AUDIT', 'PAYMENT', id, pay.pay_no, `账户余额变动 ${delta.toString()}`);
      }
      await this.dataSource.query(`UPDATE payment SET status=1 WHERE id=?`, [id]);
      // 凭证：收款 借银行 贷应收；付款 借应付 贷银行
      const subjectCode = Number(pay.direction) === 1 ? '1002' : '1002';
      const billCode = Number(pay.direction) === 1 ? '1122' : '2202';
      const subj: any[] = await this.dataSource.query(
        `SELECT id FROM account_subject WHERE tenant_id=? AND code IN ('1002','1122','2202')`, [ctx.tenantId]);
      const map: Record<string, number> = {};
      for (const s of subj) map[s.code] = Number(s.id);
      const entries: any[] = [];
      if (map[subjectCode] && map[billCode]) {
        if (Number(pay.direction) === 1) {
          entries.push({ subjectId: map['1002'], debit: pay.amount, credit: 0, summary: '收款' });
          entries.push({ subjectId: map['1122'], debit: 0, credit: pay.amount, summary: '核销应收' });
        } else {
          entries.push({ subjectId: map['2202'], debit: pay.amount, credit: 0, summary: '核销应付' });
          entries.push({ subjectId: map['1002'], debit: 0, credit: pay.amount, summary: '付款' });
        }
      }
      if (entries.length === 2) {
        await this.saveVoucher({ voucherDate: pay.pay_date, sourceType: 'PAYMENT', sourceId: id, status: 1, remark: `${pay.pay_no} 自动凭证`, entries });
      }
      await this.audit.write('AUDIT', 'PAYMENT', id, pay.pay_no, '收付款确认并核销');
      await this.dataSource.query('COMMIT');
      return { id };
    } catch (e) {
      await this.dataSource.query('ROLLBACK');
      throw e;
    }
  }

  /** 期间结账：锁期间，之后不能录该月凭证 */
  async closePeriod(period: string) {
    const ctx = currentContext();
    const res: any = await this.dataSource.query(
      `INSERT IGNORE INTO fin_period (tenant_id, period, is_closed, closed_by, closed_at) VALUES (?,?,1,?,NOW())
       ON DUPLICATE KEY UPDATE is_closed=1, closed_by=VALUES(closed_by), closed_at=NOW()`,
      [ctx.tenantId, period, ctx.userId]);
    await this.audit.write('AUDIT', 'FIN_PERIOD', 0, period, '期末结账');
    return { period, closed: true };
  }

  async openPeriod(period: string) {
    const ctx = currentContext();
    await this.dataSource.query(`UPDATE fin_period SET is_closed=0 WHERE tenant_id=? AND period=?`, [ctx.tenantId, period]);
    await this.audit.write('AUDIT', 'FIN_PERIOD', 0, period, '反结账');
    return { period, closed: false };
  }

  private async checkPeriod(date: any) {
    const period = new Date(date || new Date()).toISOString().slice(0, 7);
    const rows: any[] = await this.dataSource.query(`SELECT is_closed FROM fin_period WHERE tenant_id=? AND period=?`, [currentContext().tenantId, period]);
    if (rows[0] && Number(rows[0].is_closed) === 1) throw new BizException(BizCode.PERIOD_LOCKED, `会计期间 ${period} 已结账，请先反结账`);
  }

  /** 业务事件：自动生成并过账凭证（销售/采购） */
  @OnEvent('finance.autoVoucher', { async: true })
  async handleAutoVoucher(payload: any) {
    try {
      if (!payload?.entries?.length) return;
      await this.saveVoucher({ voucherDate: payload.voucherDate, sourceType: payload.sourceType, sourceId: payload.sourceId,
        status: 1, remark: payload.summary || '自动凭证', entries: payload.entries });
    } catch (err: any) {
      // 自动凭证失败不阻断业务，但必须写审计日志便于补单
      await this.audit.write('ERROR', payload?.sourceType || 'AUTO_VOUCHER', payload?.sourceId || 0, '', `自动凭证失败：${err?.message || err}`);
    }
  }

  /** 试算平衡表：按科目汇总借贷发生额 */
  async trialBalance() {
    return this.dataSource.query(
      `SELECT s.code, s.name, s.category,
              IFNULL(SUM(e.debit),0) AS debit, IFNULL(SUM(e.credit),0) AS credit
         FROM account_subject s
         LEFT JOIN voucher_entry e ON e.subject_id = s.id AND e.tenant_id = s.tenant_id
         LEFT JOIN voucher v ON v.id = e.voucher_id
        WHERE s.tenant_id=? AND s.is_deleted=0 AND (e.id IS NULL OR v.status = 1)
        GROUP BY s.id, s.code, s.name, s.category ORDER BY s.code`, [currentContext().tenantId]);
  }

  /** 应收账龄：按未结金额与到期日分档 */
  async receivableAging() {
    return this.dataSource.query(
      `SELECT c.name AS customer_name,
              r.amount, r.received_amount, (r.amount - r.received_amount) AS unpaid, r.due_date,
              CASE WHEN DATEDIFF(CURDATE(), r.due_date) <= 0 THEN '未逾期'
                   WHEN DATEDIFF(CURDATE(), r.due_date) BETWEEN 1 AND 30 THEN '1-30天'
                   WHEN DATEDIFF(CURDATE(), r.due_date) BETWEEN 31 AND 90 THEN '31-90天'
                   ELSE '90天以上' END AS aging
         FROM receivable r LEFT JOIN customer c ON c.id=r.customer_id
        WHERE r.tenant_id=? AND r.is_deleted=0 AND r.status <> 2
        ORDER BY aging`, [currentContext().tenantId]);
  }

  listPayables() {
    return this.dataSource.query(
      `SELECT p.*, s.name AS supplier_name FROM payable p LEFT JOIN supplier s ON s.id=p.supplier_id
        WHERE p.tenant_id=? AND p.is_deleted=0 ORDER BY p.id DESC`, [currentContext().tenantId]);
  }

  /** 损益表：损益类科目发生额汇总 */
  async profitLoss() {
    return this.dataSource.query(
      `SELECT s.category, s.code, s.name,
              IFNULL(SUM(e.credit),0) - IFNULL(SUM(e.debit),0) AS amount
         FROM account_subject s
         LEFT JOIN voucher_entry e ON e.subject_id=s.id AND e.tenant_id=s.tenant_id
         LEFT JOIN voucher v ON v.id=e.voucher_id
        WHERE s.tenant_id=? AND s.category='损益' AND s.is_deleted=0 AND (e.id IS NULL OR v.status=1)
        GROUP BY s.id, s.code, s.name ORDER BY s.code`, [currentContext().tenantId]);
  }
}

@Controller('api/v1/finance')
class FinanceController {
  constructor(private readonly service: FinanceService) {}

  @Get('subjects') @RequirePerm('finance:subject:view') listSubjects() { return this.service.listSubjects(); }
  @Post('subjects') @RequirePerm('finance:subject:edit') saveSubject(@Body() dto: any) { return this.service.saveSubject(dto); }
  @Get('accounts') @RequirePerm('finance:subject:view') listAccounts() { return this.service.listAccounts(); }
  @Post('accounts') @RequirePerm('finance:subject:edit') saveAccount(@Body() dto: any) { return this.service.saveAccount(dto); }

  @Get('vouchers') @RequirePerm('finance:voucher:view') listVouchers(@Query() q: any) { return this.service.listVouchers(q); }
  @Get('vouchers/:id') @RequirePerm('finance:voucher:view') voucherDetail(@Param('id', ParseIntPipe) id: number) { return this.service.voucherDetail(id); }
  @Post('vouchers') @RequirePerm('finance:voucher:create') saveVoucher(@Body() dto: any) { return this.service.saveVoucher(dto); }
  @Post('vouchers/:id/post') @RequirePerm('finance:voucher:post') postVoucher(@Param('id', ParseIntPipe) id: number) { return this.service.postVoucher(id); }
  @Post('vouchers/:id/void') @RequirePerm('finance:voucher:post') voidVoucher(@Param('id', ParseIntPipe) id: number) { return this.service.voidVoucher(id); }

  @Post('payments') @RequirePerm('finance:payment:create') savePayment(@Body() dto: any) { return this.service.savePayment(dto); }
  @Post('payments/:id/confirm') @RequirePerm('finance:payment:confirm') confirmPayment(@Param('id', ParseIntPipe) id: number) { return this.service.confirmPayment(id); }

  @Get('trial-balance') @RequirePerm('finance:report:view') trialBalance() { return this.service.trialBalance(); }
  @Get('receivable-aging') @RequirePerm('finance:report:view') receivableAging() { return this.service.receivableAging(); }
  @Get('payables') @RequirePerm('finance:report:view') listPayables() { return this.service.listPayables(); }
  @Get('profit-loss') @RequirePerm('finance:report:view') profitLoss() { return this.service.profitLoss(); }

  @Post('periods/:period/close') @RequirePerm('finance:period:close') closePeriod(@Param('period') period: string) { return this.service.closePeriod(period); }
  @Post('periods/:period/open') @RequirePerm('finance:period:close') openPeriod(@Param('period') period: string) { return this.service.openPeriod(period); }
}

@Module({ controllers: [FinanceController], providers: [FinanceService, SequenceService, AuditService], exports: [FinanceService] })
export class FinanceModule {}
