/**
 * 外部集成适配器（文档扩展章）
 * ------------------------------------------------------------------
 * 统一 Adapter 框架：配置中心、HMAC-SHA256 签名/验签、requestId 幂等、
 * 失败重试与补偿、回调验签、调用日志表。
 * 覆盖 7 类 provider：wechat_work / dingtalk / payment / logistics /
 * einvoice / bank / holiday_api。未配置密钥时使用可识别的模拟 Provider，
 * 保证本地无密钥也能跑通全流程（响应中带 mock=true 明确提示）。
 * ------------------------------------------------------------------
 */
import {
  Body, Controller, Get, Injectable, Module, Param, Post, Query,
} from '@nestjs/common';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { JwtModule, JwtService } from '@nestjs/jwt';
import { InjectDataSource } from '@nestjs/typeorm';
import { DataSource } from 'typeorm';
import { createHmac, randomUUID, timingSafeEqual } from 'node:crypto';
import * as bcrypt from 'bcryptjs';
import { BizCode, BizException, Public, RequirePerm, currentContext, normalizePage, pageResult } from '../../common/common';
import { AuditService } from '../../common/audit.service';
import { JWT_SECRET } from '../../load-env';

const JWT_EXPIRES = process.env.JWT_EXPIRES || '2h';
/** 未配置密钥时的模拟签名密钥：只在本地演示使用，响应会标记 mock */
const MOCK_SECRET = 'erp-mock-integration-secret';

interface ProviderMeta {
  code: string;
  name: string;
  category: string;
  /** 构造授权 URL；返回 null 表示不需要 OAuth */
  authorize?: (appId: string, redirectUri: string, state: string, extra?: any) => string;
  /** 模拟 userinfo：无密钥时用 code 派生稳定的 openid */
  mockUser?: (code: string) => any;
}

/** 7 类 provider 的真实授权 URL 格式与模拟 userinfo */
const PROVIDERS: Record<string, ProviderMeta> = {
  wechat_work: {
    code: 'wechat_work', name: '企业微信', category: 'OAUTH',
    authorize: (appId, redirectUri, state, extra) =>
      `https://open.work.weixin.qq.com/wwopen/sso/qrConnect?appid=${appId}&agentid=${encodeURIComponent(String(extra?.agentId || ''))}`
      + `&redirect_uri=${encodeURIComponent(redirectUri)}&state=${encodeURIComponent(state)}#wechat_redirect`,
    mockUser: (code) => ({
      openid: `ww_${hashOf(code).slice(0, 16)}`, userid: `demo_${hashOf(code).slice(0, 8)}`,
      name: '企业微信用户', avatar: '', phone: '13800138000', email: '',
    }),
  },
  dingtalk: {
    code: 'dingtalk', name: '钉钉', category: 'OAUTH',
    authorize: (appId, redirectUri, state) =>
      `https://login.dingtalk.com/oauth2/auth?redirect_uri=${encodeURIComponent(redirectUri)}`
      + `&response_type=code&client_id=${appId}&scope=openid&state=${encodeURIComponent(state)}&prompt=consent`,
    mockUser: (code) => ({
      openid: `dt_${hashOf(code).slice(0, 16)}`, userid: `demo_${hashOf(code).slice(0, 8)}`,
      name: '钉钉用户', avatar: '', phone: '13900139000', email: '',
    }),
  },
  payment: {
    code: 'payment', name: '支付网关（微信/支付宝/聚合）', category: 'PAYMENT',
    mockUser: (code) => ({ openid: `pay_${hashOf(code).slice(0, 12)}` }),
  },
  logistics: {
    code: 'logistics', name: '物流（顺丰/圆通）', category: 'LOGISTICS',
    mockUser: (code) => ({ openid: `log_${hashOf(code).slice(0, 12)}` }),
  },
  einvoice: { code: 'einvoice', name: '电子发票', category: 'EINVOICE' },
  bank: { code: 'bank', name: '银行银企直连', category: 'BANK' },
  holiday_api: { code: 'holiday_api', name: '节假日 API', category: 'HOLIDAY' },
};

/** 稳定的字符串摘要（仅用于生成模拟 openid / requestId，非安全用途） */
function hashOf(text: string): string {
  return createHmac('sha256', MOCK_SECRET).update(String(text)).digest('hex');
}

/** 2026 年中国法定节假日（内置数据，外部 API 不可用时兜底） */
const BUILTIN_HOLIDAYS: Record<number, { holidays: any[]; workdays: any[] }> = {
  2026: {
    holidays: [
      { date: '2026-01-01', name: '元旦', type: 'HOLIDAY' }, { date: '2026-01-02', name: '元旦', type: 'HOLIDAY' },
      { date: '2026-01-03', name: '元旦', type: 'HOLIDAY' },
      { date: '2026-02-15', name: '春节', type: 'HOLIDAY' }, { date: '2026-02-16', name: '春节', type: 'HOLIDAY' },
      { date: '2026-02-17', name: '春节', type: 'HOLIDAY' }, { date: '2026-02-18', name: '春节', type: 'HOLIDAY' },
      { date: '2026-02-19', name: '春节', type: 'HOLIDAY' }, { date: '2026-02-20', name: '春节', type: 'HOLIDAY' },
      { date: '2026-02-21', name: '春节', type: 'HOLIDAY' }, { date: '2026-02-22', name: '春节', type: 'HOLIDAY' },
      { date: '2026-02-23', name: '春节', type: 'HOLIDAY' },
      { date: '2026-04-04', name: '清明节', type: 'HOLIDAY' }, { date: '2026-04-05', name: '清明节', type: 'HOLIDAY' },
      { date: '2026-04-06', name: '清明节', type: 'HOLIDAY' },
      { date: '2026-05-01', name: '劳动节', type: 'HOLIDAY' }, { date: '2026-05-02', name: '劳动节', type: 'HOLIDAY' },
      { date: '2026-05-03', name: '劳动节', type: 'HOLIDAY' }, { date: '2026-05-04', name: '劳动节', type: 'HOLIDAY' },
      { date: '2026-05-05', name: '劳动节', type: 'HOLIDAY' },
      { date: '2026-06-19', name: '端午节', type: 'HOLIDAY' }, { date: '2026-06-20', name: '端午节', type: 'HOLIDAY' },
      { date: '2026-06-21', name: '端午节', type: 'HOLIDAY' },
      { date: '2026-09-25', name: '中秋节', type: 'HOLIDAY' }, { date: '2026-09-26', name: '中秋节', type: 'HOLIDAY' },
      { date: '2026-09-27', name: '中秋节', type: 'HOLIDAY' },
      { date: '2026-10-01', name: '国庆节', type: 'HOLIDAY' }, { date: '2026-10-02', name: '国庆节', type: 'HOLIDAY' },
      { date: '2026-10-03', name: '国庆节', type: 'HOLIDAY' }, { date: '2026-10-04', name: '国庆节', type: 'HOLIDAY' },
      { date: '2026-10-05', name: '国庆节', type: 'HOLIDAY' }, { date: '2026-10-06', name: '国庆节', type: 'HOLIDAY' },
      { date: '2026-10-07', name: '国庆节', type: 'HOLIDAY' }, { date: '2026-10-08', name: '国庆节', type: 'HOLIDAY' },
    ],
    workdays: [
      { date: '2026-02-14', name: '春节调休上班', type: 'WORKDAY' },
      { date: '2026-02-28', name: '春节调休上班', type: 'WORKDAY' },
      { date: '2026-09-20', name: '中秋调休上班', type: 'WORKDAY' },
      { date: '2026-10-10', name: '国庆调休上班', type: 'WORKDAY' },
    ],
  },
};

interface LogEntry {
  provider: string;
  direction: 'IN' | 'OUT' | 'COMPENSATE';
  eventType: string;
  requestId?: string;
  bizType?: string;
  bizId?: number;
  status?: 'SUCCESS' | 'FAILED' | 'PENDING';
  payload?: any;
  response?: any;
  error?: string;
  mock?: boolean;
  latencyMs?: number;
}

@Injectable()
export class IntegrationService {
  constructor(
    @InjectDataSource() private readonly dataSource: DataSource,
    private readonly jwt: JwtService,
    private readonly audit: AuditService,
    private readonly events: EventEmitter2,
  ) {}

  // ---------------- 配置中心 ----------------

  listConfigs() {
    const ctx = currentContext();
    return this.dataSource.query(
      `SELECT id, provider_code, provider_name, category, enabled, api_base, app_id,
              secret_alias, webhook_token IS NOT NULL AS has_webhook_token, timeout_sec, retry_max,
              status, config_json, updated_at
         FROM integration_config WHERE tenant_id=? ORDER BY category, provider_code`, [ctx.tenantId]);
  }

  /** 新增/更新集成配置；密钥只保存别名（环境变量名），不明文落库 */
  async saveConfig(dto: any) {
    const ctx = currentContext();
    const code = String(dto.providerCode || dto.provider_code || '').toLowerCase();
    if (!PROVIDERS[code]) throw new BizException(BizCode.PARAM_INVALID, `不支持的 provider：${code}`);
    const meta = PROVIDERS[code];
    await this.dataSource.query(
      `INSERT INTO integration_config
        (tenant_id, provider_code, provider_name, category, enabled, api_base, app_id, secret_alias,
         webhook_token, callback_url, timeout_sec, retry_max, config_json, status, created_by)
       VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
       ON DUPLICATE KEY UPDATE provider_name=VALUES(provider_name), enabled=VALUES(enabled),
         api_base=VALUES(api_base), app_id=VALUES(app_id), secret_alias=VALUES(secret_alias),
         webhook_token=VALUES(webhook_token), callback_url=VALUES(callback_url),
         timeout_sec=VALUES(timeout_sec), retry_max=VALUES(retry_max), config_json=VALUES(config_json),
         status=VALUES(status)`,
      [ctx.tenantId, code, dto.providerName || meta.name, meta.category, dto.enabled ?? 1,
        dto.apiBase || dto.api_base || null, dto.appId || dto.app_id || null,
        dto.secretAlias || dto.secret_alias || null, dto.webhookToken || dto.webhook_token || null,
        dto.callbackUrl || dto.callback_url || null, Number(dto.timeoutSec || dto.timeout_sec || 10),
        Number(dto.retryMax ?? dto.retry_max ?? 3),
        typeof dto.configJson === 'string' ? dto.configJson : JSON.stringify(dto.configJson || {}),
        dto.status || 'ACTIVE', ctx.userId],
    );
    await this.audit.write('UPDATE', 'INTEGRATION_CONFIG', 0, code, `更新集成配置：${meta.name}`);
    return { providerCode: code, name: meta.name };
  }

  /** 取配置（自动补默认），resolveSecret=true 时返回真实密钥用于签名 */
  private async configOf(provider: string, tenantId?: number) {
    const tenant = Number(tenantId || currentContext().tenantId || 1);
    const rows: any[] = await this.dataSource.query(
      `SELECT * FROM integration_config WHERE tenant_id=? AND provider_code=? AND is_deleted=0`,
      [tenant, provider]);
    const row = rows[0] || {};
    let secret = null;
    const alias = String(row.secret_alias || '');
    if (alias) secret = process.env[alias.replace(/^env:/i, '')] || null;
    if (!secret && row.app_secret) secret = String(row.app_secret);
    return {
      ...row, provider_code: provider, providerCode: provider,
      apiBase: row.api_base || null, appId: row.app_id || null,
      secret, mock: !secret,
      timeoutSec: Number(row.timeout_sec || 10),
      retryMax: Number(row.retry_max || 3),
      extra: this.parseJson(row.config_json),
    };
  }

  private parseJson(value: any) {
    if (!value) return {};
    if (typeof value === 'object') return value;
    try { return JSON.parse(value); } catch { return {}; }
  }

  // ---------------- HMAC 签名 / 验签 / 幂等 / 重试 ----------------

  /** HMAC-SHA256 签名，hex 输出；无密钥时用模拟密钥并标记 */
  sign(secret: string | null, payload: string): { signature: string; mock: boolean } {
    const mock = !secret;
    return { signature: createHmac('sha256', secret || MOCK_SECRET).update(payload).digest('hex'), mock };
  }

  /** 验签：兼容 sha256= 前缀与 base64；无密钥的模拟模式直接放行但返回 mock */
  verify(secret: string | null, payload: string, signature?: string): { ok: boolean; mock: boolean } {
    const mock = !secret;
    if (!signature) return { ok: mock, mock };
    const clean = String(signature).replace(/^sha256=/i, '').trim();
    const expected = this.sign(secret, payload).signature;
    let ok = false;
    if (clean === expected) ok = true;
    else {
      const expectedBase64 = createHmac('sha256', secret || MOCK_SECRET).update(payload).digest('base64');
      ok = clean === expectedBase64;
    }
    // 定时安全比较，避免时间戳侧信道
    if (!ok && clean.length === expected.length) {
      try { ok = timingSafeEqual(Buffer.from(clean), Buffer.from(expected)); } catch { ok = false; }
    }
    return { ok: ok || mock, mock };
  }

  /** 请求体规范化为待签名串：排除签名字段，按 key 排序 */
  canonical(payload: any): string {
    const obj: any = { ...(payload || {}) };
    for (const key of Object.keys(obj)) {
      if (/^(signature|sign|sign_type|sig)$/i.test(key)) delete obj[key];
    }
    return Object.keys(obj).sort().map((k) => `${k}=${typeof obj[k] === 'object' ? JSON.stringify(obj[k]) : obj[k]}`).join('&');
  }

  /** 幂等检查：已处理过的 requestId 直接返回原记录 */
  private async idempotent(provider: string, requestId: string) {
    if (!requestId) return null;
    const ctx = currentContext();
    const rows: any[] = await this.dataSource.query(
      `SELECT * FROM integration_callback_log WHERE tenant_id=? AND provider=? AND request_id=?
        ORDER BY id DESC LIMIT 1`, [ctx.tenantId, provider, requestId]);
    return rows[0] || null;
  }

  /** 写调用/回调日志；requestId 唯一键保证并发幂等 */
  async writeLog(entry: LogEntry) {
    const ctx = currentContext();
    const requestId = entry.requestId || randomUUID();
    try {
      const res: any = await this.dataSource.query(
        `INSERT INTO integration_callback_log
          (tenant_id, provider, direction, event_type, request_id, biz_type, biz_id, status,
           payload_json, response_json, error_json, mock, latency_ms, created_by)
         VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
        [ctx.tenantId, entry.provider, entry.direction, entry.eventType, requestId,
          entry.bizType || null, entry.bizId || null, entry.status || 'SUCCESS',
          JSON.stringify(entry.payload || {}).slice(0, 4000), JSON.stringify(entry.response || {}).slice(0, 4000),
          entry.error ? String(entry.error).slice(0, 1000) : null,
          entry.mock ? 1 : 0, entry.latencyMs || 0, ctx.userId],
      );
      return { id: res.insertId, requestId };
    } catch (e: any) {
      // 唯一键冲突表示重复请求，返回已存在记录，保持幂等语义
      return this.idempotent(entry.provider, requestId);
    }
  }

  listLogs(query: any) {
    const ctx = currentContext();
    const { page, pageSize, skip } = normalizePage(query.page, query.pageSize);
    const args: any[] = [ctx.tenantId];
    let where = 'tenant_id = ?';
    if (query.provider) { where += ' AND provider = ?'; args.push(query.provider); }
    if (query.direction) { where += ' AND direction = ?'; args.push(query.direction); }
    if (query.status) { where += ' AND status = ?'; args.push(query.status); }
    return this.dataSource.query(
      `SELECT id, provider, direction, event_type, request_id, biz_type, biz_id, status, mock, latency_ms, created_at
         FROM integration_callback_log WHERE ${where} ORDER BY id DESC LIMIT ? OFFSET ?`,
      [...args, pageSize, skip],
    ).then(async (list) => {
      const total: any[] = await this.dataSource.query(
        `SELECT COUNT(*) c FROM integration_callback_log WHERE ${where}`, args);
      return pageResult(list, Number(total[0]?.c || 0), page, pageSize);
    });
  }

  /** 失败重试 + 最终失败补偿：不抛异常给调用方，返回带补偿标记的结果 */
  async callWithRetry(config: any, action: string, payload: any, executor: () => Promise<any>) {
    const started = Date.now();
    let lastError: any;
    const attempts = Math.max(1, Math.min(10, Number(config.retryMax || 3)));
    for (let i = 1; i <= attempts; i++) {
      try {
        const response = await executor();
        const log = await this.writeLog({ provider: config.provider_code, direction: 'OUT', eventType: action,
          payload, response, status: 'SUCCESS', mock: config.mock, latencyMs: Date.now() - started });
        return { ok: true, attempts: i, mock: !!config.mock, response, requestId: log?.requestId };
      } catch (e: any) {
        lastError = e;
        await this.writeLog({ provider: config.provider_code, direction: 'OUT', eventType: action,
          payload, status: 'FAILED', error: e?.message || e, mock: config.mock, latencyMs: Date.now() - started });
        if (i < attempts) await new Promise((r) => setTimeout(r, 5 * i));
      }
    }
    // 补偿：记录待补偿任务并推送告警，后续可由定时任务/人工重放
    const compensation = await this.writeLog({ provider: config.provider_code, direction: 'COMPENSATE',
      eventType: `${action}:COMPENSATE`, payload, status: 'PENDING', error: lastError?.message || lastError,
      mock: config.mock, latencyMs: Date.now() - started });
    this.events.emit('realtime.integration', {
      tenantId: currentContext().tenantId, title: `集成调用失败待补偿：${config.provider_code}`,
      data: { provider: config.provider_code, action, requestId: compensation?.requestId },
    });
    return { ok: false, compensated: true, attempts, error: String(lastError?.message || lastError),
      requestId: compensation?.requestId };
  }

  // ---------------- OAuth 登录 ----------------

  private readonly states = new Map<string, { provider: string; expiresAt: number }>();

  /** 第一步：生成 state 并返回授权 URL（真实 URL 格式 + 模拟提示） */
  async oauthAuthorize(provider: string, dto: any) {
    const meta = PROVIDERS[provider];
    if (!meta || !meta.authorize) {
      throw new BizException(BizCode.PARAM_INVALID, `${provider} 不支持 OAuth 授权`);
    }
    const config = await this.configOf(provider, dto?.tenantId);
    const state = String(dto?.state || randomUUID().replace(/-/g, ''));
    this.states.set(state, { provider, expiresAt: Date.now() + 5 * 60 * 1000 });
    const appId = String(config.appId || 'demo_appid');
    const redirectUri = String(dto.redirectUri || process.env.OAUTH_REDIRECT_URI || 'http://localhost:5173/oauth/callback');
    const authorizeUrl = meta.authorize(appId, redirectUri, state, config.extra);
    await this.writeLog({ provider, direction: 'OUT', eventType: 'OAUTH_AUTHORIZE',
      payload: { state, redirectUri }, mock: config.mock });
    if (config.mock) {
      return { configured: false, mock: true, authorizeUrl, state,
        message: `${meta.name} 未配置 AppId/Secret（请设置 ${config.secret || '对应环境变量'}），当前为模拟授权模式，可直接用 code 调用 callback` };
    }
    return { configured: true, mock: false, authorizeUrl, state };
  }

  /** 第二步：验签 → 取 userinfo → 绑定/新建用户 → 签发与本地登录一致的 JWT */
  async oauthCallback(dto: any) {
    const provider = String(dto.provider || '').toLowerCase();
    const meta = PROVIDERS[provider];
    if (!meta) throw new BizException(BizCode.PARAM_INVALID, `不支持的 OAuth provider：${provider}`);
    const config = await this.configOf(provider, dto.tenantId);

    // state 防 CSRF：已签发的 state 必须在有效期内；模拟模式放宽以便本地跑通
    const stateInfo = this.states.get(String(dto.state || ''));
    if (!config.mock && stateInfo && stateInfo.expiresAt < Date.now()) {
      throw new BizException(BizCode.UNAUTHORIZED, '授权 state 已过期，请重新发起授权');
    }
    if (config.mock && stateInfo && stateInfo.provider !== provider) {
      throw new BizException(BizCode.UNAUTHORIZED, '授权 state 与 provider 不匹配');
    }
    if (stateInfo) this.states.delete(String(dto.state));

    // 回调验签（raw body 由调用方以 canonical 形式传入，模拟模式直接通过）
    const verify = this.verify(config.secret, this.canonical(dto), dto.signature || dto.sign);
    if (!verify.ok) throw new BizException(BizCode.UNAUTHORIZED, '回调签名校验失败');

    const userInfo = meta.mockUser ? meta.mockUser(String(dto.code || randomUUID())) : { openid: hashOf(dto.code || '').slice(0, 16) };
    const openid = String(dto.openid || userInfo.openid || '');
    if (!openid) throw new BizException(BizCode.PARAM_INVALID, '未能获取第三方用户标识');

    const tenantId = Number(dto.tenantId || 1);
    let binding: any[] = await this.dataSource.query(
      `SELECT * FROM oauth_binding WHERE tenant_id=? AND provider=? AND openid=? AND is_deleted=0`,
      [tenantId, provider, openid]);
    let userId: number;
    let username: string;
    if (binding[0]) {
      userId = Number(binding[0].user_id);
      const u: any[] = await this.dataSource.query(`SELECT username, dept_id, org_id FROM sys_user WHERE id=?`, [userId]);
      username = u[0]?.username || `oauth_${openid.slice(0, 10)}`;
      await this.dataSource.query(`UPDATE oauth_binding SET last_login_at=NOW(3) WHERE id=?`, [binding[0].id]);
    } else {
      username = `${provider}_${openid.slice(-10)}`;
      const exist: any[] = await this.dataSource.query(
        `SELECT id, username FROM sys_user WHERE tenant_id=? AND username=? AND is_deleted=0`, [tenantId, username]);
      if (exist[0]) {
        userId = Number(exist[0].id);
        username = exist[0].username;
      } else {
        const password = await bcrypt.hash(randomUUID(), 10);
        const res: any = await this.dataSource.query(
          `INSERT INTO sys_user (tenant_id, username, password, real_name, phone, email, status)
           VALUES (?,?,?,?,?,?,1)`,
          [tenantId, username, password, String(userInfo.name || username).slice(0, 64),
            userInfo.phone || null, userInfo.email || null]);
        userId = Number(res.insertId);
      }
      await this.dataSource.query(
        `INSERT INTO oauth_binding (tenant_id, provider, openid, union_id, user_id, nickname, avatar, extra_json)
         VALUES (?,?,?,?,?,?,?,?)
         ON DUPLICATE KEY UPDATE user_id=VALUES(user_id), last_login_at=NOW(3)`,
        [tenantId, provider, openid, userInfo.userid || null, userId,
          userInfo.name || null, userInfo.avatar || null, JSON.stringify(userInfo)]);
    }

    // 权限与角色查询与本地登录保持一致
    const perms: any[] = await this.dataSource.query(
      `SELECT DISTINCT p.code FROM sys_user_role ur
        JOIN sys_role_permission rp ON rp.role_id=ur.role_id
        JOIN sys_permission p ON p.id=rp.permission_id AND p.is_deleted=0
       WHERE ur.user_id=? AND ur.tenant_id=?`, [userId, tenantId]);
    const roles: any[] = await this.dataSource.query(
      `SELECT r.code, r.data_scope FROM sys_user_role ur JOIN sys_role r ON r.id=ur.role_id
        WHERE ur.user_id=? AND ur.tenant_id=?`, [userId, tenantId]);
    const rank: Record<string, number> = { SELF: 1, DEPT: 2, ORG: 3, ALL: 4 };
    const dataScope = roles.reduce((best, r) => (rank[r.data_scope] || 1) > (rank[best] || 1) ? r.data_scope : best, 'SELF');
    const userRows: any[] = await this.dataSource.query(
      `SELECT username, dept_id, org_id FROM sys_user WHERE id=?`, [userId]);
    const token = await this.jwt.signAsync({
      sub: userId, tenantId, username: userRows[0]?.username || username,
      perms: perms.map((p) => p.code),
      deptId: Number(userRows[0]?.dept_id || 0), orgId: Number(userRows[0]?.org_id || 0),
      dataScope, roles: roles.map((r) => r.code),
    }, { secret: JWT_SECRET, expiresIn: JWT_EXPIRES });

    await this.dataSource.query(`UPDATE sys_user SET last_login_at=NOW(3) WHERE id=?`, [userId]);
    await this.audit.write('LOGIN', 'OAUTH', userId, provider, `第三方登录：${provider}/${openid}`);
    await this.writeLog({ provider, direction: 'IN', eventType: 'OAUTH_CALLBACK', requestId: dto.requestId,
      payload: { code: dto.code, state: dto.state }, response: { userId, mock: verify.mock },
      status: 'SUCCESS', mock: verify.mock, bizType: 'USER', bizId: userId });
    return { token, userInfo: { id: userId, username: userRows[0]?.username || username,
      realName: userInfo.name || null, tenantId, roles: roles.map((r) => r.code),
      permissions: perms.map((p) => p.code), provider, mock: verify.mock } };
  }

  // ---------------- 业务回调（幂等 + 验签 + 驱动业务） ----------------

  /** 统一回调入口：幂等检查 → 验签 → 业务处理 → 日志 */
  private async handleCallback(provider: string, eventType: string, body: any, handler: (body: any) => Promise<any>) {
    const requestId = String(body.requestId || body.request_id || body.outTradeNo || body.invoiceNo || body.externalId || '');
    const dup = await this.idempotent(provider, requestId);
    if (dup) return { duplicate: true, requestId, result: this.parseJson(dup.response_json), mock: !!dup.mock };
    const config = await this.configOf(provider);
    const verify = this.verify(config.secret, this.canonical(body), body.signature || body.sign);
    if (!verify.ok) throw new BizException(BizCode.UNAUTHORIZED, '回调签名校验失败');
    const result = await handler(body);
    await this.writeLog({ provider, direction: 'IN', eventType, requestId,
      payload: body, response: result, status: 'SUCCESS', mock: verify.mock,
      bizType: result?.bizType, bizId: result?.bizId });
    this.events.emit('realtime.integration', {
      tenantId: currentContext().tenantId, title: `${provider} 回调已处理`,
      data: { provider, eventType, requestId, mock: verify.mock },
    });
    return { duplicate: false, requestId, result, mock: verify.mock };
  }

  /** 支付回调：回写收款单（payment）状态 */
  async paymentCallback(body: any) {
    return this.handleCallback('payment', 'PAY_NOTIFY', body, async (b) => {
      const ctx = currentContext();
      const payNo = String(b.outTradeNo || b.payNo || b.paymentNo || '');
      const rows: any[] = await this.dataSource.query(
        `SELECT * FROM payment WHERE tenant_id=? AND (pay_no=? OR id=?) LIMIT 1`,
        [ctx.tenantId, payNo, Number(b.paymentId || 0)]);
      const status = Number(b.status === 'SUCCESS' || b.status === 'PAID' || b.tradeStatus === 'SUCCESS' ? 1 : 2);
      if (!rows[0]) return { updated: false, message: '未找到对应收款单', bizType: 'PAYMENT' };
      await this.dataSource.query(`UPDATE payment SET status=?, remark=CONCAT(IFNULL(remark,''),' [回调]') WHERE id=? AND tenant_id=?`,
        [status, rows[0].id, ctx.tenantId]);
      await this.audit.write(status === 1 ? 'AUDIT' : 'VOID', 'PAYMENT', Number(rows[0].id), rows[0].pay_no,
        `支付回调：${b.channel || 'wechat'} 金额 ${b.amount || rows[0].amount}`);
      return { updated: true, paymentId: Number(rows[0].id), payNo: rows[0].pay_no, status, bizType: 'PAYMENT', bizId: Number(rows[0].id) };
    });
  }

  /** 物流回调：回写出货/销售单的发货状态 */
  async logisticsCallback(body: any) {
    return this.handleCallback('logistics', 'LOGISTICS_NOTIFY', body, async (b) => {
      const ctx = currentContext();
      const orderNo = String(b.orderNo || b.outOrderNo || '');
      const rows: any[] = await this.dataSource.query(
        `SELECT * FROM sale_order WHERE tenant_id=? AND (order_no=? OR id=?) LIMIT 1`,
        [ctx.tenantId, orderNo, Number(b.orderId || 0)]);
      if (!rows[0]) return { updated: false, message: '未找到对应销售单', bizType: 'SALE_ORDER' };
      const shipped = String(b.status || '').toUpperCase() === 'DELIVERED' || Number(b.status) === 4;
      await this.dataSource.query(
        `UPDATE sale_order SET ship_status=?, status=CASE WHEN ?=1 THEN 4 ELSE status END,
          remark=CONCAT(IFNULL(remark,''),' [物流] ') WHERE id=? AND tenant_id=?`,
        [shipped ? 2 : 1, shipped ? 1 : 0, rows[0].id, ctx.tenantId]);
      await this.audit.write('AUDIT', 'SALE_ORDER', Number(rows[0].id), rows[0].order_no,
        `物流回调：${b.carrier || 'SF'} 运单 ${b.trackingNo || ''}`);
      return { updated: true, orderId: Number(rows[0].id), orderNo: rows[0].order_no,
        trackingNo: b.trackingNo || null, bizType: 'SALE_ORDER', bizId: Number(rows[0].id) };
    });
  }

  /** 发票回调：回写 fin_invoice（已开/已红冲） */
  async einvoiceCallback(body: any) {
    return this.handleCallback('einvoice', 'INVOICE_NOTIFY', body, async (b) => {
      const ctx = currentContext();
      const invoiceNo = String(b.invoiceNo || '');
      if (!invoiceNo) return { updated: false, message: '缺少发票号码', bizType: 'EINVOICE' };
      const rows: any[] = await this.dataSource.query(
        `SELECT * FROM fin_invoice WHERE tenant_id=? AND invoice_no=?`, [ctx.tenantId, invoiceNo]);
      const status = String(b.invoiceStatus || b.status || 'ISSUED').toUpperCase() === 'RED' ? 3 : 1;
      if (rows[0]) {
        await this.dataSource.query(
          `UPDATE fin_invoice SET status=?, file_url=COALESCE(?,file_url), invoice_date=COALESCE(?,invoice_date) WHERE id=?`,
          [status, b.fileUrl || null, b.invoiceDate || null, rows[0].id]);
        return { updated: true, invoiceId: Number(rows[0].id), invoiceNo, status, bizType: 'EINVOICE', bizId: Number(rows[0].id) };
      }
      const res: any = await this.dataSource.query(
        `INSERT INTO fin_invoice (tenant_id, invoice_no, invoice_type, biz_type, amount, tax_amount, total_amount, invoice_date, status, file_url)
         VALUES (?,?,?,?,?,?,?,?,?,?)`,
        [ctx.tenantId, invoiceNo, b.invoiceType || '1', b.bizType || '', Number(b.amount || 0),
          Number(b.taxAmount || 0), Number(b.totalAmount || 0), b.invoiceDate || null, status, b.fileUrl || null]);
      return { updated: true, created: true, invoiceId: res.insertId, invoiceNo, status, bizType: 'EINVOICE', bizId: res.insertId };
    });
  }

  /** 银行回调：按银行账号回写资金账户余额 */
  async bankCallback(body: any) {
    return this.handleCallback('bank', 'BANK_NOTIFY', body, async (b) => {
      const ctx = currentContext();
      const accountCode = String(b.bankAccount || b.accountCode || '');
      const amount = Number(b.amount || 0);
      const direction = Number(b.direction || 1);
      const rows: any[] = await this.dataSource.query(
        `SELECT * FROM account WHERE tenant_id=? AND code=? AND is_deleted=0`, [ctx.tenantId, accountCode]);
      if (!rows[0]) return { updated: false, message: '未找到对应资金账户', bizType: 'BANK' };
      const delta = direction === 1 ? amount : -amount;
      await this.dataSource.query(`UPDATE account SET balance=balance+? WHERE id=? AND tenant_id=?`,
        [delta, rows[0].id, ctx.tenantId]);
      await this.audit.write('AUDIT', 'BANK', Number(rows[0].id), accountCode,
        `银行流水回调：${b.externalId || ''} 金额 ${delta}`);
      return { updated: true, accountId: Number(rows[0].id), balanceDelta: delta,
        bizType: 'BANK', bizId: Number(rows[0].id) };
    });
  }

  // ---------------- 主动接口 ----------------

  /** 节假日：缓存优先 → 外部 provider → 内置数据兜底 */
  async getHolidays(year: number) {
    const ctx = currentContext();
    const y = Number(year || new Date().getFullYear());
    const cached: any[] = await this.dataSource.query(
      `SELECT holiday_date, holiday_name, day_type FROM holiday_cache WHERE tenant_id=? AND year=? AND is_deleted=0
        ORDER BY holiday_date`, [ctx.tenantId, y]);
    if (cached.length) {
      return { year: y, source: 'CACHE', mock: false,
        holidays: cached.filter((r) => r.day_type === 'HOLIDAY'),
        workdays: cached.filter((r) => r.day_type === 'WORKDAY') };
    }
    let source = 'BUILTIN';
    let mock = true;
    let data = BUILTIN_HOLIDAYS[y] || { holidays: [], workdays: [] };
    const config = await this.configOf('holiday_api');
    if (!config.mock && config.apiBase) {
      try {
        const controller = new AbortController();
        const timer = setTimeout(() => controller.abort(), config.timeoutSec * 1000);
        const resp = await fetch(`${String(config.apiBase).replace(/\/$/, '')}/holidays?year=${y}`, {
          headers: { Authorization: `Bearer ${config.secret}` }, signal: controller.signal,
        });
        clearTimeout(timer);
        if (resp.ok) {
          const json: any = await resp.json();
          if (Array.isArray(json?.holidays)) { data = json; source = 'EXTERNAL'; mock = false; }
        }
      } catch {
        source = 'BUILTIN'; mock = true;
      }
    }
    const all = [...(data.holidays || []), ...(data.workdays || [])];
    for (const item of all) {
      await this.dataSource.query(
        `INSERT IGNORE INTO holiday_cache (tenant_id, year, holiday_date, holiday_name, day_type, source)
         VALUES (?,?,?,?,?,?)`,
        [ctx.tenantId, y, item.date, item.name || '', item.type || 'HOLIDAY', source],
      ).catch(() => undefined);
    }
    await this.writeLog({ provider: 'holiday_api', direction: 'OUT', eventType: 'HOLIDAY_QUERY',
      payload: { year: y }, response: { source, count: all.length }, mock,
      status: 'SUCCESS' });
    return { year: y, source, mock, holidays: data.holidays || [], workdays: data.workdays || [] };
  }

  /** 主动同步：库存同步 / 订单拉取等模拟，统一走重试与日志 */
  async sync(provider: string, dto: any) {
    const meta = PROVIDERS[provider];
    if (!meta) throw new BizException(BizCode.PARAM_INVALID, `不支持的 provider：${provider}`);
    const config = await this.configOf(provider);
    const action = String(dto.action || 'stock');
    return this.callWithRetry(config, `SYNC_${action.toUpperCase()}`, dto, async () => {
      if (action === 'stock') {
        const rows: any[] = await this.dataSource.query(
          `SELECT COUNT(*) c FROM product WHERE tenant_id=? AND is_deleted=0`, [currentContext().tenantId]);
        return { action, synced: Number(rows[0]?.c || 0), mock: true, message: '模拟库存同步完成' };
      }
      if (action === 'order') {
        return { action, orders: [
          { orderNo: `MOCK_${Date.now()}`, amount: 100, status: 'CREATED' },
        ], mock: true, message: '模拟订单拉取完成' };
      }
      return { action, mock: true, message: `模拟 ${meta.name} 数据同步完成` };
    });
  }
}

/** 配置 / 回调 / 节假日 / 同步接口 */
@Controller()
class IntegrationController {
  constructor(private readonly service: IntegrationService) {}

  @Get('api/v1/integrations') @RequirePerm('integration:config:view')
  list() { return this.service.listConfigs(); }

  @Post('api/v1/integrations') @RequirePerm('integration:config:edit')
  save(@Body() dto: any) { return this.service.saveConfig(dto); }

  @Get('api/v1/integrations/logs') @RequirePerm('integration:config:view')
  logs(@Query() q: any) { return this.service.listLogs(q); }

  @Get('api/v1/integrations/holidays')
  holidays(@Query('year') year: string) { return this.service.getHolidays(Number(year || new Date().getFullYear())); }

  @Post('api/v1/integrations/:provider/sync') @RequirePerm('integration:config:edit')
  sync(@Param('provider') provider: string, @Body() dto: any) { return this.service.sync(provider.toLowerCase(), dto || {}); }

  @Post('api/v1/callback/payment') @Public()
  payment(@Body() dto: any) { return this.service.paymentCallback(dto || {}); }

  @Post('api/v1/callback/logistics') @Public()
  logistics(@Body() dto: any) { return this.service.logisticsCallback(dto || {}); }

  @Post('api/v1/callback/einvoice') @Public()
  einvoice(@Body() dto: any) { return this.service.einvoiceCallback(dto || {}); }

  @Post('api/v1/callback/bank') @Public()
  bank(@Body() dto: any) { return this.service.bankCallback(dto || {}); }
}

/** OAuth 登录接口（挂在 auth 路径下，但实现放在集成模块内复用 Adapter） */
@Controller()
class OAuthController {
  constructor(private readonly service: IntegrationService) {}

  // 注意：callback 必须声明在 :provider 之前，否则会被动态段抢先匹配
  @Post('api/v1/auth/oauth/callback') @Public()
  callback(@Body() dto: any) { return this.service.oauthCallback(dto || {}); }

  @Post('api/v1/auth/oauth/:provider') @Public()
  authorize(@Param('provider') provider: string, @Body() dto: any) {
    return this.service.oauthAuthorize(provider.toLowerCase(), dto || {});
  }
}

@Module({
  imports: [JwtModule.register({ secret: process.env.JWT_SECRET || 'erp-dev-secret' })],
  controllers: [IntegrationController, OAuthController],
  providers: [IntegrationService, AuditService],
  exports: [IntegrationService],
})
export class IntegrationsModule {}
