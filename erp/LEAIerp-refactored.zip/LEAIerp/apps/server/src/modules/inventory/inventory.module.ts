/**
 * 库存仓储模块：产品 / SKU / 仓库 / 库存余额 / 流水 / 预警。
 * 说明：库存写操作全部收敛到 StockService，Controller 只做参数校验与权限声明。
 */
import { Body, Controller, Get, Injectable, Module, Param, ParseIntPipe, Post, Query } from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';
import { DataSource } from 'typeorm';
import { DataScope, RequirePerm, normalizePage, pageResult, currentContext, BizException, buildDataScopeWhere, appendDataScope } from '../../common/common';
import { BizCode, ProductType } from '@erp/shared';
import { StockService } from './stock.service';
import { AuditService } from '../../common/audit.service';

@Injectable()
export class InventoryService {
  constructor(
    @InjectDataSource() private readonly dataSource: DataSource,
    private readonly stock: StockService,
    private readonly audit: AuditService,
  ) {}

  async listProducts(query: any) {
    const ctx = currentContext();
    const { page, pageSize, skip } = normalizePage(query.page, query.pageSize);
    const where: string[] = ['p.tenant_id = ?', 'p.is_deleted = 0'];
    const args: any[] = [ctx.tenantId];
    if (query.keyword) { where.push('(p.name LIKE ? OR p.code LIKE ? OR p.barcode LIKE ?)'); args.push(`%${query.keyword}%`, `%${query.keyword}%`, `%${query.keyword}%`); }
    if (query.categoryId) { where.push('p.category_id = ?'); args.push(query.categoryId); }
    if (query.type) { where.push('p.type = ?'); args.push(query.type); }
    if (query.warehouseId) { where.push('EXISTS (SELECT 1 FROM stock_balance b WHERE b.product_id=p.id AND b.warehouse_id=? AND b.tenant_id=p.tenant_id)'); args.push(query.warehouseId); }
    appendDataScope(where, args, buildDataScopeWhere('ORG', ctx, 'p', { creatorCol: 'created_by' }));

    const list = await this.dataSource.query(
      `SELECT p.*, c.name AS category_name, br.name AS brand_name, u.name AS unit_name,
              IFNULL((SELECT SUM(b.qty_on_hand - b.qty_occupied) FROM stock_balance b
                       WHERE b.tenant_id = p.tenant_id AND b.product_id = p.id), 0) AS total_qty
         FROM product p
         LEFT JOIN category c ON c.id = p.category_id
         LEFT JOIN brand br ON br.id = p.brand_id
         LEFT JOIN unit u ON u.id = p.unit_id
        WHERE ${where.join(' AND ')} ORDER BY p.id DESC LIMIT ? OFFSET ?`,
      [...args, pageSize, skip],
    );
    const totalRows = await this.dataSource.query(`SELECT COUNT(*) AS c FROM product p WHERE ${where.join(' AND ')}`, args);
    // 附带规格行，前端展开即可看到多规格独立成本/价格
    for (const row of list) {
      if (Number(row.type) === ProductType.VARIANT) {
        row.variants = await this.dataSource.query(
          `SELECT v.id, v.sku_code, v.attributes, v.barcode, v.cost, v.price,
                  IFNULL((SELECT SUM(b.qty_on_hand - b.qty_occupied) FROM stock_balance b
                           WHERE b.tenant_id = v.tenant_id AND b.variant_id = v.id), 0) AS qty
             FROM product_variant v WHERE v.tenant_id=? AND v.product_id=? AND v.is_deleted=0`,
          [ctx.tenantId, row.id],
        );
      }
    }
    return pageResult(list, Number(totalRows[0]?.c || 0), page, pageSize);
  }

  async saveProduct(dto: any, id?: number) {
    const ctx = currentContext();
    if (id) {
      // 取变更前快照：成本/售价属于敏感字段，需单独留痕
      const beforeRows: any[] = await this.dataSource.query(
        `SELECT name, code, cost, price, category_id, brand_id, unit_id, remark FROM product WHERE id=? AND tenant_id=?`,
        [id, ctx.tenantId]);
      const before = beforeRows[0] || null;
      await this.dataSource.query(
        `UPDATE product SET name=?, code=?, barcode=?, category_id=?, brand_id=?, unit_id=?, cost=?, price=?, type=?, tracking=?, is_active=?, image=?, remark=?, updated_by=?
          WHERE id=? AND tenant_id=?`,
        [dto.name, dto.code, dto.barcode || null, dto.categoryId || null, dto.brandId || null, dto.unitId || null,
          dto.cost ?? 0, dto.price ?? 0, dto.type ?? 1, dto.tracking ?? 0, dto.isActive ?? 1, dto.image || null,
          dto.remark || null, ctx.userId, id, ctx.tenantId],
      );
      await this.audit.writeDiff('UPDATE', 'PRODUCT', id, dto.code, before,
        { name: dto.name, code: dto.code, cost: dto.cost ?? 0, price: dto.price ?? 0,
          category_id: dto.categoryId || null, remark: dto.remark || null },
        ['cost', 'price']);
      return { id };
    }
    const dup: any[] = await this.dataSource.query(`SELECT id FROM product WHERE tenant_id=? AND code=? AND is_deleted=0`, [ctx.tenantId, dto.code]);
    if (dup.length) throw new BizException(BizCode.PARAM_INVALID, `产品编码已存在：${dto.code}`);
    const res: any = await this.dataSource.query(
      `INSERT INTO product (tenant_id, name, code, barcode, category_id, brand_id, unit_id, cost, price, type, tracking, is_active, image, remark, created_by)
       VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
      [ctx.tenantId, dto.name, dto.code, dto.barcode || null, dto.categoryId || null, dto.brandId || null, dto.unitId || null,
        dto.cost ?? 0, dto.price ?? 0, dto.type ?? 1, dto.tracking ?? 0, dto.isActive ?? 1, dto.image || null, dto.remark || null, ctx.userId],
    );
    await this.audit.writeDiff('CREATE', 'PRODUCT', res.insertId, dto.code, null,
      { name: dto.name, code: dto.code, cost: dto.cost ?? 0, price: dto.price ?? 0 },
      ['cost', 'price']);
    return { id: res.insertId };
  }

  /** 保存多规格：整批覆盖该产品的 SKU 集合 */
  async saveVariants(productId: number, variants: any[]) {
    const ctx = currentContext();
    if (!Array.isArray(variants)) return;
    for (const v of variants) {
      if (v.id) {
        await this.dataSource.query(
          `UPDATE product_variant SET sku_code=?, attributes=?, barcode=?, cost=?, price=? WHERE id=? AND tenant_id=?`,
          [v.skuCode, JSON.stringify(v.attributes || {}), v.barcode || null, v.cost ?? 0, v.price ?? 0, v.id, ctx.tenantId],
        );
      } else {
        await this.dataSource.query(
          `INSERT INTO product_variant (tenant_id, product_id, sku_code, attributes, barcode, cost, price)
           VALUES (?,?,?,?,?,?,?)`,
          [ctx.tenantId, productId, v.skuCode, JSON.stringify(v.attributes || {}), v.barcode || null, v.cost ?? 0, v.price ?? 0],
        );
      }
    }
    await this.audit.write('UPDATE', 'PRODUCT_VARIANT', productId, String(productId), `保存 ${variants.length} 个规格`);
  }

  /** 作废产品：只软删，历史单据与流水不受影响 */
  async voidProduct(id: number) {
    const ctx = currentContext();
    await this.dataSource.query(`UPDATE product SET is_deleted=1, is_active=0, updated_by=? WHERE id=? AND tenant_id=?`, [ctx.userId, id, ctx.tenantId]);
    await this.audit.write('VOID', 'PRODUCT', id, String(id), '产品作废（软删除）');
    return { id };
  }

  listWarehouses() {
    return this.dataSource.query(`SELECT * FROM warehouse WHERE tenant_id=? AND is_deleted=0 ORDER BY is_default DESC, id`, [currentContext().tenantId]);
  }

  listCategories() {
    return this.dataSource.query(`SELECT * FROM category WHERE tenant_id=? AND is_deleted=0 ORDER BY id`, [currentContext().tenantId]);
  }
}

@Controller('api/v1/inventory')
class InventoryController {
  constructor(private readonly service: InventoryService, private readonly stock: StockService) {}

  @Get('products')
  @RequirePerm('inventory:stock:view')
  @DataScope('ORG')
  products(@Query() query: any) {
    return this.service.listProducts(query);
  }

  @Post('products')
  @RequirePerm('inventory:product:edit')
  saveProduct(@Body() dto: any) {
    return this.service.saveProduct(dto);
  }

  @Post('products/:id')
  @RequirePerm('inventory:product:edit')
  updateProduct(@Param('id', ParseIntPipe) id: number, @Body() dto: any) {
    return this.service.saveProduct(dto, id);
  }

  @Post('products/:id/variants')
  @RequirePerm('inventory:product:edit')
  saveVariants(@Param('id', ParseIntPipe) id: number, @Body('variants') variants: any[]) {
    return this.service.saveVariants(id, variants);
  }

  @Post('products/:id/void')
  @RequirePerm('inventory:product:edit')
  voidProduct(@Param('id', ParseIntPipe) id: number) {
    return this.service.voidProduct(id);
  }

  @Get('warehouses')
  warehouses() {
    return this.service.listWarehouses();
  }

  @Get('categories')
  categories() {
    return this.service.listCategories();
  }

  @Get('balance')
  @RequirePerm('inventory:stock:view')
  balance(@Query() query: any) {
    return this.stock.queryBalance(query);
  }

  @Get('negative-stocks')
  @RequirePerm('inventory:stock:view')
  async negativeStocks() {
    const rows = await this.stock.queryBalance({ negativeOnly: true });
    return rows.map((row: any) => ({
      id: row.id, productName: row.product_name, productCode: row.product_code, warehouseName: row.warehouse_name,
      qtyOnHand: row.qty_on_hand, qtyOccupied: row.qty_occupied, available: row.qty_available,
    }));
  }

  @Get('ledger')
  @RequirePerm('inventory:stock:view')
  ledger(@Query() query: any) {
    return this.stock.queryLedger(query);
  }

  @Get('alerts')
  @RequirePerm('inventory:stock:view')
  alerts() {
    return this.stock.lowStockAlerts();
  }
}

@Module({
  controllers: [InventoryController],
  providers: [InventoryService, StockService, AuditService],
  exports: [StockService, InventoryService],
})
export class InventoryModule {}
