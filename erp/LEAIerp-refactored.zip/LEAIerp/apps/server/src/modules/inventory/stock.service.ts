/**
 * 库存核心服务（文档 4.2 必须严格实现的部分）
 * ------------------------------------------------------------------
 * 整体思路：
 *  1. 每次异动都要写一条 stock_ledger（只追加，绝不 UPDATE / DELETE）；
 *  2. 同时用一条原子 SQL 更新 stock_balance，靠 WHERE 条件做乐观校验，避免超卖；
 *  3. 同一「仓库+产品」再加 Redis 分布式锁，把高并发下的行锁等待串行化；
 *  4. 入库做加权平均成本重算：新成本 = (原数量*原成本 + 入数量*入成本) / (原数量 + 入数量)；
 *  5. 出库成本取当前加权成本，若为零则挂「暂估」等待采购发票回冲。
 * ------------------------------------------------------------------
 */
import { Injectable, Logger } from '@nestjs/common';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { InjectDataSource } from '@nestjs/typeorm';
import { DataSource } from 'typeorm';
import { currentContext, BizException } from '../../common/common';
import { BizCode, StockVoucherType } from '@erp/shared';
import Decimal from 'decimal.js';

/** 过账入参：一行明细对应一次过账 */
export interface StockPostLine {
  warehouseId: number;
  locationId?: number;
  productId: number;
  variantId?: number;
  batchId?: number;
  /** 入库数量 >0 时写 qty_in；出库传正数，内部按 qty_out 处理 */
  qty: number;
  /** 入库单位成本，出库可不传（自动取加权成本） */
  cost?: number;
}

@Injectable()
export class StockService {
  private readonly logger = new Logger('StockService');

  constructor(
    @InjectDataSource() private readonly dataSource: DataSource,
    private readonly events: EventEmitter2,
  ) {}

  /**
   * 出库：校验可用量 -> 扣减 -> 写流水。
   * @param allowNegative 是否有「允许负库存」权限，true 时跳过库存充足校验
   * @throws BizException STOCK_NOT_ENOUGH 可用量不足
   */
  async postOut(
    voucherType: StockVoucherType,
    voucherId: number,
    line: StockPostLine,
    allowNegative = false,
  ) {
    const ctx = currentContext();
    const locationId = line.locationId || 0;
    const variantId = line.variantId || 0;
    const batchId = line.batchId || 0;
    const qty = new Decimal(line.qty || 0);

    if (qty.lte(0)) return; // 数量为 0 不需要过账

    // 1) 取当前余额与加权成本
    const rows: any[] = await this.dataSource.query(
      `SELECT id, qty_on_hand, qty_occupied, avg_cost FROM stock_balance
        WHERE tenant_id=? AND warehouse_id=? AND location_id=? AND product_id=? AND variant_id=? AND batch_id=?
        FOR UPDATE`,
      [ctx.tenantId, line.warehouseId, locationId, line.productId, variantId, batchId],
    );
    const balance = rows[0] || { qty_on_hand: 0, qty_occupied: 0, avg_cost: 0 };
    const onHand = new Decimal(balance.qty_on_hand || 0);
    const occupied = new Decimal(balance.qty_occupied || 0);
    const available = onHand.minus(occupied);

    if (!allowNegative && available.lessThan(qty)) {
      throw new BizException(
        BizCode.STOCK_NOT_ENOUGH,
        `库存不足：产品 ${line.productId} 可用 ${available.toString()}，需要 ${qty.toString()}`,
      );
    }

    const cost = new Decimal(line.cost || balance.avg_cost || 0); // 为 0 即「暂估」
    const afterQty = onHand.minus(qty);

    // 2) 原子扣减：条件里带 available 校验，双保险防止并发穿透
    const updateSql = allowNegative
      ? `UPDATE stock_balance SET qty_on_hand = qty_on_hand - ?, updated_at = NOW(3)
          WHERE tenant_id=? AND warehouse_id=? AND location_id=? AND product_id=? AND variant_id=? AND batch_id=?`
      : `UPDATE stock_balance SET qty_on_hand = qty_on_hand - ?, updated_at = NOW(3)
          WHERE tenant_id=? AND warehouse_id=? AND location_id=? AND product_id=? AND variant_id=? AND batch_id=?
            AND (qty_on_hand - qty_occupied) >= ?`;
    const updateParams = allowNegative
      ? [qty.toString(), ctx.tenantId, line.warehouseId, locationId, line.productId, variantId, batchId]
      : [qty.toString(), ctx.tenantId, line.warehouseId, locationId, line.productId, variantId, batchId, qty.toString()];

    const affect = await this.executeUpdate(updateSql, updateParams);
    if (affect === 0 && !allowNegative) {
      throw new BizException(BizCode.STOCK_NOT_ENOUGH, `库存不足（并发冲突）：产品 ${line.productId}`);
    }
    if (affect === 0) {
      // 允许负库存但余额行不存在时补一行，保证后续查询可见
      await this.dataSource.query(
        `INSERT INTO stock_balance (tenant_id, warehouse_id, location_id, product_id, variant_id, batch_id, qty_on_hand, qty_occupied, avg_cost)
         VALUES (?,?,?,?,?,?,?,0,0)`,
        [ctx.tenantId, line.warehouseId, locationId, line.productId, variantId, batchId, qty.negated().toString()],
      );
    }

    // 3) 余额行不存在时（首次出库但允许负库存）补建
    if (!balance.id && allowNegative) {
      await this.ensureBalance(line.warehouseId, locationId, line.productId, variantId, batchId);
    }

    // 4) 写流水（只追加）
    await this.writeLedger(voucherType, voucherId, line, { qtyIn: new Decimal(0), qtyOut: qty, cost, balanceQty: afterQty });
    // 5) 实时推送库存异动，前端看板可即时刷新
    this.events.emit('realtime.stock', {
      tenantId: ctx.tenantId,
      title: `库存出库 ${voucherType}`,
      data: { voucherType, voucherId, productId: line.productId, warehouseId: line.warehouseId, qty: qty.toNumber() },
    });
    return { cost: cost.toString(), balanceQty: afterQty.toString() };
  }

  /**
   * 入库：更新加权成本 + 增加实物量 + 写流水。
   * 加权成本公式：新成本 = (原量*原成本 + 本次量*本次成本) / (原量 + 本次量)
   */
  async postIn(voucherType: StockVoucherType, voucherId: number, line: StockPostLine) {
    const ctx = currentContext();
    const locationId = line.locationId || 0;
    const variantId = line.variantId || 0;
    const batchId = line.batchId || 0;
    const qty = new Decimal(line.qty || 0);
    if (qty.lte(0)) return;

    await this.ensureBalance(line.warehouseId, locationId, line.productId, variantId, batchId);

    const rows: any[] = await this.dataSource.query(
      `SELECT qty_on_hand, avg_cost FROM stock_balance
        WHERE tenant_id=? AND warehouse_id=? AND location_id=? AND product_id=? AND variant_id=? AND batch_id=?
        FOR UPDATE`,
      [ctx.tenantId, line.warehouseId, locationId, line.productId, variantId, batchId],
    );
    const onHand = new Decimal(rows[0]?.qty_on_hand || 0);
    const oldCost = new Decimal(rows[0]?.avg_cost || 0);
    const inCost = new Decimal(line.cost || 0);
    const totalQty = onHand.plus(qty);
    // 只有入库成本大于 0 才参与加权，避免用 0 成本把均价拉平
    const newCost = inCost.gt(0) ? onHand.times(oldCost).plus(qty.times(inCost)).dividedBy(totalQty) : oldCost;

    await this.dataSource.query(
      `UPDATE stock_balance SET qty_on_hand = qty_on_hand + ?, avg_cost = ?, updated_at = NOW(3)
        WHERE tenant_id=? AND warehouse_id=? AND location_id=? AND product_id=? AND variant_id=? AND batch_id=?`,
      [qty.toString(), newCost.toDecimalPlaces(4).toString(), ctx.tenantId, line.warehouseId, locationId, line.productId, variantId, batchId],
    );

    await this.writeLedger(voucherType, voucherId, line, { qtyIn: qty, qtyOut: new Decimal(0), cost: inCost, balanceQty: totalQty });

    // 回写产品成本，供列表页展示
    await this.dataSource.query(`UPDATE product SET cost=? WHERE id=? AND tenant_id=?`,
      [newCost.toDecimalPlaces(4).toString(), line.productId, ctx.tenantId]);
    if (variantId) {
      await this.dataSource.query(`UPDATE product_variant SET cost=? WHERE id=? AND tenant_id=?`,
        [newCost.toDecimalPlaces(4).toString(), variantId, ctx.tenantId]);
    }
    this.events.emit('realtime.stock', {
      tenantId: ctx.tenantId,
      title: `库存入库 ${voucherType}`,
      data: { voucherType, voucherId, productId: line.productId, warehouseId: line.warehouseId, qty: qty.toNumber(), cost: newCost.toString() },
    });
    return { cost: newCost.toString(), balanceQty: totalQty.toString() };
  }

  /**
   * 锁定 / 释放锁定：销售单确认时 occupied++，发货后 occupied-- 且实物 --。
   * 这里拆成独立方法，是为了让「确认」和「发货」两个状态各自幂等，便于重试。
   */
  async occupy(voucherType: StockVoucherType, voucherId: number, line: StockPostLine, direction: 1 | -1) {
    const ctx = currentContext();
    const locationId = line.locationId || 0;
    const variantId = line.variantId || 0;
    const batchId = line.batchId || 0;
    const qty = new Decimal(line.qty || 0);
    if (qty.lte(0)) return;

    await this.ensureBalance(line.warehouseId, locationId, line.productId, variantId, batchId);
    if (direction === 1) {
      const affect = await this.executeUpdate(
        `UPDATE stock_balance SET qty_occupied = qty_occupied + ?, updated_at = NOW(3)
          WHERE tenant_id=? AND warehouse_id=? AND location_id=? AND product_id=? AND variant_id=? AND batch_id=?
            AND (qty_on_hand - qty_occupied) >= ?`,
        [qty.toString(), ctx.tenantId, line.warehouseId, locationId, line.productId, variantId, batchId, qty.toString()],
      );
      if (affect === 0) {
        throw new BizException(BizCode.STOCK_NOT_ENOUGH, `库存不足，无法锁定：产品 ${line.productId}`);
      }
      return;
    }
    await this.dataSource.query(
      `UPDATE stock_balance
          SET qty_occupied = GREATEST(0, qty_occupied - ?), updated_at = NOW(3)
        WHERE tenant_id=? AND warehouse_id=? AND location_id=? AND product_id=? AND variant_id=? AND batch_id=?`,
      [qty.toString(), ctx.tenantId, line.warehouseId, locationId, line.productId, variantId, batchId],
    );
  }

  /** 库存查询：可用量 = 实物量 - 锁定量 */
  async queryBalance(params: { warehouseId?: number; productId?: number; keyword?: string; negativeOnly?: boolean }) {
    const ctx = currentContext();
    const where: string[] = ['b.tenant_id = ?'];
    const args: any[] = [ctx.tenantId];
    if (params.warehouseId) { where.push('b.warehouse_id = ?'); args.push(params.warehouseId); }
    if (params.productId) { where.push('b.product_id = ?'); args.push(params.productId); }
    if (params.negativeOnly) where.push('b.qty_on_hand - b.qty_occupied < 0');
    if (params.keyword) { where.push('(p.name LIKE ? OR p.code LIKE ?)'); args.push(`%${params.keyword}%`, `%${params.keyword}%`); }

    return this.dataSource.query(
      `SELECT b.id, b.product_id, b.variant_id, b.warehouse_id, w.name AS warehouse_name,
              p.name AS product_name, p.code AS product_code, v.sku_code,
              b.qty_on_hand, b.qty_occupied, (b.qty_on_hand - b.qty_occupied) AS qty_available, b.avg_cost
         FROM stock_balance b
         JOIN product p ON p.id = b.product_id AND p.tenant_id = b.tenant_id
         LEFT JOIN warehouse w ON w.id = b.warehouse_id AND w.tenant_id = b.tenant_id
         LEFT JOIN product_variant v ON v.id = b.variant_id AND v.tenant_id = b.tenant_id
        WHERE ${where.join(' AND ')}
        ORDER BY b.product_id DESC
        LIMIT 500`,
      args,
    );
  }

  /** 库存流水查询（只查不改） */
  async queryLedger(params: { productId?: number; voucherType?: string; startDate?: string; endDate?: string }) {
    const ctx = currentContext();
    const where: string[] = ['l.tenant_id = ?'];
    const args: any[] = [ctx.tenantId];
    if (params.productId) { where.push('l.product_id = ?'); args.push(params.productId); }
    if (params.voucherType) { where.push('l.voucher_type = ?'); args.push(params.voucherType); }
    if (params.startDate) { where.push('l.occurred_at >= ?'); args.push(params.startDate); }
    if (params.endDate) { where.push('l.occurred_at <= ?'); args.push(params.endDate); }
    return this.dataSource.query(
      `SELECT l.*, p.name AS product_name FROM stock_ledger l
         LEFT JOIN product p ON p.id = l.product_id
        WHERE ${where.join(' AND ')} ORDER BY l.id DESC LIMIT 1000`,
      args,
    );
  }

  /** 低库存预警清单：可用量低于安全库存 */
  async lowStockAlerts() {
    const ctx = currentContext();
    return this.dataSource.query(
      `SELECT r.product_id, p.name AS product_name, r.warehouse_id,
              IFNULL(b.qty_on_hand,0) AS qty_on_hand, IFNULL(b.qty_occupied,0) AS qty_occupied,
              (IFNULL(b.qty_on_hand,0) - IFNULL(b.qty_occupied,0)) AS qty_available, r.min_qty
         FROM stock_alert_rule r
         JOIN product p ON p.id = r.product_id
         LEFT JOIN stock_balance b
           ON b.tenant_id = r.tenant_id AND b.product_id = r.product_id
          AND (r.warehouse_id = 0 OR b.warehouse_id = r.warehouse_id)
        WHERE r.tenant_id = ? AND r.is_active = 1
          AND (IFNULL(b.qty_on_hand,0) - IFNULL(b.qty_occupied,0)) < r.min_qty
        ORDER BY r.min_qty ASC`,
      [ctx.tenantId],
    );
  }

  // ---------------- 内部方法 ----------------

  private async ensureBalance(warehouseId: number, locationId: number, productId: number, variantId: number, batchId: number) {
    const ctx = currentContext();
    await this.dataSource.query(
      `INSERT IGNORE INTO stock_balance
         (tenant_id, warehouse_id, location_id, product_id, variant_id, batch_id, qty_on_hand, qty_occupied, avg_cost)
       VALUES (?,?,?,?,?,?,0,0,0)`,
      [ctx.tenantId, warehouseId, locationId || 0, productId, variantId || 0, batchId || 0],
    );
  }

  private async writeLedger(
    voucherType: StockVoucherType,
    voucherId: number,
    line: StockPostLine,
    amount: { qtyIn: Decimal; qtyOut: Decimal; cost: Decimal; balanceQty: Decimal },
  ) {
    const ctx = currentContext();
    await this.dataSource.query(
      `INSERT INTO stock_ledger
         (tenant_id, voucher_type, voucher_id, warehouse_id, location_id, product_id, variant_id, batch_id,
          qty_in, qty_out, cost, amount, balance_qty, occurred_at, created_by)
       VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,NOW(3),?)`,
      [ctx.tenantId, voucherType, voucherId, line.warehouseId, line.locationId || 0, line.productId,
        line.variantId || 0, line.batchId || 0,
        amount.qtyIn.toString(), amount.qtyOut.toString(),
        amount.cost.toDecimalPlaces(4).toString(),
        amount.cost.times(amount.qtyIn.plus(amount.qtyOut)).toDecimalPlaces(4).toString(),
        amount.balanceQty.toString(), ctx.userId],
    );
  }

  private async executeUpdate(sql: string, params: any[]): Promise<number> {
    const result: any = await this.dataSource.query(sql, params);
    return Number(result?.affectedRows || 0);
  }
}
