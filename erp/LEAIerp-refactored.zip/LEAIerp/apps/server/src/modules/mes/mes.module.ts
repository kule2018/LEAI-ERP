/**
 * MES 生产制造深化（文档 17.4）：工艺路线 / MRP 运算 / 生产工单 / 报工 / 质检 / 设备
 * MRP 净需求公式（文档 4.5）：净需求 = 需求 + 安全库存 - 可用 - 在途 + 已分配
 *   - 需求来源：已确认销售单未完工工单对应 BOM 展开（简化：取工单数量）
 *   - 净需求 > 0 时：有 BOM 的下属物料建议采购，否则建议生产
 */
import { Body, Controller, Get, Injectable, Module, Param, ParseIntPipe, Post, Query } from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';
import { DataSource } from 'typeorm';
import { BizCode, BizException, RequirePerm, currentContext } from '../../common/common';
import { AuditService } from '../../common/audit.service';

function genNo(prefix: string): string {
  return `${prefix}${Date.now().toString().slice(-10)}`;
}

@Injectable()
export class MesService {
  constructor(@InjectDataSource() private readonly dataSource: DataSource, private readonly audit: AuditService) {}

  // ---------------- 工艺路线 ----------------

  listRoutings(productId?: number) {
    const ctx = currentContext();
    const args: any[] = [ctx.tenantId];
    let where = 'tenant_id=? AND is_deleted=0';
    if (productId) { where += ' AND product_id=?'; args.push(productId); }
    return this.dataSource.query(`SELECT * FROM mes_routing WHERE ${where} ORDER BY product_id, seq`, args);
  }

  saveRouting(dto: any) {
    const ctx = currentContext();
    return this.dataSource.query(
      `INSERT INTO mes_routing (tenant_id, product_id, version, seq, process_name, work_center, std_minutes) VALUES (?,?,?,?,?,?,?)`,
      [ctx.tenantId, dto.productId || dto.product_id, dto.version || 'V1', Number(dto.seq || 1),
        dto.processName || dto.process_name, dto.workCenter || dto.work_center || null, Number(dto.stdMinutes || dto.std_minutes || 0)])
      .then((res: any) => ({ id: res.insertId }));
  }

  // ---------------- MRP ----------------

  /**
   * 执行一次 MRP 运算：遍历未完工工单，按 BOM 展开子件算净需求，写入 mes_mrp_suggest。
   * @returns 运算批次号与建议条数
   */
  async runMrp(dto: any = {}) {
    const ctx = currentContext();
    const run: any = await this.dataSource.query(
      `INSERT INTO mes_mrp_run (tenant_id, run_no, run_at, source, status, created_by) VALUES (?,?,NOW(3),?,1,?)`,
      [ctx.tenantId, genNo('MRP'), dto.source || 'MANUAL', ctx.userId]);
    const runId = run.insertId;
    try {
      const demands: any[] = await this.dataSource.query(
        `SELECT w.product_id, SUM(w.qty - w.produced_qty) AS demand_qty
           FROM work_order w
          WHERE w.tenant_id=? AND w.is_deleted=0 AND w.status IN (0,1,2)
          GROUP BY w.product_id`, [ctx.tenantId]);
      let count = 0;
      for (const d of demands) {
        const demandQty = Number(d.demand_qty || 0);
        if (demandQty <= 0) continue;
        // 成品自身：有 BOM 则建议生产
        await this.insertSuggest(runId, d.product_id, demandQty, false);
        const items: any[] = await this.dataSource.query(
          `SELECT i.material_id, i.qty, i.loss_rate FROM bom_item i JOIN bom b ON b.id=i.bom_id
            WHERE b.tenant_id=? AND b.product_id=? AND b.is_active=1 AND i.is_deleted=0`, [ctx.tenantId, d.product_id]);
        for (const it of items) {
          const childDemand = demandQty * Number(it.qty) * (1 + Number(it.loss_rate || 0) / 100);
          await this.insertSuggest(runId, it.material_id, childDemand, true);
        }
        count += 1;
      }
      await this.dataSource.query(`UPDATE mes_mrp_run SET status=2 WHERE id=?`, [runId]);
      await this.audit.write('RUN', 'MES_MRP', runId, String(runId), `MRP 运算完成，涉及成品 ${count} 个`);
      return { runId, productCount: count };
    } catch (e: any) {
      await this.dataSource.query(`UPDATE mes_mrp_run SET status=3 WHERE id=?`, [runId]);
      throw e;
    }
  }

  /** 计算单品净需求并落库；isMaterial=true 表示子件，建议采购 */
  private async insertSuggest(runId: number, productId: number, demandQty: number, isMaterial: boolean) {
    const bal: any[] = await this.dataSource.query(
      `SELECT COALESCE(SUM(qty_on_hand),0) hand, COALESCE(SUM(qty_occupied),0) occupied
         FROM stock_balance WHERE tenant_id=? AND product_id=?`, [currentContext().tenantId, productId]);
    const available = Number(bal[0]?.hand || 0) - Number(bal[0]?.occupied || 0);
    const onWay: any[] = await this.dataSource.query(
      `SELECT COALESCE(SUM(l.qty - l.received_qty),0) v FROM purchase_order_line l JOIN purchase_order o ON o.id=l.order_id
        WHERE o.tenant_id=? AND o.is_deleted=0 AND o.status IN (1,2) AND l.product_id=?`, [currentContext().tenantId, productId]);
    const safety = 0; // 安全库存取自 stock_balance 预警配置时替换此处
    const net = Number(demandQty.toFixed(3)) + safety - available - Number(onWay[0]?.v || 0);
    if (net <= 0) return;
    await this.dataSource.query(
      `INSERT INTO mes_mrp_suggest (tenant_id, run_id, product_id, demand_qty, available_qty, on_way_qty, safety_qty, net_qty, suggest_type)
       VALUES (?,?,?,?,?,?,?,?,?)`,
      [currentContext().tenantId, runId, productId, Number(demandQty.toFixed(3)), available, Number(onWay[0]?.v || 0), safety,
        Number(net.toFixed(3)), isMaterial ? 'PURCHASE' : 'PRODUCE']);
  }

  suggestList(runId: number) {
    return this.dataSource.query(
      `SELECT s.*, p.name AS product_name FROM mes_mrp_suggest s LEFT JOIN product p ON p.id=s.product_id
        WHERE s.run_id=? AND s.is_deleted=0 ORDER BY s.net_qty DESC`, [runId]);
  }

  listRuns() {
    return this.dataSource.query(`SELECT * FROM mes_mrp_run WHERE tenant_id=? AND is_deleted=0 ORDER BY id DESC LIMIT 100`, [currentContext().tenantId]);
  }

  // ---------------- 生产工单 ----------------

  listWorkOrders() {
    return this.dataSource.query(
      `SELECT w.*, p.name AS product_name FROM work_order w LEFT JOIN product p ON p.id=w.product_id
        WHERE w.tenant_id=? AND w.is_deleted=0 ORDER BY w.id DESC LIMIT 200`, [currentContext().tenantId]);
  }

  createWorkOrder(dto: any) {
    const ctx = currentContext();
    return this.dataSource.query(
      `INSERT INTO work_order (tenant_id, order_no, product_id, bom_id, qty, plan_start, plan_end, status, created_by)
       VALUES (?,?,?,?,?,?,?,0,?)`,
      [ctx.tenantId, dto.orderNo || genNo('WO'), dto.productId || dto.product_id, dto.bomId || dto.bom_id || null,
        Number(dto.qty || 0), dto.planStart || dto.plan_start || null, dto.planEnd || dto.plan_end || null, ctx.userId])
      .then((res: any) => ({ id: res.insertId }));
  }

  // ---------------- 报工 ----------------

  listReports(workorderId: number) {
    return this.dataSource.query(`SELECT * FROM mes_report WHERE tenant_id=? AND workorder_id=? AND is_deleted=0 ORDER BY id DESC`,
      [currentContext().tenantId, workorderId]);
  }

  async addReport(dto: any) {
    const ctx = currentContext();
    const woId = Number(dto.workorderId || dto.workorder_id);
    const qty = Number(dto.reportQty || dto.report_qty || 0);
    const qualified = Number(dto.qualifiedQty ?? dto.qualified_qty ?? qty);
    const res: any = await this.dataSource.query(
      `INSERT INTO mes_report (tenant_id, workorder_id, process_name, report_qty, qualified_qty, work_minutes, worker, created_by)
       VALUES (?,?,?,?,?,?,?,?)`,
      [ctx.tenantId, woId, dto.processName || dto.process_name || null, qty, qualified,
        Number(dto.workMinutes || dto.work_minutes || 0), dto.worker || null, ctx.userId]);
    // 累计完工数量并推进工单状态：0计划 1下达 2生产中 3完工
    await this.dataSource.query(
      `UPDATE work_order SET produced_qty = produced_qty + ?, status = IF(produced_qty + ? >= qty, 3, 2)
        WHERE id=? AND tenant_id=?`, [qty, qty, woId, ctx.tenantId]);
    return { id: res.insertId };
  }

  // ---------------- 质检 ----------------

  listQc() {
    return this.dataSource.query(
      `SELECT q.*, p.name AS product_name FROM mes_qc q LEFT JOIN product p ON p.id=q.product_id
        WHERE q.tenant_id=? AND q.is_deleted=0 ORDER BY q.id DESC LIMIT 200`, [currentContext().tenantId]);
  }

  saveQc(dto: any) {
    const ctx = currentContext();
    const checkQty = Number(dto.checkQty || dto.check_qty || 0);
    const ngQty = Number(dto.ngQty || dto.ng_qty || 0);
    // 质检建议规则兜底：不合格率超 10% 提示关注来料或工序
    const rate = checkQty > 0 ? (ngQty / checkQty) * 100 : 0;
    const advice = rate > 10 ? `不合格率 ${rate.toFixed(1)}% 偏高，建议追溯供应商/工序并加严抽检` : '质量正常，可继续生产';
    return this.dataSource.query(
      `INSERT INTO mes_qc (tenant_id, qc_no, qc_type, source_type, source_id, product_id, check_qty, ng_qty, result, ai_advice, created_by)
       VALUES (?,?,?,?,?,?,?,?,?,?,?)`,
      [ctx.tenantId, dto.qcNo || genNo('QC'), dto.qcType || dto.qc_type || 'IQC', dto.sourceType || dto.source_type || null,
        dto.sourceId || dto.source_id || null, dto.productId || dto.product_id || null, checkQty, ngQty,
        dto.result || (ngQty > 0 ? 'REJECT' : 'PASS'), advice, ctx.userId])
      .then((res: any) => ({ id: res.insertId, aiAdvice: advice }));
  }

  // ---------------- 设备 ----------------

  listEquipments() {
    return this.dataSource.query(`SELECT * FROM mes_equipment WHERE tenant_id=? AND is_deleted=0 ORDER BY id`, [currentContext().tenantId]);
  }

  saveEquipment(dto: any) {
    const ctx = currentContext();
    if (dto.id) {
      return this.dataSource.query(
        `UPDATE mes_equipment SET code=?, name=?, status=?, last_maintain=?, next_maintain=? WHERE id=? AND tenant_id=?`,
        [dto.code, dto.name, dto.status || 'RUNNING', dto.lastMaintain || dto.last_maintain || null,
          dto.nextMaintain || dto.next_maintain || null, dto.id, ctx.tenantId])
        .then(() => ({ id: dto.id }));
    }
    return this.dataSource.query(
      `INSERT INTO mes_equipment (tenant_id, code, name, status, last_maintain, next_maintain) VALUES (?,?,?,?,?,?)`,
      [ctx.tenantId, dto.code, dto.name, dto.status || 'RUNNING', dto.lastMaintain || dto.last_maintain || null,
        dto.nextMaintain || dto.next_maintain || null])
      .then((res: any) => ({ id: res.insertId }));
  }
}

@Controller('api/v1/mes')
class MesController {
  constructor(private readonly service: MesService) {}

  @Get('routings') @RequirePerm('mes:routing:view') routings(@Query('productId') productId?: string) { return this.service.listRoutings(productId ? Number(productId) : undefined); }
  @Post('routings') @RequirePerm('mes:routing:edit') saveRouting(@Body() dto: any) { return this.service.saveRouting(dto); }
  @Post('mrp/run') @RequirePerm('mes:mrp:run') runMrp(@Body() dto: any) { return this.service.runMrp(dto || {}); }
  @Get('mrp/runs') @RequirePerm('mes:mrp:run') listRuns() { return this.service.listRuns(); }
  @Get('mrp/suggests') @RequirePerm('mes:mrp:run') suggests(@Query('runId') runId: string) { return this.service.suggestList(Number(runId)); }
  @Get('workorders') @RequirePerm('mes:workorder:view') workOrders() { return this.service.listWorkOrders(); }
  @Post('workorders') @RequirePerm('mes:workorder:edit') createWorkOrder(@Body() dto: any) { return this.service.createWorkOrder(dto); }
  @Get('reports') @RequirePerm('mes:workorder:view') reports(@Query('workorderId') workorderId: string) { return this.service.listReports(Number(workorderId)); }
  @Post('reports') @RequirePerm('mes:workorder:edit') addReport(@Body() dto: any) { return this.service.addReport(dto); }
  @Get('qc') @RequirePerm('mes:qc:view') qc() { return this.service.listQc(); }
  @Post('qc') @RequirePerm('mes:qc:edit') saveQc(@Body() dto: any) { return this.service.saveQc(dto); }
  @Get('equipments') @RequirePerm('mes:equipment:view') equipments() { return this.service.listEquipments(); }
  @Post('equipments') @RequirePerm('mes:equipment:edit') saveEquipment(@Body() dto: any) { return this.service.saveEquipment(dto); }
}

@Module({ controllers: [MesController], providers: [MesService, AuditService], exports: [MesService] })
export class MesModule {}
