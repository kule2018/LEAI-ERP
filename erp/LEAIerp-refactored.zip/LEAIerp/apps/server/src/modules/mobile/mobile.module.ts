/**
 * 移动端支持接口（文档第 19 章）：给企业微信/钉钉/H5 使用
 * 能力：移动端登录（复用 auth）、扫码查询（库存/产品/条码）、离线缓存批量提交（盘点/拣货/开单）、待办聚合
 * 说明：移动端页面为独立 H5 目录 apps/web-mobile，调用本组接口；离线提交按 batchId 幂等，同批次重复提交直接返回已处理结果。
 */
import { Body, Controller, Get, Injectable, Module, Post, Query } from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';
import { DataSource } from 'typeorm';
import { RequirePerm, currentContext } from '../../common/common';
import { AuditService } from '../../common/audit.service';

@Injectable()
export class MobileService {
  constructor(@InjectDataSource() private readonly dataSource: DataSource, private readonly audit: AuditService) {}

  /** 扫码解析：输入条码/编码 → 返回产品与库存概要 */
  async scan(code: string) {
    const ctx = currentContext();
    const rows: any[] = await this.dataSource.query(
      `SELECT p.id, p.name, p.code, p.barcode, p.price,
              v.sku_code, v.attributes,
              (SELECT COALESCE(SUM(qty_on_hand - qty_occupied),0) FROM stock_balance b WHERE b.product_id=p.id AND b.tenant_id=?) AS available
         FROM product p
         LEFT JOIN product_variant v ON v.product_id=p.id AND (v.barcode=? OR v.sku_code=?)
        WHERE p.tenant_id=? AND p.is_deleted=0 AND (p.barcode=? OR p.code=?)
        LIMIT 1`, [ctx.tenantId, code, code, ctx.tenantId, code, code]);
    const hit = rows[0] || null;
    await this.dataSource.query(`INSERT INTO mobile_scan_log (tenant_id, user_id, scan_type, code, result) VALUES (?,?, 'BARCODE', ?, ?)`,
      [ctx.tenantId, ctx.userId, code, hit ? `命中：${hit.name}` : '未找到']);
    if (!hit) return { hit: false, code };
    return { hit: true, code, product: hit };
  }

  /** 移动端首页聚合：待办数、今日销售、库存预警数 */
  async home() {
    const ctx = currentContext();
    const t = ctx.tenantId;
    const todo: any[] = await this.dataSource.query(
      `SELECT COUNT(*) c FROM flow_task WHERE tenant_id=? AND status=1 AND assignee_id=?`, [t, ctx.userId]);
    const sale: any[] = await this.dataSource.query(
      `SELECT COALESCE(SUM(total_amount),0) v FROM sale_order WHERE tenant_id=? AND is_deleted=0 AND DATE(order_date)=CURDATE()`, [t]);
    const warn: any[] = await this.dataSource.query(
      `SELECT COUNT(*) c FROM stock_balance WHERE tenant_id=? AND qty_on_hand - qty_occupied <= 0`, [t]);
    return { todo: Number(todo[0]?.c || 0), todaySale: Number(sale[0]?.v || 0), lowStock: Number(warn[0]?.c || 0) };
  }

  /** 待办清单（移动端精简版） */
  todoList() {
    return this.dataSource.query(
      `SELECT t.id, t.node_name, i.biz_type, i.biz_id, i.biz_no, i.title, i.amount, i.created_at
         FROM flow_task t JOIN flow_instance i ON i.id=t.instance_id
        WHERE t.tenant_id=? AND t.status=1 AND t.assignee_id=? ORDER BY t.id DESC LIMIT 50`,
      [currentContext().tenantId, currentContext().userId]);
  }

  /**
   * 离线缓存批量提交：支持盘点录数（stocktake）、拣货（pick）、扫码记录（scan）。
   * 幂等：同 batchId 已存在日志则直接返回「已处理」，避免弱网重复提交造成重复过账。
   */
  async offlineSubmit(batchId: string, items: Array<{ type: string; id?: number; qty?: number; code?: string }>) {
    const ctx = currentContext();
    if (!batchId) return { error: 'batchId 必填' };
    const exists: any[] = await this.dataSource.query(
      `SELECT 1 FROM mobile_scan_log WHERE tenant_id=? AND offline_batch=? LIMIT 1`, [ctx.tenantId, batchId]);
    if (exists.length) return { batchId, status: 'ALREADY_PROCESSED' };

    const result: string[] = [];
    for (const it of items || []) {
      if (it.type === 'scan' && it.code) {
        await this.dataSource.query(
          `INSERT INTO mobile_scan_log (tenant_id, user_id, scan_type, code, offline_batch) VALUES (?,?, 'STOCK', ?, ?)`,
          [ctx.tenantId, ctx.userId, it.code, batchId]);
        result.push(`扫码 ${it.code} 已记录`);
      } else if (it.type === 'stocktake' && it.id && it.qty !== undefined) {
        await this.dataSource.query(`UPDATE wms_stocktake_line SET real_qty=?, diff_qty=?-book_qty WHERE id=?`, [Number(it.qty), Number(it.qty), it.id]);
        result.push(`盘点行 ${it.id} 实盘 ${it.qty}`);
      } else if (it.type === 'pick' && it.id && it.qty !== undefined) {
        await this.dataSource.query(`UPDATE wms_pick_wave_line SET picked_qty = picked_qty + ? WHERE id=?`, [Number(it.qty), it.id]);
        result.push(`拣货行 ${it.id} +${it.qty}`);
      } else {
        result.push(`忽略无法识别的项：${JSON.stringify(it).slice(0, 80)}`);
      }
    }
    await this.dataSource.query(
      `INSERT INTO mobile_scan_log (tenant_id, user_id, scan_type, code, result, offline_batch) VALUES (?,?, 'OFFLINE', 'BATCH', ?, ?)`,
      [ctx.tenantId, ctx.userId, result.join('；').slice(0, 490), batchId]);
    await this.audit.write('OFFLINE_SUBMIT', 'MOBILE', 0, batchId, `离线提交 ${(items || []).length} 项`);
    return { batchId, status: 'DONE', result };
  }

  /** 库存查询（移动端精简） */
  stock(query: any) {
    return this.dataSource.query(
      `SELECT b.warehouse_id, b.product_id, p.name AS product_name, b.qty_on_hand, b.qty_occupied
         FROM stock_balance b JOIN product p ON p.id=b.product_id
        WHERE b.tenant_id=? AND b.is_deleted=0 AND (?='' OR p.name LIKE ? OR p.code LIKE ?)
        ORDER BY b.id LIMIT 100`,
      [currentContext().tenantId, query.keyword || '', `%${query.keyword || ''}%`, `%${query.keyword || ''}%`]);
  }
}

@Controller('api/v1/mobile')
class MobileController {
  constructor(private readonly service: MobileService) {}

  @Get('home') @RequirePerm('mobile:access') home() { return this.service.home(); }
  @Get('todo') @RequirePerm('mobile:access') todo() { return this.service.todoList(); }
  @Get('scan') @RequirePerm('mobile:access') scan(@Query('code') code: string) { return this.service.scan(code); }
  @Get('stock') @RequirePerm('mobile:access') stock(@Query() q: any) { return this.service.stock(q); }
  @Post('offline-submit') @RequirePerm('mobile:access') offline(@Body() body: any) { return this.service.offlineSubmit(body?.batchId, body?.items || []); }
}

@Module({ controllers: [MobileController], providers: [MobileService, AuditService], exports: [MobileService] })
export class MobileModule {}
