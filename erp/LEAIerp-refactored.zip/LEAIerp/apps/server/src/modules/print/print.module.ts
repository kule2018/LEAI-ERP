/**
 * 打印中心（文档第 11 章）
 * 四段式：模板设计 → 预览 → 打印（浏览器/客户端/服务端 PDF）→ 记录可追溯
 * 服务端 PDF 用 Puppeteer 渲染 Handlebars HTML；Puppeteer 启动失败时降级为返回 HTML。
 */
import { Body, Controller, Get, Injectable, Module, Param, ParseIntPipe, Patch, Post, Query, Res } from '@nestjs/common';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { InjectDataSource } from '@nestjs/typeorm';
import { DataSource } from 'typeorm';
import * as Handlebars from 'handlebars';
import { BizException, BizCode, RequirePerm, currentContext, normalizePage, pageResult } from '../../common/common';
import { AuditService } from '../../common/audit.service';

@Injectable()
export class PrintService {
  constructor(
    @InjectDataSource() private readonly dataSource: DataSource,
    private readonly audit: AuditService,
    private readonly events: EventEmitter2,
  ) {
    // 金额大写助手：{{cnMoney total}}
    Handlebars.registerHelper('cnMoney', (v: any) => this.cnMoney(Number(v || 0)));
    Handlebars.registerHelper('eq', (a: any, b: any) => a === b);
  }

  listTemplates(query: any) {
    const args: any[] = [currentContext().tenantId];
    let where = 'tenant_id = ? AND is_deleted = 0';
    if (query.bizType) { where += ' AND biz_type = ?'; args.push(query.bizType); }
    return this.dataSource.query(`SELECT * FROM print_template WHERE ${where} ORDER BY id DESC`, args);
  }

  async saveTemplate(dto: any, id?: number) {
    const ctx = currentContext();
    if (id) {
      // 模板版本化：修改时原模板停用，复制一份 version+1，保证历史单据按旧模板补打
      const old: any[] = await this.dataSource.query(`SELECT * FROM print_template WHERE id=? AND tenant_id=?`, [id, ctx.tenantId]);
      if (!old[0]) throw new BizException(BizCode.NOT_FOUND, '模板不存在');
      await this.dataSource.query(`UPDATE print_template SET is_active=0 WHERE id=?`, [id]);
      const res: any = await this.dataSource.query(
        `INSERT INTO print_template (tenant_id, code, name, biz_type, scope, paper, width_mm, height_mm, schema, is_default, version, is_active, created_by)
         VALUES (?,?,?,?,?,?,?,?,?,?,?,1,?)`,
        [ctx.tenantId, dto.code, dto.name, dto.biz_type || dto.bizType, dto.scope || 'TENANT', dto.paper || 'A4',
          dto.width_mm ?? dto.widthMm ?? 210, dto.height_mm ?? dto.heightMm ?? 297,
          typeof dto.schema === 'string' ? dto.schema : JSON.stringify(dto.schema || {}),
          dto.is_default ? 1 : 0, Number(old[0].version || 1) + 1, ctx.userId]);
      await this.audit.write('UPDATE', 'PRINT_TEMPLATE', res.insertId, dto.code, '模板升版');
      return { id: res.insertId, version: Number(old[0].version || 1) + 1 };
    }
    const res: any = await this.dataSource.query(
      `INSERT INTO print_template (tenant_id, code, name, biz_type, scope, paper, width_mm, height_mm, schema, is_default, is_active, created_by)
       VALUES (?,?,?,?,?,?,?,?,?,?,1,?)`,
      [ctx.tenantId, dto.code, dto.name, dto.biz_type || dto.bizType || '', dto.scope || 'TENANT', dto.paper || 'A4',
        dto.width_mm ?? dto.widthMm ?? 210, dto.height_mm ?? dto.heightMm ?? 297,
        typeof dto.schema === 'string' ? dto.schema : JSON.stringify(dto.schema || {}), dto.is_default ? 1 : 0, ctx.userId]);
    await this.audit.write('CREATE', 'PRINT_TEMPLATE', res.insertId, dto.code, '新建打印模板');
    return { id: res.insertId, version: 1 };
  }

  /**
   * 取模板并渲染预览 HTML
   * @param bizType 单据类型；不传 templateId 时取该类型默认模板
   */
  async preview(bizType: string, data: any, templateId?: number) {
    const ctx = currentContext();
    const rows: any[] = templateId
      ? await this.dataSource.query(`SELECT * FROM print_template WHERE id=? AND tenant_id=?`, [templateId, ctx.tenantId])
      : await this.dataSource.query(
        `SELECT * FROM print_template WHERE tenant_id=? AND biz_type=? AND is_active=1 ORDER BY is_default DESC, id DESC LIMIT 1`, [ctx.tenantId, bizType]);
    if (!rows[0]) throw new BizException(BizCode.NOT_FOUND, '未找到可用打印模板');
    const tpl = rows[0];
    const biz = await this.loadBizData(bizType, data?.bizId);
    const context = { ...(biz || {}), ...(data || {}), now: new Date().toLocaleString('zh-CN') };
    let html: string;
    if (tpl.schema && String(tpl.schema).trim().startsWith('<')) {
      html = Handlebars.compile(String(tpl.schema))(context);
    } else {
      // schema 为 hiprint 设计器 JSON 时，前端负责渲染；服务端返回占位页
      html = `<html><body><div id="hiprint-proxy" data-template='${String(tpl.schema).replace(/</g, '&lt;')}'></div></body></html>`;
    }
    return { templateId: tpl.id, version: tpl.version, paper: tpl.paper, html };
  }

  /** 创建打印任务：SERVER_PDF 通道用 Puppeteer 生成 PDF，其余通道只记日志 */
  async createJob(dto: { bizType: string; bizId: number; templateId?: number; copies?: number; channel?: string }) {
    const ctx = currentContext();
    const preview = await this.preview(dto.bizType, { bizId: dto.bizId }, dto.templateId);
    let pdfUrl: string | null = null;
    if (dto.channel === 'SERVER_PDF') {
      pdfUrl = await this.renderPdf(preview.html, `${dto.bizType}_${dto.bizId}.pdf`);
    }
    const bizNo = await this.bizNo(dto.bizType, dto.bizId);
    await this.dataSource.query(
      `INSERT INTO print_record (tenant_id, biz_type, biz_id, biz_no, template_id, template_version, copies, channel, printed_by, ip, pdf_url, watermark)
       VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`,
      [ctx.tenantId, dto.bizType, dto.bizId, bizNo, preview.templateId, preview.version, dto.copies || 1,
        dto.channel || 'BROWSER', ctx.userId, null, pdfUrl,
        `打印人：${ctx.username || ctx.userId}  时间：${new Date().toLocaleString('zh-CN')}`]);
    await this.audit.write('PRINT', dto.bizType, dto.bizId, bizNo, `打印 ${dto.copies || 1} 份，通道 ${dto.channel || 'BROWSER'}`);
    this.events.emit('realtime.print', {
      tenantId: ctx.tenantId, userIds: [ctx.userId], title: '打印任务已完成',
      data: { bizType: dto.bizType, bizId: dto.bizId, bizNo, channel: dto.channel || 'BROWSER', pdfUrl },
    });
    return { pdfUrl, html: preview.html, templateId: preview.templateId };
  }

  listRecords(query: any) {
    const { page, pageSize, skip } = normalizePage(query.page, query.pageSize);
    const args: any[] = [currentContext().tenantId];
    let where = 'tenant_id = ?';
    if (query.bizType) { where += ' AND biz_type = ?'; args.push(query.bizType); }
    if (query.bizId) { where += ' AND biz_id = ?'; args.push(query.bizId); }
    return this.dataSource.query(`SELECT * FROM print_record WHERE ${where} ORDER BY id DESC LIMIT ? OFFSET ?`, [...args, pageSize, skip])
      .then(async (list) => {
        const totalRows: any[] = await this.dataSource.query(`SELECT COUNT(*) c FROM print_record WHERE ${where}`, args);
        return pageResult(list, Number(totalRows[0]?.c || 0), page, pageSize);
      });
  }

  /** 批量条码标签：产品编码/名称 → Code128/QR 的 SVG，交给模板排版 */
  async makeLabels(dto: { productIds: number[]; type?: string }) {
    const ctx = currentContext();
    if (!dto.productIds?.length) throw new BizException(BizCode.PARAM_INVALID, '请选择产品');
    const placeholders = dto.productIds.map(() => '?').join(',');
    const products: any[] = await this.dataSource.query(
      `SELECT id, name, code, barcode, price FROM product WHERE tenant_id=? AND id IN (${placeholders}) AND is_deleted=0`,
      [ctx.tenantId, ...dto.productIds]);
    return products.map((p) => ({
      ...p,
      barcodeSvg: `<svg data-code="${p.code}" data-type="${dto.type || 'code128'}"></svg>`.replace(/"/g, '&quot;'),
    }));
  }

  /**
   * 按打印任务 ID 取 PDF（文档 11.4 GET /jobs/:id/pdf）。
   * 服务端已生成 PDF 时返回下载地址；Puppeteer 不可用时返回重渲染的 HTML，交浏览器打印兜底。
   */
  async jobPdf(id: number) {
    const ctx = currentContext();
    const rows: any[] = await this.dataSource.query(
      `SELECT * FROM print_record WHERE id=? AND tenant_id=?`, [id, ctx.tenantId]);
    if (!rows[0]) throw new BizException(BizCode.NOT_FOUND, '打印记录不存在');
    if (rows[0].pdf_url) return { pdfUrl: rows[0].pdf_url, html: null };
    const preview = await this.preview(rows[0].biz_type, { bizId: rows[0].biz_id }, rows[0].template_id);
    return { pdfUrl: null, html: preview.html };
  }

  // ---------------- 内部方法 ----------------

  private async loadBizData(bizType: string, bizId?: number) {
    if (!bizId) return null;
    const ctx = currentContext();
    if (bizType === 'SALE_ORDER' || bizType === 'SALE_RECEIPT') {
      const rows: any[] = await this.dataSource.query(
        `SELECT o.*, c.name AS customer_name, c.phone AS customer_phone FROM sale_order o
          LEFT JOIN customer c ON c.id=o.customer_id WHERE o.id=? AND o.tenant_id=?`, [bizId, ctx.tenantId]);
      if (!rows[0]) return null;
      const lines = await this.dataSource.query(
        `SELECT l.*, p.name AS product_name FROM sale_order_line l LEFT JOIN product p ON p.id=l.product_id WHERE l.order_id=?`, [bizId]);
      return { order: rows[0], customer: rows[0], lines, qrcode: rows[0].order_no };
    }
    if (bizType === 'PURCHASE_ORDER') {
      const rows: any[] = await this.dataSource.query(
        `SELECT o.*, s.name AS supplier_name FROM purchase_order o LEFT JOIN supplier s ON s.id=o.supplier_id
          WHERE o.id=? AND o.tenant_id=?`, [bizId, ctx.tenantId]);
      const lines = await this.dataSource.query(
        `SELECT l.*, p.name AS product_name FROM purchase_order_line l LEFT JOIN product p ON p.id=l.product_id WHERE l.order_id=?`, [bizId]);
      return { order: rows[0], lines };
    }
    return null;
  }

  private async bizNo(bizType: string, bizId: number) {
    const table: Record<string, string> = { SALE_ORDER: 'sale_order', SALE_RECEIPT: 'sale_order', PURCHASE_ORDER: 'purchase_order' };
    const t = table[bizType];
    if (!t) return '';
    const rows: any[] = await this.dataSource.query(`SELECT order_no FROM ${t} WHERE id=?`, [bizId]);
    return rows[0]?.order_no || '';
  }

  /** Puppeteer 渲染 PDF；未安装 Chromium 时返回 null，由前端走浏览器打印 */
  private async renderPdf(html: string, filename: string): Promise<string | null> {
    try {
      const puppeteer = await import('puppeteer');
      const browser = await (puppeteer.default || puppeteer).launch({
        headless: true,
        args: ['--no-sandbox', '--disable-setuid-sandbox'],
        executablePath: process.env.PUPPETEER_EXECUTABLE_PATH || undefined,
      });
      const page = await browser.newPage();
      await page.setContent(html, { waitUntil: 'networkidle0' });
      await page.pdf({ path: `/tmp/${filename}`, format: 'A4' });
      await browser.close();
      return `/print/pdf/${filename}`;
    } catch (err: any) {
      // 降级：不阻断打印流程，前端改用浏览器打印
      console.warn('[打印] Puppeteer 不可用，降级为浏览器打印：', err?.message || err);
      return null;
    }
  }

  /** 数字金额转人民币大写 */
  private cnMoney(n: number): string {
    const digits = '零壹贰叁肆伍陆柒捌玖';
    const units = ['', '拾', '佰', '仟'];
    const bigUnits = ['', '万', '亿'];
    if (!Number.isFinite(n)) return '';
    let intPart = Math.round(n * 100);
    const fen = intPart % 10; intPart = Math.trunc(intPart / 10);
    const jiao = intPart % 10; intPart = Math.trunc(intPart / 10);
    let result = '';
    if (intPart === 0) result = '零';
    let groupIndex = 0;
    while (intPart > 0) {
      const group = intPart % 10000;
      let groupStr = '';
      let zero = false;
      for (let i = 3; i >= 0; i--) {
        const d = Math.trunc(group / Math.pow(10, i)) % 10;
        if (d === 0) { zero = true; } else {
          if (zero && groupStr) groupStr += '零';
          zero = false;
          groupStr += digits[d] + units[i];
        }
      }
      if (groupStr) result = groupStr + bigUnits[groupIndex] + result;
      else if (result && !result.startsWith('零')) result = '零' + result;
      intPart = Math.trunc(intPart / 10000);
      groupIndex++;
    }
    result += '元';
    if (jiao === 0 && fen === 0) return result + '整';
    if (jiao > 0) result += digits[jiao] + '角';
    if (jiao === 0 && fen > 0) result += '零';
    if (fen > 0) result += digits[fen] + '分';
    return result + '整';
  }
}

@Controller('api/v1/print')
class PrintController {
  constructor(private readonly service: PrintService) {}

  @Get('templates') @RequirePerm('print:template:edit') listTemplates(@Query() q: any) { return this.service.listTemplates(q); }
  @Post('templates') @RequirePerm('print:template:edit') saveTemplate(@Body() dto: any) { return this.service.saveTemplate(dto); }
  // 模板更新走版本化：服务层会停用旧版并复制生成新版本
  @Patch('templates/:id') @RequirePerm('print:template:edit')
  updateTemplate(@Param('id', ParseIntPipe) id: number, @Body() dto: any) { return this.service.saveTemplate(dto, id); }
  @Post('templates/:id/preview') @RequirePerm('print:record:view')
  preview(@Param('id', ParseIntPipe) id: number, @Body() body: any) { return this.service.preview(body.bizType || '', body, id); }
  @Post('jobs') @RequirePerm('print:record:view') createJob(@Body() dto: any) { return this.service.createJob(dto); }
  @Get('jobs/:id/pdf') @RequirePerm('print:record:view')
  jobPdf(@Param('id', ParseIntPipe) id: number) { return this.service.jobPdf(id); }
  @Get('records') @RequirePerm('print:record:view') listRecords(@Query() q: any) { return this.service.listRecords(q); }
  @Post('labels') @RequirePerm('print:record:view') makeLabels(@Body() dto: any) { return this.service.makeLabels(dto); }
}

@Module({ controllers: [PrintController], providers: [PrintService, AuditService], exports: [PrintService] })
export class PrintModule {}
