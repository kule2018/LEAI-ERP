/**
 * 采购供应模块（文档 4.4 采购流程）
 * 草稿(0) → 待审(1) → 已确认(2) → 完成(4)
 * 收货：采购入库 PURCHASE_IN（成本确认、加权成本重算）→ 生成应付 → 自动凭证。
 */
import { Body, Controller, Get, Injectable, Module, Param, ParseIntPipe, Post, Query } from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';
import { DataSource } from 'typeorm';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { BizException, BizCode, DataScope, RequirePerm, currentContext, normalizePage, pageResult, buildDataScopeWhere, appendDataScope } from '../../common/common';
import { AuditService } from '../../common/audit.service';
import { SequenceService } from '../../common/sequence.service';
import { StockService } from '../inventory/stock.service';
import { InventoryModule } from '../inventory/inventory.module';
import { StockVoucherType } from '@erp/shared';
import Decimal from 'decimal.js';

const STATUS = { DRAFT: 0, SUBMITTED: 1, CONFIRMED: 2, PARTIAL: 3, DONE: 4, CANCELLED: 9 } as const;

@Injectable()
export class PurchaseService {
  constructor(
    @InjectDataSource() private readonly dataSource: DataSource,
    private readonly seq: SequenceService,
    private readonly stock: StockService,
    private readonly audit: AuditService,
    private readonly events: EventEmitter2,
  ) {}

  async list(query: any) {
    const ctx = currentContext();
    const { page, pageSize, skip } = normalizePage(query.page, query.pageSize);
    const where: string[] = ['o.tenant_id = ?', 'o.is_deleted = 0'];
    const args: any[] = [ctx.tenantId];
    if (query.keyword) { where.push('(o.order_no LIKE ? OR s.name LIKE ?)'); args.push(`%${query.keyword}%`, `%${query.keyword}%`); }
    if (query.supplierId) { where.push('o.supplier_id = ?'); args.push(query.supplierId); }
    if (query.status !== undefined && query.status !== '') { where.push('o.status = ?'); args.push(query.status); }
    if (query.startDate) { where.push('o.order_date >= ?'); args.push(query.startDate); }
    if (query.endDate) { where.push('o.order_date <= ?'); args.push(query.endDate); }
    appendDataScope(where, args, buildDataScopeWhere('ORG', ctx, 'o', { creatorCol: 'created_by' }));
    const source = `FROM purchase_order o
      LEFT JOIN supplier s ON s.id=o.supplier_id AND s.tenant_id=o.tenant_id
      WHERE ${where.join(' AND ')}`;
    const list = await this.dataSource.query(
      `SELECT o.*, s.name AS supplier_name ${source} ORDER BY o.id DESC LIMIT ? OFFSET ?`, [...args, pageSize, skip]);
    const statRows: any[] = await this.dataSource.query(
      `SELECT COUNT(*) order_count, IFNULL(SUM(o.total_amount),0) total_amount ${source}`, args);
    return { ...pageResult(list, Number(statRows[0]?.order_count || 0), page, pageSize), summary: statRows[0] || {} };
  }

  async detail(id: number) {
    const ctx = currentContext();
    const rows: any[] = await this.dataSource.query(
      `SELECT o.*, s.name AS supplier_name FROM purchase_order o LEFT JOIN supplier s ON s.id=o.supplier_id
        WHERE o.id=? AND o.tenant_id=? AND o.is_deleted=0`, [id, ctx.tenantId]);
    if (!rows.length) throw new BizException(BizCode.NOT_FOUND, '采购单不存在');
    const lines = await this.dataSource.query(
      `SELECT l.*, p.name AS product_name, p.code AS product_code FROM purchase_order_line l
        LEFT JOIN product p ON p.id=l.product_id WHERE l.order_id=? AND l.tenant_id=? ORDER BY l.id`, [id, ctx.tenantId]);
    return { ...rows[0], lines };
  }

  async save(dto: any, id?: number) {
    const ctx = currentContext();
    const lines: any[] = Array.isArray(dto.lines) ? dto.lines : [];
    if (!lines.length) throw new BizException(BizCode.PARAM_INVALID, '请至少录入一行商品明细');
    let total = new Decimal(0);
    const prepared = lines.map((l) => {
      const qty = new Decimal(l.qty || 0);
      const price = new Decimal(l.unitPrice ?? l.price ?? 0);
      const amount = qty.times(price);
      total = total.plus(amount);
      return { line: l, qty, price, amount };
    });
    if (id) {
      const old = await this.detail(id);
      if (Number(old.status) !== STATUS.DRAFT) throw new BizException(BizCode.STATUS_ILLEGAL, '仅草稿单可修改');
      await this.dataSource.query(
        `UPDATE purchase_order SET supplier_id=?, warehouse_id=?, order_date=?, total_amount=?, remark=?, updated_by=? WHERE id=? AND tenant_id=?`,
        [dto.supplierId || null, dto.warehouseId || null, dto.orderDate ? new Date(dto.orderDate) : new Date(),
          total.toDecimalPlaces(4).toString(), dto.remark || null, ctx.userId, id, ctx.tenantId]);
      await this.dataSource.query(`DELETE FROM purchase_order_line WHERE order_id=? AND tenant_id=?`, [id, ctx.tenantId]);
      await this.audit.writeDiff('UPDATE', 'PURCHASE_ORDER', id, old.order_no,
        { total_amount: old.total_amount, supplier_id: old.supplier_id, remark: old.remark },
        { total_amount: total.toDecimalPlaces(4).toString(), supplier_id: dto.supplierId || null, remark: dto.remark || null },
        ['total_amount']);
    } else {
      const orderNo = await this.seq.next('PO');
      const res: any = await this.dataSource.query(
        `INSERT INTO purchase_order (tenant_id, order_no, supplier_id, warehouse_id, order_date, status, total_amount, remark, created_by)
         VALUES (?,?,?,?,?,?,?,?,?)`,
        [ctx.tenantId, orderNo, dto.supplierId || null, dto.warehouseId || null,
          dto.orderDate ? new Date(dto.orderDate) : new Date(), STATUS.DRAFT, total.toDecimalPlaces(4).toString(), dto.remark || null, ctx.userId]);
      id = res.insertId;
      await this.audit.writeDiff('CREATE', 'PURCHASE_ORDER', id, orderNo, null,
        { total_amount: total.toDecimalPlaces(4).toString(), supplier_id: dto.supplierId || null, warehouse_id: dto.warehouseId || null },
        ['total_amount']);
    }
    for (const p of prepared) {
      await this.dataSource.query(
        `INSERT INTO purchase_order_line (tenant_id, order_id, product_id, variant_id, qty, unit_price, amount)
         VALUES (?,?,?,?,?,?,?)`,
        [ctx.tenantId, id, p.line.productId, p.line.variantId || 0, p.qty.toString(),
          p.price.toDecimalPlaces(4).toString(), p.amount.toDecimalPlaces(4).toString()]);
    }
    return { id, total: total.toString() };
  }

  async submit(id: number) { return this.transit(id, STATUS.DRAFT, STATUS.SUBMITTED, '提交审批'); }
  async confirm(id: number) { return this.transit(id, STATUS.SUBMITTED, STATUS.CONFIRMED, '确认采购单'); }

  /**
   * 收货入库：PURCHASE_IN 过账（重算加权成本），回写 received_qty，生成应付与凭证
   * @param body.lines 可选，不传则整单收货
   */
  async receive(id: number, body?: { lines?: { lineId: number; qty: number; cost?: number }[] }) {
    const ctx = currentContext();
    const order = await this.detail(id);
    if (!( [STATUS.CONFIRMED, STATUS.PARTIAL] as number[] ).includes(Number(order.status))) {
      throw new BizException(BizCode.STATUS_ILLEGAL, '仅已确认的采购单可收货');
    }
    await this.dataSource.query('START TRANSACTION');
    try {
      let totalCost = new Decimal(0);
      for (const line of order.lines) {
        const req = (body?.lines || []).find((l) => l.lineId === line.id);
        const remain = new Decimal(line.qty).minus(line.received_qty || 0);
        const inQty = req ? new Decimal(req.qty) : remain;
        if (inQty.lte(0)) continue;
        if (inQty.greaterThan(remain)) throw new BizException(BizCode.PARAM_INVALID, `收货量不能超过未收量：${line.product_name}`);
        const cost = req?.cost !== undefined && req.cost !== null ? new Decimal(req.cost) : new Decimal(line.unit_price || 0);
        const warehouseId = Number(line.warehouse_id || order.warehouse_id || 0);
        if (!warehouseId) throw new BizException(BizCode.PARAM_INVALID, '明细行缺少仓库');
        await this.stock.postIn(StockVoucherType.PURCHASE_IN, id, {
          warehouseId, productId: Number(line.product_id), variantId: Number(line.variant_id || 0),
          batchId: 0, qty: inQty.toNumber(), cost: cost.toNumber(),
        });
        totalCost = totalCost.plus(inQty.times(cost));
        await this.dataSource.query(`UPDATE purchase_order_line SET received_qty = received_qty + ? WHERE id=?`, [inQty.toString(), line.id]);
      }
      const allReceived = order.lines.every((l: any) => new Decimal(l.received_qty || 0).plus(
        (body?.lines || []).filter((x) => x.lineId === l.id).reduce((s, x) => s + Number(x.qty || 0), 0)
      ).greaterThanOrEqualTo(new Decimal(l.qty)));
      const newStatus = allReceived ? STATUS.DONE : STATUS.PARTIAL;
      await this.dataSource.query(`UPDATE purchase_order SET status=?, updated_by=? WHERE id=? AND tenant_id=?`, [newStatus, ctx.userId, id, ctx.tenantId]);
      await this.audit.write('AUDIT', 'PURCHASE_ORDER', id, order.order_no, `收货入库，状态 ${newStatus}`);

      const exists: any[] = await this.dataSource.query(
        `SELECT id FROM payable WHERE tenant_id=? AND source_type='PURCHASE_ORDER' AND source_id=?`, [ctx.tenantId, id]);
      if (!exists.length && Number(order.supplier_id)) {
        await this.dataSource.query(
          `INSERT INTO payable (tenant_id, supplier_id, source_type, source_id, amount, paid_amount, due_date, status)
           VALUES (?,?, 'PURCHASE_ORDER', ?, ?, 0, DATE_ADD(CURDATE(), INTERVAL ? DAY), 0)`,
          [ctx.tenantId, order.supplier_id, id, order.total_amount, Number(order.pay_days || 0)]);
      }
      await this.events.emitAsync('finance.autoVoucher', {
        sourceType: 'PURCHASE_IN', sourceId: id, voucherDate: new Date(), summary: `采购入库 ${order.order_no}`,
        entries: await this.buildPurchaseEntries(order, totalCost),
      });
      await this.dataSource.query('COMMIT');
      return { id, status: newStatus };
    } catch (e) {
      await this.dataSource.query('ROLLBACK');
      throw e;
    }
  }

  /** 采购退货：冲减库存与应付 */
  async returns(id: number, dto: { lines: { lineId: number; qty: number }[] }) {
    const ctx = currentContext();
    const order = await this.detail(id);
    for (const r of dto.lines || []) {
      const line = order.lines.find((l: any) => l.id === r.lineId);
      if (!line) continue;
      if (new Decimal(r.qty).greaterThan(new Decimal(line.received_qty || 0))) {
        throw new BizException(BizCode.PARAM_INVALID, `退货量不能超过已收量：${line.product_name}`);
      }
      await this.stock.postOut(StockVoucherType.PURCHASE_RETURN, id, {
        warehouseId: Number(line.warehouse_id || order.warehouse_id),
        productId: Number(line.product_id), variantId: Number(line.variant_id || 0),
        batchId: 0, qty: Number(r.qty), cost: Number(line.unit_price || 0),
      }, false);
    }
    await this.audit.write('CREATE', 'PURCHASE_RETURN', id, order.order_no, `采购退货：${JSON.stringify(dto.lines)}`);
    return { id };
  }

  async void(id: number) {
    const ctx = currentContext();
    const rows: any = await this.dataSource.query(`SELECT order_no FROM purchase_order WHERE id=? AND tenant_id=? AND is_deleted=0`, [id, ctx.tenantId]);
    if (!rows[0]) throw new BizException(BizCode.NOT_FOUND, '采购单不存在');
    await this.dataSource.query(`UPDATE purchase_order SET status=9, is_deleted=1, updated_by=? WHERE id=?`, [ctx.userId, id]);
    await this.audit.write('VOID', 'PURCHASE_ORDER', id, rows[0].order_no, '采购单作废');
    await this.seq.release('PO', rows[0].order_no || '', 0);
    return { id };
  }

  private async transit(id: number, from: number, to: number, action: string) {
    const ctx = currentContext();
    const rows: any = await this.dataSource.query(`SELECT status, order_no FROM purchase_order WHERE id=? AND tenant_id=? AND is_deleted=0`, [id, ctx.tenantId]);
    if (!rows[0]) throw new BizException(BizCode.NOT_FOUND, '采购单不存在');
    if (Number(rows[0].status) !== from) throw new BizException(BizCode.STATUS_ILLEGAL, `状态不允许：${action}`);
    await this.dataSource.query(`UPDATE purchase_order SET status=?, updated_by=? WHERE id=? AND tenant_id=?`, [to, ctx.userId, id, ctx.tenantId]);
    await this.audit.write('AUDIT', 'PURCHASE_ORDER', id, rows[0].order_no, action);
    return { id, status: to };
  }

  /** 借 原材料/库存商品 + 进项税 / 贷 应付账款 */
  private async buildPurchaseEntries(order: any, totalCost: Decimal) {
    const rows: any[] = await this.dataSource.query(
      `SELECT id, code FROM account_subject WHERE tenant_id=? AND code IN ('1403','1405','2221','2202')`, [currentContext().tenantId]);
    const map: Record<string, number> = {};
    for (const r of rows) map[r.code] = Number(r.id);
    const cfg: any[] = await this.dataSource.query(`SELECT cfg_value FROM sys_config WHERE tenant_id=? AND cfg_key='tax_rate'`, [currentContext().tenantId]);
    const rate = new Decimal(cfg[0]?.cfg_value || 0.13);
    const amount = totalCost.greaterThan(0) ? totalCost : new Decimal(order.total_amount);
    const tax = amount.dividedBy(rate.plus(1)).times(rate);
    const goods = amount.minus(tax);
    const assetCode = map['1403'] ? '1403' : '1405';
    const entries: any[] = [];
    if (map[assetCode]) entries.push({ subjectId: map[assetCode], debit: goods.toDecimalPlaces(4).toString(), credit: '0', summary: '采购入库' });
    if (map['2221']) entries.push({ subjectId: map['2221'], debit: tax.toDecimalPlaces(4).toString(), credit: '0', summary: '进项税额' });
    if (map['2202']) entries.push({ subjectId: map['2202'], debit: '0', credit: amount.toDecimalPlaces(4).toString(), summary: '应付供应商' });
    return entries;
  }
}

@Controller('api/v1/purchase/orders')
class PurchaseController {
  constructor(private readonly service: PurchaseService) {}

  @Get() @RequirePerm('purchase:order:view') @DataScope('ORG')
  list(@Query() query: any) { return this.service.list(query); }

  @Get(':id') @RequirePerm('purchase:order:view')
  detail(@Param('id', ParseIntPipe) id: number) { return this.service.detail(id); }

  @Post() @RequirePerm('purchase:order:create')
  create(@Body() dto: any) { return this.service.save(dto); }

  @Post(':id') @RequirePerm('purchase:order:edit')
  update(@Param('id', ParseIntPipe) id: number, @Body() dto: any) { return this.service.save(dto, id); }

  @Post(':id/submit') @RequirePerm('purchase:order:audit')
  submit(@Param('id', ParseIntPipe) id: number) { return this.service.submit(id); }

  @Post(':id/confirm') @RequirePerm('purchase:order:audit')
  confirm(@Param('id', ParseIntPipe) id: number) { return this.service.confirm(id); }

  @Post(':id/receive') @RequirePerm('purchase:receive')
  receive(@Param('id', ParseIntPipe) id: number, @Body() body: any) { return this.service.receive(id, body); }

  @Post(':id/return') @RequirePerm('purchase:order:edit')
  returns(@Param('id', ParseIntPipe) id: number, @Body() dto: any) { return this.service.returns(id, dto); }

  @Post(':id/void') @RequirePerm('purchase:order:void')
  void(@Param('id', ParseIntPipe) id: number) { return this.service.void(id); }
}

@Module({
  imports: [InventoryModule],
  controllers: [PurchaseController],
  providers: [PurchaseService, SequenceService, AuditService],
  exports: [PurchaseService],
})
export class PurchaseModule {}
