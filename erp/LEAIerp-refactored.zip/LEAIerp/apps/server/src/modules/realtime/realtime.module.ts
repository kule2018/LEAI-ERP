/**
 * 实时推送（SSE）：不引入任何新依赖，基于原生 HTTP 响应流。
 * - GET /api/v1/realtime/events 按 tenant/user/topic 过滤事件流；
 * - POST /api/v1/realtime/publish 供后台手工发布；
 * - 内部通过 @OnEvent 订阅 stock / approval / print / dashboard 事件再转发给前端。
 */
import {
  Body, Controller, Get, Injectable, Module, OnModuleDestroy, Post, Query, Req, Res,
} from '@nestjs/common';
import { OnEvent } from '@nestjs/event-emitter';
import type { Request, Response } from 'express';
import { currentContext, RequirePerm } from '../../common/common';

/** 实时事件结构 */
export interface RealtimeEvent {
  type: 'STOCK' | 'APPROVAL' | 'PRINT' | 'DASHBOARD' | 'CUSTOM';
  topic: string;
  tenantId: number;
  userIds?: number[]; // 为空表示广播给该租户所有在线用户
  title: string;
  data?: any;
  at?: string;
}

interface SseClient {
  req: Request;
  res: Response;
  tenantId: number;
  userId: number;
  topics: Set<string>;
  heartbeat: any;
}

@Injectable()
export class RealtimeService implements OnModuleDestroy {
  private readonly clients = new Set<SseClient>();

  /** 注册一个 SSE 连接，并设置 25 秒心跳防止代理断连 */
  subscribe(req: Request, res: Response, tenantId: number, userId: number, topics: string[]) {
    res.writeHead(200, {
      'Content-Type': 'text/event-stream; charset=utf-8',
      'Cache-Control': 'no-cache, no-transform',
      Connection: 'keep-alive',
      'X-Accel-Buffering': 'no',
    });
    const client: SseClient = {
      req, res, tenantId, userId,
      topics: new Set(topics.length ? topics : ['*']),
      heartbeat: null,
    };
    client.heartbeat = setInterval(() => {
      try { res.write(': ping\n\n'); } catch { /* 连接已断开，等 close 事件清理 */ }
    }, 25000);
    req.on('close', () => this.remove(client));
    this.clients.add(client);
    res.write(`event: connected\ndata: ${JSON.stringify({ tenantId, userId, topics: Array.from(client.topics) })}\n\n`);
  }

  private remove(client: SseClient) {
    if (client.heartbeat) clearInterval(client.heartbeat);
    this.clients.delete(client);
  }

  /** 发布事件：按租户、用户、订阅主题三重过滤 */
  publish(event: RealtimeEvent) {
    const payload = JSON.stringify({
      type: event.type, topic: event.topic, title: event.title,
      data: event.data || null, at: event.at || new Date().toISOString(),
    });
    let sent = 0;
    for (const client of this.clients) {
      if (client.tenantId !== Number(event.tenantId)) continue;
      if (Array.isArray(event.userIds) && event.userIds.length && !event.userIds.includes(client.userId)) continue;
      if (event.topic && !client.topics.has('*') && !client.topics.has(event.topic)) continue;
      try {
        client.res.write(`event: ${event.type}\ndata: ${payload}\n\n`);
        sent += 1;
      } catch {
        this.remove(client);
      }
    }
    return { sent, type: event.type };
  }

  /** 在线连接数（运维排障用） */
  count() {
    const byTenant: Record<string, number> = {};
    for (const c of this.clients) byTenant[String(c.tenantId)] = (byTenant[String(c.tenantId)] || 0) + 1;
    return { total: this.clients.size, byTenant };
  }

  // ---------------- 内部事件订阅：各业务模块 emit 后统一转成 SSE ----------------
  private relay(payload: any, type: RealtimeEvent['type'], defaultTopic: string) {
    if (!payload) return;
    this.publish({
      type,
      topic: payload.topic || defaultTopic,
      tenantId: Number(payload.tenantId || currentContext().tenantId),
      userIds: payload.userIds,
      title: payload.title || defaultTopic,
      data: payload,
    });
  }

  @OnEvent('realtime.stock', { async: true })
  onStock(payload: any) { this.relay(payload, 'STOCK', 'stock'); }

  @OnEvent('realtime.approval', { async: true })
  onApproval(payload: any) { this.relay(payload, 'APPROVAL', 'approval'); }

  @OnEvent('realtime.print', { async: true })
  onPrint(payload: any) { this.relay(payload, 'PRINT', 'print'); }

  @OnEvent('realtime.dashboard', { async: true })
  onDashboard(payload: any) { this.relay(payload, 'DASHBOARD', 'dashboard'); }

  onModuleDestroy() {
    for (const client of this.clients) {
      this.remove(client);
      try { client.res.end(); } catch { /* 忽略已关闭连接 */ }
    }
  }
}

@Controller('api/v1/realtime')
class RealtimeController {
  constructor(private readonly service: RealtimeService) {}

  /** SSE 事件流：topics 为逗号分隔的订阅主题，空表示订阅全部 */
  @Get('events')
  events(@Req() req: Request, @Res() res: Response, @Query('topics') topics?: string) {
    const ctx = currentContext();
    this.service.subscribe(
      req, res, ctx.tenantId, ctx.userId,
      String(topics || '').split(',').map((t) => t.trim()).filter(Boolean),
    );
  }

  /** 手工发布（管理端公告 / 联调） */
  @Post('publish') @RequirePerm('system:realtime:publish')
  publish(@Body() dto: any) {
    return this.service.publish({
      type: dto.type || 'CUSTOM', topic: dto.topic || 'custom',
      tenantId: Number(dto.tenantId || currentContext().tenantId),
      userIds: dto.userIds, title: dto.title || '系统消息', data: dto.data,
    });
  }

  @Get('clients') @RequirePerm('system:realtime:publish')
  clients() { return this.service.count(); }
}

@Module({
  controllers: [RealtimeController],
  providers: [RealtimeService],
  exports: [RealtimeService],
})
export class RealtimeModule {}
