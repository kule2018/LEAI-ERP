import { Controller, Get, Injectable, Query } from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';
import { DataSource } from 'typeorm';
import { RequirePerm, appendDataScope, buildDataScopeWhere, currentContext, normalizePage, pageResult } from '../../common/common';

type Report = 'sales-details' | 'sales-summary' | 'sales-ranking' | 'purchase-details' | 'purchase-summary' | 'purchase-prices';

const salesPartner = 'LEFT JOIN customer c ON c.id=o.customer_id AND c.tenant_id=o.tenant_id';
const purchasePartner = 'LEFT JOIN supplier s ON s.id=o.supplier_id AND s.tenant_id=o.tenant_id';
const salesLines = 'JOIN sale_order_line l ON l.order_id=o.id AND l.tenant_id=o.tenant_id';
const purchaseLines = 'JOIN purchase_order_line l ON l.order_id=o.id AND l.tenant_id=o.tenant_id';
const products = 'LEFT JOIN product p ON p.id=l.product_id AND p.tenant_id=o.tenant_id';

const reports: Record<Report, { select: string; from: string; group?: string; sort: string; filters: string[] }> = {
  'sales-details': {
    select: `l.id, o.order_no AS orderNo, c.name AS customerName, p.name AS productName, l.qty, l.unit_price AS unitPrice, l.amount, DATE_FORMAT(o.order_date,'%Y-%m-%d') AS saleDate`,
    from: `sale_order o ${salesLines} ${salesPartner} ${products}`,
    sort: 'id DESC',
    filters: ['orderNo', 'customerName', 'productName', 'saleDate'],
  },
  'sales-summary': {
    select: `DATE_FORMAT(o.order_date,'%Y-%m') AS period, c.name AS customerName, COUNT(*) AS orderCount,
             SUM(o.total_amount) AS totalAmount, SUM(o.paid_amount) AS paidAmount`,
    from: `sale_order o ${salesPartner}`,
    group: 'period, o.customer_id, c.name',
    sort: 'period DESC, totalAmount DESC, customerName',
    filters: ['period', 'customerName'],
  },
  'sales-ranking': {
    select: `DENSE_RANK() OVER (ORDER BY SUM(l.qty) DESC, SUM(l.amount) DESC) AS rankNo,
             p.name AS productName, COALESCE(v.sku_code, p.code) AS skuCode, SUM(l.qty) AS saleQty, SUM(l.amount) AS saleAmount`,
    from: `sale_order o ${salesLines} ${products}
      LEFT JOIN product_variant v ON v.id=l.variant_id AND v.tenant_id=o.tenant_id`,
    group: 'l.product_id, l.variant_id, p.name, p.code, v.sku_code',
    sort: 'rankNo, skuCode',
    filters: ['productName', 'skuCode'],
  },
  'purchase-details': {
    select: 'l.id, o.order_no AS orderNo, s.name AS supplierName, p.name AS productName, l.qty, l.unit_price AS unitPrice, l.amount, l.received_qty AS receivedQty',
    from: `purchase_order o ${purchaseLines} ${purchasePartner} ${products}`,
    sort: 'id DESC',
    filters: ['orderNo', 'supplierName', 'productName'],
  },
  'purchase-summary': {
    select: `DATE_FORMAT(o.order_date,'%Y-%m') AS period, s.name AS supplierName, COUNT(*) AS orderCount,
             SUM(o.total_amount) AS totalAmount, SUM(COALESCE(r.received, 0)) AS receivedAmount`,
    from: `purchase_order o ${purchasePartner}
       LEFT JOIN (SELECT tenant_id, order_id, SUM(received_qty * unit_price) AS received
         FROM purchase_order_line GROUP BY tenant_id, order_id) r ON r.order_id=o.id AND r.tenant_id=o.tenant_id`,
    group: 'period, o.supplier_id, s.name',
    sort: 'period DESC, totalAmount DESC, supplierName',
    filters: ['period', 'supplierName'],
  },
  'purchase-prices': {
    select: `l.id, p.name AS productName, s.name AS supplierName, l.unit_price AS price, l.qty, DATE_FORMAT(o.order_date,'%Y-%m-%d') AS purchaseDate`,
    from: `purchase_order o ${purchaseLines} ${purchasePartner} ${products}`,
    sort: 'purchaseDate DESC, id DESC',
    filters: ['productName', 'supplierName', 'purchaseDate'],
  },
};

@Injectable()
export class OrderReportsService {
  constructor(@InjectDataSource() private readonly dataSource: DataSource) {}

  async list(report: Report, query: Record<string, string>) {
    const spec = reports[report];
    const ctx = currentContext();
    const { page, pageSize, skip } = normalizePage(query.page, query.pageSize);
    const sourceWhere = ['o.tenant_id=?', 'o.is_deleted=0', 'o.status IN (2,3,4)'];
    const params: Array<string | number> = [ctx.tenantId];
    appendDataScope(sourceWhere, params, buildDataScopeWhere('ORG', ctx, 'o', { creatorCol: 'created_by' }));

    const criteria: string[] = [];
    for (const field of spec.filters) {
      if (!query[field]) continue;
      criteria.push(`${field}=?`);
      params.push(String(query[field]));
    }
    if (query.keyword) {
      criteria.push(`(${spec.filters.map((field) => `${field} LIKE ?`).join(' OR ')})`);
      params.push(...spec.filters.map(() => `%${String(query.keyword).slice(0, 200)}%`));
    }

    const groupBy = spec.group ? ` GROUP BY ${spec.group}` : '';
    const where = criteria.length ? ` WHERE ${criteria.join(' AND ')}` : '';
    const rows = `FROM (SELECT ${spec.select} FROM ${spec.from} WHERE ${sourceWhere.join(' AND ')}${groupBy}) report${where}`;
    const [list, count] = await Promise.all([
      this.dataSource.query(`SELECT * ${rows} ORDER BY ${spec.sort} LIMIT ? OFFSET ?`, [...params, pageSize, skip]),
      this.dataSource.query(`SELECT COUNT(*) AS count ${rows}`, params),
    ]);
    return pageResult(list, Number(count[0].count), page, pageSize);
  }
}

@Controller('api/v1/order-reports')
export class OrderReportsController {
  constructor(private readonly service: OrderReportsService) {}

  @Get('sales-details') @RequirePerm('sales:order:view')
  salesDetails(@Query() q: Record<string, string>) { return this.service.list('sales-details', q); }

  @Get('sales-summary') @RequirePerm('sales:order:view')
  salesSummary(@Query() q: Record<string, string>) { return this.service.list('sales-summary', q); }

  @Get('sales-ranking') @RequirePerm('sales:order:view')
  salesRanking(@Query() q: Record<string, string>) { return this.service.list('sales-ranking', q); }

  @Get('purchase-details') @RequirePerm('purchase:report:view')
  purchaseDetails(@Query() q: Record<string, string>) { return this.service.list('purchase-details', q); }

  @Get('purchase-summary') @RequirePerm('purchase:report:view')
  purchaseSummary(@Query() q: Record<string, string>) { return this.service.list('purchase-summary', q); }

  @Get('purchase-prices') @RequirePerm('purchase:report:view')
  purchasePrices(@Query() q: Record<string, string>) { return this.service.list('purchase-prices', q); }
}
