/**
 * 销售客户扩展模块：为 PC 端销售客户模块下的所有功能页提供真实 MySQL CRUD 与状态动作。
 * 设计：资源白名单映射数据表，字段按 information_schema 动态校验，避免为每个页面重复写一套控制器。
 */
import { Body, Controller, Delete, Get, Injectable, Module, Param, Patch, Post, Query } from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';
import { DataSource } from 'typeorm';
import { BizCode, BizException, RequirePerm, currentContext, normalizePage, pageResult } from '../../common/common';
import { AuditService } from '../../common/audit.service';
import { OrderReportsController, OrderReportsService } from './order-reports';

/** 前端集合名 -> 真实表名 */
const TABLES: Record<string, string> = {
  crmCustomers: 'customer',
  crmContacts: 'crm_contact',
  crmCustomerGroups: 'crm_customer_group',
  crmCustomerLevels: 'crm_customer_level',
  crmQuotations: 'crm_quotation',
  crmQuoteTemplates: 'sales_quote_template',
  crmContracts: 'sales_contract',
  crmPromotions: 'sales_promotion',
  salesReturns: 'sales_return',
  salesExchanges: 'sales_exchange',
  salesShipments: 'sales_shipment',
  salesStatements: 'sales_statement',
  salesPos: 'pos_order',
  salesProfit: 'sales_profit',
  salesUnshipped: 'sales_unshipped',
  // 采购供应：与销售共用同一套通用 CRUD / 状态机引擎，表各自独立
  purchaseSuppliers: 'supplier',
  purchaseSupplierGroups: 'pur_supplier_group',
  purchaseSupplierEvaluates: 'pur_supplier_evaluate',
  purchaseRequirements: 'pur_requirement',
  purchaseReceipts: 'pur_receipt',
  purchaseIns: 'pur_inbound',
  purchaseReturns: 'pur_return',
  purchaseStatements: 'pur_statement',
  purchaseQuotations: 'pur_quotation',
  purchaseContracts: 'pur_contract',
  purchaseOutsource: 'pur_outsource',
  purchaseLogistics: 'pur_logistics',
  purchasePrices: 'pur_price',
  purchaseOnTime: 'pur_on_time',
  // 库存仓储
  ivCategories: 'iv_categories', ivBrands: 'iv_brands', ivUnits: 'iv_units', ivWarehouses: 'iv_warehouses',
  ivLocations: 'iv_locations', ivBatches: 'iv_batches', ivSerials: 'iv_serials', ivSafeStock: 'iv_safe_stock',
  ivAdjusts: 'iv_adjusts', ivStocktakes: 'iv_stocktakes', ivTransfers: 'iv_transfers', ivPicks: 'iv_picks',
  ivReceipts: 'iv_receipts', ivOuts: 'iv_outs', ivPicksOut: 'iv_picks_out', ivReports: 'iv_reports',
  ivAging: 'iv_aging', ivTurnover: 'iv_turnover', ivSlow: 'iv_slow', ivWaves: 'iv_waves',
  ivPutaways: 'iv_putaways', ivTrace: 'iv_trace', ivCrossdocks: 'iv_crossdocks',
  ivLedgers: 'iv_ledgers', ivAlerts: 'iv_alerts',
  inventorySkus: 'iv_skus', inventoryAssemblies: 'iv_assemblies',
  // 生产制造
  mfMrpRuns: 'mf_mrp_runs', mfBom: 'mf_bom', mfBomVersions: 'mf_bom_versions', mfRoutings: 'mf_routings',
  mfWorkCenters: 'mf_work_centers', mfDemands: 'mf_demands', mfIssues: 'mf_issues',
  mfMaterialReturns: 'mf_material_returns', mfFinishIns: 'mf_finish_ins', mfReports: 'mf_reports',
  mfQc: 'mf_qc', mfEquipments: 'mf_equipments', mfCapacity: 'mf_capacity', mfCosts: 'mf_costs',
  // 财务结算：独立 /api/v1/fin/** 路由，避开原 finance 模块固定接口
  finVouchers: 'fin_vouchers', finReports: 'fin_reports', finSubjects: 'fin_subjects', finAccounts: 'fin_accounts',
  finTransfers: 'fin_transfers', finExpenses: 'fin_expenses', finIncomes: 'fin_incomes',
  finExpenseCategories: 'fin_expense_categories', finIncomeCategories: 'fin_income_categories',
  finReceivables: 'fin_receivables', finPaymentsIn: 'fin_payments_in', finPayables: 'fin_payables',
  finPaymentsOut: 'fin_payments_out', finAging: 'fin_aging', finAssets: 'fin_assets',
  finDepreciations: 'fin_depreciations', finInvoices: 'fin_invoices', finCashFlow: 'fin_cash_flow',
  finSubjectBalances: 'fin_subject_balances', finLedger: 'fin_ledger', finProfitCenters: 'fin_profit_centers',
  finTrialBalance: 'fin_trial_balance', finPeriods: 'fin_periods', finCosts: 'fin_costs',
  // 协同办公
  collabApproval: 'col_approvals', collabChat: 'col_chats', collabNotices: 'col_notices', collabMeetings: 'col_meetings',
  collabFlowDefs: 'col_flow_defs', collabProjects: 'col_projects', collabTasks: 'col_tasks', collabBoard: 'col_boards',
  collabMilestones: 'col_milestones', collabProjectReports: 'col_project_reports', collabFiles: 'col_files',
  collabKnowledge: 'col_knowledge',
  // 人事行政
  hrCompanies: 'hro_companies', hrDepartments: 'hro_departments', hrPositions: 'hro_positions', hrShifts: 'hro_shifts',
  hrEmployees: 'hro_employees', hrAttendance: 'hro_attendance', hrLeaves: 'hro_leaves', hrHolidays: 'hro_holidays',
  hrPayrolls: 'hro_payrolls', hrContracts: 'hro_contracts', hrRecruitments: 'hro_recruitments',
  hrCandidates: 'hro_candidates', hrInterviews: 'hro_interviews', hrAssets: 'hro_assets', hrVehicles: 'hro_vehicles',
  ivDisassemblies: 'iv_disassemblies',
  // 剩余页面逐页独立真实表
  xwbTodo: 'xwb_todo',
  xshopCenter: 'xshop_center', xshopStores: 'xshop_stores', xshopChannels: 'xshop_channels',
  xshopGoodsMaps: 'xshop_goods_maps', xshopOrders: 'xshop_orders', xshopCoupons: 'xshop_coupons',
  xshopPromotions: 'xshop_promotions',
  xprintTemplates: 'xprint_templates', xprintDocTemplates: 'xprint_doc_templates',
  xprintJobs: 'xprint_jobs', xprintRecords: 'xprint_records', xprintLabels: 'xprint_labels',
  xaiCopilot: 'xai_copilot', xaiDocParse: 'xai_doc_parse', xaiOcr: 'xai_ocr',
  xaiForecastRisk: 'xai_forecast_risk', xaiAnomaly: 'xai_anomaly', xaiReconcile: 'xai_reconcile',
  xaiSubjectMatch: 'xai_subject_match', xaiReport: 'xai_report', xaiCs: 'xai_cs',
  xaiKnowledge: 'xai_knowledge', xaiConfig: 'xai_config', xaiPrompts: 'xai_prompts',
  xaiFunctions: 'xai_functions', xaiMcp: 'xai_mcp', xaiAudits: 'xai_audits',
  xsysUsers: 'xsys_users', xsysConfigs: 'xsys_configs', xsysOrgs: 'xsys_orgs', xsysRoles: 'xsys_roles',
  xsysPermissions: 'xsys_permissions', xsysDataScopes: 'xsys_data_scopes', xsysSequences: 'xsys_sequences',
  xsysNos: 'xsys_nos', xsysDicts: 'xsys_dicts', xsysSettings: 'xsys_settings', xsysI18n: 'xsys_i18n',
  xsysAuditLogs: 'xsys_audit_logs', xsysLoginLogs: 'xsys_login_logs', xsysNotifies: 'xsys_notifies',
  xsysFiles: 'xsys_files', xsysJobs: 'xsys_jobs', xsysOpenapi: 'xsys_openapi', xsysWebhooks: 'xsys_webhooks',
  xsysEvents: 'xsys_events', xsysBackups: 'xsys_backups', xsysViewConfigs: 'xsys_view_configs',
  xsysImportExport: 'xsys_import_export', xsysCustomFields: 'xsys_custom_fields', xsysRules: 'xsys_rules',
  xsysAlertRules: 'xsys_alert_rules', xsysReportDesigner: 'xsys_report_designer', xsysPlugins: 'xsys_plugins',
  xsysChangelog: 'xsys_changelog', xsysIntegrations: 'xsys_integrations', xsysSubscriptions: 'xsys_subscriptions',
  xsysFeedback: 'xsys_feedback',
  // 文档第 3 章补齐的三级功能点：由 schemaOverrides/docGap.ts 提供真实字段与种子
  salesDetails: 'doc_sales_details', salesSummaries: 'doc_sales_summaries', salesRankings: 'doc_sales_rankings',
  salesReturnReasons: 'doc_sales_return_reasons', salesCommissions: 'doc_sales_commissions',
  purchaseSupplierContacts: 'doc_pur_supplier_contacts', purchaseImports: 'doc_pur_imports',
  purchaseFines: 'doc_pur_fines', purchasePriceHistory: 'doc_pur_price_history',
  purchaseDetails: 'doc_pur_details', purchaseSummaries: 'doc_pur_summaries', purchaseSupplierRankings: 'doc_pur_supplier_rankings',
  inventoryProductCreates: 'doc_inv_product_creates', inventoryProductImports: 'doc_inv_product_imports',
  inventoryProductImportUpdates: 'doc_inv_product_import_updates', inventoryProductBarcodes: 'doc_inv_product_barcodes',
  inventoryBatchTraces: 'doc_inv_batch_traces', inventoryMaterialReturns: 'doc_inv_material_returns',
  inventoryOtherInOuts: 'doc_inv_other_in_outs', inventoryNegativeStocks: 'doc_inv_negative_stocks',
  manufacturingWorkOrderProgress: 'doc_mf_work_order_progress', manufacturingLossAnalysis: 'doc_mf_loss_analysis',
  financeDashboards: 'doc_fin_dashboards', financeProfitLoss: 'doc_fin_profit_loss', financeBalanceSheets: 'doc_fin_balance_sheets',
  financeTaxSummaries: 'doc_fin_tax_summaries', financeExpensesNew: 'doc_fin_expenses_new', financeBadDebts: 'doc_fin_bad_debts',
  financeCollectionPlans: 'doc_fin_collection_plans', financeAssetDisposals: 'doc_fin_asset_disposals',
  financeAssetChecks: 'doc_fin_asset_checks', financeTaxCodes: 'doc_fin_tax_codes', financeTaxRates: 'doc_fin_tax_rates',
  financeTaxDeclarations: 'doc_fin_tax_declarations',
  collabApprovalTemplates: 'doc_col_approval_templates', collabApprovalCc: 'doc_col_approval_cc',
  collabProjectDashboards: 'doc_col_project_dashboards', collabTimesheets: 'doc_col_timesheets',
  hrHirings: 'doc_hr_hirings', hrAssetLedgers: 'doc_hr_asset_ledgers', hrAssetReturns: 'doc_hr_asset_returns',
  hrAssetScraps: 'doc_hr_asset_scraps', hrDrivers: 'doc_hr_drivers', hrVehicleUses: 'doc_hr_vehicle_uses',
  hrFuelRecords: 'doc_hr_fuel_records', hrVehicleMaintains: 'doc_hr_vehicle_maintains',
  shopGoodsPublications: 'doc_shop_goods_publications', shopStockSyncs: 'doc_shop_stock_syncs',
  shopOrderSyncs: 'doc_shop_order_syncs', shopShipCallbacks: 'doc_shop_ship_callbacks',
  shopFullReductions: 'doc_shop_full_reductions', shopFlashSales: 'doc_shop_flash_sales',
  systemThemes: 'doc_sys_themes', systemPayConfigs: 'doc_sys_pay_configs',
};

/** 状态动作对应的目标状态，与前端业务引擎 docActions 对齐 */
const ACTION_STATUS: Record<string, number> = {
  submit: 1, approve: 2, execute: 3, complete: 3, ship: 3, reconcile: 3,
  reject: 4, void: 9, enable: 1, toggle: 0, apply: 1,
  post: 2, publish: 2, archive: 3, draft: 0, assign: 1, start: 2, finish: 3,
  pay: 3, review: 2, close: 1, open: 0, checkin: 2,
};

@Injectable()
export class SalesExtService {
  constructor(@InjectDataSource() private readonly ds: DataSource, private readonly audit: AuditService) {}

  private tableOf(collection: string): string {
    const table = TABLES[collection];
    if (!table) throw new BizException(BizCode.NOT_FOUND, `未授权的资源：${collection}`);
    return table;
  }

  /** 读取表字段白名单，阻止伪造字段写入 */
  private async columnsOf(table: string): Promise<string[]> {
    const rows: any[] = await this.ds.query(
      'SELECT column_name AS name FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name=?', [table]);
    return rows.map((r) => r.name);
  }

  /** 将前端 camelCase 字段转换为数据库 snake_case */
  private snake(key: string): string { return key.replace(/([A-Z])/g, '_$1').toLowerCase(); }

  /** 数据库 snake_case 转前端 camelCase（保留原键，兼容两种写法） */
  private camel(row: any): any {
    const out = { ...row };
    for (const k of Object.keys(row)) {
      const c = k.replace(/_([a-z])/g, (_, x: string) => x.toUpperCase());
      const v = row[k];
      const p2 = (n: number) => String(n).padStart(2, '0');
      const value = v instanceof Date
        ? `${v.getFullYear()}-${p2(v.getMonth() + 1)}-${p2(v.getDate())} ${p2(v.getHours())}:${p2(v.getMinutes())}:${p2(v.getSeconds())}`
        : v;
      out[k] = value;
      if (c !== k) out[c] = value;
    }
    return out;
  }

  /** 列表：支持分页、状态与关键字（覆盖单号/名称/产品名） */
  async list(collection: string, q: any) {
    const table = this.tableOf(collection);
    const ctx = currentContext();
    const { page, pageSize, skip } = normalizePage(q.page, q.pageSize);
    const args: any[] = [ctx.tenantId];
    let where = 'tenant_id=? AND is_deleted=0';
    const docResource = table.startsWith('doc_');
    const columns = docResource || q.keyword ? await this.columnsOf(table) : [];
    if (docResource) {
      const excluded = ['id', 'tenant_id', 'is_deleted', 'created_by', 'updated_by', 'created_at', 'updated_at'];
      for (const [field, value] of Object.entries(q)) {
        const col = this.snake(field);
        if (!columns.includes(col) || excluded.includes(col) || typeof value !== 'string' || !value.trim()) continue;
        where += ` AND \`${col}\`=?`;
        args.push(value);
      }
    } else if (q.status !== undefined && q.status !== '') {
      where += ' AND status=?';
      args.push(Number(q.status));
    }
    if (q.keyword) {
      const searchable = ['name', 'title', 'code', 'remark', 'product_name', 'partner', 'biz_text', 'biz_text2',
        'contract_no', 'order_no', 'shipment_no', 'return_no', 'exchange_no', 'statement_no', 'promo_no', 'quote_no', 'phone'];
      const likeCols = columns.filter((col) => docResource
        ? /(^|_)(name|no|code|phone|title|type|reason|period|operator|employee|provider|station|driver|license|platform|buyer|location|partner|result)$/.test(col)
        : searchable.includes(col));
      if (likeCols.length) {
        const k = `%${q.keyword}%`;
        where += ` AND (${likeCols.map((col) => `\`${col}\` LIKE ?`).join(' OR ')})`;
        likeCols.forEach(() => args.push(k));
      }
    }
    const raw = await this.ds.query(`SELECT * FROM ${table} WHERE ${where} ORDER BY id DESC LIMIT ? OFFSET ?`, [...args, pageSize, skip]);
    const list = raw.map((row: any) => this.camel(row));
    const total: any[] = await this.ds.query(`SELECT COUNT(*) c FROM ${table} WHERE ${where}`, args);
    return pageResult(list, Number(total[0]?.c || 0), page, pageSize);
  }

  /** 新增/编辑：只写表内真实存在的字段 */
  async save(collection: string, dto: any) {
    const table = this.tableOf(collection);
    const ctx = currentContext();
    const cols = await this.columnsOf(table);
    const ignored = new Set(['id', 'tenant_id', 'is_deleted', 'created_at', 'updated_at', 'created_by', 'updated_by']);
    const entries = Object.entries(dto || {})
      .map(([k, v]) => [this.snake(k), v] as [string, any])
      .filter(([k, v]) => cols.includes(k) && !ignored.has(k) && v !== undefined && typeof v !== 'object');
    if (!entries.length) throw new BizException(BizCode.PARAM_INVALID, '没有可保存的字段');
    if (dto.id) {
      const sets = entries.map(([k]) => `${k}=?`).join(',');
      await this.ds.query(`UPDATE ${table} SET ${sets}, updated_by=? WHERE id=? AND tenant_id=?`,
        [...entries.map(([, v]) => v), ctx.userId, dto.id, ctx.tenantId]);
      await this.audit.write('UPDATE', collection, dto.id, dto.name || dto.title || '', '编辑业务单据');
      return { id: Number(dto.id) };
    }
    const keys = ['tenant_id', ...entries.map(([k]) => k), 'created_by'];
    const marks = ['?', ...entries.map(() => '?'), '?'];
    const res: any = await this.ds.query(
      `INSERT INTO ${table} (${keys.join(',')}) VALUES (${marks.join(',')})`,
      [ctx.tenantId, ...entries.map(([, v]) => v), ctx.userId]);
    await this.audit.write('CREATE', collection, res.insertId, dto.name || dto.title || '', '新增业务单据');
    return { id: Number(res.insertId) };
  }

  /** 软删除：保留数据可追溯 */
  async remove(collection: string, id: number) {
    const table = this.tableOf(collection);
    const ctx = currentContext();
    await this.ds.query(`UPDATE ${table} SET is_deleted=1, updated_by=? WHERE id=? AND tenant_id=?`, [ctx.userId, id, ctx.tenantId]);
    await this.audit.write('DELETE', collection, id, '', '软删除业务单据');
    return { id };
  }

  /** 业务动作：状态流转 + 复制；所有动作落库并写审计 */
  async action(collection: string, id: number, key: string, dto: any) {
    const table = this.tableOf(collection);
    const ctx = currentContext();
    const columns = await this.columnsOf(table);
    const statusCol = ['status', 'state', 'biz_status'].find((c) => columns.includes(c));
    const rows: any[] = await this.ds.query(`SELECT * FROM ${table} WHERE id=? AND tenant_id=?`, [id, ctx.tenantId]);
    const row = rows[0];
    if (!row) throw new BizException(BizCode.NOT_FOUND, '单据不存在或已删除');
    if (key === 'copy') {
      const cols = columns.filter((c) => !['id', 'created_at', 'updated_at', 'created_by', 'updated_by'].includes(c));
      const vals = cols.map((c) => c === 'tenant_id' ? ctx.tenantId : (c === 'created_by' ? ctx.userId : row[c]));
      const res: any = await this.ds.query(
        `INSERT INTO ${table} (${cols.join(',')}) VALUES (${cols.map(() => '?').join(',')})`, vals);
      return { id: Number(res.insertId), message: '已复制为新单据' };
    }
    const next = ACTION_STATUS[key];
    if (next === undefined) return { id, status: row[statusCol || 'status'], message: `${dto?.label || key} 已完成` };
    if (!statusCol) throw new BizException(BizCode.PARAM_INVALID, '该业务对象没有状态字段，无法流转');
    await this.ds.query(`UPDATE ${table} SET ${statusCol}=?, updated_by=? WHERE id=? AND tenant_id=?`, [next, ctx.userId, id, ctx.tenantId]);
    await this.audit.write(key.toUpperCase(), collection, id, row.name || row.title || row.contract_no || '', `${dto?.label || key}：状态 ${row[statusCol]} → ${next}`);
    return { id, status: next, message: `${dto?.label || key}成功` };
  }
}

const VIEW_PERMS = [
  'crm:customer:view', 'purchase:order:view', 'purchase:supplier:view', 'purchase:report:view',
  'finance:voucher:view', 'finance:report:view', 'finance:account:view', 'finance:subject:view',
  'collab:approval:view', 'collab:task:view', 'collab:project:view',
  'hr:employee:view', 'hr:org:view', 'hr:recruitment:view',
];
const EDIT_PERMS = [
  'crm:customer:edit', 'purchase:order:edit', 'purchase:supplier:edit',
  'finance:voucher:edit', 'finance:subject:edit', 'finance:payment:create',
  'collab:approval:edit', 'collab:task:edit', 'hr:employee:edit', 'hr:recruitment:edit',
];

@Controller('api/v1')
class SalesExtController {
  constructor(private readonly service: SalesExtService) {}

  /** 通用列表：/api/v1/crm/contacts?page=1 等 */
  @Get(':group/:resource') @RequirePerm(...VIEW_PERMS)
  list(@Param('group') g: string, @Param('resource') r: string, @Query() q: any) {
    return this.service.list(g + r.replace(/(^|-)([a-z])/g, (_, __, c) => c.toUpperCase()), q);
  }

  @Post(':group/:resource') @RequirePerm(...EDIT_PERMS)
  save(@Param('group') g: string, @Param('resource') r: string, @Body() dto: any) {
    return this.service.save(g + r.replace(/(^|-)([a-z])/g, (_, __, c) => c.toUpperCase()), dto);
  }

  @Patch(':group/:resource/:id') @RequirePerm(...EDIT_PERMS)
  patch(@Param('group') g: string, @Param('resource') r: string, @Param('id') id: number, @Body() dto: any) {
    return this.service.save(g + r.replace(/(^|-)([a-z])/g, (_, __, c) => c.toUpperCase()), { ...dto, id: Number(id) });
  }

  @Delete(':group/:resource/:id') @RequirePerm(...EDIT_PERMS)
  remove(@Param('group') g: string, @Param('resource') r: string, @Param('id') id: number) {
    return this.service.remove(g + r.replace(/(^|-)([a-z])/g, (_, __, c) => c.toUpperCase()), Number(id));
  }

  /** 前端业务引擎动作入口 */
  @Post('sales-ext/action/:collection/:id/:action') @RequirePerm(...EDIT_PERMS)
  action(@Param('collection') c: string, @Param('id') id: number, @Param('action') a: string, @Body() dto: any) {
    return this.service.action(c, Number(id), a, dto);
  }
}

@Module({ controllers: [OrderReportsController, SalesExtController], providers: [OrderReportsService, SalesExtService, AuditService], exports: [SalesExtService] })
export class SalesExtModule {}
