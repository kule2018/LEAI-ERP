/**
 * 销售客户模块（文档 4.3 销售流程）
 * ------------------------------------------------------------------
 * 状态机：草稿(0) → 待审(1) → 已确认(2) → 完成(4)
 *                                   ↘ 作废(9)
 * 关键联动：
 *  - 确认：锁定库存 occupied++；
 *  - 发货：实物出库 SALE_OUT + 释放锁定 + 写销售成本 + 生成应收 + 自动凭证；
 *  - 收款：由财务模块核销后回写 paid_amount / pay_status；
 *  - 退货：红字出库回补库存（SALE_RETURN）。
 * 注意：所有状态跳转都写审计日志，业务单据只作废不物理删除。
 * ------------------------------------------------------------------
 */
import { Body, Controller, Get, Injectable, Module, Param, ParseIntPipe, Post, Query, HttpCode } from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';
import { DataSource } from 'typeorm';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { DataScope, RequirePerm, normalizePage, pageResult, currentContext, BizException, buildDataScopeWhere, appendDataScope } from '../../common/common';
import { AuditService } from '../../common/audit.service';
import { SequenceService } from '../../common/sequence.service';
import { StockService } from '../inventory/stock.service';
import { InventoryModule } from '../inventory/inventory.module';
import { BizCode, StockVoucherType } from '@erp/shared';
import Decimal from 'decimal.js';

/** 销售单状态常量，避免代码里出现魔法数字 */
const STATUS = { DRAFT: 0, SUBMITTED: 1, CONFIRMED: 2, PARTIAL: 3, DONE: 4, CANCELLED: 9 } as const;

@Injectable()
export class SalesService {
  constructor(
    @InjectDataSource() private readonly dataSource: DataSource,
    private readonly seq: SequenceService,
    private readonly stock: StockService,
    private readonly audit: AuditService,
    private readonly events: EventEmitter2,
  ) {}

  /** 清单销售列表：带统计卡片数据（单数/合计/已收/未收） */
  async list(query: any) {
    const ctx = currentContext();
    const { page, pageSize, skip } = normalizePage(query.page, query.pageSize);
    const where: string[] = ['o.tenant_id = ?', 'o.is_deleted = 0'];
    const args: any[] = [ctx.tenantId];
    if (query.keyword) { where.push('(o.order_no LIKE ? OR c.name LIKE ? OR c.phone LIKE ?)'); args.push(`%${query.keyword}%`, `%${query.keyword}%`, `%${query.keyword}%`); }
    if (query.customerId) { where.push('o.customer_id = ?'); args.push(query.customerId); }
    if (query.warehouseId) { where.push('o.warehouse_id = ?'); args.push(query.warehouseId); }
    if (query.status !== undefined && query.status !== '') { where.push('o.status = ?'); args.push(query.status); }
    if (query.payStatus !== undefined && query.payStatus !== '') { where.push('o.pay_status = ?'); args.push(query.payStatus); }
    if (query.shipStatus !== undefined && query.shipStatus !== '') { where.push('o.ship_status = ?'); args.push(query.shipStatus); }
    if (query.startDate) { where.push('o.order_date >= ?'); args.push(query.startDate); }
    if (query.endDate) { where.push('o.order_date <= ?'); args.push(query.endDate); }
    // 行级数据权限：接口声明 ORG，结合用户 dataScope 生成 SQL 片段
    appendDataScope(where, args, buildDataScopeWhere('ORG', ctx, 'o', { creatorCol: 'created_by' }));

    const list = await this.dataSource.query(
      `SELECT o.*, c.name AS customer_name, c.phone AS customer_phone
         FROM sale_order o LEFT JOIN customer c ON c.id = o.customer_id
        WHERE ${where.join(' AND ')} ORDER BY o.id DESC LIMIT ? OFFSET ?`,
      [...args, pageSize, skip],
    );
    const totalRows = await this.dataSource.query(`SELECT COUNT(*) AS c FROM sale_order o WHERE ${where.join(' AND ')}`, args);
    const statRows = await this.dataSource.query(
      `SELECT COUNT(*) AS order_count, IFNULL(SUM(o.total_amount),0) AS total_amount,
              IFNULL(SUM(o.paid_amount),0) AS paid_amount,
              IFNULL(SUM(o.total_amount) - SUM(o.paid_amount),0) AS unpaid_amount
         FROM sale_order o WHERE ${where.join(' AND ')}`, args,
    );
    return { ...pageResult(list, Number(totalRows[0]?.c || 0), page, pageSize), summary: statRows[0] || {} };
  }

  async detail(id: number) {
    const ctx = currentContext();
    const rows: any[] = await this.dataSource.query(
      `SELECT o.*, c.name AS customer_name, c.phone AS customer_phone, c.credit_limit
         FROM sale_order o LEFT JOIN customer c ON c.id = o.customer_id
        WHERE o.id=? AND o.tenant_id=? AND o.is_deleted=0`, [id, ctx.tenantId]);
    if (!rows.length) throw new BizException(BizCode.NOT_FOUND, '销售单不存在');
    const lines = await this.dataSource.query(
      `SELECT l.*, p.name AS product_name, p.code AS product_code, p.type AS product_type
         FROM sale_order_line l LEFT JOIN product p ON p.id = l.product_id
        WHERE l.order_id=? AND l.tenant_id=? ORDER BY l.id`, [id, ctx.tenantId]);
    return { ...rows[0], lines };
  }

  /**
   * 新建 / 更新销售单（草稿态可改，已确认后不允许改）
   * @param dto 含 customerId / warehouseId / lines[] / remark
   */
  async save(dto: any, id?: number) {
    const ctx = currentContext();
    const lines: any[] = Array.isArray(dto.lines) ? dto.lines : [];
    if (!lines.length) throw new BizException(BizCode.PARAM_INVALID, '请至少录入一行商品明细');

    // 1) 金额一律用 decimal.js 计算，禁止 JS 浮点直接运算
    let total = new Decimal(0);
    const prepared = lines.map((l) => {
      const qty = new Decimal(l.qty || 0);
      const price = new Decimal(l.unitPrice ?? l.price ?? 0);
      const discount = new Decimal(l.discount || 0);
      const amount = qty.times(price).minus(discount);
      total = total.plus(amount);
      return { line: l, qty, price, discount, amount };
    });

    if (id) {
      const old = await this.detail(id);
      if (Number(old.status) !== STATUS.DRAFT) throw new BizException(BizCode.STATUS_ILLEGAL, '仅草稿单可修改');
      await this.dataSource.query(
        `UPDATE sale_order SET customer_id=?, warehouse_id=?, order_date=?, total_amount=?, remark=?, updated_by=? WHERE id=? AND tenant_id=?`,
        [dto.customerId || null, dto.warehouseId || null, dto.orderDate ? new Date(dto.orderDate) : new Date(),
          total.toDecimalPlaces(4).toString(), dto.remark || null, ctx.userId, id, ctx.tenantId],
      );
      await this.dataSource.query(`DELETE FROM sale_order_line WHERE order_id=? AND tenant_id=?`, [id, ctx.tenantId]);
      await this.audit.writeDiff('UPDATE', 'SALE_ORDER', id, old.order_no,
        { total_amount: old.total_amount, customer_id: old.customer_id, remark: old.remark },
        { total_amount: total.toDecimalPlaces(4).toString(), customer_id: dto.customerId || null, remark: dto.remark || null },
        ['total_amount']);
    } else {
      const orderNo = await this.seq.next('SO');
      const res: any = await this.dataSource.query(
        `INSERT INTO sale_order (tenant_id, order_no, customer_id, warehouse_id, order_date, status, total_amount, remark, created_by)
         VALUES (?,?,?,?,?,?,?,?,?)`,
        [ctx.tenantId, orderNo, dto.customerId || null, dto.warehouseId || null,
          dto.orderDate ? new Date(dto.orderDate) : new Date(), STATUS.DRAFT, total.toDecimalPlaces(4).toString(), dto.remark || null, ctx.userId],
      );
      id = res.insertId;
      await this.audit.writeDiff('CREATE', 'SALE_ORDER', id, orderNo, null,
        { total_amount: total.toDecimalPlaces(4).toString(), customer_id: dto.customerId || null, warehouse_id: dto.warehouseId || null },
        ['total_amount']);
    }

    // 2) 重写明细行
    for (const p of prepared) {
      await this.dataSource.query(
        `INSERT INTO sale_order_line (tenant_id, order_id, product_id, variant_id, batch_id, warehouse_id, qty, unit_price, discount, amount)
         VALUES (?,?,?,?,?,?,?,?,?,?)`,
        [ctx.tenantId, id, p.line.productId, p.line.variantId || 0, p.line.batchId || 0, p.line.warehouseId || dto.warehouseId || null,
          p.qty.toString(), p.price.toDecimalPlaces(4).toString(), p.discount.toDecimalPlaces(4).toString(), p.amount.toDecimalPlaces(4).toString()],
      );
    }
    return { id, total: total.toString() };
  }

  /** 提交审批：草稿 → 待审 */
  async submit(id: number) {
    return this.transit(id, STATUS.DRAFT, STATUS.SUBMITTED, '提交审批');
  }

  /** 审批、确认：待审 → 已确认，并锁定库存 */
  async confirm(id: number) {
    const order = await this.detail(id);
    if (Number(order.status) !== STATUS.SUBMITTED) throw new BizException(BizCode.STATUS_ILLEGAL, '仅待审单可确认');

    // 信用额度校验：超额度直接拒绝，避免坏账
    if (order.customer_id && Number(order.credit_limit || 0) > 0) {
      const debtRows: any[] = await this.dataSource.query(
        `SELECT IFNULL(SUM(amount - received_amount),0) AS debt FROM receivable
          WHERE tenant_id=? AND customer_id=? AND is_deleted=0 AND status <> 2`, [currentContext().tenantId, order.customer_id]);
      const debt = new Decimal(debtRows[0]?.debt || 0).plus(order.total_amount);
      if (debt.greaterThan(order.credit_limit)) {
        throw new BizException(BizCode.CREDIT_LIMIT_EXCEEDED, `客户信用额度不足：额度 ${order.credit_limit}，将占用 ${debt.toString()}`);
      }
    }

    // 锁定库存：occupied++，任一行不足则整体失败
    for (const line of order.lines) {
      if (!line.warehouse_id) continue;
      await this.stock.occupy(StockVoucherType.SALE_OUT, id, {
        warehouseId: Number(line.warehouse_id), productId: Number(line.product_id),
        variantId: Number(line.variant_id || 0), batchId: Number(line.batch_id || 0), qty: Number(line.qty),
      }, 1);
    }
    await this.transit(id, STATUS.SUBMITTED, STATUS.CONFIRMED, '确认并锁定库存');
    return { id };
  }

  /**
   * 发货：实物出库 + 释放锁定 + 结转成本 + 生成应收 + 自动凭证。
   * 支持按明细部分发货；全部发完后单据进入「完成」。
   */
  async ship(id: number, body?: { lines?: { lineId: number; qty: number }[] }) {
    const ctx = currentContext();
    const order = await this.detail(id);
    if (!( [STATUS.CONFIRMED, STATUS.PARTIAL] as number[] ).includes(Number(order.status))) {
      throw new BizException(BizCode.STATUS_ILLEGAL, '仅已确认/部分发货的单据可发货');
    }

    await this.dataSource.query('START TRANSACTION');
    try {
      let totalCost = new Decimal(0);
      for (const line of order.lines) {
        // 指定发货量优先，否则发剩余未发量
        const req = (body?.lines || []).find((l) => l.lineId === line.id);
        const remain = new Decimal(line.qty).minus(line.shipped_qty || 0);
        const shipQty = req ? new Decimal(req.qty) : remain;
        if (shipQty.lte(0)) continue;
        if (shipQty.greaterThan(remain)) throw new BizException(BizCode.PARAM_INVALID, `发货量不能超过未发量：${line.product_name}`);

        const warehouseId = Number(line.warehouse_id || order.warehouse_id || 0);
        if (!warehouseId) throw new BizException(BizCode.PARAM_INVALID, '明细行缺少仓库');

        // 1) 释放锁定并实物出库（成本为 0 时挂暂估）
        await this.stock.occupy(StockVoucherType.SALE_OUT, id, {
          warehouseId, productId: Number(line.product_id), variantId: Number(line.variant_id || 0),
          batchId: Number(line.batch_id || 0), qty: shipQty.toNumber(),
        }, -1);
        const out = await this.stock.postOut(StockVoucherType.SALE_OUT, id, {
          warehouseId, productId: Number(line.product_id), variantId: Number(line.variant_id || 0),
          batchId: Number(line.batch_id || 0), qty: shipQty.toNumber(),
        }, true);
        const lineCost = new Decimal(out.cost).times(shipQty);
        totalCost = totalCost.plus(lineCost);

        // 2) 回写明细已发量与成本
        const newShipped = remain.minus(shipQty).lte(0);
        await this.dataSource.query(
          `UPDATE sale_order_line SET shipped_qty = shipped_qty + ?, cost = ? WHERE id=? AND tenant_id=?`,
          [shipQty.toString(), new Decimal(out.cost).toDecimalPlaces(4).toString(), line.id, ctx.tenantId],
        );
        if (newShipped) {
          await this.dataSource.query(`UPDATE sale_order_line SET shipped_qty = qty WHERE id=?`, [line.id]);
        }
      }

      // 3) 更新发货状态：回查数据库判断，避免用发货前的旧 shipped_qty 误判为部分发货
      const freshLines: any[] = await this.dataSource.query(`SELECT qty, shipped_qty FROM sale_order_line WHERE order_id=? AND tenant_id=?`, [id, ctx.tenantId]);
      const shipStatus = freshLines.length > 0 && freshLines.every((l: any) => new Decimal(l.qty).lte(new Decimal(l.shipped_qty || 0))) ? 2 : 1;
      const newStatus = shipStatus === 2 ? STATUS.DONE : STATUS.PARTIAL;
      await this.dataSource.query(`UPDATE sale_order SET ship_status=?, status=?, updated_by=? WHERE id=? AND tenant_id=?`,
        [shipStatus, newStatus, ctx.userId, id, ctx.tenantId]);
      await this.audit.write('AUDIT', 'SALE_ORDER', id, order.order_no, `发货，发货状态 ${shipStatus}`);

      // 4) 生成应收（仅首次发货时建账单）
      const exists: any[] = await this.dataSource.query(
        `SELECT id FROM receivable WHERE tenant_id=? AND source_type='SALE_ORDER' AND source_id=?`, [ctx.tenantId, id]);
      if (!exists.length && Number(order.customer_id)) {
        await this.dataSource.query(
          `INSERT INTO receivable (tenant_id, customer_id, source_type, source_id, amount, received_amount, due_date, status)
           VALUES (?,?, 'SALE_ORDER', ?, ?, 0, DATE_ADD(CURDATE(), INTERVAL 30 DAY), 0)`,
          [ctx.tenantId, order.customer_id, id, order.total_amount],
        );
      }

      // 5) 自动凭证：借 应收账款 / 贷 主营业务收入 + 销项税（税率取系统参数）
      await this.events.emitAsync('finance.autoVoucher', {
        sourceType: 'SALE_ORDER', sourceId: id, voucherDate: new Date(),
        summary: `销售确认 ${order.order_no}`,
        entries: await this.buildSaleEntries(order, totalCost),
      });

      await this.dataSource.query('COMMIT');
      return { id, shipStatus, status: newStatus };
    } catch (e) {
      await this.dataSource.query('ROLLBACK');
      throw e;
    }
  }

  /** 作废：只有未发货单据可作废，并释放锁定 */
  async void(id: number) {
    const order = await this.detail(id);
    if (Number(order.ship_status || 0) !== 0) throw new BizException(BizCode.STATUS_ILLEGAL, '已发货单据不可作废，请走退货流程');
    for (const line of order.lines) {
      if (!line.warehouse_id || Number(line.shipped_qty || 0) > 0) continue;
      if (Number(order.status) === STATUS.CONFIRMED) {
        await this.stock.occupy(StockVoucherType.SALE_OUT, id, {
          warehouseId: Number(line.warehouse_id), productId: Number(line.product_id),
          variantId: Number(line.variant_id || 0), batchId: Number(line.batch_id || 0), qty: Number(line.qty),
        }, -1);
      }
    }
    await this.dataSource.query(`UPDATE sale_order SET status=9, is_deleted=1, updated_by=? WHERE id=? AND tenant_id=?`, [currentContext().userId, id, currentContext().tenantId]);
    await this.audit.write('VOID', 'SALE_ORDER', id, order.order_no, '销售单作废');
    // 作废单据尾号回到补号池，后续开单优先复用，避免断号
    await this.seq.release('SO', order.order_no || '', 0);
    return { id };
  }

  /** 复制：把原单明细复制成新草稿，便于快速开单 */
  async copy(id: number) {
    const order = await this.detail(id);
    return this.save({
      customerId: order.customer_id, warehouseId: order.warehouse_id, remark: order.remark,
      lines: order.lines.map((l: any) => ({
        productId: l.product_id, variantId: l.variant_id, batchId: l.batch_id,
        warehouseId: l.warehouse_id, qty: l.qty, unitPrice: l.unit_price, discount: l.discount,
      })),
    });
  }

  /** 销售退货：红字入库回补库存，生成红字应收 */
  async returns(id: number, dto: { lines: { lineId: number; qty: number }[]; remark?: string }) {
    const ctx = currentContext();
    const order = await this.detail(id);
    if (!Array.isArray(dto.lines) || !dto.lines.length) throw new BizException(BizCode.PARAM_INVALID, '请选择退货明细');
    for (const r of dto.lines) {
      const line = order.lines.find((l: any) => l.id === r.lineId);
      if (!line) continue;
      if (new Decimal(r.qty).greaterThan(new Decimal(line.shipped_qty || 0))) {
        throw new BizException(BizCode.PARAM_INVALID, `退货量不能超过已发货量：${line.product_name}`);
      }
      await this.stock.postIn(StockVoucherType.SALE_RETURN, id, {
        warehouseId: Number(line.warehouse_id || order.warehouse_id),
        productId: Number(line.product_id), variantId: Number(line.variant_id || 0),
        batchId: Number(line.batch_id || 0), qty: Number(r.qty), cost: Number(line.cost || 0),
      });
    }
    await this.audit.write('CREATE', 'SALE_RETURN', id, order.order_no, `销售退货：${JSON.stringify(dto.lines)}`);
    return { id };
  }

  // ---------------- 内部方法 ----------------

  private async transit(id: number, from: number, to: number, action: string) {
    const ctx = currentContext();
    const rows: any = await this.dataSource.query(`SELECT status, order_no FROM sale_order WHERE id=? AND tenant_id=? AND is_deleted=0`, [id, ctx.tenantId]);
    if (!rows[0]) throw new BizException(BizCode.NOT_FOUND, '销售单不存在');
    if (Number(rows[0].status) !== from) throw new BizException(BizCode.STATUS_ILLEGAL, `状态不允许：${action}`);
    await this.dataSource.query(`UPDATE sale_order SET status=?, updated_by=? WHERE id=? AND tenant_id=?`, [to, ctx.userId, id, ctx.tenantId]);
    await this.audit.write('AUDIT', 'SALE_ORDER', id, rows[0].order_no, action);
    return { id, status: to };
  }

  /** 构造销售凭证分录：借 应收 / 贷 收入 + 销项税；并附上成本结转分录 */
  private async buildSaleEntries(order: any, totalCost: Decimal) {
    const rows: any[] = await this.dataSource.query(
      `SELECT code, id FROM account_subject WHERE tenant_id=? AND code IN ('1122','6001','2221','6401','1405')`, [currentContext().tenantId]);
    const map: Record<string, number> = {};
    for (const r of rows) map[r.code] = Number(r.id);
    const cfg: any[] = await this.dataSource.query(`SELECT cfg_value FROM sys_config WHERE tenant_id=? AND cfg_key='tax_rate'`, [currentContext().tenantId]);
    const rate = new Decimal(cfg[0]?.cfg_value || 0.13);
    const total = new Decimal(order.total_amount);
    const tax = total.dividedBy(rate.plus(1)).times(rate);
    const income = total.minus(tax);

    const entries: any[] = [];
    if (map['1122']) entries.push({ subjectId: map['1122'], debit: total.toString(), credit: '0', summary: '应收客户款' });
    if (map['6001']) entries.push({ subjectId: map['6001'], debit: '0', credit: income.toDecimalPlaces(4).toString(), summary: '主营业务收入' });
    if (map['2221']) entries.push({ subjectId: map['2221'], debit: '0', credit: tax.toDecimalPlaces(4).toString(), summary: '应交税费-销项' });
    if (!totalCost.isZero() && map['6401'] && map['1405']) {
      entries.push({ subjectId: map['6401'], debit: totalCost.toDecimalPlaces(4).toString(), credit: '0', summary: '结转销售成本' });
      entries.push({ subjectId: map['1405'], debit: '0', credit: totalCost.toDecimalPlaces(4).toString(), summary: '减少库存商品' });
    }
    return entries;
  }
}

@Controller('api/v1/sales/orders')
class SalesController {
  constructor(private readonly service: SalesService) {}

  @Get() @RequirePerm('sales:order:view') @DataScope('ORG')
  list(@Query() query: any) { return this.service.list(query); }

  @Get(':id') @RequirePerm('sales:order:view')
  detail(@Param('id', ParseIntPipe) id: number) { return this.service.detail(id); }

  @Post() @RequirePerm('sales:order:create')
  create(@Body() dto: any) { return this.service.save(dto); }

  @Post(':id') @RequirePerm('sales:order:edit')
  update(@Param('id', ParseIntPipe) id: number, @Body() dto: any) { return this.service.save(dto, id); }

  @Post(':id/submit') @RequirePerm('sales:order:audit')
  submit(@Param('id', ParseIntPipe) id: number) { return this.service.submit(id); }

  @Post(':id/confirm') @RequirePerm('sales:order:audit')
  confirm(@Param('id', ParseIntPipe) id: number) { return this.service.confirm(id); }

  @Post(':id/ship') @RequirePerm('sales:order:ship')
  ship(@Param('id', ParseIntPipe) id: number, @Body() body: any) { return this.service.ship(id, body); }

  @Post(':id/void') @RequirePerm('sales:order:void')
  void(@Param('id', ParseIntPipe) id: number) { return this.service.void(id); }

  @Post(':id/copy') @RequirePerm('sales:order:create')
  copy(@Param('id', ParseIntPipe) id: number) { return this.service.copy(id); }

  @Post(':id/return') @RequirePerm('sales:order:edit')
  returns(@Param('id', ParseIntPipe) id: number, @Body() dto: any) { return this.service.returns(id, dto); }
}

@Module({
  imports: [InventoryModule],
  controllers: [SalesController],
  providers: [SalesService, SequenceService, AuditService],
  exports: [SalesService],
})
export class SalesModule {}
