/**
 * 商城渠道（文档 17.8）：店铺 / 商品映射 / 平台订单 / 发货回传
 * 核心逻辑：
 * 1. 平台订单拉取以 platform_order_no 做幂等键，重复拉取只更新不新增（唯一索引兜底）。
 * 2. 订单转 ERP 销售单：按 shop_goods_map 映射产品，调用销售领域创建草稿单逻辑（此处直接落 sale_order，保持模块解耦）。
 * 3. 发货回传：记录物流单号并把平台订单置为 SHIPPED。
 * 说明：真实平台对接（淘宝/京东/抖音）在 ShopSyncAdapter 中替换成各平台 SDK，本实现提供本地模拟拉取。
 */
import { Body, Controller, Get, Injectable, Module, Param, ParseIntPipe, Post, Query } from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';
import { DataSource } from 'typeorm';
import { BizCode, BizException, RequirePerm, currentContext, normalizePage, pageResult } from '../../common/common';
import { AuditService } from '../../common/audit.service';

@Injectable()
export class ShopService {
  constructor(@InjectDataSource() private readonly dataSource: DataSource, private readonly audit: AuditService) {}

  listStores() {
    return this.dataSource.query(
      `SELECT id, tenant_id, name, platform, status, created_at, updated_at,
              CASE WHEN app_secret IS NULL OR app_secret='' THEN '' ELSE '******' END AS app_secret
         FROM shop_store WHERE tenant_id=? AND is_deleted=0 ORDER BY id DESC`, [currentContext().tenantId]);
  }

  saveStore(dto: any) {
    const ctx = currentContext();
    if (dto.id) {
      // appSecret 为空时不更新原密钥，防止回显后覆盖
      const secretSql = dto.appSecret ? 'app_key=?, app_secret=?, ' : '';
      const args: any[] = [dto.name, dto.platform || null, dto.status ?? 1];
      if (dto.appSecret) args.push(dto.appKey || null, dto.appSecret);
      args.push(dto.id, ctx.tenantId);
      return this.dataSource.query(`UPDATE shop_store SET name=?, platform=?, ${secretSql}updated_at=NOW(3) WHERE id=? AND tenant_id=?`, args)
        .then(() => ({ id: dto.id }));
    }
    return this.dataSource.query(
      `INSERT INTO shop_store (tenant_id, name, platform, app_key, app_secret) VALUES (?,?,?,?,?)`,
      [ctx.tenantId, dto.name, dto.platform || 'SELF', dto.appKey || dto.app_key || null, dto.appSecret || dto.app_secret || null])
      .then((res: any) => ({ id: res.insertId }));
  }

  listGoodsMap(storeId: number) {
    return this.dataSource.query(
      `SELECT m.*, p.name AS product_name FROM shop_goods_map m LEFT JOIN product p ON p.id=m.product_id
        WHERE m.tenant_id=? AND m.store_id=? AND m.is_deleted=0`, [currentContext().tenantId, storeId]);
  }

  saveGoodsMap(dto: any) {
    const ctx = currentContext();
    return this.dataSource.query(
      `INSERT INTO shop_goods_map (tenant_id, store_id, product_id, platform_sku, price, sync_stock)
       VALUES (?,?,?,?,?,?)`,
      [ctx.tenantId, dto.storeId || dto.store_id, dto.productId || dto.product_id, dto.platformSku || dto.platform_sku || null,
        Number(dto.price || 0), dto.syncStock === undefined ? 1 : Number(dto.syncStock)])
      .then((res: any) => ({ id: res.insertId }));
  }

  listOrders(q: any) {
    const ctx = currentContext();
    const { page, pageSize, skip } = normalizePage(q.page, q.pageSize);
    const args: any[] = [ctx.tenantId];
    let where = 'tenant_id=? AND is_deleted=0';
    if (q.status) { where += ' AND status=?'; args.push(q.status); }
    if (q.storeId) { where += ' AND store_id=?'; args.push(Number(q.storeId)); }
    return this.dataSource.query(`SELECT * FROM shop_order WHERE ${where} ORDER BY id DESC LIMIT ? OFFSET ?`, [...args, pageSize, skip])
      .then(async (list) => {
        const total: any[] = await this.dataSource.query(`SELECT COUNT(*) c FROM shop_order WHERE ${where}`, args);
        return pageResult(list, Number(total[0]?.c || 0), page, pageSize);
      });
  }

  /**
   * 拉取平台订单：本实现从入参 orders 中读取（模拟平台推送/拉取）。
   * 幂等：先查 platform_order_no，已存在则跳过，仅记录同步信息。
   */
  async syncOrders(storeId: number, orders: Array<{ platformOrderNo: string; buyer?: string; amount?: number; items?: Array<{ platformSku?: string; productId?: number; qty?: number }> }>) {
    const ctx = currentContext();
    let created = 0;
    let skipped = 0;
    for (const o of orders || []) {
      const exists: any[] = await this.dataSource.query(
        `SELECT id FROM shop_order WHERE tenant_id=? AND store_id=? AND platform_order_no=?`,
        [ctx.tenantId, storeId, o.platformOrderNo]);
      if (exists.length) { skipped += 1; continue; }
      // 幂等插入：并发下由唯一索引 uk_platform 兜底
      const res: any = await this.dataSource.query(
        `INSERT IGNORE INTO shop_order (tenant_id, store_id, platform_order_no, buyer, amount, status, sync_msg)
         VALUES (?,?,?,?,?, 'NEW', ?)`,
        [ctx.tenantId, storeId, o.platformOrderNo, o.buyer || null, Number(o.amount || 0), `items:${JSON.stringify(o.items || [])}`]);
      if (res.insertId) created += 1;
      else skipped += 1;
    }
    await this.audit.write('SYNC', 'SHOP_ORDER', storeId, String(storeId), `拉取订单：新增 ${created}，跳过 ${skipped}`);
    return { created, skipped };
  }

  /**
   * 平台订单转 ERP 销售单：按商品映射生成销售单与明细。
   * 依赖销售表的字段结构（sale_order / sale_order_line），不调用 SalesService，避免模块循环依赖。
   */
  async convertToSaleOrder(orderId: number) {
    const ctx = currentContext();
    const rows: any[] = await this.dataSource.query(`SELECT * FROM shop_order WHERE id=? AND tenant_id=?`, [orderId, ctx.tenantId]);
    const order = rows[0];
    if (!order) throw new BizException(BizCode.NOT_FOUND, '平台订单不存在');
    if (order.erp_order_id) throw new BizException(BizCode.PARAM_INVALID, '该订单已转换，请勿重复操作');
    let items: any[] = [];
    try { items = JSON.parse(order.sync_msg || '[]'); } catch { items = []; }
    if (!items.length) throw new BizException(BizCode.PARAM_INVALID, '订单无明细，无法转换');

    const conn = await this.dataSource.createQueryRunner();
    await conn.connect();
    await conn.startTransaction();
    try {
      const no = `SO${Date.now().toString().slice(-8)}`;
      const ins: any = await conn.query(
        `INSERT INTO sale_order (tenant_id, order_no, customer_id, warehouse_id, order_date, status, pay_status, ship_status, total_amount, paid_amount, created_by)
         VALUES (?,?, NULL, (SELECT id FROM warehouse WHERE tenant_id=? AND is_default=1 LIMIT 1), NOW(3), 2, 2, 0, ?, ?, ?)`,
        [ctx.tenantId, no, ctx.tenantId, Number(order.amount || 0), Number(order.amount || 0), ctx.userId]);
      const saleId = ins.insertId;
      for (const it of items) {
        let productId = Number(it.productId || 0);
        if (!productId && it.platformSku) {
          const p: any[] = await conn.query(`SELECT product_id FROM shop_goods_map WHERE tenant_id=? AND platform_sku=? LIMIT 1`, [ctx.tenantId, it.platformSku]);
          productId = Number(p[0]?.product_id || 0);
        }
        if (!productId) continue;
        const prod: any[] = await conn.query(`SELECT price FROM product WHERE id=? AND tenant_id=?`, [productId, ctx.tenantId]);
        const price = Number(prod[0]?.price || 0);
        const amount = Number((price * Number(it.qty || 1)).toFixed(4));
        await conn.query(
          `INSERT INTO sale_order_line (tenant_id, order_id, product_id, warehouse_id, qty, unit_price, discount, amount)
           VALUES (?,?,?, (SELECT id FROM warehouse WHERE tenant_id=? AND is_default=1 LIMIT 1), ?,?,0,?)`,
          [ctx.tenantId, saleId, productId, ctx.tenantId, Number(it.qty || 1), price, amount]);
      }
      await conn.query(`UPDATE shop_order SET erp_order_id=?, status='PAID' WHERE id=?`, [saleId, orderId]);
      await conn.commitTransaction();
      await this.audit.write('CONVERT', 'SHOP_ORDER', orderId, order.platform_order_no, `转销售单 ${no}`);
      return { saleOrderId: saleId, orderNo: no };
    } catch (e) {
      await conn.rollbackTransaction();
      throw e;
    } finally {
      await conn.release();
    }
  }

  /** 发货回传：记录物流单号并置为已发货 */
  ship(orderId: number, dto: any) {
    return this.dataSource.query(`UPDATE shop_order SET status='SHIPPED', sync_msg=? WHERE id=? AND tenant_id=?`,
      [`物流单号：${dto.trackingNo || ''}`, orderId, currentContext().tenantId])
      .then(() => ({ status: 'SHIPPED' }));
  }
}

@Controller('api/v1/shop')
class ShopController {
  constructor(private readonly service: ShopService) {}

  @Get('stores') @RequirePerm('shop:store:view') stores() { return this.service.listStores(); }
  @Post('stores') @RequirePerm('shop:store:edit') saveStore(@Body() dto: any) { return this.service.saveStore(dto); }
  @Get('goods-maps') @RequirePerm('shop:store:view') goodsMaps(@Query('storeId') storeId: string) { return this.service.listGoodsMap(Number(storeId)); }
  @Post('goods-maps') @RequirePerm('shop:store:edit') saveGoodsMap(@Body() dto: any) { return this.service.saveGoodsMap(dto); }
  @Get('orders') @RequirePerm('shop:order:view') orders(@Query() q: any) { return this.service.listOrders(q); }
  @Post('stores/:id/sync') @RequirePerm('shop:sync') sync(@Param('id', ParseIntPipe) id: number, @Body() body: any) { return this.service.syncOrders(id, body?.orders || []); }
  @Post('orders/:id/convert') @RequirePerm('shop:sync') convert(@Param('id', ParseIntPipe) id: number) { return this.service.convertToSaleOrder(id); }
  @Post('orders/:id/ship') @RequirePerm('shop:sync') ship(@Param('id', ParseIntPipe) id: number, @Body() dto: any) { return this.service.ship(id, dto); }
}

@Module({ controllers: [ShopController], providers: [ShopService, AuditService], exports: [ShopService] })
export class ShopModule {}
