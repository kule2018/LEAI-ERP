/**
 * 分片上传：init / chunk / status / merge 四个接口。
 * 临时分片与合并后文件都落在本地磁盘 uploads/ 目录，不引入 MinIO 等新依赖。
 * sys_upload_session / sys_upload_chunk 记录进度、重试次数与失败原因。
 */
import {
  Body, Controller, Get, Injectable, Module, Post, Query, Req,
} from '@nestjs/common';
import type { Request } from 'express';
import { InjectDataSource } from '@nestjs/typeorm';
import { DataSource } from 'typeorm';
import { randomUUID } from 'node:crypto';
import { createWriteStream, existsSync, mkdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { join, basename } from 'node:path';
import { BizCode, BizException, currentContext } from '../../common/common';

const TMP_DIR = join(process.cwd(), 'uploads', 'tmp');
const FILE_DIR = join(process.cwd(), 'uploads', 'files');

@Injectable()
export class UploadService {
  constructor(@InjectDataSource() private readonly dataSource: DataSource) {
    mkdirSync(TMP_DIR, { recursive: true });
    mkdirSync(FILE_DIR, { recursive: true });
  }

  /** 初始化上传会话 */
  async init(dto: { fileName: string; fileSize: number; chunkSize?: number; totalChunks?: number; bizType?: string }) {
    if (!dto.fileName) throw new BizException(BizCode.PARAM_INVALID, '文件名不能为空');
    const ctx = currentContext();
    const uploadId = randomUUID();
    const chunkSize = Math.max(64 * 1024, Number(dto.chunkSize || 2 * 1024 * 1024));
    const fileSize = Math.max(0, Number(dto.fileSize || 0));
    const totalChunks = Math.max(1, Number(dto.totalChunks || Math.ceil(fileSize / chunkSize) || 1));
    await this.dataSource.query(
      `INSERT INTO sys_upload_session
        (tenant_id, upload_id, file_name, file_size, chunk_size, total_chunks, uploaded_chunks, status, biz_type, created_by)
       VALUES (?,?,?,?,?,?,0,'UPLOADING',?,?)`,
      [ctx.tenantId, uploadId, basename(String(dto.fileName)), fileSize, chunkSize, totalChunks,
        dto.bizType || null, ctx.userId],
    );
    mkdirSync(join(TMP_DIR, uploadId), { recursive: true });
    return { uploadId, chunkSize, totalChunks };
  }

  /** 接收单个分片：请求体为 application/octet-stream 原始字节流 */
  async chunk(req: Request, uploadId: string, index: number) {
    const ctx = currentContext();
    const sessions: any[] = await this.dataSource.query(
      `SELECT * FROM sys_upload_session WHERE upload_id=? AND tenant_id=?`, [uploadId, ctx.tenantId]);
    const session = sessions[0];
    if (!session) throw new BizException(BizCode.NOT_FOUND, '上传会话不存在');
    if (Number(index) < 0 || Number(index) >= Number(session.total_chunks)) {
      throw new BizException(BizCode.PARAM_INVALID, '分片序号越界');
    }

    const chunkDir = join(TMP_DIR, uploadId);
    mkdirSync(chunkDir, { recursive: true });
    const partPath = join(chunkDir, `${index}.part`);
    try {
      // 逐段收集原始请求流，避免整包进内存后再解析
      const buffers: Buffer[] = [];
      for await (const piece of req as any) buffers.push(Buffer.isBuffer(piece) ? piece : Buffer.from(piece));
      const buf = Buffer.concat(buffers);
      writeFileSync(partPath, buf);
      await this.dataSource.query(
        `INSERT INTO sys_upload_chunk (tenant_id, upload_id, chunk_index, chunk_size, status, retry_count, error)
         VALUES (?,?,?,?, 'DONE', 0, NULL)
         ON DUPLICATE KEY UPDATE chunk_size=VALUES(chunk_size), status='DONE', error=NULL,
           retry_count=CASE WHEN status='FAILED' THEN retry_count+1 ELSE retry_count END`,
        [ctx.tenantId, uploadId, Number(index), buf.length],
      );
    } catch (e: any) {
      await this.dataSource.query(
        `INSERT INTO sys_upload_chunk (tenant_id, upload_id, chunk_index, status, error)
         VALUES (?,?,?, 'FAILED', ?)
         ON DUPLICATE KEY UPDATE status='FAILED', error=VALUES(error), retry_count=retry_count+1`,
        [ctx.tenantId, uploadId, Number(index), String(e?.message || e).slice(0, 500)],
      );
      throw e;
    }

    const done: any[] = await this.dataSource.query(
      `SELECT COUNT(*) c FROM sys_upload_chunk WHERE upload_id=? AND status='DONE'`, [uploadId]);
    await this.dataSource.query(`UPDATE sys_upload_session SET uploaded_chunks=? WHERE upload_id=?`,
      [Number(done[0]?.c || 0), uploadId]);
    return { uploadId, index: Number(index), uploadedChunks: Number(done[0]?.c || 0) };
  }

  /** 查询进度、已完成分片与失败分片（供前端断点续传与失败重试） */
  async status(uploadId: string) {
    const ctx = currentContext();
    const sessions: any[] = await this.dataSource.query(
      `SELECT * FROM sys_upload_session WHERE upload_id=? AND tenant_id=?`, [uploadId, ctx.tenantId]);
    const session = sessions[0];
    if (!session) throw new BizException(BizCode.NOT_FOUND, '上传会话不存在');
    const chunks: any[] = await this.dataSource.query(
      `SELECT chunk_index, chunk_size, status, retry_count, error FROM sys_upload_chunk
        WHERE upload_id=? ORDER BY chunk_index`, [uploadId]);
    const total = Number(session.total_chunks || 1);
    const uploaded = Number(session.uploaded_chunks || 0);
    return {
      uploadId, status: session.status, fileName: session.file_name,
      totalChunks: total, uploadedChunks: uploaded,
      progress: Math.round((uploaded / total) * 1000) / 10,
      chunks,
      failedChunks: chunks.filter((c) => c.status === 'FAILED').map((c) => Number(c.chunk_index)),
    };
  }

  /** 合并分片为最终文件，校验全部分片到位；合并成功后清理临时目录 */
  async merge(uploadId: string) {
    const ctx = currentContext();
    const sessions: any[] = await this.dataSource.query(
      `SELECT * FROM sys_upload_session WHERE upload_id=? AND tenant_id=?`, [uploadId, ctx.tenantId]);
    const session = sessions[0];
    if (!session) throw new BizException(BizCode.NOT_FOUND, '上传会话不存在');
    if (session.status === 'MERGED') return { url: session.final_path, fileName: session.file_name };

    const total = Number(session.total_chunks || 1);
    const chunkDir = join(TMP_DIR, uploadId);
    for (let i = 0; i < total; i++) {
      if (!existsSync(join(chunkDir, `${i}.part`))) {
        throw new BizException(BizCode.PARAM_INVALID, `分片 ${i} 尚未上传完成，无法合并`);
      }
    }
    const finalName = `${Date.now()}_${basename(String(session.file_name))}`;
    const finalPath = join(FILE_DIR, finalName);
    const ws = createWriteStream(finalPath);
    try {
      for (let i = 0; i < total; i++) {
        const buf = readFileSync(join(chunkDir, `${i}.part`));
        await new Promise<void>((resolve, reject) => {
          ws.write(buf, (err?: Error | null) => (err ? reject(err) : resolve()));
        });
      }
      await new Promise<void>((resolve, reject) => {
        ws.end(() => resolve());
        ws.on('error', reject);
      });
    } catch (e) {
      ws.destroy();
      throw e;
    }

    await this.dataSource.query(
      `UPDATE sys_upload_session SET status='MERGED', final_path=?, merged_at=NOW(3) WHERE upload_id=?`,
      [`/uploads/files/${finalName}`, uploadId],
    );
    try { rmSync(chunkDir, { recursive: true, force: true }); } catch { /* 清理失败不影响合并结果 */ }
    return { url: `/uploads/files/${finalName}`, fileName: session.file_name };
  }
}

@Controller('api/v1/upload')
class UploadController {
  constructor(private readonly service: UploadService) {}

  @Post('init')
  init(@Body() dto: any) { return this.service.init(dto || {}); }

  @Post('chunk')
  chunk(@Query('uploadId') uploadId: string, @Query('index') index: string, @Req() req: Request) {
    return this.service.chunk(req, String(uploadId || ''), Number(index));
  }

  @Get('status')
  status(@Query('uploadId') uploadId: string) { return this.service.status(String(uploadId || '')); }

  @Post('merge')
  merge(@Body() dto: any) { return this.service.merge(String(dto?.uploadId || '')); }
}

@Module({ controllers: [UploadController], providers: [UploadService], exports: [UploadService] })
export class UploadModule {}
