/**
 * UX 体验增强基座（文档 24~35 章）
 * 能力：为 sql/05_ux_schema.sql 的 17 张体验增强表提供统一通用 CRUD，
 *       并补充导入进度/错误明细、OpenAPI 签名校验、Webhook 模拟推送、
 *       修订快照、自定义字段解析等专用接口。
 * 安全：表名与列名均来自代码内白名单常量，用户输入只作为 ? 参数传入，禁止字符串拼接。
 * 风格：单文件 Module + Controller + Service + 原生 SQL，与 bpm/bi 模块保持一致。
 */
import {
  Body, Controller, Delete, Get, Injectable, Module, Param,
  ParseIntPipe, Patch, Post, Query,
} from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';
import { DataSource } from 'typeorm';
import { createHmac, timingSafeEqual } from 'node:crypto';
import { BizCode, BizException, RequirePerm, currentContext, normalizePage } from '../../common/common';
import { AuditService } from '../../common/audit.service';

/** 资源名到数据表的映射：只暴露下列白名单资源，杜绝任意表名访问 */
const RESOURCE_TABLES: Record<string, string> = {
  'user-view-configs': 'user_view_config',
  'quick-search-logs': 'quick_search_log',
  'import-tasks': 'import_task',
  'import-errors': 'import_error',
  'export-tasks': 'export_task',
  'notify-rules': 'notify_rule',
  'notify-records': 'notify_record',
  'alert-rules': 'alert_rule',
  'alert-records': 'alert_record',
  'custom-fields': 'custom_field',
  'custom-forms': 'custom_form',
  'revision-snapshots': 'revision_snapshot',
  'audit-field-logs': 'audit_field_log',
  'user-drafts': 'user_draft',
  'user-favorites': 'user_favorite',
  'openapi-keys': 'openapi_key',
  'webhook-logs': 'webhook_log',
};

/** 每张资源允许写入的业务字段（不含公共字段）；列名来自常量，不接受用户输入 */
const RESOURCE_FIELDS: Record<string, string[]> = {
  'user-view-configs': ['route', 'role_code', 'name', 'columns_json', 'filters_json', 'sorts_json', 'density', 'is_default'],
  'quick-search-logs': ['keyword', 'result_type', 'result_id', 'hit_count'],
  'import-tasks': ['biz_type', 'file_name', 'file_url', 'total_rows', 'success_rows', 'fail_rows',
    'status', 'progress', 'mapping_json', 'started_at', 'finished_at'],
  'import-errors': ['task_id', 'row_no', 'field_name', 'field_value', 'reason'],
  'export-tasks': ['biz_type', 'file_name', 'format', 'filters_json', 'columns_json',
    'status', 'progress', 'file_url', 'started_at', 'finished_at'],
  'notify-rules': ['code', 'name', 'biz_type', 'event', 'channel', 'receiver_json', 'template', 'is_active'],
  'notify-records': ['rule_id', 'biz_type', 'biz_id', 'channel', 'receiver', 'title',
    'content', 'status', 'sent_at', 'read_at'],
  'alert-rules': ['code', 'name', 'biz_type', 'metric', 'operator', 'threshold',
    'level', 'channels_json', 'receiver_json', 'is_active'],
  'alert-records': ['rule_id', 'biz_type', 'biz_id', 'level', 'title', 'content',
    'trigger_value', 'status', 'handled_by', 'handled_at'],
  'custom-fields': ['entity', 'field_code', 'field_name', 'field_type', 'options_json',
    'default_value', 'is_required', 'sort', 'is_enabled'],
  'custom-forms': ['entity', 'name', 'layout_json', 'rules_json', 'is_default', 'is_active'],
  'revision-snapshots': ['biz_type', 'biz_id', 'revision', 'action', 'before_json',
    'after_json', 'operator', 'reason'],
  'audit-field-logs': ['biz_type', 'biz_id', 'field_code', 'field_name',
    'before_value', 'after_value', 'is_sensitive', 'operator'],
  'user-drafts': ['biz_type', 'biz_id', 'route', 'content_json', 'saved_at'],
  'user-favorites': ['biz_type', 'biz_id', 'title', 'url'],
  'openapi-keys': ['app_name', 'app_key', 'app_secret', 'permissions_json',
    'ip_whitelist_json', 'rate_limit', 'status', 'last_used_at'],
  'webhook-logs': ['event', 'url', 'payload_json', 'retry_count', 'status', 'response', 'next_retry_at'],
};

@Injectable()
export class UxService {
  constructor(@InjectDataSource() private readonly dataSource: DataSource, private readonly audit: AuditService) {}

  /** 资源名转表名，未命中直接 404，防止任意表访问 */
  private tableOf(resource: string): string {
    const table = RESOURCE_TABLES[resource];
    if (!table) throw new BizException(BizCode.NOT_FOUND, `不支持的资源：${resource}`);
    return table;
  }

  /**
   * 通用列表：按租户与软删除过滤，分页返回。
   * @param resource 资源名（白名单内）
   * @param q 查询参数：page/pageSize 分页
   * @returns 资源行数组
   */
  list(resource: string, q: any) {
    const table = this.tableOf(resource);
    const { page, pageSize, skip } = normalizePage(q.page, q.pageSize);
    return this.dataSource.query(
      `SELECT * FROM ${table} WHERE tenant_id=? AND is_deleted=0 ORDER BY id DESC LIMIT ? OFFSET ?`,
      [currentContext().tenantId, pageSize, skip]);
  }

  /**
   * 通用保存：id 存在则更新，否则新增；值全部走 ? 参数，列名来自白名单常量。
   * 对象类型字段自动 JSON.stringify，同时兼容 camelCase 与下划线输入。
   * @param resource 资源名
   * @param dto 表单数据，id 可选
   * @returns { id } 主键
   */
  async save(resource: string, dto: any) {
    const table = this.tableOf(resource);
    const fields = RESOURCE_FIELDS[resource] || [];
    const ctx = currentContext();
    const values: Record<string, any> = {};
    for (const col of fields) {
      const camel = col.replace(/_([a-z])/g, (_m, c: string) => c.toUpperCase());
      const raw = dto[col] !== undefined ? dto[col] : dto[camel];
      if (raw === undefined) continue;
      values[col] = raw !== null && typeof raw === 'object' ? JSON.stringify(raw) : raw;
    }
    const keys = Object.keys(values);
    if (dto.id) {
      if (!keys.length) return { id: dto.id };
      const sets = keys.map((c) => `${c}=?`).join(',');
      await this.dataSource.query(
        `UPDATE ${table} SET ${sets}, updated_by=? WHERE id=? AND tenant_id=?`,
        [...keys.map((c) => values[c]), ctx.userId, dto.id, ctx.tenantId]);
      return { id: dto.id };
    }
    const cols = ['tenant_id', ...keys, 'created_by'];
    const marks = cols.map(() => '?').join(',');
    const res: any = await this.dataSource.query(
      `INSERT INTO ${table} (${cols.join(',')}) VALUES (${marks})`,
      [ctx.tenantId, ...keys.map((c) => values[c]), ctx.userId]);
    return { id: res.insertId };
  }

  /**
   * 通用软删除：只置 is_deleted=1，带租户过滤，不做物理删除。
   * @param resource 资源名
   * @param id 主键
   */
  async remove(resource: string, id: number) {
    const table = this.tableOf(resource);
    const ctx = currentContext();
    await this.dataSource.query(
      `UPDATE ${table} SET is_deleted=1, updated_by=? WHERE id=? AND tenant_id=?`,
      [ctx.userId, id, ctx.tenantId]);
    return { id, isDeleted: 1 };
  }

  /**
   * 导入进度更新：同步状态/百分比/成功失败行数，完成时写 finished_at。
   * @param id 导入任务主键
   * @param dto status/progress/successRows/failRows
   * @returns { id, status, progress }
   */
  async updateImportProgress(id: number, dto: any) {
    const ctx = currentContext();
    const status = dto.status === undefined ? 1 : Number(dto.status);
    const progress = Math.max(0, Math.min(100, Number(dto.progress || 0)));
    const finished = status === 2 || status === 3 ? 1 : 0;
    await this.dataSource.query(
      `UPDATE import_task SET status=?, progress=?, success_rows=?, fail_rows=?,
         started_at=COALESCE(started_at, NOW(3)),
         finished_at=CASE WHEN ?=1 THEN NOW(3) ELSE finished_at END, updated_by=?
       WHERE id=? AND tenant_id=? AND is_deleted=0`,
      [status, progress, Number(dto.successRows || 0), Number(dto.failRows || 0),
        finished, ctx.userId, id, ctx.tenantId]);
    await this.audit.write('UPDATE', 'IMPORT_TASK', id, String(id), `更新导入进度至 ${progress}%`);
    return { id, status, progress };
  }

  /**
   * 导入错误明细：按行号返回某任务的全部失败原因。
   * @param id 导入任务主键
   * @returns import_error 行数组
   */
  importErrors(id: number) {
    return this.dataSource.query(
      `SELECT * FROM import_error WHERE tenant_id=? AND task_id=? AND is_deleted=0 ORDER BY row_no, id`,
      [currentContext().tenantId, id]);
  }

  /**
   * OpenAPI 签名校验：按 app_key 查 openapi_key，校验 5 分钟时效与 HMAC-SHA256 签名。
   * @param dto appKey/app_key、timestamp、nonce、signature
   * @returns { valid, tenantId, reason }
   */
  async verifyOpenApi(dto: any) {
    const appKey = String(dto.appKey || dto.app_key || '');
    const timestamp = String(dto.timestamp || '');
    const nonce = String(dto.nonce || '');
    const signature = String(dto.signature || '');
    if (!appKey || !timestamp || !signature) {
      throw new BizException(BizCode.PARAM_INVALID, 'appKey、timestamp、signature 必填');
    }
    const rows: any[] = await this.dataSource.query(
      `SELECT * FROM openapi_key WHERE app_key=? AND status=1 AND is_deleted=0`, [appKey]);
    const key = rows[0];
    if (!key) return { valid: false, tenantId: null, reason: '应用不存在或已停用' };
    if (Math.abs(Date.now() - Number(timestamp)) > 5 * 60 * 1000) {
      return { valid: false, tenantId: null, reason: '时间戳已过期' };
    }
    const expected = createHmac('sha256', String(key.app_secret))
      .update(`${appKey}\n${timestamp}\n${nonce}`).digest('hex');
    const a = Buffer.from(expected, 'hex');
    const b = Buffer.from(signature, 'hex');
    const valid = a.length === b.length && timingSafeEqual(a, b);
    if (valid) {
      await this.dataSource.query(`UPDATE openapi_key SET last_used_at=NOW(3) WHERE id=?`, [key.id]);
    }
    return { valid, tenantId: valid ? Number(key.tenant_id) : null, reason: valid ? '校验通过' : '签名不匹配' };
  }

  /**
   * Webhook 模拟推送：写一条 webhook_log 并返回成功结果，真实环境可替换为 HTTP 调用。
   * @param dto event/url/payload/remark
   * @returns { id, status, response }
   */
  async dispatchWebhook(dto: any) {
    const ctx = currentContext();
    if (!dto.event || !dto.url) throw new BizException(BizCode.PARAM_INVALID, 'event 与 url 必填');
    const payload = typeof dto.payload === 'string' ? dto.payload : JSON.stringify(dto.payload || {});
    const res: any = await this.dataSource.query(
      `INSERT INTO webhook_log (tenant_id, created_by, event, url, payload_json, retry_count, status, response, remark)
       VALUES (?,?,?,?,?,0,1,?,?)`,
      [ctx.tenantId, ctx.userId, dto.event, dto.url, payload,
        '{"code":0,"message":"模拟推送成功"}', dto.remark || null]);
    await this.audit.write('CREATE', 'WEBHOOK', res.insertId, dto.event, '模拟推送 Webhook');
    return { id: res.insertId, status: 1, response: '模拟推送成功' };
  }

  /**
   * 写修订快照：自动递增 revision，保存 before/after JSON，支持撤销/重做回溯。
   * @param dto bizType/bizId/action/before/after/reason
   * @returns { id, revision }
   */
  async saveRevision(dto: any) {
    const ctx = currentContext();
    if (!dto.bizType || !dto.bizId) throw new BizException(BizCode.PARAM_INVALID, 'bizType 与 bizId 必填');
    const rows: any[] = await this.dataSource.query(
      `SELECT COALESCE(MAX(revision),0) m FROM revision_snapshot WHERE tenant_id=? AND biz_type=? AND biz_id=?`,
      [ctx.tenantId, dto.bizType, dto.bizId]);
    const revision = Number(rows[0]?.m || 0) + 1;
    const before = typeof dto.before === 'string' ? dto.before : JSON.stringify(dto.before ?? null);
    const after = typeof dto.after === 'string' ? dto.after : JSON.stringify(dto.after ?? null);
    const res: any = await this.dataSource.query(
      `INSERT INTO revision_snapshot (tenant_id, created_by, biz_type, biz_id, revision, action, before_json, after_json, operator, reason)
       VALUES (?,?,?,?,?,?,?,?,?,?)`,
      [ctx.tenantId, ctx.userId, dto.bizType, dto.bizId, revision, dto.action || 'UPDATE',
        before, after, ctx.username, dto.reason || null]);
    await this.audit.write('CREATE', 'REVISION', res.insertId, `${dto.bizType}:${dto.bizId}`, `写入第 ${revision} 版快照`);
    return { id: res.insertId, revision };
  }

  /**
   * 自定义字段解析：按实体返回启用字段，并把 JSON 选项解析为数组/对象。
   * @param entity 业务实体编码，如 sale_order
   * @returns 规范化后的字段定义数组
   */
  async resolveCustomFields(entity: string) {
    const ctx = currentContext();
    if (!entity) throw new BizException(BizCode.PARAM_INVALID, 'entity 必填');
    const rows: any[] = await this.dataSource.query(
      `SELECT * FROM custom_field WHERE tenant_id=? AND entity=? AND is_enabled=1 AND is_deleted=0 ORDER BY sort, id`,
      [ctx.tenantId, entity]);
    return rows.map((r) => ({
      id: Number(r.id), fieldCode: r.field_code, fieldName: r.field_name, fieldType: r.field_type,
      options: typeof r.options_json === 'string' ? JSON.parse(r.options_json) : r.options_json,
      defaultValue: r.default_value, isRequired: Number(r.is_required) === 1, sort: Number(r.sort || 0),
    }));
  }
}

@Controller('api/v1/ux')
class UxController {
  constructor(private readonly service: UxService) {}

  // ---------- 专用接口：声明在通用 :resource 路由之前，避免被通配抢先匹配 ----------

  /** 更新导入任务进度与行数 */
  @Post('import-tasks/:id/progress')
  importProgress(@Param('id', ParseIntPipe) id: number, @Body() dto: any) {
    return this.service.updateImportProgress(id, dto);
  }

  /** 查询导入任务错误明细 */
  @Get('import-tasks/:id/errors')
  importErrors(@Param('id', ParseIntPipe) id: number) {
    return this.service.importErrors(id);
  }

  /** 校验开放平台 API Key 与 HMAC 签名 */
  @Post('openapi/verify')
  verifyOpenApi(@Body() dto: any) { return this.service.verifyOpenApi(dto); }

  /** 模拟 Webhook 推送并落日志 */
  @Post('webhooks/dispatch')
  dispatchWebhook(@Body() dto: any) { return this.service.dispatchWebhook(dto); }

  /** 写入修订快照 */
  @Post('revisions')
  saveRevision(@Body() dto: any) { return this.service.saveRevision(dto); }

  /** 按实体解析自定义字段：GET 走 query，POST 走 body */
  @Get('custom-fields/resolve')
  resolveByQuery(@Query('entity') entity: string) { return this.service.resolveCustomFields(entity); }
  @Post('custom-fields/resolve')
  resolveByBody(@Body() dto: any) { return this.service.resolveCustomFields(dto.entity); }

  @Get('webhook-logs') @RequirePerm('system:audit:view')
  webhookLogs(@Query() q: any) { return this.service.list('webhook-logs', q); }

  // ---------- 通用 CRUD ----------

  /** 通用列表：GET /api/v1/ux/{resource} */
  @Get(':resource') list(@Param('resource') resource: string, @Query() q: any) {
    return this.service.list(resource, q);
  }

  /** 通用新增/修改：POST /api/v1/ux/{resource} */
  @Post(':resource') save(@Param('resource') resource: string, @Body() dto: any) {
    return this.service.save(resource, dto);
  }

  /** 通用局部更新：PATCH /api/v1/ux/{resource}/:id */
  @Patch(':resource/:id')
  patch(@Param('resource') resource: string, @Param('id', ParseIntPipe) id: number, @Body() dto: any) {
    return this.service.save(resource, { ...dto, id });
  }

  /** 通用软删除：DELETE /api/v1/ux/{resource}/:id */
  @Delete(':resource/:id')
  remove(@Param('resource') resource: string, @Param('id', ParseIntPipe) id: number) {
    return this.service.remove(resource, id);
  }
}

@Module({ controllers: [UxController], providers: [UxService, AuditService], exports: [UxService] })
export class UxModule {}
