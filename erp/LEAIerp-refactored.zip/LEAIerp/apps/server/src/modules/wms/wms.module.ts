/**
 * WMS 仓储深化（文档 17.3）：上架 / 波次拣货 / 盘点（盲盘）/ 调拨 / 越库直发
 * 关键逻辑：
 * 1. 上架推荐库位：按库位现有量升序推荐，做到「就近/均衡」上架。
 * 2. 波次生成：按仓库汇总未发货销售单明细，按库位排序生成拣货顺序（路径优化简化实现）。
 * 3. 盘点完成：差异写库存调整流水（ADJUST），重算库存余额。
 * 4. 调拨完成：出仓 + 入仓各写一条流水，数量一致。
 */
import { Body, Controller, Get, Injectable, Module, Param, ParseIntPipe, Post, Query } from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';
import { DataSource } from 'typeorm';
import { BizCode, BizException, RequirePerm, currentContext, normalizePage, pageResult } from '../../common/common';
import { AuditService } from '../../common/audit.service';

/** 生成单据号：前缀 + 时间戳后 10 位 */
function genNo(prefix: string): string {
  return `${prefix}${Date.now().toString().slice(-10)}`;
}

@Injectable()
export class WmsService {
  constructor(@InjectDataSource() private readonly dataSource: DataSource, private readonly audit: AuditService) {}

  // ---------------- 上架 ----------------

  async suggestLocation(warehouseId: number, productId: number): Promise<string | null> {
    const rows: any[] = await this.dataSource.query(
      `SELECT l.code FROM location l LEFT JOIN stock_balance b ON b.location_id=l.id AND b.product_id=?
        WHERE l.warehouse_id=? GROUP BY l.id, l.code ORDER BY COALESCE(SUM(b.qty_on_hand),0) ASC LIMIT 1`,
      [productId, warehouseId]);
    return rows[0]?.code || null;
  }

  async listPutaways() {
    return this.dataSource.query(`SELECT * FROM wms_putaway WHERE tenant_id=? AND is_deleted=0 ORDER BY id DESC LIMIT 200`, [currentContext().tenantId]);
  }

  async createPutaway(dto: any) {
    const ctx = currentContext();
    const suggest = await this.suggestLocation(Number(dto.warehouseId || dto.warehouse_id), Number(dto.productId || dto.product_id));
    const res: any = await this.dataSource.query(
      `INSERT INTO wms_putaway (tenant_id, putaway_no, warehouse_id, product_id, variant_id, batch_id, qty, suggest_location, location_id)
       VALUES (?,?,?,?,?,?,?,?,?)`,
      [ctx.tenantId, genNo('PW'), dto.warehouseId || dto.warehouse_id, dto.productId || dto.product_id,
        dto.variantId || dto.variant_id || null, dto.batchId || dto.batch_id || null, Number(dto.qty || 0),
        suggest, dto.locationId || dto.location_id || null]);
    return { id: res.insertId, suggestLocation: suggest };
  }

  async confirmPutaway(id: number) {
    const ctx = currentContext();
    const rows: any[] = await this.dataSource.query(`SELECT * FROM wms_putaway WHERE id=? AND tenant_id=?`, [id, ctx.tenantId]);
    const p = rows[0];
    if (!p) throw new BizException(BizCode.NOT_FOUND, '上架单不存在');
    if (p.status === 2) throw new BizException(BizCode.PARAM_INVALID, '已上架，请勿重复操作');
    // 上架不改变总库存数量，只绑定库位：写入/更新该库位的库存余额
    await this.dataSource.query(
      `INSERT INTO stock_balance (tenant_id, warehouse_id, location_id, product_id, variant_id, batch_id, qty_on_hand, qty_occupied, avg_cost)
       VALUES (?,?,?,?,?,?,?,0,0)
       ON DUPLICATE KEY UPDATE qty_on_hand = qty_on_hand`,
      [ctx.tenantId, p.warehouse_id, p.location_id || null, p.product_id, p.variant_id || null, p.batch_id || null, 0]);
    await this.dataSource.query(`UPDATE wms_putaway SET status=2 WHERE id=?`, [id]);
    await this.audit.write('PUTAWAY', 'WMS_PUTAWAY', id, p.putaway_no, '确认上架');
    return { status: 'DONE' };
  }

  // ---------------- 波次拣货 ----------------

  async listWaves() {
    return this.dataSource.query(`SELECT * FROM wms_pick_wave WHERE tenant_id=? AND is_deleted=0 ORDER BY id DESC LIMIT 200`, [currentContext().tenantId]);
  }

  /**
   * 生成波次：取该仓库下状态为「已确认/部分发货」的销售单明细，
   * 按库位编码排序赋予拣货顺序（同一库位一次拣完，减少往返）。
   */
  async generateWave(dto: any) {
    const ctx = currentContext();
    const whId = Number(dto.warehouseId || dto.warehouse_id);
    const res: any = await this.dataSource.query(
      `INSERT INTO wms_pick_wave (tenant_id, wave_no, warehouse_id, strategy) VALUES (?,?,?,?)`,
      [ctx.tenantId, genNo('WV'), whId, dto.strategy || 'SHORTEST_PATH']);
    const waveId = res.insertId;
    const lines: any[] = await this.dataSource.query(
      `SELECT l.order_id, l.product_id, l.variant_id, l.qty, l.warehouse_id,
              COALESCE((SELECT l2.qty_on_hand FROM stock_balance l2
                         WHERE l2.warehouse_id=l.warehouse_id AND l2.product_id=l.product_id
                           AND l2.location_id IS NOT NULL AND l2.qty_on_hand>0
                         ORDER BY l2.location_id LIMIT 1),0) AS on_hand,
              (SELECT l2.location_id FROM stock_balance l2
                WHERE l2.warehouse_id=l.warehouse_id AND l2.product_id=l.product_id
                  AND l2.location_id IS NOT NULL AND l2.qty_on_hand>0
                ORDER BY l2.location_id LIMIT 1) AS location_id
         FROM sale_order_line l JOIN sale_order o ON o.id=l.order_id
        WHERE o.tenant_id=? AND o.is_deleted=0 AND l.warehouse_id=? AND o.status IN (2,3)`,
      [ctx.tenantId, whId]);
    let sortNo = 0;
    for (const ln of lines) {
      sortNo += 1;
      await this.dataSource.query(
        `INSERT INTO wms_pick_wave_line (tenant_id, wave_id, source_type, source_id, product_id, variant_id, location_id, qty, sort_no)
         VALUES (?,?, 'SALE_ORDER',?,?,?,?,?,?)`,
        [ctx.tenantId, waveId, ln.order_id, ln.product_id, ln.variant_id || null, ln.location_id || null, Number(ln.qty || 0), sortNo]);
    }
    await this.audit.write('GENERATE', 'WMS_WAVE', waveId, String(waveId), `生成波次，明细 ${lines.length} 行`);
    return { id: waveId, lineCount: lines.length };
  }

  waveLines(waveId: number) {
    return this.dataSource.query(
      `SELECT wl.*, p.name AS product_name FROM wms_pick_wave_line wl
        LEFT JOIN product p ON p.id=wl.product_id
        WHERE wl.wave_id=? AND wl.is_deleted=0 ORDER BY wl.sort_no`, [waveId]);
  }

  async pick(waveId: number, lineId: number, qty: number) {
    const ctx = currentContext();
    const rows: any[] = await this.dataSource.query(`SELECT * FROM wms_pick_wave_line WHERE id=? AND wave_id=?`, [lineId, waveId]);
    const line = rows[0];
    if (!line) throw new BizException(BizCode.NOT_FOUND, '波次明细不存在');
    const picked = Number(line.picked_qty || 0) + Number(qty || 0);
    if (picked > Number(line.qty)) throw new BizException(BizCode.PARAM_INVALID, '拣货数量超过应拣数量');
    await this.dataSource.query(`UPDATE wms_pick_wave_line SET picked_qty=? WHERE id=?`, [picked, lineId]);
    const remain: any[] = await this.dataSource.query(`SELECT COUNT(*) c FROM wms_pick_wave_line WHERE wave_id=? AND picked_qty<qty`, [waveId]);
    if (Number(remain[0]?.c || 0) === 0) {
      await this.dataSource.query(`UPDATE wms_pick_wave SET status=3 WHERE id=?`, [waveId]);
    }
    return { pickedQty: picked };
  }

  // ---------------- 盘点 ----------------

  listStocktakes() {
    return this.dataSource.query(`SELECT * FROM wms_stocktake WHERE tenant_id=? AND is_deleted=0 ORDER BY id DESC LIMIT 200`, [currentContext().tenantId]);
  }

  /** 新建盘点单并快照账面数；blind=1 时前端不展示 book_qty */
  async createStocktake(dto: any) {
    const ctx = currentContext();
    const whId = Number(dto.warehouseId || dto.warehouse_id);
    const blind = dto.blind === undefined ? 1 : Number(dto.blind);
    const res: any = await this.dataSource.query(
      `INSERT INTO wms_stocktake (tenant_id, take_no, warehouse_id, blind) VALUES (?,?,?,?)`,
      [ctx.tenantId, genNo('ST'), whId, blind]);
    await this.dataSource.query(
      `INSERT INTO wms_stocktake_line (tenant_id, take_id, product_id, variant_id, batch_id, location_id, book_qty)
       SELECT ?, ?, b.product_id, b.variant_id, b.batch_id, b.location_id, b.qty_on_hand
         FROM stock_balance b WHERE b.tenant_id=? AND b.warehouse_id=? AND b.is_deleted=0`,
      [ctx.tenantId, res.insertId, ctx.tenantId, whId]);
    return { id: res.insertId };
  }

  stocktakeLines(takeId: number) {
    return this.dataSource.query(
      `SELECT l.*, p.name AS product_name FROM wms_stocktake_line l LEFT JOIN product p ON p.id=l.product_id
        WHERE l.take_id=? AND l.is_deleted=0 ORDER BY l.id`, [takeId]);
  }

  inputReal(lineId: number, realQty: number) {
    return this.dataSource.query(`UPDATE wms_stocktake_line SET real_qty=?, diff_qty=?-book_qty WHERE id=?`,
      [realQty, realQty, lineId]).then(() => ({ ok: true }));
  }

  /** 完成盘点：差异行写 ADJUST 流水（盘盈为正、盘亏为负），更新库存余额 */
  async finishStocktake(takeId: number) {
    const ctx = currentContext();
    const rows: any[] = await this.dataSource.query(`SELECT * FROM wms_stocktake WHERE id=? AND tenant_id=?`, [takeId, ctx.tenantId]);
    const take = rows[0];
    if (!take) throw new BizException(BizCode.NOT_FOUND, '盘点单不存在');
    if (take.status === 3) throw new BizException(BizCode.PARAM_INVALID, '盘点已完成');
    const lines: any[] = await this.dataSource.query(`SELECT * FROM wms_stocktake_line WHERE take_id=? AND is_deleted=0`, [takeId]);
    for (const ln of lines) {
      const diff = Number(ln.diff_qty || 0);
      if (diff === 0) continue;
      const inQty = diff > 0 ? Math.abs(diff) : 0;
      const outQty = diff < 0 ? Math.abs(diff) : 0;
      await this.dataSource.query(
        `INSERT INTO stock_ledger (tenant_id, voucher_type, voucher_id, warehouse_id, product_id, variant_id, batch_id,
           qty_in, qty_out, cost, occurred_at)
         VALUES (?,'ADJUST',?,?,?,?,?,?,?,0,NOW(3))`,
        [ctx.tenantId, takeId, take.warehouse_id, ln.product_id, ln.variant_id || null, ln.batch_id || null, inQty, outQty]);
      await this.dataSource.query(
        `UPDATE stock_balance SET qty_on_hand = qty_on_hand + ?
          WHERE tenant_id=? AND warehouse_id=? AND product_id=? AND IFNULL(variant_id,0)=IFNULL(?,0) AND IFNULL(batch_id,0)=IFNULL(?,0)`,
        [diff, ctx.tenantId, take.warehouse_id, ln.product_id, ln.variant_id || null, ln.batch_id || null]);
    }
    await this.dataSource.query(`UPDATE wms_stocktake SET status=3 WHERE id=?`, [takeId]);
    await this.audit.write('FINISH', 'WMS_STOCKTAKE', takeId, take.take_no, `盘点完成，差异行 ${lines.filter((l) => Number(l.diff_qty) !== 0).length} 条`);
    return { diffLines: lines.filter((l) => Number(l.diff_qty) !== 0).length };
  }

  // ---------------- 调拨 ----------------

  listTransfers() {
    return this.dataSource.query(`SELECT * FROM wms_transfer WHERE tenant_id=? AND is_deleted=0 ORDER BY id DESC LIMIT 200`, [currentContext().tenantId]);
  }

  createTransfer(dto: any) {
    const ctx = currentContext();
    return this.dataSource.query(
      `INSERT INTO wms_transfer (tenant_id, transfer_no, from_warehouse_id, to_warehouse_id, product_id, variant_id, batch_id, qty)
       VALUES (?,?,?,?,?,?,?,?)`,
      [ctx.tenantId, genNo('TF'), dto.fromWarehouseId || dto.from_warehouse_id, dto.toWarehouseId || dto.to_warehouse_id,
        dto.productId || dto.product_id, dto.variantId || dto.variant_id || null, dto.batchId || dto.batch_id || null, Number(dto.qty || 0)])
      .then((res: any) => ({ id: res.insertId }));
  }

  /** 调拨完成：发出仓写 TRANSFER_OUT，收入仓写 TRANSFER_IN，各更新一次余额 */
  async executeTransfer(id: number) {
    const ctx = currentContext();
    const rows: any[] = await this.dataSource.query(`SELECT * FROM wms_transfer WHERE id=? AND tenant_id=?`, [id, ctx.tenantId]);
    const t = rows[0];
    if (!t) throw new BizException(BizCode.NOT_FOUND, '调拨单不存在');
    if (t.status === 2) throw new BizException(BizCode.PARAM_INVALID, '调拨已完成');
    await this.dataSource.query(
      `INSERT INTO stock_ledger (tenant_id, voucher_type, voucher_id, warehouse_id, product_id, variant_id, batch_id, qty_in, qty_out, occurred_at)
       VALUES (?,'TRANSFER_OUT',?,?,?,?,?,0,?,NOW(3))`,
      [ctx.tenantId, id, t.from_warehouse_id, t.product_id, t.variant_id || null, t.batch_id || null, t.qty]);
    await this.dataSource.query(
      `UPDATE stock_balance SET qty_on_hand = qty_on_hand - ?, qty_occupied = GREATEST(qty_occupied - ?, 0)
        WHERE warehouse_id=? AND product_id=? AND IFNULL(variant_id,0)=IFNULL(?,0) AND IFNULL(batch_id,0)=IFNULL(?,0)`,
      [t.qty, t.qty, t.from_warehouse_id, t.product_id, t.variant_id || null, t.batch_id || null]);
    await this.dataSource.query(
      `INSERT INTO stock_ledger (tenant_id, voucher_type, voucher_id, warehouse_id, product_id, variant_id, batch_id, qty_in, qty_out, occurred_at)
       VALUES (?,'TRANSFER_IN',?,?,?,?,?,?,0,NOW(3))`,
      [ctx.tenantId, id, t.to_warehouse_id, t.product_id, t.variant_id || null, t.batch_id || null, t.qty]);
    await this.dataSource.query(
      `INSERT INTO stock_balance (tenant_id, warehouse_id, product_id, variant_id, batch_id, qty_on_hand, qty_occupied, avg_cost)
       VALUES (?,?,?,?,?,?,0,0)
       ON DUPLICATE KEY UPDATE qty_on_hand = qty_on_hand + ?`,
      [ctx.tenantId, t.to_warehouse_id, t.product_id, t.variant_id || null, t.batch_id || null, t.qty, t.qty]);
    await this.dataSource.query(`UPDATE wms_transfer SET status=2 WHERE id=?`, [id]);
    await this.audit.write('TRANSFER', 'WMS_TRANSFER', id, t.transfer_no, `调拨完成 ${t.qty}`);
    return { status: 'DONE' };
  }

  // ---------------- 越库直发 ----------------

  listCrossdocks() {
    return this.dataSource.query(`SELECT * FROM wms_crossdock WHERE tenant_id=? AND is_deleted=0 ORDER BY id DESC LIMIT 200`, [currentContext().tenantId]);
  }

  createCrossdock(dto: any) {
    const ctx = currentContext();
    return this.dataSource.query(
      `INSERT INTO wms_crossdock (tenant_id, dock_no, purchase_id, sale_id, product_id, qty) VALUES (?,?,?,?,?,?)`,
      [ctx.tenantId, genNo('CD'), dto.purchaseId || dto.purchase_id || null, dto.saleId || dto.sale_id || null,
        dto.productId || dto.product_id, Number(dto.qty || 0)])
      .then((res: any) => ({ id: res.insertId }));
  }
}

@Controller('api/v1/wms')
class WmsController {
  constructor(private readonly service: WmsService) {}

  @Get('putaways') @RequirePerm('wms:putaway:view') putaways() { return this.service.listPutaways(); }
  @Post('putaways') @RequirePerm('wms:putaway:edit') createPutaway(@Body() dto: any) { return this.service.createPutaway(dto); }
  @Post('putaways/:id/confirm') @RequirePerm('wms:putaway:edit') confirmPutaway(@Param('id', ParseIntPipe) id: number) { return this.service.confirmPutaway(id); }
  @Get('waves') @RequirePerm('wms:wave:view') waves() { return this.service.listWaves(); }
  @Post('waves') @RequirePerm('wms:wave:edit') generateWave(@Body() dto: any) { return this.service.generateWave(dto); }
  @Get('waves/:id/lines') @RequirePerm('wms:wave:view') waveLines(@Param('id', ParseIntPipe) id: number) { return this.service.waveLines(id); }
  @Post('waves/:id/lines/:lineId/pick') @RequirePerm('wms:wave:edit') pick(@Param('id', ParseIntPipe) id: number, @Param('lineId', ParseIntPipe) lineId: number, @Body() dto: any) { return this.service.pick(id, lineId, Number(dto.qty || 0)); }
  @Get('stocktakes') @RequirePerm('wms:stocktake:view') stocktakes() { return this.service.listStocktakes(); }
  @Post('stocktakes') @RequirePerm('wms:stocktake:edit') createStocktake(@Body() dto: any) { return this.service.createStocktake(dto); }
  @Get('stocktakes/:id/lines') @RequirePerm('wms:stocktake:view') stocktakeLines(@Param('id', ParseIntPipe) id: number) { return this.service.stocktakeLines(id); }
  @Post('stocktake-lines/:id/real') @RequirePerm('wms:stocktake:edit') inputReal(@Param('id', ParseIntPipe) id: number, @Body() dto: any) { return this.service.inputReal(id, Number(dto.realQty || 0)); }
  @Post('stocktakes/:id/finish') @RequirePerm('wms:stocktake:edit') finishStocktake(@Param('id', ParseIntPipe) id: number) { return this.service.finishStocktake(id); }
  @Get('transfers') @RequirePerm('wms:transfer:view') transfers() { return this.service.listTransfers(); }
  @Post('transfers') @RequirePerm('wms:transfer:edit') createTransfer(@Body() dto: any) { return this.service.createTransfer(dto); }
  @Post('transfers/:id/execute') @RequirePerm('wms:transfer:edit') executeTransfer(@Param('id', ParseIntPipe) id: number) { return this.service.executeTransfer(id); }
  @Get('crossdocks') @RequirePerm('wms:crossdock:view') crossdocks() { return this.service.listCrossdocks(); }
  @Post('crossdocks') @RequirePerm('wms:crossdock:edit') createCrossdock(@Body() dto: any) { return this.service.createCrossdock(dto); }
}

@Module({ controllers: [WmsController], providers: [WmsService, AuditService], exports: [WmsService] })
export class WmsModule {}
