# @erp/uniapp — LEAI ERP 移动端

UniApp + Vue 3 + TypeScript + Vite 实现的 ERP 移动端，支持 H5、微信小程序、支付宝小程序与 App。
视觉语言与 PC 管理端保持一致：品牌蓝 `#4d6bfe`、圆角 10px、字号 12/13/14/16、间距 4/8/12/16。

## 运行

在仓库根目录执行（本包是 pnpm workspace 成员）：

```bash
# H5（默认 http://localhost:5174）
pnpm --filter @erp/uniapp dev:h5

# 微信小程序（产物在 dist/dev/mp-weixin，用微信开发者工具打开）
pnpm --filter @erp/uniapp dev:mp-weixin

# 支付宝小程序
pnpm --filter @erp/uniapp dev:mp-alipay

# 打包
pnpm --filter @erp/uniapp build:h5
```

首次安装依赖：在根目录执行 `pnpm install`。`@dcloudio/*` 已统一固定到 Vue3 编译器对应的
`3.0.0-alpha-5030620261112001`（`uni-cli-shared` 也已显式声明），避免 `latest` 标签指向旧版 alpha
导致构建失败。升级时请保持这一组包的版本号完全一致。H5 构建命令：`pnpm --filter @erp/uniapp build:h5`。

## 环境变量

在 `apps/uniapp/.env.local` 中配置（可选）：

```bash
VITE_API_BASE=/api/v1          # 接口基础地址，默认 /api/v1
VITE_USE_MOCK=true             # 默认 true；显式设为 false 时优先请求真实后端，失败仍自动降级 mock
VITE_PROXY_TARGET=http://localhost:3000  # H5 开发代理目标
```

## 无后端演示

默认开启内置 mock 适配器（`src/api/mock.ts`），所有页面均有数据、所有按钮均可点通：

- 登录账号：`admin` / `admin123`，也可点击“演示模式进入”。
- 审批同意/驳回会从待办移除；盘点提交会真实改变 mock 库存；销售开单可保存草稿与提交。
- 扫码在真机调用 `uni.scanCode`，H5 自动降级为条码输入框。

## 目录结构

```
src/
  api/         统一请求封装与 mock 适配器
  components/  ERP 风格小组件（卡片/统计块/状态标签/空态/加载）
  config.ts    接口地址、存储 key、演示账号等全局常量
  pages/       11 个业务页面
  store/       用户与全局响应式状态
  utils.ts     轻提示、确认框、跳转等通用函数
  pages.json   页面注册与 tabBar
  manifest.json/uni.scss/App.vue/main.ts  UniApp 入口配置
```
