<script setup lang="ts">
/**
 * App 根组件
 * 职责：应用启动时初始化本地状态；承载全局样式与设计令牌。
 * 说明：全局样式写在无 scoped 的 style 中，所有页面共享；主题通过 page 上的 CSS 变量实现。
 */
import { onLaunch } from '@dcloudio/uni-app';
import { initStore } from './store';

onLaunch(() => {
  // 启动时从本地存储恢复 token、用户信息与主题设置
  initStore();
});
</script>

<style>
/* ===================== 全局设计令牌（与 PC 端 ds/theme.css 对齐） ===================== */
page {
  --erp-brand: #4d6bfe;
  --erp-brand-soft: rgba(77, 107, 254, 0.1);
  --erp-bg: #f5f6f8;
  --erp-card: #ffffff;
  --erp-border: #e8eaed;
  --erp-divider: #eef0f2;
  --erp-text: #1a1d21;
  --erp-text-2: #4e5561;
  --erp-text-3: #8a9099;
  --erp-success: #16a34a;
  --erp-warning: #d97706;
  --erp-danger: #dc2626;
  --erp-radius: 10px;

  background: var(--erp-bg, #f5f6f8);
  color: var(--erp-text, #1a1d21);
  font-size: 14px;
  font-family: -apple-system, BlinkMacSystemFont, 'PingFang SC', 'Microsoft YaHei', sans-serif;
  line-height: 1.5;
}

/* 深色主题：页面根节点加 .theme-dark 即可覆盖局部变量 */
.theme-dark {
  --erp-bg: #17181c;
  --erp-card: #212329;
  --erp-border: #33363e;
  --erp-divider: #2c2f36;
  --erp-text: #e8eaed;
  --erp-text-2: #b6bac2;
  --erp-text-3: #828792;
  --erp-brand-soft: rgba(100, 132, 255, 0.16);
  background: var(--erp-bg, #17181c);
  color: var(--erp-text, #e8eaed);
}

/* ===================== 通用布局工具类 ===================== */
.erp-page {
  min-height: 100vh;
  padding: 12px;
  box-sizing: border-box;
}

.erp-row {
  display: flex;
  align-items: center;
}

.erp-between {
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.erp-muted {
  color: var(--erp-text-3, #8a9099);
  font-size: 12px;
}

.erp-title {
  color: var(--erp-text, #1a1d21);
  font-size: 16px;
  font-weight: 600;
}

/* 主按钮 */
.erp-btn {
  height: 40px;
  border-radius: var(--erp-radius, 10px);
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 14px;
  font-weight: 500;
  background: var(--erp-brand, #4d6bfe);
  color: #ffffff;
  border: none;
}

.erp-btn--ghost {
  background: transparent;
  color: var(--erp-brand, #4d6bfe);
  border: 1px solid var(--erp-brand, #4d6bfe);
}

.erp-btn--plain {
  background: var(--erp-bg, #f5f6f8);
  color: var(--erp-text-2, #4e5561);
  border: 1px solid var(--erp-border, #e8eaed);
}

.erp-btn::after {
  border: none;
}
</style>
