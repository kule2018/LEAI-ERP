/**
 * index.ts —— 统一请求封装
 * 职责：
 * 1. 用 uni.request 替代 axios，保证 H5 / 小程序 / App 多端兼容。
 * 2. 自动注入 Token，统一解包后端 { code, data, message } 结构。
 * 3. mock 开关：默认直接走本地 mock；真实请求失败时自动降级 mock，确保可演示。
 */
import { API_BASE, TOKEN_KEY, USE_MOCK } from '../config';
import { mockRequest } from './mock';

/** 请求可选项：data 为请求体，params 为查询参数 */
interface RequestOptions {
  data?: any;
  params?: Record<string, string | number | boolean | undefined>;
}

/**
 * 把参数对象拼成查询字符串
 * @param params 参数对象
 * @returns 形如 "keyword=耳机&page=1" 的字符串，无有效参数时返回空串
 */
function buildQuery(params?: RequestOptions['params']): string {
  if (!params) return '';
  const parts: string[] = [];
  Object.keys(params).forEach((key) => {
    const value = params[key];
    if (value === undefined || value === null || value === '') return;
    parts.push(encodeURIComponent(key) + '=' + encodeURIComponent(String(value)));
  });
  return parts.join('&');
}

/**
 * 拼出完整地址（含 API_BASE 与查询串），mock 与真实请求共用
 * @param path 接口相对路径，如 /mobile/home
 * @param params 查询参数
 * @returns 完整地址
 */
function buildUrl(path: string, params?: RequestOptions['params']): string {
  const query = buildQuery(params);
  return API_BASE + path + (query ? '?' + query : '');
}

/**
 * 统一请求函数
 * @param method HTTP 方法
 * @param path 接口相对路径
 * @param options 请求体 / 查询参数
 * @returns 解包后的业务数据；失败时抛出 Error
 */
async function request<T = any>(method: string, path: string, options: RequestOptions = {}): Promise<T> {
  const { data, params } = options;
  const fullUrl = buildUrl(path, params);

  // mock 模式：跳过网络，直接返回本地模拟数据
  if (USE_MOCK) {
    return await mockRequest<T>(method, fullUrl, data);
  }

  // 真实模式：发起 uni.request，并在失败时降级 mock
  const token = uni.getStorageSync(TOKEN_KEY) || '';
  try {
    const response: any = await new Promise((resolve, reject) => {
      uni.request({
        url: fullUrl,
        method: method as any,
        data: method === 'GET' ? undefined : data,
        header: {
          'Content-Type': 'application/json',
          Authorization: token ? `Bearer ${token}` : ''
        },
        success: resolve,
        fail: reject
      });
    });

    const body = response && response.data;
    if (body && typeof body === 'object' && 'code' in body) {
      if (body.code === 0) return body.data as T;
      throw new Error(body.message || '请求失败');
    }
    return body as T;
  } catch (error) {
    // 网络异常、后端未启动或接口不存在：降级到 mock，保证演示流程不中断
    return await mockRequest<T>(method, fullUrl, data);
  }
}

/** 认证相关接口 */
export const authApi = {
  /** 账号密码登录 */
  login: (username: string, password: string) =>
    request<any>('POST', '/auth/login', { data: { username, password } })
};

/** 移动端业务接口（路径与后端 MobileController 对齐） */
export const mobileApi = {
  /** 工作台聚合数据 */
  home: () => request<any>('GET', '/mobile/home'),
  /** 待办列表 */
  todo: () => request<any>('GET', '/mobile/todo'),
  /** 审批详情 */
  approvalDetail: (id: number) => request<any>('GET', `/mobile/approval/${id}`),
  /** 审批提交：agree 为是否同意，opinion 为审批意见 */
  approvalSubmit: (id: number, agree: boolean, opinion: string) =>
    request<any>('POST', `/mobile/approval/${id}/approve`, { data: { agree, opinion } }),
  /** 扫码查询库存 */
  scan: (code: string) => request<any>('GET', '/mobile/scan', { params: { code } }),
  /** 库存分页查询 */
  stock: (params: { keyword?: string; warehouseId?: number | string; page: number; pageSize: number }) =>
    request<any>('GET', '/mobile/stock', { params }),
  /** 库存流水 */
  stockLedger: (id: number) => request<any>('GET', '/mobile/stock/ledger', { params: { id } }),
  /** 盘点单列表 */
  stocktakeList: () => request<any>('GET', '/mobile/stocktake/list'),
  /** 盘点单详情 */
  stocktakeDetail: (id: string) => request<any>('GET', '/mobile/stocktake/detail', { params: { id } }),
  /** 盘点提交 */
  stocktakeSubmit: (id: string, lines: Array<{ id: number; realQty: number }>) =>
    request<any>('POST', '/mobile/stocktake/submit', { data: { id, lines } }),
  /** 销售开单基础数据：客户、商品、列表 */
  salesCustomers: () => request<any>('GET', '/mobile/sales/customers'),
  salesProducts: () => request<any>('GET', '/mobile/sales/products'),
  salesList: () => request<any>('GET', '/mobile/sales/list'),
  salesSave: (data: any) => request<any>('POST', '/mobile/sales/save', { data }),
  salesSubmit: (data: any) => request<any>('POST', '/mobile/sales/submit', { data }),
  /** PDA 拣货波次列表 */
  pickingWaves: () => request<any>('GET', '/mobile/picking/waves'),
  /** 拣货波次明细 */
  pickingDetail: (id: string) => request<any>('GET', '/mobile/picking/detail', { params: { id } }),
  /** 拣货提交：lines 为 { id, pickedQty, short } 数组 */
  pickingSubmit: (id: string, lines: Array<{ id: number; pickedQty: number; short: boolean }>) =>
    request<any>('POST', '/mobile/picking/submit', { data: { id, lines } }),
  /** 版本更新日志 */
  changelog: () => request<any>('GET', '/mobile/changelog'),
  /** 经营报表 */
  report: () => request<any>('GET', '/mobile/report')
};

/** AI 助理接口（复用后端 /api/v1/ai/copilot） */
export const aiApi = {
  /** 向 AI 助理提问 */
  chat: (message: string) => request<any>('POST', '/ai/copilot', { data: { message } })
};

export default request;
