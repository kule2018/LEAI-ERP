/**
 * mock.ts —— 本地模拟数据适配器
 * 职责：在“无后端”场景替代表真实接口，保证每个页面都有数据、每个按钮都能走通。
 * 设计要点：
 * 1. 数据放在模块级数组中，审批 / 盘点 / 开单等操作会真实修改数组，模拟持久化效果。
 * 2. 通过“方法 + 路径”匹配路由，返回结构与后端 {code,data,message} 解包后的 data 一致。
 * 3. 登录校验、扫码命中、报表指标、AI 规则问答都在这里实现，方便演示与联调对照。
 */

import { API_BASE, DEMO_ACCOUNT } from '../config';

/** 商品库存记录：productId 与库存流水、盘点行关联 */
interface MockProduct {
  id: number;
  name: string;
  code: string;
  barcode: string;
  skuCode: string;
  price: number;
  category: string;
  warehouseId: number;
  warehouse: string;
  onHand: number;
  occupied: number;
  unit: string;
}

/** 待办项：type 决定点击后进入审批页还是仅弹窗展示 */
interface MockTodo {
  id: number;
  type: 'approval' | 'ship' | 'receivable';
  typeName: string;
  title: string;
  bizNo: string;
  amount: number;
  applicant: string;
  time: string;
}

/** 盘点单：含若干明细行，提交时按实盘数回写库存 */
interface MockStocktake {
  id: string;
  name: string;
  warehouseId: number;
  warehouse: string;
  status: 'pending' | 'done';
  createdAt: string;
  lines: Array<{ id: number; productId: number; productName: string; bookQty: number; realQty: number | null }>;
}

/** 销售单：状态随保存草稿 / 提交变化 */
interface MockSalesOrder {
  id: string;
  customer: string;
  amount: number;
  quantity: number;
  status: string;
  time: string;
}

/** 拣货波次明细行：按库位列出待拣商品，核对条码后录入实拣数量 */
interface MockPickLine {
  id: number;
  productId: number;
  productName: string;
  barcode: string;
  location: string;
  planQty: number;
  pickedQty: number | null;
  short: boolean;
}

/** 拣货波次：pending 待拣 / picking 拣货中 / done 已完成 */
interface MockWave {
  id: string;
  name: string;
  warehouseId: number;
  warehouse: string;
  status: 'pending' | 'picking' | 'done';
  createdAt: string;
  lines: MockPickLine[];
}

/** 版本更新日志条目 */
interface MockChangelog {
  version: string;
  date: string;
  current?: boolean;
  features: string[];
  fixes: string[];
}

/** 仓库列表 */
const warehouses = [
  { id: 1, name: '深圳主仓' },
  { id: 2, name: '东莞备件仓' },
  { id: 3, name: '上海前置仓' }
];

/** 商品库存：8 条数据，覆盖充足与低库存场景 */
const products: MockProduct[] = [
  { id: 1, name: '无线蓝牙耳机 Pro', code: 'PRD-1001', barcode: '6901001100011', skuCode: 'SKU-EAR-PRO-BLK', price: 299, category: '数码配件', warehouseId: 1, warehouse: '深圳主仓', onHand: 128, occupied: 12, unit: '台' },
  { id: 2, name: '便携充电宝 20000mAh', code: 'PRD-1002', barcode: '6901001100028', skuCode: 'SKU-PWR-20000', price: 159, category: '数码配件', warehouseId: 1, warehouse: '深圳主仓', onHand: 64, occupied: 8, unit: '个' },
  { id: 3, name: '人体工学办公椅', code: 'PRD-1003', barcode: '6901001100035', skuCode: 'SKU-CHAIR-ERG', price: 899, category: '办公家具', warehouseId: 2, warehouse: '东莞备件仓', onHand: 22, occupied: 20, unit: '把' },
  { id: 4, name: 'A4 复印纸（5包装）', code: 'PRD-1004', barcode: '6901001100042', skuCode: 'SKU-PAPER-A4', price: 89, category: '办公耗材', warehouseId: 2, warehouse: '东莞备件仓', onHand: 310, occupied: 0, unit: '箱' },
  { id: 5, name: '智能温控水杯', code: 'PRD-1005', barcode: '6901001100059', skuCode: 'SKU-CUP-TEMP', price: 219, category: '生活好物', warehouseId: 3, warehouse: '上海前置仓', onHand: 3, occupied: 2, unit: '个' },
  { id: 6, name: '桌面补光灯', code: 'PRD-1006', barcode: '6901001100066', skuCode: 'SKU-LIGHT-DESK', price: 129, category: '数码配件', warehouseId: 3, warehouse: '上海前置仓', onHand: 45, occupied: 5, unit: '台' },
  { id: 7, name: '笔记本支架（铝合金）', code: 'PRD-1007', barcode: '6901001100073', skuCode: 'SKU-STAND-ALU', price: 99, category: '办公家具', warehouseId: 1, warehouse: '深圳主仓', onHand: 2, occupied: 2, unit: '个' },
  { id: 8, name: '无线机械键盘', code: 'PRD-1008', barcode: '6901001100080', skuCode: 'SKU-KEY-MECH', price: 369, category: '数码配件', warehouseId: 1, warehouse: '深圳主仓', onHand: 76, occupied: 10, unit: '把' }
];

/** 待办列表：审批 2 条、待发货 2 条、逾期应收 2 条 */
const todos: MockTodo[] = [
  { id: 101, type: 'approval', typeName: '审批', title: '采购订单 PO-2026-0188 待审批', bizNo: 'PO-2026-0188', amount: 12800, applicant: '张敏', time: '2026-11-17 09:24' },
  { id: 102, type: 'approval', typeName: '审批', title: '费用报销 EX-2026-0065 待审批', bizNo: 'EX-2026-0065', amount: 2380, applicant: '李强', time: '2026-11-17 08:50' },
  { id: 201, type: 'ship', typeName: '待发货', title: '销售订单 SO-2026-0332 待发货', bizNo: 'SO-2026-0332', amount: 5980, applicant: '王芳', time: '2026-11-16 16:10' },
  { id: 202, type: 'ship', typeName: '待发货', title: '销售订单 SO-2026-0335 待发货', bizNo: 'SO-2026-0335', amount: 12450, applicant: '陈晨', time: '2026-11-16 14:32' },
  { id: 301, type: 'receivable', typeName: '逾期应收', title: '客户「华远科技」应收款逾期 15 天', bizNo: 'AR-2026-0091', amount: 26800, applicant: '财务中心', time: '2026-11-02 10:00' },
  { id: 302, type: 'receivable', typeName: '逾期应收', title: '客户「星辰实业」应收款逾期 8 天', bizNo: 'AR-2026-0104', amount: 9350, applicant: '财务中心', time: '2026-11-09 11:20' }
];

/** 盘点单：一张待盘点、一张已完成（用于展示状态差异） */
const stocktakes: MockStocktake[] = [
  {
    id: 'PD-2026-001',
    name: '11 月月度盘点 · 深圳主仓',
    warehouseId: 1,
    warehouse: '深圳主仓',
    status: 'pending',
    createdAt: '2026-11-17 08:00',
    lines: [
      { id: 1, productId: 1, productName: '无线蓝牙耳机 Pro', bookQty: 128, realQty: null },
      { id: 2, productId: 2, productName: '便携充电宝 20000mAh', bookQty: 64, realQty: null },
      { id: 7, productId: 7, productName: '笔记本支架（铝合金）', bookQty: 2, realQty: null },
      { id: 8, productId: 8, productName: '无线机械键盘', bookQty: 76, realQty: null }
    ]
  },
  {
    id: 'PD-2026-002',
    name: '周度抽盘 · 上海前置仓',
    warehouseId: 3,
    warehouse: '上海前置仓',
    status: 'done',
    createdAt: '2026-11-10 09:30',
    lines: [
      { id: 5, productId: 5, productName: '智能温控水杯', bookQty: 4, realQty: 3 },
      { id: 6, productId: 6, productName: '桌面补光灯', bookQty: 45, realQty: 45 }
    ]
  }
];

/** 销售单列表：预置 3 条，用于展示状态标签 */
const salesOrders: MockSalesOrder[] = [
  { id: 'SO-2026-0332', customer: '华远科技', amount: 5980, quantity: 20, status: '待审核', time: '2026-11-16 16:10' },
  { id: 'SO-2026-0331', customer: '云图商贸', amount: 3240, quantity: 12, status: '已确认', time: '2026-11-16 11:05' },
  { id: 'SO-2026-0330', customer: '恒信电子', amount: 1860, quantity: 6, status: '草稿', time: '2026-11-15 17:42' }
];

/** 客户列表：销售开单选客户用 */
const customers = ['华远科技', '云图商贸', '星辰实业', '恒信电子', '远景供应链'];

/** 公告列表：首页与我的页面展示 */
const notices = [
  { id: 1, title: '关于 11 月版本更新的通知', time: '2026-11-17', content: '本次更新新增移动盘点、扫码查库存与 AI 每日简报，修复若干已知问题。' },
  { id: 2, title: '年底库存盘点工作安排', time: '2026-11-15', content: '请各仓库在 12 月 10 日前完成年度盘点，盘点单已同步至移动端。' },
  { id: 3, title: '系统维护公告（11 月 20 日）', time: '2026-11-12', content: '当日 22:00-23:00 进行系统维护，期间移动端与 PC 端暂停服务。' }
];

/** 拣货波次：2 张待处理波次，覆盖不同仓库与库位，提交后真实扣减库存 */
const waves: MockWave[] = [
  {
    id: 'WV-2026-001',
    name: '双十一补货波次 · 深圳主仓',
    warehouseId: 1,
    warehouse: '深圳主仓',
    status: 'picking',
    createdAt: '2026-11-17 09:00',
    lines: [
      { id: 1, productId: 1, productName: '无线蓝牙耳机 Pro', barcode: '6901001100011', location: 'A-01-03', planQty: 5, pickedQty: null, short: false },
      { id: 2, productId: 2, productName: '便携充电宝 20000mAh', barcode: '6901001100028', location: 'A-02-05', planQty: 3, pickedQty: null, short: false },
      { id: 3, productId: 8, productName: '无线机械键盘', barcode: '6901001100080', location: 'B-01-02', planQty: 2, pickedQty: null, short: false }
    ]
  },
  {
    id: 'WV-2026-002',
    name: '前置仓日常波次 · 上海前置仓',
    warehouseId: 3,
    warehouse: '上海前置仓',
    status: 'pending',
    createdAt: '2026-11-17 10:30',
    lines: [
      { id: 4, productId: 5, productName: '智能温控水杯', barcode: '6901001100059', location: 'C-03-01', planQty: 2, pickedQty: null, short: false },
      { id: 5, productId: 6, productName: '桌面补光灯', barcode: '6901001100066', location: 'C-01-04', planQty: 4, pickedQty: null, short: false }
    ]
  }
];

/** 版本更新日志：最新版本在前，current 标记当前版本 */
const changelog: MockChangelog[] = [
  {
    version: 'v1.3.0',
    date: '2026-11-17',
    current: true,
    features: [
      '新增 PDA 拣货波次与扫码条码核对，支持缺货标记',
      '新增离线待提交队列，断网也能盘点、拣货与开单',
      '个人中心新增版本更新日志入口'
    ],
    fixes: [
      '修复盘点提交后库存查询未即时刷新的问题',
      '修复低库存商品可售数计算偏差'
    ]
  },
  {
    version: 'v1.2.0',
    date: '2026-11-10',
    features: [
      '新增移动盘点与实盘差异统计',
      '新增 AI 每日经营简报',
      '工作台快捷功能支持自定义排序'
    ],
    fixes: [
      '修复销售开单数量输入偶发丢失',
      '优化扫码查询在弱网下的加载提示'
    ]
  },
  {
    version: 'v1.1.0',
    date: '2026-11-03',
    features: [
      '新增扫码查库存与库存流水',
      '新增经营报表趋势图'
    ],
    fixes: [
      '修复深色主题下部分卡片文字对比度不足'
    ]
  }
];

/** 审批记录：同意/驳回后留痕（目前仅内存保存，用于演示） */
const approvalRecords: Array<MockTodo & { agree: boolean; opinion: string; handledAt: string }> = [];

/**
 * 把地址字符串拆成路径与查询参数
 * @param url 完整地址（含 API_BASE 与查询串）
 * @returns { path, query } path 为去掉基础地址后的路径，query 为键值对象
 */
function parseUrl(url: string): { path: string; query: Record<string, string> } {
  const clean = url.startsWith(API_BASE) ? url.slice(API_BASE.length) : url;
  const qIndex = clean.indexOf('?');
  const path = qIndex >= 0 ? clean.slice(0, qIndex) : clean;
  const query: Record<string, string> = {};
  if (qIndex >= 0) {
    const pairs = clean.slice(qIndex + 1).split('&');
    pairs.forEach((pair) => {
      if (!pair) return;
      const idx = pair.indexOf('=');
      const key = idx >= 0 ? pair.slice(0, idx) : pair;
      const value = idx >= 0 ? decodeURIComponent(pair.slice(idx + 1)) : '';
      query[key] = value;
    });
  }
  return { path, query };
}

/**
 * 模拟网络延迟，让加载态 / 骨架屏可见
 * @returns 120~300ms 后 resolve 的 Promise
 */
function delay(): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, 120 + Math.floor(Math.random() * 180)));
}

/**
 * 根据问题内容匹配规则，返回 AI 回复（规则兜底，无需真实模型）
 * @param question 用户提问
 * @returns 规则答案文本
 */
function buildAiAnswer(question: string): string {
  const q = question || '';
  if (/库存|条码|扫码|还有多少|剩余/.test(q)) {
    const low = products.filter((p) => p.onHand - p.occupied <= 5);
    const lines = low.map((p) => `· ${p.name}（${p.code}）可售 ${p.onHand - p.occupied} ${p.unit}`).join('\n');
    return `我查了当前库存，可售数量偏低的有 ${low.length} 项：\n${lines}\n建议优先安排补货，避免影响销售发货。`;
  }
  if (/应收|欠款|回款|逾期/.test(q)) {
    const overdue = todos.filter((t) => t.type === 'receivable');
    const total = overdue.reduce((sum, t) => sum + t.amount, 0);
    return `当前逾期应收共 ${overdue.length} 笔，合计 ¥${total.toLocaleString()}。其中「华远科技」逾期 15 天金额最大，建议今天电话跟进并发送对账单。`;
  }
  if (/补货|采购|缺货|补单/.test(q)) {
    const low = products.filter((p) => p.onHand - p.occupied <= 5);
    return `补货建议：${low.map((p) => p.name).join('、')} 可售已低于安全库存。建议按近 7 日销量 1.5 倍下单，优先处理数码配件类。`;
  }
  if (/销售|业绩|报表|经营|趋势/.test(q)) {
    return `今日销售额 ¥128,560，较昨日增长 12.4%；本月累计 ¥2,864,300。办公家具类毛利最高，数码配件类销量最大，建议加大高毛利品类的推广位。`;
  }
  if (/你好|您好|hi|hello/i.test(q)) {
    return '您好，我是 ERP AI 助理。可以问我「查库存」「查应收」「补货建议」或「经营解读」，我会基于当前业务数据给您答案。';
  }
  return `已收到您的问题：「${q}」。当前为演示版，我支持库存查询、应收查询、补货建议与经营解读四类问题，试试点击下方快捷问题。`;
}

/**
 * 生成商品库存流水：按固定规则造 4 条，便于点击库存行查看
 * @param product 商品对象
 * @returns 流水数组
 */
function buildLedger(product: MockProduct) {
  return [
    { id: 1, type: '入库', source: '采购收货 PO-2026-0181', qty: 50, balance: product.onHand, time: '2026-11-16 10:20' },
    { id: 2, type: '出库', source: '销售出库 SO-2026-0331', qty: -12, balance: product.onHand - 50 + 12, time: '2026-11-15 15:40' },
    { id: 3, type: '锁定', source: '销售订单占用 SO-2026-0332', qty: 0, balance: product.onHand, time: '2026-11-14 09:12' },
    { id: 4, type: '盘点', source: '月度盘点 PD-2026-001', qty: -2, balance: product.onHand - 2, time: '2026-11-10 08:00' }
  ];
}

/**
 * mock 统一入口：按“方法 + 路径”分发到各处理器
 * @param method 请求方法（GET/POST）
 * @param url 完整地址（含查询串）
 * @param body 请求体（POST 使用）
 * @returns 与真实接口解包后一致的 data
 */
export async function mockRequest<T = any>(method: string, url: string, body?: any): Promise<T> {
  await delay();
  const { path, query } = parseUrl(url);

  // ---------- 登录 ----------
  if (path === '/auth/login' && method === 'POST') {
    const { username, password } = body || {};
    if (username !== DEMO_ACCOUNT.username || password !== DEMO_ACCOUNT.password) {
      throw new Error('账号或密码错误');
    }
    return {
      token: 'mock-token-' + Date.now(),
      userInfo: {
        id: 1,
        username: 'admin',
        realName: '系统管理员',
        tenantId: 1,
        tenantName: 'LEAI 演示企业',
        deptName: '信息化部',
        perms: ['mobile:access', 'sale:create', 'stock:view', 'stocktake:submit', 'ai:chat']
      }
    } as T;
  }

  // ---------- 工作台聚合 ----------
  if (path === '/mobile/home' && method === 'GET') {
    const todoCount = todos.filter((t) => t.type === 'approval').length;
    const lowStock = products.filter((p) => p.onHand - p.occupied <= 5).length;
    const pendingShip = todos.filter((t) => t.type === 'ship').length;
    return {
      todo,
      kpis: [
        { key: 'todo', label: '待审批', value: todoCount, suffix: '条', color: '#4d6bfe' },
        { key: 'sale', label: '今日销售', value: '12.86', suffix: '万', color: '#16a34a' },
        { key: 'low', label: '低库存', value: lowStock, suffix: '项', color: '#d97706' },
        { key: 'ship', label: '待发货', value: pendingShip, suffix: '单', color: '#dc2626' }
      ],
      aiBrief: '今日经营整体平稳：销售额较昨日增长 12.4%，待审批 2 条、待发货 2 单；智能温控水杯与笔记本支架可售告急，建议今日补货。逾期应收 2 笔共 ¥36,150，建议优先跟进华远科技。',
      notices
    } as T;
  }

  // ---------- 待办列表 ----------
  if (path === '/mobile/todo' && method === 'GET') {
    return { list: todos.slice() } as T;
  }

  // ---------- 审批详情 ----------
  const approvalDetail = path.match(/^\/mobile\/approval\/(\d+)$/);
  if (approvalDetail && method === 'GET') {
    const item = todos.find((t) => t.id === Number(approvalDetail[1]));
    if (!item) throw new Error('审批单不存在或已处理');
    return {
      ...item,
      applicant: item.applicant,
      reason: item.type === 'approval' ? '业务需要，申请领导审批。' : '系统生成的待处理事项。',
      lines: [
        { name: item.type === 'approval' ? '采购物料' : '业务单据', qty: 1, amount: item.amount }
      ]
    } as T;
  }

  // ---------- 审批提交（同意/驳回）----------
  const approvalSubmit = path.match(/^\/mobile\/approval\/(\d+)\/approve$/);
  if (approvalSubmit && method === 'POST') {
    const id = Number(approvalSubmit[1]);
    const idx = todos.findIndex((t) => t.id === id);
    if (idx < 0) throw new Error('该审批已处理');
    const item = todos[idx];
    todos.splice(idx, 1);
    approvalRecords.push({
      ...item,
      agree: !!body?.agree,
      opinion: body?.opinion || (body?.agree ? '同意' : '驳回'),
      handledAt: new Date().toISOString()
    });
    return { success: true, message: body?.agree ? '已同意审批' : '已驳回审批' } as T;
  }

  // ---------- 扫码查询 ----------
  if (path === '/mobile/scan' && method === 'GET') {
    const code = (query.code || '').trim();
    const hit = products.find(
      (p) => p.code === code || p.barcode === code || p.skuCode === code || p.name.indexOf(code) >= 0
    );
    if (!hit) return { hit: false, code } as T;
    return {
      hit: true,
      code,
      product: {
        id: hit.id,
        name: hit.name,
        code: hit.code,
        barcode: hit.barcode,
        skuCode: hit.skuCode,
        price: hit.price,
        warehouse: hit.warehouse,
        available: hit.onHand - hit.occupied,
        unit: hit.unit
      }
    } as T;
  }

  // ---------- 库存查询（支持关键词、仓库、分页）----------
  if (path === '/mobile/stock' && method === 'GET') {
    const keyword = query.keyword || '';
    const warehouseId = query.warehouseId || '';
    const page = Number(query.page || 1);
    const pageSize = Number(query.pageSize || 6);
    let list = products.slice();
    if (keyword) {
      list = list.filter(
        (p) => p.name.indexOf(keyword) >= 0 || p.code.indexOf(keyword) >= 0 || p.barcode.indexOf(keyword) >= 0
      );
    }
    if (warehouseId) {
      list = list.filter((p) => String(p.warehouseId) === String(warehouseId));
    }
    const start = (page - 1) * pageSize;
    return {
      list: list.slice(start, start + pageSize).map((p) => ({
        id: p.id,
        name: p.name,
        code: p.code,
        warehouse: p.warehouse,
        onHand: p.onHand,
        occupied: p.occupied,
        available: p.onHand - p.occupied,
        unit: p.unit,
        price: p.price
      })),
      total: list.length,
      page,
      pageSize,
      warehouses
    } as T;
  }

  // ---------- 库存流水 ----------
  if (path === '/mobile/stock/ledger' && method === 'GET') {
    const product = products.find((p) => p.id === Number(query.id));
    if (!product) return { list: [] } as T;
    return { list: buildLedger(product) } as T;
  }

  // ---------- 盘点单列表 / 详情 ----------
  if (path === '/mobile/stocktake/list' && method === 'GET') {
    return {
      list: stocktakes.map((d) => ({
        id: d.id,
        name: d.name,
        warehouse: d.warehouse,
        status: d.status,
        createdAt: d.createdAt,
        lineCount: d.lines.length
      }))
    } as T;
  }
  if (path === '/mobile/stocktake/detail' && method === 'GET') {
    const doc = stocktakes.find((d) => d.id === query.id);
    if (!doc) throw new Error('盘点单不存在');
    return { ...doc, lines: doc.lines.map((l) => ({ ...l })) } as T;
  }

  // ---------- 盘点提交：按实盘数回写库存，真实改变 mock 数据 ----------
  if (path === '/mobile/stocktake/submit' && method === 'POST') {
    const doc = stocktakes.find((d) => d.id === body?.id);
    if (!doc) throw new Error('盘点单不存在');
    const lines = (body?.lines || []) as Array<{ id: number; realQty: number }>;
    let diffCount = 0;
    lines.forEach((line) => {
      const docLine = doc.lines.find((l) => l.id === line.id);
      if (!docLine || line.realQty === null || line.realQty === undefined || line.realQty === '') return;
      const realQty = Number(line.realQty);
      docLine.realQty = realQty;
      if (realQty !== docLine.bookQty) diffCount += 1;
      // 回写商品账面库存，使库存查询页立即看到变化
      const product = products.find((p) => p.id === docLine.productId);
      if (product) product.onHand = realQty;
    });
    doc.status = 'done';
    return { success: true, diffCount, docId: doc.id } as T;
  }

  // ---------- 销售开单 ----------
  if (path === '/mobile/sales/customers' && method === 'GET') {
    return { list: customers.slice() } as T;
  }
  if (path === '/mobile/sales/products' && method === 'GET') {
    return {
      list: products.map((p) => ({ id: p.id, name: p.name, code: p.code, price: p.price, unit: p.unit }))
    } as T;
  }
  if (path === '/mobile/sales/list' && method === 'GET') {
    return { list: salesOrders.slice() } as T;
  }
  if (path === '/mobile/sales/save' && method === 'POST') {
    const order: MockSalesOrder = {
      id: 'SO-' + Date.now().toString().slice(-6),
      customer: body?.customer || '未指定客户',
      amount: Number(body?.amount || 0),
      quantity: Number(body?.quantity || 0),
      status: '草稿',
      time: new Date().toISOString().slice(0, 16).replace('T', ' ')
    };
    salesOrders.unshift(order);
    return { ...order } as T;
  }
  if (path === '/mobile/sales/submit' && method === 'POST') {
    const order = salesOrders.find((o) => o.id === body?.id);
    if (order) order.status = '待审核';
    return { success: true, id: body?.id } as T;
  }

  // ---------- PDA 拣货：波次列表 ----------
  if (path === '/mobile/picking/waves' && method === 'GET') {
    return {
      list: waves.map((w) => ({
        id: w.id,
        name: w.name,
        warehouse: w.warehouse,
        status: w.status,
        createdAt: w.createdAt,
        lineCount: w.lines.length,
        pickedCount: w.lines.filter((l) => l.pickedQty !== null || l.short).length
      }))
    } as T;
  }

  // ---------- PDA 拣货：波次明细 ----------
  if (path === '/mobile/picking/detail' && method === 'GET') {
    const wave = waves.find((w) => w.id === query.id);
    if (!wave) throw new Error('拣货波次不存在');
    return { ...wave, lines: wave.lines.map((l) => ({ ...l })) } as T;
  }

  // ---------- PDA 拣货提交：真实扣减库存并更新波次状态 ----------
  if (path === '/mobile/picking/submit' && method === 'POST') {
    const wave = waves.find((w) => w.id === body?.id);
    if (!wave) throw new Error('拣货波次不存在');
    if (wave.status === 'done') throw new Error('拣货波次已完成，无需重复提交');
    const lines = (body?.lines || []) as Array<{ id: number; pickedQty: number; short: boolean }>;
    let pickedCount = 0;
    let shortCount = 0;
    lines.forEach((line) => {
      const docLine = wave.lines.find((l) => l.id === line.id);
      if (!docLine) return;
      if (line.short) {
        docLine.short = true;
        docLine.pickedQty = 0;
        shortCount += 1;
        return;
      }
      const qty = Number(line.pickedQty || 0);
      docLine.pickedQty = qty;
      docLine.short = false;
      pickedCount += 1;
      // 真实扣减商品账面库存（拣货出库），下限保护为 0
      const product = products.find((p) => p.id === docLine.productId);
      if (product) product.onHand = Math.max(0, product.onHand - qty);
    });
    wave.status = 'done';
    return { success: true, waveId: wave.id, pickedCount, shortCount } as T;
  }

  // ---------- 版本更新日志 ----------
  if (path === '/mobile/changelog' && method === 'GET') {
    return {
      list: changelog.map((item) => ({
        ...item,
        features: item.features.slice(),
        fixes: item.fixes.slice()
      }))
    } as T;
  }

  // ---------- 经营报表 ----------
  if (path === '/mobile/report' && method === 'GET') {
    return {
      metrics: [
        { label: '今日销售', value: '¥128,560', trend: '+12.4%', color: '#4d6bfe' },
        { label: '本月累计', value: '¥2,864,300', trend: '+8.1%', color: '#16a34a' },
        { label: '毛利率', value: '23.6%', trend: '+1.2%', color: '#d97706' },
        { label: '订单数', value: '186', trend: '+5.0%', color: '#dc2626' }
      ],
      trend: [
        { label: '周一', value: 86 },
        { label: '周二', value: 102 },
        { label: '周三', value: 94 },
        { label: '周四', value: 128 },
        { label: '周五', value: 141 },
        { label: '周六', value: 116 },
        { label: '周日', value: 133 }
      ],
      insight: '本周销售呈上升趋势，周五达到峰值 ¥14.1 万。办公家具类毛利贡献最高，建议周末加大数码配件促销；同时关注低库存商品的补货节奏。'
    } as T;
  }

  // ---------- AI 助理（规则兜底）----------
  if (path === '/ai/copilot' && method === 'POST') {
    return { reply: buildAiAnswer(body?.message || '') } as T;
  }

  // ---------- 兜底：未匹配的 mock 路径返回空结构，避免页面崩坏 ----------
  return { list: [], success: true } as T;
}
