<!--
 * ErpCard 通用卡片容器
 * 职责：统一页面的卡片外观（白底、1px 细边框、10px 圆角、轻阴影），与 PC 端 DsCard 视觉一致。
 * 核心 props：title 标题、accent 标题左侧色条、tight 是否紧凑内边距。
 * 插槽：extra 头部右侧操作区、default 卡片内容。
-->
<template>
  <view class="erp-card" :class="{ 'erp-card--tight': tight }">
    <!-- 头部：有标题或右侧操作区时才渲染 -->
    <view v-if="title || $slots.extra" class="erp-card__head">
      <view class="erp-card__title-wrap">
        <view v-if="accent" class="erp-card__accent" :style="{ background: accent }"></view>
        <text class="erp-card__title">{{ title }}</text>
      </view>
      <slot name="extra"></slot>
    </view>
    <!-- 内容区 -->
    <view class="erp-card__body">
      <slot></slot>
    </view>
  </view>
</template>

<script setup lang="ts">
withDefaults(
  defineProps<{
    /** 卡片标题，为空则不渲染头部 */
    title?: string;
    /** 标题左侧色条颜色，与 PC 品牌色体系一致 */
    accent?: string;
    /** 紧凑模式：减小内边距，用于列表项 */
    tight?: boolean;
  }>(),
  { title: '', accent: '', tight: false }
);
</script>

<style scoped>
.erp-card {
  background: var(--erp-card, #ffffff);
  border: 1px solid var(--erp-border, #e8eaed);
  border-radius: 10px;
  padding: 14px;
  margin-bottom: 12px;
  box-shadow: 0 1px 2px rgba(16, 24, 40, 0.04);
}
.erp-card--tight {
  padding: 10px 12px;
  margin-bottom: 8px;
}
.erp-card__head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 10px;
}
.erp-card__title-wrap {
  display: flex;
  align-items: center;
}
.erp-card__accent {
  width: 3px;
  height: 14px;
  border-radius: 2px;
  margin-right: 8px;
}
.erp-card__title {
  font-size: 14px;
  font-weight: 600;
  color: var(--erp-text, #1a1d21);
}
.erp-card__body {
  font-size: 13px;
  color: var(--erp-text-2, #4e5561);
}
</style>
