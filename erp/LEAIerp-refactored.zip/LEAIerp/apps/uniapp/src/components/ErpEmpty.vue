<!--
 * ErpEmpty 空状态占位
 * 职责：列表或详情无数据时统一展示，避免白屏；提供纯 CSS 绘制的线性空盒图标，不依赖图片资源。
 * 核心 props：text 主文案、hint 辅助说明。
-->
<template>
  <view class="erp-empty">
    <view class="erp-empty__box">
      <view class="erp-empty__lid"></view>
      <view class="erp-empty__body"></view>
    </view>
    <text class="erp-empty__text">{{ text }}</text>
    <text v-if="hint" class="erp-empty__hint">{{ hint }}</text>
  </view>
</template>

<script setup lang="ts">
withDefaults(
  defineProps<{
    /** 空状态主文案 */
    text?: string;
    /** 辅助说明 */
    hint?: string;
  }>(),
  { text: '暂无数据', hint: '' }
);
</script>

<style scoped>
.erp-empty {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 44px 16px;
}
.erp-empty__box {
  width: 46px;
  height: 40px;
  position: relative;
  margin-bottom: 14px;
}
.erp-empty__lid {
  position: absolute;
  top: 0;
  left: 2px;
  width: 42px;
  height: 10px;
  border: 1.5px solid var(--erp-text-3, #8a9099);
  border-radius: 4px 4px 2px 2px;
}
.erp-empty__body {
  position: absolute;
  top: 11px;
  left: 0;
  width: 46px;
  height: 28px;
  border: 1.5px solid var(--erp-text-3, #8a9099);
  border-radius: 2px 2px 6px 6px;
  opacity: 0.7;
}
.erp-empty__text {
  font-size: 13px;
  color: var(--erp-text-3, #8a9099);
}
.erp-empty__hint {
  margin-top: 6px;
  font-size: 12px;
  color: var(--erp-text-3, #8a9099);
  opacity: 0.8;
}
</style>
