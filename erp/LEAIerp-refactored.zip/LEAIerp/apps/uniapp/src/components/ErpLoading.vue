<!--
 * ErpLoading 加载态占位
 * 职责：数据请求中展示纯 CSS 转圈与文案，避免页面空白。
 * 核心 props：text 加载文案、inline 是否内联紧凑展示。
-->
<template>
  <view class="erp-loading" :class="{ 'erp-loading--inline': inline }">
    <view class="erp-loading__spinner"></view>
    <text class="erp-loading__text">{{ text }}</text>
  </view>
</template>

<script setup lang="ts">
withDefaults(
  defineProps<{
    /** 加载文案 */
    text?: string;
    /** 内联模式：减小上下留白 */
    inline?: boolean;
  }>(),
  { text: '加载中...', inline: false }
);
</script>

<style scoped>
.erp-loading {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 40px 16px;
}
.erp-loading--inline {
  padding: 16px;
}
.erp-loading__spinner {
  width: 26px;
  height: 26px;
  border: 2px solid rgba(77, 107, 254, 0.18);
  border-top-color: #4d6bfe;
  border-radius: 50%;
  animation: erp-spin 0.8s linear infinite;
}
.erp-loading__text {
  margin-top: 10px;
  font-size: 12px;
  color: var(--erp-text-3, #8a9099);
}
@keyframes erp-spin {
  to {
    transform: rotate(360deg);
  }
}
</style>
