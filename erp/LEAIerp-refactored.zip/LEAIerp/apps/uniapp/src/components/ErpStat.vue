<!--
 * ErpStat 指标统计块
 * 职责：工作台 KPI 与报表指标卡的统一展示：标签、数值、后缀、趋势说明。
 * 核心 props：label 标签、value 数值、suffix 后缀、color 强调色、hint 底部说明。
-->
<template>
  <view class="erp-stat">
    <view class="erp-stat__label">{{ label }}</view>
    <view class="erp-stat__value" :style="{ color: color || 'var(--erp-text, #1a1d21)' }">
      <text class="erp-stat__num">{{ value }}</text>
      <text v-if="suffix" class="erp-stat__suffix">{{ suffix }}</text>
    </view>
    <view v-if="hint" class="erp-stat__hint">{{ hint }}</view>
  </view>
</template>

<script setup lang="ts">
withDefaults(
  defineProps<{
    /** 指标名称 */
    label?: string;
    /** 指标数值 */
    value?: string | number;
    /** 数值后缀，如 万 / 条 / % */
    suffix?: string;
    /** 数值强调色 */
    color?: string;
    /** 底部辅助说明 */
    hint?: string;
  }>(),
  { label: '', value: '', suffix: '', color: '', hint: '' }
);
</script>

<style scoped>
.erp-stat {
  background: var(--erp-card, #ffffff);
  border: 1px solid var(--erp-border, #e8eaed);
  border-radius: 10px;
  padding: 12px;
}
.erp-stat__label {
  font-size: 12px;
  color: var(--erp-text-3, #8a9099);
}
.erp-stat__value {
  margin-top: 6px;
  display: flex;
  align-items: baseline;
}
.erp-stat__num {
  font-size: 22px;
  font-weight: 650;
  line-height: 1.2;
}
.erp-stat__suffix {
  font-size: 12px;
  margin-left: 2px;
  color: var(--erp-text-3, #8a9099);
}
.erp-stat__hint {
  margin-top: 4px;
  font-size: 12px;
  color: var(--erp-text-3, #8a9099);
}
</style>
