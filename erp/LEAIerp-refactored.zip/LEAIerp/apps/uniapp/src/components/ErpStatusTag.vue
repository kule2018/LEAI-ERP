<!--
 * ErpStatusTag 状态标签
 * 职责：统一列表中的状态展示，色调语义与 PC 端一致（info 蓝 / success 绿 / warning 橙 / danger 红）。
 * 核心 props：text 文案、tone 色调。
-->
<template>
  <view class="erp-tag" :class="'erp-tag--' + tone">
    <text>{{ text }}</text>
  </view>
</template>

<script setup lang="ts">
withDefaults(
  defineProps<{
    /** 标签文案 */
    text?: string;
    /** 语义色调 */
    tone?: 'info' | 'success' | 'warning' | 'danger';
  }>(),
  { text: '', tone: 'info' }
);
</script>

<style scoped>
.erp-tag {
  display: inline-flex;
  align-items: center;
  padding: 2px 8px;
  border-radius: 999px;
  font-size: 12px;
  line-height: 18px;
  border: 1px solid transparent;
}
.erp-tag--info {
  color: #4d6bfe;
  background: rgba(77, 107, 254, 0.1);
  border-color: rgba(77, 107, 254, 0.18);
}
.erp-tag--success {
  color: #16a34a;
  background: rgba(22, 163, 74, 0.1);
  border-color: rgba(22, 163, 74, 0.18);
}
.erp-tag--warning {
  color: #d97706;
  background: rgba(217, 119, 6, 0.1);
  border-color: rgba(217, 119, 6, 0.18);
}
.erp-tag--danger {
  color: #dc2626;
  background: rgba(220, 38, 38, 0.1);
  border-color: rgba(220, 38, 38, 0.18);
}
</style>
