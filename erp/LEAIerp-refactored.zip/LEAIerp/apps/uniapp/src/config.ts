/**
 * 全局配置常量
 * 职责：集中管理接口地址、本地存储 key、演示账号与品牌色，避免各页面散落魔法字符串。
 * 说明：环境变量由 Vite 在构建时注入；真机无法访问 localhost 时可用 VITE_API_BASE 指向局域网地址。
 */

/** 接口基础地址：默认 /api/v1，H5 走 vite 代理，真机用环境变量覆盖 */
export const API_BASE = import.meta.env.VITE_API_BASE || '/api/v1';

/**
 * 是否强制使用 mock。
 * 规则：只有显式设置为字符串 'false' 时才走真实请求；其余情况一律 mock。
 * 真实请求失败时仍会自动降级到 mock，保证“无后端也能演示”。
 */
export const USE_MOCK = import.meta.env.VITE_USE_MOCK !== 'false';

/** Token 本地存储 key（与 PC 管理端保持一致） */
export const TOKEN_KEY = 'erp_token';

/** 用户信息本地存储 key */
export const USER_KEY = 'erp_user_info';

/** 主题存储 key */
export const THEME_KEY = 'erp_theme';

/** 演示账号：登录页预填，同时作为 mock 校验依据 */
export const DEMO_ACCOUNT = {
  username: 'admin',
  password: 'admin123'
};

/** 品牌色：与 PC 端 DeepSeek UI 设计令牌一致 */
export const BRAND = '#4d6bfe';

/** tabBar 页面路径：跳转时需要用 switchTab，不能用 navigateTo */
export const TAB_PAGES = [
  '/pages/home/home',
  '/pages/todo/todo',
  '/pages/scan/scan',
  '/pages/mine/mine'
];
