/// <reference types="vite/client" />

/**
 * 环境变量类型声明
 * 说明：统一在这里补充本项目用到的 VITE_* 变量，避免页面里出现 any。
 */
interface ImportMetaEnv {
  /** 接口基础地址，默认 /api/v1 */
  readonly VITE_API_BASE?: string;
  /** 是否使用 mock：默认使用；显式设为 'false' 时优先请求真实后端 */
  readonly VITE_USE_MOCK?: string;
  /** H5 开发代理目标（仅 vite.config.ts 使用） */
  readonly VITE_PROXY_TARGET?: string;
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}
