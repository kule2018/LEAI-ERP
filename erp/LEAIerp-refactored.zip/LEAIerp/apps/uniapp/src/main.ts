import { createSSRApp } from 'vue';
import App from './App.vue';

/**
 * UniApp Vue3 入口
 * 说明：uni-app 要求导出 createApp 工厂，便于各端（H5 / 小程序 / App）复用同一实例创建逻辑。
 * @returns 包含 app 实例的对象
 */
export function createApp() {
  const app = createSSRApp(App);
  return { app };
}
