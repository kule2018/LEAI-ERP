<!--
 * ai.vue AI 助理对话页
 * 职责：输入问题获得规则兜底答案（查库存 / 查应收 / 补货建议 / 经营解读），带快捷问题。
 * 说明：消息区分用户与 AI 两种气泡样式；回答期间展示“思考中”占位，回答后自动滚动到底部。
-->
<template>
  <view class="erp-page ai" :class="{ 'theme-dark': appState.theme === 'dark' }">
    <!-- 对话区 -->
    <scroll-view class="ai__list" scroll-y :scroll-top="scrollTop" :scroll-with-animation="true">
      <view class="ai__intro">
        <view class="ai__intro-logo">AI</view>
        <text class="ai__intro-name">ERP AI 助理</text>
        <text class="ai__intro-desc">基于当前业务数据为您答疑，试试下面的快捷问题</text>
      </view>

      <view v-for="(msg, index) in messages" :key="index" class="ai__msg" :class="'ai__msg--' + msg.role">
        <view v-if="msg.role === 'ai'" class="ai__avatar">AI</view>
        <view class="ai__bubble">
          <text class="ai__bubble-text">{{ msg.content }}</text>
        </view>
        <view v-if="msg.role === 'user'" class="ai__avatar ai__avatar--user">我</view>
      </view>

      <view v-if="thinking" class="ai__msg ai__msg--ai">
        <view class="ai__avatar">AI</view>
        <view class="ai__bubble">
          <text class="ai__bubble-text ai__thinking">思考中...</text>
        </view>
      </view>
    </scroll-view>

    <!-- 快捷问题 -->
    <scroll-view class="ai__quick" scroll-x>
      <view class="ai__quick-inner">
        <view v-for="q in quickQuestions" :key="q" class="ai__quick-chip" @click="ask(q)">{{ q }}</view>
      </view>
    </scroll-view>

    <!-- 输入区 -->
    <view class="ai__composer">
      <input
        class="ai__input"
        v-model="inputText"
        placeholder="输入您的问题..."
        placeholder-class="ai__ph"
        confirm-type="send"
        @confirm="ask()"
      />
      <button class="erp-btn ai__send" :disabled="thinking || !inputText.trim()" @click="ask()">发送</button>
    </view>
  </view>
</template>

<script setup lang="ts">
import { nextTick, ref } from 'vue';
import { aiApi } from '../../api';
import { appState, userState } from '../../store';
import { showError, showToast } from '../../utils';

/** 对话消息：role 为 user / ai */
const messages = ref<Array<{ role: 'user' | 'ai'; content: string }>>([]);
/** 输入框内容 */
const inputText = ref('');
/** 是否正在等待回答 */
const thinking = ref(false);
/** 滚动位置，用于自动滚到底部 */
const scrollTop = ref(0);

/** 快捷问题 */
const quickQuestions = ['查库存', '查应收', '补货建议', '经营解读'];

/**
 * 滚动对话区到底部
 * @returns 无返回值
 */
async function scrollToBottom(): Promise<void> {
  await nextTick();
  // 用一个足够大的值触发滚动到末尾，uni 会自动收敛到最大可滚动距离
  scrollTop.value = scrollTop.value + 100000;
}

/**
 * 向 AI 提问
 * @param question 快捷问题文本，为空时取输入框内容
 * @returns 无返回值
 */
async function ask(question?: string): Promise<void> {
  if (thinking.value) return;
  const text = (question || inputText.value || '').trim();
  if (!text) {
    showToast('请输入您的问题');
    return;
  }
  messages.value.push({ role: 'user', content: text });
  inputText.value = '';
  thinking.value = true;
  await scrollToBottom();
  try {
    const result = await aiApi.chat(text);
    messages.value.push({ role: 'ai', content: result.reply || '暂时无法回答该问题' });
  } catch (err) {
    messages.value.push({ role: 'ai', content: '抱歉，服务暂时不可用，请稍后重试。' });
    showError(err);
  } finally {
    thinking.value = false;
    await scrollToBottom();
  }
}

// 进入页面时的欢迎语
messages.value.push({
  role: 'ai',
  content: `您好，${userState.realName || '管理员'}！我是 ERP AI 助理。我可以帮您查库存、查应收、给补货建议或解读经营报表。请问有什么可以帮您？`
});
</script>

<style scoped>
.ai {
  display: flex;
  flex-direction: column;
  height: 100vh;
  padding: 12px 12px 0;
  box-sizing: border-box;
}
.ai__list {
  flex: 1;
  min-height: 0;
  overflow: hidden;
}
.ai__intro {
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 16px 0 22px;
}
.ai__intro-logo {
  width: 44px;
  height: 44px;
  border-radius: 12px;
  background: #4d6bfe;
  color: #ffffff;
  font-size: 14px;
  font-weight: 600;
  display: flex;
  align-items: center;
  justify-content: center;
}
.ai__intro-name {
  margin-top: 10px;
  font-size: 14px;
  font-weight: 600;
  color: var(--erp-text, #1a1d21);
}
.ai__intro-desc {
  margin-top: 4px;
  font-size: 12px;
  color: var(--erp-text-3, #8a9099);
  text-align: center;
}
.ai__msg {
  display: flex;
  align-items: flex-start;
  margin-bottom: 16px;
}
.ai__msg--user {
  justify-content: flex-end;
}
.ai__avatar {
  width: 30px;
  height: 30px;
  border-radius: 8px;
  background: rgba(77, 107, 254, 0.12);
  color: #4d6bfe;
  font-size: 11px;
  display: flex;
  align-items: center;
  justify-content: center;
  flex: none;
  margin-right: 8px;
}
.ai__avatar--user {
  background: var(--erp-bg, #f5f6f8);
  color: var(--erp-text-2, #4e5561);
  margin-right: 0;
  margin-left: 8px;
}
.ai__bubble {
  max-width: 76%;
  padding: 10px 12px;
  border-radius: 10px;
  background: var(--erp-card, #ffffff);
  border: 1px solid var(--erp-border, #e8eaed);
}
.ai__msg--user .ai__bubble {
  background: #4d6bfe;
  border-color: #4d6bfe;
}
.ai__bubble-text {
  font-size: 13px;
  line-height: 1.6;
  color: var(--erp-text, #1a1d21);
  white-space: pre-wrap;
}
.ai__msg--user .ai__bubble-text {
  color: #ffffff;
}
.ai__thinking {
  color: var(--erp-text-3, #8a9099);
}
.ai__quick {
  white-space: nowrap;
  margin: 4px 0 10px;
}
.ai__quick-inner {
  display: inline-flex;
  gap: 8px;
}
.ai__quick-chip {
  padding: 6px 12px;
  border-radius: 999px;
  font-size: 12px;
  color: #4d6bfe;
  background: rgba(77, 107, 254, 0.1);
  border: 1px solid rgba(77, 107, 254, 0.18);
}
.ai__composer {
  display: flex;
  gap: 8px;
  padding: 10px 0 14px;
  border-top: 1px solid var(--erp-border, #e8eaed);
}
.ai__input {
  flex: 1;
  height: 40px;
  padding: 0 12px;
  border-radius: 10px;
  border: 1px solid var(--erp-border, #e8eaed);
  background: var(--erp-card, #ffffff);
  font-size: 13px;
  color: var(--erp-text, #1a1d21);
}
.ai__ph {
  color: var(--erp-text-3, #8a9099);
}
.ai__send {
  width: 68px;
  height: 40px;
  font-size: 13px;
}
</style>
