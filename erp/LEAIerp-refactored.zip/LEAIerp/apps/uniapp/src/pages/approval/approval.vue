<!--
 * approval.vue 审批详情
 * 职责：展示待审批事项详情，支持填写意见后同意或驳回；提交后该事项从待办中消失。
 * 说明：驳回必须填写意见；提交成功后短暂提示再返回上一页，返回后待办列表会自动刷新。
-->
<template>
  <view class="erp-page approval" :class="{ 'theme-dark': appState.theme === 'dark' }">
    <ErpLoading v-if="loading" text="正在加载审批详情..." />

    <ErpEmpty v-else-if="!detail" text="审批事项不存在或已处理" hint="可返回待办列表查看其他事项" />

    <template v-else>
      <!-- 事项概要 -->
      <ErpCard :title="detail.title" accent="#4d6bfe">
        <view class="approval__meta-grid">
          <view class="approval__meta-item">
            <text class="approval__meta-label">单据编号</text>
            <text class="approval__meta-value">{{ detail.bizNo }}</text>
          </view>
          <view class="approval__meta-item">
            <text class="approval__meta-label">申请人</text>
            <text class="approval__meta-value">{{ detail.applicant }}</text>
          </view>
          <view class="approval__meta-item">
            <text class="approval__meta-label">申请金额</text>
            <text class="approval__meta-value approval__amount">¥{{ formatMoney(detail.amount) }}</text>
          </view>
          <view class="approval__meta-item">
            <text class="approval__meta-label">提交时间</text>
            <text class="approval__meta-value">{{ detail.time }}</text>
          </view>
        </view>
      </ErpCard>

      <!-- 申请明细 -->
      <ErpCard title="申请明细" accent="#16a34a">
        <view v-for="(line, index) in detail.lines" :key="index" class="approval__line">
          <text class="approval__line-name">{{ line.name }}</text>
          <text class="approval__line-qty">x{{ line.qty }}</text>
          <text class="approval__line-amount">¥{{ formatMoney(line.amount) }}</text>
        </view>
        <view class="approval__reason">
          <text class="approval__reason-label">申请事由</text>
          <text class="approval__reason-text">{{ detail.reason }}</text>
        </view>
      </ErpCard>

      <!-- 审批意见 -->
      <ErpCard title="审批意见" accent="#d97706">
        <textarea
          class="approval__textarea"
          v-model="opinion"
          placeholder="请输入审批意见（驳回时必填）"
          placeholder-class="approval__ph"
          :maxlength="200"
        />
        <text class="approval__counter">{{ opinion.length }}/200</text>
      </ErpCard>

      <!-- 操作按钮 -->
      <view class="approval__actions">
        <button class="erp-btn erp-btn--plain approval__reject" :disabled="submitting" @click="handleReject">
          驳回
        </button>
        <button class="erp-btn approval__agree" :disabled="submitting" @click="handleAgree">同意</button>
      </view>
    </template>
  </view>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import { onLoad } from '@dcloudio/uni-app';
import ErpCard from '../../components/ErpCard.vue';
import ErpEmpty from '../../components/ErpEmpty.vue';
import ErpLoading from '../../components/ErpLoading.vue';
import { mobileApi } from '../../api';
import { appState } from '../../store';
import { formatMoney, showError, showToast, wait } from '../../utils';

/** 当前审批单 id */
const approvalId = ref<number>(0);
/** 审批详情数据 */
const detail = ref<any>(null);
/** 审批意见输入 */
const opinion = ref('');
/** 加载态 */
const loading = ref(true);
/** 提交中标记，防止重复点击 */
const submitting = ref(false);

/**
 * 加载审批详情；未传 id 时自动取第一条待审批事项
 * @returns 无返回值
 */
async function loadDetail(): Promise<void> {
  loading.value = true;
  try {
    if (!approvalId.value) {
      const todoResult = await mobileApi.todo();
      const first = (todoResult.list || []).find((item: any) => item.type === 'approval');
      if (!first) {
        detail.value = null;
        return;
      }
      approvalId.value = first.id;
    }
    detail.value = await mobileApi.approvalDetail(approvalId.value);
  } catch (err) {
    detail.value = null;
    showError(err);
  } finally {
    loading.value = false;
  }
}

/**
 * 提交审批结果
 * @param agree 是否同意
 * @returns 无返回值
 */
async function submit(agree: boolean): Promise<void> {
  if (submitting.value) return;
  if (!agree && !opinion.value.trim()) {
    showToast('驳回时必须填写审批意见');
    return;
  }
  submitting.value = true;
  try {
    const result = await mobileApi.approvalSubmit(approvalId.value, agree, opinion.value.trim());
    showToast(result.message || '提交成功', 'success');
    await wait(700);
    goBack();
  } catch (err) {
    showError(err);
  } finally {
    submitting.value = false;
  }
}

/** 同意审批 */
function handleAgree(): void {
  submit(true);
}

/** 驳回审批 */
function handleReject(): void {
  submit(false);
}

/**
 * 返回上一页；若为直接打开的页面则回退到待办 tab
 * @returns 无返回值
 */
function goBack(): void {
  const pages = getCurrentPages();
  if (pages && pages.length > 1) {
    uni.navigateBack();
  } else {
    uni.switchTab({ url: '/pages/todo/todo' });
  }
}

onLoad((options: any) => {
  approvalId.value = Number(options && options.id ? options.id : 0);
  loadDetail();
});
</script>

<style scoped>
.approval__meta-grid {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 12px 8px;
}
.approval__meta-item {
  display: flex;
  flex-direction: column;
}
.approval__meta-label {
  font-size: 12px;
  color: var(--erp-text-3, #8a9099);
}
.approval__meta-value {
  margin-top: 4px;
  font-size: 13px;
  color: var(--erp-text, #1a1d21);
}
.approval__amount {
  color: #dc2626;
  font-weight: 600;
}
.approval__line {
  display: flex;
  align-items: center;
  padding: 8px 0;
  border-bottom: 1px solid var(--erp-divider, #eef0f2);
}
.approval__line-name {
  flex: 1;
  font-size: 13px;
  color: var(--erp-text, #1a1d21);
}
.approval__line-qty {
  width: 50px;
  text-align: right;
  font-size: 12px;
  color: var(--erp-text-3, #8a9099);
}
.approval__line-amount {
  width: 90px;
  text-align: right;
  font-size: 13px;
  color: var(--erp-text, #1a1d21);
}
.approval__reason {
  margin-top: 12px;
  padding: 10px;
  background: var(--erp-bg, #f5f6f8);
  border-radius: 8px;
}
.approval__reason-label {
  display: block;
  font-size: 12px;
  color: var(--erp-text-3, #8a9099);
}
.approval__reason-text {
  display: block;
  margin-top: 4px;
  font-size: 13px;
  color: var(--erp-text-2, #4e5561);
}
.approval__textarea {
  width: 100%;
  min-height: 80px;
  padding: 10px;
  box-sizing: border-box;
  border: 1px solid var(--erp-border, #e8eaed);
  border-radius: 8px;
  font-size: 13px;
  color: var(--erp-text, #1a1d21);
  background: var(--erp-card, #ffffff);
}
.approval__ph {
  color: var(--erp-text-3, #8a9099);
}
.approval__counter {
  display: block;
  text-align: right;
  margin-top: 4px;
  font-size: 12px;
  color: var(--erp-text-3, #8a9099);
}
.approval__actions {
  display: flex;
  gap: 12px;
  margin-top: 4px;
}
.approval__reject,
.approval__agree {
  flex: 1;
}
</style>
