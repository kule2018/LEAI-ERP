<!--
 * changelog.vue 版本更新日志
 * 职责：按版本倒序展示版本号、发布日期、新特性与修复列表，数据来自 mock 接口并带本地兜底。
 * 说明：最新版本用「当前版本」标签与绿色色条强调，列表项用圆点区分新增与修复两类。
-->
<template>
  <view class="erp-page changelog" :class="{ 'theme-dark': appState.theme === 'dark' }">
    <view class="changelog__head">
      <text class="changelog__title">版本更新日志</text>
      <text class="changelog__sub">LEAI ERP 移动端 · 持续迭代中</text>
    </view>

    <ErpLoading v-if="loading" text="正在加载版本日志..." />
    <template v-else>
      <ErpCard
        v-for="item in versions"
        :key="item.version"
        :title="item.version"
        :accent="item.current ? '#16a34a' : '#4d6bfe'"
      >
        <template #extra>
          <ErpStatusTag v-if="item.current" text="当前版本" tone="success" />
          <text v-else class="changelog__date">{{ item.date }}</text>
        </template>
        <view v-if="item.current" class="changelog__current-date">发布日期：{{ item.date }}</view>

        <view class="changelog__section">
          <view class="changelog__section-title">新特性</view>
          <view v-for="(feature, index) in item.features" :key="'f' + index" class="changelog__line">
            <text class="changelog__dot changelog__dot--feature">•</text>
            <text class="changelog__line-text">{{ feature }}</text>
          </view>
        </view>

        <view class="changelog__section">
          <view class="changelog__section-title">问题修复</view>
          <view v-for="(fix, index) in item.fixes" :key="'x' + index" class="changelog__line">
            <text class="changelog__dot changelog__dot--fix">•</text>
            <text class="changelog__line-text">{{ fix }}</text>
          </view>
        </view>
      </ErpCard>

      <view class="changelog__footer">已展示全部历史版本</view>
    </template>
  </view>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import { onLoad } from '@dcloudio/uni-app';
import ErpCard from '../../components/ErpCard.vue';
import ErpLoading from '../../components/ErpLoading.vue';
import ErpStatusTag from '../../components/ErpStatusTag.vue';
import { mobileApi } from '../../api';
import { appState } from '../../store';
import { showError } from '../../utils';

/** 接口异常时的本地兜底数据，保证页面始终有内容 */
const FALLBACK: any[] = [
  {
    version: 'v1.3.0',
    date: '2026-11-17',
    current: true,
    features: ['新增 PDA 拣货与扫码核对', '新增离线待提交队列', '个人中心新增版本更新日志入口'],
    fixes: ['修复盘点提交后库存未即时刷新', '修复低库存可售数计算偏差']
  }
];

/** 版本日志列表 */
const versions = ref<any[]>([]);
/** 加载态 */
const loading = ref(true);

/**
 * 加载版本日志：优先走接口，失败时用本地常量兜底
 * @returns 无返回值
 */
async function loadChangelog(): Promise<void> {
  loading.value = true;
  try {
    const data = await mobileApi.changelog();
    versions.value = data.list && data.list.length ? data.list : FALLBACK;
  } catch (err) {
    versions.value = FALLBACK;
    showError(err);
  } finally {
    loading.value = false;
  }
}

onLoad(() => {
  loadChangelog();
});
</script>

<style scoped>
.changelog__head {
  padding: 4px 2px 16px;
}
.changelog__title {
  display: block;
  font-size: 18px;
  font-weight: 650;
  color: var(--erp-text, #1a1d21);
}
.changelog__sub {
  display: block;
  margin-top: 4px;
  font-size: 12px;
  color: var(--erp-text-3, #8a9099);
}
.changelog__date {
  font-size: 12px;
  color: var(--erp-text-3, #8a9099);
}
.changelog__current-date {
  font-size: 12px;
  color: var(--erp-text-3, #8a9099);
  margin-bottom: 10px;
}
.changelog__section {
  margin-top: 12px;
}
.changelog__section-title {
  font-size: 13px;
  font-weight: 600;
  color: var(--erp-text-2, #4e5561);
  margin-bottom: 6px;
}
.changelog__line {
  display: flex;
  align-items: flex-start;
  padding: 3px 0;
}
.changelog__dot {
  width: 16px;
  flex: none;
  font-size: 14px;
  line-height: 1.6;
}
.changelog__dot--feature {
  color: #16a34a;
}
.changelog__dot--fix {
  color: #d97706;
}
.changelog__line-text {
  flex: 1;
  font-size: 13px;
  line-height: 1.6;
  color: var(--erp-text, #1a1d21);
}
.changelog__footer {
  margin-top: 8px;
  text-align: center;
  font-size: 12px;
  color: var(--erp-text-3, #8a9099);
}
</style>
