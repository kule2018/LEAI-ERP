<!--
 * home.vue 个人工作台
 * 职责：聚合展示 KPI 指标、九宫格快捷功能、AI 每日简报与公告，并作为各业务页面的导航入口。
 * 数据：来自 /mobile/home 聚合接口（mock 模式下为本地模拟数据），支持下拉刷新。
-->
<template>
  <view class="erp-page home" :class="{ 'theme-dark': appState.theme === 'dark' }">
    <!-- 顶部问候 -->
    <view class="home__greeting">
      <view>
        <text class="home__hello">{{ greeting }}，{{ userState.realName || '管理员' }}</text>
        <text class="home__date">{{ todayText }} · {{ userState.tenantName || '演示企业' }}</text>
      </view>
      <view class="home__avatar">{{ (userState.realName || '管').slice(0, 1) }}</view>
    </view>

    <!-- 加载态 -->
    <ErpLoading v-if="loading" text="正在加载工作台..." />

    <!-- 错误态：带重试按钮 -->
    <ErpCard v-else-if="error" title="加载失败">
      <text class="home__error-text">{{ error }}</text>
      <button class="erp-btn erp-btn--plain home__retry" @click="loadData">重新加载</button>
    </ErpCard>

    <template v-else>
      <!-- KPI 指标：4 个统计块，2x2 网格 -->
      <view class="home__kpi-grid">
        <ErpStat
          v-for="kpi in homeData.kpis"
          :key="kpi.key"
          :label="kpi.label"
          :value="kpi.value"
          :suffix="kpi.suffix"
          :color="kpi.color"
        />
      </view>

      <!-- 快捷功能九宫格 -->
      <ErpCard title="快捷功能" accent="#4d6bfe">
        <view class="home__quick-grid">
          <view v-for="item in quickItems" :key="item.key" class="home__quick-item" @click="onQuickClick(item)">
            <view class="home__quick-icon" :style="{ background: item.color + '1f', color: item.color }">
              {{ item.icon }}
            </view>
            <text class="home__quick-label">{{ item.label }}</text>
          </view>
        </view>
      </ErpCard>

      <!-- AI 每日简报 -->
      <ErpCard title="AI 每日简报" accent="#16a34a">
        <template #extra>
          <text class="home__link" @click="goPage('/pages/ai/ai')">问 AI ></text>
        </template>
        <text class="home__brief">{{ homeData.aiBrief }}</text>
      </ErpCard>

      <!-- 公告列表 -->
      <ErpCard title="企业公告" accent="#d97706">
        <view v-for="notice in homeData.notices" :key="notice.id" class="home__notice" @click="openNotice(notice)">
          <view class="home__notice-dot"></view>
          <text class="home__notice-title">{{ notice.title }}</text>
          <text class="home__notice-time">{{ notice.time }}</text>
        </view>
      </ErpCard>
    </template>
  </view>
</template>

<script setup lang="ts">
import { computed, ref } from 'vue';
import { onPullDownRefresh, onShow } from '@dcloudio/uni-app';
import ErpCard from '../../components/ErpCard.vue';
import ErpLoading from '../../components/ErpLoading.vue';
import ErpStat from '../../components/ErpStat.vue';
import { mobileApi } from '../../api';
import { appState, userState } from '../../store';
import { goPage, showError } from '../../utils';

/** 工作台聚合数据 */
const homeData = ref<any>({ kpis: [], notices: [], aiBrief: '' });
/** 页面加载态 */
const loading = ref(true);
/** 加载错误信息 */
const error = ref('');

/** 快捷功能项：icon 用单个汉字，避免依赖图标库或图片资源 */
const quickItems = [
  { key: 'todo', label: '待办', icon: '审', color: '#4d6bfe', url: '/pages/todo/todo' },
  { key: 'scan', label: '扫码', icon: '扫', color: '#4d6bfe', url: '/pages/scan/scan' },
  { key: 'stock', label: '库存', icon: '库', color: '#16a34a', url: '/pages/stock/stock' },
  { key: 'stocktake', label: '盘点', icon: '盘', color: '#16a34a', url: '/pages/stocktake/stocktake' },
  { key: 'picking', label: '拣货', icon: '拣', color: '#4d6bfe', url: '/pages/picking/picking' },
  { key: 'sales', label: '开单', icon: '单', color: '#d97706', url: '/pages/sales/sales' },
  { key: 'report', label: '报表', icon: '报', color: '#d97706', url: '/pages/report/report' },
  { key: 'ai', label: 'AI 助理', icon: 'AI', color: '#4d6bfe', url: '/pages/ai/ai' },
  { key: 'notice', label: '公告', icon: '公', color: '#dc2626', url: '' },
  { key: 'mine', label: '我的', icon: '我', color: '#8a9099', url: '/pages/mine/mine' }
];

/** 根据当前小时生成问候语 */
const greeting = computed(() => {
  const hour = new Date().getHours();
  if (hour < 12) return '早上好';
  if (hour < 18) return '下午好';
  return '晚上好';
});

/** 今日日期文本 */
const todayText = computed(() => {
  const now = new Date();
  return `${now.getFullYear()}年${now.getMonth() + 1}月${now.getDate()}日`;
});

/**
 * 加载工作台数据
 * @returns 无返回值
 */
async function loadData(): Promise<void> {
  loading.value = true;
  error.value = '';
  try {
    homeData.value = await mobileApi.home();
  } catch (err) {
    error.value = err instanceof Error ? err.message : '数据加载失败';
    showError(err);
  } finally {
    loading.value = false;
  }
}

/**
 * 快捷功能点击：公告走弹窗，其余跳转对应页面
 * @param item 快捷功能项
 * @returns 无返回值
 */
function onQuickClick(item: { key: string; label: string; url: string }): void {
  if (item.key === 'notice') {
    const first = homeData.value.notices && homeData.value.notices[0];
    if (first) openNotice(first);
    return;
  }
  if (item.url) goPage(item.url);
}

/**
 * 查看公告详情
 * @param notice 公告对象
 * @returns 无返回值
 */
function openNotice(notice: { title: string; content: string; time: string }): void {
  uni.showModal({
    title: notice.title,
    content: `${notice.time}\n\n${notice.content}`,
    showCancel: false,
    confirmColor: '#4d6bfe'
  });
}

// 页面显示时刷新，保证从审批 / 盘点返回后数据是最新的
onShow(() => {
  loadData();
});

// 下拉刷新
onPullDownRefresh(async () => {
  await loadData();
  uni.stopPullDownRefresh();
});
</script>

<style scoped>
.home__greeting {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 6px 2px 16px;
}
.home__hello {
  display: block;
  font-size: 16px;
  font-weight: 600;
  color: var(--erp-text, #1a1d21);
}
.home__date {
  display: block;
  margin-top: 4px;
  font-size: 12px;
  color: var(--erp-text-3, #8a9099);
}
.home__avatar {
  width: 40px;
  height: 40px;
  border-radius: 50%;
  background: #4d6bfe;
  color: #ffffff;
  font-size: 14px;
  display: flex;
  align-items: center;
  justify-content: center;
}
.home__kpi-grid {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 10px;
  margin-bottom: 12px;
}
.home__quick-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  row-gap: 16px;
}
.home__quick-item {
  display: flex;
  flex-direction: column;
  align-items: center;
}
.home__quick-icon {
  width: 42px;
  height: 42px;
  border-radius: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 14px;
  font-weight: 600;
}
.home__quick-label {
  margin-top: 6px;
  font-size: 12px;
  color: var(--erp-text-2, #4e5561);
}
.home__link {
  font-size: 12px;
  color: #4d6bfe;
}
.home__brief {
  font-size: 13px;
  line-height: 1.7;
  color: var(--erp-text-2, #4e5561);
}
.home__notice {
  display: flex;
  align-items: center;
  padding: 9px 0;
  border-bottom: 1px solid var(--erp-divider, #eef0f2);
}
.home__notice:last-child {
  border-bottom: none;
}
.home__notice-dot {
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background: #4d6bfe;
  margin-right: 8px;
  flex: none;
}
.home__notice-title {
  flex: 1;
  font-size: 13px;
  color: var(--erp-text, #1a1d21);
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.home__notice-time {
  margin-left: 8px;
  font-size: 12px;
  color: var(--erp-text-3, #8a9099);
}
.home__error-text {
  font-size: 13px;
  color: var(--erp-text-3, #8a9099);
}
.home__retry {
  margin-top: 12px;
  height: 34px;
}
</style>
