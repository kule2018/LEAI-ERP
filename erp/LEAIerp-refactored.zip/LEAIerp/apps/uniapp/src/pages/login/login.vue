<!--
 * login.vue 登录页
 * 职责：账号密码登录（admin/admin123）与演示模式直接进入；登录成功后写入 token 与用户信息。
 * 说明：默认预填演示账号，方便无后端环境下直接体验；演示模式直接构造一份用户信息写入本地存储。
-->
<template>
  <view class="login" :class="{ 'theme-dark': appState.theme === 'dark' }">
    <!-- 品牌头部 -->
    <view class="login__header">
      <view class="login__logo">E</view>
      <text class="login__name">LEAI ERP</text>
      <text class="login__sub">中小企业一体化云管理平台</text>
    </view>

    <!-- 登录表单卡片 -->
    <view class="login__card">
      <view class="login__field">
        <text class="login__label">账号</text>
        <input
          class="login__input"
          v-model="username"
          placeholder="请输入账号"
          placeholder-class="login__ph"
          confirm-type="next"
        />
      </view>
      <view class="login__field">
        <text class="login__label">密码</text>
        <input
          class="login__input"
          v-model="password"
          placeholder="请输入密码"
          placeholder-class="login__ph"
          :password="true"
          confirm-type="done"
          @confirm="handleLogin"
        />
      </view>

      <button class="erp-btn login__submit" :loading="loading" :disabled="loading" @click="handleLogin">
        登录
      </button>
      <button class="erp-btn erp-btn--ghost login__demo" @click="handleDemo">
        演示模式进入
      </button>

      <view class="login__tip">演示账号：admin / admin123</view>
    </view>

    <view class="login__footer">登录即表示同意企业账号使用规范</view>
  </view>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import { authApi } from '../../api';
import { DEMO_ACCOUNT } from '../../config';
import { appState, isLoggedIn, setLogin } from '../../store';
import { goPage, showError, showToast, wait } from '../../utils';

/** 账号输入框绑定值，默认预填演示账号 */
const username = ref(DEMO_ACCOUNT.username);
/** 密码输入框绑定值，默认预填演示密码 */
const password = ref(DEMO_ACCOUNT.password);
/** 登录按钮加载态，防止重复提交 */
const loading = ref(false);

/**
 * 账号密码登录
 * 流程：校验输入 → 调用登录接口 → 写入登录态 → 跳转工作台。
 * @returns 无返回值
 */
async function handleLogin(): Promise<void> {
  if (loading.value) return;
  if (!username.value || !password.value) {
    showToast('请输入账号和密码');
    return;
  }
  loading.value = true;
  try {
    const result = await authApi.login(username.value, password.value);
    setLogin(result);
    showToast('登录成功', 'success');
    await wait(400);
    goPage('/pages/home/home');
  } catch (error) {
    showError(error);
  } finally {
    loading.value = false;
  }
}

/**
 * 演示模式直接进入：不请求接口，直接构造一份演示用户信息写入本地
 * @returns 无返回值
 */
async function handleDemo(): Promise<void> {
  if (isLoggedIn()) {
    goPage('/pages/home/home');
    return;
  }
  setLogin({
    token: 'demo-token-' + Date.now(),
    userInfo: {
      id: 1,
      username: 'admin',
      realName: '系统管理员',
      tenantName: 'LEAI 演示企业',
      deptName: '信息化部',
      perms: ['mobile:access', 'sale:create', 'stock:view', 'stocktake:submit', 'ai:chat']
    }
  });
  showToast('已进入演示模式', 'success');
  await wait(400);
  goPage('/pages/home/home');
}
</script>

<style scoped>
.login {
  min-height: 100vh;
  padding: 0 24px;
  background: linear-gradient(180deg, #f0f3ff 0%, var(--erp-bg, #f5f6f8) 42%);
  box-sizing: border-box;
}
.login__header {
  padding: 72px 0 36px;
  display: flex;
  flex-direction: column;
  align-items: center;
}
.login__logo {
  width: 56px;
  height: 56px;
  border-radius: 14px;
  background: #4d6bfe;
  color: #ffffff;
  font-size: 28px;
  font-weight: 700;
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: 0 8px 20px rgba(77, 107, 254, 0.24);
}
.login__name {
  margin-top: 14px;
  font-size: 20px;
  font-weight: 650;
  color: var(--erp-text, #1a1d21);
}
.login__sub {
  margin-top: 4px;
  font-size: 12px;
  color: var(--erp-text-3, #8a9099);
}
.login__card {
  background: var(--erp-card, #ffffff);
  border: 1px solid var(--erp-border, #e8eaed);
  border-radius: 14px;
  padding: 20px 16px;
  box-shadow: 0 6px 20px rgba(16, 24, 40, 0.06);
}
.login__field {
  margin-bottom: 16px;
}
.login__label {
  display: block;
  font-size: 13px;
  color: var(--erp-text-2, #4e5561);
  margin-bottom: 8px;
}
.login__input {
  height: 42px;
  padding: 0 12px;
  border: 1px solid var(--erp-border, #e8eaed);
  border-radius: 10px;
  font-size: 14px;
  color: var(--erp-text, #1a1d21);
  background: var(--erp-card, #ffffff);
}
.login__ph {
  color: var(--erp-text-3, #8a9099);
}
.login__submit {
  margin-top: 8px;
}
.login__demo {
  margin-top: 12px;
}
.login__tip {
  margin-top: 14px;
  text-align: center;
  font-size: 12px;
  color: var(--erp-text-3, #8a9099);
}
.login__footer {
  margin-top: 28px;
  text-align: center;
  font-size: 12px;
  color: var(--erp-text-3, #8a9099);
}
</style>
