<!--
 * mine.vue 个人中心
 * 职责：展示用户信息与权限、切换主题、清除缓存、退出登录。
 * 说明：清除缓存只清本地非登录数据并保留 token；退出登录会清空登录态并返回登录页。
-->
<template>
  <view class="erp-page mine" :class="{ 'theme-dark': appState.theme === 'dark' }">
    <!-- 用户卡片 -->
    <ErpCard>
      <view class="mine__profile">
        <view class="mine__avatar">{{ (userState.realName || '管').slice(0, 1) }}</view>
        <view class="mine__profile-info">
          <text class="mine__name">{{ userState.realName || '未登录' }}</text>
          <text class="mine__username">账号：{{ userState.username || '-' }}</text>
        </view>
        <ErpStatusTag text="已认证" tone="success" />
      </view>
      <view class="mine__org">
        <text>{{ userState.tenantName || '演示企业' }}</text>
        <text>{{ userState.deptName || '信息化部' }}</text>
      </view>
    </ErpCard>

    <!-- 权限列表 -->
    <ErpCard title="我的权限" accent="#4d6bfe">
      <view v-if="userState.perms.length" class="mine__perms">
        <text v-for="perm in userState.perms" :key="perm" class="mine__perm">{{ perm }}</text>
      </view>
      <ErpEmpty v-else text="暂无权限数据" size="sm" />
    </ErpCard>

    <!-- 设置项 -->
    <ErpCard title="设置" accent="#16a34a">
      <view class="mine__setting">
        <text class="mine__setting-label" @click="changeTheme">深色主题</text>
        <switch :checked="appState.theme === 'dark'" color="#4d6bfe" @change="onSwitchChange" />
      </view>
      <view class="mine__setting" @click="clearCache">
        <text class="mine__setting-label">清除缓存</text>
        <text class="mine__setting-value">已使用 {{ cacheSize }} KB ></text>
      </view>
      <view class="mine__setting" @click="openAbout">
        <text class="mine__setting-label">关于系统</text>
        <text class="mine__setting-value">v1.0.0 ></text>
      </view>
    </ErpCard>

    <!-- 更多功能：离线队列与版本日志 -->
    <ErpCard title="更多功能" accent="#8a9099">
      <view class="mine__setting" @click="goPage('/pages/offline/offline')">
        <text class="mine__setting-label">离线待提交</text>
        <text class="mine__setting-value">{{ offlineCount }} 项待提交 ></text>
      </view>
      <view class="mine__setting" @click="goPage('/pages/changelog/changelog')">
        <text class="mine__setting-label">版本更新日志</text>
        <text class="mine__setting-value">v1.3.0 ></text>
      </view>
    </ErpCard>

    <!-- 退出登录 -->
    <button class="erp-btn erp-btn--plain mine__logout" @click="handleLogout">退出登录</button>

    <view class="mine__footer">LEAI ERP · 让企业管理更简单</view>
  </view>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import ErpCard from '../../components/ErpCard.vue';
import ErpEmpty from '../../components/ErpEmpty.vue';
import ErpStatusTag from '../../components/ErpStatusTag.vue';
import { TOKEN_KEY, USER_KEY } from '../../config';
import { appState, logout, userState } from '../../store';
import { confirmAction, goPage, showToast } from '../../utils';
import { OFFLINE_QUEUE_KEY, initOfflineQueue, offlineCount } from '../../utils/offlineQueue';

/** 模拟的缓存占用大小（KB），仅用于展示 */
const cacheSize = ref(128);

/**
 * 切换主题：点击整行或 switch 均可触发
 * @returns 无返回值
 */
function changeTheme(): void {
  const next = appState.theme === 'dark' ? 'light' : 'dark';
  appState.theme = next;
  uni.setStorageSync('erp_theme', next);
  showToast(next === 'dark' ? '已开启深色主题' : '已关闭深色主题');
}

/**
 * switch 组件变化：仅当目标状态与当前状态不同时才切换，避免与整行点击重复触发
 * @param event switch change 事件，detail.value 为目标是否开启
 * @returns 无返回值
 */
function onSwitchChange(event: any): void {
  const target = event && event.detail && event.detail.value ? 'dark' : 'light';
  if (target !== appState.theme) changeTheme();
}

/**
 * 清除本地缓存：保留登录态与主题设置
 * @returns 无返回值
 */
async function clearCache(): Promise<void> {
  const ok = await confirmAction('确定清除本地缓存吗？登录状态会保留。', '清除缓存');
  if (!ok) return;
  const token = uni.getStorageSync(TOKEN_KEY);
  const user = uni.getStorageSync(USER_KEY);
  const theme = appState.theme;
  const offlineRaw = uni.getStorageSync(OFFLINE_QUEUE_KEY);
  uni.clearStorageSync();
  if (token) uni.setStorageSync(TOKEN_KEY, token);
  if (user) uni.setStorageSync(USER_KEY, user);
  if (offlineRaw) uni.setStorageSync(OFFLINE_QUEUE_KEY, offlineRaw);
  uni.setStorageSync('erp_theme', theme);
  initOfflineQueue();
  cacheSize.value = 0;
  showToast('缓存已清除', 'success');
}

/**
 * 关于系统弹窗
 * @returns 无返回值
 */
function openAbout(): void {
  uni.showModal({
    title: '关于系统',
    content: 'LEAI ERP 移动端 v1.3.0\n基于 UniApp + Vue3 构建\n支持 H5 / 微信小程序 / 支付宝小程序 / App',
    showCancel: false,
    confirmColor: '#4d6bfe'
  });
}

/**
 * 退出登录：二次确认后清空状态并返回登录页
 * @returns 无返回值
 */
async function handleLogout(): Promise<void> {
  const ok = await confirmAction('确定退出当前账号吗？', '退出登录');
  if (!ok) return;
  logout();
  uni.reLaunch({ url: '/pages/login/login' });
}
</script>

<style scoped>
.mine__profile {
  display: flex;
  align-items: center;
}
.mine__avatar {
  width: 52px;
  height: 52px;
  border-radius: 50%;
  background: #4d6bfe;
  color: #ffffff;
  font-size: 18px;
  display: flex;
  align-items: center;
  justify-content: center;
  flex: none;
}
.mine__profile-info {
  flex: 1;
  margin-left: 12px;
}
.mine__name {
  display: block;
  font-size: 16px;
  font-weight: 600;
  color: var(--erp-text, #1a1d21);
}
.mine__username {
  display: block;
  margin-top: 4px;
  font-size: 12px;
  color: var(--erp-text-3, #8a9099);
}
.mine__org {
  display: flex;
  justify-content: space-between;
  margin-top: 14px;
  padding-top: 12px;
  border-top: 1px solid var(--erp-divider, #eef0f2);
  font-size: 12px;
  color: var(--erp-text-2, #4e5561);
}
.mine__perms {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
}
.mine__perm {
  padding: 4px 10px;
  border-radius: 6px;
  font-size: 12px;
  color: #4d6bfe;
  background: rgba(77, 107, 254, 0.1);
}
.mine__setting {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 12px 0;
  border-bottom: 1px solid var(--erp-divider, #eef0f2);
}
.mine__setting:last-child {
  border-bottom: none;
}
.mine__setting-label {
  font-size: 13px;
  color: var(--erp-text, #1a1d21);
}
.mine__setting-value {
  font-size: 12px;
  color: var(--erp-text-3, #8a9099);
}
.mine__logout {
  margin-top: 8px;
}
.mine__footer {
  margin-top: 24px;
  text-align: center;
  font-size: 12px;
  color: var(--erp-text-3, #8a9099);
}
</style>
