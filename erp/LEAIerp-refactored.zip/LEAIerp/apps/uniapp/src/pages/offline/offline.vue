<!--
 * offline.vue 离线待提交
 * 职责：展示断网时暂存的盘点 / 拣货 / 销售开单操作，支持手动同步、单条删除与清空队列。
 * 说明：同步逐条回放，成功移出队列；失败保留并累加重试次数；业务冲突单独提示，避免用户误以为已提交。
-->
<template>
  <view class="erp-page offline" :class="{ 'theme-dark': appState.theme === 'dark' }">
    <ErpCard title="离线待提交" accent="#4d6bfe">
      <template #extra>
        <text class="offline__refresh" @click="reload">刷新</text>
      </template>
      <view class="offline__summary">
        <view class="offline__stat">
          <text class="offline__stat-num">{{ items.length }}</text>
          <text class="offline__stat-label">待提交</text>
        </view>
        <view class="offline__stat">
          <text class="offline__stat-num offline__stat-num--warn">{{ conflictCount }}</text>
          <text class="offline__stat-label">冲突</text>
        </view>
        <view class="offline__stat">
          <text class="offline__stat-num offline__stat-num--danger">{{ failCount }}</text>
          <text class="offline__stat-label">失败</text>
        </view>
      </view>

      <ErpEmpty v-if="items.length === 0" text="暂无离线任务" hint="断网时的操作会自动存入这里" />
      <view v-for="op in items" :key="op.id" class="offline__item">
        <view class="offline__item-top">
          <ErpStatusTag :text="typeName(op.type)" :tone="typeTone(op.type)" />
          <text class="offline__item-title">{{ op.title }}</text>
          <text class="offline__item-del" @click="removeOp(op)">×</text>
        </view>
        <view class="offline__item-meta">
          <text>{{ op.createdAt }} · 已重试 {{ op.retries }} 次</text>
        </view>
        <view v-if="op.lastError" class="offline__item-error" :class="{ 'offline__item-error--conflict': op.conflict }">
          {{ op.conflict ? '冲突' : '失败' }}：{{ op.lastError }}
        </view>
      </view>
    </ErpCard>

    <view class="offline__actions">
      <button class="erp-btn" :disabled="syncing || items.length === 0" @click="syncNow">
        {{ syncing ? '同步中...' : '立即同步' }}
      </button>
      <button class="erp-btn erp-btn--plain" :disabled="items.length === 0" @click="clearAll">清空队列</button>
    </view>
    <view class="offline__tip">提示：网络恢复后点击「立即同步」，数据将按与在线提交相同的逻辑真实入账。</view>
  </view>
</template>

<script setup lang="ts">
import { computed, ref } from 'vue';
import { onShow } from '@dcloudio/uni-app';
import ErpCard from '../../components/ErpCard.vue';
import ErpEmpty from '../../components/ErpEmpty.vue';
import ErpStatusTag from '../../components/ErpStatusTag.vue';
import { appState } from '../../store';
import { confirmAction, showError, showToast } from '../../utils';
import { clear, isOnline, list, remove, sync, type OfflineOp, type OfflineOpType } from '../../utils/offlineQueue';

/** 待提交操作列表 */
const items = ref<OfflineOp[]>([]);
/** 同步中标记 */
const syncing = ref(false);

/** 冲突条数 */
const conflictCount = computed(() => items.value.filter((op) => op.conflict).length);
/** 失败条数（不含冲突） */
const failCount = computed(() => items.value.filter((op) => !!op.lastError && !op.conflict).length);

/**
 * 刷新列表
 * @returns 无返回值
 */
function reload(): void {
  items.value = list();
}

/**
 * 业务类型展示文案
 * @param type 业务类型
 * @returns 中文文案
 */
function typeName(type: OfflineOpType): string {
  if (type === 'stocktake') return '盘点';
  if (type === 'picking') return '拣货';
  return '开单';
}

/**
 * 业务类型标签色调
 * @param type 业务类型
 * @returns 色调枚举
 */
function typeTone(type: OfflineOpType): 'info' | 'success' | 'warning' {
  if (type === 'stocktake') return 'success';
  if (type === 'picking') return 'warning';
  return 'info';
}

/**
 * 手动同步：先判断网络，再逐条回放并汇总结果
 * @returns 无返回值
 */
async function syncNow(): Promise<void> {
  if (syncing.value || items.value.length === 0) return;
  if (!(await isOnline())) {
    showToast('当前无网络，请连网后再同步');
    return;
  }
  syncing.value = true;
  try {
    const result = await sync();
    reload();
    if (result.conflicts > 0) {
      const conflicts = items.value.filter((op) => op.conflict).map((op) => `· ${op.title}：${op.lastError || '单据已处理'}`);
      uni.showModal({
        title: '同步完成（存在冲突）',
        content: `成功 ${result.success} 条，失败 ${result.failed} 条，冲突 ${result.conflicts} 条。\n\n冲突明细需人工确认：\n${conflicts.join('\n')}`,
        showCancel: false,
        confirmColor: '#4d6bfe'
      });
    } else if (result.failed > 0) {
      showToast(`成功 ${result.success} 条，失败 ${result.failed} 条，将自动重试`);
    } else {
      showToast(`同步成功 ${result.success} 条`, 'success');
    }
  } catch (err) {
    showError(err);
  } finally {
    syncing.value = false;
  }
}

/**
 * 删除单条操作
 * @param op 目标操作
 * @returns 无返回值
 */
async function removeOp(op: OfflineOp): Promise<void> {
  const ok = await confirmAction(`确定删除「${op.title}」吗？`, '删除离线任务');
  if (!ok) return;
  remove(op.id);
  reload();
  showToast('已删除');
}

/**
 * 清空队列
 * @returns 无返回值
 */
async function clearAll(): Promise<void> {
  const ok = await confirmAction(`确定清空全部 ${items.value.length} 条离线任务吗？`, '清空队列');
  if (!ok) return;
  clear();
  reload();
  showToast('队列已清空', 'success');
}

onShow(() => {
  reload();
});
</script>

<style scoped>
.offline__refresh {
  font-size: 12px;
  color: #4d6bfe;
}
.offline__summary {
  display: flex;
  padding: 6px 0 14px;
  margin-bottom: 8px;
  border-bottom: 1px solid var(--erp-divider, #eef0f2);
}
.offline__stat {
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
}
.offline__stat-num {
  font-size: 22px;
  font-weight: 650;
  color: #4d6bfe;
}
.offline__stat-num--warn {
  color: #d97706;
}
.offline__stat-num--danger {
  color: #dc2626;
}
.offline__stat-label {
  margin-top: 2px;
  font-size: 12px;
  color: var(--erp-text-3, #8a9099);
}
.offline__item {
  padding: 10px 0;
  border-bottom: 1px solid var(--erp-divider, #eef0f2);
}
.offline__item:last-child {
  border-bottom: none;
}
.offline__item-top {
  display: flex;
  align-items: center;
}
.offline__item-title {
  flex: 1;
  margin-left: 8px;
  font-size: 13px;
  color: var(--erp-text, #1a1d21);
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.offline__item-del {
  margin-left: 8px;
  font-size: 18px;
  color: var(--erp-text-3, #8a9099);
  line-height: 1;
}
.offline__item-meta {
  margin-top: 6px;
  font-size: 12px;
  color: var(--erp-text-3, #8a9099);
}
.offline__item-error {
  margin-top: 6px;
  padding: 6px 8px;
  border-radius: 6px;
  font-size: 12px;
  line-height: 1.5;
  color: #dc2626;
  background: rgba(220, 38, 38, 0.08);
}
.offline__item-error--conflict {
  color: #d97706;
  background: rgba(217, 119, 6, 0.08);
}
.offline__actions {
  display: flex;
  gap: 12px;
}
.offline__actions button {
  flex: 1;
}
.offline__tip {
  margin-top: 14px;
  font-size: 12px;
  line-height: 1.6;
  color: var(--erp-text-3, #8a9099);
  text-align: center;
}
</style>
