<!--
 * picking.vue PDA 拣货
 * 职责：选择波次 → 按库位/商品列出拣货任务 → 扫码或输入条码核对 → 逐个拣货（数量可改）→ 缺货标记 → 全部完成提交。
 * 说明：三步流程条明确进度；提交时无网络则入离线队列，有网络则直接调用接口，mock 会真实扣减库存并更新波次状态。
-->
<template>
  <view class="erp-page picking" :class="{ 'theme-dark': appState.theme === 'dark' }">
    <!-- 步骤条 -->
    <view class="picking__steps">
      <view v-for="(s, index) in steps" :key="s" class="picking__step" :class="{ 'picking__step--active': step >= index + 1 }">
        <view class="picking__step-dot">{{ index + 1 }}</view>
        <text class="picking__step-label">{{ s }}</text>
      </view>
    </view>

    <ErpLoading v-if="loading" text="正在加载拣货波次..." />

    <!-- 第 1 步：选择波次 -->
    <template v-else-if="step === 1">
      <view class="picking__hint">请选择一张拣货波次开始作业</view>
      <ErpEmpty v-if="waves.length === 0" text="暂无拣货波次" hint="请在 PC 管理端下发拣货波次" />
      <ErpCard v-for="wave in waves" :key="wave.id" tight>
        <view class="picking__wave" @click="selectWave(wave)">
          <view class="picking__wave-top">
            <text class="picking__wave-name">{{ wave.name }}</text>
            <ErpStatusTag
              :text="wave.status === 'done' ? '已完成' : wave.status === 'picking' ? '拣货中' : '待拣货'"
              :tone="wave.status === 'done' ? 'success' : wave.status === 'picking' ? 'warning' : 'info'"
            />
          </view>
          <view class="picking__wave-meta">
            <text>{{ wave.id }} · {{ wave.warehouse }}</text>
            <text>{{ wave.pickedCount }}/{{ wave.lineCount }} 已拣</text>
          </view>
          <view class="picking__wave-time">下发时间：{{ wave.createdAt }}</view>
        </view>
      </ErpCard>
    </template>

    <!-- 第 2 步：核对与拣货 -->
    <template v-else-if="step === 2">
      <!-- 扫码 / 输入条码核对 -->
      <ErpCard title="扫码核对" accent="#4d6bfe">
        <view class="picking__verify-row">
          <input
            class="picking__verify-input"
            v-model="barcodeInput"
            placeholder="输入或扫描商品条码"
            placeholder-class="picking__ph"
            @confirm="verifyBarcode"
          />
          <button class="erp-btn picking__verify-btn" @click="verifyBarcode">核对</button>
          <button class="erp-btn erp-btn--plain picking__scan-btn" @click="scanBarcode">扫码</button>
        </view>
        <view v-if="activeLine" class="picking__active">
          当前待拣：<text class="picking__active-loc">{{ activeLine.location }}</text>
          {{ activeLine.productName }} · 应拣 {{ activeLine.planQty }}
        </view>
        <view v-else class="picking__verify-tip">核对成功会定位到对应任务，再确认实拣数量</view>
      </ErpCard>

      <!-- 波次进度 -->
      <ErpCard :title="selectedWave.name" accent="#16a34a">
        <template #extra>
          <text class="picking__back" @click="step = 1">切换波次</text>
        </template>
        <view class="picking__progress">
          <text>{{ selectedWave.id }} · {{ selectedWave.warehouse }}</text>
          <text>已处理 {{ handledCount }}/{{ lines.length }} 项</text>
        </view>
        <view class="picking__bar">
          <view class="picking__bar-fill" :style="{ width: progressPercent + '%' }"></view>
        </view>
      </ErpCard>

      <!-- 按库位分组的拣货任务 -->
      <ErpCard title="拣货任务（按库位）" accent="#d97706">
        <ErpEmpty v-if="lines.length === 0" text="该波次暂无拣货明细" size="sm" />
        <view v-for="group in locationGroups" :key="group.location" class="picking__group">
          <view class="picking__group-title">库位 {{ group.location }}</view>
          <view
            v-for="line in group.items"
            :key="line.id"
            class="picking__line"
            :class="{ 'picking__line--done': line.done, 'picking__line--short': line.short, 'picking__line--active': activeLineId === line.id && !line.done }"
          >
            <view class="picking__line-head">
              <text class="picking__line-name">{{ line.productName }}</text>
              <ErpStatusTag :text="lineStatus(line)" :tone="lineTone(line)" />
            </view>
            <view class="picking__line-meta">
              <text>条码 {{ line.barcode }}</text>
              <text>应拣 {{ line.planQty }}</text>
            </view>
            <view class="picking__line-op">
              <view class="picking__qty-wrap">
                <text class="picking__qty-label">实拣</text>
                <input class="picking__qty" type="number" v-model="line.pickedQty" :disabled="line.short" placeholder="0" placeholder-class="picking__ph" />
              </view>
              <button class="erp-btn picking__line-btn" :disabled="line.done || line.short" @click="confirmPick(line)">确认拣货</button>
              <button class="erp-btn erp-btn--plain picking__line-btn" :disabled="line.done" @click="markShort(line)">缺货</button>
            </view>
          </view>
        </view>
      </ErpCard>

      <view class="picking__actions">
        <button class="erp-btn erp-btn--plain" @click="step = 1">上一步</button>
        <button class="erp-btn" :disabled="submitting || !allHandled" @click="submitPicking">
          {{ allHandled ? '全部完成，提交' : '请处理全部任务' }}
        </button>
      </view>
    </template>

    <!-- 第 3 步：完成 -->
    <template v-else>
      <ErpCard title="拣货完成" accent="#16a34a">
        <view class="picking__result">
          <view class="picking__result-icon">✓</view>
          <text class="picking__result-title">波次已提交</text>
          <text class="picking__result-desc">
            {{ selectedWave.id }} 共 {{ lines.length }} 项任务，实拣 {{ result.pickedCount }} 项，缺货 {{ result.shortCount }} 项。
            {{ result.queued ? '当前无网络，已存入离线队列，联网同步后生效。' : '库存已真实扣减，波次状态已更新。' }}
          </text>
        </view>
        <button class="erp-btn picking__again" @click="backToList">返回波次列表</button>
      </ErpCard>
    </template>
  </view>
</template>

<script setup lang="ts">
import { computed, ref } from 'vue';
import { onShow } from '@dcloudio/uni-app';
import ErpCard from '../../components/ErpCard.vue';
import ErpEmpty from '../../components/ErpEmpty.vue';
import ErpLoading from '../../components/ErpLoading.vue';
import ErpStatusTag from '../../components/ErpStatusTag.vue';
import { mobileApi } from '../../api';
import { appState } from '../../store';
import { showError, showToast } from '../../utils';
import { enqueue, isOnline } from '../../utils/offlineQueue';

/** 步骤文案 */
const steps = ['选择波次', '核对拣货', '完成提交'];
/** 当前步骤：1 选波次 / 2 核对拣货 / 3 完成 */
const step = ref(1);
/** 波次列表 */
const waves = ref<any[]>([]);
/** 当前选中的波次 */
const selectedWave = ref<any>({ id: '', name: '', warehouse: '' });
/** 拣货明细行（页面模型：pickedQty 可改、short 缺货、done 是否处理） */
const lines = ref<any[]>([]);
/** 条码输入 */
const barcodeInput = ref('');
/** 当前核对定位的明细行 id */
const activeLineId = ref<number | null>(null);
/** 加载态 */
const loading = ref(true);
/** 提交中标记 */
const submitting = ref(false);
/** 提交结果 */
const result = ref<any>({ pickedCount: 0, shortCount: 0, queued: false });

/** 已处理行数 */
const handledCount = computed(() => lines.value.filter((line) => line.done).length);
/** 是否全部处理完成 */
const allHandled = computed(() => lines.value.length > 0 && handledCount.value === lines.value.length);
/** 进度百分比 */
const progressPercent = computed(() => (lines.value.length ? Math.round((handledCount.value / lines.value.length) * 100) : 0));
/** 当前核对定位的明细行对象 */
const activeLine = computed(() => lines.value.find((line) => line.id === activeLineId.value) || null);

/** 按库位分组的明细，便于「按库位/商品列出拣货任务」 */
const locationGroups = computed(() => {
  const map = new Map<string, any[]>();
  lines.value.forEach((line) => {
    if (!map.has(line.location)) map.set(line.location, []);
    map.get(line.location)!.push(line);
  });
  return Array.from(map.entries()).map(([location, items]) => ({ location, items }));
});

/**
 * 加载拣货波次列表
 * @returns 无返回值
 */
async function loadWaves(): Promise<void> {
  loading.value = true;
  try {
    const data = await mobileApi.pickingWaves();
    waves.value = data.list || [];
  } catch (err) {
    showError(err);
  } finally {
    loading.value = false;
  }
}

/**
 * 选择波次并加载明细，默认实拣数填入应拣数、按库位排序
 * @param wave 波次
 * @returns 无返回值
 */
async function selectWave(wave: any): Promise<void> {
  if (wave.status === 'done') {
    showToast('该波次已完成');
    return;
  }
  loading.value = true;
  try {
    const detail = await mobileApi.pickingDetail(wave.id);
    selectedWave.value = { id: detail.id, name: detail.name, warehouse: detail.warehouse };
    lines.value = (detail.lines || [])
      .map((line: any) => ({
        ...line,
        pickedQty: line.planQty,
        short: false,
        done: false
      }))
      .sort((a: any, b: any) => a.location.localeCompare(b.location));
    barcodeInput.value = '';
    activeLineId.value = null;
    step.value = 2;
  } catch (err) {
    showError(err);
  } finally {
    loading.value = false;
  }
}

/**
 * 核对条码：命中第一个未处理的匹配行则定位并提示
 * @returns 无返回值
 */
function verifyBarcode(): void {
  const code = barcodeInput.value.trim();
  if (!code) {
    showToast('请输入或扫描条码');
    return;
  }
  const hit = lines.value.find(
    (line) => !line.done && (line.barcode === code || line.productName.indexOf(code) >= 0)
  );
  if (!hit) {
    activeLineId.value = null;
    showToast('条码不匹配或无待拣任务');
    return;
  }
  activeLineId.value = hit.id;
  showToast(`核对成功：${hit.location} ${hit.productName}`, 'success');
}

/**
 * 扫码核对：H5 下提示改为手动输入条码，其余端调用 uni.scanCode
 * @returns 无返回值
 */
function scanBarcode(): void {
  // #ifdef H5
  showToast('H5 环境请使用上方输入框录入条码');
  return;
  // #endif
  // #ifndef H5
  uni.scanCode({
    onlyFromCamera: false,
    success: (res: any) => {
      barcodeInput.value = res.result || '';
      verifyBarcode();
    },
    fail: () => showToast('扫码已取消')
  });
  // #endif
}

/**
 * 确认拣货：校验数量后标记该行已处理，并清除核对定位
 * @param line 明细行
 * @returns 无返回值
 */
function confirmPick(line: any): void {
  if (line.done || line.short) return;
  const qty = Number(line.pickedQty);
  if (!qty || qty <= 0) {
    showToast('请输入正确的实拣数量');
    return;
  }
  line.pickedQty = qty;
  line.done = true;
  if (activeLineId.value === line.id) {
    activeLineId.value = null;
    barcodeInput.value = '';
  }
  showToast('已确认拣货', 'success');
}

/**
 * 缺货标记：数量归零并标记该行已处理
 * @param line 明细行
 * @returns 无返回值
 */
function markShort(line: any): void {
  if (line.done) return;
  line.short = true;
  line.pickedQty = 0;
  line.done = true;
  if (activeLineId.value === line.id) {
    activeLineId.value = null;
    barcodeInput.value = '';
  }
  showToast('已标记缺货');
}

/**
 * 明细行状态文案
 * @param line 明细行
 * @returns 状态文案
 */
function lineStatus(line: any): string {
  if (!line.done) return '待拣';
  return line.short ? '缺货' : '已拣';
}

/**
 * 明细行状态色调
 * @param line 明细行
 * @returns 色调枚举
 */
function lineTone(line: any): 'info' | 'success' | 'danger' {
  if (!line.done) return 'info';
  return line.short ? 'danger' : 'success';
}

/**
 * 提交拣货：全部处理完成后，无网入队、有网直接提交
 * @returns 无返回值
 */
async function submitPicking(): Promise<void> {
  if (submitting.value || !allHandled.value) return;
  const payload = {
    id: selectedWave.value.id,
    lines: lines.value.map((line) => ({
      id: line.id,
      pickedQty: Number(line.pickedQty) || 0,
      short: !!line.short
    }))
  };
  submitting.value = true;
  try {
    if (!(await isOnline())) {
      enqueue({ type: 'picking', title: `拣货 ${selectedWave.value.id}`, payload });
      result.value = {
        pickedCount: payload.lines.filter((l) => !l.short).length,
        shortCount: payload.lines.filter((l) => l.short).length,
        queued: true
      };
      showToast('当前无网络，已加入离线队列');
      step.value = 3;
      return;
    }
    result.value = await mobileApi.pickingSubmit(payload.id, payload.lines);
    result.value.queued = false;
    showToast('拣货提交成功', 'success');
    step.value = 3;
  } catch (err) {
    showError(err);
  } finally {
    submitting.value = false;
  }
}

/**
 * 返回波次列表并刷新状态
 * @returns 无返回值
 */
function backToList(): void {
  step.value = 1;
  loadWaves();
}

onShow(() => {
  if (step.value === 1) loadWaves();
});
</script>

<style scoped>
.picking__steps {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 16px;
  padding: 0 6px;
}
.picking__step {
  display: flex;
  align-items: center;
  flex: 1;
}
.picking__step-dot {
  width: 24px;
  height: 24px;
  border-radius: 50%;
  background: var(--erp-card, #ffffff);
  border: 1px solid var(--erp-border, #e8eaed);
  color: var(--erp-text-3, #8a9099);
  font-size: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
  flex: none;
}
.picking__step--active .picking__step-dot {
  background: #4d6bfe;
  border-color: #4d6bfe;
  color: #ffffff;
}
.picking__step-label {
  margin-left: 6px;
  font-size: 12px;
  color: var(--erp-text-3, #8a9099);
}
.picking__step--active .picking__step-label {
  color: #4d6bfe;
}
.picking__hint {
  font-size: 12px;
  color: var(--erp-text-3, #8a9099);
  margin: 0 2px 10px;
}
.picking__wave-top {
  display: flex;
  align-items: center;
  justify-content: space-between;
}
.picking__wave-name {
  flex: 1;
  font-size: 14px;
  font-weight: 600;
  color: var(--erp-text, #1a1d21);
  margin-right: 8px;
}
.picking__wave-meta {
  display: flex;
  justify-content: space-between;
  margin-top: 8px;
  font-size: 12px;
  color: var(--erp-text-2, #4e5561);
}
.picking__wave-time {
  margin-top: 4px;
  font-size: 12px;
  color: var(--erp-text-3, #8a9099);
}
.picking__verify-row {
  display: flex;
  gap: 8px;
}
.picking__verify-input {
  flex: 1;
  height: 38px;
  padding: 0 10px;
  box-sizing: border-box;
  border: 1px solid var(--erp-border, #e8eaed);
  border-radius: 10px;
  font-size: 13px;
  color: var(--erp-text, #1a1d21);
  background: var(--erp-card, #ffffff);
}
.picking__verify-btn {
  width: 64px;
  height: 38px;
  font-size: 13px;
}
.picking__scan-btn {
  width: 64px;
  height: 38px;
  font-size: 13px;
}
.picking__ph {
  color: var(--erp-text-3, #8a9099);
  font-size: 12px;
}
.picking__verify-tip {
  margin-top: 8px;
  font-size: 12px;
  color: var(--erp-text-3, #8a9099);
}
.picking__active {
  margin-top: 8px;
  padding: 8px 10px;
  border-radius: 8px;
  font-size: 12px;
  color: var(--erp-text-2, #4e5561);
  background: var(--erp-brand-soft, rgba(77, 107, 254, 0.1));
}
.picking__active-loc {
  color: #4d6bfe;
  font-weight: 600;
}
.picking__back {
  font-size: 12px;
  color: #4d6bfe;
}
.picking__progress {
  display: flex;
  justify-content: space-between;
  font-size: 12px;
  color: var(--erp-text-2, #4e5561);
}
.picking__bar {
  height: 6px;
  margin-top: 8px;
  border-radius: 999px;
  background: var(--erp-divider, #eef0f2);
  overflow: hidden;
}
.picking__bar-fill {
  height: 100%;
  border-radius: 999px;
  background: #4d6bfe;
  transition: width 0.2s;
}
.picking__group-title {
  font-size: 12px;
  font-weight: 600;
  color: #4d6bfe;
  padding: 6px 0;
}
.picking__line {
  padding: 10px;
  margin-bottom: 8px;
  border: 1px solid var(--erp-border, #e8eaed);
  border-radius: 10px;
  background: var(--erp-card, #ffffff);
}
.picking__line--active {
  border-color: #4d6bfe;
  box-shadow: 0 0 0 2px rgba(77, 107, 254, 0.12);
}
.picking__line--done {
  opacity: 0.75;
}
.picking__line--short {
  background: rgba(220, 38, 38, 0.04);
}
.picking__line-head {
  display: flex;
  align-items: center;
  justify-content: space-between;
}
.picking__line-name {
  flex: 1;
  font-size: 13px;
  font-weight: 500;
  color: var(--erp-text, #1a1d21);
  margin-right: 8px;
}
.picking__line-meta {
  display: flex;
  justify-content: space-between;
  margin: 6px 0 10px;
  font-size: 12px;
  color: var(--erp-text-3, #8a9099);
}
.picking__line-op {
  display: flex;
  align-items: center;
  gap: 8px;
}
.picking__qty-wrap {
  display: flex;
  align-items: center;
  gap: 6px;
}
.picking__qty-label {
  font-size: 12px;
  color: var(--erp-text-3, #8a9099);
}
.picking__qty {
  width: 64px;
  height: 34px;
  padding: 0 8px;
  text-align: center;
  box-sizing: border-box;
  border: 1px solid var(--erp-border, #e8eaed);
  border-radius: 8px;
  font-size: 14px;
  color: var(--erp-text, #1a1d21);
  background: var(--erp-card, #ffffff);
}
.picking__line-btn {
  flex: 1;
  height: 34px;
  font-size: 12px;
}
.picking__actions {
  display: flex;
  gap: 12px;
}
.picking__actions button {
  flex: 1;
}
.picking__result {
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 16px 0;
}
.picking__result-icon {
  width: 54px;
  height: 54px;
  border-radius: 50%;
  background: rgba(22, 163, 74, 0.12);
  color: #16a34a;
  font-size: 28px;
  display: flex;
  align-items: center;
  justify-content: center;
}
.picking__result-title {
  margin-top: 12px;
  font-size: 16px;
  font-weight: 600;
  color: var(--erp-text, #1a1d21);
}
.picking__result-desc {
  margin-top: 8px;
  font-size: 13px;
  color: var(--erp-text-2, #4e5561);
  text-align: center;
  line-height: 1.6;
}
.picking__again {
  margin-top: 12px;
}
</style>
