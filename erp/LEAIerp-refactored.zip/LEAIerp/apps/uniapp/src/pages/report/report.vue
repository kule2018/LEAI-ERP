<!--
 * report.vue 经营报表
 * 职责：展示核心经营指标与近 7 日销售趋势，提供“AI 解读”一键获取文字分析。
 * 说明：趋势图使用纯文本条形图（view 宽度百分比）实现，避免引入 ECharts 等重型依赖。
-->
<template>
  <view class="erp-page report" :class="{ 'theme-dark': appState.theme === 'dark' }">
    <ErpLoading v-if="loading" text="正在加载经营报表..." />

    <template v-else>
      <!-- 指标卡 -->
      <view class="report__metrics">
        <ErpStat
          v-for="metric in metrics"
          :key="metric.label"
          :label="metric.label"
          :value="metric.value"
          :hint="metric.trend"
          :color="metric.color"
        />
      </view>

      <!-- 销售趋势：文本条形图 -->
      <ErpCard title="近 7 日销售趋势" accent="#4d6bfe">
        <template #extra>
          <text class="erp-muted">单位：千元</text>
        </template>
        <view v-for="row in trend" :key="row.label" class="report__bar-row">
          <text class="report__bar-label">{{ row.label }}</text>
          <view class="report__bar-track">
            <view class="report__bar-fill" :style="{ width: barWidth(row.value) + '%' }"></view>
          </view>
          <text class="report__bar-value">{{ row.value }}</text>
        </view>
      </ErpCard>

      <!-- AI 解读 -->
      <ErpCard title="AI 经营解读" accent="#16a34a">
        <template #extra>
          <button class="report__ai-btn" :disabled="aiLoading" @click="askAi">
            {{ aiLoading ? '解读中...' : 'AI 解读' }}
          </button>
        </template>
        <ErpEmpty v-if="!insight" text="点击右上角「AI 解读」获取分析" size="sm" />
        <view v-else class="report__insight">
          <text class="report__insight-text">{{ insight }}</text>
        </view>
      </ErpCard>
    </template>
  </view>
</template>

<script setup lang="ts">
import { computed, ref } from 'vue';
import { onShow } from '@dcloudio/uni-app';
import ErpCard from '../../components/ErpCard.vue';
import ErpEmpty from '../../components/ErpEmpty.vue';
import ErpLoading from '../../components/ErpLoading.vue';
import ErpStat from '../../components/ErpStat.vue';
import { aiApi, mobileApi } from '../../api';
import { appState } from '../../store';
import { showError } from '../../utils';

/** 指标卡数据 */
const metrics = ref<any[]>([]);
/** 趋势数据 */
const trend = ref<any[]>([]);
/** AI 解读文本 */
const insight = ref('');
/** 报表加载态 */
const loading = ref(true);
/** AI 解读中标记 */
const aiLoading = ref(false);

/** 趋势最大值，用于计算条形宽度 */
const maxValue = computed(() => {
  if (trend.value.length === 0) return 1;
  return Math.max.apply(null, trend.value.map((row) => Number(row.value)));
});

/**
 * 计算条形图宽度百分比
 * @param value 当日数值
 * @returns 百分比（至少 6%，保证极小值可见）
 */
function barWidth(value: number): number {
  return Math.max(6, Math.round((Number(value) / maxValue.value) * 100));
}

/**
 * 加载报表数据
 * @returns 无返回值
 */
async function loadReport(): Promise<void> {
  loading.value = true;
  try {
    const data = await mobileApi.report();
    metrics.value = data.metrics || [];
    trend.value = data.trend || [];
    insight.value = data.insight || '';
  } catch (err) {
    showError(err);
  } finally {
    loading.value = false;
  }
}

/**
 * 调用 AI 助理获取经营解读
 * @returns 无返回值
 */
async function askAi(): Promise<void> {
  if (aiLoading.value) return;
  aiLoading.value = true;
  try {
    const result = await aiApi.chat('请解读本周经营报表并给出建议');
    insight.value = result.reply || '暂时无法生成解读';
  } catch (err) {
    showError(err);
  } finally {
    aiLoading.value = false;
  }
}

onShow(() => {
  loadReport();
});
</script>

<style scoped>
.report__metrics {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 10px;
  margin-bottom: 12px;
}
.report__bar-row {
  display: flex;
  align-items: center;
  margin-bottom: 10px;
}
.report__bar-label {
  width: 40px;
  font-size: 12px;
  color: var(--erp-text-3, #8a9099);
}
.report__bar-track {
  flex: 1;
  height: 12px;
  border-radius: 6px;
  background: var(--erp-bg, #f5f6f8);
  overflow: hidden;
}
.report__bar-fill {
  height: 100%;
  border-radius: 6px;
  background: linear-gradient(90deg, #4d6bfe, #7c98ff);
}
.report__bar-value {
  width: 40px;
  text-align: right;
  font-size: 12px;
  color: var(--erp-text-2, #4e5561);
}
.report__ai-btn {
  height: 28px;
  padding: 0 12px;
  border-radius: 999px;
  background: rgba(77, 107, 254, 0.1);
  color: #4d6bfe;
  font-size: 12px;
  line-height: 28px;
  border: none;
}
.report__ai-btn::after {
  border: none;
}
.report__insight {
  padding: 10px;
  border-radius: 8px;
  background: var(--erp-bg, #f5f6f8);
}
.report__insight-text {
  font-size: 13px;
  line-height: 1.7;
  color: var(--erp-text-2, #4e5561);
  white-space: pre-wrap;
}
</style>
