<!--
 * sales.vue 销售开单（简易）
 * 职责：选客户 → 扫码或选择商品 → 录入数量 → 计算合计 → 保存草稿 / 提交订单，并展示开单列表。
 * 说明：H5 下扫码降级为 picker 选商品；提交流程为“先存草稿再提交”，与后端状态流转一致。
-->
<template>
  <view class="erp-page sales" :class="{ 'theme-dark': appState.theme === 'dark' }">
    <ErpLoading v-if="loading" text="正在加载开单基础数据..." />

    <template v-else>
      <!-- 开单信息 -->
      <ErpCard title="开单信息" accent="#4d6bfe">
        <picker mode="selector" :range="customers" :value="customerIndex" @change="onCustomerChange">
          <view class="sales__picker">
            <text class="sales__label">客户</text>
            <text class="sales__picker-value">{{ customers[customerIndex] || '请选择客户' }}</text>
            <text class="sales__arrow">></text>
          </view>
        </picker>

        <view class="sales__product-head">
          <text class="sales__label">商品</text>
          <text class="sales__scan" @click="scanProduct">扫码添加</text>
        </view>
        <picker mode="selector" :range="productNames" :value="productIndex" @change="onProductChange">
          <view class="sales__picker">
            <text class="sales__picker-value">{{ productNames[productIndex] || '请选择商品' }}</text>
            <text class="sales__arrow">></text>
          </view>
        </picker>

        <view class="sales__add-row">
          <view class="sales__qty-wrap">
            <text class="sales__label">数量</text>
            <input class="sales__qty" type="number" v-model="qty" placeholder="1" placeholder-class="sales__ph" />
          </view>
          <button class="erp-btn sales__add-btn" @click="addItem">加入订单</button>
        </view>
      </ErpCard>

      <!-- 订单明细 -->
      <ErpCard title="订单明细" accent="#16a34a">
        <ErpEmpty v-if="items.length === 0" text="还没有添加商品" hint="选择商品并点击加入订单" size="sm" />
        <view v-else>
          <view v-for="(item, index) in items" :key="item.productId" class="sales__item">
            <view class="sales__item-info">
              <text class="sales__item-name">{{ item.name }}</text>
              <text class="sales__item-sub">¥{{ formatMoney(item.price) }} x {{ item.qty }}</text>
            </view>
            <text class="sales__item-amount">¥{{ formatMoney(item.price * item.qty) }}</text>
            <text class="sales__item-del" @click="removeItem(index)">×</text>
          </view>
          <view class="sales__total">
            <text>合计 {{ totalQty }} 件</text>
            <text class="sales__total-amount">¥{{ formatMoney(totalAmount) }}</text>
          </view>
        </view>
      </ErpCard>

      <!-- 操作按钮 -->
      <view class="sales__actions">
        <button class="erp-btn erp-btn--plain" :disabled="submitting" @click="saveDraft">保存草稿</button>
        <button class="erp-btn" :disabled="submitting" @click="submitOrder">提交订单</button>
      </view>

      <!-- 开单列表 -->
      <ErpCard title="开单记录" accent="#d97706">
        <template #extra>
          <text class="sales__refresh" @click="reloadOrders">刷新</text>
        </template>
        <ErpEmpty v-if="orders.length === 0" text="暂无开单记录" />
        <view v-for="order in orders" :key="order.id" class="sales__order">
          <view class="sales__order-top">
            <text class="sales__order-id">{{ order.id }}</text>
            <ErpStatusTag :text="order.status" :tone="orderStatusTone(order.status)" />
          </view>
          <view class="sales__order-meta">
            <text>{{ order.customer }} · {{ order.quantity }} 件</text>
            <text>¥{{ formatMoney(order.amount) }}</text>
          </view>
          <view class="sales__order-time">{{ order.time }}</view>
        </view>
      </ErpCard>
    </template>
  </view>
</template>

<script setup lang="ts">
import { computed, ref } from 'vue';
import { onLoad } from '@dcloudio/uni-app';
import ErpCard from '../../components/ErpCard.vue';
import ErpEmpty from '../../components/ErpEmpty.vue';
import ErpLoading from '../../components/ErpLoading.vue';
import ErpStatusTag from '../../components/ErpStatusTag.vue';
import { mobileApi } from '../../api';
import { appState } from '../../store';
import { formatMoney, showError, showToast } from '../../utils';
import { enqueue, isOnline } from '../../utils/offlineQueue';

/** 是否为 H5 环境 */
let isH5 = false;
// #ifdef H5
isH5 = true;
// #endif

/** 客户列表 */
const customers = ref<string[]>([]);
/** 当前客户索引 */
const customerIndex = ref(0);
/** 可选择商品列表 */
const products = ref<any[]>([]);
/** 商品名称数组，供 picker 使用 */
const productNames = computed(() => products.value.map((p) => p.name));
/** 当前商品索引 */
const productIndex = ref(0);
/** 数量输入 */
const qty = ref('1');
/** 订单明细行 */
const items = ref<Array<{ productId: number; name: string; price: number; qty: number }>>([]);
/** 开单记录 */
const orders = ref<any[]>([]);
/** 加载态 */
const loading = ref(true);
/** 提交中标记 */
const submitting = ref(false);

/** 明细总件数 */
const totalQty = computed(() => items.value.reduce((sum, item) => sum + item.qty, 0));
/** 明细总金额 */
const totalAmount = computed(() => items.value.reduce((sum, item) => sum + item.price * item.qty, 0));

/**
 * 加载客户、商品与开单记录
 * @returns 无返回值
 */
async function loadBase(): Promise<void> {
  loading.value = true;
  try {
    const [customerData, productData, orderData] = await Promise.all([
      mobileApi.salesCustomers(),
      mobileApi.salesProducts(),
      mobileApi.salesList()
    ]);
    customers.value = customerData.list || [];
    products.value = productData.list || [];
    orders.value = orderData.list || [];
  } catch (err) {
    showError(err);
  } finally {
    loading.value = false;
  }
}

/**
 * 刷新开单记录
 * @returns 无返回值
 */
async function reloadOrders(): Promise<void> {
  try {
    const data = await mobileApi.salesList();
    orders.value = data.list || [];
    showToast('已刷新', 'success');
  } catch (err) {
    showError(err);
  }
}

/**
 * 客户选择变化
 * @param event picker change 事件
 * @returns 无返回值
 */
function onCustomerChange(event: any): void {
  customerIndex.value = Number(event.detail.value || 0);
}

/**
 * 商品选择变化
 * @param event picker change 事件
 * @returns 无返回值
 */
function onProductChange(event: any): void {
  productIndex.value = Number(event.detail.value || 0);
}

/**
 * 把当前选择的商品加入订单明细，同商品合并数量
 * @returns 无返回值
 */
function addItem(): void {
  const product = products.value[productIndex.value];
  if (!product) {
    showToast('请选择商品');
    return;
  }
  const num = Number(qty.value);
  if (!num || num <= 0) {
    showToast('请输入正确的数量');
    return;
  }
  const exist = items.value.find((item) => item.productId === product.id);
  if (exist) {
    exist.qty += num;
  } else {
    items.value.push({ productId: product.id, name: product.name, price: product.price, qty: num });
  }
  qty.value = '1';
  showToast('已加入订单');
}

/**
 * 删除明细行
 * @param index 行索引
 * @returns 无返回值
 */
function removeItem(index: number): void {
  items.value.splice(index, 1);
}

/**
 * 扫码添加商品：扫码结果命中后定位商品并加入订单
 * @returns 无返回值
 */
async function scanProduct(): Promise<void> {
  if (isH5) {
    showToast('H5 环境请使用商品选择器');
    return;
  }
  uni.scanCode({
    onlyFromCamera: false,
    success: async (res: any) => {
      try {
        const result = await mobileApi.scan(res.result);
        if (!result.hit) {
          showToast('未找到该商品');
          return;
        }
        const index = products.value.findIndex((p) => p.code === result.product.code);
        if (index < 0) {
          showToast('该商品暂不可开单');
          return;
        }
        productIndex.value = index;
        qty.value = '1';
        addItem();
      } catch (err) {
        showError(err);
      }
    },
    fail: () => showToast('扫码已取消')
  });
}

/**
 * 校验订单明细
 * @returns 是否校验通过
 */
function validateItems(): boolean {
  if (!customers.value[customerIndex.value]) {
    showToast('请选择客户');
    return false;
  }
  if (items.value.length === 0) {
    showToast('请先添加商品');
    return false;
  }
  return true;
}

/**
 * 构造提交给后端的数据
 * @returns 订单数据对象
 */
function buildPayload(): any {
  return {
    customer: customers.value[customerIndex.value],
    amount: totalAmount.value,
    quantity: totalQty.value,
    items: items.value.slice()
  };
}

/**
 * 保存草稿
 * @returns 无返回值
 */
async function saveDraft(): Promise<void> {
  if (!validateItems()) return;
  submitting.value = true;
  try {
    await mobileApi.salesSave(buildPayload());
    showToast('草稿已保存', 'success');
    items.value = [];
    await reloadOrders();
  } catch (err) {
    showError(err);
  } finally {
    submitting.value = false;
  }
}

/**
 * 提交订单：先保存草稿拿到单号，再提交审核
 * @returns 无返回值
 */
async function submitOrder(): Promise<void> {
  if (!validateItems()) return;
  const payload = buildPayload();
  submitting.value = true;
  try {
    if (!(await isOnline())) {
      enqueue({
        type: 'sales',
        title: `销售单 ${payload.customer} · ¥${formatMoney(payload.amount)}`,
        payload
      });
      showToast('当前无网络，已加入离线队列');
      items.value = [];
      await reloadOrders();
      return;
    }
    const draft = await mobileApi.salesSave(payload);
    await mobileApi.salesSubmit({ id: draft.id });
    showToast('订单已提交', 'success');
    items.value = [];
    await reloadOrders();
  } catch (err) {
    showError(err);
  } finally {
    submitting.value = false;
  }
}

/**
 * 订单状态对应标签色调
 * @param status 状态文案
 * @returns 色调枚举
 */
function orderStatusTone(status: string): 'info' | 'success' | 'warning' | 'danger' {
  if (status === '已确认') return 'success';
  if (status === '草稿') return 'info';
  if (status === '待审核') return 'warning';
  return 'danger';
}

onLoad(() => {
  loadBase();
});
</script>

<style scoped>
.sales__picker {
  display: flex;
  align-items: center;
  min-height: 40px;
  padding: 0 10px;
  border: 1px solid var(--erp-border, #e8eaed);
  border-radius: 10px;
  margin-bottom: 10px;
}
.sales__label {
  font-size: 13px;
  color: var(--erp-text-3, #8a9099);
  margin-right: 12px;
}
.sales__picker-value {
  flex: 1;
  font-size: 13px;
  color: var(--erp-text, #1a1d21);
}
.sales__arrow {
  color: var(--erp-text-3, #8a9099);
}
.sales__product-head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 8px;
}
.sales__scan {
  font-size: 12px;
  color: #4d6bfe;
}
.sales__add-row {
  display: flex;
  align-items: flex-end;
  gap: 12px;
  margin-top: 4px;
}
.sales__qty-wrap {
  width: 100px;
}
.sales__qty {
  width: 100%;
  height: 38px;
  padding: 0 10px;
  box-sizing: border-box;
  border: 1px solid var(--erp-border, #e8eaed);
  border-radius: 10px;
  font-size: 14px;
  color: var(--erp-text, #1a1d21);
  background: var(--erp-card, #ffffff);
}
.sales__ph {
  color: var(--erp-text-3, #8a9099);
}
.sales__add-btn {
  flex: 1;
  height: 38px;
  font-size: 13px;
}
.sales__item {
  display: flex;
  align-items: center;
  padding: 10px 0;
  border-bottom: 1px solid var(--erp-divider, #eef0f2);
}
.sales__item-info {
  flex: 1;
}
.sales__item-name {
  display: block;
  font-size: 13px;
  color: var(--erp-text, #1a1d21);
}
.sales__item-sub {
  display: block;
  margin-top: 2px;
  font-size: 12px;
  color: var(--erp-text-3, #8a9099);
}
.sales__item-amount {
  font-size: 13px;
  font-weight: 600;
  color: var(--erp-text, #1a1d21);
  margin-right: 10px;
}
.sales__item-del {
  font-size: 20px;
  color: var(--erp-text-3, #8a9099);
  line-height: 1;
}
.sales__total {
  display: flex;
  justify-content: space-between;
  align-items: baseline;
  margin-top: 12px;
  padding-top: 10px;
  border-top: 1px solid var(--erp-divider, #eef0f2);
  font-size: 13px;
  color: var(--erp-text-2, #4e5561);
}
.sales__total-amount {
  font-size: 18px;
  font-weight: 650;
  color: #dc2626;
}
.sales__actions {
  display: flex;
  gap: 12px;
  margin-bottom: 12px;
}
.sales__actions button {
  flex: 1;
}
.sales__refresh {
  font-size: 12px;
  color: #4d6bfe;
}
.sales__order {
  padding: 10px 0;
  border-bottom: 1px solid var(--erp-divider, #eef0f2);
}
.sales__order:last-child {
  border-bottom: none;
}
.sales__order-top {
  display: flex;
  align-items: center;
  justify-content: space-between;
}
.sales__order-id {
  font-size: 13px;
  font-weight: 600;
  color: var(--erp-text, #1a1d21);
}
.sales__order-meta {
  display: flex;
  justify-content: space-between;
  margin-top: 6px;
  font-size: 12px;
  color: var(--erp-text-2, #4e5561);
}
.sales__order-time {
  margin-top: 4px;
  font-size: 12px;
  color: var(--erp-text-3, #8a9099);
}
</style>
