<!--
 * scan.vue 扫码查库存
 * 职责：调用 uni.scanCode 扫描条码/编码查询商品与可售库存；H5 自动降级为输入框。
 * 说明：连续扫描同一商品会累加数量，便于现场快速点数；结果区展示最近一次扫码的商品详情。
-->
<template>
  <view class="erp-page scan" :class="{ 'theme-dark': appState.theme === 'dark' }">
    <!-- 扫码输入区 -->
    <ErpCard title="扫描商品条码" accent="#4d6bfe">
      <view class="scan__input-row">
        <input
          class="scan__input"
          v-model="code"
          placeholder="输入或扫描条码 / 商品编码"
          placeholder-class="scan__ph"
          confirm-type="search"
          @confirm="queryByCode"
        />
        <button class="erp-btn scan__btn" @click="startScan">扫码</button>
      </view>
      <button class="erp-btn erp-btn--plain scan__query" @click="queryByCode">查询库存</button>
      <text class="scan__tip">{{ isH5 ? 'H5 环境请手动输入条码，真机可使用摄像头扫码' : '将摄像头对准商品条码即可自动识别' }}</text>
    </ErpCard>

    <!-- 最近一次扫码结果 -->
    <ErpCard v-if="lastResult" title="扫码结果" accent="#16a34a">
      <template #extra>
        <ErpStatusTag text="已命中" tone="success" />
      </template>
      <view class="scan__result-name">{{ lastResult.name }}</view>
      <view class="scan__result-grid">
        <view class="scan__result-item">
          <text class="scan__result-label">商品编码</text>
          <text class="scan__result-value">{{ lastResult.code }}</text>
        </view>
        <view class="scan__result-item">
          <text class="scan__result-label">SKU</text>
          <text class="scan__result-value">{{ lastResult.skuCode }}</text>
        </view>
        <view class="scan__result-item">
          <text class="scan__result-label">可售库存</text>
          <text class="scan__result-value scan__stock">{{ lastResult.available }} {{ lastResult.unit }}</text>
        </view>
        <view class="scan__result-item">
          <text class="scan__result-label">销售单价</text>
          <text class="scan__result-value scan__price">¥{{ formatMoney(lastResult.price) }}</text>
        </view>
      </view>
      <view class="scan__warehouse">所在仓库：{{ lastResult.warehouse }}</view>
    </ErpCard>

    <ErpEmpty v-else-if="!loading && scanned" text="未查询到该条码" hint="请确认条码后重试，可尝试输入商品编码" />

    <ErpLoading v-if="loading" inline text="正在查询库存..." />

    <!-- 连续扫码累加列表 -->
    <ErpCard v-if="scanList.length" title="本次扫码清单" accent="#d97706">
      <template #extra>
        <text class="scan__clear" @click="clearList">清空</text>
      </template>
      <view v-for="(item, index) in scanList" :key="item.code" class="scan__list-item">
        <text class="scan__list-index">{{ index + 1 }}</text>
        <view class="scan__list-info">
          <text class="scan__list-name">{{ item.name }}</text>
          <text class="scan__list-code">{{ item.code }}</text>
        </view>
        <text class="scan__list-count">x{{ item.count }}</text>
      </view>
      <view class="scan__total">
        <text>共 {{ totalCount }} 件商品</text>
        <text>预估金额 ¥{{ formatMoney(totalAmount) }}</text>
      </view>
    </ErpCard>
  </view>
</template>

<script setup lang="ts">
import { computed, ref } from 'vue';
import ErpCard from '../../components/ErpCard.vue';
import ErpEmpty from '../../components/ErpEmpty.vue';
import ErpLoading from '../../components/ErpLoading.vue';
import ErpStatusTag from '../../components/ErpStatusTag.vue';
import { mobileApi } from '../../api';
import { appState } from '../../store';
import { formatMoney, showError, showToast } from '../../utils';

/** 是否为 H5 环境（H5 下 scanCode 不可用，降级为输入框） */
let isH5 = false;
// #ifdef H5
isH5 = true;
// #endif

/** 输入框中的条码 */
const code = ref('');
/** 最近一次命中的商品 */
const lastResult = ref<any>(null);
/** 本次扫码累加清单 */
const scanList = ref<Array<{ code: string; name: string; price: number; count: number }>>([]);
/** 查询中标记 */
const loading = ref(false);
/** 是否已经发起过查询（用于区分空态） */
const scanned = ref(false);

/** 累加后的总件数 */
const totalCount = computed(() => scanList.value.reduce((sum, item) => sum + item.count, 0));
/** 累加后的预估金额 */
const totalAmount = computed(() =>
  scanList.value.reduce((sum, item) => sum + item.price * item.count, 0)
);

/**
 * 根据条码查询库存，并把结果累加进清单
 * @param scanCode 条码字符串，为空时取输入框的值
 * @returns 无返回值
 */
async function queryByCode(scanCode?: string): Promise<void> {
  const target = (scanCode || code.value || '').trim();
  if (!target) {
    showToast('请输入或扫描条码');
    return;
  }
  loading.value = true;
  scanned.value = true;
  try {
    const result = await mobileApi.scan(target);
    if (!result.hit) {
      lastResult.value = null;
      showToast('未找到该条码对应的商品');
      return;
    }
    lastResult.value = result.product;
    code.value = '';
    // 同一商品重复扫码时只累加数量，不重复插入行
    const exist = scanList.value.find((item) => item.code === result.product.code);
    if (exist) {
      exist.count += 1;
    } else {
      scanList.value.push({
        code: result.product.code,
        name: result.product.name,
        price: result.product.price,
        count: 1
      });
    }
  } catch (err) {
    showError(err);
  } finally {
    loading.value = false;
  }
}

/**
 * 调用摄像头扫码；H5 或扫码失败时提示改用输入框
 * @returns 无返回值
 */
function startScan(): void {
  if (isH5) {
    showToast('H5 环境请使用输入框');
    return;
  }
  uni.scanCode({
    onlyFromCamera: false,
    success: (res: any) => {
      queryByCode(res.result);
    },
    fail: () => {
      showToast('扫码已取消，请手动输入条码');
    }
  });
}

/**
 * 清空本次扫码清单
 * @returns 无返回值
 */
function clearList(): void {
  scanList.value = [];
  lastResult.value = null;
  scanned.value = false;
  code.value = '';
  showToast('已清空', 'success');
}
</script>

<style scoped>
.scan__input-row {
  display: flex;
  gap: 8px;
}
.scan__input {
  flex: 1;
  height: 40px;
  padding: 0 10px;
  border: 1px solid var(--erp-border, #e8eaed);
  border-radius: 10px;
  font-size: 13px;
  color: var(--erp-text, #1a1d21);
  background: var(--erp-card, #ffffff);
}
.scan__ph {
  color: var(--erp-text-3, #8a9099);
}
.scan__btn {
  width: 72px;
  height: 40px;
  font-size: 14px;
}
.scan__query {
  width: 100%;
  height: 38px;
  margin-top: 10px;
}
.scan__tip {
  display: block;
  margin-top: 10px;
  font-size: 12px;
  color: var(--erp-text-3, #8a9099);
}
.scan__result-name {
  font-size: 16px;
  font-weight: 600;
  color: var(--erp-text, #1a1d21);
  margin-bottom: 12px;
}
.scan__result-grid {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 12px 8px;
}
.scan__result-item {
  display: flex;
  flex-direction: column;
}
.scan__result-label {
  font-size: 12px;
  color: var(--erp-text-3, #8a9099);
}
.scan__result-value {
  margin-top: 4px;
  font-size: 13px;
  color: var(--erp-text, #1a1d21);
}
.scan__stock {
  color: #16a34a;
  font-weight: 600;
}
.scan__price {
  color: #dc2626;
  font-weight: 600;
}
.scan__warehouse {
  margin-top: 12px;
  padding-top: 10px;
  border-top: 1px solid var(--erp-divider, #eef0f2);
  font-size: 12px;
  color: var(--erp-text-3, #8a9099);
}
.scan__clear {
  font-size: 12px;
  color: #4d6bfe;
}
.scan__list-item {
  display: flex;
  align-items: center;
  padding: 8px 0;
  border-bottom: 1px solid var(--erp-divider, #eef0f2);
}
.scan__list-index {
  width: 22px;
  height: 22px;
  border-radius: 50%;
  background: rgba(77, 107, 254, 0.1);
  color: #4d6bfe;
  font-size: 12px;
  text-align: center;
  line-height: 22px;
  margin-right: 10px;
}
.scan__list-info {
  flex: 1;
  display: flex;
  flex-direction: column;
}
.scan__list-name {
  font-size: 13px;
  color: var(--erp-text, #1a1d21);
}
.scan__list-code {
  margin-top: 2px;
  font-size: 12px;
  color: var(--erp-text-3, #8a9099);
}
.scan__list-count {
  font-size: 13px;
  font-weight: 600;
  color: #4d6bfe;
}
.scan__total {
  display: flex;
  justify-content: space-between;
  margin-top: 12px;
  padding-top: 10px;
  border-top: 1px solid var(--erp-divider, #eef0f2);
  font-size: 13px;
  color: var(--erp-text, #1a1d21);
}
</style>
