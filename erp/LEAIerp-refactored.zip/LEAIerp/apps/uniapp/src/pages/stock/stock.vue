<!--
 * stock.vue 库存查询
 * 职责：按关键词与仓库筛选库存，支持下拉刷新与上拉分页；点击库存行可查看进销存流水。
 * 说明：仓库数据随首次查询结果返回；流水以底部弹层展示，不额外新增页面。
-->
<template>
  <view class="erp-page stock" :class="{ 'theme-dark': appState.theme === 'dark' }">
    <!-- 查询区：关键词 + 仓库 -->
    <ErpCard tight>
      <view class="stock__search-row">
        <input
          class="stock__input"
          v-model="keyword"
          placeholder="搜索商品名称 / 编码"
          placeholder-class="stock__ph"
          confirm-type="search"
          @confirm="reload"
        />
        <button class="erp-btn stock__search-btn" @click="reload">搜索</button>
      </view>
      <picker mode="selector" :range="warehouseNames" :value="warehouseIndex" @change="onWarehouseChange">
        <view class="stock__picker">
          <text class="stock__picker-label">仓库</text>
          <text class="stock__picker-value">{{ warehouseNames[warehouseIndex] || '全部仓库' }}</text>
          <text class="stock__picker-arrow">></text>
        </view>
      </picker>
    </ErpCard>

    <!-- 列表统计 -->
    <view v-if="!loading" class="stock__count">共 {{ total }} 条库存记录</view>

    <!-- 加载 / 错误 / 空态 -->
    <ErpLoading v-if="loading" text="正在加载库存..." />
    <ErpCard v-else-if="error" title="加载失败">
      <text class="erp-muted">{{ error }}</text>
      <button class="erp-btn erp-btn--plain stock__retry" @click="reload">重新加载</button>
    </ErpCard>
    <ErpEmpty v-else-if="list.length === 0" text="未找到库存记录" hint="换个关键词或仓库试试" />

    <!-- 库存列表 -->
    <view v-else>
      <ErpCard v-for="item in list" :key="item.id" tight>
        <view class="stock__item" @click="openLedger(item)">
          <view class="stock__item-top">
            <text class="stock__item-name">{{ item.name }}</text>
            <ErpStatusTag
              :text="item.available <= 5 ? '库存偏低' : '库存正常'"
              :tone="item.available <= 5 ? 'danger' : 'success'"
            />
          </view>
          <view class="stock__item-code">{{ item.code }} · {{ item.warehouse }}</view>
          <view class="stock__item-numbers">
            <view class="stock__num-item">
              <text class="stock__num-label">账面</text>
              <text class="stock__num-value">{{ item.onHand }}</text>
            </view>
            <view class="stock__num-item">
              <text class="stock__num-label">占用</text>
              <text class="stock__num-value">{{ item.occupied }}</text>
            </view>
            <view class="stock__num-item">
              <text class="stock__num-label">可售</text>
              <text class="stock__num-value stock__num-avail">{{ item.available }} {{ item.unit }}</text>
            </view>
          </view>
        </view>
      </ErpCard>

      <view class="stock__more">
        <text v-if="loadingMore">加载中...</text>
        <text v-else-if="!hasMore">— 已加载全部 —</text>
        <text v-else>上拉加载更多</text>
      </view>
    </view>

    <!-- 库存流水弹层 -->
    <view v-if="ledgerVisible" class="stock__mask" @click="ledgerVisible = false">
      <view class="stock__sheet" @click.stop>
        <view class="stock__sheet-head">
          <text class="stock__sheet-title">库存流水 · {{ ledgerProduct }}</text>
          <text class="stock__sheet-close" @click="ledgerVisible = false">×</text>
        </view>
        <ErpLoading v-if="ledgerLoading" inline text="加载流水..." />
        <ErpEmpty v-else-if="ledgerList.length === 0" text="暂无流水记录" />
        <view v-else>
          <view v-for="row in ledgerList" :key="row.id" class="stock__ledger-row">
            <view class="stock__ledger-left">
              <text class="stock__ledger-type" :style="{ color: row.qty < 0 ? '#dc2626' : '#16a34a' }">
                {{ row.type }} {{ row.qty > 0 ? '+' : '' }}{{ row.qty }}
              </text>
              <text class="stock__ledger-source">{{ row.source }}</text>
            </view>
            <view class="stock__ledger-right">
              <text class="stock__ledger-balance">余额 {{ row.balance }}</text>
              <text class="stock__ledger-time">{{ row.time }}</text>
            </view>
          </view>
        </view>
      </view>
    </view>
  </view>
</template>

<script setup lang="ts">
import { computed, ref } from 'vue';
import { onPullDownRefresh, onReachBottom } from '@dcloudio/uni-app';
import ErpCard from '../../components/ErpCard.vue';
import ErpEmpty from '../../components/ErpEmpty.vue';
import ErpLoading from '../../components/ErpLoading.vue';
import ErpStatusTag from '../../components/ErpStatusTag.vue';
import { mobileApi } from '../../api';
import { appState } from '../../store';
import { showError } from '../../utils';

/** 搜索关键词 */
const keyword = ref('');
/** 仓库列表（首屏接口返回） */
const warehouses = ref<Array<{ id: number; name: string }>>([]);
/** 当前仓库在 picker 中的索引，0 表示全部 */
const warehouseIndex = ref(0);
/** 库存列表 */
const list = ref<any[]>([]);
/** 当前页码 */
const page = ref(1);
/** 每页条数 */
const pageSize = 6;
/** 总条数 */
const total = ref(0);
/** 首屏加载态 */
const loading = ref(true);
/** 上拉加载更多态 */
const loadingMore = ref(false);
/** 错误信息 */
const error = ref('');

/** 流水弹层是否显示 */
const ledgerVisible = ref(false);
/** 流水加载态 */
const ledgerLoading = ref(false);
/** 流水数据 */
const ledgerList = ref<any[]>([]);
/** 当前查看流水的商品名 */
const ledgerProduct = ref('');

/** picker 展示用的仓库名数组，第一项为“全部仓库” */
const warehouseNames = computed(() => ['全部仓库'].concat(warehouses.value.map((w) => w.name)));
/** 是否还有下一页 */
const hasMore = computed(() => list.value.length < total.value);

/**
 * 加载库存列表
 * @param reset 是否重置为第一页
 * @returns 无返回值
 */
async function loadData(reset = true): Promise<void> {
  if (reset) {
    page.value = 1;
    loading.value = true;
  } else {
    loadingMore.value = true;
  }
  error.value = '';
  const selected = warehouseIndex.value > 0 ? warehouses.value[warehouseIndex.value - 1] : null;
  try {
    const result = await mobileApi.stock({
      keyword: keyword.value,
      warehouseId: selected ? selected.id : '',
      page: page.value,
      pageSize
    });
    warehouses.value = result.warehouses || warehouses.value;
    list.value = reset ? result.list || [] : list.value.concat(result.list || []);
    total.value = result.total || 0;
  } catch (err) {
    error.value = err instanceof Error ? err.message : '库存加载失败';
    showError(err);
  } finally {
    loading.value = false;
    loadingMore.value = false;
  }
}

/**
 * 搜索按钮：重置到第一页
 * @returns 无返回值
 */
function reload(): void {
  loadData(true);
}

/**
 * 仓库切换
 * @param event picker change 事件
 * @returns 无返回值
 */
function onWarehouseChange(event: any): void {
  warehouseIndex.value = Number(event.detail.value || 0);
  reload();
}

/**
 * 上拉加载下一页
 * @returns 无返回值
 */
async function loadMore(): Promise<void> {
  if (loading.value || loadingMore.value || !hasMore.value) return;
  page.value += 1;
  await loadData(false);
}

/**
 * 打开库存流水弹层
 * @param item 库存行
 * @returns 无返回值
 */
async function openLedger(item: any): Promise<void> {
  ledgerVisible.value = true;
  ledgerLoading.value = true;
  ledgerProduct.value = item.name;
  ledgerList.value = [];
  try {
    const result = await mobileApi.stockLedger(item.id);
    ledgerList.value = result.list || [];
  } catch (err) {
    showError(err);
  } finally {
    ledgerLoading.value = false;
  }
}

onPullDownRefresh(async () => {
  await loadData(true);
  uni.stopPullDownRefresh();
});

onReachBottom(() => {
  loadMore();
});
</script>

<style scoped>
.stock__search-row {
  display: flex;
  gap: 8px;
}
.stock__input {
  flex: 1;
  height: 38px;
  padding: 0 10px;
  border: 1px solid var(--erp-border, #e8eaed);
  border-radius: 10px;
  font-size: 13px;
  color: var(--erp-text, #1a1d21);
  background: var(--erp-card, #ffffff);
}
.stock__ph {
  color: var(--erp-text-3, #8a9099);
}
.stock__search-btn {
  width: 68px;
  height: 38px;
  font-size: 13px;
}
.stock__picker {
  display: flex;
  align-items: center;
  margin-top: 10px;
  padding-top: 10px;
  border-top: 1px solid var(--erp-divider, #eef0f2);
}
.stock__picker-label {
  font-size: 13px;
  color: var(--erp-text-3, #8a9099);
  margin-right: 12px;
}
.stock__picker-value {
  flex: 1;
  font-size: 13px;
  color: var(--erp-text, #1a1d21);
}
.stock__picker-arrow {
  color: var(--erp-text-3, #8a9099);
}
.stock__count {
  font-size: 12px;
  color: var(--erp-text-3, #8a9099);
  margin: 2px 2px 8px;
}
.stock__item-top {
  display: flex;
  align-items: center;
  justify-content: space-between;
}
.stock__item-name {
  flex: 1;
  font-size: 14px;
  font-weight: 600;
  color: var(--erp-text, #1a1d21);
  margin-right: 8px;
}
.stock__item-code {
  margin-top: 4px;
  font-size: 12px;
  color: var(--erp-text-3, #8a9099);
}
.stock__item-numbers {
  display: flex;
  margin-top: 10px;
  padding-top: 10px;
  border-top: 1px solid var(--erp-divider, #eef0f2);
}
.stock__num-item {
  flex: 1;
}
.stock__num-label {
  display: block;
  font-size: 12px;
  color: var(--erp-text-3, #8a9099);
}
.stock__num-value {
  display: block;
  margin-top: 2px;
  font-size: 14px;
  color: var(--erp-text, #1a1d21);
}
.stock__num-avail {
  color: #4d6bfe;
  font-weight: 600;
}
.stock__more {
  text-align: center;
  padding: 12px 0 20px;
  font-size: 12px;
  color: var(--erp-text-3, #8a9099);
}
.stock__retry {
  margin-top: 12px;
  height: 34px;
}
.stock__mask {
  position: fixed;
  left: 0;
  top: 0;
  right: 0;
  bottom: 0;
  background: rgba(15, 20, 28, 0.45);
  z-index: 100;
  display: flex;
  align-items: flex-end;
}
.stock__sheet {
  width: 100%;
  max-height: 70vh;
  overflow-y: auto;
  background: var(--erp-card, #ffffff);
  border-radius: 16px 16px 0 0;
  padding: 16px;
  box-sizing: border-box;
}
.stock__sheet-head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 12px;
}
.stock__sheet-title {
  font-size: 15px;
  font-weight: 600;
  color: var(--erp-text, #1a1d21);
}
.stock__sheet-close {
  font-size: 22px;
  color: var(--erp-text-3, #8a9099);
  line-height: 1;
}
.stock__ledger-row {
  display: flex;
  justify-content: space-between;
  padding: 10px 0;
  border-bottom: 1px solid var(--erp-divider, #eef0f2);
}
.stock__ledger-left,
.stock__ledger-right {
  display: flex;
  flex-direction: column;
}
.stock__ledger-right {
  align-items: flex-end;
}
.stock__ledger-type {
  font-size: 13px;
  font-weight: 600;
}
.stock__ledger-source {
  margin-top: 2px;
  font-size: 12px;
  color: var(--erp-text-3, #8a9099);
}
.stock__ledger-balance {
  font-size: 13px;
  color: var(--erp-text, #1a1d21);
}
.stock__ledger-time {
  margin-top: 2px;
  font-size: 12px;
  color: var(--erp-text-3, #8a9099);
}
</style>
