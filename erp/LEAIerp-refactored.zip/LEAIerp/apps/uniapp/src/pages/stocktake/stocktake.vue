<!--
 * stocktake.vue 移动端盘点
 * 职责：选盘点单 → 逐行录入实盘数 → 提交差异 → 完成盘点；提交后 mock 会真实回写库存。
 * 说明：用三个步骤条明确当前进度，避免用户不知道下一步该做什么。
-->
<template>
  <view class="erp-page stocktake" :class="{ 'theme-dark': appState.theme === 'dark' }">
    <!-- 步骤条 -->
    <view class="stocktake__steps">
      <view v-for="(s, index) in steps" :key="s" class="stocktake__step" :class="{ 'stocktake__step--active': step >= index + 1 }">
        <view class="stocktake__step-dot">{{ index + 1 }}</view>
        <text class="stocktake__step-label">{{ s }}</text>
      </view>
    </view>

    <ErpLoading v-if="loading" text="正在加载盘点单..." />

    <!-- 第 1 步：选择盘点单 -->
    <template v-else-if="step === 1">
      <view class="stocktake__hint">请选择一张盘点单开始录入</view>
      <ErpEmpty v-if="docs.length === 0" text="暂无盘点单" hint="请在 PC 管理端创建盘点单" />
      <ErpCard v-for="doc in docs" :key="doc.id" tight>
        <view class="stocktake__doc" @click="selectDoc(doc)">
          <view class="stocktake__doc-top">
            <text class="stocktake__doc-name">{{ doc.name }}</text>
            <ErpStatusTag :text="doc.status === 'done' ? '已完成' : '待盘点'" :tone="doc.status === 'done' ? 'success' : 'warning'" />
          </view>
          <view class="stocktake__doc-meta">
            <text>{{ doc.id }} · {{ doc.warehouse }}</text>
            <text>{{ doc.lineCount }} 个品项</text>
          </view>
          <view class="stocktake__doc-time">创建时间：{{ doc.createdAt }}</view>
        </view>
      </ErpCard>
    </template>

    <!-- 第 2 步：录入实盘数 -->
    <template v-else-if="step === 2">
      <ErpCard :title="selectedDoc.name" accent="#4d6bfe">
        <template #extra>
          <text class="stocktake__back" @click="step = 1">切换盘点单</text>
        </template>
        <view class="stocktake__doc-meta">
          <text>{{ selectedDoc.id }} · {{ selectedDoc.warehouse }}</text>
          <text>差异 {{ diffCount }} 项</text>
        </view>
      </ErpCard>

      <ErpCard title="盘点明细" accent="#16a34a">
        <view v-for="(line, index) in lines" :key="line.id" class="stocktake__line">
          <view class="stocktake__line-info">
            <text class="stocktake__line-name">{{ index + 1 }}. {{ line.productName }}</text>
            <text class="stocktake__line-book">账面数：{{ line.bookQty }}</text>
          </view>
          <view class="stocktake__line-input">
            <input
              class="stocktake__input"
              type="number"
              v-model="line.realQty"
              placeholder="实盘"
              placeholder-class="stocktake__ph"
            />
            <text class="stocktake__diff" :class="{ 'stocktake__diff--has': lineDiff(line) !== 0 }">
              {{ lineDiff(line) === 0 ? '无差异' : (lineDiff(line) > 0 ? '+' : '') + lineDiff(line) }}
            </text>
          </view>
        </view>
      </ErpCard>

      <view class="stocktake__actions">
        <button class="erp-btn erp-btn--plain" @click="step = 1">上一步</button>
        <button class="erp-btn" :disabled="submitting" @click="submitStocktake">提交并盘点</button>
      </view>
    </template>

    <!-- 第 3 步：完成 -->
    <template v-else>
      <ErpCard title="盘点完成" accent="#16a34a">
        <view class="stocktake__result">
          <view class="stocktake__result-icon">✓</view>
          <text class="stocktake__result-title">{{ result.queued ? '盘点已离线暂存' : '盘点单已提交' }}</text>
          <text class="stocktake__result-desc">{{ selectedDoc.id }} 共录入 {{ lines.length }} 个品项，发现 {{ result.diffCount }} 项差异。{{ result.queued ? '当前无网络，操作已加入离线队列，联网同步后生效。' : '库存数据已更新。' }}</text>
        </view>
        <button class="erp-btn stocktake__again" @click="backToList">返回盘点单列表</button>
      </ErpCard>
    </template>
  </view>
</template>

<script setup lang="ts">
import { computed, ref } from 'vue';
import { onShow } from '@dcloudio/uni-app';
import ErpCard from '../../components/ErpCard.vue';
import ErpEmpty from '../../components/ErpEmpty.vue';
import ErpLoading from '../../components/ErpLoading.vue';
import ErpStatusTag from '../../components/ErpStatusTag.vue';
import { mobileApi } from '../../api';
import { appState } from '../../store';
import { showError, showToast } from '../../utils';
import { enqueue, isOnline } from '../../utils/offlineQueue';

/** 步骤文案 */
const steps = ['选择盘点单', '录入实盘数', '完成盘点'];
/** 当前步骤：1 选单 / 2 录数 / 3 完成 */
const step = ref(1);
/** 盘点单列表 */
const docs = ref<any[]>([]);
/** 当前选中的盘点单 */
const selectedDoc = ref<any>({ id: '', name: '', warehouse: '' });
/** 明细行（含 realQty 输入值） */
const lines = ref<any[]>([]);
/** 提交结果 */
const result = ref<any>({ diffCount: 0, queued: false });
/** 加载态 */
const loading = ref(true);
/** 提交中标记 */
const submitting = ref(false);

/** 有差异的行数 */
const diffCount = computed(() => lines.value.filter((line) => lineDiff(line) !== 0).length);

/**
 * 计算单行差异：实盘数 - 账面数，未录入时按 0 处理
 * @param line 盘点明细行
 * @returns 差异数值
 */
function lineDiff(line: any): number {
  if (line.realQty === '' || line.realQty === null || line.realQty === undefined) return 0;
  return Number(line.realQty) - Number(line.bookQty);
}

/**
 * 加载盘点单列表
 * @returns 无返回值
 */
async function loadDocs(): Promise<void> {
  loading.value = true;
  try {
    const data = await mobileApi.stocktakeList();
    docs.value = data.list || [];
  } catch (err) {
    showError(err);
  } finally {
    loading.value = false;
  }
}

/**
 * 选择盘点单并加载明细
 * @param doc 盘点单
 * @returns 无返回值
 */
async function selectDoc(doc: any): Promise<void> {
  loading.value = true;
  try {
    const detail = await mobileApi.stocktakeDetail(doc.id);
    selectedDoc.value = { id: detail.id, name: detail.name, warehouse: detail.warehouse };
    // 已完成的盘点单保留原有实盘数，便于查看；未录入的默认空串
    lines.value = (detail.lines || []).map((line: any) => ({
      ...line,
      realQty: line.realQty === null || line.realQty === undefined ? '' : line.realQty
    }));
    step.value = 2;
  } catch (err) {
    showError(err);
  } finally {
    loading.value = false;
  }
}

/**
 * 提交盘点结果：校验全部录入后调用接口，成功后进入完成步骤
 * @returns 无返回值
 */
async function submitStocktake(): Promise<void> {
  if (submitting.value) return;
  const empty = lines.value.some((line) => line.realQty === '' || line.realQty === null || line.realQty === undefined);
  if (empty) {
    showToast('请录入所有品项的实盘数');
    return;
  }
  const submitLines = lines.value.map((line) => ({ id: line.id, realQty: Number(line.realQty) }));
  const payload = { id: selectedDoc.value.id, lines: submitLines };
  submitting.value = true;
  try {
    if (!(await isOnline())) {
      enqueue({ type: 'stocktake', title: `盘点 ${selectedDoc.value.id}`, payload });
      result.value = { diffCount: diffCount.value, queued: true };
      showToast('当前无网络，已加入离线队列');
      step.value = 3;
      return;
    }
    result.value = await mobileApi.stocktakeSubmit(payload.id, submitLines);
    result.value.queued = false;
    showToast('盘点提交成功', 'success');
    step.value = 3;
  } catch (err) {
    showError(err);
  } finally {
    submitting.value = false;
  }
}

/**
 * 返回列表并刷新，便于看到已完成状态
 * @returns 无返回值
 */
function backToList(): void {
  step.value = 1;
  loading.value = true;
  loadDocs();
}

onShow(() => {
  loadDocs();
});
</script>

<style scoped>
.stocktake__steps {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 16px;
  padding: 0 6px;
}
.stocktake__step {
  display: flex;
  align-items: center;
  flex: 1;
}
.stocktake__step-dot {
  width: 24px;
  height: 24px;
  border-radius: 50%;
  background: var(--erp-card, #ffffff);
  border: 1px solid var(--erp-border, #e8eaed);
  color: var(--erp-text-3, #8a9099);
  font-size: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
  flex: none;
}
.stocktake__step--active .stocktake__step-dot {
  background: #4d6bfe;
  border-color: #4d6bfe;
  color: #ffffff;
}
.stocktake__step-label {
  margin-left: 6px;
  font-size: 12px;
  color: var(--erp-text-3, #8a9099);
}
.stocktake__step--active .stocktake__step-label {
  color: #4d6bfe;
}
.stocktake__hint {
  font-size: 12px;
  color: var(--erp-text-3, #8a9099);
  margin: 0 2px 10px;
}
.stocktake__doc-top {
  display: flex;
  align-items: center;
  justify-content: space-between;
}
.stocktake__doc-name {
  flex: 1;
  font-size: 14px;
  font-weight: 600;
  color: var(--erp-text, #1a1d21);
  margin-right: 8px;
}
.stocktake__doc-meta {
  display: flex;
  justify-content: space-between;
  margin-top: 8px;
  font-size: 12px;
  color: var(--erp-text-2, #4e5561);
}
.stocktake__doc-time {
  margin-top: 4px;
  font-size: 12px;
  color: var(--erp-text-3, #8a9099);
}
.stocktake__back {
  font-size: 12px;
  color: #4d6bfe;
}
.stocktake__line {
  display: flex;
  align-items: center;
  padding: 10px 0;
  border-bottom: 1px solid var(--erp-divider, #eef0f2);
}
.stocktake__line-info {
  flex: 1;
}
.stocktake__line-name {
  display: block;
  font-size: 13px;
  color: var(--erp-text, #1a1d21);
}
.stocktake__line-book {
  display: block;
  margin-top: 4px;
  font-size: 12px;
  color: var(--erp-text-3, #8a9099);
}
.stocktake__line-input {
  width: 110px;
  display: flex;
  flex-direction: column;
  align-items: flex-end;
}
.stocktake__input {
  width: 80px;
  height: 34px;
  padding: 0 8px;
  text-align: center;
  border: 1px solid var(--erp-border, #e8eaed);
  border-radius: 8px;
  font-size: 14px;
  color: var(--erp-text, #1a1d21);
  background: var(--erp-card, #ffffff);
}
.stocktake__ph {
  color: var(--erp-text-3, #8a9099);
  font-size: 12px;
}
.stocktake__diff {
  margin-top: 4px;
  font-size: 12px;
  color: var(--erp-text-3, #8a9099);
}
.stocktake__diff--has {
  color: #dc2626;
  font-weight: 600;
}
.stocktake__actions {
  display: flex;
  gap: 12px;
}
.stocktake__actions button {
  flex: 1;
}
.stocktake__result {
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 16px 0;
}
.stocktake__result-icon {
  width: 54px;
  height: 54px;
  border-radius: 50%;
  background: rgba(22, 163, 74, 0.12);
  color: #16a34a;
  font-size: 28px;
  display: flex;
  align-items: center;
  justify-content: center;
}
.stocktake__result-title {
  margin-top: 12px;
  font-size: 16px;
  font-weight: 600;
  color: var(--erp-text, #1a1d21);
}
.stocktake__result-desc {
  margin-top: 8px;
  font-size: 13px;
  color: var(--erp-text-2, #4e5561);
  text-align: center;
  line-height: 1.6;
}
.stocktake__again {
  margin-top: 12px;
}
</style>
