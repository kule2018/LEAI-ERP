<!--
 * todo.vue 待办中心
 * 职责：按类型分组展示审批、待发货、逾期应收三类待办，支持类型切换与下拉刷新。
 * 说明：审批类点击跳转审批详情页；其余类型点击弹出事项详情，保证每个入口都能走通。
-->
<template>
  <view class="erp-page todo" :class="{ 'theme-dark': appState.theme === 'dark' }">
    <!-- 顶部统计 -->
    <view class="todo__summary">
      <view class="todo__summary-item">
        <text class="todo__summary-num">{{ allList.length }}</text>
        <text class="todo__summary-label">全部待办</text>
      </view>
      <view class="todo__summary-item">
        <text class="todo__summary-num" style="color: #4d6bfe">{{ countByType('approval') }}</text>
        <text class="todo__summary-label">待审批</text>
      </view>
      <view class="todo__summary-item">
        <text class="todo__summary-num" style="color: #dc2626">{{ countByType('receivable') }}</text>
        <text class="todo__summary-label">逾期应收</text>
      </view>
    </view>

    <!-- 类型筛选 -->
    <view class="todo__tabs">
      <view
        v-for="tab in tabs"
        :key="tab.key"
        class="todo__tab"
        :class="{ 'todo__tab--active': activeTab === tab.key }"
        @click="activeTab = tab.key"
      >
        {{ tab.label }}
      </view>
    </view>

    <!-- 加载 / 错误 / 空态 -->
    <ErpLoading v-if="loading" text="正在加载待办..." />
    <ErpCard v-else-if="error" title="加载失败">
      <text class="erp-muted">{{ error }}</text>
      <button class="erp-btn erp-btn--plain todo__retry" @click="loadData">重新加载</button>
    </ErpCard>
    <ErpEmpty v-else-if="visibleGroups.length === 0" text="暂无待办事项" hint="所有事项都已处理完毕" />

    <!-- 分组列表 -->
    <view v-else>
      <view v-for="group in visibleGroups" :key="group.type" class="todo__group">
        <view class="todo__group-title">
          <text class="todo__group-dot" :style="{ background: group.color }"></text>
          <text>{{ group.title }}</text>
          <text class="todo__group-count">{{ group.items.length }}</text>
        </view>

        <ErpCard v-for="item in group.items" :key="item.id" tight>
          <view class="todo__item" @click="openItem(item)">
            <view class="todo__item-top">
              <text class="todo__item-title">{{ item.title }}</text>
              <ErpStatusTag :text="statusText(item.type)" :tone="statusTone(item.type)" />
            </view>
            <view class="todo__item-meta">
              <text>单号 {{ item.bizNo }}</text>
              <text>¥{{ formatMoney(item.amount) }}</text>
            </view>
            <view class="todo__item-bottom">
              <text>{{ item.applicant }}</text>
              <text>{{ item.time }}</text>
            </view>
          </view>
        </ErpCard>
      </view>
    </view>
  </view>
</template>

<script setup lang="ts">
import { computed, ref } from 'vue';
import { onPullDownRefresh, onShow } from '@dcloudio/uni-app';
import ErpCard from '../../components/ErpCard.vue';
import ErpEmpty from '../../components/ErpEmpty.vue';
import ErpLoading from '../../components/ErpLoading.vue';
import ErpStatusTag from '../../components/ErpStatusTag.vue';
import { mobileApi } from '../../api';
import { appState } from '../../store';
import { formatMoney, goPage, showError } from '../../utils';

/** 类型筛选标签 */
const tabs = [
  { key: 'all', label: '全部' },
  { key: 'approval', label: '审批' },
  { key: 'ship', label: '待发货' },
  { key: 'receivable', label: '应收' }
];

/** 全部待办数据 */
const allList = ref<any[]>([]);
/** 当前筛选类型 */
const activeTab = ref('all');
/** 加载态 */
const loading = ref(true);
/** 错误信息 */
const error = ref('');

/** 分组配置：顺序固定为审批、待发货、逾期应收 */
const groupConfig = [
  { type: 'approval', title: '待我审批', color: '#4d6bfe' },
  { type: 'ship', title: '待发货', color: '#d97706' },
  { type: 'receivable', title: '逾期应收', color: '#dc2626' }
];

/**
 * 按类型统计数量
 * @param type 待办类型
 * @returns 该类型待办条数
 */
function countByType(type: string): number {
  return allList.value.filter((item) => item.type === type).length;
}

/**
 * 待办类型对应的状态文案
 * @param type 待办类型
 * @returns 状态文案
 */
function statusText(type: string): string {
  if (type === 'approval') return '待审批';
  if (type === 'ship') return '待发货';
  return '已逾期';
}

/**
 * 待办类型对应的标签色调
 * @param type 待办类型
 * @returns 色调枚举
 */
function statusTone(type: string): 'info' | 'warning' | 'danger' {
  if (type === 'approval') return 'info';
  if (type === 'ship') return 'warning';
  return 'danger';
}

/** 按当前筛选条件生成的分组列表 */
const visibleGroups = computed(() => {
  const source = activeTab.value === 'all' ? allList.value : allList.value.filter((i) => i.type === activeTab.value);
  return groupConfig
    .map((cfg) => ({ ...cfg, items: source.filter((item) => item.type === cfg.type) }))
    .filter((group) => group.items.length > 0);
});

/**
 * 加载待办列表
 * @returns 无返回值
 */
async function loadData(): Promise<void> {
  loading.value = true;
  error.value = '';
  try {
    const result = await mobileApi.todo();
    allList.value = result.list || [];
  } catch (err) {
    error.value = err instanceof Error ? err.message : '待办加载失败';
    showError(err);
  } finally {
    loading.value = false;
  }
}

/**
 * 点击待办项
 * @param item 待办对象
 * @returns 无返回值
 */
function openItem(item: any): void {
  if (item.type === 'approval') {
    goPage(`/pages/approval/approval?id=${item.id}`);
    return;
  }
  uni.showModal({
    title: item.title,
    content: `单号：${item.bizNo}\n金额：¥${formatMoney(item.amount)}\n负责人：${item.applicant}\n时间：${item.time}\n\n请在 PC 管理端处理该事项。`,
    showCancel: false,
    confirmColor: '#4d6bfe'
  });
}

onShow(() => {
  loadData();
});

onPullDownRefresh(async () => {
  await loadData();
  uni.stopPullDownRefresh();
});
</script>

<style scoped>
.todo__summary {
  display: flex;
  background: var(--erp-card, #ffffff);
  border: 1px solid var(--erp-border, #e8eaed);
  border-radius: 10px;
  padding: 14px 0;
  margin-bottom: 12px;
}
.todo__summary-item {
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  border-right: 1px solid var(--erp-divider, #eef0f2);
}
.todo__summary-item:last-child {
  border-right: none;
}
.todo__summary-num {
  font-size: 20px;
  font-weight: 650;
  color: var(--erp-text, #1a1d21);
}
.todo__summary-label {
  margin-top: 4px;
  font-size: 12px;
  color: var(--erp-text-3, #8a9099);
}
.todo__tabs {
  display: flex;
  gap: 8px;
  margin-bottom: 12px;
}
.todo__tab {
  padding: 6px 14px;
  border-radius: 999px;
  font-size: 13px;
  color: var(--erp-text-2, #4e5561);
  background: var(--erp-card, #ffffff);
  border: 1px solid var(--erp-border, #e8eaed);
}
.todo__tab--active {
  color: #ffffff;
  background: #4d6bfe;
  border-color: #4d6bfe;
}
.todo__group {
  margin-bottom: 14px;
}
.todo__group-title {
  display: flex;
  align-items: center;
  font-size: 14px;
  font-weight: 600;
  color: var(--erp-text, #1a1d21);
  margin-bottom: 8px;
  padding-left: 2px;
}
.todo__group-dot {
  width: 6px;
  height: 14px;
  border-radius: 3px;
  margin-right: 8px;
}
.todo__group-count {
  margin-left: 6px;
  font-size: 12px;
  font-weight: 400;
  color: var(--erp-text-3, #8a9099);
}
.todo__item-top {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
}
.todo__item-title {
  flex: 1;
  font-size: 13px;
  font-weight: 500;
  color: var(--erp-text, #1a1d21);
  line-height: 1.5;
  margin-right: 8px;
}
.todo__item-meta {
  display: flex;
  justify-content: space-between;
  margin-top: 8px;
  font-size: 12px;
  color: var(--erp-text-2, #4e5561);
}
.todo__item-bottom {
  display: flex;
  justify-content: space-between;
  margin-top: 6px;
  font-size: 12px;
  color: var(--erp-text-3, #8a9099);
}
.todo__retry {
  margin-top: 12px;
  height: 34px;
}
</style>
