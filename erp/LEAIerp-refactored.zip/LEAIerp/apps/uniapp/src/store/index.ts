/**
 * store/index.ts —— 全局响应式状态
 * 职责：保存当前登录用户、主题与全局 UI 状态，并封装本地存储的读写。
 * 说明：不引入 pinia，使用 Vue 的 reactive 即可满足移动端轻量状态管理需求，保持扁平易读。
 */
import { reactive } from 'vue';
import { THEME_KEY, TOKEN_KEY, USER_KEY } from '../config';

/** 用户状态：token 与基本信息 */
export const userState = reactive({
  token: '',
  username: '',
  realName: '',
  tenantName: '',
  deptName: '',
  perms: [] as string[]
});

/** 应用全局状态 */
export const appState = reactive({
  /** 当前主题：light / dark */
  theme: 'light',
  /** 全局请求加载中标记（预留给统一 loading） */
  loading: false
});

/**
 * 应用启动时初始化：从 uni storage 恢复 token / 用户 / 主题
 * 说明：H5 端 uni.getStorageSync 底层即 localStorage，与 PC 端共用 erp_token key。
 * @returns 无返回值
 */
export function initStore(): void {
  const token = uni.getStorageSync(TOKEN_KEY);
  if (token) userState.token = token;

  const rawUser = uni.getStorageSync(USER_KEY);
  if (rawUser) {
    try {
      const info = typeof rawUser === 'string' ? JSON.parse(rawUser) : rawUser;
      userState.username = info.username || '';
      userState.realName = info.realName || '';
      userState.tenantName = info.tenantName || '';
      userState.deptName = info.deptName || '';
      userState.perms = info.perms || [];
    } catch (error) {
      // 本地数据损坏时忽略，不影响应用启动
      userState.username = '';
    }
  }

  const theme = uni.getStorageSync(THEME_KEY);
  if (theme === 'dark' || theme === 'light') appState.theme = theme;
}

/**
 * 写入登录态：同步内存状态与本地存储
 * @param payload 登录接口返回的 { token, userInfo }
 * @returns 无返回值
 */
export function setLogin(payload: { token: string; userInfo: any }): void {
  const info = payload.userInfo || {};
  userState.token = payload.token || '';
  userState.username = info.username || '';
  userState.realName = info.realName || '';
  userState.tenantName = info.tenantName || '';
  userState.deptName = info.deptName || '';
  userState.perms = info.perms || [];

  uni.setStorageSync(TOKEN_KEY, userState.token);
  uni.setStorageSync(USER_KEY, JSON.stringify(info));
}

/**
 * 退出登录：清空内存状态与本地存储
 * @returns 无返回值
 */
export function logout(): void {
  userState.token = '';
  userState.username = '';
  userState.realName = '';
  userState.tenantName = '';
  userState.deptName = '';
  userState.perms = [];
  uni.removeStorageSync(TOKEN_KEY);
  uni.removeStorageSync(USER_KEY);
}

/**
 * 切换主题并持久化
 * @returns 切换后的主题字符串
 */
export function toggleTheme(): string {
  appState.theme = appState.theme === 'dark' ? 'light' : 'dark';
  uni.setStorageSync(THEME_KEY, appState.theme);
  return appState.theme;
}

/**
 * 是否已登录
 * @returns token 非空即视为已登录
 */
export function isLoggedIn(): boolean {
  return !!userState.token;
}
