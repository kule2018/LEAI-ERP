/**
 * utils.ts —— 通用轻量工具
 * 职责：集中封装轻提示、确认弹窗、页面跳转、金额格式化，避免各页面重复编写。
 */
import { TAB_PAGES } from './config';

/**
 * 显示轻提示
 * @param title 提示文案
 * @param icon 图标，默认 none（uni 支持 success / error / loading / none）
 * @returns 无返回值
 */
export function showToast(title: string, icon: 'none' | 'success' | 'error' = 'none'): void {
  uni.showToast({ title, icon, duration: 1800 });
}

/**
 * 显示错误提示（统一用 none 图标，避免小程序 success 图标样式差异）
 * @param error 错误对象或文案
 * @returns 无返回值
 */
export function showError(error: any): void {
  const message = error && error.message ? error.message : String(error || '操作失败');
  showToast(message);
}

/**
 * 带取消/确认的弹窗
 * @param content 提示内容
 * @param title 标题，默认“提示”
 * @returns Promise<boolean> 用户点确定返回 true，取消返回 false
 */
export function confirmAction(content: string, title = '提示'): Promise<boolean> {
  return new Promise((resolve) => {
    uni.showModal({
      title,
      content,
      confirmColor: '#4d6bfe',
      success: (res: any) => resolve(!!res.confirm),
      fail: () => resolve(false)
    });
  });
}

/**
 * 统一的页面跳转：自动区分 tabBar 页面与普通页面
 * @param url 以 / 开头的页面路径，如 /pages/home/home
 * @returns 无返回值
 */
export function goPage(url: string): void {
  if (TAB_PAGES.indexOf(url) >= 0) {
    uni.switchTab({ url });
  } else {
    uni.navigateTo({ url });
  }
}

/**
 * 金额格式化：加千分位并保留两位小数
 * @param value 数字或数字字符串
 * @returns 格式化后的金额字符串
 */
export function formatMoney(value: number | string): string {
  const num = Number(value || 0);
  return num.toLocaleString('zh-CN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

/**
 * 短时间延迟，用于提交成功后让用户看到提示再返回
 * @param ms 毫秒数
 * @returns Promise
 */
export function wait(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
