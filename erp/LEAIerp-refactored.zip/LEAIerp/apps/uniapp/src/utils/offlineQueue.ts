/**
 * offlineQueue.ts —— 离线待提交操作队列
 * 职责：断网时把「盘点 / 拣货 / 销售开单」操作暂存本地，恢复网络后可重试提交并提示冲突。
 * 存储：H5 端 uni.setStorageSync 底层即 localStorage；小程序 / App 使用各自本地存储，跨端一致。
 * 说明：导出响应式 offlineCount，供「我的」页实时展示待提交数量；sync 逐条回放，失败保留并累加重试次数。
 */
import { ref } from 'vue';
import { mobileApi } from '../api';

/** 本地存储 key（我的页清缓存时需要保留） */
export const OFFLINE_QUEUE_KEY = 'erp_offline_queue';

/** 支持离线的业务类型 */
export type OfflineOpType = 'stocktake' | 'picking' | 'sales';

/** 一条离线待提交操作 */
export interface OfflineOp {
  /** 唯一 id */
  id: string;
  /** 业务类型 */
  type: OfflineOpType;
  /** 列表展示标题 */
  title: string;
  /** 提交参数（联网回放时使用） */
  payload: any;
  /** 创建时间文本 */
  createdAt: string;
  /** 已重试次数 */
  retries: number;
  /** 最近一次失败原因 */
  lastError?: string;
  /** 是否为业务冲突（单据已处理，需人工确认） */
  conflict?: boolean;
}

/** 同步结果统计 */
export interface SyncResult {
  /** 成功条数 */
  success: number;
  /** 仍失败条数 */
  failed: number;
  /** 冲突条数 */
  conflicts: number;
}

/** 响应式待提交数量，页面模板可直接绑定 */
export const offlineCount = ref(0);

/**
 * 生成唯一 id：时间戳 36 进制 + 随机串，避免同一毫秒多次入队冲突
 * @returns 唯一 id 字符串
 */
function genId(): string {
  return 'op_' + Date.now().toString(36) + '_' + Math.floor(Math.random() * 1000).toString(36);
}

/**
 * 读取队列，兼容字符串 / 对象两种存储形态，损坏数据按空队列处理
 * @returns 离线操作数组
 */
function readQueue(): OfflineOp[] {
  try {
    const raw = uni.getStorageSync(OFFLINE_QUEUE_KEY);
    if (!raw) return [];
    const parsed = typeof raw === 'string' ? JSON.parse(raw) : raw;
    return Array.isArray(parsed) ? parsed : [];
  } catch (error) {
    return [];
  }
}

/**
 * 写入队列并同步响应式计数
 * @param list 待写入的队列
 * @returns 无返回值
 */
function writeQueue(list: OfflineOp[]): void {
  uni.setStorageSync(OFFLINE_QUEUE_KEY, JSON.stringify(list));
  offlineCount.value = list.length;
}

/**
 * 初始化计数：模块加载即执行一次，保证各页面首次进入显示正确数量
 * @returns 无返回值
 */
export function initOfflineQueue(): void {
  offlineCount.value = readQueue().length;
}

/**
 * 入队一条待提交操作
 * @param op 业务类型、展示标题与提交参数
 * @returns 新建的离线操作对象
 */
export function enqueue(op: { type: OfflineOpType; title: string; payload: any }): OfflineOp {
  const list = readQueue();
  const item: OfflineOp = {
    id: genId(),
    type: op.type,
    title: op.title,
    payload: op.payload,
    createdAt: new Date().toISOString().slice(0, 16).replace('T', ' '),
    retries: 0,
    conflict: false
  };
  list.push(item);
  writeQueue(list);
  return item;
}

/**
 * 列出全部待提交操作（返回副本，避免外部直接修改内部数据）
 * @returns 离线操作数组
 */
export function list(): OfflineOp[] {
  return readQueue().map((item) => ({ ...item }));
}

/**
 * 查询待提交数量
 * @returns 数量
 */
export function getCount(): number {
  return readQueue().length;
}

/**
 * 删除单条操作
 * @param id 操作 id
 * @returns 无返回值
 */
export function remove(id: string): void {
  writeQueue(readQueue().filter((item) => item.id !== id));
}

/**
 * 清空队列
 * @returns 无返回值
 */
export function clear(): void {
  writeQueue([]);
}

/**
 * 判断当前是否有网络：H5 用 getNetworkType，失败时以 navigator.onLine 兜底
 * @returns 是否有网
 */
export function isOnline(): Promise<boolean> {
  return new Promise((resolve) => {
    try {
      uni.getNetworkType({
        success: (res: any) => resolve(!!res.networkType && res.networkType !== 'none'),
        fail: () => resolve(typeof navigator !== 'undefined' ? navigator.onLine !== false : true)
      });
    } catch (error) {
      resolve(typeof navigator !== 'undefined' ? navigator.onLine !== false : true);
    }
  });
}

/**
 * 判断错误是否属于业务冲突：单据已处理 / 已完成时重试无意义，需提示用户
 * @param error 异常对象
 * @returns 是否冲突
 */
function isConflictError(error: any): boolean {
  const message = error && error.message ? String(error.message) : String(error || '');
  return /不存在|已处理|已提交|已盘点|已完成|冲突|重复|已审核/.test(message);
}

/**
 * 按业务类型回放单条操作：复用 mobileApi，确保与在线提交走同一套 mock/真实逻辑
 * @param op 离线操作
 * @returns 无返回值，失败时抛出异常
 */
async function replay(op: OfflineOp): Promise<void> {
  if (op.type === 'stocktake') {
    await mobileApi.stocktakeSubmit(op.payload.id, op.payload.lines);
  } else if (op.type === 'picking') {
    await mobileApi.pickingSubmit(op.payload.id, op.payload.lines);
  } else if (op.type === 'sales') {
    const draft = await mobileApi.salesSave(op.payload);
    await mobileApi.salesSubmit({ id: draft.id });
  }
}

/**
 * 同步队列：逐条回放，成功移出队列，失败保留并累加重试次数。
 * @returns 成功 / 失败 / 冲突统计
 */
export async function sync(): Promise<SyncResult> {
  const result: SyncResult = { success: 0, failed: 0, conflicts: 0 };
  const queue = readQueue();
  const remain: OfflineOp[] = [];
  for (const op of queue) {
    try {
      await replay(op);
      result.success += 1;
    } catch (error) {
      const conflict = isConflictError(error);
      if (conflict) result.conflicts += 1;
      else result.failed += 1;
      remain.push({
        ...op,
        retries: op.retries + 1,
        conflict,
        lastError: error && error.message ? String(error.message) : String(error || '提交失败')
      });
    }
  }
  writeQueue(remain);
  return result;
}

// 模块加载时刷新一次计数，保证「我的」页角标初始值正确
initOfflineQueue();
