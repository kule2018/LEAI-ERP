import { defineConfig } from 'vite';
import uni from '@dcloudio/vite-plugin-uni';

/**
 * UniApp + Vite 构建配置
 * 说明：
 * 1. 使用 @dcloudio/vite-plugin-uni 插件，一份代码编译到 H5 / 小程序 / App。
 * 2. H5 开发时把 /api 代理到后端，真实地址可用环境变量 VITE_PROXY_TARGET 覆盖。
 * 3. 端口固定 5174，避免与 PC 管理端（默认 5173）冲突。
 */
export default defineConfig({
  plugins: [uni()],
  server: {
    host: '0.0.0.0',
    port: 5174,
    proxy: {
      '/api': {
        target: process.env.VITE_PROXY_TARGET || 'http://localhost:3000',
        changeOrigin: true
      }
    }
  }
});
