<template>
  <router-view />
  <DsConfirm />
  <DsPrompt />
</template>

<script setup lang="ts">
import DsConfirm from './components/ds/DsConfirm.vue';
import DsPrompt from './components/ds/DsPrompt.vue';
</script>
