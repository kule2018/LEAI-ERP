/** 扩展模块接口：BPM / BI / CRM / WMS / MES / 商城 / 移动端（统一走 Mock 适配器） */
import { mockGet as get, mockPost as post } from './mockAdapter'

export const bpmApi = {
  definitions: () => get('/api/v1/bpm/definitions', {}),
  saveDefinition: (d: any) => post('/api/v1/bpm/definitions', d),
  start: (d: any) => post('/api/v1/bpm/start', d),
  todo: () => get('/api/v1/bpm/tasks/todo', {}),
  done: () => get('/api/v1/bpm/tasks/done', {}),
  handle: (id: number, d: any) => post(`/api/v1/bpm/tasks/${id}/handle`, d),
  /** 撤回：申请人终止流程，单据恢复可编辑 */
  cancel: (id: number, comment?: string) => post(`/api/v1/bpm/tasks/${id}/cancel`, { comment: comment || '申请人撤回' }),
  /** 转办：把待办指派给其他人 */
  transfer: (id: number, assignee: string) => post(`/api/v1/bpm/tasks/${id}/transfer`, { assignee }),
  instance: (id: number) => get(`/api/v1/bpm/instances/${id}`, {}),
  logs: (id: number) => get(`/api/v1/bpm/instances/${id}/logs`, {}),
  saveDelegation: (d: any) => post('/api/v1/bpm/delegations', d),
}
export const biApi = {
  trend: () => get('/api/v1/bi/trend', {}),
  reports: () => get('/api/v1/bi/reports', {}),
  saveReport: (d: any) => post('/api/v1/bi/reports', d),
  run: (id: number, params?: any) => post(`/api/v1/bi/reports/${id}/run`, params || {}),
  dashboard: () => get('/api/v1/bi/dashboard', {}),
  subscriptions: () => get('/api/v1/bi/subscriptions', {}),
  saveSubscription: (d: any) => post('/api/v1/bi/subscriptions', d),
}
export const crmApi = {
  leads: (q?: any) => get('/api/v1/crm/leads', q || {}),
  saveLead: (d: any) => post('/api/v1/crm/leads', d),
  convertLead: (id: number, d: any) => post(`/api/v1/crm/leads/${id}/convert`, d),
  opportunities: (q?: any) => get('/api/v1/crm/opportunities', q || {}),
  saveOpportunity: (d: any) => post('/api/v1/crm/opportunities', d),
  follows: (bizType: string, bizId: number) => get('/api/v1/crm/follows', { bizType, bizId }),
  addFollow: (d: any) => post('/api/v1/crm/follows', d),
  quotations: () => get('/api/v1/crm/quotations', {}),
  saveQuotation: (d: any) => post('/api/v1/crm/quotations', d),
  acceptQuotation: (id: number) => post(`/api/v1/crm/quotations/${id}/accept`, {}),
}
export const wmsApi = {
  putaways: () => get('/api/v1/wms/putaways', {}),
  createPutaway: (d: any) => post('/api/v1/wms/putaways', d),
  confirmPutaway: (id: number) => post(`/api/v1/wms/putaways/${id}/confirm`, {}),
  waves: () => get('/api/v1/wms/waves', {}),
  generateWave: (d: any) => post('/api/v1/wms/waves', d),
  waveLines: (id: number) => get(`/api/v1/wms/waves/${id}/lines`, {}),
  pick: (id: number, lineId: number, qty: number) => post(`/api/v1/wms/waves/${id}/lines/${lineId}/pick`, { qty }),
  stocktakes: () => get('/api/v1/wms/stocktakes', {}),
  createStocktake: (d: any) => post('/api/v1/wms/stocktakes', d),
  stocktakeLines: (id: number) => get(`/api/v1/wms/stocktakes/${id}/lines`, {}),
  inputReal: (id: number, realQty: number) => post(`/api/v1/wms/stocktake-lines/${id}/real`, { realQty }),
  finishStocktake: (id: number) => post(`/api/v1/wms/stocktakes/${id}/finish`, {}),
  transfers: () => get('/api/v1/wms/transfers', {}),
  createTransfer: (d: any) => post('/api/v1/wms/transfers', d),
  executeTransfer: (id: number) => post(`/api/v1/wms/transfers/${id}/execute`, {}),
  crossdocks: () => get('/api/v1/wms/crossdocks', {}),
  createCrossdock: (d: any) => post('/api/v1/wms/crossdocks', d),
}
export const mesApi = {
  routings: (productId?: number) => get('/api/v1/mes/routings', productId ? { productId } : {}),
  saveRouting: (d: any) => post('/api/v1/mes/routings', d),
  runMrp: (d?: any) => post('/api/v1/mes/mrp/run', d || {}),
  runs: () => get('/api/v1/mes/mrp/runs', {}),
  suggests: (runId: number) => get('/api/v1/mes/mrp/suggests', { runId }),
  workOrders: () => get('/api/v1/mes/workorders', {}),
  createWorkOrder: (d: any) => post('/api/v1/mes/workorders', d),
  reports: (workorderId: number) => get('/api/v1/mes/reports', { workorderId }),
  addReport: (d: any) => post('/api/v1/mes/reports', d),
  qc: () => get('/api/v1/mes/qc', {}),
  saveQc: (d: any) => post('/api/v1/mes/qc', d),
  equipments: () => get('/api/v1/mes/equipments', {}),
  saveEquipment: (d: any) => post('/api/v1/mes/equipments', d),
}
export const shopApi = {
  stores: () => get('/api/v1/shop/stores', {}),
  saveStore: (d: any) => post('/api/v1/shop/stores', d),
  goodsMaps: (storeId: number) => get('/api/v1/shop/goods-maps', { storeId }),
  saveGoodsMap: (d: any) => post('/api/v1/shop/goods-maps', d),
  orders: (q?: any) => get('/api/v1/shop/orders', q || {}),
  sync: (id: number, orders: any[]) => post(`/api/v1/shop/stores/${id}/sync`, { orders }),
  convert: (id: number) => post(`/api/v1/shop/orders/${id}/convert`, {}),
  ship: (id: number, d: any) => post(`/api/v1/shop/orders/${id}/ship`, d),
}
export const mobileApi = {
  home: () => get('/api/v1/mobile/home', {}),
  todo: () => get('/api/v1/mobile/todo', {}),
  scan: (code: string) => get('/api/v1/mobile/scan', { code }),
  stock: (keyword: string) => get('/api/v1/mobile/stock', { keyword }),
  offlineSubmit: (batchId: string, items: any[]) => post('/api/v1/mobile/offline-submit', { batchId, items }),
}
