// 全部接口统一经过 Mock 适配器：默认本地全量数据，VITE_USE_MOCK=false 时直连后端并自动降级
import { mockGet as get, mockPost as post } from './mockAdapter';
import { pageData } from './pageData';

/** 各模块接口集合，路径与后端 Controller 一一对应 */
export const authApi = {
  login: (data: any) => post('/api/v1/auth/login', data),
  refresh: (token: string) => post('/api/v1/auth/refresh', { token }),
};

export const sysApi = {
  users: (q?: any) => get('/api/v1/system/users', q),
  saveUser: (d: any) => post('/api/v1/system/users', d),
  roles: () => get('/api/v1/system/roles'),
  saveRole: (d: any) => post('/api/v1/system/roles', d),
  permissions: () => get('/api/v1/system/permissions'),
  orgs: () => get('/api/v1/system/orgs'),
  dict: (code: string) => get(`/api/v1/system/dicts/${code}`),
  dicts: () => get('/api/v1/system/dicts'),
  configs: () => get('/api/v1/system/configs'),
  saveConfig: (key: string, value: string) => post('/api/v1/system/configs', { key, value }),
  notifies: () => get('/api/v1/system/notifies'),
  addNotify: (d: any) => post('/api/v1/system/notifies', d),
  readNotify: (id: number) => post(`/api/v1/system/notifies/${id}/read`),
  auditLogs: (q?: any) => get('/api/v1/system/audit-logs', q),
  loginLogs: () => get('/api/v1/system/login-logs'),
};

export const inventoryApi = {
  products: (q?: any) => get('/api/v1/inventory/products', q),
  saveProduct: (d: any) => post('/api/v1/inventory/products', d),
  saveVariants: (id: number, d: any) => post(`/api/v1/inventory/products/${id}/variants`, d),
  voidProduct: (id: number) => post(`/api/v1/inventory/products/${id}/void`, {}),
  warehouses: () => get('/api/v1/inventory/warehouses'),
  categories: () => get('/api/v1/inventory/categories'),
  balance: (q?: any) => get('/api/v1/inventory/balance', q),
  ledger: (q?: any) => get('/api/v1/inventory/ledger', q),
  alerts: () => get('/api/v1/inventory/alerts'),
};

export const salesApi = {
  customers: (q?: any) => get('/api/v1/crm/customers', q),
  list: (q?: any) => get('/api/v1/sales/orders', q),
  detail: (id: number) => get(`/api/v1/sales/orders/${id}`),
  create: (d: any) => post('/api/v1/sales/orders', d),
  update: (id: number, d: any) => post(`/api/v1/sales/orders/${id}`, d),
  submit: (id: number) => post(`/api/v1/sales/orders/${id}/submit`),
  confirm: (id: number) => post(`/api/v1/sales/orders/${id}/confirm`),
  ship: (id: number) => post(`/api/v1/sales/orders/${id}/ship`),
  invoice: (id: number) => post(`/api/v1/sales/orders/${id}/invoice`),
  void: (id: number) => post(`/api/v1/sales/orders/${id}/void`),
  copy: (id: number) => post(`/api/v1/sales/orders/${id}/copy`),
  doReturn: (id: number, d: any) => post(`/api/v1/sales/orders/${id}/return`, d),
};

export const purchaseApi = {
  list: (q?: any) => pageData<any>('GET', '/api/v1/purchase/orders', q),
  detail: (id: number) => pageData<any>('GET', `/api/v1/purchase/orders/${id}`),
  create: (d: any) => pageData<any>('POST', '/api/v1/purchase/orders', d),
  update: (id: number, d: any) => pageData<any>('POST', `/api/v1/purchase/orders/${id}`, d),
  submit: (id: number) => pageData<any>('POST', `/api/v1/purchase/orders/${id}/submit`),
  confirm: (id: number) => pageData<any>('POST', `/api/v1/purchase/orders/${id}/confirm`),
  receive: (id: number, d?: any) => pageData<any>('POST', `/api/v1/purchase/orders/${id}/receive`, d),
  doReturn: (id: number, d: any) => pageData<any>('POST', `/api/v1/purchase/orders/${id}/return`, d),
  void: (id: number) => pageData<any>('POST', `/api/v1/purchase/orders/${id}/void`),
};

export const financeApi = {
  subjects: () => get('/api/v1/finance/subjects'),
  saveSubject: (d: any) => post('/api/v1/finance/subjects', d),
  accounts: () => get('/api/v1/finance/accounts'),
  saveAccount: (d: any) => post('/api/v1/finance/accounts', d),
  vouchers: (q?: any) => get('/api/v1/finance/vouchers', q),
  voucherDetail: (id: number) => get(`/api/v1/finance/vouchers/${id}`),
  saveVoucher: (d: any) => post('/api/v1/finance/vouchers', d),
  postVoucher: (id: number) => post(`/api/v1/finance/vouchers/${id}/post`),
  voidVoucher: (id: number) => post(`/api/v1/finance/vouchers/${id}/void`),
  savePayment: (d: any) => post('/api/v1/finance/payments', d),
  confirmPayment: (id: number) => post(`/api/v1/finance/payments/${id}/confirm`),
  trialBalance: () => get('/api/v1/finance/trial-balance'),
  receivableAging: () => get('/api/v1/finance/receivable-aging'),
  payables: () => get('/api/v1/finance/payables'),
  profitLoss: () => get('/api/v1/finance/profit-loss'),
  closePeriod: (p: string) => post(`/api/v1/finance/periods/${p}/close`),
  openPeriod: (p: string) => post(`/api/v1/finance/periods/${p}/open`),
};

export const printApi = {
  templates: (q?: any) => get('/api/v1/print/templates', q),
  listTemplates: (q?: any) => get('/api/v1/print/templates', q),
  saveTemplate: (d: any) => post('/api/v1/print/templates', d),
  preview: (id: number, d: any) => post(`/api/v1/print/templates/${id}/preview`, d),
  createJob: (d: any) => post('/api/v1/print/jobs', d),
  records: (q?: any) => get('/api/v1/print/records', q),
  labels: (d: any) => post('/api/v1/print/labels', d),
};

export const aiApi = {
  copilot: (message: string, stream = false) => post('/api/v1/ai/copilot', { message, stream }),
  docParse: (content: string) => post('/api/v1/ai/doc-parse', { content }),
  ocr: (imageBase64: string) => post('/api/v1/ai/ocr', { imageBase64 }),
  recommend: (d: any) => post('/api/v1/ai/recommend', d),
  forecastRun: () => post('/api/v1/ai/forecast/run', {}),
  forecastResult: (period?: string) => get('/api/v1/ai/forecast/result', { period }),
  anomalyScan: () => post('/api/v1/ai/anomaly/scan', {}),
  reconcile: (d: any) => post('/api/v1/ai/reconcile', d),
  subjectMatch: (summary: string) => post('/api/v1/ai/subject-match', { summary }),
  reportInsight: (metrics: any) => post('/api/v1/ai/report/insight', { metrics }),
  ragQuery: (question: string) => post('/api/v1/ai/rag/query', { question }),
  ragUpload: (d: any) => post('/api/v1/ai/rag/upload', d),
  labelRec: (text: string) => post('/api/v1/ai/label', { text }),
  customerService: (question: string) => post('/api/v1/ai/cs', { question }),
  resumeParse: (text: string) => post('/api/v1/ai/resume', { text }),
  audits: () => get('/api/v1/ai/audits'),
  prompts: () => get('/api/v1/ai/prompts'),
  savePrompt: (d: any) => post('/api/v1/ai/prompts', d),
};

/**
 * 生产计划与排产（APS）接口集合
 * 路径与后端 ApsController / Mock 适配器的 APS 分支一一对应
 */
const apsGet = (path: string, query?: unknown) => pageData<any>('GET', path, query);
const apsPost = (path: string, body?: unknown) => pageData<any>('POST', path, body);

export const apsApi = {
  overview: () => apsGet('/api/v1/aps/overview'),
  plans: (q?: any) => apsGet('/api/v1/aps/plans', q),
  savePlan: (d: any) => apsPost('/api/v1/aps/plans', d),
  planAction: (id: number, action: 'confirm' | 'cancel' | 'issue' | 'complete') => apsPost(`/api/v1/aps/plans/${id}/${action}`, {}),
  runSchedule: (d: any) => apsPost('/api/v1/aps/schedule/run', d),
  runs: () => apsGet('/api/v1/aps/schedule/runs'),
  tasks: (q?: any) => apsGet('/api/v1/aps/tasks', q),
  saveTask: (d: any) => apsPost('/api/v1/aps/tasks', d),
  patchTask: (id: number, d: any) => apsPost(`/api/v1/aps/tasks/${id}`, d),
  completeTask: (id: number) => apsPost(`/api/v1/aps/tasks/${id}/complete`, {}),
  loads: (q?: any) => apsGet('/api/v1/aps/loads', q),
  rebuildLoads: () => apsPost('/api/v1/aps/loads/rebuild', {}),
  resources: () => apsGet('/api/v1/aps/resources'),
  saveResource: (d: any) => apsPost('/api/v1/aps/resources', d),
  calendars: (q?: any) => apsGet('/api/v1/aps/calendars', q),
  saveCalendar: (d: any) => apsPost('/api/v1/aps/calendars', d),
  batchCalendar: (d: any) => apsPost('/api/v1/aps/calendars/batch', d),
  materials: (q?: any) => apsGet('/api/v1/aps/material-check', q),
  materialCheck: (planId?: number) => apsPost('/api/v1/aps/material-check', { planId }),
  alerts: (q?: any) => apsGet('/api/v1/aps/alerts', q),
  resolveAlert: (id: number) => apsPost(`/api/v1/aps/alerts/${id}/resolve`, {}),
};
