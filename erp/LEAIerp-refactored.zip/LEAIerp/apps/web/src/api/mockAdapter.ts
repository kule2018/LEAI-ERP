/**
 * PC 端本地业务数据层（Mock 适配器）
 * ---------------------------------------------------------------------------
 * 作用：当后端未启动或显式开启 Mock 时，接管全部 /api/v1/** 请求，
 *       用本地内存 + localStorage 模拟数据库、状态机与业务联动，
 *       保证「无后端也能把销售→库存→应收→凭证、采购→入库→应付、审批、
 *       打印、AI、WMS/MES/CRM/商城、移动端」全链路走通。
 *
 * 设计原则（遵循《注释.txt》）：
 *   1. 代码尽量扁平：一个入口函数 + 若干按业务域分组的处理函数，不搞层层包装；
 *   2. 每个函数顶部写清「功能 / 参数 / 返回值」；
 *   3. 核心业务（库存扣减、状态流转、凭证生成）写详细中文注释；
 *   4. 数据保存在 localStorage，刷新页面不丢失，可通过「系统设置-重置演示数据」清空。
 */
import axios from 'axios';
import { getEntitySchema } from '../config/entitySchemas';
import { buildFlow, sideEffectsFor, canonicalState, type BizFlow } from '../config/businessFlows';

/** 业务方案设置存储键（独立于业务数据，页面「业务方案」抽屉可改且真实影响联动） */
const SCHEME_KEY = 'erp_mock_schemes_v1';

/**
 * 读取全部业务方案：集合名 -> { key: value }。
 * @returns 方案映射
 */
function loadSchemes(): Record<string, Record<string, any>> {
  try { return JSON.parse(localStorage.getItem(SCHEME_KEY) || '{}'); } catch { return {}; }
}

/**
 * 取某集合的方案（缺省值由 buildFlow 提供）。
 * @param collection 集合名
 * @returns 合并后的方案对象
 */
function schemeOf(collection: string, flowKey = ''): Record<string, any> {
  const flow = buildFlow(collection, collection, '', [], flowKey);
  const defaults: Record<string, any> = {};
  for (const s of flow.scheme) defaults[s.key] = s.value;
  return { ...defaults, ...(loadSchemes()[collection] || {}) };
}

/**
 * 保存某集合的业务方案（写 localStorage，立即影响后续动作）。
 * @param collection 集合名
 * @param values 方案值
 * @returns 保存后的方案
 */
function saveScheme(collection: string, values: Record<string, any>): Record<string, any> {
  const all = loadSchemes();
  all[collection] = { ...(all[collection] || {}), ...values };
  try { localStorage.setItem(SCHEME_KEY, JSON.stringify(all)); } catch { /* 忽略配额错误 */ }
  return all[collection];
}

/**
 * 写审计日志：所有状态动作与方案变更都留痕（文档要求「谁/何时/改了什么」）。
 * @param module 模块集合名
 * @param action 动作标识
 * @param bizId 单据 id
 * @param detail 中文说明
 */
function writeAudit(module: string, action: string, bizId: any, detail: string): void {
  table('auditLogs').push({
    id: nextId('auditLogs'), module: String(module).toUpperCase(), action: String(action).toUpperCase(),
    bizId: Number(bizId) || 0, detail, operator: '当前用户', createdAt: now(),
  });
}

/**
 * 写通知中心：状态流转后向待办/通知推送（方案可关闭）。
 * @param title 标题
 * @param content 内容
 */
function writeNotify(title: string, content: string): void {
  table('notifies').push({ id: nextId('notifies'), title, content, isRead: 0, createdAt: now() });
}

/** 是否默认启用 Mock：VITE_USE_MOCK=false 时走真实后端 */
export const MOCK_ENABLED = (import.meta as any).env?.VITE_USE_MOCK !== 'false';

/** 本地数据库存储键 */
const DB_KEY = 'erp_mock_db_v3';
/** 种子数据版本：升级种子时 +1，旧库会自动补齐新增/空集合，不清空用户已产生的业务数据 */
const SEED_VERSION = 7;
const SEED_VERSION_KEY = 'erp_mock_seed_version';

/** 本地数据库类型：集合名 -> 记录数组 */
type MockDb = Record<string, any[]>;

/** 当前内存数据库 */
let db: MockDb = loadDb();

/**
 * 从 localStorage 加载数据库；没有数据时用种子数据初始化。
 * @returns 完整的本地数据库对象
 */
function loadDb(): MockDb {
  const seed = createSeedDb();
  try {
    const raw = localStorage.getItem(DB_KEY);
    if (raw) {
      const stored = JSON.parse(raw) as MockDb;
      let ver = 0;
      try { ver = Number(localStorage.getItem(SEED_VERSION_KEY) || 0); } catch { /* 忽略 */ }
      if (ver < SEED_VERSION) {
        // 迁移：只补齐「缺失或仍为空」的集合，绝不覆盖用户已经写入的业务数据
        let added = 0;
        for (const key of Object.keys(seed)) {
          if (!Array.isArray(stored[key]) || stored[key].length === 0) {
            stored[key] = clone(seed[key]);
            added++;
          }
        }
        // v6：人事行政「部门」页从组织集合中独立出来，补入部门基准行（按编码判重，不覆盖用户数据）
        if (Array.isArray(stored.systemOrgs) && Array.isArray(seed.systemOrgs)) {
          for (const row of seed.systemOrgs.filter((r: any) => r.orgType === 'DEPT')) {
            if (!stored.systemOrgs.some((r: any) => r.code === row.code)) stored.systemOrgs.push(clone(row));
          }
        }
        try { localStorage.setItem(SEED_VERSION_KEY, String(SEED_VERSION)); } catch { /* 忽略 */ }
        saveDb(stored);
        if (added) console.info(`[Mock数据] 已补齐 ${added} 个业务集合的真实种子数据（v${SEED_VERSION}）`);
      }
      return stored;
    }
  } catch { /* 存储不可用时退回种子数据 */ }
  try { localStorage.setItem(SEED_VERSION_KEY, String(SEED_VERSION)); } catch { /* 忽略 */ }
  saveDb(seed);
  return seed;
}

/**
 * 保存数据库到 localStorage，保证刷新后数据仍在。
 * @param data 要保存的数据库
 */
function saveDb(data: MockDb = db): void {
  try { localStorage.setItem(DB_KEY, JSON.stringify(data)); } catch { /* 超出配额时忽略 */ }
}

/**
 * 重置演示数据（供「系统设置」页面调用）。
 * @returns 无
 */
export function resetMockDb(): void {
  db = createSeedDb();
  saveDb(db);
  try { localStorage.setItem(SEED_VERSION_KEY, String(SEED_VERSION)); } catch { /* 忽略 */ }
}

/**
 * 取集合，不存在时创建空数组。
 * @param key 集合名
 * @returns 该集合的记录数组（引用）
 */
function table(key: string): any[] {
  if (!db[key]) db[key] = [];
  return db[key];
}

/**
 * 展示层字段适配：部分集合的底表由业务代码用旧字段名写入（如 dicts 用 dictCode/name，
 * ledger 用 voucherType/productId），独立页面 Schema 用的是文档字段名（dictType/dictLabel、
 * voucherNo/productName）。这里在读取时若检测到旧格式，则改用 Schema 的真实种子展示，
 * 不修改底表数据，避免影响财务汇总等依赖旧字段的业务逻辑。
 * @param schemaKey 实体 Schema 的 key（collection 名）
 * @param rows 底表当前数据
 * @returns 适配后的展示数据
 */
function displayRows(schemaKey: string, rows: any[]): any[] {
  const schema = getEntitySchema(schemaKey);
  // 空表或没有 Schema 时原样返回：由各接口的种子初始化流程负责填充，不能在此伪造数据。
  if (!schema?.seed?.length || !rows?.length) return rows;
  // 只有「真实底表整行都没有任何 Schema 业务字段」才视为旧格式并回退种子。
  // 旧实现仅凭首个字段缺失就整表替换，会把业务过账新产生的流水/应收当成旧数据抹掉，
  // 导致「发货后库存流水看不到 SALE_OUT」这类联动断裂。
  const businessProps = schema.fields.map((f: any) => f.prop).filter((p: string) => p && p !== 'id');
  const hasRealData = rows.some((r) => businessProps.some((p: string) => r[p] !== undefined && r[p] !== null && r[p] !== ''));
  if (!hasRealData) return clone(schema.seed);
  // 真实数据原样返回：展示字段由写入方（postStock 等）在落库时补齐，避免用种子值张冠李戴。
  return rows;
}

/**
 * 生成下一主键：集合内最大 id + 1。
 * @param key 集合名
 * @returns 新的数字主键
 */
function nextId(key: string): number {
  return table(key).reduce((max, row) => Math.max(max, Number(row.id) || 0), 0) + 1;
}

/**
 * 生成业务单号。
 * @param prefix 前缀，如 SO / PO
 * @param id 单据主键
 * @returns 形如 SO20261117-0001 的单号
 */
function makeNo(prefix: string, id: number): string {
  const d = new Date();
  const day = `${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, '0')}${String(d.getDate()).padStart(2, '0')}`;
  return `${prefix}${day}-${String(id).padStart(4, '0')}`;
}

/** 当前时间字符串 */
function now(): string {
  return new Date().toISOString().slice(0, 19).replace('T', ' ');
}

/**
 * 深拷贝：避免调用方直接改到 Mock 数据库。
 * @param value 任意值
 * @returns 拷贝后的值
 */
function clone<T>(value: T): T {
  return JSON.parse(JSON.stringify(value));
}

/**
 * 数字转换：空值按 0 处理，金额统一两位小数字符串。
 * @param value 任意输入
 * @returns 两位小数字符串
 */
function money(value: any): string {
  return Number(value || 0).toFixed(2);
}

/**
 * 通用列表查询：支持 keyword / status / 精确字段 / 分页。
 * @param key 集合名
 * @param query 查询条件
 * @returns { list, total, page, pageSize, summary }
 */
function listResult(key: string, query: any = {}, summary?: any): any {
  const rows = clone(table(key));
  const keyword = String(query.keyword || query.q || '').trim().toLowerCase();
  // 这些键由上面的专用分支处理，不参与通用字段匹配；__ids 由调用方预筛（如按仓库筛产品）
  const RESERVED = new Set(['page', 'pageSize', 'keyword', 'q', 'status', 'date', 'startDate', 'endDate', 'isDeleted', 'sort', 'order', 'fields', 'module', '__ids']);
  let filtered = rows.filter((row) => {
    // 默认隐藏软删除记录；显式传 isDeleted 时可查询回收站
    const wantDeleted = query.isDeleted !== undefined && query.isDeleted !== '' ? Number(query.isDeleted) : 0;
    if (Number(row.isDeleted || 0) !== wantDeleted) return false;
    // 调用方预筛的 id 集合（产品列表按仓库筛选：仓库信息在 balance 表而不在产品表）
    if (Array.isArray(query.__ids) && !query.__ids.map(Number).includes(Number(row.id))) return false;
    // status 比较兼容字符串（TODO/草稿）与数字状态
    if (query.status !== undefined && query.status !== '') {
      const same = typeof row.status === 'string' || typeof query.status === 'string'
        ? String(row.status) === String(query.status)
        : Number(row.status) === Number(query.status);
      if (!same) return false;
    }
    // 日期区间：支持列表页「开始日期~结束日期」筛选，兼容 date:[start,end] 与 startDate/endDate 两种传法
    const range = Array.isArray(query.date) ? query.date : [];
    const start = query.startDate ?? range[0];
    const end = query.endDate ?? range[1];
    if (start || end) {
      const rawDate = row.orderDate ?? row.bizDate ?? row.voucherDate ?? row.date ?? row.createdAt;
      const day = String(rawDate ?? '').slice(0, 10);
      if (start && day < String(start).slice(0, 10)) return false;
      if (end && day > String(end).slice(0, 10)) return false;
    }
    // 通用精确匹配：原型页筛选（客户/仓库/支付/发货/产品性质等）直接按同名字段过滤，
    // 键名同时兼容 camelCase 与 snake_case，与后端 @Query 参数行为保持一致。
    for (const [key, value] of Object.entries(query || {})) {
      if (RESERVED.has(key) || value === undefined || value === null || value === '' || Array.isArray(value)) continue;
      const snake = key.replace(/([A-Z])/g, '_$1').toLowerCase();
      const raw = (row as any)[key] !== undefined ? (row as any)[key] : (row as any)[snake];
      if (raw === undefined) continue;
      if (String(raw) !== String(value) && Number(raw) !== Number(value)) return false;
    }
    if (!keyword) return true;
    return Object.values(row).some((v) => typeof v !== 'object' && String(v ?? '').toLowerCase().includes(keyword));
  });
  const page = Number(query.page || 1);
  const pageSize = Number(query.pageSize || 10);
  const total = filtered.length;
  filtered = filtered.slice((page - 1) * pageSize, page * pageSize);
  return { list: filtered, total, page, pageSize, summary: summary ?? { total } };
}

/**
 * 通用保存（新增或更新）。
 * @param key 集合名
 * @param data 记录数据，含 id 为更新
 * @returns 保存后的记录
 */
function saveRow(key: string, data: any): any {
  const row = clone(data || {});
  if (row.id) {
    const idx = table(key).findIndex((r) => Number(r.id) === Number(row.id));
    if (idx >= 0) { row.updatedAt = now(); table(key)[idx] = { ...table(key)[idx], ...row }; saveDb(); return clone(table(key)[idx]); }
  }
  row.id = nextId(key);
  row.createdAt = now();
  row.updatedAt = now();
  row.isDeleted = row.isDeleted ?? 0;
  table(key).push(row);
  saveDb();
  return clone(row);
}

/**
 * 按 id 查找记录。
 * @param key 集合名
 * @param id 主键
 * @returns 记录或 undefined
 */
function findRow(key: string, id: any): any {
  return table(key).find((r) => Number(r.id) === Number(id));
}

/**
 * 删除记录（业务上以软删除语义处理）。
 * @param key 集合名
 * @param id 主键
 * @returns 被删除的记录或空对象
 */
function removeRow(key: string, id: any): any {
  const index = table(key).findIndex((r) => Number(r.id) === Number(id));
  if (index < 0) return {};
  const [row] = table(key).splice(index, 1);
  saveDb();
  return clone(row);
}

/**
 * 库存过账后刷新低库存预警：可用量低于安全库存自动新增，恢复后自动关闭。
 * 解决预警永远是种子静态数据、出库后不产生预警的问题。
 */
function refreshAlerts(): void {
  for (const p of table('products')) {
    const safe = Number((p as any).safeQty || 20);
    const available = table('balance')
      .filter((b) => Number(b.productId) === Number(p.id))
      .reduce((s, b) => s + (Number(b.qtyOnHand) - Number(b.qtyOccupied)), 0);
    const existing = table('alerts').find((a) => Number(a.productId) === Number(p.id) && a.type === '低库存' && !Number(a.handled));
    if (available < safe) {
      const level = available < safe / 2 ? '高' : '中';
      const message = `可用量 ${available} 低于安全库存 ${safe}`;
      if (existing) Object.assign(existing, { level, message });
      else table('alerts').push({ id: nextId('alerts'), productId: p.id, productName: p.name, type: '低库存', level, message, createdAt: now(), handled: 0 });
    } else if (existing) {
      existing.handled = 1;
    }
  }
}

/**
 * 写库存流水，并同步更新余额（移动加权平均成本）。
 * 关键业务：stock_balance 的可用量 = 实物量 - 锁定量；
 *           入库增加实物量与金额，出库减少实物量，流水只追加不修改。
 * @param productId 产品 id
 * @param warehouseId 仓库 id
 * @param voucherType 流水类型（SALE_OUT / PURCHASE_IN ...）
 * @param qty 数量，正为入负为出
 * @param unitCost 单价成本
 * @param voucherId 来源单据 id
 * @returns 无
 */
function postStock(productId: number, warehouseId: number, voucherType: string, qty: number, unitCost: number, voucherId: number): void {
  let balance = table('balance').find((b) => Number(b.productId) === Number(productId) && Number(b.warehouseId) === Number(warehouseId));
  if (!balance) {
    balance = { id: nextId('balance'), productId, warehouseId, qtyOnHand: 0, qtyOccupied: 0, avgCost: 0 };
    table('balance').push(balance);
  }
  if (qty > 0) {
    // 移动加权：新成本 = (原金额 + 本次入库金额) / (原数量 + 本次入库数量)
    const oldAmount = Number(balance.qtyOnHand) * Number(balance.avgCost || 0);
    const newQty = Number(balance.qtyOnHand) + qty;
    balance.avgCost = newQty > 0 ? Number(((oldAmount + qty * (unitCost || Number(balance.avgCost || 0))) / newQty).toFixed(4)) : 0;
  }
  balance.qtyOnHand = Number((Number(balance.qtyOnHand) + qty).toFixed(3));
  const ledgerId = nextId('ledger');
  // 展示字段在落库时补齐：库存流水页直接展示这些字段，缺字段会被 displayRows 判为旧格式而回退种子。
  const typeName: Record<string, string> = { SALE_OUT: '销售出库', SALE_RETURN: '销售退货', PURCHASE_IN: '采购入库', PURCHASE_RETURN: '采购退货', ADJUST: '库存调整', TRANSFER_IN: '调拨入库', TRANSFER_OUT: '调拨出库', FINISH_IN: '完工入库', PRODUCTION_PICK: '生产领料', PRODUCTION_RETURN: '生产退料', ASSEMBLY_IN: '组装入库', ASSEMBLY_OUT: '组装出库' };
  table('ledger').push({
    id: ledgerId,
    voucherNo: `LS${now().slice(0, 10).replace(/-/g, '')}-${String(ledgerId).padStart(4, '0')}`,
    productId, productName: findRow('products', productId)?.name || `产品${productId}`,
    warehouseId, warehouseName: findRow('warehouses', warehouseId)?.name || `仓库${warehouseId}`,
    voucherType, voucherTypeName: typeName[voucherType] || voucherType, voucherId,
    qtyIn: qty > 0 ? qty : 0, qtyOut: qty < 0 ? -qty : 0, cost: Number((unitCost || balance.avgCost || 0).toFixed(4)),
    balanceQty: balance.qtyOnHand, occurredAt: now(),
  });
  refreshAlerts();
  saveDb();
}

/**
 * 生成会计凭证：借贷必须平衡，来源单据与凭证一一对应。
 * @param summary 摘要
 * @param entries 分录数组 [{ subjectId, debit, credit }]
 * @param sourceType 来源类型
 * @param sourceId 来源单据 id
 * @returns 新建凭证
 */
/**
 * 会计科目编码常量：分录一律按科目编码取 id，避免硬编码数字随科目表调整而错位。
 */
const SUBJECT = {
  CASH: '1001',        // 库存现金
  BANK: '1002',        // 银行存款
  AR: '1122',          // 应收账款
  RAW_MATERIAL: '1403',// 原材料
  GOODS: '1405',       // 库存商品
  ACCUM_DEPR: '1602',  // 累计折旧
  AP: '2202',          // 应付账款
  ACCRUED_AP: '2209',  // 应付暂估
  VAT: '2221',         // 应交税费（销项税额）
  MFG_EXPENSE: '5101', // 制造费用
  REVENUE: '6001',     // 主营业务收入
  COGS: '6401',        // 主营业务成本
  SELL_EXPENSE: '6601',// 销售费用
  ADMIN_EXPENSE: '6602',// 管理费用
} as const;

/**
 * 按科目编码取科目 id；科目不存在时返回 0（分录仍会写入，便于用户补建科目）。
 * @param code 科目编码（如 1122）
 * @returns 科目 id
 */
function subjectId(code: string): number {
  const s = table('subjects').find((x: any) => x.code === code);
  return s ? Number(s.id) : 0;
}

/**
 * 取默认增值税率：优先系统参数 DEFAULT_TAX_RATE，其次 13%。
 * @returns 税率小数（0.13）
 */
function defaultTaxRate(): number {
  try {
    const cfg = table('configs').find((c: any) => c.configKey === 'DEFAULT_TAX_RATE' || c.cfgKey === 'DEFAULT_TAX_RATE');
    const raw = String(cfg?.configValue ?? cfg?.cfgValue ?? '13%').replace('%', '').trim();
    const n = Number(raw);
    return Number.isFinite(n) && n > 0 ? n / 100 : 0.13;
  } catch { return 0.13; }
}

/**
 * 含税金额价税分离：返回不含税收入与销项税额。
 * @param gross 含税金额
 * @param rate 税率小数
 * @returns { net: 不含税额, tax: 税额 }
 */
function splitTax(gross: number, rate: number): { net: number; tax: number } {
  const g = Number(money(gross));
  const net = Number(money(g / (1 + rate)));
  return { net, tax: Number(money(g - net)) };
}

/**
 * 按业务语义生成分录条目（对应《企业会计准则》ERP 自动化分录规则）：
 * - 费用支出：借 费用科目（管理/销售/制造） / 贷 银行存款
 * - 折旧计提：借 制造费用或管理费用 / 贷 累计折旧
 * - 收付款：借 银行存款 / 贷 应收账款（收）；借 应付账款 / 贷 银行存款（付）
 * - 资金转账：借 银行存款 / 贷 银行存款
 * - 收入确认：借 银行存款或应收账款 / 贷 主营业务收入
 * @param collection 集合名（用于识别业务语义）
 * @param amount 金额
 * @param row 单据行
 * @param data 附加参数
 * @returns 分录数组（借贷平衡），无匹配语义时返回空数组
 */
function buildVoucherEntries(collection: string, amount: number, row: any, data: any): any[] {
  const amt = Number(money(amount));
  if (amt <= 0) return [];
  const c = String(collection).toLowerCase();

  // 折旧：借 制造费用/管理费用，贷 累计折旧
  if (/depreciat/i.test(c)) {
    const toMfg = /mfg|manufactur|生产|制造/i.test(`${c}${row?.useType || ''}${row?.deptName || ''}`);
    return [
      { subjectId: subjectId(toMfg ? SUBJECT.MFG_EXPENSE : SUBJECT.ADMIN_EXPENSE), debit: amt, credit: 0, summary: toMfg ? '制造费用' : '管理费用' },
      { subjectId: subjectId(SUBJECT.ACCUM_DEPR), debit: 0, credit: amt, summary: '累计折旧' },
    ];
  }
  // 费用支出：借 费用科目，贷 银行存款
  if (/expense|expenses|费用/.test(c)) {
    const sell = /sell|sales|market|销售|营销/.test(c);
    const mfg = /mfg|manufactur|生产/.test(c);
    const code = mfg ? SUBJECT.MFG_EXPENSE : sell ? SUBJECT.SELL_EXPENSE : SUBJECT.ADMIN_EXPENSE;
    const name = mfg ? '制造费用' : sell ? '销售费用' : '管理费用';
    return [
      { subjectId: subjectId(code), debit: amt, credit: 0, summary: name },
      { subjectId: subjectId(SUBJECT.BANK), debit: 0, credit: amt, summary: '银行存款' },
    ];
  }
  // 付款：借 应付账款，贷 银行存款
  if (/paymentout|paymentsout|payment_?out|付款/i.test(c)) {
    return [
      { subjectId: subjectId(SUBJECT.AP), debit: amt, credit: 0, summary: '应付账款' },
      { subjectId: subjectId(SUBJECT.BANK), debit: 0, credit: amt, summary: '银行存款' },
    ];
  }
  // 收款：借 银行存款，贷 应收账款
  if (/paymentin|paymentsin|payment_?in|收款/i.test(c)) {
    return [
      { subjectId: subjectId(SUBJECT.BANK), debit: amt, credit: 0, summary: '银行存款' },
      { subjectId: subjectId(SUBJECT.AR), debit: 0, credit: amt, summary: '应收账款' },
    ];
  }
  // 资金转账：借 银行存款，贷 银行存款
  if (/transfer|转账/i.test(c)) {
    return [
      { subjectId: subjectId(SUBJECT.BANK), debit: amt, credit: 0, summary: '银行存款（转出）' },
      { subjectId: subjectId(SUBJECT.BANK), debit: 0, credit: amt, summary: '银行存款（转入）' },
    ];
  }
  // 收入确认：借 应收账款（未收）或 银行存款（已收），贷 主营业务收入
  if (/income|incomes|收入/.test(c)) {
    const received = Number(data?.paidAmount ?? row?.paidAmount ?? 0);
    const unpaid = Number(money(amt - received));
    const { net, tax } = splitTax(amt, defaultTaxRate());
    const entries: any[] = [];
    if (received > 0) entries.push({ subjectId: subjectId(SUBJECT.BANK), debit: money(received), credit: 0, summary: '银行存款' });
    if (unpaid > 0) entries.push({ subjectId: subjectId(SUBJECT.AR), debit: unpaid, credit: 0, summary: '应收账款' });
    // 含税收入必须价税分离：贷方 = 不含税收入 + 销项税额，否则借贷不平导致凭证生成失败
    entries.push({ subjectId: subjectId(SUBJECT.REVENUE), debit: 0, credit: net, summary: '主营业务收入' });
    if (tax > 0) entries.push({ subjectId: subjectId(SUBJECT.VAT), debit: 0, credit: tax, summary: '销项税额' });
    return entries;
  }
  // 工资计提：借 制造费用（计入成本），贷 应付职工薪酬（此处用应交税费近似不准确，改为其他应付款）
  if (/salary|payroll|工资/.test(c)) {
    return [
      { subjectId: subjectId(SUBJECT.MFG_EXPENSE), debit: amt, credit: 0, summary: '制造费用（工资）' },
      { subjectId: subjectId(SUBJECT.AP), debit: 0, credit: amt, summary: '应付职工薪酬' },
    ];
  }
  // 兜底：按费用/收入二分，保持借贷平衡
  const isExpense = /cost|out|支出|成本/.test(c);
  return isExpense
    ? [
      { subjectId: subjectId(SUBJECT.ADMIN_EXPENSE), debit: amt, credit: 0, summary: '管理费用' },
      { subjectId: subjectId(SUBJECT.BANK), debit: 0, credit: amt, summary: '银行存款' },
    ]
    : [
      { subjectId: subjectId(SUBJECT.AR), debit: amt, credit: 0, summary: '应收账款' },
      { subjectId: subjectId(SUBJECT.REVENUE), debit: 0, credit: amt, summary: '主营业务收入' },
    ];
}

/**
 * 生成会计凭证：借贷必须平衡，平衡时返回凭证，不平衡直接抛错（防止错账落库）。
 * @param summary 摘要
 * @param entries 分录数组 [{ subjectId, debit, credit }]
 * @param sourceType 来源类型
 * @param sourceId 来源单据 id
 * @returns 新建凭证
 */
function makeVoucher(summary: string, entries: any[], sourceType: string, sourceId: number): any {
  const debit = Number(money(entries.reduce((sum, e) => sum + Number(e.debit || 0), 0)));
  const credit = Number(money(entries.reduce((sum, e) => sum + Number(e.credit || 0), 0)));
  if (Math.abs(debit - credit) > 0.01) {
    throw new Error(`凭证「${summary}」借贷不平衡：借 ${debit} / 贷 ${credit}`);
  }
  const voucher: any = {
    id: nextId('vouchers'), voucherNo: makeNo('VCH', nextId('vouchers')), voucherDate: now().slice(0, 10),
    sourceType, sourceId, status: 1, summary,
    totalDebit: debit, totalCredit: credit,
    createdAt: now(),
  };
  table('vouchers').push(voucher);
  for (const entry of entries) {
    table('voucherEntries').push({ id: nextId('voucherEntries'), voucherId: voucher.id, ...entry });
  }
  saveDb();
  return clone(voucher);
}

/** 初始化种子数据：让每个菜单打开都有内容 */
function createSeedDb(): MockDb {
  const empty: MockDb = {};
  const put = (key: string, rows: any[]) => { empty[key] = rows; };

  put('users', [
    { id: 1, username: 'admin', password: 'admin123', realName: '系统管理员', deptId: 1, status: 1, permissions: ['*'] },
    { id: 2, username: 'sales', password: '123456', realName: '张销售', deptId: 2, status: 1, permissions: ['sales:*', 'inventory:balance:view'] },
    { id: 3, username: 'buyer', password: '123456', realName: '李采购', deptId: 3, status: 1, permissions: ['purchase:*'] },
    { id: 4, username: 'store', password: '123456', realName: '王仓管', deptId: 4, status: 1, permissions: ['inventory:*'] },
    { id: 5, username: 'finance', password: '123456', realName: '赵财务', deptId: 5, status: 1, permissions: ['finance:*'] },
  ]);
  put('roles', [{ id: 1, code: 'ADMIN', name: '超级管理员' }, { id: 2, code: 'SALES', name: '销售专员' }, { id: 3, code: 'FINANCE', name: '财务专员' }]);
  put('permissions', [
    { id: 1, code: 'sales:order:view', name: '查看销售单', type: 1 }, { id: 2, code: 'sales:order:create', name: '新建销售单', type: 2 },
    { id: 3, code: 'purchase:order:view', name: '查看采购单', type: 1 }, { id: 4, code: 'inventory:product:view', name: '查看产品', type: 1 },
    { id: 5, code: 'finance:voucher:view', name: '查看凭证', type: 1 }, { id: 6, code: 'print:template:edit', name: '编辑打印模板', type: 2 },
    { id: 7, code: 'ai:chat', name: 'AI 助理', type: 2 },
  ]);
  put('orgs', [{ id: 1, name: 'LEO科技有限公司', type: 'COMPANY' }, { id: 2, name: '销售部', type: 'DEPT' }, { id: 3, name: '采购部', type: 'DEPT' }, { id: 4, name: '仓储部', type: 'DEPT' }, { id: 5, name: '财务部', type: 'DEPT' }]);
  const dictRows: any[] = [];
  const dictData: Record<string, string[]> = {
    unit: ['个', '件', '箱', '千克', '米', '包'], product_nature: ['标准产品', '多规格产品', '序列号产品', '服务型'],
    pay_type: ['现金', '银行转账', '微信', '支付宝', '月结'], invoice_type: ['增值税专用发票', '普通发票'],
    department: ['销售部', '采购部', '仓储部', '财务部'], priority: ['高', '中', '低'],
  };
  Object.entries(dictData).forEach(([code, values]) => values.forEach((name, i) => dictRows.push({ id: dictRows.length + 1, dictCode: code, code: String(i + 1), name, sort: i + 1 })));
  put('dicts', dictRows);
  put('configs', [
    { id: 1, cfgKey: 'company_name', cfgValue: 'LEO科技有限公司' }, { id: 2, cfgKey: 'tax_rate', cfgValue: '0.13' },
    { id: 3, cfgKey: 'currency', cfgValue: 'CNY' }, { id: 4, cfgKey: 'stock_negative_allowed', cfgValue: '0' },
    { id: 5, cfgKey: 'ai_model', cfgValue: 'local-rule' },
    { id: 6, cfgKey: 'security.mask.enabled', cfgValue: '1' },
  ]);
  put('notifies', [
    { id: 1, title: '销售单 SO 待审批', content: '销售单 SO20261117-0001 金额超过 1 万，请及时处理', isRead: 0, createdAt: now() },
    { id: 2, title: '库存预警', content: '办公用品 A4 复印纸可用量低于安全库存', isRead: 0, createdAt: now() },
    { id: 3, title: '应收逾期提醒', content: '客户「蓝天实业」有一笔应收已逾期 7 天', isRead: 1, createdAt: now() },
  ]);
  put('auditLogs', [{ id: 1, module: 'SALE', action: 'CREATE', bizId: 1, detail: '创建销售单', operator: '张销售', createdAt: now() }]);
  put('loginLogs', [{ id: 1, username: 'admin', ip: '127.0.0.1', result: '成功', createdAt: now() }]);

  put('categories', [{ id: 1, name: '办公用品', code: 'OFFICE' }, { id: 2, name: '数码电子', code: 'DIGITAL' }, { id: 3, name: '包装材料', code: 'PACK' }]);
  put('brands', [{ id: 1, name: '得力' }, { id: 2, name: '晨光' }, { id: 3, name: '华为' }]);
  put('units', [{ id: 1, name: '个' }, { id: 2, name: '件' }, { id: 3, name: '箱' }, { id: 4, name: '千克' }]);
  put('warehouses', [{ id: 1, name: '主仓库', code: 'WH01', address: '深圳市南山区科技园', isDefault: 1 }, { id: 2, name: '深圳分仓', code: 'WH02', address: '深圳市福田区', isDefault: 0 }]);
  const productNames = ['A4 复印纸', '中性笔 0.5mm', '得力订书机', '无线鼠标', 'USB-C 扩展坞', '快递纸箱', '华为耳机', '办公文件夹'];
  const products = productNames.map((name, i) => ({
    id: i + 1, name, code: `P${String(i + 1).padStart(4, '0')}`, barcode: `6901234567${String(i).padStart(3, '0')}`,
    categoryId: i < 3 ? 1 : i < 6 ? 2 : 3, brandId: (i % 3) + 1, unitId: (i % 4) + 1,
    cost: [18, 2.5, 22, 45, 88, 3.2, 199, 12][i], price: [26, 4, 32, 69, 129, 5, 299, 18][i],
    safeQty: [50, 200, 20, 15, 20, 100, 10, 40][i],
    type: i === 3 ? 2 : 1, tracking: i === 6 ? 1 : 0, isActive: 1, image: '', totalQty: 0,
    // 多规格产品：颜色 × 尺码笛卡尔积 4 行，每行库存/成本/价格独立（原型展开效果）
    variants: i === 3 ? [
      { id: 11, skuCode: 'M-BLACK-S', attributes: { 颜色: '黑色', 尺码: 'S' }, price: 69, cost: 45, qty: 2 },
      { id: 12, skuCode: 'M-BLACK-M', attributes: { 颜色: '黑色', 尺码: 'M' }, price: 69, cost: 45, qty: 3 },
      { id: 13, skuCode: 'M-WHITE-S', attributes: { 颜色: '白色', 尺码: 'S' }, price: 72, cost: 47, qty: 1 },
      { id: 14, skuCode: 'M-WHITE-M', attributes: { 颜色: '白色', 尺码: 'M' }, price: 72, cost: 47, qty: 2 },
    ] : [],
  }));
  put('products', products);
  put('batches', [{ id: 1, productId: 1, batchNo: 'B20261101', produceDate: '2026-11-01', expireDate: '2027-11-01' }]);
  put('serials', [{ id: 1, productId: 7, serialNo: 'IMEI862000001', status: 1 }]);
  const initialQty = [120, 500, 45, 8, 3, 300, 20, 80];
  put('balance', products.map((p, i) => ({
    id: i + 1, productId: p.id, warehouseId: 1, qtyOnHand: initialQty[i], qtyOccupied: i === 3 ? 2 : 0, avgCost: p.cost,
  })));
  put('ledger', products.slice(0, 5).map((p, i) => ({
    id: i + 1, productId: p.id, warehouseId: 1, voucherType: 'PURCHASE_IN', voucherId: i + 1,
    qtyIn: initialQty[i], qtyOut: 0, cost: p.cost, balanceQty: initialQty[i], occurredAt: now(),
  })));
  put('alerts', [
    { id: 1, productId: 5, productName: 'USB-C 扩展坞', type: '低库存', level: '高', message: '可用量 3 低于安全库存 20', createdAt: now(), handled: 0 },
    { id: 2, productId: 4, productName: '无线鼠标', type: '低库存', level: '中', message: '可用量 6 低于安全库存 15', createdAt: now(), handled: 0 },
    { id: 3, productId: 1, productName: 'A4 复印纸', type: '临期', level: '低', message: '批次 B20261101 距离效期 12 个月', createdAt: now(), handled: 0 },
  ]);

  put('customers', [
    { id: 1, name: '蓝天实业有限公司', code: 'C001', contact: '陈经理', phone: '13800138001', level: 'A', creditLimit: 50000, receivable: 12800 },
    { id: 2, name: '深圳好再来商贸', code: 'C002', contact: '刘老板', phone: '13800138002', level: 'B', creditLimit: 20000, receivable: 3200 },
    { id: 3, name: '广州云科技有限公司', code: 'C003', contact: '周总', phone: '13800138003', level: 'A', creditLimit: 80000, receivable: 0 },
  ]);
  put('suppliers', [
    { id: 1, name: '得力集团深圳分公司', code: 'S001', contact: '孙经理', phone: '13900139001', payTerm: 30 },
    { id: 2, name: '华强北电子批发', code: 'S002', contact: '吴老板', phone: '13900139002', payTerm: 15 },
  ]);
  put('saleOrders', [
    { id: 1, orderNo: 'SO20261116-0001', customerId: 1, customerName: '蓝天实业有限公司', warehouseId: 1, orderDate: '2026-11-16 09:30:00', status: 4, payStatus: 1, shipStatus: 2, totalAmount: 12800, paidAmount: 8000, lines: [{ productId: 1, productName: 'A4 复印纸', qty: 100, unitPrice: 26, amount: 2600 }, { productId: 7, productName: '华为耳机', qty: 34, unitPrice: 300, amount: 10200 }] },
    { id: 2, orderNo: 'SO20261117-0002', customerId: 2, customerName: '深圳好再来商贸', warehouseId: 1, orderDate: '2026-11-17 10:12:00', status: 2, payStatus: 0, shipStatus: 0, totalAmount: 3200, paidAmount: 0, lines: [{ productId: 4, productName: '无线鼠标', qty: 20, unitPrice: 160, amount: 3200 }] },
    { id: 3, orderNo: 'SO20261117-0003', customerId: 3, customerName: '广州云科技有限公司', warehouseId: 1, orderDate: '2026-11-17 11:40:00', status: 0, payStatus: 0, shipStatus: 0, totalAmount: 780, paidAmount: 0, lines: [{ productId: 5, productName: 'USB-C 扩展坞', qty: 6, unitPrice: 130, amount: 780 }] },
  ]);
  put('purchaseOrders', [
    { id: 1, orderNo: 'PO20261115-0001', supplierId: 1, supplierName: '得力集团深圳分公司', warehouseId: 1, orderDate: '2026-11-15 14:00:00', status: 4, totalAmount: 5600, receivedQty: 200, lines: [{ productId: 1, qty: 200, unitPrice: 28, amount: 5600 }] },
    { id: 2, orderNo: 'PO20261117-0002', supplierId: 2, supplierName: '华强北电子批发', warehouseId: 1, orderDate: '2026-11-17 09:00:00', status: 1, totalAmount: 4500, receivedQty: 0, lines: [{ productId: 5, qty: 50, unitPrice: 90, amount: 4500 }] },
  ]);

  // 会计科目表：按《企业会计准则》科目编码，覆盖 ERP 全部自动化分录所需科目
  // direction: 1=借方余额(资产/费用) 2=贷方余额(负债/收入)
  put('subjects', [
    { id: 1, code: '1001', name: '库存现金', category: '资产', direction: 1 },
    { id: 2, code: '1002', name: '银行存款', category: '资产', direction: 1 },
    { id: 3, code: '1122', name: '应收账款', category: '资产', direction: 1 },
    { id: 4, code: '1403', name: '原材料', category: '资产', direction: 1 },
    { id: 5, code: '1405', name: '库存商品', category: '资产', direction: 1 },
    { id: 6, code: '1602', name: '累计折旧', category: '资产', direction: 2 },
    { id: 7, code: '2202', name: '应付账款', category: '负债', direction: 2 },
    { id: 8, code: '2209', name: '应付暂估', category: '负债', direction: 2 },
    { id: 9, code: '2221', name: '应交税费', category: '负债', direction: 2 },
    { id: 10, code: '5101', name: '制造费用', category: '成本', direction: 1 },
    { id: 11, code: '6001', name: '主营业务收入', category: '损益', direction: 2 },
    { id: 12, code: '6401', name: '主营业务成本', category: '损益', direction: 1 },
    { id: 13, code: '6601', name: '销售费用', category: '损益', direction: 1 },
    { id: 14, code: '6602', name: '管理费用', category: '损益', direction: 1 },
  ]);
  put('accounts', [{ id: 1, code: 'CASH', name: '现金账户', type: 'CASH', balance: 12000 }, { id: 2, code: 'BANK', name: '招商银行', type: 'BANK', balance: 258000 }]);
  put('vouchers', [
    { id: 1, voucherNo: 'V20261116-0001', voucherDate: '2026-11-16', sourceType: 'SALE', sourceId: 1, status: 1, summary: '销售确认', totalDebit: 12800, totalCredit: 12800 },
  ]);
  put('voucherEntries', [
    { id: 1, voucherId: 1, subjectId: 3, debit: 12800, credit: 0, summary: '销售未收款' },
    { id: 2, voucherId: 1, subjectId: 11, credit: 12800, debit: 0, summary: '主营业务收入' },
  ]);
  put('receivables', [{ id: 1, customerId: 1, customerName: '蓝天实业有限公司', sourceType: 'SALE', sourceId: 1, amount: 12800, receivedAmount: 8000, dueDate: '2026-12-16', status: 1 }]);
  put('payables', [{ id: 1, supplierId: 1, supplierName: '得力集团深圳分公司', sourceType: 'PURCHASE', sourceId: 1, amount: 5600, paidAmount: 0, dueDate: '2026-12-15', status: 1 }]);
  put('payments', [
    { id: 1, payNo: 'SK20261116-0001', type: 'IN', amount: 8000, receivableId: 1, payMethod: '银行转账', payDate: '2026-11-16', status: 1, remark: '蓝天实业部分货款' },
    { id: 2, payNo: 'FK20261117-0001', type: 'OUT', amount: 2000, payableId: 1, payMethod: '银行转账', payDate: '2026-11-17', status: 1, remark: '得力集团部分货款' },
  ]);
  put('periods', [{ id: 1, period: '2026-11', closed: 0 }]);

  put('printTemplates', [
    { id: 1, code: 'SALE_ORDER', name: 'A4 销售单模板', bizType: 'SALE_ORDER', paper: 'A4', scope: 'TENANT', isDefault: 1, version: 1, isActive: 1, schema: '{}' },
    { id: 2, code: 'PURCHASE_IN', name: 'A4 采购入库单', bizType: 'PURCHASE_IN', paper: 'A4', scope: 'TENANT', isDefault: 1, version: 1, isActive: 1, schema: '{}' },
    { id: 3, code: 'LABEL', name: '58mm 条码标签', bizType: 'LABEL', paper: '58mm', scope: 'TENANT', isDefault: 1, version: 1, isActive: 1, schema: '{}' },
  ]);
  put('printRecords', [
    { id: 1, bizType: 'SALE_ORDER', bizNo: 'SO20261116-0001', templateName: 'A4 销售单模板', copies: 2, channel: 'SERVER_PDF', printedBy: '张销售', printedAt: '2026-11-16 10:20:00', status: 1 },
    { id: 2, bizType: 'PURCHASE_IN', bizNo: 'PO20261115-0001', templateName: 'A4 采购入库单', copies: 1, channel: 'SILENT', printedBy: '王仓管', printedAt: '2026-11-15 16:05:00', status: 1 },
  ]);
  put('aiPrompts', [
    { id: 1, code: 'copilot', name: 'AI 助理', content: '你是企业 ERP 助手，请用简洁中文回答。数据：{{data}}', model: 'local-rule', temperature: 0.2, version: 1, isActive: 1 },
    { id: 2, code: 'forecast', name: '补货预测', content: '基于销量与库存预测未来 {{horizon}} 期需求，低于安全库存才建议采购。数据：{{data}}', model: 'local-rule', temperature: 0.2, version: 1, isActive: 1 },
  ]);
  put('aiAudits', [
    { id: 1, capability: 'ai.copilot', userId: 1, model: 'local-rule', promptTokens: 0, completionTokens: 0, latencyMs: 18, accepted: 1, fallback: 1, request: '如何核销应收？', response: '在财务-收款单中确认后自动核销应收', createdAt: '2026-11-17 09:12:00' },
    { id: 2, capability: 'ai.forecast', userId: 1, model: 'local-rule', promptTokens: 0, completionTokens: 0, latencyMs: 24, accepted: 0, fallback: 1, request: '预测12月补货', response: '建议补货 A4 复印纸 80 箱', createdAt: '2026-11-16 15:40:00' },
  ]);
  put('forecastResults', [
    { id: 1, productCode: 'P0001', productName: 'A4 复印纸', period: '2026-12', predictQty: 180, suggestPurchaseQty: 80, model: 'local-rule', reason: '12月办公采购旺季，历史销量上行', createdAt: '2026-11-16 15:40:00' },
    { id: 2, productCode: 'P0005', productName: 'USB-C 扩展坞', period: '2026-12', predictQty: 12, suggestPurchaseQty: 20, model: 'local-rule', reason: '当前可用量低于安全库存', createdAt: '2026-11-16 15:40:00' },
  ]);
  put('knowledgeDocs', [{ id: 1, title: 'ERP 操作手册', content: '销售流程：新建销售单、提交、确认、发货、收款、生成凭证。', chunkCount: 3, status: 1 }]);

  put('bpmDefs', [
    { id: 1, code: 'SALE_ORDER', name: '销售单审批', remark: '金额 > 10000 走总监审批', status: 1 },
    { id: 2, code: 'PURCHASE_ORDER', name: '采购单审批', remark: '金额 > 5000 走总监审批', status: 1 },
    { id: 3, code: 'LEAVE', name: '请假审批', remark: '3 天以上走人事审批', status: 1 },
  ]);
  put('bpmTasks', [
    { id: 1, bizType: 'SALE_ORDER', bizId: 2, bizNo: 'SO20261117-0002', nodeName: '销售总监审批', amount: 3200, status: 'TODO', createdAt: now() },
    { id: 2, bizType: 'PURCHASE_ORDER', bizId: 2, bizNo: 'PO20261117-0002', nodeName: '采购总监审批', amount: 4500, status: 'TODO', createdAt: now() },
  ]);
  put('bpmDone', [
    { id: 1, bizType: 'SALE_ORDER', bizId: 1, bizNo: 'SO20261116-0001', nodeName: '销售总监审批', amount: 12800, status: 'APPROVED', comment: '金额较大，同意发货', handledAt: '2026-11-16 11:00:00' },
  ]);
  put('bpmInstances', [{ id: 1, bizType: 'SALE_ORDER', bizNo: 'SO20261116-0001', status: 'APPROVED', currentNode: '完成', createdAt: now() }]);
  put('bpmLogs', [{ id: 1, instanceId: 1, nodeName: '销售主管', action: 'APPROVE', comment: '同意', createdAt: now() }]);
  put('bpmDelegations', [
    { id: 1, fromUser: '李采购', toUser: '王经理', bizType: 'PURCHASE_ORDER', reason: '出差期间代为审批', startDate: '2026-11-20', endDate: '2026-11-25', status: 1 },
  ]);

  put('biReports', [
    { id: 1, code: 'SALE_TREND', name: '月度销售额', dims: [{ name: '月份', code: 'month' }], measures: [{ name: '销售额', code: 'saleAmount' }, { name: '毛利', code: 'profit' }], dimensions: '月份', metrics: '销售额,毛利' },
    { id: 2, code: 'CUSTOMER_SALE', name: '客户销售排行', dims: [{ name: '客户', code: 'customer' }], measures: [{ name: '销售额', code: 'saleAmount' }, { name: '已收款', code: 'paidAmount' }], dimensions: '客户', metrics: '销售额,已收款' },
    { id: 3, code: 'STOCK_TURNOVER', name: '产品库存量', dims: [{ name: '产品', code: 'product' }], measures: [{ name: '库存量', code: 'stockQty' }], dimensions: '产品', metrics: '库存量' },
  ]);
  put('biSubscriptions', [
    { id: 1, reportName: '销售趋势', channel: '邮件', receiver: 'sales@leo.com', frequency: '每周一', enabled: 1 },
  ]);
  put('leads', [
    { id: 1, name: '陈先生', company: '蓝天实业', phone: '13800138001', score: 86, status: 'FOLLOWING' },
    { id: 2, name: '林小姐', company: '云科技', phone: '13800138003', score: 72, status: 'NEW' },
  ]);
  put('opportunities', [{ id: 1, name: '年度办公用品采购', amount: 120000, stage: '方案报价', probability: 60 }]);
  put('follows', [
    { id: 1, leadId: 1, contact: '陈先生', way: '电话', content: '确认年度办公用品采购预算 12 万，下周提供报价', nextDate: '2026-11-24', owner: '张销售', createdAt: '2026-11-17 14:00:00' },
    { id: 2, leadId: 2, contact: '林小姐', way: '微信', content: '对云科技门禁系统方案感兴趣，待发资料', nextDate: '2026-11-22', owner: '张销售', createdAt: '2026-11-16 10:30:00' },
  ]);
  put('quotations', [{ id: 1, quoteNo: 'QT20261110-0001', customerName: '蓝天实业', totalAmount: 12800, status: '有效' }]);

  put('putaways', [
    { id: 1, productId: 5, productName: 'USB-C 扩展坞', qty: 20, warehouseId: 1, location: 'A-02-01', batchNo: 'B20261115', status: '已上架', operator: '王仓管', createdAt: '2026-11-15 11:00:00' },
  ]);
  put('waves', [{ id: 1, waveNo: 'WV20261117-0001', warehouseId: 1, status: '待拣货' }]);
  put('waveLines', [{ id: 1, waveId: 1, productName: 'A4 复印纸', planQty: 10, pickedQty: 0 }]);
  put('stocktakes', [{ id: 1, takeNo: 'ST20261117-0001', warehouseId: 1, status: '进行中' }]);
  put('stocktakeLines', [
    { id: 1, stocktakeId: 1, productId: 1, productName: 'A4 复印纸', bookQty: 120, realQty: 120, diffQty: 0 },
    { id: 2, stocktakeId: 1, productId: 5, productName: 'USB-C 扩展坞', bookQty: 3, realQty: 2, diffQty: -1 },
  ]);
  put('transfers', [
    { id: 1, transferNo: 'TR20261116-0001', fromWarehouse: '主仓库', toWarehouse: '深圳分仓', productName: '无线鼠标', qty: 10, status: '已调拨', operator: '王仓管', createdAt: '2026-11-16 14:20:00' },
  ]);
  put('crossdocks', [
    { id: 1, dockNo: 'CD20261117-0001', supplierName: '华强北电子批发', productName: 'USB-C 扩展坞', qty: 50, status: '待直发', createdAt: '2026-11-17 09:00:00' },
  ]);

  put('routings', [{ id: 1, productId: 1, name: '默认工艺', steps: '下料→组装→检验' }]);
  put('mrpRuns', [
    { id: 1, runNo: 'MRP20261117-0001', planDate: '2026-11-17', source: '销售预测+安全库存', status: '已完成', resultCount: 2, createdAt: '2026-11-17 08:30:00' },
  ]);
  put('mrpSuggests', [
    { id: 1, runId: 1, productId: 1, productName: 'A4 复印纸', demandQty: 180, stockQty: 120, suggestQty: 80, supplierName: '得力集团深圳分公司', status: '待转采购单' },
    { id: 2, runId: 1, productId: 5, productName: 'USB-C 扩展坞', demandQty: 12, stockQty: 3, suggestQty: 20, supplierName: '华强北电子批发', status: '待转采购单' },
  ]);
  put('workOrders', [
    { id: 1, orderNo: 'WO20261117-0001', productId: 1, productName: 'A4 复印纸', qty: 100, planQty: 100, finishedQty: 30, producedQty: 30, status: 'REPORTED' },
    { id: 2, orderNo: 'WO20261118-0002', productId: 4, productName: '无线鼠标', qty: 60, planQty: 60, finishedQty: 0, producedQty: 0, status: 'ISSUED' },
  ]);
  put('mesReports', [
    { id: 1, workOrderNo: 'WO20261117-0001', productName: 'A4 复印纸', reportQty: 30, ngQty: 1, worker: '李师傅', reportTime: '2026-11-17 15:20:00', status: '已报工' },
  ]);
  put('qc', [{ id: 1, qcNo: 'QC20261117-0001', checkQty: 100, ngQty: 2, aiAdvice: '不良率 2%，建议复核来料批次' }]);
  put('equipments', [{ id: 1, code: 'EQ001', name: '贴片机', status: '正常', nextMaintain: '2026-12-01' }]);

  put('stores', [{ id: 1, name: '官方商城', platform: 'SELF', status: 1 }]);
  put('goodsMaps', [
    { id: 1, shopId: 1, platformSku: 'JD-100023', productId: 1, productName: 'A4 复印纸', price: 29, status: 1 },
    { id: 2, shopId: 1, platformSku: 'JD-100078', productId: 7, productName: '华为耳机', price: 319, status: 1 },
  ]);
  put('shopOrders', [
    { id: 1, platformOrderNo: 'PL20261117001', buyer: '王先生', productName: 'A4 复印纸', amount: 260, status: '待发货', shopName: '官方商城' },
    { id: 2, platformOrderNo: 'PL20261117002', buyer: '李女士', productName: '华为耳机', amount: 319, status: '待发货', shopName: '官方商城' },
  ]);

  put('viewConfigs', [
    { id: 1, name: '我的销售看板', module: 'sales', config: '{"columns":["orderNo","customerName","totalAmount","status"]}', isDefault: 1, createdBy: '张销售' },
  ]);
  put('importTasks', [
    { id: 1, name: '客户资料导入', entity: 'customers', fileName: 'customers_20261116.xlsx', total: 120, success: 118, fail: 2, status: '已完成', createdAt: '2026-11-16 10:00:00' },
  ]);
  put('importErrors', [
    { id: 1, taskId: 1, row: 15, field: 'phone', value: '138', reason: '手机号格式不正确' },
    { id: 2, taskId: 1, row: 42, field: 'name', value: '', reason: '客户名称不能为空' },
  ]);
  put('exportTasks', [
    { id: 1, name: '销售单导出', entity: 'saleOrders', fileName: 'sale_orders_20261117.xlsx', rows: 3, status: '已完成', createdAt: '2026-11-17 09:30:00' },
  ]);
  put('notifyRules', [{ id: 1, name: '低库存提醒', channel: '站内信', threshold: 10, enabled: 1 }]);
  put('notifyRecords', [
    { id: 1, ruleName: '低库存提醒', title: 'USB-C 扩展坞库存不足', channel: '站内信', receiver: '王仓管', sentAt: '2026-11-17 08:00:00', status: 1 },
  ]);
  put('alertRules', [{ id: 1, name: '安全库存', type: 'STOCK', threshold: 20, enabled: 1 }]);
  put('alertRecords', [
    { id: 1, ruleName: '安全库存', target: 'USB-C 扩展坞', content: '可用量 3 低于安全库存 20', level: '高', triggeredAt: '2026-11-17 08:00:00', handled: 0 },
  ]);
  put('customFields', [
    { id: 1, entity: 'customers', fieldName: 'customerSource', label: '客户来源', type: 'select', options: '展会,转介绍,网络', required: 0, enabled: 1 },
  ]);
  put('customForms', [
    { id: 1, name: '客户满意度调查', entity: 'customers', fields: 5, status: 1, createdBy: '张销售' },
  ]);
  put('revisions', [
    { id: 1, entity: 'product', bizId: 1, field: 'price', before: '25', after: '26', operator: '张销售', createdAt: '2026-11-15 10:00:00' },
  ]);
  put('drafts', [
    { id: 1, entity: 'saleOrders', title: '未完成的销售单', content: '{"customerId":3,"lines":[]}', savedAt: '2026-11-17 11:40:00' },
  ]);
  put('favorites', [
    { id: 1, userId: 1, path: 'sales/orders', title: '清单销售', createdAt: '2026-11-16 09:00:00' },
  ]);
  put('searchLogs', [
    { id: 1, userId: 1, keyword: 'A4 复印纸', module: '产品', resultCount: 1, searchedAt: '2026-11-17 10:15:00' },
    { id: 2, userId: 1, keyword: '蓝天实业', module: '客户', resultCount: 1, searchedAt: '2026-11-16 14:20:00' },
  ]);
  put('auditFieldLogs', [
    { id: 1, entity: 'saleOrders', bizId: 1, field: 'status', before: '2', after: '4', operator: '张销售', createdAt: '2026-11-16 10:00:00' },
  ]);
  put('openapiKeys', [
    { id: 1, appName: '对外数据对接', appKey: 'ak_live_8f2a9c', permissions: 'sales:read,inventory:read', status: 1, createdAt: '2026-11-10 09:00:00' },
  ]);
  put('webhookLogs', [
    { id: 1, event: 'sale.order.shipped', url: 'https://example.com/hook', status: 200, latencyMs: 120, createdAt: '2026-11-16 10:05:00' },
  ]);
  put('offlineBatches', [
    { id: 1, device: 'PDA-01', bizType: 'STOCKTAKE', count: 15, synced: 1, syncedAt: '2026-11-17 15:00:00' },
  ]);
  // AI 模型配置：真实种子，避免 ModelConfig 页面触发内置 DEMO 兜底
  put('aiModels', [
    { id: 1, name: 'qwen-plus', provider: '阿里云', endpoint: 'https://dashscope.aliyuncs.com/compatible-mode/v1', contextLength: 32768, defaultParams: '{"temperature":0.3,"max_tokens":4096}', health: 'healthy', isDefault: 1, isActive: 1 },
    { id: 2, name: 'gpt-4o-mini', provider: 'OpenAI', endpoint: 'https://api.openai.com/v1', contextLength: 128000, defaultParams: '{"temperature":0.2,"max_tokens":2048}', health: 'healthy', isDefault: 0, isActive: 1 },
    { id: 3, name: 'local-rule', provider: 'Local', endpoint: 'local://rule-engine', contextLength: 4096, defaultParams: '{"temperature":0}', health: 'healthy', isDefault: 0, isActive: 0 },
  ]);

  // ---- 采购中心（industry 深度页）真实种子：供应商/分组/采购单/收货/评估/询报价/应付/对账/付款 ----
  // 这些集合被通用兜底有意跳过自动 seed，必须由此处提供，否则采购中心整页空白。
  put('industrySuppliers', [
    { id: 1, code: 'SUP001', name: '得力集团深圳分公司', group: '办公用品', contact: '孙经理', phone: '13900139001', payDays: 30, payMethod: '银行转账', licenseNo: '91440300MA5XXXXX1A', licenseExpire: '2028-06-30', bank: '招商银行深圳分行', bankAccount: '7559XXXXXXXX01', address: '深圳市南山区科技园', remark: '核心供应商', status: '合作中' },
    { id: 2, code: 'SUP002', name: '华强北电子批发', group: '数码电子', contact: '吴老板', phone: '13900139002', payDays: 15, payMethod: '银行转账', licenseNo: '91440300MA5XXXXX2B', licenseExpire: '2027-12-31', bank: '工商银行深圳分行', bankAccount: '4000XXXXXXXX02', address: '深圳市福田区华强北', remark: '价格优势明显', status: '合作中' },
    { id: 3, code: 'SUP003', name: '广州包装材料厂', group: '包装材料', contact: '郑厂长', phone: '13900139003', payDays: 45, payMethod: '承兑汇票', licenseNo: '91440100MA5XXXXX3C', licenseExpire: '2029-03-31', bank: '中国银行广州分行', bankAccount: '6788XXXXXXXX03', address: '广州市白云区', remark: '账期较长', status: '合作中' },
  ]);
  put('industrySupplierGroups', [{ id: 1, name: '办公用品' }, { id: 2, name: '数码电子' }, { id: 3, name: '包装材料' }]);
  put('industryPurchaseOrders', [
    { id: 1, orderNo: 'PO20261115-0001', supplierId: 1, supplierName: '得力集团深圳分公司', warehouseId: 1, warehouseName: '主仓库', payDays: 30, buyer: '李采购', totalAmount: 5600, paidAmount: 2000, receivedQty: 200, status: '部分收货', createdAt: '2026-11-15 14:00:00', lines: [{ id: 1, productId: 1, productName: 'A4 复印纸', qty: 200, received: 200, unitPrice: 28, amount: 5600 }] },
    { id: 2, orderNo: 'PO20261117-0002', supplierId: 2, supplierName: '华强北电子批发', warehouseId: 1, warehouseName: '主仓库', payDays: 15, buyer: '李采购', totalAmount: 4500, paidAmount: 0, receivedQty: 0, status: '已确认', createdAt: '2026-11-17 09:00:00', lines: [{ id: 2, productId: 5, productName: 'USB-C 扩展坞', qty: 50, received: 0, unitPrice: 90, amount: 4500 }] },
    { id: 3, orderNo: 'PO20261118-0003', supplierId: 3, supplierName: '广州包装材料厂', warehouseId: 1, warehouseName: '主仓库', payDays: 45, buyer: '李采购', totalAmount: 1280, paidAmount: 0, receivedQty: 0, status: '待审', createdAt: '2026-11-18 10:30:00', lines: [{ id: 3, productId: 6, productName: '快递纸箱', qty: 400, received: 0, unitPrice: 3.2, amount: 1280 }] },
  ]);
  put('industryPurchaseReceipts', [
    { id: 1, no: 'RCV20261116-0001', orderNo: 'PO20261115-0001', supplierId: 1, supplierName: '得力集团深圳分公司', productId: 1, productName: 'A4 复印纸', qty: 200, batchNo: 'B20261116', expireDate: '2027-11-16', qc: '合格', status: '已上架', warehouseId: 1, cost: 28 },
    { id: 2, no: 'RCV20261118-0002', orderNo: 'PO20261117-0002', supplierId: 2, supplierName: '华强北电子批发', productId: 5, productName: 'USB-C 扩展坞', qty: 20, batchNo: 'B20261118', expireDate: '2028-11-18', qc: '合格', status: '待上架', warehouseId: 1 },
  ]);
  put('industryPurchasePrices', [
    { id: 1, supplierId: 1, supplierName: '得力集团深圳分公司', productId: 1, productName: 'A4 复印纸', price: 28, minQty: 100, effectiveDate: '2026-11-01', status: '生效' },
    { id: 2, supplierId: 2, supplierName: '华强北电子批发', productId: 5, productName: 'USB-C 扩展坞', price: 90, minQty: 20, effectiveDate: '2026-11-01', status: '生效' },
  ]);
  put('industryInquiries', [
    { id: 1, inquiryNo: 'INQ20261116-0001', title: 'A4 复印纸年度询价', items: 'A4 复印纸×1000',deadline: '2026-11-25', status: '询价中', createdAt: '2026-11-16 10:00:00' },
  ]);
  put('industryQuotes', [
    { id: 1, quoteNo: 'QT20261117-0001', inquiryNo: 'INQ20261116-0001', supplierId: 1, supplierName: '得力集团深圳分公司', totalAmount: 26500, validUntil: '2026-12-17', status: '待评审' },
    { id: 2, quoteNo: 'QT20261118-0002', inquiryNo: 'INQ20261116-0001', supplierId: 3, supplierName: '广州包装材料厂', totalAmount: 25800, validUntil: '2026-12-18', status: '待评审' },
  ]);
  put('industryPayables', [
    { id: 1, orderNo: 'PO20261115-0001', supplierName: '得力集团深圳分公司', amount: 5600, paidAmount: 2000, dueDate: '2026-12-15', sourceType: 'PURCHASE', sourceId: 1, status: 1 },
    { id: 2, orderNo: 'PO20261117-0002', supplierName: '华强北电子批发', amount: 4500, paidAmount: 0, dueDate: '2026-12-02', sourceType: 'PURCHASE', sourceId: 2, status: 1 },
  ]);
  put('industryPurchaseStatements', [
    { id: 1, statementNo: 'DZ202611-0001', supplierName: '得力集团深圳分公司', period: '2026-11', amount: 5600, paidAmount: 2000, status: '待确认' },
  ]);
  put('industryPurchasePayments', [
    { id: 1, no: 'PAY20261117-0001', orderNo: 'PO20261115-0001', supplierName: '得力集团深圳分公司', amount: 2000, payMethod: '银行转账', payDate: '2026-11-17', status: 1 },
  ]);
  put('industryPurchaseRejects', [
    { id: 1, no: 'RJ20261117-0001', orderNo: 'PO20261117-0002', supplierName: '华强北电子批发', productId: 5, productName: 'USB-C 扩展坞', qty: 3, reason: '到货外观划痕，质检不合格', qc: '拒收', handledBy: '王仓管', createdAt: '2026-11-17 16:20:00' },
  ]);

  // ---- 行业应用中心（POS / 餐饮 / 服装）真实种子 ----
  put('industryPosOrders', [
    { id: 1, orderNo: 'POS20261118-0001', createdAt: '2026-11-18 10:22:00', total: 32, discount: 2, payMethod: '微信', memberPhone: '13800138001', status: '已完成', items: [{ productId: 1, name: 'A4 复印纸', price: 26, qty: 1 }, { productId: 2, name: '中性笔', price: 3, qty: 2 }] },
    { id: 2, orderNo: 'POS20261118-0002', createdAt: '2026-11-18 11:05:00', total: 59, discount: 0, payMethod: '现金', memberPhone: '', status: '已完成', items: [{ productId: 4, name: '无线鼠标', price: 59, qty: 1 }] },
  ]);
  put('industryCateringTables', [
    { id: 1, no: 'A01', status: '已开台', guests: 4, dishes: [{ name: '宫保鸡丁', price: 38, qty: 1 }, { name: '米饭', price: 3, qty: 4 }] },
    { id: 2, no: 'A02', status: '空闲', guests: 0, dishes: [] },
    { id: 3, no: 'A03', status: '已结账', guests: 2, dishes: [{ name: '番茄炒蛋', price: 26, qty: 1 }] },
    { id: 4, no: 'B01', status: '空闲', guests: 0, dishes: [] },
  ]);
  put('industryCateringOrders', [
    { id: 1, orderNo: 'CY20261118-0001', tableNo: 'A01', guests: 4, total: 50, discount: 0, payMethod: '微信', status: '用餐中', createdAt: '2026-11-18 12:10:00' },
  ]);
  put('industryKitchenTickets', [
    { id: 1, ticketNo: 'KT20261118-0001', tableNo: 'A01', dishName: '宫保鸡丁', qty: 1, status: '已出品', createdAt: '2026-11-18 12:12:00' },
  ]);
  put('industryApparelSkus', [
    { id: 1, styleId: 1, skuCode: 'TSHIRT-RED-M', barcode: '690100000001', color: '红色', size: 'M', price: 89, cost: 35, stock: 25, status: '在售' },
    { id: 2, styleId: 1, skuCode: 'TSHIRT-RED-L', barcode: '690100000002', color: '红色', size: 'L', price: 89, cost: 35, stock: 8, status: '在售' },
    { id: 3, styleId: 1, skuCode: 'TSHIRT-BLU-M', barcode: '690100000003', color: '蓝色', size: 'M', price: 89, cost: 35, stock: 0, status: '停售' },
    { id: 4, styleId: 2, skuCode: 'JEANS-BLK-30', barcode: '690200000001', color: '黑色', size: '30', price: 199, cost: 90, stock: 12, status: '在售' },
  ]);
  return empty;
}

/* -------------------------------------------------------------------------- */
/*                              业务动作处理                                   */
/* ========================== 通用审批引擎（BPM 运行时） ==========================
 * 文档 4.7：定义(flow) → 节点(node) → 规则(condition: 金额/部门/产品)；
 * 节点类型：审批 / 会签 / 或签 / 抄送 / 条件分支 / 自动通过；
 * 触发：单据 submit；回调：通过/驳回/撤回/转办；与「申请与审批」中心互通。
 *
 * 引擎数据落在既有集合：
 *   bpmInstances（流程实例：状态 RUNNING/APPROVED/REJECTED/CANCELED，currentNode）
 *   bpmTasks（当前待办：含 instanceId/nodeId/nodeType/assignee/countersignSeq）
 *   bpmDone（已办）、bpmLogs（全量轨迹）、bpmDelegations（委托/转办记录）
 * 流程定义 bpmDefs.nodes 由 FlowDesigner 保存；无 nodes 时按内置默认节点路由。
 * -------------------------------------------------------------------------- */

/** 内置默认审批节点（当流程定义未保存 nodes 时按金额阈值路由） */
function defaultBpmNodes(bizType: string, ctx: Record<string, any>): any[] {
  const amount = Number(ctx.amount || 0);
  const threshold = bizType === 'SALE_ORDER' ? 10000 : bizType === 'PURCHASE_ORDER' ? 5000 : 0;
  if (bizType === 'LEAVE') {
    return Number(ctx.days || 0) > 3
      ? [{ id: 'n1', type: 'approval', name: '人事经理审批', approver: '人事经理' }]
      : [{ id: 'n1', type: 'auto', name: '自动通过', approver: '系统' }];
  }
  return amount > threshold
    ? [{ id: 'n1', type: 'approval', name: '总监审批', approver: '总监' }]
    : [{ id: 'n1', type: 'approval', name: '主管审批', approver: '主管' }];
}

/**
 * 条件求值：支持 `字段 比较符 数字/字符串` 与中文规则（如「金额>10000」「部门=销售部」）。
 * @param expr 条件表达式，空视为通过
 * @param ctx 业务上下文（amount/days/department/product 等）
 * @returns 是否命中
 */
function evalBpmCondition(expr: string, ctx: Record<string, any>): boolean {
  const s = String(expr || '').trim();
  if (!s) return true;
  const norm = s.replace(/金额/g, 'amount').replace(/部门/g, 'department').replace(/产品/g, 'product').replace(/天数/g, 'days');
  const m = norm.match(/^([\w.]+)\s*(>=|<=|==|!=|>|<|=)\s*(.+)$/);
  if (m) {
    const op = m[2] === '=' ? '==' : m[2];
    const leftRaw = ctx[m[1]];
    const rightRaw = m[3].trim().replace(/^['"]|['"]$/g, '');
    const ln = Number(leftRaw), rn = Number(rightRaw);
    const numeric = !Number.isNaN(ln) && !Number.isNaN(rn);
    const l: any = numeric ? ln : String(leftRaw ?? '');
    const r: any = numeric ? rn : rightRaw;
    switch (op) {
      case '>': return l > r; case '<': return l < r;
      case '>=': return l >= r; case '<=': return l <= r;
      case '==': return String(l) === String(r); case '!=': return String(l) !== String(r);
    }
  }
  return /^(true|是|yes|通过)$/i.test(s);
}

/**
 * 从流程定义解析本次要走的节点序列（跳过 start/end，展开条件分支，识别自动通过）。
 * @param defCode 流程定义编码（如 SALE_ORDER）
 * @param ctx 业务上下文
 * @returns 节点数组（已按顺序）
 */
function resolveBpmNodes(defCode: string, ctx: Record<string, any>): any[] {
  const def = table('bpmDefs').find((d) => d.code === defCode);
  const raw: any[] = Array.isArray(def?.nodes) && def.nodes.length
    ? def.nodes
    : defaultBpmNodes(defCode, ctx);
  // 起点：start 节点的 next，或直接第一个非 start/end 节点
  const start = raw.find((n) => n.type === 'start');
  const out: any[] = [];
  let cur: any = start?.next ? raw.find((n) => n.id === start.next) : raw.find((n) => !['start', 'end'].includes(n.type));
  const visited = new Set<string>();
  while (cur && !visited.has(String(cur.id))) {
    visited.add(String(cur.id));
    if (cur.type === 'end') break;
    if (cur.type === 'condition') {
      const branch = (cur.branches || []).find((b: any) => evalBpmCondition(b.condition, ctx));
      const targetId = branch?.to || cur.next;
      cur = targetId ? raw.find((n) => n.id === targetId) : undefined;
      continue;
    }
    out.push(cur);
    cur = cur.next ? raw.find((n) => n.id === cur.next) : undefined;
  }
  return out.length ? out : defaultBpmNodes(defCode, ctx);
}

/**
 * 为某节点生成审批待办。审批节点生成 1 条；会签生成多条（assignee 逗号分隔）；
 * 或签生成多条任一人通过即可；抄送生成只读任务；自动通过直接记日志并跳过。
 * @returns 本节点生成的任务数
 */
function spawnBpmNode(inst: any, node: any): number {
  const nodeType = String(node.type || 'approval');
  const approvers = String(node.approver || '审批人').split(/[,，、]/).map((s) => s.trim()).filter(Boolean);
  if (nodeType === 'auto') {
    table('bpmLogs').push({ id: nextId('bpmLogs'), instanceId: inst.id, nodeName: node.name || '自动通过', action: 'AUTO', comment: '条件满足，系统自动通过', createdAt: now() });
    return 0;
  }
  const list = nodeType === 'approval' ? approvers.slice(0, 1) : approvers;
  const assignees = list.length ? list : ['审批人'];
  assignees.forEach((who: string, i: number) => {
    table('bpmTasks').push({
      id: nextId('bpmTasks'), instanceId: inst.id, nodeId: node.id, nodeType,
      bizType: inst.bizType, bizId: inst.bizId, bizNo: inst.bizNo, amount: inst.amount,
      context: inst.context || {}, nodeName: node.name || '审批', assignee: who,
      countersignSeq: i + 1, countersignTotal: assignees.length, status: 'TODO', createdAt: now(),
    });
  });
  return assignees.length;
}

/**
 * 发起审批：建实例 + 解析节点 + 生成首个待处理节点的任务（自动通过会连续跳过）。
 * @param bizType 业务类型（SALE_ORDER/PURCHASE_ORDER/集合名大写）
 * @param bizId 单据 id
 * @param bizNo 单号
 * @param ctx 规则上下文
 * @returns 审批实例
 */
function startApproval(bizType: string, bizId: any, bizNo: string, ctx: Record<string, any>): any {
  // 幂等：同单据已有 RUNNING 实例则复用
  const exist = table('bpmInstances').find((i) => i.bizType === bizType && Number(i.bizId) === Number(bizId) && i.status === 'RUNNING');
  if (exist) return exist;
  const nodes = resolveBpmNodes(bizType, ctx);
  const inst = saveRow('bpmInstances', {
    bizType, bizId, bizNo, amount: ctx.amount || 0, context: ctx,
    status: 'RUNNING', currentNode: '开始', nodeIndex: 0, nodePlan: nodes,
    createdAt: now(),
  });
  const real = findRow('bpmInstances', inst.id);
  advanceToNode(real, 0);
  return real;
}

/**
 * 流转到指定下标的节点：自动通过/抄送自动记日志并继续，直到生成真实审批任务或结束。
 */
function advanceToNode(inst: any, index: number): void {
  const nodes: any[] = inst.nodePlan || [];
  if (index >= nodes.length) {
    inst.status = 'APPROVED'; inst.currentNode = '完成'; inst.nodeIndex = nodes.length;
    table('bpmLogs').push({ id: nextId('bpmLogs'), instanceId: inst.id, nodeName: '完成', action: 'AUTO', comment: '审批流程结束，全部节点通过', createdAt: now() });
    onApprovalFinished(inst, true);
    saveDb(); return;
  }
  const node = nodes[index];
  inst.nodeIndex = index; inst.currentNode = node.name || '审批';
  const spawned = spawnBpmNode(inst, node);
  if (spawned === 0) advanceToNode(inst, index + 1); // 自动通过：递归跳到下一节点
  else saveDb();
}

/**
 * 审批全部通过后的业务回调：按 bizType 走既有确认逻辑（锁库存/费用生效等）。
 */
function onApprovalFinished(inst: any, approved: boolean): void {
  if (!approved) return;
  try {
    if (inst.bizType === 'SALE_ORDER') saleAction(Number(inst.bizId), 'confirm');
    else if (inst.bizType === 'PURCHASE_ORDER') purchaseAction(Number(inst.bizId), 'confirm');
    else {
      // 通用单据：把状态推进到「已确认/已批准」（若引擎状态机可推导）
      const row = findRow(String(inst.bizType).toLowerCase(), inst.bizId);
      if (row) { row.approvalStatus = 'APPROVED'; row.updatedAt = now(); }
    }
  } catch { /* 回调失败不影响审批结论，路径由业务单据自身守卫负责 */ }
}

/**
 * 审批处理：通过/驳回/撤回/转办。会签需全部通过、或签任一人通过即进入下一节点。
 */
function handleBpmTask(task: any, data: any): string {
  const action = String(data.action || 'APPROVE').toUpperCase();
  const inst = findRow('bpmInstances', task.instanceId) || table('bpmInstances').find((i) => i.bizType === task.bizType && Number(i.bizId) === Number(task.bizId));
  const comment = String(data.comment || '');

  if (action === 'TRANSFER') {
    const target = String(data.assignee || '').trim();
    if (!target) throw new Error('转办必须指定接收人');
    table('bpmDelegations').push({ id: nextId('bpmDelegations'), taskId: task.id, from: task.assignee, to: target, createdAt: now() });
    task.assignee = target; task.status = 'TODO';
    table('bpmLogs').push({ id: nextId('bpmLogs'), instanceId: inst?.id, nodeName: task.nodeName, action: 'TRANSFER', comment: `转办给 ${target}`, createdAt: now() });
    saveDb(); return `已转办给 ${target}`;
  }
  if (action === 'CANCEL') {
    // 撤回：仅待办可撤回，作废同单据的全部待办并终止实例
    const tasks = table('bpmTasks').filter((t) => t.instanceId === task.instanceId || (t.bizType === task.bizType && Number(t.bizId) === Number(task.bizId)));
    tasks.forEach((t) => { t.status = 'CANCELED'; });
    if (inst) { inst.status = 'CANCELED'; inst.currentNode = '已撤回'; }
    table('bpmLogs').push({ id: nextId('bpmLogs'), instanceId: inst?.id, nodeName: task.nodeName, action: 'CANCEL', comment: comment || '申请人撤回', createdAt: now() });
    saveDb(); return '已撤回审批，单据恢复可编辑';
  }

  const approved = action === 'APPROVE';
  task.status = approved ? 'DONE' : 'REJECTED';
  table('bpmDone').push({ ...clone(task), action, comment, handledAt: now() });
  table('bpmLogs').push({ id: nextId('bpmLogs'), instanceId: inst?.id, nodeName: task.nodeName, action, comment, createdAt: now() });

  if (!approved) {
    if (inst) { inst.status = 'REJECTED'; inst.currentNode = '已驳回'; }
    // 驳回：业务单据置作废（与原逻辑一致）
    const bz = task.bizType === 'SALE_ORDER' ? findRow('saleOrders', task.bizId)
      : task.bizType === 'PURCHASE_ORDER' ? findRow('purchaseOrders', task.bizId)
      : findRow(String(task.bizType).toLowerCase(), task.bizId);
    if (bz && Number(bz.status) === 1) bz.status = 9;
    saveDb(); return '已驳回';
  }

  // 通过：判断节点内其他待办是否都完成
  const nodeTasks = table('bpmTasks').filter((t) => t.instanceId === inst?.id && t.nodeId === task.nodeId && t.status === 'TODO');
  const nodeType = String(task.nodeType || 'approval');
  const isCounter = nodeType === 'countersign';
  const isOr = nodeType === 'orsign';
  if (nodeTasks.length === 0 || isOr) {
    // 会签：其余人还没通过则等待；或签/单人审批：立即流转
    if (isCounter && nodeTasks.length > 0) { saveDb(); return '已同意，等待其他会签人'; }
    if (isOr && nodeTasks.length > 0) nodeTasks.forEach((t) => { t.status = 'DONE'; }); // 或签：其余自动通过
    // 清理当前节点残留待办，进入下一节点
    table('bpmTasks').filter((t) => t.instanceId === inst?.id && t.nodeId === task.nodeId).forEach((t) => { if (t.status === 'TODO') t.status = 'DONE'; });
    if (inst) advanceToNode(inst, Number(inst.nodeIndex || 0) + 1);
    else onApprovalFinished({ bizType: task.bizType, bizId: task.bizId }, true);
  } else {
    saveDb(); return isCounter ? '已同意，等待其他会签人' : '已通过';
  }
  saveDb();
  return inst?.status === 'APPROVED' ? '审批全部通过，业务单据已生效' : '已通过，流转至下一审批节点';
}

/* -------------------------------------------------------------------------- */

/**
 * 销售单状态动作：提交 / 确认（锁库存）/ 发货（出库+应收+凭证）/ 作废 / 复制 / 退货。
 * @param id 销售单 id
 * @param action 动作名
 * @param data 附加参数（退货数量等）
 * @returns 操作结果
 */
function saleAction(id: number, action: string, data: any = {}): any {
  const order = findRow('saleOrders', id);
  if (!order) throw new Error('销售单不存在');
  // 提交：草稿 -> 待审，交通用审批引擎按流程定义建实例 + 多节点待办
  if (action === 'submit') {
    if (Number(order.status) !== 0) throw new Error('仅草稿单据可提交审批');
    order.status = 1;
    const scheme = schemeOf('saleOrders');
    const threshold = Number(scheme.approvalAmount ?? 10000);
    const dept = order.department || '销售部';
    const inst = startApproval('SALE_ORDER', order.id, order.orderNo, { amount: Number(order.totalAmount || 0), department: dept, product: (order.lines?.[0]?.productName || ''), days: 0 });
    saveDb(); return { ...clone(order), message: `已提交审批（阈值 ${threshold}，实例 #${inst.id}）` };
  }
  // 确认：待审 -> 已确认，逐行锁定库存（可用量减少，实物不变）
  if (action === 'confirm') {
    if ([2, 3, 4].includes(Number(order.status))) return { ...clone(order), message: '单据已确认，无需重复操作' };
    // 校验可用量，避免超卖导致负库存
    for (const line of order.lines || []) {
      const balance = table('balance').find((b) => Number(b.productId) === Number(line.productId) && Number(b.warehouseId) === Number(order.warehouseId));
      const available = Number(balance?.qtyOnHand || 0) - Number(balance?.qtyOccupied || 0);
      if (!balance || available < Number(line.qty)) throw new Error(`产品 ${line.productName || line.productId} 可用库存不足`);
    }
    order.status = 2;
    for (const line of order.lines || []) {
      const balance = table('balance').find((b) => Number(b.productId) === Number(line.productId) && Number(b.warehouseId) === Number(order.warehouseId));
      if (balance) { balance.qtyOccupied = Number((Number(balance.qtyOccupied) + Number(line.qty)).toFixed(3)); }
    }
    saveDb(); return { ...clone(order), message: '已确认，库存已锁定' };
  }
  // 发货：已确认 -> 完成；释放锁定、实际出库、写流水、生成应收与收入凭证
  if (action === 'ship') {
    if (Number(order.status) !== 2 && Number(order.status) !== 3) throw new Error('仅已确认/部分发货单据可发货');
    if (Number(order.shipStatus) === 2) throw new Error('单据已发货，请勿重复操作');
    order.status = 4; order.shipStatus = 2;
    let costAmount = 0;
    for (const line of order.lines || []) {
      const balance = table('balance').find((b) => Number(b.productId) === Number(line.productId) && Number(b.warehouseId) === Number(order.warehouseId));
      const cost = Number(balance?.avgCost || 0);
      costAmount += cost * Number(line.qty);
      balance && (balance.qtyOccupied = Math.max(0, Number(balance.qtyOccupied) - Number(line.qty)));
      postStock(Number(line.productId), Number(order.warehouseId), 'SALE_OUT', -Number(line.qty), cost, order.id);
    }
    const unpaid = Number(order.totalAmount) - Number(order.paidAmount || 0);
    if (unpaid > 0) {
      table('receivables').push({ id: nextId('receivables'), customerId: order.customerId, customerName: order.customerName, sourceType: 'SALE', sourceId: order.id, amount: money(unpaid), receivedAmount: '0', dueDate: '2026-12-31', status: 1 });
    }
    // 收入凭证按未收金额入账；已收款部分在收款环节已挂应付/预收，避免应收重复
    // 价税分离：含税未收额 = 不含税收入 + 销项税额
    const taxRate = defaultTaxRate();
    const { net: netIncome, tax: vatAmount } = splitTax(unpaid, taxRate);
    makeVoucher(`销售确认 ${order.orderNo}`, [
      { subjectId: subjectId(SUBJECT.AR), debit: money(unpaid), credit: 0, summary: '应收账款' },
      { subjectId: subjectId(SUBJECT.REVENUE), debit: 0, credit: netIncome, summary: '主营业务收入' },
      ...(vatAmount > 0 ? [{ subjectId: subjectId(SUBJECT.VAT), debit: 0, credit: vatAmount, summary: '销项税额' }] : []),
    ], 'SALE_ORDER', order.id);
    makeVoucher(`结转成本 ${order.orderNo}`, [
      { subjectId: subjectId(SUBJECT.COGS), debit: money(costAmount), credit: 0, summary: '主营业务成本' },
      { subjectId: subjectId(SUBJECT.GOODS), debit: 0, credit: money(costAmount), summary: '库存商品' },
    ], 'SALE_COST', order.id);
    saveDb(); return { ...clone(order), message: '已发货，应收与凭证已生成' };
  }
  // 作废：仅草稿/待审可作废，已锁库存需先释放
  if (action === 'void') {
    if ([2, 3, 4].includes(Number(order.status))) throw new Error('已确认/已完成单据不可直接作废，请先退货');
    order.status = 9; saveDb(); return { ...clone(order), message: '已作废' };
  }
  // 复制：带明细复制成新草稿（saveRow 返回副本，需取真实行写单号才能持久化）
  if (action === 'copy') {
    const saved = saveRow('saleOrders', { ...clone(order), id: undefined, orderNo: '', status: 0, payStatus: 0, shipStatus: 0, paidAmount: 0, lines: clone(order.lines || []) });
    const real = findRow('saleOrders', saved.id);
    if (real) { real.orderNo = makeNo('SO', real.id); saveDb(); }
    return { ...clone(real || saved), message: '已复制为新草稿' };
  }
  // 退货：红字出库，按传入数量逐行回补库存（data.lines 可指定部分退货，缺省整单）
  if (action === 'return') {
    const retLines = Array.isArray(data?.lines) && data.lines.length ? data.lines : (order.lines || []).map((l: any) => ({ productId: l.productId, qty: l.qty }));
    for (const rl of retLines) {
      const qty = Number(rl.qty || 0);
      if (qty <= 0) continue;
      const origin = (order.lines || []).find((l: any) => Number(l.productId) === Number(rl.productId));
      const returned = Number(order.returnedQtyByProduct?.[rl.productId] || 0);
      if (origin && returned + qty > Number(origin.qty)) throw new Error(`产品 ${origin.productName || rl.productId} 退货数量超过已发数量`);
      // 按原成本价回补，避免用售价抬高移动平均成本
      const balance = table('balance').find((b) => Number(b.productId) === Number(rl.productId) && Number(b.warehouseId) === Number(order.warehouseId));
      postStock(Number(rl.productId), Number(order.warehouseId), 'SALE_RETURN', qty, Number(balance?.avgCost || origin?.cost || 0), order.id);
      order.returnedQtyByProduct = { ...(order.returnedQtyByProduct || {}), [rl.productId]: returned + qty };
    }
    order.returnStatus = '已退货';
    // 按退货占比冲减收入与应收，生成红字凭证，避免退货后应收/收入虚高
    const totalQty = (order.lines || []).reduce((s: number, l: any) => s + Number(l.qty || 0), 0);
    const returnQty = Object.values(order.returnedQtyByProduct || {}).reduce((s: any, q: any) => s + Number(q || 0), 0) as number;
    const ratio = totalQty > 0 ? Math.min(1, returnQty / totalQty) : 0;
    const refundAmount = Number(order.totalAmount || 0) * ratio;
    if (refundAmount > 0) {
      const related = table('receivables').filter((r) => r.sourceType === 'SALE' && Number(r.sourceId) === Number(order.id));
      for (const r of related) r.amount = money(Math.max(0, Number(r.amount) - refundAmount));
      // 红字冲销：借 主营业务收入(不含税) + 借 应交税费(销项税额) / 贷 应收账款(含税)
      const { net: netRefund, tax: vatRefund } = splitTax(refundAmount, defaultTaxRate());
      makeVoucher(`销售退货 ${order.orderNo}`, [
        { subjectId: subjectId(SUBJECT.REVENUE), debit: netRefund, credit: 0, summary: '冲减主营业务收入' },
        ...(vatRefund > 0 ? [{ subjectId: subjectId(SUBJECT.VAT), debit: vatRefund, credit: 0, summary: '冲减销项税额' }] : []),
        { subjectId: subjectId(SUBJECT.AR), debit: 0, credit: money(refundAmount), summary: '冲减应收账款' },
      ], 'SALE_RETURN', order.id);
    }
    saveDb();
    return { ...clone(order), message: '退货已回补库存并冲减应收' };
  }
  // 开票：已发货/完成单据登记发票，带 sourceType/sourceId 与销售单一一关联，可追溯
  if (action === 'invoice') {
    if (![2, 3, 4].includes(Number(order.status))) throw new Error('仅已确认/已发货单据可开票');
    const exists = table('financeInvoices').find((i: any) => i.sourceType === 'SALE' && Number(i.sourceId) === Number(order.id));
    if (exists) return { ...clone(order), invoiceNo: exists.invoiceNo, message: `已开票 ${exists.invoiceNo}` };
    const inv = saveRow('financeInvoices', {
      invoiceNo: makeNo('0441', nextId('financeInvoices')),
      invoiceCode: '0441200000',
      invoiceType: 'ELECTRONIC',
      buyerName: order.customerName || order.customerId || '客户',
      sourceType: 'SALE', sourceId: order.id, sourceNo: order.orderNo,
      amount: money(order.totalAmount || 0), taxRate: 13,
      taxAmount: money(Number(order.totalAmount || 0) * 0.13 / 1.13),
      invoiceDate: now().slice(0, 10), status: 1,
    });
    order.invoiceNo = inv.invoiceNo;
    saveDb();
    return { ...clone(order), invoiceNo: inv.invoiceNo, message: `开票成功 ${inv.invoiceNo}，已关联销售单` };
  }
  saveDb(); return { ...clone(order), message: '状态已更新' };
}

/**
 * 采购单状态动作：提交 / 确认 / 收货（入库+应付）/ 退货 / 作废。
 * @param id 采购单 id
 * @param action 动作名
 * @param data 附加参数
 * @returns 操作结果
 */
function purchaseAction(id: number, action: string, data: any = {}): any {
  const order = findRow('purchaseOrders', id);
  if (!order) throw new Error('采购单不存在');
  if (action === 'submit') {
    if (Number(order.status) !== 0) throw new Error('仅草稿单据可提交审批');
    order.status = 1;
    const scheme = schemeOf('purchaseOrders');
    const threshold = Number(scheme.approvalAmount ?? 5000);
    const inst = startApproval('PURCHASE_ORDER', order.id, order.orderNo, { amount: Number(order.totalAmount || 0), department: '采购部', product: (order.lines?.[0]?.productName || ''), days: 0 });
    saveDb(); return { ...clone(order), message: `已提交审批（阈值 ${threshold}，实例 #${inst.id}）` };
  }
  if (action === 'confirm') { if ([2, 3, 4].includes(Number(order.status))) return { ...clone(order), message: '单据已确认' }; order.status = 2; saveDb(); return { ...clone(order), message: '已确认' }; }
  if (action === 'receive') {
    if (![2, 3].includes(Number(order.status))) throw new Error('仅已确认/部分收货单据可收货');
    let amount = 0; let allReceived = true;
    for (const line of order.lines || []) {
      const reqQty = Number(data?.lines?.find?.((l: any) => Number(l.productId) === Number(line.productId))?.qty ?? line.qty);
      const already = Number(order.receivedQtyByProduct?.[line.productId] || 0);
      const qty = Math.min(reqQty, Number(line.qty) - already);
      if (qty <= 0) { if (already < Number(line.qty)) allReceived = false; continue; }
      if (already + qty < Number(line.qty)) allReceived = false;
      order.receivedQtyByProduct = { ...(order.receivedQtyByProduct || {}), [line.productId]: already + qty };
      order.receivedQty = Number((Number(order.receivedQty || 0) + qty).toFixed(3));
      postStock(Number(line.productId), Number(order.warehouseId), 'PURCHASE_IN', qty, Number(line.unitPrice), order.id);
      amount += qty * Number(line.unitPrice);
    }
    if (amount <= 0) throw new Error('没有可收货数量，请勿重复收货');
    order.status = allReceived ? 4 : 3;
    // 应付按本次实收金额生成，避免全额应付与实际入库不符
    table('payables').push({ id: nextId('payables'), supplierId: order.supplierId, supplierName: order.supplierName, sourceType: 'PURCHASE', sourceId: order.id, amount: money(amount), paidAmount: '0', dueDate: '2026-12-31', status: 1 });
    // 入库分录：生产物料计入原材料、商品计入库存商品；贷方先挂应付暂估（收到发票转应付账款）
    const isRawMaterial = /material|raw|component|物料|原料/i.test(
      (order.lines || []).map((l: any) => `${l.productName || ''}${l.productType || ''}`).join(' ')
    );
    makeVoucher(`采购入库 ${order.orderNo}`, [
      { subjectId: subjectId(isRawMaterial ? SUBJECT.RAW_MATERIAL : SUBJECT.GOODS), debit: money(amount), credit: 0, summary: isRawMaterial ? '原材料' : '库存商品' },
      { subjectId: subjectId(SUBJECT.ACCRUED_AP), debit: 0, credit: money(amount), summary: '应付暂估' },
    ], 'PURCHASE_ORDER', order.id);
    saveDb(); return { ...clone(order), message: allReceived ? '已全部收货入库，应付与凭证已生成' : '已部分收货入库' };
  }
  if (action === 'return') {
    const retQty = Math.max(0, Number(data?.qty ?? 0));
    if (retQty <= 0) throw new Error('退货数量必须大于 0');
    const productId = Number(data?.productId ?? order.lines?.[0]?.productId);
    const unitPrice = Number(order.lines?.find((l: any) => Number(l.productId) === productId)?.unitPrice ?? order.lines?.[0]?.unitPrice ?? 0);
    // 已收数量统一从 receivedQtyByProduct 读取，兼容旧数据的 line.received
    const already = Number(order.receivedQtyByProduct?.[productId] ?? order.lines?.[0]?.received ?? 0);
    if (retQty > already) throw new Error(`退货数量 ${retQty} 超过已收数量 ${already}`);
    postStock(productId, Number(order.warehouseId), 'PURCHASE_RETURN', -retQty, unitPrice, order.id);
    order.receivedQtyByProduct = { ...(order.receivedQtyByProduct || {}), [productId]: Number((already - retQty).toFixed(3)) };
    order.receivedQty = Number((Number(order.receivedQty || 0) - retQty).toFixed(3));
    // 冲减应付：按退货金额记红字应付
    const refundAmount = money(retQty * unitPrice);
    table('payables').push({ id: nextId('payables'), supplierId: order.supplierId, supplierName: order.supplierName, sourceType: 'PURCHASE_RETURN', sourceId: order.id, amount: money(-Number(refundAmount)), paidAmount: '0', status: 1 });
    saveDb(); return { ...clone(order), message: '采购退货已冲减库存与应付' };
  }
  if (action === 'void') {
    if ([3, 4].includes(Number(order.status))) throw new Error('已收货单据不可直接作废，请先退货冲销');
    order.status = 9; saveDb(); return { ...clone(order), message: '已作废' };
  }
  saveDb(); return { ...clone(order), message: '状态已更新' };
}

/**
 * 通用业务动作执行器：驱动 126 个功能页的状态机与跨单据联动。
 * ---------------------------------------------------------------------------
 * 设计思路：
 *   1. 先按 flow 的 from/to 守卫校验状态，非法跳转直接抛错（对应文档「单据状态机不可逆跳」）；
 *   2. 执行集合相关的副作用：库存过账 / 会计凭证 / 应收应付 / 考勤联动；
 *   3. 所有动作写审计日志，按方案决定是否写通知；
 *   4. 返回值带 message，页面 toast 直接显示「做了什么、联动了什么」。
 * @param collection 集合名（如 hrLeaves / inventoryAdjusts）
 * @param id 记录 id
 * @param action 动作标识
 * @param data 附加参数（退货数量等）
 * @returns 更新后的记录与说明
 */
function genericBizAction(collection: string, id: any, action: string, data: any = {}): any {
  const row = findRow(collection, id);
  if (!row) throw new Error(`记录不存在（${collection}#${id}）`);
  // 用实体 Schema 的真实字段构建流程，保证后端状态机与前端页面完全一致：
  // 若传空数组会退化成 fallback 数字 key（'0'/'1'），与中文种子值（待审/通过）不匹配，动作会被误判为非法。
  const schema = getEntitySchema(collection);
  // flowKey 由页面传入：公司/部门共用 systemOrgs 集合但业务流不同，必须按 flowKey 取专属配置
  const flow: BizFlow = buildFlow(collection, schema?.label || collection, '', schema?.fields || [], data.flowKey || '');
  const scheme = schemeOf(collection, data.flowKey || '');
  const statusField = data.statusField || (flow.status?.field) || schema?.statusField || 'status';
  const currentRaw = String(row[statusField] ?? '');
  const actDef = flow.actions.find((a) => a.key === action);
  // 状态值体系可能是「中文文案」（种子/历史数据：草稿、待审核）或「数字 code」（Schema options：0/1/2）。
  // 统一用 canonicalState 归一化后比较，避免"当前状态草稿、仅允许草稿"却判失败的错位。
  // 文案映射：优先用 Schema 的 statusLabels，把 code 转成中文再归一化。
  const labels = { ...(flow.status?.labels || {}), ...(schema?.statusLabels || {}) };
  const displayLabel = (v: any) => labels[String(v)] || String(v);
  const canon = (v: any) => canonicalState(displayLabel(v));
  const current = canon(currentRaw);

  // 守卫：状态机不允许的跳转直接拒绝；报表/日志类无状态动作不受限
  if (actDef && actDef.from.length && flow.category === 'doc' && !actDef.from.some((f) => canon(f) === current)) {
    const names = actDef.from.map((f) => displayLabel(f) || '空').join('/');
    throw new Error(`当前状态「${displayLabel(currentRaw) || '空'}」不可执行「${actDef.label}」，仅允许：${names}`);
  }

  const effects: string[] = [];
  const amount = Number(data.amount ?? row.amount ?? row.totalAmount ?? row.paidAmount ?? row.netPay ?? row.netSalary ?? 0);
  // 过账类副作用（库存/凭证）只能在「终态过账动作」触发一次。
  // 模块专属流显式声明 postingActions；未声明时沿用 execute/approve 推断，避免重复过账。
  const effectsFor = flow.effects?.length ? flow.effects : sideEffectsFor(collection);
  const isPostingAction = flow.postingActions
    ? flow.postingActions.includes(action)
    : (flow.actions.some((x) => x.key === 'execute') ? action === 'execute' : action === 'approve');
  const voucherTypeOf = (c: string): string => {
    const map: Record<string, string> = {
      inventoryadjusts: 'ADJUST', wmsstocktakes: 'ADJUST', wmstransfers: 'TRANSFER',
      inventoryreceipts: 'PURCHASE_IN', inventoryouts: 'SALE_OUT', inventorypicks: 'PRODUCTION_PICK',
      inventorypicksout: 'PRODUCTION_PICK', mesissues: 'PRODUCTION_PICK', mesmaterialreturns: 'PRODUCTION_RETURN',
      mesfinishins: 'FINISH_IN', mesassemblies: 'ASSEMBLY',
    };
    return map[c.toLowerCase()] || c.toUpperCase();
  };
  const vType = voucherTypeOf(collection);

  // ---- 副作用 1：库存过账（调整/盘点/调拨/出入库/领退料/完工），仅终态触发一次 ----
  const wantStock = effectsFor.includes('stock') && isPostingAction;
  if (wantStock && scheme.autoPost) {
    const productId = Number(data.productId ?? row.productId ?? 0);
    const warehouseId = Number(data.warehouseId ?? row.warehouseId ?? 1);
    // 兼容多种数量字段：adjustQty（调整）、qty（通用）、changeQty（盘点）
    const qty = Number(data.qty ?? row.qty ?? row.adjustQty ?? row.changeQty ?? 0);
    if (productId && qty) {
      postStock(productId, warehouseId, vType, qty, Number(data.cost ?? row.cost ?? 0), Number(id));
      effects.push(`库存${qty >= 0 ? '入库' : '出库'} ${Math.abs(qty)}`);
    }
  }

  // ---- 副作用 2：会计凭证（费用/收入/收付款/转账/折旧/工资），仅终态触发一次 ----
  const wantVoucher = effectsFor.includes('voucher') && isPostingAction;
  if (wantVoucher && scheme.autoPost && amount > 0) {
    // 按业务语义选择科目，避免"所有单据都用同一对科目"的错账
    const entries = buildVoucherEntries(collection, amount, row, data);
    if (entries.length) {
      makeVoucher(`${flow.title || collection} ${row.code || row.no || row.id}`, entries, vType, Number(id));
      effects.push(`已生成凭证 ${money(amount)}`);
    }
  }

  // ---- 副作用 3：应收 / 应付（收付款核销） ----
  // 核销后回写来源单据（销售单/采购单）的已收/已付金额与状态，保证列表页金额联动。
  if (effectsFor.includes('receivable') && action === 'execute' && amount > 0) {
    // 优先按显式 receivableId 定位；收款单未绑定时按客户名称匹配未结清应收，保证联动可达。
    let rel = table('receivables').find((r) => Number(r.id) === Number(data.receivableId ?? row.receivableId));
    if (!rel && row.customerName) {
      rel = table('receivables').find((r) => r.customerName === row.customerName && Number(r.receivedAmount || 0) < Number(r.amount || 0));
    }
    if (rel) {
      rel.receivedAmount = money(Number(rel.receivedAmount || 0) + amount);
      if (rel.sourceType === 'SALE' && rel.sourceId) {
        const so = findRow('saleOrders', Number(rel.sourceId));
        if (so) {
          so.paidAmount = money(Number(so.paidAmount || 0) + amount);
          so.payStatus = Number(so.paidAmount) >= Number(so.totalAmount) ? 2 : 1;
        }
      }
      effects.push('已核销应收并回写销售单');
    }
  }
  if (effectsFor.includes('payable') && action === 'execute' && amount > 0) {
    const rel = table('payables').find((p) => Number(p.id) === Number(data.payableId ?? row.payableId));
    if (rel) {
      rel.paidAmount = money(Number(rel.paidAmount || 0) + amount);
      if (rel.sourceType === 'PURCHASE' && rel.sourceId) {
        const po = findRow('purchaseOrders', Number(rel.sourceId));
        if (po) po.paidAmount = money(Number(po.paidAmount || 0) + amount);
      }
      effects.push('已核销应付并回写采购单');
    }
  }

  // ---- 副作用 4：请假审批通过 -> 考勤状态回写 ----
  if (effectsFor.includes('attendance') && ['approve', 'confirm', 'onboard', 'offboard'].includes(action)) {
    const emp = String(row.employeeName || row.employee || '');
    const att = table('attendance').find((a) => String(a.employeeName) === emp && String(a.workDate) === String(row.startDate || ''));
    if (att) { att.status = '请假'; effects.push('考勤已标记请假'); }
    else if (emp) { table('attendance').push({ id: nextId('attendance'), employeeName: emp, workDate: row.startDate || now().slice(0, 10), status: '请假', remark: row.leaveType || '' }); effects.push('已生成请假考勤记录'); }
  }

  // ---- 状态流转 ----
  // 画像动作（pageProfiles）不在通用状态机里，目标状态由前端通过 data.to 传入。
  if (actDef?.to !== undefined) {
    row[statusField] = actDef.to;
    row.updatedAt = now();
  } else if (data.to !== undefined && data.to !== '') {
    row[statusField] = data.to;
    row.updatedAt = now();
  }
  if (action === 'copy') {
    const copy = saveRow(collection, { ...clone(row), id: undefined, createdAt: now() });
    const real = findRow(collection, copy.id);
    if (real) real.code = `${real.code || 'COPY'}-C${real.id}`;
    saveDb(); return { ...clone(real || copy), message: '已复制为新记录' };
  }

  // ---- 提交审批：单据类走通用引擎建实例 + 多节点待办（与主链路销售/采购一致） ----
  let approvalMsg = '';
  if (action === 'submit' && flow.category === 'doc' && scheme.autoApprove !== 0) {
    const bizType = collection.toUpperCase();
    const bizNo = String(row.no || row.code || row.orderNo || `${collection}-${id}`);
    const ctx = {
      amount: Number(row.amount ?? row.totalAmount ?? 0),
      department: String(row.department || row.dept || ''),
      product: String(row.productName || row.product || ''),
      days: Number(row.days || row.leaveDays || 0),
    };
    const inst = startApproval(bizType, id, bizNo, ctx);
    approvalMsg = `，已提交审批（实例 #${inst.id}）`;
  }

  // ---- 审计与通知 ----
  const label = actDef?.label || data.label || action;
  writeAudit(collection, action, id, `${label}：${flow.title || collection}#${id}${effects.length ? '；' + effects.join('；') : ''}`);
  if (scheme.notifyOnAction !== 0 && !['copy', 'print', 'export', 'refresh'].includes(action)) {
    writeNotify(`${flow.title || collection} ${label}`, `记录 #${id} 已${label}${effects.length ? '，' + effects.join('，') : ''}`);
  }
  saveDb();
  return { ...clone(row), message: `${label}成功${approvalMsg}${effects.length ? '，' + effects.join('，') : ''}` };
}

/**
 * AI 规则引擎：无密钥时按关键词给出库存 / 应收 / 补货 / 科目建议。
 * @param message 用户输入
 * @returns { text, fallback, items? }
 */
function aiRule(message: string): any {
  const msg = String(message || '');
  if (msg.includes('库存') || msg.includes('缺货') || msg.includes('预警')) {
    const low = table('balance').map((b) => {
      const product = findRow('products', b.productId) || {};
      return { name: product.name, available: Number(b.qtyOnHand) - Number(b.qtyOccupied), safe: Number(product.safeQty || 20) };
    }).filter((r) => r.available < r.safe);
    return { text: low.length ? `当前有 ${low.length} 个产品低于安全库存：\n` + low.slice(0, 8).map((r, i) => `${i + 1}. ${r.name}：可用 ${r.available}，安全 ${r.safe}`).join('\n') : '当前全部产品库存充足，暂无缺货预警。', fallback: true };
  }
  if (msg.includes('应收') || msg.includes('欠款') || msg.includes('回款')) {
    const rows = table('receivables');
    const total = rows.reduce((sum, r) => sum + Number(r.amount) - Number(r.receivedAmount), 0);
    return { text: `当前未结应收共 ${rows.length} 笔，合计 ${money(total)} 元。 TOP 客户：${rows.slice(0, 3).map((r) => r.customerName).join('、') || '无'}。`, fallback: true };
  }
  if (msg.includes('补货') || msg.includes('预测') || msg.includes('采购建议')) {
    const items = table('balance').map((b) => {
      const product = findRow('products', b.productId) || {};
      const available = Number(b.qtyOnHand) - Number(b.qtyOccupied);
      const safe = Number(product.safeQty || 20);
      return { productCode: product.code, productName: product.name, predictQty: safe, suggestPurchaseQty: Math.max(0, safe - available), reason: `可用 ${available} 低于安全库存 ${safe}` };
    }).filter((i) => i.suggestPurchaseQty > 0);
    return { text: `已生成 ${items.length} 条补货建议（本地规则引擎）`, fallback: true, items };
  }
  if (msg.includes('流程') || msg.includes('怎么')) {
    return { text: '标准流程：销售单 → 提交审批 → 确认锁库存 → 发货出库 → 生成应收 → 收款核销 → 自动凭证。采购：采购单 → 确认 → 收货入库 → 应付 → 付款 → 凭证。', fallback: true };
  }
  return { text: `（本地规则引擎）已收到：「${msg}」。我可以帮你查库存预警、查应收、生成补货建议、解释业务流程。配置 AI 密钥后可获得大模型回答。`, fallback: true };
}

/**
 * APS 默认工序模板：无工艺路线数据时按产品通用工艺展开（分钟/件 + 准备工时）。
 * 工时＝准备工时/60 + 数量×单件分钟/60/设备效率，保证排产结果可被工作日历逐日分配。
 */
const APS_PROCESS_TEMPLATE = [
  { seqNo: 10, processName: '下料', workCenter: '数控加工中心', stdMinutes: 1.2, setupMinutes: 30 },
  { seqNo: 20, processName: '焊接', workCenter: '焊接工作站', stdMinutes: 1.8, setupMinutes: 20 },
  { seqNo: 30, processName: '总装调试', workCenter: '总装线', stdMinutes: 2.4, setupMinutes: 15 },
];

/**
 * APS 默认 BOM：齐套检查时按产品展开物料需求（每件用量）。
 * 库存表找不到同名物料时使用演示可用量，保证演示链路必定可观察缺料与齐套两种结果。
 */
const APS_BOM: Record<string, Array<{ name: string; per: number; fallback: number }>> = {
  智能温控器: [{ name: '温控芯片', per: 1, fallback: 150 }, { name: '铝合金外壳', per: 1, fallback: 86 }],
  无线网关: [{ name: '网关主控板', per: 1, fallback: 200 }, { name: '天线组件', per: 1, fallback: 320 }],
  工控主板: [{ name: 'PCB 空板', per: 1, fallback: 90 }, { name: '芯片组', per: 1, fallback: 60 }],
};

/** 日期格式化：本地日期转 yyyy-mm-dd，避免 toISOString 的时区偏移 */
function apsDate(d: Date): string {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}
/** 小数小时转 HH:MM 时间串 */
function apsClock(hour: number): string {
  const total = Math.max(0, Math.round(hour * 60));
  return `${String(Math.floor(total / 60)).padStart(2, '0')}:${String(total % 60).padStart(2, '0')}`;
}
/** 日期 + 小时小数转排产时间串 */
function apsTime(date: string, hour: number): string { return `${date} ${apsClock(hour)}`; }

/**
 * 取某工作中心某日的工作日历可用工时。
 * 未维护日历时按周一至周五 8 小时、周末停产兜底。
 */
function apsAvailable(center: string, date: string): number {
  const row = table('apsCalendars').find((c) => c.workCenter === center && c.calendarDate === date);
  if (row) return Number(row.isWorking) ? Number(row.availableHours || 0) : 0;
  const day = new Date(`${date}T00:00:00`).getDay();
  return [0, 6].includes(day) ? 0 : 8;
}

/**
 * 取某工作中心某日已被工序任务占用的工时（已完工任务不再占用产能）。
 * @param extra 本次排产中尚未落库的新任务占用（日期|中心 -> 小时），避免同批工序互相抢占
 */
function apsOccupied(center: string, date: string, extra: Map<string, number>): number {
  const stored = table('apsTasks')
    .filter((t) => t.workCenter === center && String(t.planStart || '').slice(0, 10) === date && t.status !== 'DONE')
    .reduce((sum, t) => sum + Number(t.workHours || 0), 0);
  return stored + (extra.get(`${date}|${center}`) || 0);
}

/**
 * 为工序分配时间窗口：正排从起始日向后找空档，倒排从起始日向前找空档，
 * 逐日消耗工时并自动跳过周末/停产日；有限产能模式会扣减已占用工时。
 * @returns 起止时间串；无可用工作日时返回 null
 */
function apsAllocate(center: string, hours: number, from: string, direction: 'FORWARD' | 'BACKWARD', finite: boolean, extra: Map<string, number>): { start: string; end: string } | null {
  let remain = Math.max(0.1, Number(hours));
  const base = new Date(`${from}T00:00:00`);
  type Slot = { date: string; startHour: number; endHour: number };
  let startSlot: Slot | null = null;
  let endSlot: Slot | null = null;
  for (let i = 0; i < 90 && remain > 0.001; i++) {
    const date = apsDate(new Date(base.getTime() + (direction === 'FORWARD' ? i : -i) * 86400000));
    const available = apsAvailable(center, date);
    if (available <= 0) continue;
    const used = finite ? apsOccupied(center, date, extra) : 0;
    const free = Math.max(0, available - used);
    if (free <= 0.001) continue;
    const take = Math.min(remain, free);
    const slot: Slot = direction === 'FORWARD'
      ? { date, startHour: 8 + used, endHour: 8 + used + take }
      : { date, startHour: 8 + free - take, endHour: 8 + free };
    if (direction === 'FORWARD') {
      if (!startSlot) startSlot = slot;
      endSlot = slot;
    } else {
      if (!endSlot) endSlot = slot;
      startSlot = slot;
    }
    extra.set(`${date}|${center}`, used + take);
    remain -= take;
  }
  if (!startSlot || !endSlot) return null;
  return { start: apsTime(startSlot.date, startSlot.startHour), end: apsTime(endSlot.date, endSlot.endHour) };
}

/**
 * 重算产能负荷：按「日期 × 工作中心」汇总未完成工序任务工时，
 * 负荷率 = 计划工时 / 日历可用工时；>100% 标记为超载并识别瓶颈中心。
 */
function apsRebuildLoads(): void {
  db.apsLoads = [];
  const map = new Map<string, { date: string; center: string; hours: number; count: number }>();
  for (const task of table('apsTasks')) {
    if (task.status === 'DONE' || task.isDeleted) continue;
    const date = String(task.planStart || '').slice(0, 10);
    if (!date) continue;
    const key = `${date}|${task.workCenter}`;
    const cur = map.get(key) || { date, center: task.workCenter, hours: 0, count: 0 };
    cur.hours += Number(task.workHours || 0);
    cur.count += 1;
    map.set(key, cur);
  }
  for (const item of map.values()) {
    const available = apsAvailable(item.center, item.date);
    const rate = available > 0 ? Math.round((item.hours / available) * 1000) / 10 : 100;
    db.apsLoads.push({
      id: nextId('apsLoads'), loadDate: item.date, workCenter: item.center,
      availableHours: available, plannedHours: Math.round(item.hours * 10) / 10,
      loadRate: rate, taskCount: item.count,
      level: rate > 100 ? 'OVER' : rate >= 85 ? 'WARN' : rate <= 20 ? 'IDLE' : 'NORMAL',
      bottleneck: rate > 100 ? 1 : 0, createdAt: now(), isDeleted: 0,
    });
  }
  saveDb();
}

/**
 * 写入或更新一条 APS 预警：同类型 + 同关联单号只保留一条待处理记录，避免每次排产刷屏。
 */
function apsUpsertAlert(type: string, level: string, title: string, detail: string, bizNo: string): void {
  const exists = table('apsAlerts').find((a) => a.alertType === type && a.bizNo === bizNo && a.status === 'OPEN');
  if (exists) return;
  table('apsAlerts').push({
    id: nextId('apsAlerts'), alertType: type, level, title, detail, bizNo,
    status: 'OPEN', createdAt: now(), isDeleted: 0,
  });
}

/**
 * 齐套检查：按默认 BOM 展开已排产/已确认计划，逐料核对可用库存并生成缺料预警。
 * @param planId 指定计划；不传时检查全部未完工计划
 */
function apsMaterialCheck(planId?: number): any {
  const plans = table('apsPlans').filter((p) => !p.isDeleted && p.status !== 'CANCELLED'
    && (!planId || Number(p.id) === Number(planId)));
  if (!plans.length) throw new Error('没有可检查的生产计划');
  const checkNo = makeNo('QK', nextId('apsMaterials'));
  let shortCount = 0;
  for (const plan of plans) {
    const items = APS_BOM[String(plan.productName || '')] || [{ name: plan.productName || '主料', per: 1, fallback: 0 }];
    for (const it of items) {
      const bal = table('balance').find((b) => String((findRow('products', b.productId) || {}).name || '') === it.name);
      const available = bal ? Number(bal.qtyOnHand || 0) - Number(bal.qtyOccupied || 0) : it.fallback;
      const require = Number(plan.qty || 0) * Number(it.per || 1);
      const short = Math.max(0, require - available);
      if (short > 0) shortCount++;
      table('apsMaterials').push({
        id: nextId('apsMaterials'), checkNo, planNo: plan.planNo, materialName: it.name,
        requireQty: require, availableQty: available, shortQty: short,
        status: short > 0 ? 'SHORT' : 'OK', checkedAt: now(), isDeleted: 0,
      });
      if (short > 0) apsUpsertAlert('MATERIAL', short > require * 0.3 ? 'HIGH' : 'MED',
        `${plan.planNo} 缺少${it.name} ${short} 件`, `需求 ${require} 件，可用 ${available} 件，建议加急采购或调整开工日期`, plan.planNo);
    }
  }
  saveDb();
  writeAudit('SCHEDULE', 'APS_MATERIAL_CHECK', planId || 0, `${checkNo} 齐套检查完成，缺料 ${shortCount} 项`);
  return { checkNo, planCount: plans.length, shortCount };
}

/**
 * 执行排产运算：按优先级与交期顺序展开工序，使用工作日历与有限产能空档逐工序分配时间，
 * 生成工序任务、刷新负荷、识别交期风险，并回写计划状态与排产批次。
 */
function apsRunSchedule(cfg: any = {}): any {
  const strategy = cfg.strategy === 'INFINITE' ? 'INFINITE' : 'FINITE';
  const direction = cfg.direction === 'BACKWARD' ? 'BACKWARD' : 'FORWARD';
  const plans = table('apsPlans').filter((p) => !p.isDeleted && p.status === 'CONFIRMED'
    && (!Array.isArray(cfg.planIds) || !cfg.planIds.length || cfg.planIds.includes(Number(p.id))));
  if (!plans.length) throw new Error('没有可排产的「已确认」计划，请先确认计划');
  plans.sort((a, b) => String(a.priority || 'P3').localeCompare(String(b.priority || 'P3'))
    || String(a.dueDate || '9999').localeCompare(String(b.dueDate || '9999')));

  const run = {
    id: nextId('apsRuns'), runNo: makeNo('APS', nextId('apsRuns')), strategy, direction,
    planCount: plans.length, taskCount: 0, lateCount: 0, overloadCount: 0,
    status: 'RUNNING', createdAt: now(), isDeleted: 0,
  };
  table('apsRuns').push(run);
  const extra = new Map<string, number>();
  let taskCount = 0;
  let lateCount = 0;

  for (const plan of plans) {
    let planLate = 0;
    const resource = table('apsResources').find((r) => r.name === plan.workCenter);
    const efficiency = Math.max(50, Number(resource?.efficiency || 90)) / 100;
    const templates = APS_PROCESS_TEMPLATE.map((t) => {
      const route = table('routings').find((r) => r.productName === plan.productName && r.processName === t.processName);
      return { ...t, processName: route?.processName || t.processName, workCenter: route?.workCenter || t.workCenter };
    });
    const startDate = String(plan.planStart || apsDate(new Date()));
    let previousEnd = direction === 'BACKWARD' ? String(plan.dueDate || startDate) : startDate;
    let previousTaskNo = '';
    let firstStart = '';
    for (const proc of templates) {
      const hours = Math.round((proc.setupMinutes / 60 + Number(plan.qty || 0) * proc.stdMinutes / 60 / efficiency) * 10) / 10;
      const slot = apsAllocate(proc.workCenter, hours, previousEnd, direction, strategy === 'FINITE', extra);
      if (!slot) throw new Error(`工作中心 ${proc.workCenter} 在计划期内没有可用工作日，请检查工作日历`);
      const id = nextId('apsTasks');
      const late = String(slot.end).slice(0, 10) > String(plan.dueDate || '9999-12-31') ? 1 : 0;
      if (late) { lateCount++; planLate = late; }
      table('apsTasks').push({
        id, taskNo: `APT${String(id).padStart(4, '0')}`, planId: plan.id, planNo: plan.planNo,
        productName: plan.productName, seqNo: proc.seqNo, processName: proc.processName,
        workCenter: proc.workCenter, qty: Number(plan.qty || 0), workHours: hours,
        planStart: slot.start, planEnd: slot.end, predecessor: previousTaskNo,
        priority: plan.priority || 'P3', status: 'SCHEDULED', lateFlag: late,
        runId: run.id, createdAt: now(), isDeleted: 0,
      });
      taskCount++;
      if (!firstStart) firstStart = slot.start;
      previousTaskNo = `APT${String(id).padStart(4, '0')}`;
      previousEnd = String(slot.end).slice(0, 10);
    }
    plan.status = 'SCHEDULED';
    plan.planStart = String(firstStart).slice(0, 10);
    plan.planEnd = String(previousEnd);
    plan.scheduleNo = run.runNo;
    if (planLate) apsUpsertAlert('DUE', 'HIGH', `${plan.planNo} 交期风险`, `排产完工 ${plan.planEnd} 晚于需求日期 ${plan.dueDate}，建议加急或调整优先级`, plan.planNo);
  }

  run.taskCount = taskCount;
  run.lateCount = lateCount;
  run.status = 'DONE';
  apsRebuildLoads();
  run.overloadCount = table('apsLoads').filter((l) => l.level === 'OVER').length;
  for (const load of table('apsLoads').filter((l) => l.level === 'OVER')) {
    apsUpsertAlert('CAPACITY', 'HIGH', `${load.workCenter} ${load.loadDate} 产能超载 ${Math.round(load.loadRate - 100)}%`,
      `可用 ${load.availableHours} 小时，已排 ${load.plannedHours} 小时，建议分流或调整班次`, load.loadDate);
  }
  writeAudit('RUN', 'APS_SCHEDULE', run.id, `${run.runNo} 排产完成：${run.planCount} 张计划 / ${run.taskCount} 道工序 / ${lateCount} 项交期风险`);
  writeNotify('排产运算完成', `${run.runNo} 生成 ${run.taskCount} 道工序，交期风险 ${lateCount} 项`);
  saveDb();
  return clone(run);
}

/**
 * 确保 APS 集合首次访问即具备真实种子：
 * 通用兜底只在 GET 集合时初始化种子，而看板统计直接读内存表，故在 APS 入口统一补齐。
 */
function apsEnsureSeed(): void {
  const keys = ['apsPlans', 'apsRuns', 'apsTasks', 'apsResources', 'apsCalendars', 'apsLoads', 'apsMaterials', 'apsAlerts'];
  for (const key of keys) {
    if (table(key).length) continue;
    const schema = getEntitySchema(key);
    if (!schema?.seed?.length) continue;
    for (const row of schema.seed) table(key).push({ ...clone(row), createdAt: now(), updatedAt: now(), isDeleted: 0 });
    saveDb();
  }
}

/**
 * APS 专用接口处理：看板统计、排产运算、计划状态动作、任务调整/完工、
 * 齐套检查、预警处理、日历批量生成；其余 REST 请求返回 undefined 交给通用兜底。
 */
function handleAps(m: string, parts: string[], data: any, params: any, path: string): any {
  if (parts[0] !== 'aps') return undefined;
  apsEnsureSeed();
  const sub = parts[1] || '';
  const id = Number(parts[2]);

  if (sub === 'overview' && m === 'GET') {
    const plans = table('apsPlans').filter((p) => !p.isDeleted);
    const tasks = table('apsTasks').filter((t) => !t.isDeleted);
    return {
      plans: plans.length,
      confirmed: plans.filter((p) => p.status === 'CONFIRMED').length,
      scheduled: plans.filter((p) => p.status === 'SCHEDULED' || p.status === 'ISSUED').length,
      tasks: tasks.length,
      pendingTasks: tasks.filter((t) => t.status === 'SCHEDULED').length,
      lateTasks: tasks.filter((t) => Number(t.lateFlag) === 1 && t.status !== 'DONE').length,
      overloads: table('apsLoads').filter((l) => l.level === 'OVER').length,
      openAlerts: table('apsAlerts').filter((a) => a.status === 'OPEN').length,
      shortMaterials: table('apsMaterials').filter((x) => x.status === 'SHORT').length,
    };
  }
  if (sub === 'schedule' && parts[2] === 'run' && m === 'POST') return apsRunSchedule(data || {});
  if (sub === 'material-check' && m === 'POST') return apsMaterialCheck(data?.planId ? Number(data.planId) : undefined);
  if (sub === 'material-check' && m === 'GET') return clone(table('apsMaterials').filter((x) => !params.planNo || x.planNo === params.planNo));
  if (sub === 'loads' && parts[2] === 'rebuild' && m === 'POST') { apsRebuildLoads(); return { ok: true }; }

  if (sub === 'plans' && parts[3] && m === 'POST') {
    const plan = findRow('apsPlans', id);
    if (!plan) throw new Error('生产计划不存在');
    const action = parts[3];
    if (action === 'confirm') {
      if (plan.status !== 'DRAFT') throw new Error('只有草稿计划可以确认');
      plan.status = 'CONFIRMED';
    } else if (action === 'cancel') {
      if (['COMPLETED', 'CANCELLED'].includes(plan.status)) throw new Error('该计划已结束，不可作废');
      plan.status = 'CANCELLED';
    } else if (action === 'issue') {
      if (plan.status !== 'SCHEDULED') throw new Error('计划需先完成排产才能下达工单');
      plan.status = 'ISSUED';
      const exists = table('workOrders').find((w) => w.planNo === plan.planNo);
      if (!exists) {
        table('workOrders').push({
          id: nextId('workOrders'), orderNo: makeNo('WO', nextId('workOrders')), planNo: plan.planNo,
          productId: plan.productId || 1, productName: plan.productName, qty: plan.qty,
          planQty: plan.qty, planStart: plan.planStart, planEnd: plan.planEnd,
          producedQty: 0, status: 'DRAFT', createdAt: now(), isDeleted: 0,
        });
      }
    } else if (action === 'complete') {
      plan.status = 'COMPLETED';
    } else return undefined;
    plan.updatedAt = now();
    writeAudit('ACTION', 'APS_PLAN', plan.id, `${plan.planNo} 执行「${action}」，状态变更为 ${plan.status}`);
    saveDb();
    return { ok: true, status: plan.status };
  }

  if (sub === 'tasks' && parts[3] === 'complete' && m === 'POST') {
    const task = findRow('apsTasks', id);
    if (!task) throw new Error('工序任务不存在');
    task.status = 'DONE';
    task.updatedAt = now();
    // 同计划内尚未开始的后续工序转为生产中，全部完工后自动完成生产计划
    const rest = table('apsTasks').filter((t) => t.planId === task.planId && t.status !== 'DONE');
    if (rest.length) rest.sort((a, b) => Number(a.seqNo) - Number(b.seqNo))[0].status = 'RUNNING';
    else {
      const plan = findRow('apsPlans', task.planId);
      if (plan && plan.status !== 'COMPLETED') plan.status = 'COMPLETED';
    }
    apsRebuildLoads();
    writeAudit('ACTION', 'APS_TASK', task.id, `${task.taskNo} 工序任务完工，后续工序已推进`);
    saveDb();
    return { ok: true, status: task.status };
  }
  // 手动调整任务：重算负荷并重新识别交期风险（兼容 PATCH 与 POST 两种调用方式）
  if (sub === 'tasks' && (m === 'PATCH' || m === 'POST') && parts[2] && parts[3] !== 'complete') {
    const task = findRow('apsTasks', id);
    if (!task) throw new Error('工序任务不存在');
    Object.assign(task, data || {});
    task.updatedAt = now();
    const plan = findRow('apsPlans', task.planId);
    const late = plan && String(task.planEnd || '').slice(0, 10) > String(plan.dueDate || '9999-12-31') ? 1 : 0;
    task.lateFlag = late;
    apsRebuildLoads();
    writeAudit('EDIT', 'APS_TASK', task.id, `${task.taskNo} 手动调整排产：${task.workCenter} ${task.planStart} ~ ${task.planEnd}`);
    saveDb();
    return { ok: true, task: clone(task) };
  }

  if (sub === 'alerts' && parts[3] === 'resolve' && m === 'POST') {
    const alert = findRow('apsAlerts', id);
    if (!alert) throw new Error('预警不存在');
    alert.status = 'RESOLVED';
    alert.updatedAt = now();
    writeAudit('ACTION', 'APS_ALERT', alert.id, `${alert.bizNo} 预警已处理：${alert.title}`);
    saveDb();
    return { ok: true };
  }

  if (sub === 'calendars' && parts[2] === 'batch' && m === 'POST') {
    const centers: string[] = data?.workCenters?.length ? data.workCenters : table('apsResources').map((r) => r.name);
    const start = new Date(`${data?.startDate || apsDate(new Date())}T00:00:00`);
    const days = Math.min(90, Number(data?.days || 14));
    const hours = Number(data?.defaultHours || 8);
    let created = 0;
    for (let i = 0; i < days; i++) {
      const date = apsDate(new Date(start.getTime() + i * 86400000));
      const weekend = [0, 6].includes(new Date(`${date}T00:00:00`).getDay());
      for (const center of centers) {
        if (table('apsCalendars').some((c) => c.calendarDate === date && c.workCenter === center)) continue;
        table('apsCalendars').push({
          id: nextId('apsCalendars'), calendarDate: date, workCenter: center,
          shiftType: weekend ? '停产' : '白班', availableHours: weekend ? 0 : hours,
          isWorking: weekend ? 0 : 1, reason: weekend ? '周末休息' : '正常班次',
          createdAt: now(), isDeleted: 0,
        });
        created++;
      }
    }
    saveDb();
    return { created };
  }

  if (sub === 'plans' && m === 'GET' && params.status === 'SCHEDULABLE') return clone(table('apsPlans').filter((p) => p.status === 'CONFIRMED' && !p.isDeleted));
  // 兼容 /aps/schedule/runs 查看历次运算批次
  if (sub === 'schedule' && parts[2] === 'runs') return clone(table('apsRuns').slice().reverse());
  if (sub === 'plan' && path.includes('/aps/plan/')) return undefined;
  return undefined;
}

/**
 * Mock 请求分发入口：把 axios 请求映射到本地业务处理。
 * @param method HTTP 方法
 * @param url 请求地址（含 /api/v1 前缀）
 * @param data 请求体
 * @param params 查询参数
 * @returns Promise<任意业务数据>
 */
export async function handleMock(method: string, url: string, data: any = {}, params: any = {}): Promise<any> {
  const path = url.replace(/^\/api\/v1/, '').split('?')[0];
  const parts = path.split('/').filter(Boolean);
  const m = method.toUpperCase();

  /** 通用集合名：把 REST 路径转成 camelCase 集合，例如 crm/leads -> crmLeads */
  const collectionOf = (segments: string[]) => segments.map((s, i) => i === 0 ? s : s.replace(/(^|-)([a-z])/g, (_, __, c) => c.toUpperCase())).join('');

  // ---- 认证 ----
  if (path === '/auth/login') {
    const user = table('users').find((u) => u.username === data.username && u.password === data.password);
    if (!user) throw new Error('用户名或密码错误，可点击「使用演示数据」进入');
    return { token: 'mock-token-' + user.id, userInfo: clone(user) };
  }
  if (path === '/auth/refresh') return { token: 'mock-token-refreshed' };

  // ---- 系统管理 ----
  if (path === '/system/dicts') return displayRows('systemDicts', clone(table('dicts')));
  if (parts[0] === 'system' && parts[1] === 'dicts' && parts[2]) return clone(table('dicts').filter((d) => d.dictCode === parts[2]));
  if (path === '/system/notifies' && m === 'GET') return clone(table('notifies'));
  // 事件总线订阅落点：领域事件（库存变动/订单确认/审批完成等）转为通知中心消息
  if (path === '/system/notifies' && m === 'POST') {
    const n = saveRow('notifies', { ...data, isRead: 0, createdAt: data.createdAt || now() });
    return clone(n);
  }
  if (parts[0] === 'system' && parts[1] === 'notifies' && parts[3] === 'read') { const n = findRow('notifies', parts[2]); if (n) n.isRead = 1; saveDb(); return { ok: true }; }
  if (path === '/system/users' && m === 'GET') return listResult('users', params);
  if (path === '/system/users' && m === 'POST') {
    const saved = saveRow('users', { ...data, password: data.password || '123456' });
    return clone(saved);
  }
  if (path === '/system/roles') return clone(table('roles'));
  if (path === '/system/permissions') return clone(table('permissions'));
  if (path === '/system/configs' && m === 'GET') {
    // 同时给出 cfgKey/cfgValue 与 configKey/configValue 两套别名：
    // 系统参数页读 cfgKey/cfgValue，Schema 种子用 configKey/configValue，避免编辑后显示为空。
    const rows = displayRows('systemConfigs', clone(table('configs')));
    return rows.map((c: any) => ({ ...c, cfgKey: c.cfgKey ?? c.configKey ?? c.key, cfgValue: c.cfgValue ?? c.configValue ?? c.value }));
  }
  if (path === '/system/configs' && m === 'POST') {
    const cfgKey = data.key ?? data.cfgKey ?? data.configKey;
    const cfgValue = String(data.value ?? data.cfgValue ?? data.configValue ?? '');
    // 双写两套字段名，兼容参数页（cfg*）与 Schema 种子（config*）两种口径。
    const existing = table('configs').find((c: any) => (c.cfgKey || c.configKey || c.key) === cfgKey);
    if (existing) { Object.assign(existing, { cfgKey, cfgValue, configKey: cfgKey, configValue: cfgValue }); saveDb(); }
    else saveRow('configs', { cfgKey, cfgValue, configKey: cfgKey, configValue: cfgValue, configName: cfgKey });
    return { ok: true };
  }
  if (path === '/system/audit-logs') return displayRows('systemAuditLogs', listResult('auditLogs', params).list);
  if (path === '/system/login-logs') return displayRows('systemLoginLogs', clone(table('loginLogs')));
  if (path === '/system/orgs') return clone(table('orgs'));

  // ---- 基础数据 / 库存 ----
  if (path === '/inventory/warehouses') return clone(table('warehouses'));
  if (path === '/inventory/categories') return clone(table('categories'));
  if (path === '/inventory/products' && m === 'GET') {
    // 仓库筛选：库存归属在 balance 表，先按仓库预筛产品 id 再交给通用列表查询
    const ids = params.warehouseId
      ? table('balance').filter((b) => Number(b.warehouseId) === Number(params.warehouseId)).map((b) => Number(b.productId))
      : undefined;
    const r = listResult('products', { ...params, __ids: ids });
    // 原型产品列表要求展示品牌/分类/计量单位与合计库存（可用量 = 实物量 - 锁定量）
    for (const p of r.list) {
      p.categoryName = findRow('categories', p.categoryId)?.name || '';
      p.brandName = findRow('brands', p.brandId)?.name || '';
      p.unitName = findRow('units', p.unitId)?.name || '';
      const rows = table('balance').filter((b) => Number(b.productId) === Number(p.id)
        && (!params.warehouseId || Number(b.warehouseId) === Number(params.warehouseId)));
      p.totalQty = money(rows.reduce((s, b) => s + Number(b.qtyOnHand || 0) - Number(b.qtyOccupied || 0), 0));
    }
    r.summary = { productCount: r.total, stockValue: money(table('products').reduce((s, p) => s + Number(p.cost || 0) * Number(p.totalQty || 0), 0)) };
    return r;
  }
  if (path === '/inventory/products' && m === 'POST') {
    const duplicate = table('products').some((row) => !row.isDeleted && row.id !== data.id && String(row.code).toLowerCase() === String(data.code).toLowerCase());
    if (duplicate) throw new Error('产品编码已存在');
    const saved = saveRow('products', { ...data, totalQty: data.totalQty ?? 0 });
    return clone(saved);
  }
  if (parts[0] === 'inventory' && parts[1] === 'products' && parts.length === 3 && m === 'POST') {
    const product = findRow('products', parts[2]);
    if (!product || product.isDeleted) throw new Error('产品不存在');
    return clone(saveRow('products', { ...data, id: product.id }));
  }
  if (parts[0] === 'inventory' && parts[1] === 'products' && parts[3] === 'variants') {
    const product = findRow('products', parts[2]);
    if (product) { product.variants = data.variants || []; saveDb(); return { ok: true }; }
  }
  if (parts[0] === 'inventory' && parts[1] === 'products' && parts[3] === 'void') {
    const product = findRow('products', parts[2]); if (product) { product.isActive = 0; saveDb(); } return { ok: true };
  }
  if (path === '/inventory/balance') {
    // 同时给出 available 与 qtyAvailable 两个别名：列表页读 qtyAvailable，AI/移动端读 available，保持一致。
    const rows = table('balance')
      .filter((b) => !params.warehouseId || Number(b.warehouseId) === Number(params.warehouseId))
      .map((b) => ({ ...clone(b), productName: findRow('products', b.productId)?.name || '', warehouseName: findRow('warehouses', b.warehouseId)?.name || '', available: Number(b.qtyOnHand) - Number(b.qtyOccupied), qtyAvailable: Number(b.qtyOnHand) - Number(b.qtyOccupied) }));
    const keyword = String(params.keyword || '').trim();
    return { list: keyword ? rows.filter((r) => r.productName.includes(keyword) || String(r.productId).includes(keyword)) : rows, total: rows.length };
  }
  if (path === '/inventory/negative-stocks' && m === 'GET') {
    return table('balance').filter((row) => Number(row.qtyOnHand) - Number(row.qtyOccupied) < 0).map((row) => {
      const product = findRow('products', row.productId);
      return {
        id: row.id, productName: product?.name, productCode: product?.code,
        warehouseName: findRow('warehouses', row.warehouseId)?.name,
        qtyOnHand: row.qtyOnHand, qtyOccupied: row.qtyOccupied, available: Number(row.qtyOnHand) - Number(row.qtyOccupied),
      };
    });
  }
  if (path === '/inventory/ledger') return displayRows('inventoryLedger', listResult('ledger', params).list);
  // 组装/拆装：按 BOM 组件用量真实过账，改变库存余额并写流水，避免只保存单据不动库存
  if (path === '/inventory/assemblies' && m === 'POST') {
    const qty = Number(data.qty || 0);
    const warehouseId = Number(data.warehouseId || 1);
    const productId = Number(data.productId || 0);
    const assemble = String(data.mode || 'ASSEMBLE') !== 'DISASSEMBLE';
    const lines = Array.isArray(data.lines) ? data.lines : [];
    if (!(qty > 0) || !productId) throw new Error('组装/拆装需要成品和大于 0 的数量');
    if (!lines.length) throw new Error('缺少 BOM 组件明细，无法过账');
    const balanceOf = (pid: number) => table('balance').find((b) => Number(b.productId) === pid && Number(b.warehouseId) === warehouseId);
    const availableOf = (pid: number) => {
      const b = balanceOf(pid);
      return Number(b?.qtyOnHand || 0) - Number(b?.qtyOccupied || 0);
    };
    const totalUsage = lines.reduce((s: number, l: any) => s + Number(l.usage || 0), 0);
    if (assemble) {
      for (const l of lines) {
        const need = Number(l.usage || 0) * qty;
        if (availableOf(Number(l.productId)) < need) throw new Error(`组件「${l.name || l.productId}」可用库存不足`);
      }
    } else if (availableOf(productId) < qty) {
      throw new Error('待拆成品可用库存不足');
    }
    let materialCost = 0;
    for (const l of lines) {
      const need = Number(l.usage || 0) * qty;
      const b = balanceOf(Number(l.productId));
      materialCost += need * Number(b?.avgCost || 0);
      postStock(Number(l.productId), warehouseId, assemble ? 'ASSEMBLY_OUT' : 'ASSEMBLY_IN', assemble ? -need : need, Number(b?.avgCost || 0), Number(data.id || 0));
    }
    const finished = balanceOf(productId);
    const unitCost = assemble && qty > 0 ? materialCost / qty : Number(finished?.avgCost || 0);
    postStock(productId, warehouseId, assemble ? 'ASSEMBLY_IN' : 'ASSEMBLY_OUT', assemble ? qty : -qty, unitCost, Number(data.id || 0));
    const saved = saveRow('assemblies', { ...data, no: data.no || makeNo('AS', nextId('assemblies')), status: 'DONE', totalUsage, unitCost: money(unitCost), createdAt: now() });
    saveDb();
    return clone(saved);
  }
  if (path === '/inventory/alerts') return clone(table('alerts'));
  // 通用库存过账接口：供采购收货/退货等行业深度组件真正驱动库存与流水
  if (path === '/industry/stock-post' && m === 'POST') {
    const qty = Number(data.qty || 0);
    if (!data.productId || !qty) throw new Error('库存过账需要 productId 与非零 qty');
    postStock(Number(data.productId), Number(data.warehouseId || 1), data.voucherType || 'PURCHASE_IN', qty, Number(data.cost || 0), Number(data.voucherId || 0));
    saveDb();
    return { ok: true, message: '库存已过账' };
  }
  // 收货中心「质检入库」：保存入库快照的同时真实驱动库存余额与流水（PURCHASE_IN）
  // 之前该路径落入通用 saveRow，仅存记录不过账，导致库存余额不变，此处补齐。
  if (path === '/industry/stockBalanceIn' && m === 'POST') {
    const qty = Number(data.qty || 0);
    if (!data.productId || !qty) throw new Error('上架入库需要 productId 与非零 qty');
    const snapshot = saveRow('industryStockBalanceIns', data);
    postStock(Number(data.productId), Number(data.warehouseId || 1), 'PURCHASE_IN', qty, Number(data.unitCost || data.cost || 0), Number(snapshot.id));
    return { ...clone(snapshot), ok: true, message: '库存已过账（采购入库）' };
  }

  // ---- 销售 ----
  // 新建销售单：自动生成单号、默认状态与金额，供表单页保存后立即显示
  if (path === '/sales/orders' && m === 'POST') {
    const lines = data.lines || [];
    const lineTotal = lines.reduce((sum: number, l: any) => sum + Number(l.amount ?? Number(l.qty) * Number(l.unitPrice)), 0);
    // 表单已按促销/优惠试算出应付金额时优先采用，避免入库金额与界面展示不一致
    const total = Number(data.totalAmount) > 0 ? Number(data.totalAmount) : lineTotal;
    const saved = saveRow('saleOrders', { ...data, lines, status: data.status ?? 0, payStatus: 0, shipStatus: 0, paidAmount: 0, totalAmount: money(total), customerName: data.customerName || findRow('customers', data.customerId)?.name || '' });
    // saveRow 返回的是副本，必须改库里的真实行，否则单号不会持久化
    const stored = findRow('saleOrders', saved.id);
    if (stored) stored.orderNo = makeNo('SO', stored.id);
    saveDb(); return clone(stored || saved);
  }
  if (path === '/sales/orders' && m === 'GET') {
    const r = listResult('saleOrders', params);
    // 统计卡与后端保持一致：按当前筛选条件汇总，而不是永远统计全表
    const all = listResult('saleOrders', { ...params, page: 1, pageSize: 100000 }).list;
    r.summary = {
      orderCount: all.length, totalAmount: money(all.reduce((s, o) => s + Number(o.totalAmount || 0), 0)),
      paidAmount: money(all.reduce((s, o) => s + Number(o.paidAmount || 0), 0)),
      unpaidAmount: money(all.reduce((s, o) => s + Number(o.totalAmount || 0) - Number(o.paidAmount || 0), 0)),
      todayAmount: money(all.filter((o) => String(o.orderDate || '').includes(new Date().toISOString().slice(0, 10))).reduce((s, o) => s + Number(o.totalAmount || 0), 0)),
    };
    return r;
  }
  // 经营趋势：从真实销售单/采购单按日期聚合近 7 日金额，供首页 ECharts 使用
  if (path === '/bi/trend') {
    const days: string[] = [];
    const base = new Date();
    for (let i = 6; i >= 0; i--) {
      const d = new Date(base.getTime() - i * 86400000);
      days.push(`${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`);
    }
    const sumBy = (key: string) => days.map((day) => money(table(key)
      .filter((o) => String(o.orderDate || '').slice(0, 10) === day)
      .reduce((s, o) => s + Number(o.totalAmount || 0), 0)));
    return { days: days.map((d) => `${Number(d.slice(5, 7))}/${Number(d.slice(8, 10))}`), sale: sumBy('saleOrders'), purchase: sumBy('purchaseOrders') };
  }
  // 单据详情：/sales/orders/:id，带明细行，供表单页回显
  if (parts[0] === 'sales' && parts[1] === 'orders' && parts[2] && !parts[3] && m === 'GET') {
    return clone(findRow('saleOrders', parts[2]) || {});
  }
  if (parts[0] === 'sales' && parts[1] === 'orders' && parts[3]) {
    return saleAction(Number(parts[2]), parts[3], data);
  }

  // ---- 采购 ----
  if (path === '/purchase/orders' && m === 'POST') {
    const lines = data.lines || [];
    const total = lines.reduce((sum: number, l: any) => sum + Number(l.amount ?? Number(l.qty) * Number(l.unitPrice)), 0);
    const saved = saveRow('purchaseOrders', { ...data, lines, status: data.status ?? 0, receivedQty: 0, totalAmount: money(total), supplierName: data.supplierName || findRow('suppliers', data.supplierId)?.name || '' });
    const stored = findRow('purchaseOrders', saved.id);
    if (stored) stored.orderNo = makeNo('PO', stored.id);
    saveDb(); return clone(stored || saved);
  }
  if (path === '/purchase/orders' && m === 'GET') {
    const r = listResult('purchaseOrders', params);
    const all = table('purchaseOrders');
    r.summary = { orderCount: all.length, totalAmount: money(all.reduce((s, o) => s + Number(o.totalAmount || 0), 0)), todayAmount: money(all.reduce((s, o) => s + Number(o.totalAmount || 0), 0)) };
    return r;
  }
  if (parts[0] === 'purchase' && parts[1] === 'orders' && parts[2] && !parts[3] && m === 'GET') return clone(findRow('purchaseOrders', parts[2]) || {});
  if (parts[0] === 'purchase' && parts[1] === 'orders' && parts[3]) return purchaseAction(Number(parts[2]), parts[3], data);
  if (path === '/purchase/suppliers') return listResult('suppliers', params);

  // ---- 财务 ----
  if (path === '/finance/subjects') return m === 'POST' ? saveRow('subjects', data) : clone(table('subjects'));
  if (path === '/finance/accounts') return m === 'POST' ? saveRow('accounts', data) : clone(table('accounts'));
  if (path === '/finance/vouchers' && m === 'POST') {
    const debit = Number(data.debit || 0), credit = Number(data.credit || 0);
    if (Math.abs(debit - credit) > 0.005) throw new Error('借贷不平衡，凭证无法保存');
    return saveRow('vouchers', { ...data, voucherNo: data.voucherNo || makeNo('VCH', nextId('vouchers')), totalDebit: money(debit), totalCredit: money(credit), status: data.status ?? 0 });
  }
  if (path === '/finance/vouchers' && m === 'GET') {
    const r = listResult('vouchers', params);
    // 拼接分录明细与科目名称，供凭证列表展开查看（否则 entries 永远为空）
    r.list = r.list.map((v: any) => ({
      ...v,
      entries: table('voucherEntries').filter((e: any) => Number(e.voucherId) === Number(v.id)).map((e: any) => ({
        ...e, subjectName: findRow('subjects', e.subjectId)?.name || e.subjectId,
      })),
    }));
    return r;
  }
  if (parts[0] === 'finance' && parts[1] === 'vouchers' && parts[3] === 'post') {
    const v = findRow('vouchers', parts[2]);
    if (!v) throw new Error('凭证不存在');
    if (Number(v.status) === 2) throw new Error('已作废凭证不可过账');
    if (Number(v.status) === 1) throw new Error('已过账凭证不可重复过账');
    v.status = 1;
    writeAudit('financeVouchers', 'post', v.id, `凭证过账 ${v.voucherNo || v.id}`);
    saveDb(); return { ...clone(v), ok: true, message: '凭证已过账' };
  }
  // 凭证作废（软删除）：草稿可直接作废；已过账需先红字冲销，避免账实不符。
  if (parts[0] === 'finance' && parts[1] === 'vouchers' && parts[3] === 'void') {
    const v = findRow('vouchers', parts[2]);
    if (!v) throw new Error('凭证不存在');
    if (Number(v.status) === 2) return { ...clone(v), message: '凭证已作废' };
    if (Number(v.status) === 1) throw new Error('已过账凭证不可直接作废，请先红字冲销');
    v.status = 2;
    writeAudit('financeVouchers', 'void', v.id, `凭证作废 ${v.voucherNo || v.id}（软删除，记录保留）`);
    saveDb(); return { ...clone(v), message: '凭证已作废（记录保留可追溯）' };
  }
  if (parts[0] === 'finance' && parts[1] === 'periods' && parts[3] === 'close') { const p = table('periods').find((x) => x.period === parts[2]); if (p) p.closed = 1; saveDb(); return { ok: true }; }
  if (parts[0] === 'finance' && parts[1] === 'periods' && parts[3] === 'open') { const p = table('periods').find((x) => x.period === parts[2]); if (p) p.closed = 0; saveDb(); return { ok: true }; }
  if (path === '/finance/receivables') return displayRows('financeReceivables', listResult('receivables', params).list);
  if (path === '/finance/trial-balance') {
    // 从已过账凭证分录汇总真实借贷发生额，替代写死数值
    const agg: Record<number, { debit: number; credit: number }> = {};
    for (const e of table('voucherEntries')) {
      const v = table('vouchers').find((x) => Number(x.id) === Number(e.voucherId) && Number(x.status) === 1);
      if (!v) continue;
      const a = agg[e.subjectId] ||= { debit: 0, credit: 0 };
      a.debit += Number(e.debit || 0); a.credit += Number(e.credit || 0);
    }
    return clone(table('subjects').map((s) => ({ subjectCode: s.code, subjectName: s.name, debit: money(agg[s.id]?.debit || 0), credit: money(agg[s.id]?.credit || 0) })));
  }
  if (path === '/finance/receivable-aging') {
    const today = new Date(); today.setHours(0, 0, 0, 0);
    return clone(table('receivables').map((r) => {
      const unpaid = Number(r.amount) - Number(r.receivedAmount);
      const due = r.dueDate ? new Date(r.dueDate + 'T00:00:00') : today;
      const daysOver = Math.floor((today.getTime() - due.getTime()) / 86400000);
      const bucket = daysOver <= 0 ? 'notDue' : daysOver <= 30 ? 'd1_30' : daysOver <= 90 ? 'd31_90' : 'd90';
      return { ...r, unpaid: money(unpaid), aging: bucket === 'notDue' ? '未到期' : bucket === 'd1_30' ? '1-30天' : bucket === 'd31_90' ? '31-90天' : '90天以上', notDue: bucket === 'notDue' ? unpaid : 0, d1_30: bucket === 'd1_30' ? unpaid : 0, d31_90: bucket === 'd31_90' ? unpaid : 0, d90: bucket === 'd90' ? unpaid : 0 };
    }));
  }
  if (path === '/finance/payables') {
    // 桥接采购中心应付（industryPayables）与财务应付（payables），消除两套数据互不可见的断点
    const base = clone(table('payables'));
    const extra = table('industryPayables')
      .filter((ip) => !base.some((b) => String(b.orderNo) === String(ip.orderNo) && Number(b.amount) === Number(ip.amount)))
      .map((ip) => ({ ...clone(ip), sourceType: ip.sourceType || 'PURCHASE', status: 1 }));
    return [...base, ...extra];
  }
  if (path === '/finance/profit-loss') {
    // 从已过账凭证按科目汇总收入(6001 id=11)与成本(6401 id=12)，保证报表随业务数据变化
    const posted = (e: any) => table('vouchers').some((v) => Number(v.id) === Number(e.voucherId) && Number(v.status) === 1);
    const income = table('voucherEntries').filter((e) => Number(e.subjectId) === 11 && posted(e)).reduce((s, e) => s + Number(e.credit || 0) - Number(e.debit || 0), 0);
    const cost = table('voucherEntries').filter((e) => Number(e.subjectId) === 12 && posted(e)).reduce((s, e) => s + Number(e.debit || 0) - Number(e.credit || 0), 0);
    return [{ item: '主营业务收入', name: '主营业务收入', amount: money(income) }, { item: '主营业务成本', name: '主营业务成本', amount: money(cost) }, { item: '净利润', name: '净利润', amount: money(income - cost) }];
  }
  // 深度财务报表：按真实凭证/单据/库存计算，替代 DeepReports 前端写死的 demo 数据
  if (parts[0] === 'finance' && parts[1] === 'reports' && parts[2]) {
    const posted = (e: any) => table('vouchers').some((v) => Number(v.id) === Number(e.voucherId) && Number(v.status) === 1);
    if (parts[2] === 'cash-flow') {
      const inCash = table('voucherEntries').filter((e) => [1, 2].includes(Number(e.subjectId)) && posted(e)).reduce((s, e) => s + Number(e.debit || 0) - Number(e.credit || 0), 0);
      const saleIn = table('saleOrders').reduce((s, o) => s + Number(o.paidAmount || 0), 0);
      const payOut = table('purchaseOrders').reduce((s, o) => s + Number(o.paidAmount || 0), 0);
      return [
        { 项目: '销售商品收到的现金', 本月金额: money(saleIn), 本年累计: money(saleIn), 说明: '销售单已收款汇总' },
        { 项目: '购买商品支付的现金', 本月金额: money(payOut), 本年累计: money(payOut), 说明: '采购单已付款汇总' },
        { 项目: '经营活动现金流量净额', 本月金额: money(saleIn - payOut), 本年累计: money(saleIn - payOut), 说明: inCash >= 0 ? '经营净流入' : '经营净流出' },
      ];
    }
    if (parts[2] === 'subject-balance') {
      const agg: Record<number, { d: number; c: number }> = {};
      for (const e of table('voucherEntries')) {
        if (!posted(e)) continue;
        const a = agg[e.subjectId] ||= { d: 0, c: 0 };
        a.d += Number(e.debit || 0); a.c += Number(e.credit || 0);
      }
      return table('subjects').map((s) => {
        const a = agg[s.id] || { d: 0, c: 0 };
        const bal = s.direction === 2 ? a.c - a.d : a.d - a.c;
        return { 科目编码: s.code, 科目名称: s.name, 期初借方: '0.00', 本期借方: money(a.d), 本期贷方: money(a.c), 期末余额: money(bal) };
      });
    }
    if (parts[2] === 'ledger' || parts[2] === 'subject-ledger') {
      return table('vouchers').filter((v) => Number(v.status) === 1).flatMap((v) =>
        table('voucherEntries').filter((e) => Number(e.voucherId) === Number(v.id)).map((e) => ({
          日期: v.voucherDate, 凭证号: v.voucherNo, 摘要: e.summary || v.summary,
          科目: (table('subjects').find((s) => Number(s.id) === Number(e.subjectId))?.code || '') + ' ' + (table('subjects').find((s) => Number(s.id) === Number(e.subjectId))?.name || ''),
          借方: e.debit || 0, 贷方: e.credit || 0, 余额: '',
        })));
    }
    if (parts[2] === 'profit-center') {
      const centers = table('orgs').filter((o) => /销售部|采购部/.test(o.name || ''));
      const totalSale = table('saleOrders').reduce((s, o) => s + Number(o.totalAmount || 0), 0);
      return centers.map((o) => {
        const share = /销售部/.test(o.name) ? 1 : 0.4;
        const income = totalSale * share, cost = income * 0.68, exp = income * 0.07;
        return { 中心: o.name, 收入: money(income), 成本: money(cost), 费用: money(exp), 利润: money(income - cost - exp), 利润率: ((income - cost - exp) / (income || 1) * 100).toFixed(1) + '%' };
      });
    }
  }
  if (path === '/finance/payments' && m === 'POST') {
    const pay = saveRow('payments', { ...data, payNo: makeNo('PAY', nextId('payments')), status: 0 });
    return clone(pay);
  }
  // 采购中心付款记录：保存时同步生成付款凭证，打通「采购付款 → 财务凭证」
  if (path === '/industry/purchasePayments' && m === 'POST') {
    const saved = saveRow('purchasePayments', { ...data, no: data.no || makeNo('PAY', nextId('purchasePayments')) });
    if (Number(data.amount) > 0) {
      makeVoucher(`采购付款 ${data.orderNo || saved.no}`, [
        { subjectId: subjectId(SUBJECT.AP), debit: money(data.amount), credit: 0, summary: '应付账款' },
        { subjectId: subjectId(SUBJECT.BANK), debit: 0, credit: money(data.amount), summary: '银行存款' },
      ], 'PURCHASE_PAY', saved.id);
    }
    return clone(saved);
  }
  if (parts[0] === 'finance' && parts[1] === 'payments' && parts[3] === 'confirm') {
    const pay = findRow('payments', parts[2]);
    if (pay && Number(pay.status) !== 1) {
      pay.status = 1;
      if (pay.receivableId) {
        const r = findRow('receivables', Number(pay.receivableId));
        if (r) {
          r.receivedAmount = money(Number(r.receivedAmount) + Number(pay.amount));
          // 闭环：回写来源销售单的已收金额与收款状态
          if (r.sourceType === 'SALE' && r.sourceId) {
            const so = findRow('saleOrders', Number(r.sourceId));
            if (so) {
              so.paidAmount = money(Number(so.paidAmount || 0) + Number(pay.amount));
              so.payStatus = Number(so.paidAmount) >= Number(so.totalAmount) ? 2 : 1;
            }
          }
        }
      }
      if (pay.payableId) {
        const p = findRow('payables', Number(pay.payableId));
        if (p) {
          p.paidAmount = money(Number(p.paidAmount) + Number(pay.amount));
          // 闭环：回写来源采购单的已付金额
          if (p.sourceType === 'PURCHASE' && p.sourceId) {
            const po = findRow('purchaseOrders', Number(p.sourceId));
            if (po) po.paidAmount = money(Number(po.paidAmount || 0) + Number(pay.amount));
          }
        }
      }
      makeVoucher(`收付款 ${pay.payNo}`, pay.type === 'IN'
        ? [{ subjectId: subjectId(SUBJECT.BANK), debit: money(pay.amount), credit: 0, summary: '银行存款' },
           { subjectId: subjectId(SUBJECT.AR), debit: 0, credit: money(pay.amount), summary: '应收账款' }]
        : [{ subjectId: subjectId(SUBJECT.AP), debit: money(pay.amount), credit: 0, summary: '应付账款' },
           { subjectId: subjectId(SUBJECT.BANK), debit: 0, credit: money(pay.amount), summary: '银行存款' }], 'PAYMENT', pay.id);
      saveDb();
    }
    return { ok: true };
  }

  // ---- 打印中心 ----
  if (path === '/print/templates' && m === 'GET') return listResult('printTemplates', params);
  if (path === '/print/templates' && m === 'POST') return saveRow('printTemplates', data);
  if (parts[0] === 'print' && parts[1] === 'templates' && parts[3] === 'preview') return { html: `<h2>${findRow('printTemplates', parts[2])?.name || '打印预览'}</h2><p>数据已绑定，可导出 PDF 或静默打印。</p>` };
  if (path === '/print/jobs' && m === 'POST') {
    const record = saveRow('printRecords', { ...data, bizNo: data.bizNo || `BIZ-${data.bizId || 0}`, templateId: data.templateId || 1, copies: data.copies || 1, channel: data.channel || 'SERVER_PDF', printedBy: 1, printedAt: now(), ip: '127.0.0.1', watermark: '演示数据', pdfUrl: '' });
    return { ...clone(record), jobId: record.id, message: '打印任务已完成，可在打印记录补打' };
  }
  if (path === '/print/records') return listResult('printRecords', params);
  if (path === '/print/labels') { const r = saveRow('printRecords', { bizType: 'LABEL', bizNo: 'LABEL-BATCH', copies: data.lines?.length || 1, channel: 'hiprint', printedBy: 1, printedAt: now() }); return { ...clone(r), message: '标签任务已生成' }; }

  // ---- AI 中枢 ----
  if (path === '/ai/copilot') { const r = aiRule(data.message); table('aiAudits').push({ id: nextId('aiAudits'), capability: 'ai.copilot', userId: 1, model: 'local-rule', promptTokens: 0, completionTokens: 0, latencyMs: 12, accepted: 0, fallback: 1, request: data.message, response: r.text, createdAt: now() }); saveDb(); return r; }
  if (path === '/ai/doc-parse') return { fields: { customerName: '蓝天实业有限公司', date: now().slice(0, 10), items: [{ productName: 'A4 复印纸', qty: 10, price: 26 }] }, fallback: true, text: '已从文档中抽取字段，请在表单中确认' };
  if (path === '/ai/ocr') return { fields: { invoiceNo: 'INV20261117001', amount: '1280.00', seller: '得力集团' }, fallback: true, text: '规则兜底：请人工核对识别结果' };
  if (path === '/ai/recommend') return aiRule('补货建议');
  if (path === '/ai/forecast/run') {
    const r = aiRule('预测补货');
    for (const it of r.items || []) table('forecastResults').push({ id: nextId('forecastResults'), productCode: it.productCode, productName: it.productName, period: '2026-12', predictQty: it.predictQty, suggestPurchaseQty: it.suggestPurchaseQty, model: 'local-rule', reason: it.reason, createdAt: now() });
    saveDb(); return r;
  }
  if (path === '/ai/forecast/result') return listResult('forecastResults', params);
  if (path === '/ai/anomaly/scan') return { risks: clone(table('alerts').map((a) => ({ level: a.level, type: a.type, detail: a.message }))) };
  if (path === '/ai/reconcile') return { differences: [{ field: '金额', ours: 12800, theirs: 12800, diff: 0 }, { field: '数量', ours: 10, theirs: 9, diff: -1 }], text: '已按金额/数量/日期模糊匹配，发现 1 条数量差异' };
  if (path === '/ai/subject-match') {
    const s = String(data.summary || '');
    const hit = s.includes('办公') || s.includes('差旅') ? { code: '6602', name: '管理费用' } : s.includes('采购') ? { code: '1405', name: '库存商品' } : { code: '6001', name: '主营业务收入' };
    return { ...hit, confidence: 0.8, source: '本地规则' };
  }
  if (path === '/ai/report/insight') return { text: `经营诊断（本地规则）：今日销售 ${data.metrics?.今日销售 || 0} 元，应收未收 ${data.metrics?.应收未收 || 0} 元，库存预警 ${data.metrics?.库存预警 || 0} 项。建议优先处理高金额逾期应收与低库存商品，并对毛利率低于 15% 的订单复核报价。`, fallback: true };
  if (path === '/ai/rag/query') return { text: `根据知识库《ERP 操作手册》：${String(data.question || '')} 可参考标准业务流程处理。`, sources: 'ERP 操作手册', fallback: true };
  if (path === '/ai/rag/upload') return { ok: true, docId: nextId('ragDocs'), name: data.name || '知识文档', chunks: Array.isArray(data.chunks) ? data.chunks.length : 1, message: '文档已入库（本地规则），可供 RAG 检索', fallback: true };
  if (path === '/ai/audits') return clone(table('aiAudits').slice().reverse().slice(0, 100));
  if (path === '/ai/prompts' && m === 'GET') return clone(table('aiPrompts'));
  if (path === '/ai/prompts' && m === 'POST') return saveRow('aiPrompts', { ...data, version: Number(data.version || 1) + 1, isActive: 1 });

  // AI 能力配置：模型 / Function 工具 / MCP Server
  if (path === '/ai/models') {
    if (m === 'GET') {
      if (!table('aiModels').length) {
        [
          { id: 1, name: 'local-rule', provider: 'LOCAL', endpoint: '内置规则引擎', contextLength: 0, temperature: 0, isActive: 1, isDefault: 1, health: 'HEALTHY' },
          { id: 2, name: 'qwen-plus', provider: 'ALIYUN', endpoint: 'https://dashscope.aliyuncs.com/compatible-mode/v1', contextLength: 32768, temperature: 0.3, isActive: 1, isDefault: 0, health: 'UNCONFIGURED' },
          { id: 3, name: 'gpt-4o-mini', provider: 'OPENAI', endpoint: 'https://api.openai.com/v1', contextLength: 128000, temperature: 0.3, isActive: 0, isDefault: 0, health: 'UNCONFIGURED' },
        ].forEach((row) => table('aiModels').push(row));
        saveDb();
      }
      return clone(table('aiModels'));
    }
    return saveRow('aiModels', data);
  }
  if (path === '/ai/functions') {
    if (m === 'GET') {
      if (!table('aiFunctions').length) {
        [
          { id: 1, name: 'query_stock', description: '查询产品库存可用量', schema: '{"productId":"number"}', endpoint: '/api/v1/inventory/balance', perm: 'inventory:view', isActive: 1 },
          { id: 2, name: 'create_sale_order', description: '创建销售草稿单', schema: '{"customerId":"number","lines":"array"}', endpoint: '/api/v1/sales/orders', perm: 'sales:order:create', isActive: 1 },
          { id: 3, name: 'query_receivable', description: '查询客户应收与账龄', schema: '{"customerId":"number"}', endpoint: '/api/v1/finance/receivables', perm: 'finance:view', isActive: 1 },
        ].forEach((row) => table('aiFunctions').push(row));
        saveDb();
      }
      return clone(table('aiFunctions'));
    }
    return saveRow('aiFunctions', data);
  }
  if (path && path.startsWith('/ai/functions/') && path.endsWith('/test') && m === 'POST') {
    return { ok: true, result: { code: 0, message: '模拟调用成功', data: { productId: 1, available: 128 } }, latencyMs: 42 };
  }
  if (path === '/ai/mcp/servers') {
    if (m === 'GET') {
      if (!table('aiMcpServers').length) {
        [
          { id: 1, name: 'erp-local', transport: 'STDIO', endpoint: 'local://erp-tools', capabilities: ['tools', 'resources'], status: 'CONNECTED' },
          { id: 2, name: 'filesystem', transport: 'STDIO', endpoint: 'npx -y @modelcontextprotocol/server-filesystem', capabilities: ['tools'], status: 'AVAILABLE' },
        ].forEach((row) => table('aiMcpServers').push(row));
        saveDb();
      }
      return clone(table('aiMcpServers'));
    }
    return saveRow('aiMcpServers', data);
  }
  if (path === '/ai/mcp/call' && m === 'POST') return { ok: true, content: [{ type: 'text', text: `MCP 工具 ${data.tool || 'query'} 模拟返回：执行成功` }], latencyMs: 68 };
  if (path === '/ai/label') return { name: '品牌无线鼠标', categoryId: 2, code: 'P-NEW01', price: 79, fallback: true, fields: {} };
  if (path === '/ai/cs') {
    const question = String(data.question || '');
    const price = /价|报价|多少钱/.test(question) ? '参考报价：标准版 ￥299，专业版 ￥699，含税另加 13%。' : '';
    return { text: `您好！关于「${question}」，${price || '我们可为您提供标准固件支持与 7×12 小时服务。'}如需人工协助请联系销售顾问。`, quote: price ? 299 : null, fallback: true };
  }
  if (path === '/ai/resume') {
    const text = String(data.text || '');
    const phones = text.match(/1[3-9]\d{9}/);
    return { name: (text.match(/姓名[:：]?\s*([\u4e00-\u9fa5]{2,4})/) || [])[1] || '待确认', phone: phones ? phones[0] : '', skills: (text.match(/熟悉|精通([\u4e00-\u9fa5、A-Za-z+#.]{2,40})/) || [])[1] || '待提取', experience: /年.*经验/.test(text) ? '有工作经验' : '待确认', fallback: true };
  }

  // ---- BPM / BI / CRM / WMS / MES / 商城 / 移动端 ----
  if (path === '/bpm/definitions') return m === 'POST' ? saveRow('bpmDefs', data) : clone(table('bpmDefs'));
  // 主动发起流程：建实例 + 解析节点 + 生成首节点待办（不再只写一条 RUNNING）
  if (path === '/bpm/start') {
    const ctx = data.context || { amount: Number(data.amount || 0), department: data.department || '', product: data.product || '', days: Number(data.days || 0) };
    const inst = startApproval(String(data.bizType || 'CUSTOM'), data.bizId ?? Date.now(), String(data.bizNo || data.title || '手动发起'), ctx);
    return { ok: true, instanceId: inst.id, message: `流程已发起（实例 #${inst.id}，${(inst.nodePlan || []).length} 个节点）` };
  }
  if (path === '/bpm/tasks/todo') return clone(table('bpmTasks').filter((t) => t.status === 'TODO'));
  if (path === '/bpm/tasks/done') return clone(table('bpmDone'));
  if (parts[0] === 'bpm' && parts[1] === 'tasks' && parts[3] === 'handle') {
    const task = findRow('bpmTasks', parts[2]);
    if (!task) throw new Error('审批任务不存在');
    if (task.status !== 'TODO') throw new Error('该任务已处理，请勿重复审批');
    const msg = handleBpmTask(task, data);
    return { ok: true, message: msg };
  }
  if (parts[0] === 'bpm' && parts[1] === 'tasks' && parts[3] === 'cancel') {
    const task = findRow('bpmTasks', parts[2]);
    if (!task) throw new Error('审批任务不存在');
    return { ok: true, message: handleBpmTask(task, { action: 'CANCEL', comment: data.comment }) };
  }
  if (parts[0] === 'bpm' && parts[1] === 'tasks' && parts[3] === 'transfer') {
    const task = findRow('bpmTasks', parts[2]);
    if (!task) throw new Error('审批任务不存在');
    return { ok: true, message: handleBpmTask(task, { action: 'TRANSFER', assignee: data.assignee }) };
  }
  // 实例详情：附带当前节点待办，供审批中心展示进度
  if (parts[0] === 'bpm' && parts[1] === 'instances' && parts[3] === 'tasks') {
    return clone(table('bpmTasks').filter((t) => Number(t.instanceId) === Number(parts[2])));
  }
  if (parts[0] === 'bpm' && parts[1] === 'instances' && parts[3] === 'logs') return clone(table('bpmLogs').filter((l) => Number(l.instanceId) === Number(parts[2])));
  if (parts[0] === 'bpm' && parts[1] === 'instances' && parts[2]) return findRow('bpmInstances', parts[2]) || {};
  if (path === '/bpm/delegations') return m === 'POST' ? saveRow('bpmDelegations', data) : clone(table('bpmDelegations'));

  if (path === '/bi/reports') return m === 'POST' ? saveRow('biReports', data) : clone(table('biReports'));
  /** BI 实时取数引擎：按报表定义的维度/指标，从真实销售单/库存聚合，替代写死的演示行 */
  if ((parts[0] === 'bi' && parts[1] === 'reports' && parts[3] === 'run') || path === '/bi/preview-run') {
    const rpt: any = path === '/bi/preview-run' ? data : (findRow('biReports', parts[2]) || {});
    const dims: any[] = rpt.dims || [];
    const meas: any[] = rpt.measures || [];
    const orders = table('saleOrders');
    const dimCode = dims[0]?.code || 'month';
    const dimName = dims[0]?.name || '月份';
    // 按维度分组键
    const groupKey = (o: any): string => {
      if (dimCode === 'customer') return String(o.customerName || '未指定');
      if (dimCode === 'product') return String(o.productName || o.lines?.[0]?.productName || '未指定');
      if (dimCode === 'warehouse') return String(o.warehouseName || '主仓库');
      if (dimCode === 'salesman') return String(o.salesman || o.buyer || '未指定');
      const d = String(o.orderDate || '').slice(0, 7);
      return d ? `${Number(d.slice(0, 4))}年${Number(d.slice(5, 7))}月` : '未指定';
    };
    const groups: Record<string, any[]> = {};
    for (const o of orders) (groups[groupKey(o)] ||= []).push(o);
    const keys = Object.keys(groups).sort();
    const out = keys.map((k) => {
      const os = groups[k];
      const row: any = { [dimName]: k };
      for (const m of meas) {
        const c = m.code;
        if (c === 'saleAmount') row[m.name] = money(os.reduce((s, o) => s + Number(o.totalAmount || 0), 0));
        else if (c === 'paidAmount') row[m.name] = money(os.reduce((s, o) => s + Number(o.paidAmount || 0), 0));
        else if (c === 'profit') row[m.name] = money(os.reduce((s, o) => s + Number(o.totalAmount || 0) * 0.28, 0));
        else if (c === 'purchaseAmount') row[m.name] = money(table('purchaseOrders').reduce((s, o) => s + Number(o.totalAmount || 0), 0));
        else if (c === 'stockQty') row[m.name] = table('products').reduce((s, p) => s + Number(p.stockQty || p.qty || 0), 0);
        else row[m.name] = os.length;
      }
      return row;
    });
    if (out.length) return out;
    // 无销售单时按产品库存出一份真实库存视图，避免空白
    return table('products').slice(0, 8).map((p) => {
      const row: any = { [dimName]: p.name };
      for (const m of meas) row[m.name] = m.code === 'stockQty' ? Number(p.stockQty || p.qty || 0) : 0;
      return row;
    });
  }
  if (path === '/bi/dashboard') {
    const today = new Date().toISOString().slice(0, 10);
    const todaySale = table('saleOrders').filter((o) => String(o.orderDate || '').slice(0, 10) === today).reduce((s, o) => s + Number(o.totalAmount || 0), 0);
    const receivable = table('receivables').reduce((s, r) => s + Number(r.amount || 0) - Number(r.receivedAmount || 0), 0);
    const alerts = table('products').filter((p) => Number(p.stockQty || p.qty || 0) < Number(p.safetyStock || 20)).length;
    return [
      { 指标: '今日销售', 数值: money(todaySale) },
      { 指标: '库存预警', 数值: String(alerts) },
      { 指标: '应收未收', 数值: money(receivable) },
      { 指标: '待办', 数值: String(table('bpmTasks').length) },
    ];
  }
  if (path === '/bi/subscriptions') return m === 'POST' ? saveRow('biSubscriptions', data) : clone(table('biSubscriptions'));

  if (path === '/crm/customers') return m === 'POST' ? saveRow('customers', data) : listResult('customers', params);
  if (path === '/crm/leads' && m === 'POST') return saveRow('leads', { ...data, score: Math.floor(60 + Math.random() * 40), status: 'NEW' });
  if (path === '/crm/leads') return listResult('leads', params);
  if (parts[0] === 'crm' && parts[1] === 'leads' && parts[3] === 'convert') {
    const lead = findRow('leads', parts[2]);
    if (lead) { saveRow('customers', { name: data.customerName || lead.company, code: `C${nextId('customers')}`, level: 'C', phone: lead.phone }); lead.status = 'CONVERTED'; saveDb(); }
    return { ok: true, message: '已转化为客户' };
  }
  if (path === '/crm/opportunities') return m === 'POST' ? saveRow('opportunities', data) : clone(table('opportunities'));
  if (path === '/crm/follows') return m === 'POST' ? saveRow('follows', { ...data, createdAt: now() }) : clone(table('follows').filter((f) => f.bizType === params.bizType && Number(f.bizId) === Number(params.bizId)));
  if (path === '/crm/quotations') return m === 'POST' ? saveRow('quotations', data) : clone(table('quotations'));
  if (parts[0] === 'crm' && parts[1] === 'quotations' && parts[3] === 'accept') { const q = findRow('quotations', parts[2]); if (q) q.status = '已接受'; saveDb(); return { ok: true }; }

  if (path === '/wms/putaways') return m === 'POST' ? saveRow('putaways', data) : clone(table('putaways'));
  if (parts[0] === 'wms' && parts[1] === 'putaways' && parts[3] === 'confirm') { const p = findRow('putaways', parts[2]); if (p) p.status = '已上架'; saveDb(); return { ok: true }; }
  if (path === '/wms/waves' && m === 'POST') { const w = saveRow('waves', { ...data, waveNo: makeNo('WV', nextId('waves')), status: '待拣货' }); table('waveLines').push({ id: nextId('waveLines'), waveId: w.id, productName: 'A4 复印纸', planQty: 10, pickedQty: 0 }); saveDb(); return { ...clone(w), lineCount: 1 }; }
  if (path === '/wms/waves') return clone(table('waves'));
  if (parts[0] === 'wms' && parts[1] === 'waves' && parts[3] === 'lines') return clone(table('waveLines').filter((l) => Number(l.waveId) === Number(parts[2])));
  if (parts[0] === 'wms' && parts[1] === 'waves' && parts[5] === 'pick') { const l = findRow('waveLines', parts[4]); if (l) { l.pickedQty = Number(l.pickedQty) + Number(data.qty || 1); if (l.pickedQty >= l.planQty) l.status = '已拣完'; } saveDb(); return { ok: true }; }
  if (path === '/wms/stocktakes' && m === 'POST') { const s = saveRow('stocktakes', { ...data, takeNo: makeNo('ST', nextId('stocktakes')), status: '进行中' }); return clone(s); }
  if (path === '/wms/stocktakes') return clone(table('stocktakes'));
  if (parts[0] === 'wms' && parts[1] === 'stocktakes' && parts[3] === 'lines') return clone(table('stocktakeLines').filter((l) => Number(l.stocktakeId) === Number(parts[2])));
  if (parts[0] === 'wms' && parts[1] === 'stocktake-lines' && parts[3] === 'real') {
    const l = findRow('stocktakeLines', parts[2]);
    if (l) { l.realQty = Number(data.realQty); l.diffQty = Number((l.realQty - l.bookQty).toFixed(3)); }
    saveDb(); return clone(l);
  }
  if (parts[0] === 'wms' && parts[1] === 'stocktakes' && parts[3] === 'finish') {
    const s = findRow('stocktakes', parts[2]);
    if (s && s.status === '已完成') throw new Error('该盘点单已完成，请勿重复过账');
    let diffLines = 0;
    for (const l of table('stocktakeLines').filter((x) => Number(x.stocktakeId) === Number(parts[2]) && Number(x.diffQty) !== 0)) {
      postStock(Number(l.productId), Number(s?.warehouseId || 1), 'ADJUST', Number(l.diffQty), 0, Number(parts[2]));
      l.diffQty = 0;
      diffLines++;
    }
    if (s) s.status = '已完成'; saveDb(); return { ok: true, diffLines, message: `已完成，${diffLines} 行差异已过账` };
  }
  if (path === '/wms/transfers') return m === 'POST' ? saveRow('transfers', { ...data, status: '待调拨' }) : clone(table('transfers'));
  if (parts[0] === 'wms' && parts[1] === 'transfers' && parts[3] === 'execute') {
    const t = findRow('transfers', parts[2]);
    if (!t) throw new Error('调拨单不存在');
    if (t.status === '已完成') throw new Error('该调拨单已完成，请勿重复执行');
    const src = table('balance').find((b) => Number(b.productId) === Number(t.productId) && Number(b.warehouseId) === Number(t.fromWarehouseId));
    const available = Number(src?.qtyOnHand || 0) - Number(src?.qtyOccupied || 0);
    if (available < Number(t.qty)) throw new Error(`源仓可用库存不足（可用 ${available}，需调拨 ${t.qty}）`);
    postStock(Number(t.productId), Number(t.fromWarehouseId), 'TRANSFER_OUT', -Number(t.qty), 0, t.id);
    postStock(Number(t.productId), Number(t.toWarehouseId), 'TRANSFER_IN', Number(t.qty), 0, t.id);
    t.status = '已完成'; saveDb(); return { ok: true };
  }
  if (path === '/wms/crossdocks') return m === 'POST' ? saveRow('crossdocks', data) : clone(table('crossdocks'));

  if (path === '/mes/routings') return m === 'POST' ? saveRow('routings', data) : clone(table('routings').filter((r) => !params.productId || Number(r.productId) === Number(params.productId)));
  if (path === '/mes/mrp/run') {
    const suggests: any[] = [];
    for (const b of table('balance')) {
      const product = findRow('products', b.productId) || {};
      const available = Number(b.qtyOnHand) - Number(b.qtyOccupied);
      const safe = Number(product.safeQty || 20);
      if (available < safe) suggests.push({ id: suggests.length + 1, productId: b.productId, productName: product.name, demandQty: safe, availableQty: available, onWayQty: 0, netQty: safe - available, suggestType: 'PURCHASE' });
    }
    const run = saveRow('mrpRuns', { runNo: makeNo('MRP', nextId('mrpRuns')), source: data.source || 'MANUAL', productCount: suggests.length, createdAt: now() });
    for (const s of suggests) { table('mrpSuggests').push({ ...s, runId: run.id }); }
    saveDb(); return { ...clone(run), productCount: suggests.length };
  }
  if (path === '/mes/mrp/runs') return clone(table('mrpRuns').slice().reverse());
  if (path === '/mes/mrp/suggests') return clone(table('mrpSuggests').filter((s) => Number(s.runId) === Number(params.runId)));
  if (path === '/mes/workorders') return m === 'POST' ? saveRow('workOrders', { ...data, status: data.status || '计划' }) : clone(table('workOrders'));
  if (parts[0] === 'mes' && parts[1] === 'workorders' && parts[3]) {
    const w = findRow('workOrders', parts[2]);
    const act = parts[3];
    if (!w) throw new Error('工单不存在');
    if (act === 'issue') {
      if (['ISSUED', 'REPORTED', 'FINISHED', 'CLOSED'].includes(w.status)) throw new Error('该工单已领料，请勿重复领料');
      w.status = 'ISSUED';
      // 领料出库：按工单 BOM 明细逐行扣减原料库存，无明细时按工单产品等量领用
      const issues: any[] = Array.isArray(w.materials) && w.materials.length
        ? w.materials
        : [{ productId: w.productId || 1, qty: Number(w.qty || w.planQty || 0) }];
      for (const it of issues) {
        const need = Number(it.qty || 0);
        const bal = table('balance').find((b) => Number(b.productId) === Number(it.productId));
        if (!bal || Number(bal.qtyOnHand) < need) throw new Error(`领料失败：产品 ${it.productId} 库存不足`);
        postStock(Number(it.productId), Number(w.warehouseId || 1), 'ISSUE_OUT', -need, Number(bal.avgCost || 0), w.id);
      }
    }
    else if (act === 'report') w.status = 'REPORTED';
    else if (act === 'finish' || act === 'complete') {
      if (w.status === 'FINISHED' || w.status === 'CLOSED') throw new Error('工单已完工，请勿重复入库');
      // 按实际报工累计产量入库，不再用计划量全额入库；成本取当前加权成本避免摊薄
      const produced = Number(w.producedQty || w.finishedQty || w.qty || w.planQty || 0);
      w.status = 'FINISHED'; w.finishedQty = produced; w.producedQty = produced;
      const bal = table('balance').find((b) => Number(b.productId) === Number(w.productId || 1));
      postStock(Number(w.productId || 1), Number(w.warehouseId || 1), 'FINISH_IN', produced, Number(bal?.avgCost || 0), w.id);
    } else if (act === 'close') { if (w.status !== 'FINISHED') throw new Error('工单未完工，不可关闭'); w.status = 'CLOSED'; }
    else if (act === 'reopen') w.status = 'DRAFT';
    saveDb(); return { ok: true, status: w.status };
  }
  if (path === '/mes/reports') return m === 'POST' ? saveRow('mesReports', data) : clone(table('mesReports').filter((r) => !params.workorderId || Number(r.workorderId) === Number(params.workorderId)));
  if (path === '/mes/qc') return m === 'POST' ? saveRow('qc', data) : clone(table('qc'));
  if (path === '/mes/equipments') return m === 'POST' ? saveRow('equipments', data) : clone(table('equipments'));

  if (path === '/shop/stores') return m === 'POST' ? saveRow('stores', data) : clone(table('stores'));
  if (path === '/shop/goods-maps') return m === 'POST' ? saveRow('goodsMaps', data) : clone(table('goodsMaps').filter((g) => !params.storeId || Number(g.storeId) === Number(params.storeId)));
  if (path === '/shop/orders' && m === 'GET') return listResult('shopOrders', params);
  if (parts[0] === 'shop' && parts[1] === 'stores' && parts[3] === 'sync') {
    let created = 0;
    for (const o of data.orders || []) { table('shopOrders').push({ ...o, id: nextId('shopOrders'), storeId: Number(parts[2]), status: '待发货' }); created++; }
    saveDb(); return { created };
  }
  if (parts[0] === 'shop' && parts[1] === 'orders' && parts[3] === 'convert') {
    const o = findRow('shopOrders', parts[2]);
    if (o) {
      const s = saveRow('saleOrders', { customerId: 1, customerName: o.buyer, warehouseId: 1, orderDate: now(), status: 2, payStatus: 2, shipStatus: 0, totalAmount: o.amount, paidAmount: o.amount, lines: [{ productId: 1, productName: 'A4 复印纸', qty: 10, unitPrice: o.amount / 10, amount: o.amount }] });
      const stored = findRow('saleOrders', s.id);
      if (stored) stored.orderNo = makeNo('SO', stored.id);
      // 已确认单据同步锁定库存，避免商城单发货时超卖
      const bal = table('balance').find((b) => Number(b.productId) === 1 && Number(b.warehouseId) === 1);
      if (bal) bal.qtyOccupied = Number((Number(bal.qtyOccupied || 0) + 10).toFixed(3));
      o.status = '已转销售单'; o.saleOrderId = s.id;
      saveDb(); return { orderNo: stored?.orderNo || s.orderNo, id: s.id };
    }
    return { orderNo: '' };
  }
  if (parts[0] === 'shop' && parts[1] === 'orders' && parts[3] === 'ship') { const o = findRow('shopOrders', parts[2]); if (o) { o.status = '已发货'; o.trackingNo = data.trackingNo; } saveDb(); return { ok: true }; }

  if (path === '/mobile/home') return { todoCount: table('bpmTasks').filter((t) => t.status === 'TODO').length, todaySale: '3980.00', lowStockCount: table('alerts').filter((a) => a.type === '低库存').length, waitShipCount: table('saleOrders').filter((o) => Number(o.shipStatus) === 0).length };
  if (path === '/mobile/todo') return clone(table('bpmTasks').filter((t) => t.status === 'TODO'));
  if (path === '/mobile/scan') {
    const product = table('products').find((p) => p.barcode === params.code || p.code === params.code);
    if (!product) { return { product: null, offlineSaved: false, message: '未找到该产品，可离线保存' }; }
    const b = table('balance').find((x) => Number(x.productId) === Number(product.id));
    return { product: { ...clone(product), available: Number(b?.qtyOnHand || 0) - Number(b?.qtyOccupied || 0) }, offlineSaved: false };
  }
  if (path === '/mobile/stock') { const kw = String(params.keyword || ''); return clone(table('balance').map((b) => ({ ...clone(b), productName: findRow('products', b.productId)?.name || '' })).filter((r) => !kw || r.productName.includes(kw))); }
  if (path === '/mobile/offline-submit') { table('offlineBatches').push({ batchId: data.batchId, count: data.items?.length || 0, createdAt: now() }); saveDb(); return { status: '已接收', batchId: data.batchId, deduped: false }; }

  // 外部集成：配置、回调、OAuth 与节假日（真实后端对应 /api/v1/integrations、/api/v1/callback/*）
  if (path === '/integrations' ) {
    if (m === 'GET') {
      if (!table('integrationConfigs').length) {
        [
          { id: 1, code: 'wechat_work', name: '企业微信', enabled: 0, appId: '', callback: '/api/v1/auth/oauth/callback/wechat_work' },
          { id: 2, code: 'dingtalk', name: '钉钉', enabled: 0, appId: '', callback: '/api/v1/auth/oauth/callback/dingtalk' },
          { id: 3, code: 'payment', name: '支付平台', enabled: 1, appId: 'mock-pay', callback: '/api/v1/callback/payment' },
          { id: 4, code: 'logistics', name: '物流平台', enabled: 1, appId: 'mock-sf', callback: '/api/v1/callback/logistics' },
          { id: 5, code: 'einvoice', name: '电子发票', enabled: 0, appId: '', callback: '/api/v1/callback/einvoice' },
          { id: 6, code: 'bank', name: '银企直连', enabled: 0, appId: '', callback: '/api/v1/callback/bank' },
        ].forEach((row) => table('integrationConfigs').push(row));
        saveDb();
      }
      return clone(table('integrationConfigs'));
    }
    return saveRow('integrationConfigs', data);
  }
  if (path === '/integrations/logs' && m === 'GET') {
    return clone(table('integrationLogs').slice().reverse().slice(0, 100));
  }
  const oauthMatch = path.match(/^\/auth\/oauth\/([a-z_]+)$/);
  if (oauthMatch && m === 'POST') {
    const provider = oauthMatch[1];
    const state = Math.random().toString(36).slice(2, 12);
    return { provider, state, authorizeUrl: `https://oauth.example.com/${provider}/authorize?state=${state}&redirect_uri=${encodeURIComponent(location.origin + '/api/v1/auth/oauth/callback/' + provider)}`, message: '未配置真实密钥时返回模拟授权地址' };
  }
  const callbackMatch = path.match(/^\/auth\/oauth\/callback\/([a-z_]+)$/);
  if (callbackMatch && m === 'POST') {
    const provider = callbackMatch[1];
    saveRow('oauthBindings', { provider, openid: data.code || 'mock-openid', userId: 1, boundAt: now() });
    return { token: 'mock-token-1', user: { id: 1, username: 'admin', realName: '演示管理员', permissions: ['*'] }, provider };
  }
  if (path.startsWith('/callback/') && m === 'POST') {
    const provider = path.split('/')[2];
    const exists = table('integrationLogs').some((l) => l.requestId === data.requestId);
    if (exists) return { ok: true, duplicate: true, message: '重复回调已幂等忽略' };
    saveRow('integrationLogs', { ...data, provider, signatureValid: true, result: 'SUCCESS', createdAt: now() });
    return { ok: true, duplicate: false, message: `${provider} 回调已验签并回写业务单据` };
  }
  if (path === '/integrations/holidays' && m === 'GET') {
    const year = Number(params.year || new Date().getFullYear());
    return { year, source: '内置数据', items: [
      { date: `${year}-01-01`, name: '元旦' }, { date: `${year}-05-01`, name: '劳动节' },
      { date: `${year}-10-01`, name: '国庆节' }, { date: `${year}-11-26`, name: '感恩节（参考）' },
    ] };
  }
  if (path.match(/^\/integrations\/[a-z_]+\/sync$/) && m === 'POST') {
    const provider = path.split('/')[2];
    saveRow('integrationLogs', { provider, action: 'sync', result: 'SUCCESS', createdAt: now() });
    return { ok: true, provider, synced: 3, message: '同步完成（模拟）' };
  }

  // 分片上传：会话、分片状态与合并（真实后端对应 /api/v1/upload/*）
  if (path === '/upload/init' && m === 'POST') {
    const uploadId = `up-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
    return saveRow('uploadSessions', { ...data, id: table('uploadSessions').length + 1, uploadId, receivedChunks: [], status: 'UPLOADING' });
  }
  if (path === '/upload/chunk' && m === 'POST') {
    const session = table('uploadSessions').find((s) => s.uploadId === data.uploadId);
    if (session && !session.receivedChunks.includes(Number(data.index))) session.receivedChunks.push(Number(data.index));
    saveDb(); return { ok: true, received: session?.receivedChunks?.length || 0 };
  }
  if (path === '/upload/status' && m === 'GET') {
    return clone(table('uploadSessions').find((s) => s.uploadId === params.uploadId) || { receivedChunks: [] });
  }
  if (path === '/upload/merge' && m === 'POST') {
    const session = table('uploadSessions').find((s) => s.uploadId === data.uploadId);
    if (session) session.status = 'DONE';
    saveDb(); return { ok: true, uploadId: data.uploadId, docUrl: `/mock/docs/${data.uploadId}` };
  }

  // 多语言与多币种：语言包、币种、汇率
  if (path === '/system/language-packs') return m === 'POST' ? saveRow('languagePacks', data) : listResult('languagePacks', params);
  if (path === '/system/currencies') return m === 'POST' ? saveRow('sysCurrencies', data) : listResult('sysCurrencies', params);
  if (path === '/system/exchange-rates') return m === 'POST' ? saveRow('sysExchangeRates', data) : listResult('sysExchangeRates', params);

  // 版本日志：无服务端数据时返回空数组，由前端展示内置发布说明
  if (path === '/ux/changelogs' && m === 'GET') return [];
  if (path === '/ux/changelogs/read' && m === 'POST') return { ok: true };
  // 领域事件流：由前端 eventBus 写入 localStorage，这里读取并合并内置事件
  if (path === '/ux/events' && m === 'GET') {
    let live: any[] = [];
    try { live = JSON.parse(localStorage.getItem('erp_domain_events') || '[]'); } catch { /* 忽略损坏数据 */ }
    const builtin = [
      { id: 1, level: 'high', title: '销售单 SO20260001 已确认', detail: '库存已锁定，等待发货', createdAt: now() },
      { id: 2, level: 'normal', title: '库存预警：无线鼠标', detail: '可用量低于安全库存 20', createdAt: now() },
      { id: 3, level: 'normal', title: 'AI 简报已生成', detail: '今日应收逾期 2 笔', createdAt: now() },
    ];
    return [...live.reverse(), ...builtin];
  }

  // 单据评论：列表按单据过滤，发帖直接写入 comments 集合
  if (path === '/collab/comments/list' && m === 'POST') {
    return table('comments').filter((r) => (!data.bizType || r.bizType === data.bizType) && (!data.bizId || Number(r.bizId) === Number(data.bizId))).map(clone);
  }
  if (path === '/collab/comments' && m === 'POST') {
    return saveRow('comments', { ...data, createdAt: now() });
  }

  // ---- 体验增强域：/ux/* 统一映射，避免落入通用兜底生成假数据 ----
  if (parts[0] === 'ux') {
    if (path === '/ux/webhook-logs') {
      const legacy = table('uxWebhookLogs');
      if (legacy.length) {
        for (const row of legacy) table('webhookLogs').push({ ...row, id: nextId('webhookLogs') });
        legacy.length = 0;
        saveDb();
      }
      if (m === 'GET') return listResult('webhookLogs', params);
      if (m === 'POST') return saveRow('webhookLogs', data);
    }

    // 任务进度更新
    const progressMatch = path.match(/^\/ux\/(import|export)-tasks\/(\d+)\/progress$/);
    if (progressMatch && m === 'POST') {
      const key = progressMatch[1] === 'import' ? 'importTasks' : 'exportTasks';
      const row = findRow(key, progressMatch[2]);
      if (row) Object.assign(row, data);
      saveDb(); return clone(row || {});
    }
    if (path === '/ux/openapi/verify' && m === 'POST') return { valid: true, tenantId: 1, scope: data.scope || 'read' };
    if (path === '/ux/webhooks/dispatch' && m === 'POST') {
      const url = data.url || findRow('webhooks', data.id)?.url;
      if (!url) throw new Error('缺少推送地址');
      const row = saveRow('webhookLogs', { event: data.event || 'test', url, retryCount: 0, status: 1 });
      return { id: row.id, status: 1, response: '模拟推送成功' };
    }
    if (path === '/ux/custom-fields/delete' && m === 'POST') return removeRow('customFields', data.id);
    if (path === '/ux/calendar-events/delete' && m === 'POST') return removeRow('calendarEvents', data.id);

    const uxTableMap: Record<string, string> = {
      'ux/import-tasks': 'importTasks', 'ux/import-errors': 'importErrors', 'ux/export-tasks': 'exportTasks',
      'ux/alert-rules': 'alertRules', 'ux/custom-fields': 'customFields', 'ux/custom-fields/resolve': 'customFields',
      'ux/view-configs': 'viewConfigs', 'ux/revisions': 'revisions', 'ux/backups': 'backups',
      'ux/openapi-keys': 'openapiKeys', 'ux/webhooks': 'webhooks',
      'ux/calendar-events': 'calendarEvents', 'ux/comments': 'comments', 'ux/notifies': 'notifies',
    };
    const uxTable = uxTableMap[path] || collectionOf(parts);
    if (m === 'GET') return listResult(uxTable, params);
    if (m === 'POST') return saveRow(uxTable, data);
    if (m === 'PATCH' || m === 'PUT') {
      const row = findRow(uxTable, params.id || parts[parts.length - 1]);
      if (row) Object.assign(row, data);
      saveDb(); return clone(row || {});
    }
    if (m === 'DELETE') return removeRow(uxTable, params.id || parts[parts.length - 1]);
  }

  // ---- 体验增强域（我的视图 / 导入导出 / 预警 / 低代码 / 开放平台）----
  const uxMap: Record<string, string> = {
    'system/view-configs': 'viewConfigs', 'system/import-tasks': 'importTasks', 'system/import-errors': 'importErrors',
    'system/export-tasks': 'exportTasks', 'system/notify-rules': 'notifyRules', 'system/notify-records': 'notifyRecords',
    'system/alert-rules': 'alertRules', 'system/alerts': 'alertRecords', 'system/custom-fields': 'customFields',
    'system/custom-forms': 'customForms', 'system/revisions': 'revisions', 'system/drafts': 'drafts',
    'system/favorites': 'favorites', 'system/search-logs': 'searchLogs', 'system/field-audits': 'auditFieldLogs',
    'system/openapi-keys': 'openapiKeys', 'system/webhook-logs': 'webhookLogs',
  };
  if (uxMap[path]) return m === 'POST' ? saveRow(uxMap[path], data) : listResult(uxMap[path], params);

  // ---- 通用业务引擎：供 126 个功能页统一调用（状态机 + 联动 + 审计） ----
  // GET  /_biz/schemes/:collection      读取业务方案
  // POST /_biz/schemes/:collection      保存业务方案
  // GET  /_biz/flow/:collection         读取页面业务流配置（动作/状态/方案）
  // POST /_biz/action/:collection/:id/:action  执行状态动作
  if (parts[0] === '_biz' && parts[1] === 'schemes' && parts[2]) {
    if (m === 'POST') return saveScheme(parts[2], data || {});
    return schemeOf(parts[2]);
  }
  if (parts[0] === '_biz' && parts[1] === 'flow' && parts[2]) {
    const schema = getEntitySchema(parts[2]);
    return buildFlow(parts[2], schema?.label || parts[2], '', schema?.fields || []);
  }
  // GET /_biz/schema/:collection -> 权威字段与种子（来自 entitySchemas 注册表）
  if (parts[0] === '_biz' && parts[1] === 'schema' && parts[2]) {
    const schema = getEntitySchema(parts[2]);
    return schema ? { fields: schema.fields, seed: schema.seed, label: schema.label, statusField: schema.statusField, statusLabels: schema.statusLabels } : { fields: [], seed: [] };
  }
  if (parts[0] === '_biz' && parts[1] === 'action' && parts[2] && parts[3] && parts[4]) {
    return genericBizAction(parts[2], parts[3], parts[4], data || {});
  }

  // ---- 生产计划与排产（APS）：排产运算/状态动作/齐套检查/负荷与预警 ----
  // 未命中 APS 专用接口时返回 undefined，继续走下方通用 REST 兜底完成 CRUD。
  const apsResult = handleAps(m, parts, data, params, path);
  if (apsResult !== undefined) return apsResult;

  // ---- 兜底：通用 REST 集合 CRUD（未显式定义的接口自动具备增删改查）----
  // 资源型路径 /a/b/:id 的集合名应取前两段（a/b），不能把 id 拼进集合名，
  // 否则 PATCH /sales/orders/5 会写进幻影集合 salesOrders5，导致编辑后刷新即丢。
  const tailIsId = parts.length > 2 && /^\d+$/.test(parts[parts.length - 1]);
  const resourceParts = tailIsId ? parts.slice(0, 2) : parts;
  const key = collectionOf(resourceParts);
  // 大小写规范的集合映射（collectionOf 已把第二段首字母大写，这里对齐种子表实际命名）
  const collectionAlias: Record<string, string> = {
    salesOrders: 'saleOrders', financeVouchers: 'vouchers', systemUsers: 'users',
    inventoryProducts: 'products', financeSubjects: 'subjects', financeAccounts: 'accounts',
    financeReceivables: 'receivables', financePayables: 'payables', systemRoles: 'roles',
    systemPermissions: 'permissions',
  };
  const realKey = collectionAlias[key] || key;
  if (m === 'GET') {
    if (tailIsId) return clone(findRow(realKey, Number(parts[parts.length - 1])) || {});
    if (parts.length === 2 && params.id) return findRow(realKey, params.id) || {};
    // 未预置种子的扩展实体：优先用业务 Schema 的真实种子数据初始化，
    // 让每个菜单按《ERP完整产品与技术文档》展示真实字段与业务数据，而非千篇一律的"演示数据 N"。
    // industry 前缀集合由各行业/采购深度组件自行 seed，跳过以免覆盖真实场景数据。
    if (!table(realKey).length && !realKey.startsWith('industry')) {
      const schema = getEntitySchema(realKey);
      if (schema?.seed?.length) {
        for (const row of schema.seed) {
          table(realKey).push({ ...clone(row), createdAt: now(), updatedAt: now(), isDeleted: 0 });
        }
      } else {
        // 未登记 Schema 的实体：仍给通用占位，保证菜单打开不空白
        const titles: Record<string, string> = { status: '草稿', isActive: '1', enabled: '1', closed: '0' };
        for (let i = 1; i <= 3; i++) {
          table(realKey).push({
            id: i, name: `演示数据 ${i}`, code: `${realKey.toUpperCase().slice(0, 6)}-${String(i).padStart(3, '0')}`,
            status: titles.status, isActive: 1, enabled: 1, closed: 0,
            remark: '本地演示数据，可编辑/删除', createdAt: now(), updatedAt: now(), isDeleted: 0,
          });
        }
      }
      saveDb();
    }
    return listResult(realKey, params);
  }
  if (m === 'POST') return saveRow(realKey, data);
  if (m === 'PATCH' || m === 'PUT') {
    const id = Number(params.id ?? parts[parts.length - 1]);
    const row = findRow(realKey, id);
    if (row) { Object.assign(row, data); saveDb(); return clone(row); }
    // 更新不存在的记录应报错，避免静默新建幽灵数据
    throw new Error(`记录不存在（${realKey}#${id}），无法更新`);
  }
  if (m === 'DELETE') {
    const id = Number(params.id ?? parts[parts.length - 1]);
    const row = findRow(realKey, id);
    if (row) { row.isDeleted = 1; saveDb(); }
    return { ok: true };
  }
  return {};
}

/**
 * 发起请求：Mock 模式直接走本地处理；真实模式失败后自动降级到 Mock。
 * @param method HTTP 方法
 * @param url 接口地址
 * @param data 请求体或查询参数
 * @returns 业务数据 Promise
 */
async function requestWithMock(method: string, url: string, data?: any): Promise<any> {
  // /_biz/** 是前端业务引擎（Schema/流程/动作/审计），后端没有对应路由。
  // 真实模式下若交给 axios，会被 Vite 的 SPA 回退返回 index.html，导致字段为空、流程动作全失效。
  // 这条规则与 MOCK_ENABLED 无关，保证两种模式下各页面字段与状态机完全一致。
  if (MOCK_ENABLED || localStorage.getItem('erp_token')?.startsWith('mock-token-') || url.startsWith('/_biz/')) return handleMock(method, url, data, method === 'GET' ? data : {});
  try {
    // 真实模式：直接用 axios 请求后端，响应解包与 request.ts 保持一致
    const token = localStorage.getItem('erp_token');
    // 演示登录或未登录时没有可用令牌，直接走本地数据，避免整页 401 噪音
    if (!token) return handleMock(method, url, data, method === 'GET' ? data : {});
    const resp = await axios.request({
      url, method: method as any,
      params: method === 'GET' ? data : undefined,
      data: method === 'GET' ? undefined : data,
      headers: token ? { Authorization: `Bearer ${token}` } : {},
    });
    const body = resp.data;
    // 后端返回业务错误码（如 40400「未授权的资源」）时降级到本地演示账套；
    // 后端已连通但业务表尚未初始化而返回空列表时同样降级，
    // 否则「字段有值、数据全空」且动作只在本地生效，流程看起来会全部失效。
    if (body && typeof body === 'object' && 'code' in body) {
      if (Number((body as any).code) !== 0) return handleMock(method, url, data, method === 'GET' ? data : {});
    }
    const unwrapped = body && typeof body === 'object' && 'code' in body ? (body as any).data : body;
    if (method === 'GET') {
      const empty = Array.isArray(unwrapped)
        ? unwrapped.length === 0
        : !!unwrapped && typeof unwrapped === 'object' && Array.isArray((unwrapped as any).list) && (unwrapped as any).list.length === 0;
      if (empty) return handleMock(method, url, data, method === 'GET' ? data : {});
    }
    return unwrapped;
  } catch (err) {
    // 后端不可用时自动降级，保证业务流程不中断（文档 0 章 AI 降级约定同样适用于整体演示）
    if (url.startsWith('/_biz/action/')) return handleMock(method, url, data, method === 'GET' ? data : {});
    return handleMock(method, url, data, method === 'GET' ? data : {});
  }
}

/** 带 Mock 降级的 GET */
export const mockGet = <T = any>(url: string, params?: any): Promise<T> => requestWithMock('GET', url, params) as Promise<T>;
/** 带 Mock 降级的 POST */
export const mockPost = <T = any>(url: string, data?: any): Promise<T> => requestWithMock('POST', url, data) as Promise<T>;
/** 带 Mock 降级的 PATCH */
export const mockPatch = <T = any>(url: string, data?: any): Promise<T> => requestWithMock('PATCH', url, data) as Promise<T>;
/** 带 Mock 降级的 DELETE */
export const mockDel = <T = any>(url: string): Promise<T> => requestWithMock('DELETE', url) as Promise<T>;
