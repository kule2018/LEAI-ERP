import { handleMock, MOCK_ENABLED } from './mockAdapter';
import { get, patch, post } from './request';

const demoEndpoints: Record<string, string> = {
  '/api/v1/order-reports/sales-details': '/api/v1/sales/details',
  '/api/v1/order-reports/sales-summary': '/api/v1/sales/summaries',
  '/api/v1/order-reports/sales-ranking': '/api/v1/sales/rankings',
  '/api/v1/order-reports/purchase-details': '/api/v1/purchase/details',
  '/api/v1/order-reports/purchase-summary': '/api/v1/purchase/summaries',
  '/api/v1/order-reports/purchase-prices': '/api/v1/purchase/price-history',
};

/** 页面操作使用单一账套。正式接口返回空数据或业务错误时保留原结果。 */
export async function pageData<T = unknown>(
  method: 'GET' | 'POST' | 'PATCH',
  path: string,
  data?: unknown,
): Promise<T> {
  if (MOCK_ENABLED || localStorage.getItem('erp_token')?.startsWith('mock-token-')) {
    const mockPath = (demoEndpoints[path] ?? path).replace(/^\/api\/v1\/sales-ext\/action\//, '/_biz/action/');
    return handleMock(method, mockPath, method === 'GET' ? {} : data, method === 'GET' ? data : {});
  }
  if (method === 'GET') return get<T>(path, data);
  if (method === 'PATCH') return patch<T>(path, data);
  return post<T>(path, data);
}

export type BusinessRow = Record<string, any>;

export function pageRows(data: BusinessRow[] | { list?: BusinessRow[] } | null): BusinessRow[] {
  return Array.isArray(data) ? data : data?.list ?? [];
}
