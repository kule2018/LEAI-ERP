/**
 * 生产上传 API（文档第 26 章：分片上传）。
 * ---------------------------------------------------------------------------
 * 提供文件指纹、创建会话、分片上传、状态查询与合并接口。
 * 演示模式走本地 Mock；切换真实后端后，把 mockPost/mockGet 换成 axios 即可，
 * 组件层无需改动。真实后端对应 /api/v1/upload/init|chunk|status|merge。
 */
import { mockGet, mockPost } from './mockAdapter';

/** 分片大小：2MB */
const CHUNK_SIZE = 2 * 1024 * 1024;

/**
 * 计算文件 SHA-256 指纹，用于秒传与断点续传定位。
 * @param file 待上传文件
 * @returns 十六进制指纹字符串
 */
export async function fileHash(file: File): Promise<string> {
  try {
    const buffer = await file.arrayBuffer();
    const digest = await crypto.subtle.digest('SHA-256', buffer);
    return Array.from(new Uint8Array(digest)).map((b) => b.toString(16).padStart(2, '0')).join('');
  } catch {
    // 非安全上下文下 crypto.subtle 不可用，回退到稳定字符串指纹
    return `${file.name}-${file.size}-${file.lastModified}`;
  }
}

/** 上传会话信息 */
export interface UploadSession {
  uploadId: string;
  chunkSize: number;
  totalChunks: number;
  duplicate?: boolean;
  message?: string;
}

/** 上传 API 门面 */
export const uploadApi = {
  /** 创建会话 */
  async createSession(data: { kbId: number; fileName: string; fileSize: number; fileHash: string }): Promise<UploadSession> {
    const totalChunks = Math.max(1, Math.ceil(data.fileSize / CHUNK_SIZE));
    const result: any = await mockPost('/api/v1/upload/init', { ...data, chunkSize: CHUNK_SIZE, totalChunks });
    return {
      uploadId: result?.uploadId || `up-${Date.now()}`,
      chunkSize: result?.chunkSize || CHUNK_SIZE,
      totalChunks: result?.totalChunks || totalChunks,
      duplicate: !!result?.duplicate,
      message: result?.message,
    };
  },
  /** 上传单个分片 */
  async uploadChunk(uploadId: string, index: number, chunk: Blob): Promise<any> {
    return mockPost('/api/v1/upload/chunk', { uploadId, index, size: chunk.size });
  },
  /** 查询已收到分片 */
  async status(uploadId: string): Promise<{ receivedChunks: number[]; chunkSize: number; totalChunks: number }> {
    const result: any = await mockGet('/api/v1/upload/status', { uploadId });
    return { receivedChunks: result?.receivedChunks || [], chunkSize: result?.chunkSize || CHUNK_SIZE, totalChunks: result?.totalChunks || 1 };
  },
  /** 合并分片 */
  async complete(uploadId: string): Promise<any> {
    return mockPost('/api/v1/upload/merge', { uploadId });
  },
};
