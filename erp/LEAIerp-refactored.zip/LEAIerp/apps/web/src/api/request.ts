import axios from 'axios';
import { useToast } from '../components/ds/toast';
import { friendlyError } from '../utils/errorMessage';

/** 非组件上下文（拦截器）直接用 Toast 单例推消息 */
const toast = useToast();

/** Axios 实例：Token 注入、刷新队列、统一 { code, data, message } 解包 */
const instance = axios.create({ baseURL: '/', timeout: 30000 });

instance.interceptors.request.use((config) => {
  const token = localStorage.getItem('erp_token');
  if (token) config.headers!.Authorization = `Bearer ${token}`;
  return config;
});

let refreshing: Promise<string> | null = null;

instance.interceptors.response.use(
  (resp) => {
    const body = resp.data;
    if (body && typeof body === 'object' && 'code' in body) {
      if (body.code === 0) return body.data;
      const friendly = friendlyError({ code: body.code, message: body.message });
      toast.error(`${friendly.message}${friendly.suggestion ? '：' + friendly.suggestion : ''}`);
      return Promise.reject(new Error(friendly.message));
    }
    return body;
  },
  async (err) => {
    const status = err?.response?.status;
    const token = localStorage.getItem('erp_token');
    const config = err?.config;
    if (status === 401 && token && config && config.url !== '/api/v1/auth/refresh' && !config.erpRetried) {
      config.erpRetried = true;
      // 刷新 Token 队列：并发 401 只刷新一次
      if (!refreshing) {
        refreshing = instance.post('/api/v1/auth/refresh', { token }).then((data: any) => {
          const newToken = data?.token;
          if (newToken) localStorage.setItem('erp_token', newToken);
          return newToken;
        }).finally(() => { refreshing = null; });
      }
      try {
        const newToken = await refreshing;
        if (!newToken) throw new Error('Token 刷新失败');
        config.headers.Authorization = `Bearer ${newToken}`;
        return instance.request(config);
      } catch {
        localStorage.removeItem('erp_token');
        location.hash = '#/login';
      }
    }
    const friendly = friendlyError(err);
    toast.error(`${friendly.message}${friendly.suggestion ? '：' + friendly.suggestion : ''}`);
    return Promise.reject(err);
  },
);

export function get<T = any>(url: string, params?: any): Promise<T> { return instance.get(url, { params }) as any; }
export function post<T = any>(url: string, data?: any): Promise<T> { return instance.post(url, data) as any; }
export function patch<T = any>(url: string, data?: any): Promise<T> { return instance.patch(url, data) as any; }
export function del<T = any>(url: string): Promise<T> { return instance.delete(url) as any; }
export default instance;
