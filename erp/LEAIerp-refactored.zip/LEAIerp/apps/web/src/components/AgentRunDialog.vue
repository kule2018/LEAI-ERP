<template>
  <DsModal v-model="visible" :title="title" :width="760" @close="stop">
    <DsChatView :messages="messages" empty-title="运行测试" empty-desc="输入问题，实时查看 Agent 的流式输出" @regenerate="regenerate">
      <template #footer="{ msg }">
        <div v-if="msg.role === 'assistant' && msg.content && !msg.streaming && msg.traceId" class="fb-bar">
          <span class="fb-label">回答是否有帮助？</span>
          <button
            class="fb-btn" :class="{ active: msg.feedback === 'up' }"
            type="button" title="有帮助" :disabled="!!msg.feedback"
            @click="rate(msg, 'up')"
          >👍</button>
          <button
            class="fb-btn" :class="{ active: msg.feedback === 'down' }"
            type="button" title="需改进" :disabled="!!msg.feedback"
            @click="rate(msg, 'down')"
          >👎</button>
          <span v-if="msg.feedback" class="fb-done">已反馈，感谢</span>
        </div>
      </template>
    </DsChatView>
    <DsComposer
      v-model="input"
      :streaming="streaming"
      show-reasoning
      placeholder="输入问题测试这个 Agent…"
      @send="send"
      @stop="stop"
      @update:reasoning="useReason = $event"
    />
  </DsModal>
</template>

<script setup lang="ts">
import { ref, watch } from 'vue'
import { DsModal, DsChatView, DsComposer, useToast } from '@/components'
import { agentApi } from '@/api/agent'
import { auditApi } from '@/api/business'
import type { ChatMessage } from '@/types'

const props = withDefaults(defineProps<{
  modelValue: boolean
  agentId: number
  title?: string
}>(), { title: '运行 Agent' })

const emit = defineEmits<{ (e: 'update:modelValue', value: boolean): void }>()
const toast = useToast()
const visible = ref(props.modelValue)
const input = ref('')
const streaming = ref(false)
const useReason = ref(true)
const messages = ref<ChatMessage[]>([])
let controller: AbortController | null = null

watch(() => props.modelValue, (v) => { visible.value = v })
watch(visible, (v) => emit('update:modelValue', v))

function stop() {
  controller?.abort()
  controller = null
  streaming.value = false
  messages.value.forEach((m) => { m.streaming = false })
}

async function send(text: string) {
  if (!text || streaming.value) return
  messages.value.push({ id: `u-${Date.now()}`, role: 'user', content: text, createdAt: Date.now() })
  const reply: ChatMessage = {
    id: `a-${Date.now()}`, role: 'assistant', content: '', reasoning: useReason.value ? '正在分析请求…\n' : '',
    streaming: true, createdAt: Date.now(),
  }
  messages.value.push(reply)
  input.value = ''
  streaming.value = true
  controller = new AbortController()
  try {
    await agentApi.run(
      props.agentId,
      { input: text },
      (chunk, done) => {
        if (done) return
        if (chunk.startsWith('[meta]')) {
          // 首帧元信息：提取 traceId，不展示给用户
          try { reply.traceId = JSON.parse(chunk.slice(6)).traceId || '' } catch { /* 忽略异常帧 */ }
        } else if (chunk.startsWith('[citations]')) {
          // 引用来源：本次回答依据的知识库片段
          try { reply.citations = JSON.parse(chunk.slice(11)) || [] } catch { /* 忽略异常帧 */ }
        } else if (chunk.startsWith('[thinking]')) reply.reasoning = (reply.reasoning || '') + chunk.slice(10)
        else if (chunk.startsWith('[tool]')) reply.reasoning = (reply.reasoning || '') + chunk.slice(6)
        else if (chunk.startsWith('[note]')) reply.reasoning = (reply.reasoning || '') + chunk.slice(6)
        else reply.content += chunk
      },
      controller.signal,
    )
    reply.reasoningMs = 1200
  } catch (e: any) {
    if (e?.name !== 'AbortError') {
      reply.error = e.message || '运行失败'
      toast.error(reply.error || '运行失败')
    }
  } finally {
    reply.streaming = false
    streaming.value = false
    controller = null
  }
}

async function rate(msg: ChatMessage, rating: 'up' | 'down') {
  if (msg.feedback) return
  msg.feedback = rating
  try {
    await auditApi.createFeedback({ traceId: msg.traceId, agentId: props.agentId, rating })
    toast.success(rating === 'up' ? '感谢你的反馈' : '已记录，我们会持续改进')
  } catch {
    msg.feedback = undefined
    toast.error('反馈提交失败，请重试')
  }
}

function regenerate(msg: ChatMessage) {
  const index = messages.value.findIndex((m) => m.id === msg.id)
  const previous = [...messages.value.slice(0, index)].reverse().find((m) => m.role === 'user')
  if (previous) {
    messages.value.splice(index, 1)
    send(previous.content)
  }
}
</script>

<style scoped>
.fb-bar { display: flex; align-items: center; gap: 6px; margin-top: 6px; }
.fb-label { font-size: var(--ds-font-xs); color: var(--ds-text-3); margin-right: 2px; }
.fb-btn {
  width: 26px; height: 26px; display: inline-flex; align-items: center; justify-content: center;
  border: 1px solid var(--ds-border); border-radius: var(--ds-radius-sm);
  background: var(--ds-bg-elevated); font-size: 13px; cursor: pointer;
  transition: border-color .15s, background-color .15s;
}
.fb-btn:hover:not(:disabled) { border-color: var(--ds-brand); background: var(--ds-bg-hover); }
.fb-btn.active { border-color: var(--ds-brand); background: var(--ds-brand); }
.fb-btn:disabled { cursor: default; }
.fb-done { font-size: var(--ds-font-xs); color: var(--ds-success); margin-left: 2px; }
</style>
