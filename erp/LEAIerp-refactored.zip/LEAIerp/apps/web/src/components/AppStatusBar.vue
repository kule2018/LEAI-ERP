<template>
  <!-- 顶部导航进度条：路由懒加载期间给出明确反馈，避免「点击没反应」 -->
  <div class="app-progress" :class="{ 'is-active': loading }" aria-hidden="true">
    <span class="app-progress-bar" />
  </div>

  <!-- 离线提示：断网时立刻告诉用户，并在恢复后提示已恢复 -->
  <Transition name="app-slide">
    <div v-if="!online" class="app-offline">
      <span class="app-offline-dot" />
      网络已断开，页面数据可能不是最新；恢复后会自动继续
    </div>
  </Transition>
  <Transition name="app-slide">
    <div v-if="online && recovered" class="app-online">
      <span class="app-online-dot" />
      网络已恢复
    </div>
  </Transition>
</template>

<script setup lang="ts">
import { computed, onBeforeUnmount, onMounted, ref, watch } from 'vue'
import { useAppStore } from '@/stores/app'

const app = useAppStore()
const loading = computed(() => app.loading)
const online = computed(() => app.online)

/** 网络刚恢复时短暂提示「已恢复」，随后自动消失 */
const recovered = ref(false)
let timer: number | undefined

watch(() => app.onlineEpoch, () => {
  if (!app.online) return
  recovered.value = true
  window.clearTimeout(timer)
  timer = window.setTimeout(() => { recovered.value = false }, 2600)
})

function onOnline() { app.setOnline(true) }
function onOffline() { app.setOnline(false) }

onMounted(() => {
  window.addEventListener('online', onOnline)
  window.addEventListener('offline', onOffline)
})

onBeforeUnmount(() => {
  window.removeEventListener('online', onOnline)
  window.removeEventListener('offline', onOffline)
  window.clearTimeout(timer)
})
</script>

<style scoped>
.app-progress {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  height: 2px;
  z-index: 2000;
  pointer-events: none;
  opacity: 0;
  transition: opacity .2s ease;
}
.app-progress.is-active { opacity: 1; }
.app-progress-bar {
  display: block;
  height: 100%;
  width: 40%;
  border-radius: 2px;
  background: var(--ds-brand);
  animation: app-progress-slide 1.1s ease-in-out infinite;
}
@keyframes app-progress-slide {
  0% { transform: translateX(-100%); }
  100% { transform: translateX(260%); }
}

.app-offline,
.app-online {
  position: fixed;
  top: 0;
  left: 50%;
  transform: translateX(-50%);
  z-index: 2001;
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 7px 16px;
  border-radius: 0 0 10px 10px;
  font-size: var(--ds-font-sm);
  box-shadow: var(--ds-shadow-md);
}
.app-offline { background: var(--ds-warning-soft, #fff4e5); color: var(--ds-warning, #b26a00); }
.app-online { background: var(--ds-brand-soft); color: var(--ds-brand); }
.app-offline-dot,
.app-online-dot { width: 7px; height: 7px; border-radius: 50%; background: currentColor; }
.app-offline-dot { animation: app-blink 1.2s ease-in-out infinite; }
@keyframes app-blink { 0%, 100% { opacity: 1; } 50% { opacity: .25; } }

.app-slide-enter-active, .app-slide-leave-active { transition: opacity .25s ease, transform .25s ease; }
.app-slide-enter-from, .app-slide-leave-to { opacity: 0; transform: translate(-50%, -8px); }
</style>
