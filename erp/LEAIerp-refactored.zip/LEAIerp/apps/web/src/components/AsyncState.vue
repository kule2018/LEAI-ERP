<template>
  <!-- 加载中 -->
  <div v-if="loading" class="async-state" role="status" aria-live="polite">
    <DsLoading v-if="showSpinner" :text="loadingText" />
    <DsSkeleton v-else :rows="skeletonRows" />
  </div>

  <!-- 加载失败 -->
  <div v-else-if="error" class="async-state" role="alert" aria-live="assertive">
    <div class="async-state__icon async-state__icon--error" aria-hidden="true">!</div>
    <p class="async-state__title">{{ errorTitle }}</p>
    <p class="async-state__detail">{{ errorTextOf(error) }}</p>
    <DsButton v-if="retryable" variant="primary" size="sm" @click="emit('retry')">重试</DsButton>
  </div>

  <!-- 空数据 -->
  <div v-else-if="empty" class="async-state">
    <DsEmpty :text="emptyText" :size="size" />
    <slot name="empty-action" />
  </div>

  <!-- 正常内容 -->
  <slot v-else />
</template>

<script setup lang="ts">
import { DsButton, DsEmpty, DsLoading, DsSkeleton } from '@/components'

/**
 * 异步数据的「加载 / 失败 / 空 / 正常」四态容器。
 *
 * 页面只要把 loading / error / empty 三个状态传进来，
 * 就能得到一致的加载骨架、失败重试与空态提示，不需要每页各写一套。
 */
withDefaults(defineProps<{
  loading?: boolean
  error?: string | Error | null
  empty?: boolean
  loadingText?: string
  errorTitle?: string
  emptyText?: string
  size?: 'sm' | 'md' | 'lg'
  /** 骨架行数 */
  skeletonRows?: number
  /** 失败时是否显示重试按钮 */
  retryable?: boolean
  /** 加载时是否用转圈（否则用骨架屏） */
  showSpinner?: boolean
}>(), {
  loading: false,
  error: null,
  empty: false,
  loadingText: '加载中…',
  errorTitle: '加载失败',
  emptyText: '暂无数据',
  size: 'sm',
  skeletonRows: 4,
  retryable: true,
  showSpinner: false,
})

const emit = defineEmits<{ (event: 'retry'): void }>()

function errorTextOf(error: string | Error | null): string {
  if (!error) return '请稍后重试'
  return typeof error === 'string' ? error : error.message || '请稍后重试'
}
</script>

<style scoped>
.async-state {
  padding: 28px 12px;
  text-align: center;
}
.async-state__icon {
  width: 40px;
  height: 40px;
  margin: 0 auto 12px;
  display: grid;
  place-items: center;
  border-radius: 50%;
  font-size: 20px;
  font-weight: 700;
}
.async-state__icon--error {
  background: rgba(220, 38, 38, 0.12);
  color: var(--ds-danger);
}
.async-state__title { margin: 0 0 6px; font-size: 14px; font-weight: 650; }
.async-state__detail { margin: 0 0 14px; color: var(--ds-text-3); font-size: 13px; line-height: 1.6; }
</style>