<!--
 * BaseDialog 通用弹窗组件（DeepSeek UI 版）
 * 职责：统一弹窗外观与「取消 / 确定」底部操作区，提供显隐双向绑定、标题 / 尺寸 /
 *       可拖拽 / 全屏等常用配置，并通过 confirm/opened/closed 事件与父组件通信。
 * 与旧版区别：基于 ds 设计令牌自绘（Teleport + Transition），不再依赖 Element Plus；
 *             拖拽与全屏为自实现，保持零依赖。
 * 页面位置 / 用途：用于新增、编辑、提示等需要弹窗承载内容的场景。
 * 核心 props：title 标题、width 宽度、top 距顶距离、loading 确认按钮加载态（由父组件控制提交中状态）、
 *            draggable 可拖拽、fullscreen 全屏、closeOnClickModal 点击遮罩是否关闭、closeOnPressEscape 按 ESC 是否关闭等。
 * 核心 emits：confirm 点击「确定」时触发（由父组件执行异步提交并控制 loading）、opened 打开动画结束、closed 关闭动画结束。
 -->
<template>
  <Teleport to="body">
    <Transition name="ds-dialog">
      <div v-if="visible" class="base-dialog__mask" :class="{ 'is-center': alignCenter }" @click="onMask">
        <div
          ref="panelRef"
          class="base-dialog"
          :class="{ 'is-full': isFull }"
          :style="panelStyle"
          role="dialog"
          aria-modal="true"
        >
          <!-- 头部（draggable 时作为拖拽把手） -->
          <header
            class="base-dialog__head"
            :class="{ 'is-draggable': draggable }"
            @mousedown="draggable && startDrag($event)"
          >
            <span class="base-dialog__title">{{ title }}</span>
            <button type="button" class="base-dialog__close" title="关闭" @click="close">✕</button>
          </header>

          <!-- 默认插槽：弹窗主体内容 -->
          <div class="base-dialog__body">
            <slot />
          </div>

          <!-- 底部操作区：允许父组件完全自定义（footer 插槽优先于默认按钮） -->
          <footer class="base-dialog__foot">
            <slot name="footer">
              <!-- 取消按钮：直接关闭弹窗 -->
              <DsButton variant="default" size="md" @click="close">{{ cancelText }}</DsButton>
              <!-- 确定按钮：触发 confirm 事件，loading 由父组件通过 prop 控制 -->
              <DsButton variant="primary" size="md" :loading="loading" @click="emit('confirm')">
                {{ confirmText }}
              </DsButton>
            </slot>
          </footer>
        </div>
      </div>
    </Transition>
  </Teleport>
</template>

<script setup lang="ts">
// ref/reactive/computed/watch 状态与派生；onBeforeUnmount 卸载兜底；DsButton 为 ds 设计系统按钮
import { ref, reactive, computed, watch, onBeforeUnmount } from "vue";
import DsButton from "./ds/DsButton.vue";

// visible 双向绑定（父组件 v-model:visible），表示弹窗是否显示
const visible = defineModel<boolean>("visible", { required: true });

const props = withDefaults(
  defineProps<{
    /** 标题 */
    title?: string;
    /** 宽度（px 或 CSS 值） */
    width?: string | number;
    /** 距顶距离（全屏 / 居中时忽略） */
    top?: string;
    /** 确定按钮文案 */
    confirmText?: string;
    /** 取消按钮文案 */
    cancelText?: string;
    /** 确认按钮 loading（由父组件控制提交中状态） */
    loading?: boolean;
    /** 点击遮罩是否关闭 */
    closeOnClickModal?: boolean;
    /** 是否可拖拽（拖动头部移动弹窗） */
    draggable?: boolean;
    /** 是否全屏 */
    fullscreen?: boolean;
    /** 按 ESC 是否关闭 */
    closeOnPressEscape?: boolean;
    /** 是否水平垂直居中 */
    alignCenter?: boolean;
  }>(),
  {
    width: "520px",
    top: "12vh",
    confirmText: "确定",
    cancelText: "取消",
    loading: false,
    closeOnClickModal: false,
    draggable: false,
    fullscreen: false,
    closeOnPressEscape: true,
    alignCenter: false,
  }
);

const emit = defineEmits<{
  (e: "confirm"): void;
  (e: "opened"): void;
  (e: "closed"): void;
}>();

/** 是否全屏：prop 优先 */
const isFull = computed(() => props.fullscreen);
/** 弹窗面板元素引用（拖拽定位用） */
const panelRef = ref<HTMLElement>();
// 仅由模板的 ref="panelRef" 绑定（字符串 ref 不被 TS 计为使用）
void panelRef.value;
/** 拖拽偏移量：x/y 为面板相对初始位置的位移（px） */
const drag = reactive({ x: 0, y: 0 });

/**
 * 弹窗面板样式：宽度 + 拖拽位移 + 顶部位置。
 * 拖拽时用 transform 位移，不改 top/left，避免反复触发布局。
 */
const panelStyle = computed(() => ({
  width: isFull.value ? "100%" : typeof props.width === "number" ? props.width + "px" : props.width,
  transform: `translate(${drag.x}px, ${drag.y}px)`,
  marginTop: isFull.value || props.alignCenter ? "0" : props.top,
}));

/**
 * 关闭弹窗：同步 v-model。
 * @returns 无
 */
function close(): void {
  visible.value = false;
}

/** 遮罩点击（仅当点在遮罩本身而非面板） */
function onMask(e: MouseEvent): void {
  if (props.closeOnClickModal && e.target === e.currentTarget) close();
}

/** 拖拽起始：记录按下点，挂上 move / up 监听 */
function startDrag(e: MouseEvent): void {
  // 点在头部按钮上不拖
  if ((e.target as HTMLElement).closest("button")) return;
  const startX = e.clientX - drag.x;
  const startY = e.clientY - drag.y;
  const move = (ev: MouseEvent) => {
    drag.x = ev.clientX - startX;
    drag.y = ev.clientY - startY;
  };
  const up = () => {
    document.removeEventListener("mousemove", move);
    document.removeEventListener("mouseup", up);
  };
  document.addEventListener("mousemove", move);
  document.addEventListener("mouseup", up);
}

/** ESC 关闭（打开期间监听） */
function onKey(e: KeyboardEvent): void {
  if (e.key === "Escape") close();
}

// 打开：锁页面滚动 + 监听 ESC；关闭：恢复 + 复位拖拽偏移
watch(
  () => visible.value,
  (open) => {
    if (typeof document === "undefined") return;
    document.body.style.overflow = open ? "hidden" : "";
    if (open) {
      drag.x = 0;
      drag.y = 0;
      document.addEventListener("keydown", onKey);
      requestAnimationFrame(() => emit("opened"));
    } else {
      document.removeEventListener("keydown", onKey);
      requestAnimationFrame(() => emit("closed"));
    }
  },
);

// 卸载兜底：恢复滚动与监听
onBeforeUnmount(() => {
  if (typeof document === "undefined") return;
  document.body.style.overflow = "";
  document.removeEventListener("keydown", onKey);
});
</script>

<style scoped>
/* 遮罩 */
.base-dialog__mask {
  position: fixed;
  inset: 0;
  z-index: 1000;
  display: flex;
  align-items: flex-start;
  justify-content: center;
  padding: 20px;
  overflow: auto;
  background: var(--ds-mask);
  backdrop-filter: blur(2px);
}
.base-dialog__mask.is-center { align-items: center; }

/* 面板 */
.base-dialog {
  display: flex;
  flex-direction: column;
  max-width: 100%;
  max-height: calc(100vh - 40px);
  background: var(--ds-bg-elevated);
  border-radius: var(--ds-radius-lg);
  box-shadow: var(--ds-shadow-lg);
  overflow: hidden;
}
.base-dialog.is-full {
  width: 100% !important;
  height: calc(100vh - 40px);
  max-height: none;
}

/* 头部 */
.base-dialog__head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  padding: 14px 18px;
  border-bottom: 1px solid var(--ds-divider);
  flex: none;
  user-select: none;
}
.base-dialog__head.is-draggable { cursor: move; }
.base-dialog__title { font-size: var(--ds-font-lg); font-weight: 600; color: var(--ds-text); }
.base-dialog__close {
  width: 28px;
  height: 28px;
  display: grid;
  place-items: center;
  border: 0;
  border-radius: var(--ds-radius-xs);
  background: transparent;
  color: var(--ds-text-3);
  cursor: pointer;
  font-size: var(--ds-font-sm);
  transition: background var(--ds-dur-fast) var(--ds-ease);
}
.base-dialog__close:hover { background: var(--ds-bg-hover); color: var(--ds-text); }

/* 内容区 */
.base-dialog__body { flex: 1; overflow-y: auto; padding: 18px; }

/* 底部操作区 */
.base-dialog__foot {
  flex: none;
  display: flex;
  justify-content: flex-end;
  gap: 10px;
  padding: 12px 18px;
  border-top: 1px solid var(--ds-divider);
}

/* 进出动画：淡入 + 轻微上浮（面板位移动画见下方全局样式块） */
</style>

<style>
/* 全局过渡：面板的位移动画需要作用在面板元素上，故用非 scoped 块 */
.ds-dialog-enter-active .base-dialog,
.ds-dialog-leave-active .base-dialog { transition: transform var(--ds-dur) var(--ds-ease); }
.ds-dialog-enter-from,
.ds-dialog-leave-to { opacity: 0; }
.ds-dialog-enter-from .base-dialog,
.ds-dialog-leave-to .base-dialog { transform: translateY(14px) scale(0.985); }
</style>
