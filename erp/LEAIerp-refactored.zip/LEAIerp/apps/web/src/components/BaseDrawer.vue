<!--
 * BaseDrawer 通用弹层（居中弹窗版）
 * 职责：居中弹出、可拖拽改变大小、可一键最大化/还原，承载详情与表单。
 * 变更说明：原来是从右侧滑出的抽屉（placement=right），反馈体验差；
 *          现在统一改为居中弹窗，保留原有 props / 事件 / 插槽，页面无需改动调用方式。
 * 核心 props：title 标题、size 初始宽度、fullscreen 初始是否最大化、loading 内容区加载态、
 *            closeOnPressEscape 按 ESC 是否关闭。
 * 核心 emits：opened 打开动画结束、closed 关闭动画结束。
 * 插槽：默认插槽为主体；header 可替换标题区；footer 为底部操作区。
 -->
<template>
  <Teleport to="body">
    <Transition name="bd" @after-enter="emit('opened')" @after-leave="handleAfterLeave">
      <div v-if="visible" class="bd-mask" @mousedown.self="onMaskClick">
        <div
          class="bd"
          :class="{ 'is-max': maximized, 'is-resizing': resizing }"
          :style="dialogStyle"
          role="dialog"
          aria-modal="true"
        >
          <!-- 头部：标题 + 最大化 / 关闭 -->
          <header class="bd__head">
            <slot name="header">
              <span class="bd__title">{{ title }}</span>
            </slot>
            <div class="bd__ops">
              <IconButton
                :icon="maximized ? 'Aim' : 'FullScreen'"
                :title="maximized ? '还原' : '最大化'"
                size="sm"
                @click="toggleMax"
              />
              <button class="bd__close" type="button" aria-label="关闭" @click="close">✕</button>
            </div>
          </header>

          <!-- 内容区：loading 覆盖 + 默认插槽 -->
          <div class="bd__body">
            <div v-if="loading" class="bd__loading">
              <span class="bd__spin" />
              <span>加载中…</span>
            </div>
            <slot />
          </div>

          <!-- 底部操作区（父组件提供 footer 插槽时才渲染） -->
          <footer v-if="$slots.footer" class="bd__foot">
            <slot name="footer" />
          </footer>

          <!-- 拖拽改尺寸：右边缘 / 下边缘 / 右下角 -->
          <template v-if="!maximized">
            <span class="bd__rz bd__rz--x" title="拖动调整宽度" @pointerdown="startResize($event, 'x')" />
            <span class="bd__rz bd__rz--y" title="拖动调整高度" @pointerdown="startResize($event, 'y')" />
            <span class="bd__rz bd__rz--corner" title="拖动调整大小" @pointerdown="startResize($event, 'both')" />
          </template>
        </div>
      </div>
    </Transition>
  </Teleport>
</template>

<script setup lang="ts">
import { computed, nextTick, onBeforeUnmount, ref, watch } from 'vue';
import IconButton from './IconButton.vue';

/** 显隐双向绑定（父组件 v-model:visible） */
const visible = defineModel<boolean>('visible', { required: true });

const props = withDefaults(
  defineProps<{
    /** 标题 */
    title?: string;
    /** 初始宽度（px 数字或 '620px' / '60%' 字符串） */
    size?: string | number;
    /** 初始是否最大化 */
    fullscreen?: boolean;
    /** 内容区加载态 */
    loading?: boolean;
    /** 是否允许按 ESC 关闭（默认 true） */
    closeOnPressEscape?: boolean;
  }>(),
  { size: 720, fullscreen: false, loading: false, closeOnPressEscape: true },
);

const emit = defineEmits<{ (e: 'opened'): void; (e: 'closed'): void }>();

/* ---------------- 尺寸 ---------------- */

/** 最小 / 最大边界：既保证表单可用，又不让弹窗超出视口 */
const MIN_W = 420;
const MIN_H = 240;

/** 拖拽后的自定义尺寸（null 表示用 size / 内容自适应） */
const customW = ref<number | null>(null);
const customH = ref<number | null>(null);
const maximized = ref(false);
const resizing = ref(false);

/** size 解析：数字按 px，百分比按视口宽度换算 */
const baseWidth = computed(() => {
  const raw = props.size;
  if (typeof raw === 'number') return Math.max(MIN_W, raw);
  const text = String(raw || '').trim();
  if (!text) return 720;
  if (text.endsWith('%')) {
    const pct = Number(text.slice(0, -1));
    const vw = typeof window === 'undefined' ? 1440 : window.innerWidth;
    return Math.max(MIN_W, Math.round((vw * (Number.isFinite(pct) ? pct : 50)) / 100));
  }
  const num = Number(text.replace(/px$/, ''));
  return Number.isFinite(num) && num > 0 ? Math.max(MIN_W, num) : 720;
});

const dialogStyle = computed<Record<string, string>>(() => {
  if (maximized.value) return { width: '94vw', height: '90vh' };
  const style: Record<string, string> = { width: `${customW.value ?? baseWidth.value}px` };
  // 未手动拖过高度时自适应内容，最多 86vh
  if (customH.value) style.height = `${customH.value}px`;
  return style;
});

/** 最大化 / 还原 */
function toggleMax(): void {
  maximized.value = !maximized.value;
}

/* ---------------- 打开 / 关闭 ---------------- */

function close(): void {
  visible.value = false;
}

/** 遮罩点击不关闭：避免填了一半的表单被误触清空 */
function onMaskClick(): void {
  /* 有意留空，保持与原抽屉 mask-closable=false 的行为一致 */
}

function onKey(e: KeyboardEvent): void {
  if (e.key === 'Escape' && props.closeOnPressEscape) close();
}

function handleAfterLeave(): void {
  // 关闭后复位尺寸，下次打开回到默认大小
  customW.value = null;
  customH.value = null;
  resizing.value = false;
  emit('closed');
}

watch(
  () => visible.value,
  (open) => {
    if (typeof document === 'undefined') return;
    document.body.style.overflow = open ? 'hidden' : '';
    if (open) {
      document.addEventListener('keydown', onKey);
      maximized.value = props.fullscreen;
      void nextTick();
    } else {
      document.removeEventListener('keydown', onKey);
    }
  },
);

onBeforeUnmount(() => {
  if (typeof document === 'undefined') return;
  document.body.style.overflow = '';
  document.removeEventListener('keydown', onKey);
});

/* ---------------- 拖拽改大小 ---------------- */

type ResizeAxis = 'x' | 'y' | 'both';

function startResize(e: PointerEvent, axis: ResizeAxis): void {
  if (maximized.value) return;
  const el = (e.currentTarget as HTMLElement)?.parentElement;
  if (!el) return;
  e.preventDefault();
  e.stopPropagation();
  resizing.value = true;

  // 以当前实际渲染尺寸为基准，避免从 auto 高度起步时跳动
  const rect = el.getBoundingClientRect();
  const startX = e.clientX;
  const startY = e.clientY;
  const startW = rect.width;
  const startH = rect.height;
  customW.value = Math.round(startW);
  customH.value = Math.round(startH);

  const maxW = () => Math.max(MIN_W, window.innerWidth - 48);
  const maxH = () => Math.max(MIN_H, window.innerHeight - 64);

  const onMove = (ev: PointerEvent) => {
    if (axis === 'x' || axis === 'both') {
      customW.value = Math.min(maxW(), Math.max(MIN_W, Math.round(startW + (ev.clientX - startX))));
    }
    if (axis === 'y' || axis === 'both') {
      customH.value = Math.min(maxH(), Math.max(MIN_H, Math.round(startH + (ev.clientY - startY))));
    }
  };

  const onUp = () => {
    resizing.value = false;
    window.removeEventListener('pointermove', onMove);
    window.removeEventListener('pointerup', onUp);
  };

  window.addEventListener('pointermove', onMove);
  window.addEventListener('pointerup', onUp);
}
</script>

<style scoped>
.bd-mask {
  position: fixed;
  inset: 0;
  z-index: 1200;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 20px;
  background: var(--ds-mask, rgba(15, 20, 28, 0.45));
  backdrop-filter: blur(2px);
}

.bd {
  position: relative;
  display: flex;
  flex-direction: column;
  max-width: calc(100vw - 40px);
  max-height: 86vh;
  background: var(--ds-bg-elevated);
  border-radius: var(--ds-radius-lg);
  box-shadow: var(--ds-shadow-lg);
  overflow: hidden;
}
.bd.is-max {
  box-shadow: var(--ds-shadow-lg);
}
.bd.is-resizing {
  user-select: none;
}

.bd__head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  padding: 12px 12px 12px 20px;
  border-bottom: 1px solid var(--ds-divider);
  flex: 0 0 auto;
}
.bd__title {
  font-weight: 600;
  font-size: var(--ds-font-lg);
  color: var(--ds-text);
}
.bd__ops {
  display: flex;
  align-items: center;
  gap: 4px;
}
.bd__close {
  width: 28px;
  height: 28px;
  border: 0;
  border-radius: var(--ds-radius-sm);
  background: transparent;
  color: var(--ds-text-3);
  font-size: 13px;
  cursor: pointer;
}
.bd__close:hover {
  background: var(--ds-bg-hover);
  color: var(--ds-text);
}

.bd__body {
  position: relative;
  flex: 1 1 auto;
  min-height: 0;
  padding: 18px 20px;
  overflow: auto;
}

.bd__loading {
  position: absolute;
  inset: 0;
  z-index: 5;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  background: var(--ds-frosted);
  color: var(--ds-text-3);
  font-size: var(--ds-font-sm);
}
.bd__spin {
  width: 15px;
  height: 15px;
  border: 2px solid var(--ds-border);
  border-top-color: var(--ds-brand);
  border-radius: 50%;
  animation: ds-spin 0.7s linear infinite;
}

.bd__foot {
  flex: 0 0 auto;
  display: flex;
  justify-content: flex-end;
  gap: 10px;
  padding: 12px 20px;
  border-top: 1px solid var(--ds-divider);
}

/* 拖拽热区：边缘 6px，右下角 16px */
.bd__rz {
  position: absolute;
  z-index: 4;
}
.bd__rz--x {
  top: 0;
  right: 0;
  width: 6px;
  height: 100%;
  cursor: ew-resize;
}
.bd__rz--y {
  left: 0;
  bottom: 0;
  width: 100%;
  height: 6px;
  cursor: ns-resize;
}
.bd__rz--corner {
  right: 0;
  bottom: 0;
  width: 16px;
  height: 16px;
  cursor: nwse-resize;
  background: linear-gradient(135deg, transparent 46%, var(--ds-border-strong, var(--ds-border)) 48%, var(--ds-border-strong, var(--ds-border)) 56%, transparent 58%);
}
.bd__rz:hover {
  background-color: var(--ds-bg-hover);
}
.bd__rz--corner:hover {
  background-color: transparent;
}

/* 出入场：淡入 + 轻微上浮 */
.bd-fade-enter-active,
.bd-fade-leave-active {
  transition: opacity var(--ds-dur, 0.18s) var(--ds-ease, ease);
}
.bd-fade-enter-active .bd,
.bd-fade-leave-active .bd {
  transition: transform var(--ds-dur, 0.18s) var(--ds-ease, ease);
}
.bd-fade-enter-from,
.bd-fade-leave-to {
  opacity: 0;
}
.bd-fade-enter-from .bd,
.bd-fade-leave-to .bd {
  transform: translateY(10px) scale(0.98);
}
</style>
