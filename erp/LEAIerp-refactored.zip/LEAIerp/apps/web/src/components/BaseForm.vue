<!--
 * BaseForm 通用表单组件（DeepSeek UI 版）
 * 职责：根据传入的 fields 配置数组，动态渲染出完整表单（支持 input/number/textarea/select/
 *       remote-select/radio/checkbox/cascader/tree-select/switch/rate/slider/date/datetime/time/upload 等控件）。
 * 与旧版区别：控件全部切换为 ds 设计系统组件（DsInput/DsSelect/DsSwitch/…），
 *             校验为自实现（required 规则 + blur 触发），不再依赖 Element Plus。
 * 在页面中的位置/用途：通常被抽屉(Drawer)或对话框(Dialog)包裹，用于「新增/编辑」场景；也可作为页面内独立查询/录入表单。
 * 依赖的核心 props：fields（字段配置，必填）、readonly（整体只读）、labelWidth / labelPosition / gutter（布局相关）。
 * 双向绑定：通过 defineModel 暴露 model，父组件用 v-model 直接读写整张表单数据。
 * 字段级自定义：父组件可用 #field-{prop} 插槽覆盖任意字段的渲染逻辑。
 * 对外方法（defineExpose）：validate / validateField / resetFields / clearValidate。
 -->
<template>
  <!-- 配置化表单：24 列栅格，字段按 span 占位 -->
  <form class="base-form" :class="`is-${labelPosition}`" :style="{ '--bf-gutter': gutter + 'px' }" @submit.prevent>
    <div
      v-for="f in fields"
      :key="f.prop"
      class="base-form__item"
      :class="{ 'is-error': !!errors[f.prop] }"
      :style="{ gridColumn: `span ${f.span || 24}` }"
    >
      <!-- 标签：top 模式在控件上方，right/left 模式在左侧固定宽度 -->
      <label v-if="f.label" class="base-form__label" :class="{ 'is-required': f.required }" :style="labelStyle">
        {{ f.label }}
      </label>

      <!-- 控件区 -->
      <div class="base-form__control">
        <!-- 字段级自定义插槽：#field-{prop}，优先级最高 -->
        <slot v-if="hasFieldSlot(f.prop)" :name="`field-${f.prop}`" :model="model" :field="f" />

        <template v-else>
          <!-- 文本 / 数字输入 -->
          <DsInput
            v-if="f.type === 'input' || f.type === 'number' || !f.type"
            v-model="model[f.prop]"
            :type="f.type === 'number' ? 'number' : 'text'"
            :placeholder="f.placeholder"
            :disabled="isDisabled(f)"
            clearable
            @blur="validateField(f.prop)"
          />
          <!-- 多行文本域：固定 3 行 -->
          <DsInput
            v-else-if="f.type === 'textarea'"
            v-model="model[f.prop]"
            type="textarea"
            :rows="3"
            :placeholder="f.placeholder"
            :disabled="isDisabled(f)"
            @blur="validateField(f.prop)"
          />
          <!-- 下拉选择 -->
          <DsSelect
            v-else-if="f.type === 'select'"
            v-model="model[f.prop]"
            :options="f.options || []"
            :placeholder="f.placeholder"
            :disabled="isDisabled(f)"
            filterable
          />
          <!-- 远程搜索下拉：复用 BaseSelect，fetch 返回选项数组 -->
          <BaseSelect
            v-else-if="f.type === 'remote-select'"
            v-model="model[f.prop]"
            :fetch="f.fetch!"
            :multiple="f.multiple"
            :placeholder="f.placeholder"
            :disabled="isDisabled(f)"
          />
          <!-- 单选组 -->
          <div v-else-if="f.type === 'radio'" class="base-form__group">
            <DsRadio
              v-for="opt in f.options || []"
              :key="String(opt.value)"
              v-model="model[f.prop]"
              :value="opt.value"
              :disabled="isDisabled(f)"
            >
              {{ opt.label }}
            </DsRadio>
          </div>
          <!-- 多选组 -->
          <div v-else-if="f.type === 'checkbox'" class="base-form__group">
            <DsCheckbox
              v-for="opt in f.options || []"
              :key="String(opt.value)"
              v-model="model[f.prop]"
              :value="opt.value"
              :disabled="isDisabled(f)"
            >
              {{ opt.label }}
            </DsCheckbox>
          </div>
          <!-- 级联选择：options 为树形结构 -->
          <DsCascader
            v-else-if="f.type === 'cascader'"
            v-model="model[f.prop]"
            :options="f.options || []"
            :placeholder="f.placeholder"
            :disabled="isDisabled(f)"
          />
          <!-- 树选择 -->
          <DsTreeSelect
            v-else-if="f.type === 'tree-select'"
            v-model="model[f.prop]"
            :data="f.options || []"
            :placeholder="f.placeholder"
            :disabled="isDisabled(f)"
          />
          <!-- 开关 -->
          <DsSwitch v-else-if="f.type === 'switch'" v-model="model[f.prop]" :disabled="isDisabled(f)" />
          <!-- 评分 -->
          <DsRate v-else-if="f.type === 'rate'" v-model="model[f.prop]" :disabled="isDisabled(f)" />
          <!-- 滑块 -->
          <DsSlider v-else-if="f.type === 'slider'" v-model="model[f.prop]" :disabled="isDisabled(f)" show-value />
          <!-- 日期 / 日期时间 / 时间 -->
          <DsDatePicker
            v-else-if="f.type === 'date' || f.type === 'datetime' || f.type === 'time'"
            v-model="model[f.prop]"
            :type="f.type"
            :placeholder="f.placeholder"
            :disabled="isDisabled(f)"
          />
          <!-- 图片 / 文件上传 -->
          <BaseUpload v-else-if="f.type === 'upload'" v-model="model[f.prop]" :disabled="isDisabled(f)" />
        </template>

        <!-- 字段级错误 / 帮助文案：错误优先 -->
        <p v-if="errors[f.prop]" class="base-form__error">{{ errors[f.prop] }}</p>
        <p v-else-if="f.hint" class="base-form__hint">{{ f.hint }}</p>
      </div>
    </div>
  </form>
</template>

<script setup lang="ts">
// ref/computed/getCurrentInstance 状态与插槽检测；ds 控件全家桶；BaseSelect/BaseUpload 业务控件
import { ref, computed, getCurrentInstance, onMounted } from "vue";
import DsInput from "./ds/DsInput.vue";
import DsSelect from "./ds/DsSelect.vue";
import DsCheckbox from "./ds/DsCheckbox.vue";
import DsRadio from "./ds/DsRadio.vue";
import DsSwitch from "./ds/DsSwitch.vue";
import DsSlider from "./ds/DsSlider.vue";
import DsRate from "./ds/DsRate.vue";
import DsDatePicker from "./ds/DsDatePicker.vue";
import DsCascader from "./ds/DsCascader.vue";
import DsTreeSelect from "./ds/DsTreeSelect.vue";
import BaseSelect from "./BaseSelect.vue";
import BaseUpload from "./BaseUpload.vue";
import type { FormField } from "./types";

// model 双向绑定整个表单数据对象：父组件通过 v-model 读写；表单内各控件通过 model[f.prop] 直接绑定
const model = defineModel<Record<string, any>>({ required: true });

const props = withDefaults(
  defineProps<{
    /** 字段配置数组 */
    fields: FormField[];
    /** 标签宽度（right/left 模式生效） */
    labelWidth?: string;
    /** 表单整体只读：所有控件禁用 */
    readonly?: boolean;
    /** 标签对齐方式：right 右对齐 / left 左对齐 / top 顶部 */
    labelPosition?: "right" | "left" | "top";
    /** 栅格间隔（px） */
    gutter?: number;
  }>(),
  { labelWidth: "100px", readonly: false, labelPosition: "right", gutter: 16 }
);

/** 事件：校验失败（父组件可监听做提示） */
const emit = defineEmits<{ (e: "validate-fail", errors: Record<string, string>): void }>();

/** 字段错误表：prop -> 错误文案 */
const errors = ref<Record<string, string>>({});

/** 组件实例（读取父组件插槽） */
const instance = getCurrentInstance();

/** 初始模型快照（resetFields 用）：挂载时深拷贝一份 */
let initial: Record<string, any> = {};

/** 标签样式：top 模式不固定宽度 */
const labelStyle = computed(() => (props.labelPosition === "top" ? {} : { width: props.labelWidth, flex: `0 0 ${props.labelWidth}` }));

/**
 * 判断父组件是否提供了 #field-{prop} 插槽。
 * @param prop 字段名
 * @returns 是否提供
 */
function hasFieldSlot(prop: string): boolean {
  return !!instance?.slots?.[`field-${prop}`];
}

/**
 * 判断某个字段的控件是否应被禁用。
 * @param f 字段配置
 * @returns 是否禁用
 */
function isDisabled(f: FormField): boolean {
  return props.readonly || !!f.disabled;
}

/**
 * 判断某个字段的值是否为空（未填）。
 * @param v 字段值
 * @returns 是否为空
 */
function isEmpty(v: any): boolean {
  if (v === undefined || v === null || v === "") return true;
  if (Array.isArray(v) && v.length === 0) return true;
  return false;
}

/**
 * 校验单个字段（当前仅内置 required 规则）。
 * @param prop 字段名
 * @returns 是否通过
 */
function validateField(prop: string): boolean {
  const f = props.fields.find((x) => x.prop === prop);
  if (!f) return true;
  if (f.required && isEmpty(model.value[prop])) {
    errors.value[prop] = `${f.label}必填`;
    return false;
  }
  delete errors.value[prop];
  return true;
}

/**
 * 校验整张表单：逐字段跑规则，任一失败即拒绝。
 * 兼容 el-form 的用法：await formRef.value.validate() 在失败时抛错。
 * @returns Promise<void> 全部通过时 resolve；有失败字段时 reject（携带错误表）
 */
function validate(): Promise<void> {
  const errs: Record<string, string> = {};
  for (const f of props.fields) {
    if (!validateField(f.prop)) errs[f.prop] = errors.value[f.prop];
  }
  if (Object.keys(errs).length) {
    emit("validate-fail", errs);
    // 以 rejected Promise 抛错，保持「await validate() 失败即抛出」的兼容语义
    return Promise.reject(new Error(JSON.stringify(errs)));
  }
  return Promise.resolve();
}

/**
 * 重置表单：恢复挂载时的初始值并清空错误。
 * @returns 无
 */
function resetFields(): void {
  for (const k of Object.keys(initial)) {
    model.value[k] = Array.isArray(initial[k]) ? [...initial[k]] : initial[k];
  }
  errors.value = {};
}

/** 清空全部错误提示（不触碰数据） */
function clearValidate(): void {
  errors.value = {};
}

// 挂载：快照初始值，供 resetFields 恢复
onMounted(() => {
  initial = JSON.parse(JSON.stringify(model.value ?? {}));
});

/** 暴露给父组件：校验与重置 */
defineExpose({ validate, validateField, resetFields, clearValidate, errors });
</script>

<style scoped>
.base-form {
  display: grid;
  grid-template-columns: repeat(24, 1fr);
  gap: var(--bf-gutter) calc(var(--bf-gutter) * 1.25);
  width: 100%;
}

/* 表单项：top 模式纵向排列，right/left 横向排列 */
.base-form__item { display: flex; min-width: 0; }
.base-form.is-top .base-form__item { flex-direction: column; gap: 4px; }
.base-form.is-right .base-form__item,
.base-form.is-left .base-form__item { align-items: flex-start; gap: 10px; }

/* 标签 */
.base-form__label {
  flex: none;
  font-size: var(--ds-font-md);
  color: var(--ds-text-2);
  line-height: var(--ds-ctl-h-md);
  text-align: right;
  word-break: break-all;
}
.base-form.is-left .base-form__label { text-align: left; }
.base-form.is-top .base-form__label { line-height: 1.5; text-align: left; width: auto; flex: none; }
/* 必填星号 */
.base-form__label.is-required::before {
  content: "*";
  color: var(--ds-danger);
  margin-right: 4px;
}

/* 控件区 */
.base-form__control { flex: 1; min-width: 0; }

/* 单选 / 多选组：横向排列、允许换行 */
.base-form__group { display: flex; flex-wrap: wrap; gap: 8px 18px; min-height: var(--ds-ctl-h-md); align-items: center; }

/* 错误与帮助文案 */
.base-form__error {
  margin: 4px 0 0;
  font-size: var(--ds-font-xs);
  color: var(--ds-danger);
  line-height: 1.5;
}
.base-form__hint {
  margin: 4px 0 0;
  font-size: var(--ds-font-xs);
  color: var(--ds-text-3);
  line-height: 1.5;
}

/* 错误态：把子控件的边框染红（穿透 scoped 定位到控件内部） */
.base-form__item.is-error :deep(.ds-input-wrap),
.base-form__item.is-error :deep(.ds-select-trigger),
.base-form__item.is-error :deep(.ds-dp-trigger),
.base-form__item.is-error :deep(.ds-cascader-trigger),
.base-form__item.is-error :deep(.ds-treeselect-trigger) {
  border-color: var(--ds-danger);
}
</style>
