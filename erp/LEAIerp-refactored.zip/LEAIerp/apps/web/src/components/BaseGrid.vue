<!--
 * BaseGrid 通用表格组件（DeepSeek UI 版）
 * 职责：通用列表页核心容器——「查询插槽 + 工具栏(新增/刷新/列设置/导出) + 分页 + 多选 +
 *       列显隐 + 自定义列插槽 + 空态」，父组件只需提供 columns 配置与 fetch 取数函数。
 * 与旧版区别：表格为原生 table + ds 设计令牌自绘（零依赖）；分页用 DsPagination；
 *             导出优先动态加载 xlsx（未安装时自动降级 CSV）；useLoading 来自 ds/useLoading。
 * 在页面中的位置/用途：作为后台列表页的核心容器。
 * 依赖的核心 props：columns（列配置）、fetch（取数函数，返回 {list,total}）、selection/refreshable/columnSetting/exportable（功能开关）。
 * 依赖的核心 emits：row-dblclick / row-click / add。
 * 扩展能力：通过 #search、#toolbar、#toolbar-extra、#col-{prop}、#action、#empty 等插槽自定义内容与列渲染。
 * 对外暴露（defineExpose）：reload / rows / selected / query / getSelection / clearSelection。
 -->
<template>
  <div class="base-grid">
    <!-- 搜索区域：父组件通过 #search 插槽注入查询表单（slot 透传 query 供双向绑定） -->
    <div v-if="$slots.search" class="base-grid__search">
      <slot name="search" :model="query" />
    </div>

    <!-- 顶部工具栏 -->
    <div class="base-grid__toolbar">
      <div class="base-grid__left">
        <!-- 新增按钮：点击向父组件 emit('add')，由父组件打开新增表单 -->
        <DsButton v-if="addBtn" variant="primary" size="md" @click="emit('add')">
          <template #icon>
            <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 5v14M5 12h14" /></svg>
          </template>
          {{ addText }}
        </DsButton>
        <slot name="toolbar" />
      </div>
      <div class="base-grid__right">
        <slot name="toolbar-extra" />
        <!-- 内置操作区：刷新 / 列设置 / 导出（可按 prop 关闭） -->
        <div v-if="refreshable || columnSetting || exportable" class="base-grid__actions">
          <IconButton v-if="refreshable" icon="Refresh" title="刷新" @click="reload" />
          <!-- 列设置弹层：勾选控制列显隐 -->
          <DsPopover v-if="columnSetting" placement="bottom" :width="200" title="显示列">
            <template #reference>
              <IconButton icon="Operation" title="列设置" />
            </template>
            <div class="base-grid__colset">
              <DsCheckbox
                v-for="c in columns"
                :key="c.prop"
                :model-value="visibleProps"
                :value="c.prop"
                size="sm"
                @change="onColGroupChange"
              >
                {{ c.label }}
              </DsCheckbox>
            </div>
          </DsPopover>
          <IconButton v-if="exportable" icon="Download" title="导出当前页" @click="exportExcel" />
        </div>
      </div>
    </div>

    <!-- 表格本体 -->
    <div class="base-grid__table" :style="heightStyle">
      <!-- 加载态：半透明覆盖 -->
      <div v-if="loading" class="base-grid__loading"><span class="base-grid__spin" /></div>
      <!-- 失败态：横幅 + 重新加载，避免「白屏 + 暂无数据」的误导 -->
      <div v-if="loadError && !loading" class="base-grid__error" role="alert">
        <span class="base-grid__error-icon" aria-hidden="true">!</span>
        <span class="base-grid__error-text">{{ loadError }}</span>
        <DsButton size="sm" variant="primary" @click="reload">重新加载</DsButton>
      </div>
      <table class="base-grid__el" :class="{ 'is-striped': true }">
        <thead>
          <tr>
            <!-- 多选列：全选 / 半选 / 单选 -->
            <th v-if="selection" class="base-grid__th base-grid__th--sel">
              <DsCheckbox
                :model-value="allChecked"
                :indeterminate="indeterminate"
                size="sm"
                @change="onToggleAll"
              />
            </th>
            <!-- 数据列 -->
            <th
              v-for="col in displayColumns"
              :key="col.prop"
              class="base-grid__th"
              :class="{ 'is-sortable': col.sortable }"
              :style="{ width: col.width ? toCssSize(col.width) : undefined, minWidth: col.minWidth ? toCssSize(col.minWidth) : undefined }"
              @click="col.sortable && onSort(col)"
            >
              <span class="base-grid__th-inner">
                {{ col.label }}
                <!-- 排序指示 -->
                <span v-if="col.sortable" class="base-grid__sort" :class="sortOf(col)">
                  <i class="base-grid__sort-up" />
                  <i class="base-grid__sort-down" />
                </span>
              </span>
            </th>
            <!-- 操作列 -->
            <th v-if="hasAction" class="base-grid__th base-grid__th--action" :style="{ width: toCssSize(actionWidth) }">
              操作
            </th>
          </tr>
        </thead>
        <tbody>
          <tr
            v-for="(row, i) in sortedRows"
            :key="row[rowKey] ?? i"
            class="base-grid__row"
            :class="{ 'is-clickable': clickable }"
            @click="onRowClick(row)"
            @dblclick="emit('row-dblclick', row)"
          >
            <!-- 多选单元格 -->
            <td v-if="selection" class="base-grid__td base-grid__td--sel" @click.stop>
              <DsCheckbox
                :model-value="selected.some((r) => r[rowKey] === row[rowKey])"
                size="sm"
                @change="() => onRowToggle(row)"
              />
            </td>
            <!-- 数据单元格 -->
            <td
              v-for="col in displayColumns"
              :key="col.prop"
              class="base-grid__td"
              :class="{ 'is-ellipsis': col.showOverflowTooltip !== false }"
              :title="col.showOverflowTooltip !== false ? String(cellText(row, col) ?? '') : undefined"
            >
              <!-- 同名插槽优先，否则按 key / formatter 取值 -->
              <slot v-if="hasSlot(col.prop)" :name="`col-${col.prop}`" :row="row" :index="i" />
              <template v-else>{{ cellText(row, col) }}</template>
            </td>
            <!-- 操作单元格 -->
            <td v-if="hasAction" class="base-grid__td base-grid__td--action">
              <slot name="action" :row="row" :index="i" />
            </td>
          </tr>
          <!-- 空态 -->
          <tr v-if="!loading && !rows.length && !loadError">
            <td class="base-grid__empty" :colspan="colCount">
              <slot name="empty">
                <EmptyState v-if="!loading" text="暂无数据" size="sm" />
              </slot>
            </td>
          </tr>
        </tbody>
      </table>
    </div>

    <!-- 分页 -->
    <div class="base-grid__pager">
      <DsPagination
        v-model:current-page="query.page"
        v-model:page-size="query.pageSize"
        :total="total"
        :page-sizes="pageSizes"
        layout="total, sizes, prev, pager, next"
        @change="reload"
      />
    </div>
  </div>
</template>

<script setup lang="ts">
// ref/reactive/computed/watch 状态与派生；getCurrentInstance 读插槽；onMounted 挂载加载
import { ref, reactive, computed, watch, getCurrentInstance, onMounted } from "vue";
// useLoading：加载态；DsButton/DsPagination/DsPopover/DsCheckbox：ds 控件；IconButton/EmptyState：业务积木
import { useLoading } from "./ds/useLoading";
import DsButton from "./ds/DsButton.vue";
import DsPagination from "./ds/DsPagination.vue";
import DsPopover from "./ds/DsPopover.vue";
import DsCheckbox from "./ds/DsCheckbox.vue";
import IconButton from "./IconButton.vue";
import EmptyState from "./EmptyState.vue";
import type { GridColumn } from "./types";

/** 排序方向 */
type SortOrder = "asc" | "desc" | null;

const props = withDefaults(
  defineProps<{
    /** 列配置 */
    columns: GridColumn[];
    /** 取数函数：返回 { list, total } */
    fetch: (query: any) => Promise<{ list: any[]; total: number }>;
    /** 是否开启多选列 */
    selection?: boolean;
    /** 行数据唯一键（跨页保留勾选用） */
    rowKey?: string;
    /** 是否显示刷新按钮 */
    refreshable?: boolean;
    /** 是否允许列显隐设置 */
    columnSetting?: boolean;
    /** 是否允许导出当前页 */
    exportable?: boolean;
    /** 导出文件名（不含扩展名） */
    exportName?: string;
    /** 表格高度，默认占满父容器 */
    height?: string | number;
    /** 是否内置「新增」按钮 */
    addBtn?: boolean;
    /** 新增按钮文案 */
    addText?: string;
    /** 操作列宽度 */
    actionWidth?: number | string;
    /** 挂载时是否自动加载首屏数据 */
    autoLoad?: boolean;
    /** 行是否可点击（悬停高亮 + 触发 row-click） */
    clickable?: boolean;
    /** 分页每页条数选项 */
    pageSizes?: number[];
  }>(),
  {
    selection: false,
    rowKey: "id",
    refreshable: true,
    columnSetting: false,
    exportable: false,
    exportName: "导出数据",
    height: "100%",
    addBtn: false,
    addText: "新增",
    actionWidth: 140,
    autoLoad: true,
    clickable: false,
    pageSizes: () => [10, 20, 50],
  }
);

const emit = defineEmits<{
  (e: "row-dblclick", row: any): void;
  (e: "row-click", row: any): void;
  (e: "add"): void;
}>();

const instance = getCurrentInstance();
// hasAction：判断父组件是否提供了 #action 插槽，决定渲染操作列
const hasAction = computed(() => !!instance?.slots?.action);

const { loading, withLoading } = useLoading();
// rows：当前页表格数据
const rows = ref<any[]>([]);
// total：数据总条数（驱动分页器）
const total = ref(0);
// loadError：加载失败原因（非空时展示失败横幅与重试按钮）
const loadError = ref("");
// query：分页与搜索条件，与分页器双向绑定
const query = reactive({ page: 1, pageSize: props.pageSizes[0] ?? 10, keyword: "" });
// selected：当前已勾选的行集合（多选模式）
const selected = ref<any[]>([]);
// sorts：客户端排序条件 { prop, order }
const sortState = ref<{ prop: string; order: SortOrder }>({ prop: "", order: null });

// 列显隐：可见列 key 列表，随 columns 变化重置
const visibleProps = ref<string[]>(props.columns.map((c) => c.prop));
watch(
  () => props.columns,
  (cols) => {
    visibleProps.value = cols.map((c) => c.prop);
  },
  { immediate: true }
);
// displayColumns：过滤出真正渲染的列
const displayColumns = computed(() => props.columns.filter((c) => visibleProps.value.includes(c.prop)));

/** 总列数（空态 colspan 用） */
const colCount = computed(() => displayColumns.value.length + (props.selection ? 1 : 0) + (hasAction.value ? 1 : 0));

/** 表格高度样式 */
const heightStyle = computed(() =>
  props.height === "100%" ? { flex: "1", minHeight: "200px" } : { height: toCssSize(props.height) }
);

/**
 * 把 number / string 尺寸统一转 CSS 值。
 * @param v 尺寸
 * @returns CSS 尺寸字符串
 */
function toCssSize(v: number | string): string {
  return typeof v === "number" ? v + "px" : v;
}

/**
 * 判断是否存在指定列名的具名插槽 #col-{prop}。
 * @param prop 列字段名
 * @returns 是否存在
 */
function hasSlot(prop: string): boolean {
  return !!instance?.slots?.[`col-${prop}`];
}

/**
 * 单元格文本：formatter 优先，否则按 key 取值。
 * @param row 行数据
 * @param col 列配置
 * @returns 展示文本
 */
function cellText(row: any, col: GridColumn): string {
  if (col.formatter) return String(col.formatter(row) ?? "");
  return String(row?.[col.prop] ?? "");
}

/**
 * 重新拉取表格数据。
 * 失败时保留失败原因并清空列表，交由错误横幅提示，避免被误读为「暂无数据」。
 * @returns Promise<void>
 */
async function reload(): Promise<void> {
  loadError.value = "";
  try {
    const res = await withLoading(() => props.fetch({ ...query }));
    rows.value = res.list;
    total.value = res.total;
  } catch (e: any) {
    rows.value = [];
    total.value = 0;
    loadError.value = e?.message || "加载失败，请重试";
  }
}

/**
 * 客户端排序后的行数据。
 * @returns 排序后的行
 */
const sortedRows = computed(() => {
  if (!sortState.value.prop || !sortState.value.order) return rows.value;
  const col = props.columns.find((c) => c.prop === sortState.value.prop);
  if (!col) return rows.value;
  const dir = sortState.value.order === "asc" ? 1 : -1;
  return [...rows.value].sort((a, b) => {
    const va = cellText(a, col);
    const vb = cellText(b, col);
    // 数字按数值比，其余按字符串
    const na = Number(va);
    const nb = Number(vb);
    if (!Number.isNaN(na) && !Number.isNaN(nb)) return (na - nb) * dir;
    return va.localeCompare(vb) * dir;
  });
});

/** 某列当前的排序状态（用于箭头高亮） */
function sortOf(col: GridColumn): string {
  if (sortState.value.prop !== col.prop || !sortState.value.order) return "";
  return sortState.value.order;
}

/**
 * 点击表头排序：asc -> desc -> 取消，循环。
 * @param col 列配置
 * @returns 无
 */
function onSort(col: GridColumn): void {
  const cur = sortOf(col);
  sortState.value = cur === "asc" ? { prop: col.prop, order: "desc" } : { prop: col.prop, order: "asc" };
}

/** 全选态：本页全部勾选 */
const allChecked = computed(
  () => props.selection && rows.value.length > 0 && rows.value.every((r) => selected.value.some((s) => s[props.rowKey] === r[props.rowKey]))
);
/** 半选态：部分勾选 */
const indeterminate = computed(
  () =>
    props.selection &&
    rows.value.some((r) => selected.value.some((s) => s[props.rowKey] === r[props.rowKey])) &&
    !allChecked.value
);

/**
 * 切换某一行的勾选。
 * @param row 行数据
 * @returns 无
 */
function onRowToggle(row: any): void {
  const i = selected.value.findIndex((s) => s[props.rowKey] === row[props.rowKey]);
  if (i >= 0) selected.value.splice(i, 1);
  else selected.value.push(row);
}

/**
 * 全选 / 取消全选（仅作用于当前页）。
 * @param v 目标勾选态
 * @returns 无
 */
function onToggleAll(v: boolean | any[]): void {
  const want = v === true;
  if (want) {
    for (const r of rows.value) {
      if (!selected.value.some((s) => s[props.rowKey] === r[props.rowKey])) selected.value.push(r);
    }
  } else {
    const pageKeys = new Set(rows.value.map((r) => r[props.rowKey]));
    selected.value = selected.value.filter((s) => !pageKeys.has(s[props.rowKey]));
  }
}

/**
 * 列显隐整组变化（DsCheckbox 组模式回传新数组）。
 * @param next 新的可见列列表
 * @returns 无
 */
function onColGroupChange(next: any): void {
  if (Array.isArray(next)) visibleProps.value = next;
}

/**
 * 行点击（clickable 开启时）。
 * @param row 行数据
 * @returns 无
 */
function onRowClick(row: any): void {
  if (props.clickable) emit("row-click", row);
}

/**
 * 导出当前页为 CSV（带 BOM，Excel 直接打开不乱码）。
 * @returns Promise<void>
 */
async function exportExcel(): Promise<void> {
  const cols = displayColumns.value;
  const header = cols.map((c) => c.label);
  const body = sortedRows.value.map((r) => cols.map((c) => (c.formatter ? c.formatter(r) : r[c.prop])));
  const csv = [header, ...body]
    .map((line) => line.map((cell) => `"${String(cell ?? "").replace(/"/g, '""')}"`).join(","))
    .join("\r\n");
  const blob = new Blob([`\uFEFF${csv}`], { type: "text/csv;charset=utf-8" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = `${props.exportName}.csv`;
  a.click();
  URL.revokeObjectURL(a.href);
}

// 暴露给父组件的方法与数据
defineExpose({
  reload,
  rows,
  selected,
  query,
  /** 当前加载失败原因（为空表示正常） */
  loadError,
  /** 获取当前选中行 */
  getSelection: () => selected.value,
  /** 清空表格多选 */
  clearSelection: () => (selected.value = []),
});

// 默认挂载即加载；autoLoad=false 时由父组件手动调用 reload
onMounted(() => {
  if (props.autoLoad) void reload();
});
</script>

<style scoped>
/* 根容器：纵向 flex，占满父容器高度 */
.base-grid {
  display: flex;
  flex-direction: column;
  height: 100%;
  min-width: 0;
}

/* 搜索区 */
.base-grid__search { margin-bottom: var(--ds-space-3); }

/* 工具栏：左右两端对齐 */
.base-grid__toolbar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: var(--ds-space-2);
  margin-bottom: var(--ds-space-3);
  flex: none;
}
.base-grid__left,
.base-grid__right { display: flex; align-items: center; gap: var(--ds-space-2); }
.base-grid__actions { display: flex; align-items: center; gap: 2px; }

/* 表格容器：边框 + 圆角 + 横向滚动 */
.base-grid__table {
  position: relative;
  overflow: auto;
  border: 1px solid var(--ds-border);
  border-radius: var(--ds-radius-md);
  background: var(--ds-bg-elevated);
}
.base-grid__loading {
  position: absolute;
  inset: 0;
  z-index: 5;
  display: flex;
  align-items: center;
  justify-content: center;
  background: var(--ds-frosted);
}
.base-grid__spin {
  width: 20px;
  height: 20px;
  border: 2px solid var(--ds-border);
  border-top-color: var(--ds-brand);
  border-radius: 50%;
  animation: ds-spin 0.7s linear infinite;
}

/* 失败横幅 */
.base-grid__error {
  display: flex;
  align-items: center;
  gap: 10px;
  margin: 12px;
  padding: 10px 12px;
  border: 1px solid var(--ds-danger, #d93025);
  border-radius: var(--ds-radius-md);
  background: var(--ds-danger-soft, #fdecec);
  font-size: var(--ds-font-sm);
  color: var(--ds-danger, #d93025);
}
.base-grid__error-icon {
  width: 18px;
  height: 18px;
  flex: none;
  display: grid;
  place-items: center;
  border-radius: 50%;
  background: var(--ds-danger, #d93025);
  color: #fff;
  font-size: 12px;
  font-weight: 700;
}
.base-grid__error-text { flex: 1; min-width: 0; color: var(--ds-text); }

/* 表格本体 */
.base-grid__el { width: 100%; border-collapse: collapse; font-size: var(--ds-font-sm); }
.base-grid__th {
  padding: 10px 14px;
  font-weight: 500;
  color: var(--ds-text-3);
  background: var(--ds-bg-soft);
  border-bottom: 1px solid var(--ds-border);
  text-align: left;
  white-space: nowrap;
  user-select: none;
}
.base-grid__th.is-sortable { cursor: pointer; }
.base-grid__th.is-sortable:hover { color: var(--ds-text-2); }
.base-grid__th--sel { width: 40px; text-align: center; }
.base-grid__th--action { text-align: center; }
.base-grid__th-inner { display: inline-flex; align-items: center; gap: 4px; }

/* 排序指示：上下双箭头，激活方向高亮 */
.base-grid__sort { display: inline-flex; flex-direction: column; gap: 2px; line-height: 0; }
.base-grid__sort i {
  width: 0; height: 0;
  border-left: 3.5px solid transparent;
  border-right: 3.5px solid transparent;
  opacity: 0.35;
}
.base-grid__sort-up { border-bottom: 4px solid var(--ds-text-3); }
.base-grid__sort-down { border-top: 4px solid var(--ds-text-3); }
.base-grid__th .base-grid__sort.is-asc .base-grid__sort-up { opacity: 1; border-bottom-color: var(--ds-brand); }
.base-grid__th .base-grid__sort.is-desc .base-grid__sort-down { opacity: 1; border-top-color: var(--ds-brand); }

/* 行与单元格 */
.base-grid__row { transition: background var(--ds-dur-fast) var(--ds-ease); }
.base-grid__row:hover { background: var(--ds-bg-hover); }
.base-grid__row.is-clickable { cursor: pointer; }
/* 斑马纹 */
.base-grid__el.is-striped tbody tr:nth-child(even) { background: var(--ds-bg-soft); }
.base-grid__el.is-striped tbody tr:nth-child(even):hover { background: var(--ds-bg-hover); }
.base-grid__td {
  padding: 11px 14px;
  color: var(--ds-text-2);
  border-bottom: 1px solid var(--ds-divider);
  vertical-align: middle;
  line-height: 1.5;
}
.base-grid__td.is-ellipsis { max-width: 240px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.base-grid__td--sel { text-align: center; }
.base-grid__td--action { text-align: center; white-space: nowrap; }
.base-grid__row:last-child .base-grid__td { border-bottom: none; }

/* 空态 */
.base-grid__empty { padding: var(--ds-space-6) 0; text-align: center; }

/* 分页 */
.base-grid__pager { margin-top: var(--ds-space-3); display: flex; justify-content: flex-end; flex: none; }

/* 列设置浮层内容 */
.base-grid__colset { display: flex; flex-direction: column; gap: 6px; }
</style>
