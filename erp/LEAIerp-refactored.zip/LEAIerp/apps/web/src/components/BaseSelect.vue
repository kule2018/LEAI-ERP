<!--
 * BaseSelect 远程搜索下拉选择组件（DeepSeek UI 版）
 * 职责：封装远程取数 + 防抖搜索的下拉选择，对外提供统一的 v-model 选中值、
 *       首屏即时加载（immediate）、展开时懒加载首屏、对象值映射（valueKey）等能力。
 * 与旧版区别：基于 ds 设计令牌自绘（usePopover + 自绘浮层），不再依赖 Element Plus。
 * 页面位置 / 用途：用于选项数据来自后端接口、需要关键字检索的下拉场景。
 * 核心 props：fetch 取数函数（必填）、placeholder 占位文案、multiple 多选、clearable 可清除、
 *            immediate 挂载即加载、debounce 防抖毫秒、valueKey 对象值取值字段。
 * 对外暴露（defineExpose）：reload 重新加载选项、options 当前选项列表。
 -->
<template>
  <!-- 远程下拉：自绘浮层，v-model 绑定选中值 -->
  <div ref="rootRef" class="base-select" :class="[{ 'is-open': open, 'is-disabled': disabled }]">
    <!-- 触发器 -->
    <div class="base-select__trigger" :tabindex="disabled ? -1 : 0" @click="!disabled && toggle()">
      <!-- 多选：已选标签 -->
      <span v-if="multiple" class="base-select__tags">
        <span v-for="(opt, i) in selectedOptions" :key="i" class="base-select__tag">
          {{ opt.label }}
          <button type="button" title="移除" @click.stop="removeTag(opt)">✕</button>
        </span>
        <span v-if="!selectedOptions.length" class="base-select__ph">{{ placeholder }}</span>
      </span>
      <!-- 单选：文案或占位符 -->
      <span v-else class="base-select__value" :class="{ 'is-ph': !hasValue }">
        {{ hasValue ? selectedLabel : placeholder }}
      </span>
      <!-- 右侧功能区：加载 / 清空 / 箭头 -->
      <span class="base-select__icons">
        <span v-if="loading" class="base-select__spin" />
        <button v-else-if="clearable && hasValue" type="button" class="base-select__clear" title="清空" @click.stop="clearAll">✕</button>
        <svg class="base-select__arrow" :class="{ 'is-flip': open }" viewBox="0 0 24 24" aria-hidden="true"><path d="m6 9 6 6 6-6" /></svg>
      </span>
    </div>

    <!-- 浮层 -->
    <div v-if="open" class="base-select__pop">
      <!-- 搜索框：远程过滤入口 -->
      <div class="base-select__search">
        <input v-model="keyword" type="text" placeholder="输入关键字搜索…" @input="onSearchInput" @keydown="onKeydown" />
      </div>
      <!-- 选项列表 -->
      <ul v-if="shownOptions.length" class="base-select__list">
        <li
          v-for="(opt, i) in shownOptions"
          :key="optKey(opt, i)"
          class="base-select__opt"
          :class="{ 'is-active': isActive(opt), 'is-hl': i === activeIndex, 'is-disabled': opt.disabled }"
          @click="pick(opt)"
          @mouseenter="activeIndex = i"
        >
          <span class="base-select__opt-label">{{ opt.label }}</span>
          <svg v-if="isActive(opt)" class="base-select__check" viewBox="0 0 24 24" aria-hidden="true"><path d="M20 6 9 17l-5-5" /></svg>
        </li>
      </ul>
      <!-- 空态 -->
      <div v-else class="base-select__empty">{{ loading ? "搜索中…" : "暂无匹配选项" }}</div>
    </div>
  </div>
</template>

<script setup lang="ts">
// ref/onMounted/computed/watch 状态与派生；usePopover 浮层控制；useLoading 加载态；SelectOption 选项类型
import { ref, onMounted, computed, watch } from "vue";
import { usePopover } from "./ds/usePopover";
import { useLoading } from "./ds/useLoading";
import type { SelectOption } from "./types";

// model: 选中值（父组件 v-model），类型 any 以支持字符串 / 数字 / 对象
const model = defineModel<any>({ required: true });

const props = withDefaults(
  defineProps<{
    /** 取数函数：传入关键字，返回选项数组 */
    fetch: (keyword: string) => Promise<SelectOption[]>;
    /** 占位文案 */
    placeholder?: string;
    /** 是否多选 */
    multiple?: boolean;
    /** 是否可清空 */
    clearable?: boolean;
    /** 是否允许把输入值创建为新选项 */
    allowCreate?: boolean;
    /** 挂载即加载首屏数据 */
    immediate?: boolean;
    /** 远程搜索防抖毫秒 */
    debounce?: number;
    /** 是否禁用 */
    disabled?: boolean;
  }>(),
  {
    placeholder: "请输入关键字搜索",
    multiple: false,
    clearable: true,
    allowCreate: false,
    immediate: false,
    debounce: 300,
    disabled: false,
  }
);

// 浮层控制
const { open, rootRef, toggle, close } = usePopover();
// 仅由模板的 ref="rootRef" 绑定（字符串 ref 不被 TS 计为使用）
void rootRef;
// 加载态
const { loading, withLoading } = useLoading();

/** 当前下拉可选项列表 */
const options = ref<SelectOption[]>([]);
/** 浮层内搜索关键字 */
const keyword = ref("");
/** 键盘高亮项下标 */
const activeIndex = ref(0);

/** 是否已有值 */
const hasValue = computed(() => {
  if (props.multiple) return Array.isArray(model.value) && model.value.length > 0;
  return model.value !== "" && model.value !== undefined && model.value !== null;
});

/** 单选：选中项文案 */
const selectedLabel = computed(() => {
  if (props.multiple) return "";
  const hit = options.value.find((o) => o.value === model.value);
  return hit ? hit.label : String(model.value ?? "");
});

/** 多选：已选选项对象列表 */
const selectedOptions = computed<SelectOption[]>(() => {
  if (!props.multiple || !Array.isArray(model.value)) return [];
  return model.value.map((v) => options.value.find((o) => o.value === v) ?? { label: String(v), value: v });
});

/** 过滤后的选项（浮层内再做一次本地过滤，命中远程结果集） */
const shownOptions = computed(() => {
  const kw = keyword.value.trim().toLowerCase();
  const list = !kw
    ? options.value
    : options.value.filter((o) => String(o.label).toLowerCase().includes(kw));
  // allowCreate：输入值没有完全匹配项时，允许把输入值创建为新选项
  if (props.allowCreate && kw && !list.some((o) => String(o.label).toLowerCase() === kw)) {
    return [{ label: `创建「${keyword.value.trim()}」`, value: keyword.value.trim() }, ...list];
  }
  return list;
});

/**
 * 选项唯一 key：优先 value，回退 label + 下标。
 * @param opt 选项
 * @param i 下标
 * @returns key 字符串
 */
function optKey(opt: SelectOption, i: number): string {
  return `${String(opt.value)}-${i}`;
}

/**
 * 判断某个选项是否已选中。
 * @param opt 选项
 * @returns 是否选中
 */
function isActive(opt: SelectOption): boolean {
  if (props.multiple) return Array.isArray(model.value) && model.value.includes(opt.value);
  return model.value === opt.value;
}

/**
 * 加载选项：调用外部 fetch 取数。
 * @param kw 搜索关键字（默认空串）
 * @returns Promise<void>
 */
async function load(kw = ""): Promise<void> {
  options.value = await withLoading(() => props.fetch(kw));
}

// 防抖定时器句柄
let timer: ReturnType<typeof setTimeout> | null = null;

/**
 * 浮层搜索输入：防抖后远程取数。
 * @returns 无
 */
function onSearchInput(): void {
  if (timer) clearTimeout(timer);
  timer = setTimeout(() => void load(keyword.value), props.debounce);
}

/**
 * 点击某个选项：单选写入并收起；多选切换勾选。
 * @param opt 选项
 * @returns 无
 */
function pick(opt: SelectOption): void {
  if (opt.disabled) return;
  if (props.multiple) {
    const arr = Array.isArray(model.value) ? [...model.value] : [];
    const i = arr.indexOf(opt.value);
    if (i >= 0) arr.splice(i, 1);
    else arr.push(opt.value);
    model.value = arr;
  } else {
    model.value = opt.value;
    close();
  }
}

/**
 * 多选模式下移除某个已选标签。
 * @param opt 选项
 * @returns 无
 */
function removeTag(opt: SelectOption): void {
  if (!props.multiple || !Array.isArray(model.value)) return;
  model.value = model.value.filter((v) => v !== opt.value);
}

/** 清空全部选择 */
function clearAll(): void {
  model.value = props.multiple ? [] : "";
}

/** 键盘导航：↑/↓ 移动，Enter 选中，Esc 收起 */
function onKeydown(e: KeyboardEvent): void {
  const list = shownOptions.value.filter((o) => !o.disabled);
  if (e.key === "ArrowDown" || e.key === "ArrowUp") {
    e.preventDefault();
    if (!list.length) return;
    const dir = e.key === "ArrowDown" ? 1 : -1;
    activeIndex.value = (activeIndex.value + dir + list.length) % list.length;
  } else if (e.key === "Enter") {
    const opt = list[activeIndex.value];
    if (opt) {
      e.preventDefault();
      pick(opt);
    }
  } else if (e.key === "Escape") {
    close();
  }
}

// 展开浮层：重置关键字；首屏未加载过则拉取（懒加载首屏）
watch(open, (v) => {
  if (!v) return;
  keyword.value = "";
  activeIndex.value = 0;
  if (!options.value.length) void load();
});

// 挂载：immediate 时预加载首屏
onMounted(() => {
  if (props.immediate) void load();
});

/** 暴露 reload 与当前选项供父组件取用 */
defineExpose({ reload: load, options });
</script>

<style scoped>
.base-select { position: relative; width: 100%; font-size: var(--ds-font-md); }

/* 触发器（与 DsSelect 同构） */
.base-select__trigger {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
  min-height: var(--ds-ctl-h-md);
  padding: 0 10px 0 12px;
  background: var(--ds-bg-elevated);
  border: 1px solid var(--ds-border);
  border-radius: var(--ds-radius-sm);
  cursor: pointer;
  transition: border-color var(--ds-dur-fast) var(--ds-ease), box-shadow var(--ds-dur-fast) var(--ds-ease);
}
.base-select__trigger:hover { border-color: var(--ds-border-strong); }
.base-select.is-open .base-select__trigger { border-color: var(--ds-brand); box-shadow: 0 0 0 3px var(--ds-brand-soft); }
.base-select.is-disabled .base-select__trigger { background: var(--ds-bg-hover); cursor: not-allowed; }

.base-select__value,
.base-select__ph {
  flex: 1; min-width: 0;
  overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
  color: var(--ds-text); text-align: left;
}
.base-select__value.is-ph { color: var(--ds-text-3); }

.base-select__tags { flex: 1; display: flex; flex-wrap: wrap; gap: 4px; padding: 4px 0; min-width: 0; }
.base-select__tag {
  display: inline-flex; align-items: center; gap: 2px;
  padding: 1px 4px 1px 8px;
  background: var(--ds-brand-soft); color: var(--ds-brand);
  border-radius: var(--ds-radius-xs);
  font-size: var(--ds-font-xs); line-height: 1.6;
}
.base-select__tag button {
  border: 0; background: transparent; color: inherit;
  cursor: pointer; font-size: 10px; line-height: 1; padding: 0 2px; border-radius: 50%;
}
.base-select__tag button:hover { background: rgba(0, 0, 0, 0.12); }

.base-select__icons { display: inline-flex; align-items: center; gap: 6px; flex: none; color: var(--ds-text-3); }
.base-select__spin {
  width: 12px; height: 12px;
  border: 2px solid var(--ds-border);
  border-top-color: var(--ds-brand);
  border-radius: 50%;
  animation: ds-spin 0.7s linear infinite;
}
.base-select__clear {
  border: 0; background: transparent; color: var(--ds-text-3);
  cursor: pointer; font-size: var(--ds-font-xs); padding: 2px; border-radius: var(--ds-radius-xs);
}
.base-select__clear:hover { background: var(--ds-bg-hover); color: var(--ds-text); }
.base-select__arrow {
  width: 16px; height: 16px;
  fill: none; stroke: currentColor; stroke-width: 2; stroke-linecap: round; stroke-linejoin: round;
  transition: transform var(--ds-dur-fast) var(--ds-ease);
}
.base-select__arrow.is-flip { transform: rotate(180deg); }

/* 浮层 */
.base-select__pop {
  position: absolute;
  top: calc(100% + 6px);
  left: 0; right: 0;
  z-index: 100;
  background: var(--ds-bg-elevated);
  border: 1px solid var(--ds-border);
  border-radius: var(--ds-radius);
  box-shadow: var(--ds-shadow-md);
  overflow: hidden;
}
.base-select__search { padding: 8px; border-bottom: 1px solid var(--ds-divider); }
.base-select__search input {
  width: 100%; height: 30px; padding: 0 10px;
  border: 1px solid var(--ds-border); border-radius: var(--ds-radius-xs);
  background: var(--ds-bg); color: var(--ds-text);
  font-size: var(--ds-font-sm); outline: none; font-family: inherit;
}
.base-select__search input:focus { border-color: var(--ds-brand); }

.base-select__list { margin: 0; padding: 4px; list-style: none; max-height: 240px; overflow-y: auto; }
.base-select__opt {
  display: flex; align-items: center; justify-content: space-between; gap: 8px;
  padding: 7px 10px;
  border-radius: var(--ds-radius-xs);
  color: var(--ds-text-2); font-size: var(--ds-font-sm);
  cursor: pointer;
  transition: background var(--ds-dur-fast) var(--ds-ease);
}
.base-select__opt-label { flex: 1; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.base-select__opt.is-hl { background: var(--ds-bg-hover); }
.base-select__opt.is-active { color: var(--ds-brand); background: var(--ds-brand-soft); font-weight: 500; }
.base-select__opt.is-disabled { opacity: 0.45; cursor: not-allowed; }
.base-select__check {
  width: 14px; height: 14px; flex: none;
  fill: none; stroke: currentColor; stroke-width: 2.5; stroke-linecap: round; stroke-linejoin: round;
}
.base-select__empty { padding: 20px 0; text-align: center; color: var(--ds-text-3); font-size: var(--ds-font-sm); }
</style>
