<!--
 * BaseTable 全功能表格组件（DeepSeek UI 版）
 * 职责：在 BaseGrid 能力之上进一步集成「内置关键字搜索 / 树形懒加载 / 展开行 / 合计行 /
 *       服务端排序 / 密度切换 / 列显隐持久化 / 导出」等高级能力。
 * 与旧版区别：原生 table + ds 设计令牌自绘；树形 / 展开 / 合计均为自实现，零第三方表格库。
 * 在页面中的位置/用途：后台复杂列表页核心组件，父组件仅需提供 columns 与 fetch。
 * 依赖的核心 props：columns、fetch、searchable、serverSort、treeProp、lazy、load、showSummary、columnKey、sizeable 等。
 * 依赖的核心 emits：row-dblclick、row-click、add、sort-change、current-change、search。
 * 扩展插槽：#search、#toolbar、#toolbar-extra、#expand、#col-{prop}、#action、#empty。
 * 对外暴露（defineExpose）：reload / rows / selected / query / getSelection / clearSelection / getSort / getSize。
 -->
<template>
  <div class="base-table">
    <!-- 搜索区：searchable 时内置关键字搜索框；或父组件 #search 自定义查询表单 -->
    <div v-if="searchable || $slots.search" class="base-table__search">
      <div v-if="searchable" class="base-table__search-box">
        <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M11 19a8 8 0 1 0 0-16 8 8 0 0 0 0 16Zm10 2-4.35-4.35" /></svg>
        <input v-model="query.keyword" type="text" :placeholder="searchPlaceholder || '请输入关键字搜索'" @input="onSearchInput" />
        <button v-if="query.keyword" type="button" title="清空" @click="query.keyword = ''; onSearchInput()">✕</button>
      </div>
      <slot name="search" :model="query" />
    </div>

    <!-- 顶部工具栏 -->
    <div class="base-table__toolbar">
      <div class="base-table__left">
        <DsButton v-if="addBtn" variant="primary" size="md" @click="emit('add')">
          <template #icon>
            <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 5v14M5 12h14" /></svg>
          </template>
          {{ addText }}
        </DsButton>
        <slot name="toolbar" />
      </div>
      <div class="base-table__right">
        <slot name="toolbar-extra" />
        <!-- 内置操作区：密度 / 刷新 / 列设置 / 导出 -->
        <div v-if="sizeable || refreshable || columnSetting || exportable" class="base-table__actions">
          <!-- 密度切换下拉 -->
          <DsDropdown v-if="sizeable" :items="sizeItems" placement="bottom-end" @command="onSizeCommand">
            <IconButton icon="Menu" title="密度" />
          </DsDropdown>
          <IconButton v-if="refreshable" icon="Refresh" title="刷新" @click="reload" />
          <!-- 列设置弹层（含持久化） -->
          <DsPopover v-if="columnSetting" placement="bottom" :width="200" title="显示列">
            <template #reference>
              <IconButton icon="Operation" title="列设置" />
            </template>
            <div class="base-table__colset">
              <DsCheckbox
                v-for="c in columns"
                :key="c.prop"
                :model-value="visibleProps"
                :value="c.prop"
                size="sm"
                @change="onColGroupChange"
              >
                {{ c.label }}
              </DsCheckbox>
            </div>
          </DsPopover>
          <IconButton v-if="exportable" icon="Download" title="导出当前页" @click="exportExcel" />
        </div>
      </div>
    </div>

    <!-- 表格本体 -->
    <div class="base-table__wrap" :class="`is-${tableSize}`" :style="heightStyle">
      <!-- 加载态 -->
      <div v-if="loading" class="base-table__loading"><span class="base-table__spin" /></div>

      <table class="base-table__el" :class="{ 'is-striped': striped }">
        <thead>
          <tr>
            <!-- 多选列 -->
            <th v-if="selection" class="base-table__th base-table__th--sel">
              <DsCheckbox :model-value="allChecked" :indeterminate="indeterminate" size="sm" @change="onToggleAll" />
            </th>
            <!-- 展开列 -->
            <th v-if="expandable" class="base-table__th base-table__th--exp" />
            <!-- 数据列 -->
            <th
              v-for="col in displayColumns"
              :key="col.prop"
              class="base-table__th"
              :class="{ 'is-sortable': !!col.sortable }"
              :style="{ width: col.width ? toCssSize(col.width) : undefined, minWidth: col.minWidth ? toCssSize(col.minWidth) : undefined }"
              @click="col.sortable && onSort(col)"
            >
              <span class="base-table__th-inner">
                {{ col.label }}
                <span v-if="col.sortable" class="base-table__sort" :class="sortOf(col)">
                  <i class="base-table__sort-up" />
                  <i class="base-table__sort-down" />
                </span>
              </span>
            </th>
            <!-- 操作列 -->
            <th v-if="hasAction" class="base-table__th base-table__th--action" :style="{ width: toCssSize(actionWidth) }">操作</th>
          </tr>
        </thead>

        <tbody>
          <!-- 树形模式：按展开状态扁平化渲染；非树形模式走排序结果 -->
          <template v-for="(row, i) in flatRowsFinal" :key="rowKeyOf(row, i)">
            <tr
              class="base-table__row"
              :class="{
                'is-clickable': clickable,
                'is-current': highlightCurrentRow && currentRow && currentRow[rowKey] === row[rowKey],
                'is-tree': row.__depth > 0,
              }"
              @click="onRowClick(row)"
              @dblclick="emit('row-dblclick', row)"
            >
              <!-- 多选 -->
              <td v-if="selection" class="base-table__td base-table__td--sel" @click.stop>
                <DsCheckbox
                  :model-value="selected.some((s) => s[rowKey] === row[rowKey])"
                  size="sm"
                  @change="() => onRowToggle(row)"
                />
              </td>
              <!-- 展开箭头 -->
              <td v-if="expandable" class="base-table__td base-table__td--exp" @click.stop>
                <button
                  v-if="mayHaveChildren(row)"
                  type="button"
                  class="base-table__exp-btn"
                  :class="{ 'is-open': expandedKeys.has(row[rowKey]) }"
                  @click="toggleExpand(row)"
                >
                  ›
                </button>
              </td>
              <!-- 数据单元格 -->
              <td
                v-for="col in displayColumns"
                :key="col.prop"
                class="base-table__td"
                :class="[
                  { 'is-ellipsis': col.showOverflowTooltip !== false },
                  col.align ? `is-${col.align}` : '',
                ]"
                :title="col.showOverflowTooltip !== false ? String(cellText(row, col) ?? '') : undefined"
              >
                <!-- 树形缩进 -->
                <span v-if="row.__depth" class="base-table__indent" :style="{ width: row.__depth * 20 + 'px' }" />
                <slot v-if="hasSlot(col.prop)" :name="`col-${col.prop}`" :row="row" :index="i" />
                <template v-else>{{ cellText(row, col) }}</template>
              </td>
              <!-- 操作 -->
              <td v-if="hasAction" class="base-table__td base-table__td--action">
                <slot name="action" :row="row" :index="i" />
              </td>
            </tr>
            <!-- 展开行：父组件通过 #expand 注入明细 -->
            <tr v-if="expandable && expandedKeys.has(row[rowKey])" class="base-table__row-exp">
              <td :colspan="colCount">
                <div class="base-table__exp-body">
                  <slot name="expand" :row="row" :index="i" />
                </div>
              </td>
            </tr>
          </template>

          <!-- 空态 -->
          <tr v-if="!loading && !rows.length">
            <td class="base-table__empty" :colspan="colCount">
              <slot name="empty">
                <EmptyState text="暂无数据" size="sm" />
              </slot>
            </td>
          </tr>
        </tbody>

        <!-- 合计行 -->
        <tfoot v-if="showSummary && rows.length">
          <tr class="base-table__row-sum">
            <td
              v-for="(col, ci) in allColumns"
              :key="col.prop || ci"
              class="base-table__td base-table__td--sum"
            >
              {{ summaryText(col, ci) }}
            </td>
          </tr>
        </tfoot>
      </table>
    </div>

    <!-- 分页 -->
    <div class="base-table__pager">
      <DsPagination
        v-model:current-page="query.page"
        v-model:page-size="query.pageSize"
        :total="total"
        :page-sizes="pageSizes"
        :layout="layout"
        @change="reload"
      />
    </div>
  </div>
</template>

<script setup lang="ts">
// ref/reactive/computed/watch 状态与派生；getCurrentInstance 读插槽；onMounted 挂载加载
import { ref, reactive, computed, watch, getCurrentInstance, onMounted } from "vue";
// useLoading：加载态；ds 控件：按钮 / 分页 / 弹层 / 复选框 / 下拉
import { useLoading } from "./ds/useLoading";
import DsButton from "./ds/DsButton.vue";
import DsPagination from "./ds/DsPagination.vue";
import DsPopover from "./ds/DsPopover.vue";
import DsCheckbox from "./ds/DsCheckbox.vue";
import DsDropdown from "./ds/DsDropdown.vue";
import type { DropdownItem } from "./ds/types";
import IconButton from "./IconButton.vue";
import EmptyState from "./EmptyState.vue";
import type { TableColumn } from "./types";

/** 排序方向 */
type SortOrder = "asc" | "desc" | null;

const props = withDefaults(
  defineProps<{
    /** 列配置 */
    columns: TableColumn[];
    /** 取数函数：返回 { list, total } */
    fetch: (query: any) => Promise<{ list: any[]; total: number }>;
    /** 是否开启多选列 */
    selection?: boolean;
    /** 行唯一键 */
    rowKey?: string;
    /** 是否显示刷新按钮 */
    refreshable?: boolean;
    /** 是否允许列显隐设置 */
    columnSetting?: boolean;
    /** 是否允许导出当前页 */
    exportable?: boolean;
    /** 导出文件名 */
    exportName?: string;
    /** 表格高度 */
    height?: string | number;
    /** 是否内置「新增」按钮 */
    addBtn?: boolean;
    /** 新增按钮文案 */
    addText?: string;
    /** 操作列宽度 */
    actionWidth?: number | string;
    /** 挂载时是否自动加载 */
    autoLoad?: boolean;
    /** 表格密度 */
    size?: "large" | "default" | "small";
    /** 是否显示密度切换下拉 */
    sizeable?: boolean;
    /** 行是否可被勾选的判定函数 */
    selectable?: (row: any, index: number) => boolean;
    /** 行 className 回调 */
    rowClassName?: (row: any, rowIndex: number) => string;
    /** 分页每页条数选项 */
    pageSizes?: number[];
    /** 分页布局 */
    layout?: string;
    /** 是否内置关键字搜索框 */
    searchable?: boolean;
    /** 搜索框占位文案 */
    searchPlaceholder?: string;
    /** 服务端排序：sort-change 触发 reload 并把排序条件传给 fetch */
    serverSort?: boolean;
    /** 树形数据的子节点字段名 */
    treeProp?: string;
    /** 是否懒加载子节点（需配合 load） */
    lazy?: boolean;
    /** 懒加载回调 */
    load?: (row: any, resolve: (data: any[]) => void) => void;
    /** 是否默认展开全部树节点 */
    defaultExpandAll?: boolean;
    /** 是否显示合计行 */
    showSummary?: boolean;
    /** 合计行计算方法 */
    summaryMethod?: (param: { columns: TableColumn[]; data: any[] }) => string[];
    /** 是否启用展开行（#expand 插槽） */
    expandable?: boolean;
    /** 是否高亮当前行 */
    highlightCurrentRow?: boolean;
    /** 列显隐持久化 key */
    columnKey?: string;
    /** 斑马纹 */
    striped?: boolean;
    /** 行是否可点击（悬停高亮 + 触发 row-click） */
    clickable?: boolean;
  }>(),
  {
    selection: false,
    rowKey: "id",
    refreshable: true,
    columnSetting: false,
    exportable: false,
    exportName: "导出数据",
    height: "100%",
    addBtn: false,
    addText: "新增",
    actionWidth: 140,
    autoLoad: true,
    size: "default",
    sizeable: false,
    pageSizes: () => [10, 20, 50],
    layout: "total, sizes, prev, pager, next",
    searchable: false,
    serverSort: false,
    treeProp: "children",
    lazy: false,
    defaultExpandAll: false,
    showSummary: false,
    expandable: false,
    highlightCurrentRow: false,
    striped: true,
    clickable: false,
  }
);

const emit = defineEmits<{
  (e: "row-dblclick", row: any): void;
  (e: "row-click", row: any): void;
  (e: "add"): void;
  (e: "sort-change", sort: { prop: string; order: string } | null): void;
  (e: "current-change", row: any): void;
  (e: "search", keyword: string): void;
  (e: "selection-change", rows: any[]): void;
}>();

const instance = getCurrentInstance();
// hasAction：是否渲染操作列
const hasAction = computed(() => !!instance?.slots?.action);

const { loading, withLoading } = useLoading();
// rows：当前页数据
const rows = ref<any[]>([]);
// total：总条数
const total = ref(0);
// query：查询条件
const query = reactive({ page: 1, pageSize: props.pageSizes[0] ?? 10, keyword: "" });
// selected：已勾选行
const selected = ref<any[]>([]);
// tableSize：当前密度
const tableSize = ref<"large" | "default" | "small">(props.size);
// currentSort：排序条件
const currentSort = ref<{ prop: string; order: SortOrder }>({ prop: "", order: null });
// currentRow：高亮当前行
const currentRow = ref<any>(null);
// expandedKeys：展开的树节点 key 集合
const expandedKeys = ref<Set<string | number>>(new Set());

/* ============================ 列显隐（含持久化） ============================ */
// STORE_PREFIX：持久化键名前缀
const STORE_PREFIX = "bt-col-";
// visibleProps：可见列列表
const visibleProps = ref<string[]>(props.columns.map((c) => c.prop));

/**
 * 从 localStorage 恢复列显隐（仅提供 columnKey 时生效；脏列自动过滤）。
 * @returns 无
 */
function loadVisible(): void {
  if (!props.columnKey) return;
  try {
    const raw = localStorage.getItem(STORE_PREFIX + props.columnKey);
    if (raw) {
      const arr = JSON.parse(raw) as string[];
      const valid = arr.filter((p) => props.columns.some((c) => c.prop === p));
      if (valid.length) visibleProps.value = valid;
    }
  } catch {
    /* 忽略损坏数据 */
  }
}
loadVisible();

// columns 变化：重置 + 恢复持久化
watch(
  () => props.columns,
  (cols) => {
    visibleProps.value = cols.map((c) => c.prop);
    loadVisible();
  },
  { immediate: true }
);
// visibleProps 变化：写回 localStorage
watch(visibleProps, (val) => {
  if (props.columnKey) {
    try {
      localStorage.setItem(STORE_PREFIX + props.columnKey, JSON.stringify(val));
    } catch {
      /* 隐私模式忽略 */
    }
  }
});

// displayColumns：过滤出渲染列
const displayColumns = computed(() => props.columns.filter((c) => visibleProps.value.includes(c.prop)));
// allColumns：合计行需要的「全部列」（含选择/展开列占位）
const allColumns = computed<TableColumn[]>(() => {
  const head: TableColumn[] = [];
  if (props.selection) head.push({ prop: "__sel", label: "" });
  if (props.expandable) head.push({ prop: "__exp", label: "" });
  return [...head, ...displayColumns.value, ...(hasAction.value ? [{ prop: "__action", label: "操作" } as TableColumn] : [])];
});

/** 总列数（空态 colspan） */
const colCount = computed(() => allColumns.value.length);

/** 高度样式 */
const heightStyle = computed(() =>
  props.height === "100%" ? { flex: "1", minHeight: "200px" } : { height: toCssSize(props.height) }
);

/**
 * number / string -> CSS 尺寸。
 * @param v 尺寸
 * @returns CSS 字符串
 */
function toCssSize(v: number | string): string {
  return typeof v === "number" ? v + "px" : v;
}

/**
 * 是否存在 #col-{prop} 插槽。
 * @param prop 列字段名
 * @returns 是否存在
 */
function hasSlot(prop: string): boolean {
  return !!instance?.slots?.[`col-${prop}`];
}

/**
 * 单元格文本。
 * @param row 行数据
 * @param col 列配置
 * @returns 文本
 */
function cellText(row: any, col: TableColumn): string {
  if (col.formatter) return String(col.formatter(row) ?? "");
  return String(row?.[col.prop] ?? "");
}

/* ============================ 取数 ============================ */

/**
 * 重新拉取数据（serverSort 时附带排序条件）。
 * @returns Promise<void>
 */
async function reload(): Promise<void> {
  const params: any = { ...query };
  if (props.serverSort && currentSort.value.order) params.sort = { ...currentSort.value };
  const res = await withLoading(() => props.fetch(params));
  rows.value = res.list;
  total.value = res.total;
  // 树形默认展开
  if (props.defaultExpandAll) {
    const set = new Set<string | number>();
    walk(rows.value, (n) => {
      if (n[props.treeProp]?.length) set.add(n[props.rowKey]);
    });
    expandedKeys.value = set;
  }
}

/**
 * 递归遍历树。
 * @param list 节点数组
 * @param fn 访问函数
 * @returns 无
 */
function walk(list: any[] | undefined, fn: (n: any) => void): void {
  if (!Array.isArray(list)) return;
  for (const n of list) {
    fn(n);
    walk(n[props.treeProp], fn);
  }
}

/** 行 key（树形扁平化后同一行可能重复，用 depth 拼后缀） */
function rowKeyOf(row: any, i: number): string {
  return `${String(row[props.rowKey])}-${row.__depth ?? 0}-${i}`;
}

/**
 * 树形扁平化：按展开状态把树拍平成一维列表（带 __depth）。
 * @returns 扁平行
 */
const flatRows = computed<any[]>(() => {
  const out: any[] = [];
  const push = (list: any[], depth: number) => {
    for (const n of list) {
      out.push(depth === 0 ? n : { ...n, __depth: depth });
      if (expandedKeys.value.has(n[props.rowKey])) push(n[props.treeProp] || [], depth + 1);
    }
  };
  push(rows.value, 0);
  return out;
});

/**
 * 是否可能有子节点（懒加载占位：懒加载模式未展开过的都当可能有）。
 * @param row 行数据
 * @returns 是否可能有子级
 */
function mayHaveChildren(row: any): boolean {
  if (Array.isArray(row[props.treeProp]) && row[props.treeProp].length) return true;
  return props.lazy && !row.__loaded;
}

/**
 * 展开 / 收起树节点（懒加载首次展开触发 load）。
 * @param row 行数据
 * @returns 无
 */
function toggleExpand(row: any): void {
  const k = row[props.rowKey];
  const set = new Set(expandedKeys.value);
  if (set.has(k)) {
    set.delete(k);
    expandedKeys.value = set;
    return;
  }
  set.add(k);
  expandedKeys.value = set;
  // 懒加载：无子级数据且未加载过
  if (props.lazy && !row.__loaded && !row[props.treeProp]?.length) {
    props.load?.(row, (data) => {
      row[props.treeProp] = data || [];
      row.__loaded = true;
    });
  }
}

/* ============================ 排序 ============================ */

/** 客户端排序后的行（树形模式下不排序，保持层级） */
const sortedRows = computed(() => {
  if (!currentSort.value.prop || !currentSort.value.order) return rows.value;
  const col = props.columns.find((c) => c.prop === currentSort.value.prop);
  if (!col) return rows.value;
  const dir = currentSort.value.order === "asc" ? 1 : -1;
  return [...rows.value].sort((a, b) => {
    const va = cellText(a, col);
    const vb = cellText(b, col);
    const na = Number(va);
    const nb = Number(vb);
    if (!Number.isNaN(na) && !Number.isNaN(nb)) return (na - nb) * dir;
    return va.localeCompare(vb) * dir;
  });
});

// 排序结果覆盖 flatRows 的顶层（树形模式下跳过）
const flatRowsFinal = computed(() => {
  const hasTree = rows.value.some((r) => Array.isArray(r[props.treeProp]) && r[props.treeProp].length);
  if (hasTree || props.lazy) return flatRows.value;
  return sortedRows.value.map((r) => r);
});

/** 某列排序状态（箭头高亮） */
function sortOf(col: TableColumn): string {
  if (currentSort.value.prop !== col.prop || !currentSort.value.order) return "";
  return currentSort.value.order;
}

/**
 * 点击表头排序：asc -> desc -> 取消；服务端排序立即 reload。
 * @param col 列配置
 * @returns 无
 */
function onSort(col: TableColumn): void {
  const cur = sortOf(col);
  const order: SortOrder = cur === "asc" ? "desc" : cur === "desc" ? null : "asc";
  currentSort.value = { prop: col.prop, order };
  emit("sort-change", order ? { prop: col.prop, order } : null);
  if (props.serverSort) void reload();
}

/* ============================ 多选 ============================ */

/** 全选态 */
const allChecked = computed(
  () =>
    props.selection &&
    rows.value.length > 0 &&
    rows.value.every((r) => selected.value.some((s) => s[props.rowKey] === r[props.rowKey]))
);
/** 半选态 */
const indeterminate = computed(
  () =>
    props.selection &&
    rows.value.some((r) => selected.value.some((s) => s[props.rowKey] === r[props.rowKey])) &&
    !allChecked.value
);

/**
 * 切换某行勾选。
 * @param row 行数据
 * @returns 无
 */
function onRowToggle(row: any): void {
  const i = selected.value.findIndex((s) => s[props.rowKey] === row[props.rowKey]);
  if (i >= 0) selected.value.splice(i, 1);
  else selected.value.push(row);
  emit("selection-change", selected.value);
}

/**
 * 全选 / 取消全选（当前页）。
 * @param v 目标态
 * @returns 无
 */
function onToggleAll(v: boolean | any[]): void {
  const want = v === true;
  if (want) {
    for (const r of rows.value) {
      if (!selected.value.some((s) => s[props.rowKey] === r[props.rowKey])) selected.value.push(r);
    }
  } else {
    const pageKeys = new Set(rows.value.map((r) => r[props.rowKey]));
    selected.value = selected.value.filter((s) => !pageKeys.has(s[props.rowKey]));
  }
  emit("selection-change", selected.value);
}

/* ============================ 搜索 / 密度 / 行交互 ============================ */

// 搜索防抖
let searchTimer: ReturnType<typeof setTimeout> | null = null;
/**
 * 内置搜索输入：emit search + 防抖 300ms 回到首页重载。
 * @returns 无
 */
function onSearchInput(): void {
  emit("search", query.keyword);
  if (searchTimer) clearTimeout(searchTimer);
  searchTimer = setTimeout(() => {
    query.page = 1;
    void reload();
  }, 300);
}

/** 密度菜单项 */
const sizeItems: DropdownItem[] = [
  { command: "large", label: "宽松" },
  { command: "default", label: "默认" },
  { command: "small", label: "紧凑" },
];

/**
 * 密度切换命令。
 * @param c 密度
 * @returns 无
 */
function onSizeCommand(c: string | number): void {
  tableSize.value = c as "large" | "default" | "small";
}

/**
 * 行点击：高亮当前行 + emit 事件。
 * @param row 行数据
 * @returns 无
 */
function onRowClick(row: any): void {
  currentRow.value = row;
  emit("current-change", row);
  emit("row-click", row);
}

/**
 * 列显隐整组变化。
 * @param next 新可见列
 * @returns 无
 */
function onColGroupChange(next: any): void {
  if (Array.isArray(next)) visibleProps.value = next;
}

/**
 * 合计行单元格文本。
 * @param col 列配置
 * @param ci 列下标
 * @returns 文本
 */
function summaryText(col: TableColumn, ci: number): string {
  if (props.summaryMethod) {
    const arr = props.summaryMethod({ columns: allColumns.value, data: rows.value });
    return String(arr[ci] ?? "");
  }
  // 默认：选择/展开列留空，其余统计数值和
  if (!col.prop || col.prop.startsWith("__")) return "";
  const sum = rows.value.reduce((acc, r) => acc + (Number(r[col.prop]) || 0), 0);
  return rows.value.some((r) => typeof r[col.prop] === "number") ? String(sum) : "";
}

/**
 * 导出当前页为 CSV（带 BOM，Excel 直接打开不乱码）。
 * @returns Promise<void>
 */
async function exportExcel(): Promise<void> {
  const cols = displayColumns.value;
  const header = cols.map((c) => c.label);
  const body = sortedRows.value.map((r) => cols.map((c) => (c.formatter ? c.formatter(r) : r[c.prop])));
  const csv = [header, ...body]
    .map((line) => line.map((cell) => `"${String(cell ?? "").replace(/"/g, '""')}"`).join(","))
    .join("\r\n");
  const blob = new Blob([`\uFEFF${csv}`], { type: "text/csv;charset=utf-8" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = `${props.exportName}.csv`;
  a.click();
  URL.revokeObjectURL(a.href);
}

// 外部 size 变化时同步密度
watch(
  () => props.size,
  (v) => (tableSize.value = v)
);

// 暴露给父组件
defineExpose({
  reload,
  rows,
  selected,
  query,
  getSelection: () => selected.value,
  clearSelection: () => {
    selected.value = [];
    emit("selection-change", selected.value);
  },
  /** 获取当前排序条件 */
  getSort: () => (currentSort.value.order ? { ...currentSort.value } : null),
  /** 获取当前表格密度 */
  getSize: () => tableSize.value,
  /** 手动展开 / 收起某个树节点 */
  toggleExpand,
});

// 默认挂载即加载
onMounted(() => {
  if (props.autoLoad) void reload();
});
</script>

<style scoped>
.base-table { display: flex; flex-direction: column; height: 100%; min-width: 0; }

/* 搜索区 */
.base-table__search { display: flex; align-items: center; gap: var(--ds-space-3); margin-bottom: var(--ds-space-3); }
.base-table__search-box {
  display: flex;
  align-items: center;
  gap: 8px;
  width: 300px;
  height: var(--ds-ctl-h-md);
  padding: 0 12px;
  background: var(--ds-bg-elevated);
  border: 1px solid var(--ds-border);
  border-radius: var(--ds-radius-sm);
  transition: border-color var(--ds-dur-fast) var(--ds-ease), box-shadow var(--ds-dur-fast) var(--ds-ease);
}
.base-table__search-box:focus-within { border-color: var(--ds-brand); box-shadow: 0 0 0 3px var(--ds-brand-soft); }
.base-table__search-box svg {
  width: 15px; height: 15px; flex: none;
  fill: none; stroke: var(--ds-text-3); stroke-width: 2; stroke-linecap: round;
}
.base-table__search-box input {
  flex: 1; min-width: 0; border: 0; outline: none; background: transparent;
  color: var(--ds-text); font-size: var(--ds-font-md); font-family: inherit;
}
.base-table__search-box button {
  border: 0; background: transparent; color: var(--ds-text-3);
  cursor: pointer; font-size: var(--ds-font-xs); padding: 2px; border-radius: var(--ds-radius-xs);
}
.base-table__search-box button:hover { background: var(--ds-bg-hover); color: var(--ds-text); }

/* 工具栏 */
.base-table__toolbar {
  display: flex; align-items: center; justify-content: space-between;
  gap: var(--ds-space-2); margin-bottom: var(--ds-space-3); flex: none;
}
.base-table__left,
.base-table__right { display: flex; align-items: center; gap: var(--ds-space-2); }
.base-table__actions { display: flex; align-items: center; gap: 2px; }

/* 表格容器 */
.base-table__wrap {
  position: relative;
  overflow: auto;
  border: 1px solid var(--ds-border);
  border-radius: var(--ds-radius-md);
  background: var(--ds-bg-elevated);
}
.base-table__loading {
  position: absolute; inset: 0; z-index: 5;
  display: flex; align-items: center; justify-content: center;
  background: var(--ds-frosted);
}
.base-table__spin {
  width: 20px; height: 20px;
  border: 2px solid var(--ds-border);
  border-top-color: var(--ds-brand);
  border-radius: 50%;
  animation: ds-spin 0.7s linear infinite;
}

/* 表格本体 */
.base-table__el { width: 100%; border-collapse: collapse; font-size: var(--ds-font-sm); }
/* 密度：紧凑模式收紧行高 */
.base-table__wrap.is-small .base-table__td { padding: 7px 14px; }
.base-table__wrap.is-large .base-table__td { padding: 15px 14px; }

.base-table__th {
  padding: 10px 14px;
  font-weight: 500;
  color: var(--ds-text-3);
  background: var(--ds-bg-soft);
  border-bottom: 1px solid var(--ds-border);
  text-align: left;
  white-space: nowrap;
  user-select: none;
}
.base-table__th.is-sortable { cursor: pointer; }
.base-table__th.is-sortable:hover { color: var(--ds-text-2); }
.base-table__th--sel { width: 40px; text-align: center; }
.base-table__th--exp { width: 36px; }
.base-table__th--action { text-align: center; }
.base-table__th-inner { display: inline-flex; align-items: center; gap: 4px; }

/* 排序指示 */
.base-table__sort { display: inline-flex; flex-direction: column; gap: 2px; line-height: 0; }
.base-table__sort i {
  width: 0; height: 0;
  border-left: 3.5px solid transparent;
  border-right: 3.5px solid transparent;
  opacity: 0.35;
}
.base-table__sort-up { border-bottom: 4px solid var(--ds-text-3); }
.base-table__sort-down { border-top: 4px solid var(--ds-text-3); }
.base-table__th .base-table__sort.is-asc .base-table__sort-up { opacity: 1; border-bottom-color: var(--ds-brand); }
.base-table__th .base-table__sort.is-desc .base-table__sort-down { opacity: 1; border-top-color: var(--ds-brand); }

/* 行 */
.base-table__row { transition: background var(--ds-dur-fast) var(--ds-ease); }
.base-table__row:hover { background: var(--ds-bg-hover); }
.base-table__row.is-clickable { cursor: pointer; }
.base-table__row.is-current { background: var(--ds-brand-soft); }
.base-table__el.is-striped tbody tr:nth-child(even) { background: var(--ds-bg-soft); }
.base-table__el.is-striped tbody tr:nth-child(even):hover { background: var(--ds-bg-hover); }

.base-table__td {
  padding: 11px 14px;
  color: var(--ds-text-2);
  border-bottom: 1px solid var(--ds-divider);
  vertical-align: middle;
  line-height: 1.5;
}
.base-table__td.is-ellipsis { max-width: 240px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.base-table__td.is-center { text-align: center; }
.base-table__td.is-right { text-align: right; }
.base-table__td--sel { text-align: center; }
.base-table__td--exp { text-align: center; }
.base-table__td--action { text-align: center; white-space: nowrap; }

/* 展开箭头 */
.base-table__exp-btn {
  width: 20px; height: 20px;
  display: inline-grid; place-items: center;
  border: 0; border-radius: var(--ds-radius-xs);
  background: transparent; color: var(--ds-text-3);
  cursor: pointer; font-size: 14px; line-height: 1;
  transition: transform var(--ds-dur-fast) var(--ds-ease), background var(--ds-dur-fast) var(--ds-ease);
}
.base-table__exp-btn:hover { background: var(--ds-bg-active); }
.base-table__exp-btn.is-open { transform: rotate(90deg); }

/* 树形缩进 */
.base-table__indent { display: inline-block; flex: none; }

/* 展开行内容 */
.base-table__row-exp .base-table__td { background: var(--ds-bg-soft); }
.base-table__exp-body { padding: 10px 12px; }

/* 合计行 */
.base-table__row-sum .base-table__td--sum {
  background: var(--ds-bg-soft);
  font-weight: 600;
  color: var(--ds-text);
}

/* 空态 */
.base-table__empty { padding: var(--ds-space-6) 0; text-align: center; }

/* 分页 */
.base-table__pager { margin-top: var(--ds-space-3); display: flex; justify-content: flex-end; flex: none; }

/* 列设置浮层 */
.base-table__colset { display: flex; flex-direction: column; gap: 6px; }
</style>
