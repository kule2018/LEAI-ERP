<!--
 * BaseTree 通用树形组件（DeepSeek UI 版）
 * 职责：关键字过滤、单选（highlight-current）/ 多选（checkbox）、默认展开、懒加载子节点，
 *       并通过 select / check 事件把选中结果回传父组件。
 * 与旧版区别：底层由自绘 DsTree 承担（递归渲染 + 级联勾选 + 过滤），不再依赖 Element Plus；
 *             本组件保留原 API，作为业务侧的统一入口。
 * 页面位置 / 用途：用于部门 / 分类 / 菜单等层级数据的展示与选择。
 * 核心 props：data 树数据、nodeKey 节点唯一字段、labelKey 显示字段、childrenKey 子节点字段、
 *            filterable 可过滤、checkable 可勾选、checkStrictly 父子是否级联、lazy / lazyLoad 懒加载。
 * 核心 emits：select 单选节点变化、check 勾选变化（返回选中 key 与节点）。
 * 对外暴露（defineExpose）：getCheckedKeys / getCheckedNodes / setCheckedKeys / updateKeyChildren / filter / expandAll / collapseAll。
 -->
<template>
  <!-- 通用树：DsTree + 过滤框，支持关键字过滤与选中回调 -->
  <div class="base-tree">
    <DsTree
      ref="treeRef"
      :data="data"
      :node-key="nodeKey"
      :label-key="labelKey"
      :children-key="childrenKey"
      :filterable="filterable"
      :checkable="checkable"
      :check-strictly="checkStrictly"
      :default-expand-all="defaultExpandAll"
      :default-expanded-keys="defaultExpandedKeys"
      :lazy="lazy"
      :lazy-load="lazyLoad"
      @select="(n: any) => emit('select', n)"
      @check="(keys: any, nodes: any) => emit('check', keys, nodes)"
    />
  </div>
</template>

<script setup lang="ts">
// ref 实例引用；DsTree：ds 设计系统树形控件；TreeNode/LazyLoad 为共享类型
import { ref } from "vue";
import DsTree from "./ds/DsTree.vue";
import type { TreeNode, LazyLoad } from "./ds/types";

type TreeData = TreeNode;

withDefaults(
  defineProps<{
    /** 树数据 */
    data: TreeData[];
    /** 节点唯一字段 */
    nodeKey?: string;
    /** 显示字段 */
    labelKey?: string;
    /** 子节点字段 */
    childrenKey?: string;
    /** 是否可过滤 */
    filterable?: boolean;
    /** 是否可勾选 */
    checkable?: boolean;
    /** 父子节点勾选是否独立（默认 false，即级联） */
    checkStrictly?: boolean;
    /** 是否默认展开全部 */
    defaultExpandAll?: boolean;
    /** 默认展开的节点 key 列表 */
    defaultExpandedKeys?: (string | number)[];
    /** 是否懒加载子节点 */
    lazy?: boolean;
    /** 懒加载回调（lazy 为真时必填） */
    lazyLoad?: LazyLoad;
  }>(),
  {
    nodeKey: "id",
    labelKey: "label",
    childrenKey: "children",
    filterable: true,
    checkable: false,
    checkStrictly: false,
    defaultExpandAll: false,
    defaultExpandedKeys: () => [],
    lazy: false,
  }
);

const emit = defineEmits<{
  (e: "select", node: TreeData): void;
  (e: "check", keys: (string | number)[], nodes: TreeData[]): void;
}>();

/** DsTree 实例引用（转发全部方法） */
const treeRef = ref<InstanceType<typeof DsTree>>();

// 对外暴露：与旧版 API 一致（透传到 DsTree）
defineExpose({
  /** 获取已勾选节点的 key 列表 */
  getCheckedKeys: () => treeRef.value?.getCheckedKeys() ?? [],
  /** 获取已勾选节点（顶层语义） */
  getCheckedNodes: () => treeRef.value?.getCheckedNodes() ?? [],
  /** 设置勾选节点（用于回显） */
  setCheckedKeys: (keys: (string | number)[]) => treeRef.value?.setCheckedKeys(keys),
  /** 手动触发某节点懒加载刷新 */
  updateKeyChildren: (key: string | number, children: TreeData[]) =>
    treeRef.value?.updateKeyChildren(key, children),
  /** 手动过滤 */
  filter: (kw: string) => treeRef.value?.filter(kw),
  /** 全部展开 */
  expandAll: () => treeRef.value?.expandAll(),
  /** 全部收起 */
  collapseAll: () => treeRef.value?.collapseAll(),
});
</script>

<style scoped>
.base-tree {
  display: flex;
  flex-direction: column;
  height: 100%;
}
</style>
