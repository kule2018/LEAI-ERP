<!--
 * BaseUpload 通用文件上传组件（DeepSeek UI 版）
 * 职责：对外以 v-model 维护「已上传文件 URL 数组」，支持多图 / 拖拽 / 文本列表多种展示样式、
 *       上传前大小校验、超出数量限制提示、上传进度展示，并兼容 {url} 与 {data:{url}} 两种后端返回结构。
 * 与旧版区别：基于 ds 设计令牌自绘；上传走原生 fetch + FormData（不依赖 el-upload 的 XHR 封装）。
 * 页面位置 / 用途：用于头像、证件、图片集等文件上传场景。
 * 核心 props：action 上传接口、name 字段名、multiple 多选、limit 数量上限、maxSize 单文件 MB 上限、
 *            accept 接受类型、listType 列表样式、drag 拖拽模式、tip 提示文案。
 * 双向绑定：model 为已上传文件 URL 字符串数组（父组件 v-model）。
 * 对外暴露（defineExpose）：clear 清空全部、submit 手动提交待上传文件。
 -->
<template>
  <!-- 通用上传：v-model 绑定已上传文件 URL 数组 -->
  <div class="base-upload" :class="{ 'is-disabled': disabled }">
    <!-- 投放区 -->
    <div
      class="base-upload__area"
      :class="{
        'is-drag': drag,
        'is-picture': listType !== 'text',
        'is-dragging': dragging,
      }"
      @click="!disabled && openPicker()"
      @dragover.prevent="dragging = true"
      @dragleave="dragging = false"
      @drop.prevent="onDrop"
    >
      <!-- 图片卡片模式：已选图片平铺 + 末尾加号 -->
      <template v-if="listType === 'picture-card'">
        <div v-for="(f, i) in list" :key="f.uid" class="base-upload__card">
          <img v-if="f.url" :src="f.url" alt="已上传" />
          <div v-else-if="f.preview" class="base-upload__card-loading">
            <span class="base-upload__ring" :style="{ '--p': f.percent + '%' }" />
            <span class="base-upload__card-pct">{{ f.percent }}%</span>
          </div>
          <!-- 单张遮罩：预览 + 移除 -->
          <div class="base-upload__card-mask">
            <button type="button" title="移除" @click.stop="removeAt(i)">✕</button>
          </div>
        </div>
        <!-- 加号占位：未达上限才显示 -->
        <div v-if="canAdd" class="base-upload__plus">
          <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 5v14M5 12h14" /></svg>
        </div>
      </template>

      <!-- 拖拽模式：拖拽提示 -->
      <template v-else-if="drag">
        <svg class="base-upload__drag-icon" viewBox="0 0 24 24" aria-hidden="true">
          <path d="M12 15V3m0 12-4-4m4 4 4-4M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2" />
        </svg>
        <p class="base-upload__main">将文件拖到此处，或<em>点击上传</em></p>
      </template>

      <!-- 文本模式：按钮 -->
      <button v-else type="button" class="base-upload__btn" @click.stop="openPicker">{{ uploadText }}</button>
    </div>

    <!-- 文本 / 图片列表：文件名 + 大小 + 进度 + 移除 -->
    <ul v-if="listType === 'text' && list.length" class="base-upload__list">
      <li v-for="(f, i) in list" :key="f.uid">
        <span class="base-upload__name">{{ f.name }}</span>
        <span v-if="f.status === 'uploading'" class="base-upload__pct">{{ f.percent }}%</span>
        <span v-else-if="f.status === 'error'" class="base-upload__err">失败</span>
        <span v-else class="base-upload__size">{{ f.sizeText }}</span>
        <button type="button" class="base-upload__del" @click="removeAt(i)">移除</button>
      </li>
    </ul>

    <!-- 隐藏的原始 input -->
    <input
      ref="inputRef"
      class="base-upload__input"
      type="file"
      :accept="accept"
      :multiple="multiple"
      :disabled="disabled"
      @change="onChange"
    />

    <!-- 提示文案 -->
    <p v-if="tip" class="base-upload__tip">{{ tip }}</p>
  </div>
</template>

<script setup lang="ts">
// ref/computed 响应式状态；watch 外部值同步；useToast 失败提示；formatBytes 体积格式化
import { ref, computed, watch } from "vue";
import { useToast } from "./ds/toast";
import { formatBytes } from "./ds/format";

// model: 已上传文件的 URL 数组（父组件 v-model）
const model = defineModel<string[]>({ required: true });

/** 内部文件项：含上传状态与本地预览 */
interface UploadItem {
  /** 唯一 id */
  uid: string;
  /** 文件名 */
  name: string;
  /** 原始文件（上传中才有） */
  raw?: File;
  /** 已上传 URL */
  url: string;
  /** 本地预览 URL（未上传完的图片） */
  preview: string;
  /** 状态 */
  status: "ready" | "uploading" | "success" | "error";
  /** 进度百分比 */
  percent: number;
  /** 体积文案 */
  sizeText: string;
}

const props = withDefaults(
  defineProps<{
    /** 上传接口地址 */
    action?: string;
    /** 上传字段名 */
    name?: string;
    /** 是否多选 */
    multiple?: boolean;
    /** 数量上限 */
    limit?: number;
    /** 单文件大小上限（MB） */
    maxSize?: number;
    /** 接受类型 */
    accept?: string;
    /** 是否禁用 */
    disabled?: boolean;
    /** 提示文案 */
    tip?: string;
    /** 列表展示样式：text / picture / picture-card */
    listType?: "text" | "picture" | "picture-card";
    /** 是否启用拖拽上传 */
    drag?: boolean;
    /** 文本 / 拖拽模式下的按钮文案 */
    uploadText?: string;
  }>(),
  {
    action: "/api/upload",
    name: "file",
    multiple: false,
    limit: 1,
    maxSize: 2,
    accept: "image/*",
    disabled: false,
    listType: "picture-card",
    drag: false,
    uploadText: "点击上传",
  }
);

const toast = useToast();

/** 隐藏 input 引用 */
const inputRef = ref<HTMLInputElement | null>(null);
/** 内部文件列表 */
const list = ref<UploadItem[]>([]);
/** 拖拽悬停态 */
const dragging = ref(false);

/** 是否还能继续添加（未达数量上限） */
const canAdd = computed(() => list.value.length < props.limit);

// 外部 model 变化时同步到内部列表（已有 URL 标记为成功态）
watch(
  model,
  (val) => {
    const urls = val || [];
    // 保留上传中的项，其余按外部 URL 重建
    list.value = [
      ...list.value.filter((f) => f.status === "uploading"),
      ...urls.map((url) => ({
        uid: url,
        name: url.split("/").pop() || "文件",
        url,
        preview: url,
        status: "success" as const,
        percent: 100,
        sizeText: "",
      })),
    ];
  },
  { immediate: true }
);

/**
 * 把列表里所有成功项的 URL 同步回 model。
 * @returns 无
 */
function syncFromList(): void {
  model.value = list.value
    .filter((f) => f.status === "success")
    .map((f) => f.url)
    .filter((u): u is string => !!u);
}

/**
 * 打开系统文件选择框。
 * @returns 无
 */
function openPicker(): void {
  if (props.disabled) return;
  inputRef.value?.click();
}

/** input change 回调 */
function onChange(e: Event): void {
  const el = e.target as HTMLInputElement;
  handleFiles(Array.from(el.files || []));
  el.value = ""; // 清空，允许重复选同一文件
}

/** 拖拽放下 */
function onDrop(e: DragEvent): void {
  dragging.value = false;
  if (props.disabled) return;
  handleFiles(Array.from(e.dataTransfer?.files || []));
}

/**
 * 文件入口：数量校验 + 体积校验 + 逐个入队并开始上传。
 * @param files 待处理文件
 * @returns 无
 */
function handleFiles(files: File[]): void {
  if (!files.length) return;
  // 多选关闭时只取第一个
  const picked = props.multiple ? files : files.slice(0, 1);
  for (const f of picked) {
    // 数量上限
    if (list.value.length >= props.limit) {
      toast.warning(`最多上传 ${props.limit} 个文件`);
      break;
    }
    // 体积上限
    if (f.size / 1024 / 1024 > props.maxSize) {
      toast.error(`「${f.name}」超过 ${props.maxSize}MB 限制`);
      continue;
    }
    const item: UploadItem = {
      uid: `${Date.now()}-${f.name}-${Math.random().toString(36).slice(2, 6)}`,
      name: f.name,
      raw: f,
      url: "",
      preview: f.type.startsWith("image/") ? URL.createObjectURL(f) : "",
      status: "uploading",
      percent: 0,
      sizeText: formatBytes(f.size),
    };
    list.value.push(item);
    void uploadItem(item);
  }
}

/**
 * 上传单个文件：FormData + fetch，简易进度（fetch 无上传进度，
 * 用 30% / 90% 两个假进度点表示「请求中 / 响应中」，完成后置 100%）。
 * @param item 文件项
 * @returns Promise<void>
 */
async function uploadItem(item: UploadItem): Promise<void> {
  if (!item.raw) return;
  const fd = new FormData();
  fd.append(props.name, item.raw);
  try {
    item.percent = 30;
    const res = await fetch(props.action, { method: "POST", body: fd });
    item.percent = 90;
    if (!res.ok) throw new Error(String(res.status));
    const data = await res.json().catch(() => ({}));
    const url = data?.url ?? data?.data?.url ?? "";
    if (!url) throw new Error("返回格式异常");
    item.url = url;
    item.status = "success";
    item.percent = 100;
    // 上传成功：本地预览切换为远端 URL，并释放 objectURL
    if (item.preview.startsWith("blob:")) URL.revokeObjectURL(item.preview);
    item.preview = url;
    syncFromList();
  } catch {
    item.status = "error";
    toast.error(`「${item.name}」上传失败`);
  }
}

/**
 * 移除某个文件（从内部列表移除并同步 model）。
 * @param i 下标
 * @returns 无
 */
function removeAt(i: number): void {
  const f = list.value[i];
  if (f?.preview.startsWith("blob:")) URL.revokeObjectURL(f.preview);
  list.value.splice(i, 1);
  syncFromList();
}

/** 暴露给父组件：清空全部 */
defineExpose({
  /** 清空已选文件（含 model） */
  clear: () => {
    list.value.forEach((f) => {
      if (f.preview.startsWith("blob:")) URL.revokeObjectURL(f.preview);
    });
    list.value = [];
    model.value = [];
  },
});
</script>

<style scoped>
.base-upload { width: 100%; }
.base-upload.is-disabled { opacity: 0.6; pointer-events: none; }

/* ---- 投放区 ---- */
.base-upload__area {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  align-items: center;
  border-radius: var(--ds-radius-lg);
  cursor: pointer;
  transition: border-color var(--ds-dur) var(--ds-ease), background var(--ds-dur) var(--ds-ease);
}
.base-upload__area.is-drag {
  border: 1.5px dashed var(--ds-border-strong);
  background: var(--ds-bg-soft);
  padding: 22px 16px;
  justify-content: center;
  text-align: center;
  flex-direction: column;
}
.base-upload__area.is-drag:hover,
.base-upload__area.is-drag.is-dragging { border-color: var(--ds-brand); background: var(--ds-brand-soft); }

/* 文本模式：无边框 */
.base-upload__area:not(.is-drag):not(.is-picture) { border: none; }

/* 图片卡片模式：无边框，靠卡片自身描边 */
.base-upload__area.is-picture { border: none; background: transparent; }

/* 文本模式按钮 */
.base-upload__btn {
  height: var(--ds-ctl-h-md);
  padding: 0 16px;
  border: 0;
  border-radius: var(--ds-radius-sm);
  background: var(--ds-brand);
  color: #fff;
  font-size: var(--ds-font-md);
  font-family: inherit;
  font-weight: 500;
  cursor: pointer;
}
.base-upload__btn:hover { background: var(--ds-brand-hover); }

/* 拖拽图标与文案 */
.base-upload__drag-icon {
  width: 34px; height: 34px;
  fill: none; stroke: var(--ds-text-3); stroke-width: 1.6; stroke-linecap: round; stroke-linejoin: round;
}
.base-upload__main { margin: 6px 0 0; font-size: var(--ds-font-sm); color: var(--ds-text-2); }
.base-upload__main em { color: var(--ds-brand); font-style: normal; }

/* ---- 图片卡片 ---- */
.base-upload__card {
  position: relative;
  width: 88px;
  height: 88px;
  border-radius: var(--ds-radius-md);
  border: 1px solid var(--ds-border);
  overflow: hidden;
  background: var(--ds-bg-soft);
}
.base-upload__card img { width: 100%; height: 100%; object-fit: cover; display: block; }

/* 上传中：环形进度 */
.base-upload__card-loading {
  position: absolute; inset: 0;
  display: grid; place-items: center;
  background: var(--ds-frosted);
}
.base-upload__ring {
  width: 26px; height: 26px;
  border-radius: 50%;
  background: conic-gradient(var(--ds-brand) var(--p), var(--ds-border) var(--p));
  mask: radial-gradient(farthest-side, transparent calc(100% - 3px), #000 calc(100% - 2px));
  -webkit-mask: radial-gradient(farthest-side, transparent calc(100% - 3px), #000 calc(100% - 2px));
}
.base-upload__card-pct {
  position: absolute;
  font-size: 10px;
  color: var(--ds-text-2);
  font-variant-numeric: tabular-nums;
}

/* 卡片悬停遮罩：移除按钮 */
.base-upload__card-mask {
  position: absolute; inset: 0;
  display: flex; align-items: center; justify-content: center;
  background: rgba(0, 0, 0, 0.45);
  opacity: 0;
  transition: opacity var(--ds-dur-fast) var(--ds-ease);
}
.base-upload__card:hover .base-upload__card-mask { opacity: 1; }
.base-upload__card-mask button {
  width: 24px; height: 24px;
  border: 0; border-radius: 50%;
  background: rgba(0, 0, 0, 0.5); color: #fff;
  cursor: pointer; font-size: 11px; line-height: 1;
}

/* 加号占位 */
.base-upload__plus {
  width: 88px; height: 88px;
  display: grid; place-items: center;
  border: 1.5px dashed var(--ds-border-strong);
  border-radius: var(--ds-radius-md);
  color: var(--ds-text-3);
  transition: border-color var(--ds-dur) var(--ds-ease), color var(--ds-dur) var(--ds-ease);
}
.base-upload__area:hover .base-upload__plus { border-color: var(--ds-brand); color: var(--ds-brand); }
.base-upload__plus svg {
  width: 22px; height: 22px;
  fill: none; stroke: currentColor; stroke-width: 1.8; stroke-linecap: round;
}

/* ---- 文本列表 ---- */
.base-upload__list { margin: 10px 0 0; padding: 0; list-style: none; display: flex; flex-direction: column; gap: 6px; }
.base-upload__list li {
  display: flex; align-items: center; gap: 10px;
  padding: 7px 12px;
  background: var(--ds-bg-hover);
  border-radius: var(--ds-radius-sm);
  font-size: var(--ds-font-sm);
}
.base-upload__name { flex: 1; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; color: var(--ds-text); }
.base-upload__size { color: var(--ds-text-3); flex: none; font-variant-numeric: tabular-nums; }
.base-upload__pct { color: var(--ds-brand); flex: none; font-variant-numeric: tabular-nums; }
.base-upload__err { color: var(--ds-danger); flex: none; }
.base-upload__del { color: var(--ds-danger); font-size: var(--ds-font-xs); flex: none; background: none; border: 0; cursor: pointer; }
.base-upload__del:hover { text-decoration: underline; }

/* 隐藏 input */
.base-upload__input { display: none; }
.base-upload__tip { margin: 8px 0 0; font-size: var(--ds-font-xs); color: var(--ds-text-3); }
</style>
