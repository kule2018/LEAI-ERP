<template>
  <transition name="batch-bar">
    <div v-if="count > 0" class="batch-bar">
      <span class="batch-bar__info">已选 <b>{{ count }}</b> 项</span>
      <div class="batch-bar__actions">
        <slot />
        <DsButton variant="text" size="sm" :disabled="loading" @click="$emit('clear')">取消选择</DsButton>
      </div>
    </div>
  </transition>
</template>

<script setup lang="ts">
defineProps<{ count: number; loading?: boolean }>();
defineEmits<{ (e: 'clear'): void }>();
</script>

<style scoped>
.batch-bar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  padding: 8px 14px;
  margin-bottom: 12px;
  border: 1px solid var(--ds-brand, #4d6bfe);
  border-radius: var(--ds-radius, 8px);
  background: color-mix(in srgb, var(--ds-brand, #4d6bfe) 8%, var(--ds-bg));
}
.batch-bar__info {
  font-size: var(--ds-font-sm);
  color: var(--ds-text-2);
}
.batch-bar__info b {
  color: var(--ds-brand, #4d6bfe);
}
.batch-bar__actions {
  display: flex;
  align-items: center;
  gap: 8px;
}
.batch-bar-enter-active,
.batch-bar-leave-active {
  transition: opacity 0.18s ease, transform 0.18s ease;
}
.batch-bar-enter-from,
.batch-bar-leave-to {
  opacity: 0;
  transform: translateY(-6px);
}
</style>
