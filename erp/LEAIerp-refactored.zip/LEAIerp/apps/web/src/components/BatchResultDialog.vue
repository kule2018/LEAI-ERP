<!--
 * 批量操作结果报告（文档第 24 章：批量结果报告）。
 * ---------------------------------------------------------------------------
 * 批量审核/删除/改价/打印后逐条展示成功与失败原因，
 * 失败明细可下载 CSV，方便用户修正后重试。
 -->
<template>
  <DsModal v-model="visible" title="批量操作结果" :width="560">
    <div class="batch-summary">
      <div class="batch-stat success"><b>{{ results.success?.length || 0 }}</b><span>成功</span></div>
      <div class="batch-stat danger"><b>{{ results.failed?.length || 0 }}</b><span>失败</span></div>
      <div class="batch-stat"><b>{{ total }}</b><span>合计</span></div>
    </div>
    <div v-if="results.failed?.length" class="batch-list">
      <b>失败明细</b>
      <div v-for="(item, i) in results.failed" :key="i" class="batch-row">
        <span>{{ item.label || item.id || `第 ${i + 1} 条` }}</span>
        <em>{{ item.reason || '未知原因' }}</em>
      </div>
      <DsButton size="sm" @click="download">下载失败明细</DsButton>
    </div>
    <p v-else class="batch-all">全部处理成功，没有失败项。</p>
    <template #footer><div class="batch-foot"><DsButton variant="primary" @click="visible = false">知道了</DsButton></div></template>
  </DsModal>
</template>

<script setup lang="ts">
/** 批量结果展示与失败明细导出 */
import { computed, ref, watch } from 'vue';

interface BatchResult { success?: any[]; failed?: Array<{ label?: string; id?: string | number; reason?: string }> }

const props = defineProps<{ modelValue: boolean; results: BatchResult }>();
const emit = defineEmits<{ (e: 'update:modelValue', value: boolean): void }>();
const visible = ref(props.modelValue);
watch(() => props.modelValue, (v) => { visible.value = v; });
watch(visible, (v) => emit('update:modelValue', v));

const total = computed(() => (props.results.success?.length || 0) + (props.results.failed?.length || 0));

/** 把失败明细导出为 CSV（带 BOM，Excel 可直接打开） */
function download(): void {
  const lines = ['序号,对象,失败原因', ...(props.results.failed || []).map((f, i) => `${i + 1},${f.label || f.id || ''},${f.reason || ''}`)];
  const blob = new Blob(['\ufeff' + lines.join('\n')], { type: 'text/csv;charset=utf-8' });
  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.download = `批量操作失败明细_${new Date().toISOString().slice(0, 10)}.csv`;
  link.click();
  URL.revokeObjectURL(link.href);
}
</script>

<style scoped>
.batch-summary { display: flex; gap: 12px; margin-bottom: 16px; }
.batch-stat { flex: 1; text-align: center; border: 1px solid var(--ds-border); border-radius: var(--ds-radius); padding: 12px; display: flex; flex-direction: column; }
.batch-stat b { font-size: 22px; }
.batch-stat span { font-size: 12px; color: var(--ds-text-3); }
.batch-stat.success b { color: var(--ds-success); }
.batch-stat.danger b { color: var(--ds-danger); }
.batch-list b { font-size: 13px; }
.batch-row { display: flex; gap: 12px; padding: 8px 0; border-bottom: 1px solid var(--ds-divider); font-size: 13px; }
.batch-row span { min-width: 100px; }
.batch-row em { color: var(--ds-danger); font-style: normal; flex: 1; }
.batch-list .ds-btn { margin-top: 12px; }
.batch-all { text-align: center; color: var(--ds-text-3); padding: 24px; }
.batch-foot { display: flex; justify-content: flex-end; }
</style>
