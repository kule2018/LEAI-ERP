<template>
  <div class="chunked-upload">
    <input ref="fileInput" type="file" hidden @change="onPick" />
    <DsButton variant="primary" :loading="running" @click="fileInput?.click()">上传文档</DsButton>

    <!-- 上传进度 -->
    <div v-if="state.fileName" class="upload-progress" role="status" aria-live="polite">
      <div class="upload-progress__head">
        <span class="upload-progress__name">{{ state.fileName }}</span>
        <span class="muted">{{ state.stageText }}</span>
      </div>
      <div class="upload-progress__bar">
        <span :style="{ width: `${state.percent}%` }" />
      </div>
      <p v-if="state.error" class="upload-progress__error">{{ state.error }}</p>
      <div class="upload-progress__actions">
        <DsButton v-if="state.error" size="sm" variant="primary" @click="resume">断点续传</DsButton>
        <DsButton v-if="state.error" size="sm" @click="reset">重新开始</DsButton>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { reactive, ref } from 'vue'
import { DsButton, useToast } from '@/components'
import { fileHash, uploadApi } from '@/api/production'

/**
 * 分片上传组件（支持断点续传）。
 *
 * 流程：选择文件 → 计算 SHA-256 → 创建会话（命中重复文件时直接提示）→
 * 并发上传分片 → 服务端合并、扫描并解析入库。
 *
 * 上传中断时把 uploadId 记在 localStorage 里，刷新页面后仍可续传。
 */
const props = withDefaults(defineProps<{
  /** 目标知识库 ID */
  kbId: number
  /** 并发上传的分片数 */
  concurrency?: number
}>(), { concurrency: 3 })

const emit = defineEmits<{ (event: 'done', payload: any): void }>()

const toast = useToast()
const fileInput = ref<HTMLInputElement | null>(null)
const running = ref(false)

const state = reactive({
  fileName: '',
  file: null as File | null,
  uploadId: '',
  chunkSize: 0,
  totalChunks: 0,
  uploaded: 0,
  percent: 0,
  stageText: '',
  error: '',
})

/** 续传标识：同一个文件（名 + 大小 + 哈希）复用同一个 uploadId */
function resumeKey(name: string, size: number) {
  return `dawei_upload_${props.kbId}_${name}_${size}`
}

function onPick(event: Event) {
  const input = event.target as HTMLInputElement
  const file = input.files?.[0]
  input.value = ''
  if (!file) return
  state.file = file
  state.fileName = file.name
  state.error = ''
  state.uploaded = 0
  state.percent = 0
  void start(file)
}

/** 创建会话并开始上传 */
async function start(file: File) {
  running.value = true
  try {
    state.stageText = '正在计算文件指纹…'
    const hash = await fileHash(file)

    state.stageText = '正在创建上传会话…'
    const session = await uploadApi.createSession({
      kbId: props.kbId,
      fileName: file.name,
      fileSize: file.size,
      fileHash: hash,
    })

    // 服务端判定为重复文件，无需再传
    if (session?.duplicate) {
      state.stageText = ''
      state.percent = 100
      toast.info(session.message || '知识库中已存在相同内容的文档')
      emit('done', session)
      return
    }

    state.uploadId = session.uploadId
    state.chunkSize = session.chunkSize
    state.totalChunks = session.totalChunks
    localStorage.setItem(resumeKey(file.name, file.size), session.uploadId)

    await uploadAll(file)
  } catch (e: any) {
    state.error = e?.message || '上传失败'
    state.stageText = '上传中断'
  } finally {
    running.value = false
  }
}

/** 并发上传分片 */
async function uploadAll(file: File) {
  const chunkSize = state.chunkSize || file.size
  const total = state.totalChunks || 1
  const queue: number[] = []
  for (let index = 0; index < total; index += 1) queue.push(index)

  const worker = async () => {
    while (queue.length) {
      const index = queue.shift()
      if (index === undefined) return
      const start = index * chunkSize
      const chunk = file.slice(start, Math.min(start + chunkSize, file.size))
      await uploadApi.uploadChunk(state.uploadId, index, chunk)
      state.uploaded += 1
      state.percent = Math.round((state.uploaded / total) * 100)
      state.stageText = `已上传 ${state.uploaded}/${total} 个分片`
    }
  }

  const workers = Array.from({ length: Math.min(props.concurrency, total) }, () => worker())
  await Promise.all(workers)

  state.stageText = '正在合并并解析入库…'
  const result = await uploadApi.complete(state.uploadId)
  localStorage.removeItem(resumeKey(file.name, file.size))
  state.stageText = '已完成'
  state.percent = 100
  toast.success('文档已入库')
  emit('done', result)
}

/** 断点续传：查询服务端已收到的分片，只补传缺失部分 */
async function resume() {
  const file = state.file
  if (!file || !state.uploadId) {
    reset()
    return
  }
  running.value = true
  try {
    const status = await uploadApi.status(state.uploadId)
    const received: number[] = status?.receivedChunks || []
    state.chunkSize = status?.chunkSize || state.chunkSize
    state.totalChunks = status?.totalChunks || state.totalChunks
    state.uploaded = received.length
    state.error = ''

    const chunkSize = state.chunkSize || file.size
    const total = state.totalChunks || 1
    const queue: number[] = []
    for (let index = 0; index < total; index += 1) {
      if (!received.includes(index)) queue.push(index)
    }

    const worker = async () => {
      while (queue.length) {
        const index = queue.shift()
        if (index === undefined) return
        const begin = index * chunkSize
        const chunk = file.slice(begin, Math.min(begin + chunkSize, file.size))
        await uploadApi.uploadChunk(state.uploadId, index, chunk)
        state.uploaded += 1
        state.percent = Math.round((state.uploaded / total) * 100)
        state.stageText = `已上传 ${state.uploaded}/${total} 个分片`
      }
    }
    const workers = Array.from({ length: Math.min(props.concurrency, queue.length || 1) }, () => worker())
    await Promise.all(workers)

    state.stageText = '正在合并并解析入库…'
    const result = await uploadApi.complete(state.uploadId)
    localStorage.removeItem(resumeKey(file.name, file.size))
    state.stageText = '已完成'
    state.percent = 100
    toast.success('文档已入库')
    emit('done', result)
  } catch (e: any) {
    state.error = e?.message || '续传失败'
    state.stageText = '续传中断'
  } finally {
    running.value = false
  }
}

function reset() {
  state.file = null
  state.fileName = ''
  state.uploadId = ''
  state.uploaded = 0
  state.percent = 0
  state.stageText = ''
  state.error = ''
}
</script>

<style scoped>
.upload-progress {
  margin-top: 12px;
  padding: 12px;
  border: 1px solid var(--ds-border);
  border-radius: var(--ds-radius);
  background: var(--ds-bg-elevated);
}
.upload-progress__head { display: flex; justify-content: space-between; gap: 12px; font-size: 13px; margin-bottom: 8px; }
.upload-progress__name { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; font-weight: 600; }
.upload-progress__bar { height: 6px; border-radius: 999px; background: var(--ds-bg-soft); overflow: hidden; }
.upload-progress__bar span { display: block; height: 100%; background: var(--ds-brand); transition: width .2s; }
.upload-progress__error { margin: 8px 0 0; color: var(--ds-danger); font-size: 12px; }
.upload-progress__actions { display: flex; gap: 8px; margin-top: 10px; }
</style>