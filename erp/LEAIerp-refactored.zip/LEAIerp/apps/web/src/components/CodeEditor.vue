<template>
  <div class="code-editor">
    <div class="code-editor__bar"><span class="mono">PROMPT · {{ lines }} 行</span></div>
    <div class="code-editor__body">
      <pre class="code-editor__lines mono">{{ lineNumbers }}</pre>
      <textarea
        :value="modelValue"
        class="code-editor__input mono"
        spellcheck="false"
        :placeholder="placeholder"
        @input="emit('update:modelValue', ($event.target as HTMLTextAreaElement).value)"
      />
    </div>
  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue'

const props = withDefaults(defineProps<{
  modelValue: string
  placeholder?: string
}>(), { placeholder: '请输入 Prompt 模板…' })
const emit = defineEmits<{ (e: 'update:modelValue', value: string): void }>()

const lines = computed(() => (props.modelValue || '').split('\n').length)
const lineNumbers = computed(() => Array.from({ length: lines.value }, (_, i) => i + 1).join('\n'))
</script>

<style scoped>
.code-editor { border: 1px solid var(--ds-border); border-radius: var(--ds-radius); overflow: hidden; background: var(--ds-bg-code); }
.code-editor__bar { padding: 6px 12px; border-bottom: 1px solid var(--ds-border); background: var(--ds-bg-hover); font-size: 11px; color: var(--ds-text-3); }
.code-editor__body { display: flex; min-height: 320px; }
.code-editor__lines {
  margin: 0;
  padding: 12px 10px;
  text-align: right;
  color: var(--ds-text-3);
  font-size: 13px;
  line-height: 1.7;
  user-select: none;
  border-right: 1px solid var(--ds-border);
  background: var(--ds-bg-soft)
}
.code-editor__input {
  flex: 1;
  border: 0;
  outline: 0;
  resize: vertical;
  padding: 12px;
  font-size: 13px;
  line-height: 1.7;
  background: transparent;
  color: var(--ds-text);
  min-height: 320px
}
</style>
