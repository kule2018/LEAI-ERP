<!--
 * DetailDrawer 配置化详情抽屉组件（DeepSeek UI 版）
 * 职责：基于 items 字段配置自动渲染描述列表（DsDescriptions），支持字段级插槽（#item-{prop}）自定义渲染，
 *       并提供默认格式化（空值占位、布尔转「是/否」），无数据时展示空状态。通过 v-model:visible 控制显隐。
 * 与旧版区别：描述列表由自绘 DsDescriptions 承担，空态用自绘 EmptyState，不再依赖 Element Plus。
 * 页面位置 / 用途：用于查看记录详情，避免为每个详情页手写大量字段。
 * 核心 props：title 标题、data 详情数据对象、items 字段配置数组、column 描述列表列数、loading 加载态。
 *       其中 items 每项：label 显示名、prop 取值路径、span 跨列数、formatter 自定义格式化函数。
 * 插槽：item-{prop} 字段级自定义渲染（作用域含 value）、footer 底部自定义区。
 -->
<template>
  <!-- 详情抽屉：基于 items 配置渲染描述列表 -->
  <BaseDrawer v-model:visible="visible" :title="title || '详情'" :size="size" :loading="loading">
    <!-- 有字段配置时渲染描述列表；column 控制一行几列，bordered 显示边框 -->
    <DsDescriptions v-if="items?.length" :items="descItems" :data="data || {}" :column="column" bordered>
      <!-- 字段级插槽：#item-{prop}，可自定义渲染（如时间戳/标签/图片） -->
      <template v-for="it in items" :key="it.prop" #[`item-${it.prop}`]>
        <slot :name="`item-${it.prop}`" :value="data?.[it.prop]">
          <!-- 未提供插槽时走默认格式化展示 -->
          {{ format(data?.[it.prop], it.formatter) }}
        </slot>
      </template>
    </DsDescriptions>
    <!-- 无字段配置时展示空状态 -->
    <EmptyState v-else text="暂无数据" size="sm" />

    <!-- 仅当父组件提供了 footer 插槽时才渲染 -->
    <template v-if="$slots.footer" #footer>
      <slot name="footer" />
    </template>
  </BaseDrawer>
</template>

<script setup lang="ts">
// BaseDrawer：ds 风格抽屉容器；DsDescriptions：描述列表；EmptyState：空态
import { computed } from "vue";
import BaseDrawer from "./BaseDrawer.vue";
import DsDescriptions from "./ds/DsDescriptions.vue";
import EmptyState from "./EmptyState.vue";

// visible 双向绑定（父组件 v-model:visible），表示抽屉是否显示
const visible = defineModel<boolean>("visible", { required: true });

/** DsDescriptions 的 DescItem 以 key 取字段，而本组件对外用 prop 命名，这里统一映射 */
const descItems = computed(() =>
  (props.items || []).map((it) => ({ label: it.label, key: it.prop, span: it.span, formatter: it.formatter }))
);

/** 字段格式化函数类型 */
type Formatter = (v: any) => any;

const props = withDefaults(
  defineProps<{
    /** 标题 */
    title?: string;
    /** 抽屉宽度 */
    size?: string | number;
    /** 详情数据对象 */
    data?: Record<string, any>;
    /** 字段配置：label 显示名，prop 取值路径，span 跨列数，formatter 自定义格式化 */
    items?: { label: string; prop: string; span?: number; formatter?: Formatter }[];
    /** 描述列表列数（默认 2） */
    column?: number;
    /** 内容区加载态 */
    loading?: boolean;
  }>(),
  { size: "520px", column: 2, loading: false }
);

/**
 * 默认格式化方法。
 * 思路：优先使用字段自带的 formatter 自定义格式化；否则按约定规则展示——
 *       空值（null/undefined/空串）显示「-」，布尔值显示「是/否」，其余转字符串。
 * @param v 原始字段值
 * @param formatter 可选自定义格式化函数
 * @returns string 展示文本（空值统一为「-」）
 */
function format(v: any, formatter?: Formatter): string {
  if (formatter) return String(formatter(v) ?? "-");
  if (v === null || v === undefined || v === "") return "-";
  if (typeof v === "boolean") return v ? "是" : "否";
  return String(v);
}
</script>
