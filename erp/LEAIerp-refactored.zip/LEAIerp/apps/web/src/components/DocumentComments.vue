<!--
 * 单据评论与 @ 提及（文档第 30 章：单据评论@）。
 * ---------------------------------------------------------------------------
 * 挂在单据详情里：可查看讨论、输入评论、@同事。被 @ 的人会收到待办提醒
 * （提醒由 mock 的 notify 接口写入），评论不参与单据状态流转。
 -->
<template>
  <div class="comments">
    <div class="comments-title">讨论与协作 <span>{{ rows.length }}</span></div>
    <div v-for="row in rows" :key="row.id" class="comment-item">
      <div class="comment-avatar">{{ (row.authorName || '用').slice(0, 1) }}</div>
      <div class="comment-body">
        <div class="comment-meta"><b>{{ row.authorName }}</b><small>{{ row.createdAt }}</small></div>
        <p v-html="renderText(row.content)"></p>
      </div>
    </div>
    <div v-if="!rows.length" class="comments-empty">还没有讨论，来说第一句吧</div>

    <div class="comment-editor">
      <textarea v-model="text" class="ds-input" rows="3" placeholder="输入评论，输入 @ 可选择同事" @input="onInput" />
      <div v-if="mentionVisible" class="mention-list">
        <div v-for="user in mentionUsers" :key="user.id" class="mention-item" @click="pickMention(user)">
          {{ user.realName || user.username }}
        </div>
      </div>
      <div class="comment-foot">
        <DsButton size="sm" variant="primary" :loading="sending" @click="send">发表评论</DsButton>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
/** 单据评论：加载、提及、发送；@ 后触发通知写入 */
import { onMounted, ref } from 'vue';
import { sysApi } from '../api';
import { mockPost } from '../api/mockAdapter';
import { useToast } from '../components/ds/toast';
import { emit, Events } from '../utils/eventBus';

const props = defineProps<{ bizType: string; bizId: number | string }>();
const toast = useToast();
const rows = ref<any[]>([]);
const text = ref('');
const sending = ref(false);
const mentionVisible = ref(false);
const mentionUsers = ref<any[]>([]);

/** 加载评论列表 */
async function load(): Promise<void> {
  try { rows.value = (await mockPost('/api/v1/collab/comments/list', { bizType: props.bizType, bizId: props.bizId })) as any[]; }
  catch { rows.value = []; }
}

/** 输入时检测 @ 符号，弹出同事列表 */
async function onInput(): Promise<void> {
  const match = text.value.match(/@([^@\s]*)$/);
  if (!match) { mentionVisible.value = false; return; }
  mentionVisible.value = true;
  const result: any = await sysApi.users({ pageSize: 20, keyword: match[1] });
  mentionUsers.value = result?.list || result || [];
}

/** 选中同事，把 @姓名 插入文本 */
function pickMention(user: any): void {
  text.value = text.value.replace(/@([^@\s]*)$/, `@${user.realName || user.username} `);
  mentionVisible.value = false;
}

/** 把 @姓名 高亮显示（先转义 HTML 再替换，避免 XSS） */
function renderText(value: string): string {
  const safe = String(value || '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]!));
  return safe.replace(/@([^\s<]+)/g, '<b style="color:var(--ds-brand)">@$1</b>');
}

/** 发送评论，若含 @ 则同时写一条通知 */
async function send(): Promise<void> {
  if (!text.value.trim()) { toast.warning('请输入评论内容'); return; }
  sending.value = true;
  try {
    const row: any = await mockPost('/api/v1/collab/comments', {
      bizType: props.bizType, bizId: props.bizId, content: text.value, authorName: '我',
    });
    rows.value.push(row);
    if (text.value.includes('@')) {
      await mockPost('/api/v1/system/notifies', { title: '单据评论提及', content: `你在 ${props.bizType} 中被提及` });
      emit(Events.NOTIFY_RECEIVED, { title: '单据评论提及' });
    }
    text.value = '';
    toast.success('评论已发表');
  } finally { sending.value = false; }
}

onMounted(load);
</script>

<style scoped>
.comments { padding: 12px; }
.comments-title { font-size: 14px; font-weight: 600; margin-bottom: 12px; }
.comments-title span { color: var(--ds-text-3); font-weight: 400; }
.comment-item { display: flex; gap: 10px; padding: 10px 0; border-bottom: 1px solid var(--ds-divider); }
.comment-avatar { width: 30px; height: 30px; border-radius: 50%; background: var(--ds-brand-soft); color: var(--ds-brand); display: grid; place-items: center; flex: none; font-size: 12px; }
.comment-body { flex: 1; }
.comment-meta { display: flex; justify-content: space-between; font-size: 12px; }
.comment-meta small { color: var(--ds-text-3); }
.comment-body p { margin: 4px 0 0; font-size: 13px; line-height: 1.6; }
.comments-empty { padding: 24px; text-align: center; color: var(--ds-text-3); font-size: 13px; }
.comment-editor { margin-top: 12px; position: relative; }
.comment-editor .ds-input { width: 100%; box-sizing: border-box; }
.comment-foot { display: flex; justify-content: flex-end; margin-top: 8px; }
.mention-list { position: absolute; left: 0; bottom: 52px; z-index: 10; background: var(--ds-bg-elevated); border: 1px solid var(--ds-border); border-radius: var(--ds-radius); box-shadow: var(--ds-shadow-md); max-height: 180px; overflow: auto; }
.mention-item { padding: 7px 14px; font-size: 13px; cursor: pointer; }
.mention-item:hover { background: var(--ds-brand-soft); }
</style>
