<!--
 * EmptyState 空状态占位组件（DeepSeek UI 版）
 * 职责：当列表 / 详情无数据时，统一展示空状态占位——可选自定义插图、图标、文案与操作区。
 * 与旧版区别：基于 ds 设计令牌自绘（极简线框插画），不再依赖 Element Plus 图标。
 * 页面位置 / 用途：用于各列表页、详情页的空数据兜底展示。
 * 核心 props：text 占位文案、icon ds 图标名、size 尺寸（sm/md/lg）。
 * 插槽：image 自定义插图（优先级高于默认图标）、默认插槽为操作区（如「去新增」按钮）。
 -->
<template>
  <!-- 空状态：列表/详情无数据时的占位 -->
  <div class="empty-state" :class="`empty-state--${size}`">
    <!-- 自定义插图插槽：优先级高于默认图标 -->
    <div v-if="$slots.image" class="empty-state__image">
      <slot name="image" />
    </div>
    <!-- 未提供 image 插槽时，渲染 ds 内置线性图标 -->
    <svg v-else-if="iconD" class="empty-state__icon" viewBox="0 0 24 24" aria-hidden="true">
      <path :d="iconD" />
    </svg>
    <!-- 占位文案 -->
    <p class="empty-state__text">{{ text }}</p>
    <!-- 操作区：默认插槽，有内容才渲染（如引导按钮） -->
    <div v-if="$slots.default" class="empty-state__action">
      <slot />
    </div>
  </div>
</template>

<script setup lang="ts">
// computed 派生图标 path；getIcon 从 ds 图标字典取 path
import { computed } from "vue";
import { getIcon } from "./ds/icons";

// 组件入参（含默认值）
const props = withDefaults(
  defineProps<{
    /** 占位文案 */
    text?: string;
    /** ds 图标名，默认 Box（空盒子） */
    icon?: string;
    /** 尺寸：sm 紧凑 / md 常规 / lg 整页 */
    size?: "sm" | "md" | "lg";
  }>(),
  { text: "暂无数据", icon: "Box", size: "md" }
);

/**
 * 图标 path 解析。
 * @returns SVG path 的 d 属性
 */
const iconD = computed(() => getIcon(props.icon));
</script>

<style scoped>
.empty-state {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 10px;
  color: var(--ds-text-3);
}
.empty-state--sm { padding: 24px 12px; }
.empty-state--md { padding: 44px 16px; }
.empty-state--lg { padding: 72px 16px; }

/* 默认图标：线性空盒子，颜色取辅助文字色 */
.empty-state__icon {
  width: 52px;
  height: 52px;
  fill: none;
  stroke: var(--ds-border-strong);
  stroke-width: 1.2;
  stroke-linecap: round;
  stroke-linejoin: round;
  opacity: 0.9;
}
.empty-state--sm .empty-state__icon { width: 36px; height: 36px; }
.empty-state--lg .empty-state__icon { width: 64px; height: 64px; }
.empty-state__image { display: flex; }

.empty-state__text {
  margin: 0;
  font-size: var(--ds-font-sm);
  color: var(--ds-text-3);
}
.empty-state__action { margin-top: 4px; }
</style>
