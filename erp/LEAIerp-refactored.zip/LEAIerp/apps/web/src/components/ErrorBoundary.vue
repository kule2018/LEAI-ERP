<template>
  <div v-if="error" class="error-boundary" role="alert" aria-live="assertive">
    <div class="error-boundary__icon" aria-hidden="true">!</div>
    <h2 class="error-boundary__title">{{ title }}</h2>
    <p class="error-boundary__detail">{{ error.message || '页面渲染时发生未知错误' }}</p>
    <!-- AI 解释异常：把错误码与上下文交给 Copilot 生成处置步骤（文档第 24 章） -->
    <ErrorExplainer code="RENDER_ERROR" :message="error.message || '页面渲染时发生未知错误'" :context="stack.slice(0, 200)" />
    <div class="error-boundary__actions">
      <DsButton variant="primary" @click="reset">重试</DsButton>
      <DsButton @click="goHome">返回工作台</DsButton>
    </div>
    <details v-if="stack" class="error-boundary__stack">
      <summary>技术细节</summary>
      <pre class="mono">{{ stack }}</pre>
    </details>
  </div>
  <slot v-else />
</template>

<script setup lang="ts">
import { onErrorCaptured, ref } from 'vue'
import { useRouter } from 'vue-router'
import { DsButton } from '@/components'
import ErrorExplainer from '@/views/ai/ErrorExplainer.vue'

/**
 * 错误边界。
 *
 * 捕获子树内的渲染异常，避免整页白屏；
 * 提供「重试」与「返回工作台」两个出口，并保留技术细节便于排障。
 */
const props = withDefaults(defineProps<{
  /** 错误标题 */
  title?: string
}>(), { title: '页面出错了' })

const router = useRouter()
const error = ref<Error | null>(null)
const stack = ref('')

onErrorCaptured((err: Error) => {
  error.value = err
  stack.value = err.stack || ''
  // 已在此处消化异常，不再向上抛
  return false
})

function reset() {
  error.value = null
  stack.value = ''
}

function goHome() {
  reset()
  router.push('/dashboard')
}
</script>

<style scoped>
.error-boundary {
  margin: 32px auto;
  max-width: 560px;
  padding: 32px;
  text-align: center;
  border: 1px solid var(--ds-border);
  border-radius: var(--ds-radius-lg);
  background: var(--ds-bg-elevated);
}
.error-boundary__icon {
  width: 44px;
  height: 44px;
  margin: 0 auto 16px;
  display: grid;
  place-items: center;
  border-radius: 50%;
  background: var(--ds-danger-soft, rgba(220, 38, 38, 0.12));
  color: var(--ds-danger);
  font-size: 22px;
  font-weight: 700;
}
.error-boundary__title { margin: 0 0 8px; font-size: 18px; font-weight: 650; }
.error-boundary__detail { margin: 0 0 20px; color: var(--ds-text-3); font-size: 13px; line-height: 1.7; }
.error-boundary__actions { display: flex; justify-content: center; gap: 10px; }
.error-boundary__stack { margin-top: 20px; text-align: left; font-size: 12px; color: var(--ds-text-3); }
.error-boundary__stack pre { margin: 8px 0 0; white-space: pre-wrap; word-break: break-all; }
</style>