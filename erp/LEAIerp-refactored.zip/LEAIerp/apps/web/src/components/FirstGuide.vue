<!--
 * 首次引导浮层（文档第 24 章：首次进入分步引导）。
 * ---------------------------------------------------------------------------
 * 只在第一次登录成功后显示三步：全局搜索 → 快捷键 → AI 助理。
 * 完成后写 localStorage，不再打扰；系统参数可重置。
 -->
<template>
  <div v-if="visible" class="guide-mask">
    <div class="guide-card">
      <span class="guide-step">第 {{ index + 1 }} / {{ steps.length }} 步</span>
      <h3>{{ steps[index].title }}</h3>
      <p>{{ steps[index].desc }}</p>
      <div class="guide-dots"><i v-for="(s, i) in steps" :key="s.title" :class="{ active: i === index }" /></div>
      <div class="guide-foot">
        <DsButton variant="text" size="sm" @click="skip">跳过引导</DsButton>
        <div>
          <DsButton v-if="index > 0" size="sm" @click="index--">上一步</DsButton>
          <DsButton variant="primary" size="sm" @click="next">{{ index === steps.length - 1 ? '开始使用' : '下一步' }}</DsButton>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
/** 首次引导：展示三步核心操作，完成后不再自动弹出 */
import { onMounted, ref } from 'vue';

const visible = ref(false);
const index = ref(0);
const steps = [
  { title: '欢迎使用LEO ERP', desc: '左侧是全部业务菜单。工作台聚合了今日销售、待收款、低库存和待审批，每天进来先看这里。' },
  { title: '按 Ctrl + K 全局搜索', desc: '不用记菜单位置。按 Ctrl+K 或输入 /，可直接搜菜单、单号、产品和客户，回车即可打开。' },
  { title: '键盘流与 AI 助理', desc: 'N 新建、S 保存、Ctrl+Enter 提交、P 打印。右上角 AI 助理可自然语言查库存、生成单据草稿。' },
];

/** 首次挂载时判断是否展示 */
onMounted(() => {
  const param = localStorage.getItem('erp_guide_enabled');
  visible.value = param !== '0' && localStorage.getItem('erp_guide_done') !== '1';
});

/** 下一步，最后一步写入完成标记 */
function next(): void {
  if (index.value === steps.length - 1) { skip(); return; }
  index.value++;
}

/** 跳过或结束引导 */
function skip(): void {
  localStorage.setItem('erp_guide_done', '1');
  visible.value = false;
}
</script>

<style scoped>
.guide-mask { position: fixed; inset: 0; z-index: 3000; background: rgba(10, 14, 24, .45); display: grid; place-items: center; }
.guide-card { width: 420px; background: var(--ds-bg-elevated, #fff); border-radius: var(--ds-radius-lg, 14px); padding: 28px; box-shadow: var(--ds-shadow-lg); }
.guide-step { font-size: 12px; color: var(--ds-brand, #4d6bfe); }
.guide-card h3 { font-size: 18px; margin: 8px 0 10px; }
.guide-card p { font-size: 13px; line-height: 1.8; color: var(--ds-text-2, #4e5561); min-height: 92px; margin: 0; }
.guide-dots { display: flex; gap: 6px; margin: 12px 0; }
.guide-dots i { width: 18px; height: 4px; border-radius: 2px; background: var(--ds-border, #e8eaed); }
.guide-dots i.active { background: var(--ds-brand, #4d6bfe); }
.guide-foot { display: flex; justify-content: space-between; align-items: center; }
.guide-foot > div { display: flex; gap: 8px; }
</style>
