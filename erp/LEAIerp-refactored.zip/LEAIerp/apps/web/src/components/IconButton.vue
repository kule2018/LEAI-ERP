<!--
 * IconButton 图标按钮组件（DeepSeek UI 版）
 * 职责：工具栏 / 表格操作列的小图标按钮，统一尺寸、圆角与语义色。
 * 与旧版区别：基于 ds 设计令牌自绘，不再依赖 Element Plus；图标名走 ds 内置图标库（ds/icons.ts）。
 * 页面位置 / 用途：作为页面搭建的基础积木，配合表格、Tbar、Panel、BaseGrid 等使用。
 * 核心 props：icon 图标名、type 语义色（primary/danger/success/warning/info/default）、disabled、circle、size、text。
 * 核心 emits：click 点击事件。
 -->
<template>
  <!-- 图标按钮：无文字时为方形图标钮；有默认插槽文字时为「图标 + 文字」按钮 -->
  <button
    class="icon-btn"
    :class="[
      `icon-btn--${type}`,
      `icon-btn--${size}`,
      { 'is-circle': circle, 'is-icon-only': !$slots.default, 'is-disabled': disabled },
    ]"
    :type="nativeType"
    :disabled="disabled"
    :title="title"
    @click="onClick"
  >
    <!-- 图标：ds 内置线性图标 -->
    <svg v-if="iconD" class="icon-btn__icon" viewBox="0 0 24 24" aria-hidden="true"><path :d="iconD" /></svg>
    <!-- 文字（可选） -->
    <span v-if="$slots.default" class="icon-btn__text"><slot /></span>
  </button>
</template>

<script setup lang="ts">
// computed 派生图标 path；getIcon 从 ds 图标字典取 path
import { computed } from "vue";
import { getIcon } from "./ds/icons";

const props = withDefaults(
  defineProps<{
    /** ds 图标名，如 'Plus' / 'Refresh' / 'Delete' */
    icon?: string;
    /** 语义色：primary 品牌 / danger 危险 / success 成功 / warning 警告 / info 中性 / default 默认 */
    type?: "primary" | "danger" | "success" | "warning" | "info" | "default";
    /** 是否禁用 */
    disabled?: boolean;
    /** 是否圆形按钮 */
    circle?: boolean;
    /** 尺寸：sm / md / lg */
    size?: "sm" | "md" | "lg";
    /** 原生 type（表单内提交按钮用 submit） */
    nativeType?: "button" | "submit" | "reset";
    /** 悬浮提示（无文字时建议必填，提升可用性） */
    title?: string;
  }>(),
  {
    type: "default",
    disabled: false,
    circle: false,
    size: "md",
    nativeType: "button",
    title: "",
  }
);

const emit = defineEmits<{ (e: "click", ev: MouseEvent): void }>();

/**
 * 图标 path 解析：查 ds 图标字典，未注册返回空串（不渲染图标）。
 * @returns SVG path 的 d 属性
 */
const iconD = computed(() => (props.icon ? getIcon(props.icon) : ""));

/**
 * 点击转发（禁用时不触发）。
 * @param ev 原生鼠标事件
 * @returns 无
 */
function onClick(ev: MouseEvent): void {
  if (props.disabled) return;
  emit("click", ev);
}
</script>

<style scoped>
.icon-btn {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  border: 1px solid transparent;
  border-radius: var(--ds-radius-sm);
  background: transparent;
  color: var(--ds-text-2);
  font-family: inherit;
  font-weight: 500;
  white-space: nowrap;
  cursor: pointer;
  user-select: none;
  transition: background var(--ds-dur-fast) var(--ds-ease), border-color var(--ds-dur-fast) var(--ds-ease),
    color var(--ds-dur-fast) var(--ds-ease), box-shadow var(--ds-dur-fast) var(--ds-ease);
}
.icon-btn:hover:not(:disabled) { background: var(--ds-bg-hover); color: var(--ds-text); }
.icon-btn:active:not(:disabled) { background: var(--ds-bg-active); }
.icon-btn:disabled { opacity: 0.45; cursor: not-allowed; }

/* 尺寸 */
.icon-btn--sm { height: 28px; min-width: 28px; padding: 0 6px; font-size: var(--ds-font-sm); }
.icon-btn--md { height: 34px; min-width: 34px; padding: 0 8px; font-size: var(--ds-font-md); }
.icon-btn--lg { height: 40px; min-width: 40px; padding: 0 10px; font-size: var(--ds-font-lg); }
/* 纯图标：内边距归零，保持正方形 */
.icon-btn.is-icon-only { padding: 0; }
.icon-btn.is-icon-only.icon-btn--sm { width: 28px; }
.icon-btn.is-icon-only.icon-btn--md { width: 34px; }
.icon-btn.is-icon-only.icon-btn--lg { width: 40px; }
.icon-btn.is-circle { border-radius: 50%; }

/* 图标 */
.icon-btn__icon {
  width: 1.15em;
  height: 1.15em;
  flex: none;
  fill: none;
  stroke: currentColor;
  stroke-width: 1.9;
  stroke-linecap: round;
  stroke-linejoin: round;
}

/* 语义色 */
.icon-btn--primary { color: var(--ds-brand); }
.icon-btn--primary:hover:not(:disabled) { background: var(--ds-brand-soft); color: var(--ds-brand); }
.icon-btn--danger { color: var(--ds-danger); }
.icon-btn--danger:hover:not(:disabled) { background: rgba(220, 38, 38, 0.1); color: var(--ds-danger); }
.icon-btn--success { color: var(--ds-success); }
.icon-btn--success:hover:not(:disabled) { background: rgba(22, 163, 74, 0.1); color: var(--ds-success); }
.icon-btn--warning { color: var(--ds-warning); }
.icon-btn--warning:hover:not(:disabled) { background: rgba(217, 119, 6, 0.1); color: var(--ds-warning); }
.icon-btn--info { color: var(--ds-text-2); }
</style>
