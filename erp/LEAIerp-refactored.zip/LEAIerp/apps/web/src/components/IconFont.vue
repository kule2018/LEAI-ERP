<!--
 * IconFont 图标封装组件（DeepSeek UI 版）
 * 职责：按名称渲染 ds 内置 SVG 图标（见 ds/icons.ts），统一尺寸 / 颜色 / 旋转（spin）与静态旋转角度（rotate）。
 * 与旧版区别：不再依赖外部第三方图标库，改为组件库自带的 ~50 个线性图标字典；
 *             传入未注册的名字时，若字符串本身是 SVG path（长度 > 6 且含 M），按 path 兜底渲染。
 * 页面位置 / 用途：作为配置化组件，被 StatCard、Tbar、BaseTree 等通过图标名字符串引用。
 * 核心 props：name 图标名、size 尺寸、color 颜色、spin 旋转动画、rotate 静态旋转角度。
 -->
<template>
  <!-- 图标封装：按名称渲染 ds 内置线性图标，统一尺寸/颜色 -->
  <svg
    v-if="d"
    class="icon-font"
    :class="{ 'is-spin': spin }"
    :style="{
      width: typeof size === 'number' ? size + 'px' : size,
      height: typeof size === 'number' ? size + 'px' : size,
      color: color,
      transform: rotate ? `rotate(${rotate}deg)` : undefined,
    }"
    viewBox="0 0 24 24"
    aria-hidden="true"
  >
    <path :d="d" />
  </svg>
</template>

<script setup lang="ts">
// getIcon：从 ds 图标字典按名取 path；取不到时按自定义 path 兜底
import { computed } from "vue";
import { getIcon } from "./ds/icons";

const props = withDefaults(
  defineProps<{
    /** ds 图标名（如 'Plus' / 'Search' / 'Refresh'），或直接传 SVG path 的 d */
    name?: string;
    /** 尺寸：px 数字或 CSS 值（默认 16） */
    size?: number | string;
    /** 颜色（默认继承 currentColor） */
    color?: string;
    /** 是否旋转（用于 loading 态） */
    spin?: boolean;
    /** 静态旋转角度（度），如 90 / 180 */
    rotate?: number;
  }>(),
  { size: 16 }
);

/**
 * 解析出最终要渲染的 path。
 * 思路：先查图标字典；未命中时若字符串「看起来像 path」（长度 > 6 且以 M/m 开头），
 *       按自定义 path 兜底，兼容旧代码里直接写 d 的用法。
 * @returns SVG path 的 d 属性（空串表示不渲染）
 */
const d = computed(() => {
  const n = props.name || "";
  if (!n) return "";
  return getIcon(n) || (/^[Mm].{6,}$/.test(n) ? n : "");
});
</script>

<style scoped>
.icon-font {
  display: inline-block;
  vertical-align: middle;
  fill: none;
  stroke: currentColor;
  stroke-width: 1.8;
  stroke-linecap: round;
  stroke-linejoin: round;
  flex: none;
}
.icon-font.is-spin {
  animation: icon-font-spin 1s linear infinite;
}
@keyframes icon-font-spin {
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
}
</style>
