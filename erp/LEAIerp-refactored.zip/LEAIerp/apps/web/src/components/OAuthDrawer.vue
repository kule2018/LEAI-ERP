<template>
  <BaseDrawer
    :visible="visible"
    :title="`OAuth 授权 · ${account?.accountName || ''}`"
    size="620px"
    @update:visible="onVisible"
  >
    <div class="oa">
      <DsAlert
        type="info"
        description="需先在「系统设置 → 平台配置」填写该平台的 appId / appSecret 与回调地址。授权成功后令牌加密写入账号，接口不回显明文。"
      />

      <section class="oa__step">
        <div class="oa__title"><b>1</b> 生成授权链接</div>
        <p class="oa__hint">链接 10 分钟内有效且只能使用一次（state 一次性校验，防重放）。</p>
        <div class="oa__ops">
          <DsButton variant="primary" size="md" :loading="starting" @click="onStart">生成授权链接</DsButton>
          <DsButton v-if="info?.authorizationUrl" variant="default" size="md" @click="openUrl">
            打开平台授权页
          </DsButton>
          <DsButton v-if="info?.authorizationUrl" variant="text" size="md" @click="onCopy">复制链接</DsButton>
        </div>
        <div v-if="info" class="oa__meta">
          <div class="oa__row"><span>回调地址</span><b>{{ info.redirectUri }}</b></div>
          <div class="oa__row"><span>state</span><b>{{ String(info.state || '').slice(0, 12) }}…</b></div>
          <div class="oa__row"><span>平台</span><b>{{ platformLabel(info.platform) }}</b></div>
        </div>
        <p v-if="info?.authorizationUrl" class="oa__url">{{ info.authorizationUrl }}</p>
      </section>

      <section class="oa__step">
        <div class="oa__title"><b>2</b> 粘贴授权码完成绑定</div>
        <p class="oa__hint">没有公网回调域名时（本地 / 内网），从平台跳转地址里复制 <code>code</code> 参数贴到下面。</p>
        <DsInput v-model="code" placeholder="粘贴平台返回的 code" />
        <div class="oa__ops">
          <DsButton variant="primary" size="md" :loading="exchanging" :disabled="!code.trim()" @click="onExchange">
            完成绑定
          </DsButton>
        </div>
      </section>

      <p class="oa__hint">
        回调成功后浏览器会跳回账号列表并提示结果；若提示「未配置应用」，请先到平台配置补全后再试。
      </p>
    </div>

    <template #footer>
      <div class="oa__foot">
        <DsButton variant="default" size="md" @click="close">关闭</DsButton>
      </div>
    </template>
  </BaseDrawer>
</template>

<script setup lang="ts">
import { ref, watch } from 'vue';
import { copyText, useToast } from '@ds';
import { accountsApi } from '@/api/accounts';
import { platformLabel } from '@/constants/platform';

/**
 * OAuth 授权抽屉。
 *
 * 两条路径都走真实的令牌交换接口：
 *  - 有公网回调：生成授权链接 → 平台授权 → 回跳 /api/accounts/oauth/callback 自动绑定；
 *  - 无公网回调：生成链接后手动复制回调地址里的 code，用「粘贴授权码」完成绑定。
 */
const props = defineProps<{
  visible: boolean;
  account: { id: number; accountName: string; platform: string } | null;
}>();
const emit = defineEmits<{ (e: 'update:visible', v: boolean): void; (e: 'done'): void }>();

const toast = useToast();
const starting = ref(false);
const exchanging = ref(false);
const info = ref<any>(null);
const code = ref('');

watch(
  () => props.visible,
  (v) => {
    if (v) {
      info.value = null;
      code.value = '';
    }
  },
);

async function onStart(): Promise<void> {
  if (!props.account) return;
  starting.value = true;
  try {
    info.value = await accountsApi.oauthStart(props.account.id);
    toast.success('授权链接已生成，10 分钟内有效');
  } catch (e: any) {
    toast.error(e?.message || '生成授权链接失败');
  } finally {
    starting.value = false;
  }
}

function openUrl(): void {
  if (info.value?.authorizationUrl) window.open(info.value.authorizationUrl, '_blank', 'noopener');
}

async function onCopy(): Promise<void> {
  try {
    await copyText(info.value?.authorizationUrl || '');
    toast.success('授权链接已复制');
  } catch {
    toast.error('复制失败，请手动选择链接');
  }
}

async function onExchange(): Promise<void> {
  if (!props.account) return;
  exchanging.value = true;
  try {
    await accountsApi.oauthExchange(props.account.id, code.value.trim());
    toast.success('授权成功，账号凭证已更新');
    emit('done');
    close();
  } catch (e: any) {
    toast.error(e?.message || '绑定失败');
  } finally {
    exchanging.value = false;
  }
}

function onVisible(v: boolean): void {
  emit('update:visible', v);
}

function close(): void {
  emit('update:visible', false);
}
</script>

<style scoped>
.oa {
  display: flex;
  flex-direction: column;
  gap: 16px;
}
.oa__step {
  display: flex;
  flex-direction: column;
  gap: 8px;
  padding: 12px;
  border: 1px solid var(--ds-border);
  border-radius: var(--ds-radius);
}
.oa__title {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: var(--ds-font-sm);
  font-weight: 600;
}
.oa__title b {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 18px;
  height: 18px;
  border-radius: 50%;
  background: var(--ds-brand);
  color: #fff;
  font-size: 11px;
}
.oa__hint {
  margin: 0;
  color: var(--ds-text-3);
  font-size: var(--ds-font-xs);
  line-height: 1.8;
}
.oa__ops {
  display: flex;
  align-items: center;
  gap: 8px;
  flex-wrap: wrap;
}
.oa__meta {
  display: flex;
  flex-direction: column;
  gap: 4px;
  padding: 8px 10px;
  border-radius: var(--ds-radius-sm);
  background: var(--ds-bg-soft);
}
.oa__row {
  display: flex;
  gap: 10px;
  font-size: var(--ds-font-xs);
  color: var(--ds-text-2);
}
.oa__row span {
  flex: 0 0 62px;
  color: var(--ds-text-3);
}
.oa__row b {
  word-break: break-all;
  font-weight: 500;
}
.oa__url {
  margin: 0;
  padding: 8px 10px;
  border-radius: var(--ds-radius-sm);
  background: var(--ds-bg-soft);
  color: var(--ds-text-2);
  font-size: var(--ds-font-xs);
  word-break: break-all;
}
.oa__foot {
  display: flex;
  justify-content: flex-end;
}
</style>
