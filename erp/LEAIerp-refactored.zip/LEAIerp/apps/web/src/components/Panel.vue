<!--
 * Panel 通用面板容器组件（DeepSeek UI 版）
 * 职责：带标题的内容容器，提供可选边框、内容区加载态、可折叠能力，以及 title/extra 插槽，
 *       作为页面搭建的基础积木统一卡片外观。
 * 与旧版区别：基于 ds 设计令牌自绘（DsCard 同款视觉），不再依赖 Element Plus。
 * 页面位置 / 用途：用于把页面划分为一个个带标题的内容区块。
 * 核心 props：title 标题、loading 内容区加载态、bordered 是否显示边框、collapsible 是否可折叠。
 * 插槽：title 自定义标题区、extra 标题右侧操作区、默认插槽为面板主体内容。
 -->
<template>
  <!-- 通用面板：带标题的内容容器，页面搭建的基础积木 -->
  <section class="panel" :class="{ 'panel--bordered': bordered, 'panel--flat': !bordered }">
    <!-- 标题栏：存在 title 插槽 / title 文本 / 可折叠时渲染 -->
    <header v-if="title || $slots.title || collapsible" class="panel__header">
      <!-- 标题区：默认展示 title 文本，可被 title 插槽覆盖 -->
      <slot name="title">
        <span class="panel__title">{{ title }}</span>
      </slot>
      <div class="panel__extra">
        <!-- 标题右侧操作区插槽 -->
        <slot name="extra" />
        <!-- 可折叠时展示折叠/展开切换按钮：折叠态箭头朝下，展开态朝上 -->
        <button
          v-if="collapsible"
          type="button"
          class="panel__fold"
          :title="collapsed ? '展开' : '收起'"
          @click="collapsed = !collapsed"
        >
          <svg viewBox="0 0 24 24" aria-hidden="true"><path d="m6 9 6 6 6-6" /></svg>
        </button>
      </div>
    </header>
    <!-- 主体区：collapsed 为 false 时显示，并支持 loading 加载态 -->
    <div v-show="!collapsed" class="panel__body">
      <!-- 加载态：转圈 + 文案覆盖在内容区上 -->
      <div v-if="loading" class="panel__loading">
        <span class="panel__spin" />
        <span>加载中…</span>
      </div>
      <!-- 默认插槽：面板主体内容 -->
      <slot />
    </div>
  </section>
</template>

<script setup lang="ts">
// ref 声明折叠状态
import { ref } from "vue";

withDefaults(
  defineProps<{
    /** 标题 */
    title?: string;
    /** 内容区加载态 */
    loading?: boolean;
    /** 是否显示边框（默认 true） */
    bordered?: boolean;
    /** 是否可折叠（默认 false） */
    collapsible?: boolean;
  }>(),
  { loading: false, bordered: true, collapsible: false }
);

// 折叠状态（仅 collapsible 为真时生效），控制面板主体显示与折叠图标方向
const collapsed = ref(false);
</script>

<style scoped>
.panel {
  background: var(--ds-bg-elevated);
  border: 1px solid var(--ds-border);
  border-radius: var(--ds-radius-lg);
  margin-bottom: var(--ds-space-3);
  transition: box-shadow var(--ds-dur) var(--ds-ease);
}
.panel--flat { border-color: transparent; box-shadow: var(--ds-shadow-sm); }

.panel__header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  padding: 12px 16px;
  border-bottom: 1px solid var(--ds-divider);
}
.panel__title { font-weight: 600; font-size: var(--ds-font-md); color: var(--ds-text); }
.panel__extra { display: flex; align-items: center; gap: 8px; }

.panel__fold {
  width: 28px;
  height: 28px;
  display: grid;
  place-items: center;
  border: 0;
  border-radius: var(--ds-radius-xs);
  background: transparent;
  color: var(--ds-text-3);
  cursor: pointer;
  transition: background var(--ds-dur-fast) var(--ds-ease);
}
.panel__fold:hover { background: var(--ds-bg-hover); color: var(--ds-text); }
.panel__fold svg {
  width: 16px;
  height: 16px;
  fill: none;
  stroke: currentColor;
  stroke-width: 2;
  stroke-linecap: round;
  stroke-linejoin: round;
}

.panel__body {
  position: relative;
  padding: 16px;
  min-height: 40px;
}

/* 加载态：半透明覆盖，防止重复操作 */
.panel__loading {
  position: absolute;
  inset: 0;
  z-index: 5;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  background: var(--ds-frosted);
  color: var(--ds-text-3);
  font-size: var(--ds-font-sm);
  border-radius: inherit;
}
.panel__spin {
  width: 15px;
  height: 15px;
  border: 2px solid var(--ds-border);
  border-top-color: var(--ds-brand);
  border-radius: 50%;
  animation: ds-spin 0.7s linear infinite;
}
</style>
