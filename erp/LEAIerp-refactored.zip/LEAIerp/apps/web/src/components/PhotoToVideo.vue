<!-- src/components/PhotoToVideo.vue -->
<script setup lang="ts">
/**
 * 拍照讲解 —— 把一张题目照片变成一段知识点讲解视频。
 *
 * 整体思路：
 *   1) 输入层：点击选择、拖拽投递、调后置摄像头拍照三条路径都收敛到 handleFile()，
 *      统一做体积校验，并生成 objectURL 预览（让用户确认拍的是不是这张）；
 *   2) 提交层：上传拿 taskId 后立即开启轮询（1.5s/次），不依赖长连接，
 *      因为视频生成横跨多个 Worker 进程，轮询实现最稳；
 *   3) 反馈层：把后端 stage 映射成 8 段可读的流水线步骤条，用户能看见"卡在哪一步"，
 *      而不是一个沉默的百分比；
 *   4) 增量收益：progress ≥ 45%（讲稿阶段完成）先拉一次分镜脚本，
 *      用户可提前审文案，不必干等视频渲染完；
 *   5) 清理：卸载前必须清定时器 + revoke objectURL，否则组件销毁后仍在发请求 / 占内存。
 */
import { ref, onBeforeUnmount, computed } from 'vue';
import DsButton from './ds/DsButton.vue';
import DsProgress from './ds/DsProgress.vue';
import DsStatCard from './ds/DsStatCard.vue';
import DsEmpty from './ds/DsEmpty.vue';
import DsField from './ds/DsField.vue';
import { useToast } from './ds/toast';
import { formatBytes } from './ds/format';
import type { PhotoVideoTask as VideoTask, PhotoVideoScene as Scene } from './types';

/**
 * 后端接口三件套（默认实现走 fetch，宿主可通过 props 覆盖为自己的 API 层）。
 * 这样组件既能零配置跑通演示（配合 Mock 后端），也能直接对接真实服务。
 */
const props = withDefaults(
  defineProps<{
    /** 创建任务：上传文件并返回任务 ID */
    createVideoTask?: (file: File, subject: string, grade: string) => Promise<number | string>;
    /** 查询任务状态 */
    getTask?: (taskId: number | string) => Promise<VideoTask>;
    /** 查询分镜列表 */
    listScenes?: (taskId: number | string) => Promise<Scene[]>;
  }>(),
  {
    // 默认实现：约定后端接口为 /api/photo-video/tasks（创建 / 查询 / 分镜）
    createVideoTask: async (file: File, subject: string, grade: string) => {
      const fd = new FormData();
      fd.append('file', file);
      fd.append('subject', subject);
      fd.append('grade', grade);
      const res = await fetch('/api/photo-video/tasks', { method: 'POST', body: fd });
      const data = await res.json();
      return data?.id ?? data?.data?.id;
    },
    getTask: async (taskId: number | string) => {
      const res = await fetch(`/api/photo-video/tasks/${taskId}`);
      return (await res.json())?.data ?? (await res.json());
    },
    listScenes: async (taskId: number | string) => {
      const res = await fetch(`/api/photo-video/tasks/${taskId}/scenes`);
      return (await res.json())?.data ?? [];
    },
  },
);

/** 学科选项 */
const SUBJECTS = ['数学', '物理', '化学', '英语', '语文', '生物'];
/** 学段选项 */
const GRADES = ['小学', '初中', '高中', '大学'];

/** 生成长链路的 8 个阶段（顺序即流水线顺序，用于步骤条高亮） */
const STAGES = ['UPLOADED', 'PREPROCESS', 'OCR', 'UNDERSTAND', 'SCRIPT', 'TTS', 'RENDER', 'DONE'];
/** 阶段中文名映射 */
const STAGE_TEXT: Record<string, string> = {
  UPLOADED: '已上传',
  PREPROCESS: '图像预处理',
  OCR: '文字识别',
  UNDERSTAND: '知识点分析',
  SCRIPT: '讲稿生成',
  TTS: '语音合成',
  RENDER: '视频渲染',
  DONE: '完成',
};

/** 单个文件体积上限（20MB）：手机直出照片普遍在 3–8MB，留出冗余 */
const MAX_SIZE = 20 * 1024 * 1024;

const toast = useToast();

/** 选中的学科 */
const subject = ref('数学');
/** 学段 */
const grade = ref('高中');
/** 预览图（本地 objectURL） */
const previewUrl = ref('');
/** 待上传文件 */
const file = ref<File | null>(null);
/** 当前任务 */
const task = ref<VideoTask | null>(null);
/** 分镜列表 */
const scenes = ref<Scene[]>([]);
/** 拖拽悬停态（仅用于高亮投放区） */
const dragging = ref(false);
/** 是否处理中：未完成且未失败 */
const busy = computed(() => !!task.value && task.value.progress < 100 && task.value.status !== 'FAILED');
/** 当前阶段在流水线中的下标，用于步骤条着色 */
const stageIndex = computed(() => {
  const i = STAGES.indexOf(task.value?.stage ?? '');
  return i < 0 ? 0 : i;
});
/** 已选文件的体积文案 */
const fileSizeText = computed(() => (file.value ? formatBytes(file.value.size) : ''));
/** 是否生成成功 */
const done = computed(() => task.value?.progress === 100 && task.value?.status !== 'FAILED');

/** 轮询定时器句柄 */
let timer: number | undefined;

/** 隐藏的普通文件选择框 */
const fileInput = ref<HTMLInputElement | null>(null);
/** 隐藏的摄像头输入框（capture 属性在手机上直接调起后置摄像头） */
const camInput = ref<HTMLInputElement | null>(null);

/**
 * 打开普通文件选择框。
 * @returns 无
 */
function pick(): void {
  if (busy.value) return;
  fileInput.value?.click();
}

/**
 * 打开摄像头拍照。
 * @returns 无
 */
function shoot(): void {
  if (busy.value) return;
  camInput.value?.click();
}

/**
 * 统一的文件接收口：校验体积 → 记入状态 → 生成本地预览。
 * @param f 用户选中的文件（可能为 null）
 * @returns 无
 */
function handleFile(f: File | null | undefined): void {
  if (!f) return;
  // 第一条防线：非图片直接拒（拖拽投递可能带来任意文件）
  if (!f.type.startsWith('image/')) {
    toast.warning('请选择图片文件（jpg / png / heic 均可）');
    return;
  }
  // 第二条防线：体积上限，避免上传到一半才失败
  if (f.size > MAX_SIZE) {
    toast.error(`图片过大（${formatBytes(f.size)}），请压缩到 20MB 以内`);
    return;
  }
  file.value = f;
  // 释放上一个 objectURL，避免长时间使用后内存泄漏
  if (previewUrl.value) URL.revokeObjectURL(previewUrl.value);
  previewUrl.value = URL.createObjectURL(f);
}

/**
 * input[type=file] 的 change 回调。
 * @param e change 事件
 * @returns 无
 */
function onFileChange(e: Event): void {
  const input = e.target as HTMLInputElement;
  handleFile(input.files?.[0]);
  // 清空 value，允许用户重复选同一个文件
  input.value = '';
}

/**
 * 拖拽投放回调。
 * @param e drop 事件
 * @returns 无
 */
function onDrop(e: DragEvent): void {
  dragging.value = false;
  handleFile(e.dataTransfer?.files?.[0]);
}

/**
 * 提交：创建任务并开始轮询。
 * @returns Promise<void>
 */
async function handleSubmit(): Promise<void> {
  if (!file.value) return;
  // 重置上一轮状态，支持连续生成
  task.value = null;
  scenes.value = [];
  stopPoll();

  try {
    const taskId = await props.createVideoTask(file.value, subject.value, grade.value);
    // 先乐观置一个初始态，让进度条立刻出现，避免"点了没反应"的空窗期
    task.value = { id: taskId, stage: 'UPLOADED', status: 'PENDING', progress: 0 };
    startPoll(taskId);
    toast.success('已提交，正在生成讲解视频');
  } catch (err) {
    toast.error('提交失败，请检查网络后重试');
    throw err;
  }
}

/**
 * 开启轮询。
 * 为什么用轮询而不是 SSE：视频生成链路长且跨多个 Worker 进程，
 * 轮询实现更简单可靠；若要更实时，可改用 SSE（第 01/02 章有完整示例）。
 * @param taskId 任务 ID
 * @returns 无
 */
function startPoll(taskId: number | string): void {
  // setInterval 的回调约定返回 void，异步逻辑抽到 pollOnce 并显式忽略其 Promise
  timer = window.setInterval(() => {
    void pollOnce(taskId);
  }, 1500);
}

/**
 * 单次轮询：拉取任务状态，讲稿阶段完成后补拉一次分镜，并在完成/失败时收尾。
 * @param taskId 任务 ID
 * @returns 无
 */
async function pollOnce(taskId: number | string): Promise<void> {
  try {
    const t = await props.getTask(taskId);
    task.value = t;

    // 讲稿阶段完成后拉一次分镜（用长度判断，只需拉一次）
    if (t.progress >= 45 && !scenes.value.length) {
      scenes.value = await props.listScenes(taskId).catch(() => []);
    }
    // 结束条件：完成或失败
    if (t.progress >= 100 || t.status === 'FAILED') {
      stopPoll();
      if (t.status === 'FAILED') toast.error(t.errMsg || '生成失败，请换个清晰的题目照片重试');
      else toast.success('讲解视频已生成');
    }
  } catch {
    // 单次查询失败不终止轮询：弱网下偶发丢包不应让用户丢掉整个任务
  }
}

/**
 * 停止轮询并清理定时器。
 * @returns 无
 */
function stopPoll(): void {
  if (timer) {
    clearInterval(timer);
    timer = undefined;
  }
}

/**
 * 格式化毫秒为 m:ss。
 * @param ms 毫秒
 * @returns 形如 "1:03"
 */
function fmtDuration(ms: number): string {
  const s = Math.round((ms || 0) / 1000);
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;
}

/**
 * 触发成片下载。
 * 为什么不用 <a download>：视频地址是跨域对象存储，
 * a[download] 对跨域资源会被浏览器忽略，改用中转 a 标签 + 打开新窗口兜底。
 * @returns 无
 */
function downloadVideo(): void {
  const url = task.value?.videoUrl;
  if (!url) return;
  const a = document.createElement('a');
  a.href = url;
  a.download = `讲解视频-${subject.value}-${Date.now()}.mp4`;
  a.target = '_blank';
  a.rel = 'noopener';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  toast.success('已开始下载');
}

/**
 * 重新拍一张：清空当前输入与结果，回到初始态。
 * @returns 无
 */
function resetAll(): void {
  stopPoll();
  task.value = null;
  scenes.value = [];
  file.value = null;
  if (previewUrl.value) URL.revokeObjectURL(previewUrl.value);
  previewUrl.value = '';
}

// 组件卸载前清理定时器与 objectURL
onBeforeUnmount(() => {
  stopPoll();
  if (previewUrl.value) URL.revokeObjectURL(previewUrl.value);
});
</script>

<template>
  <div class="p2v">
    <!-- 页头：一句话说清这个工具干什么 -->
    <header class="p2v-head">
      <div>
        <h2 class="p2v-title">拍照讲解</h2>
        <p class="p2v-sub">拍摄或上传题目照片，自动识别知识点并生成一段讲解视频</p>
      </div>
      <span class="ds-tag">AI 生成</span>
    </header>

    <div class="p2v-grid">
      <!-- 左栏：输入与设置 -->
      <section class="ds-card p2v-panel">
        <h3 class="ds-section-title">1. 上传题目照片</h3>

        <div
          class="p2v-drop"
          :class="{ 'is-drag': dragging, 'has-img': !!previewUrl }"
          @click="pick"
          @dragover.prevent="dragging = true"
          @dragleave="dragging = false"
          @drop.prevent="onDrop"
        >
          <img v-if="previewUrl" :src="previewUrl" alt="题目预览" />
          <div v-else class="p2v-drop-empty">
            <svg width="40" height="40" viewBox="0 0 24 24" fill="none" aria-hidden="true">
              <rect x="3" y="4" width="18" height="16" rx="3" stroke="currentColor" stroke-width="1.6" />
              <circle cx="8.5" cy="9.5" r="1.6" fill="currentColor" />
              <path d="M4 17l5-5 4 4 3-3 4 4" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" />
            </svg>
            <p>点击选择图片，或把照片拖到这里</p>
            <small>建议正对题目拍摄，光线均匀、四角完整</small>
          </div>
          <button v-if="previewUrl" class="p2v-repick" type="button" @click.stop="pick">重新选择</button>
        </div>

        <div class="p2v-camrow">
          <DsButton variant="default" size="sm" :disabled="busy" @click="shoot">用摄像头拍照</DsButton>
          <DsButton v-if="previewUrl" variant="text" size="sm" :disabled="busy" @click="resetAll">清空</DsButton>
          <span v-if="fileSizeText" class="ds-hint">{{ fileSizeText }}</span>
        </div>

        <!-- 两个隐藏 input：一个走相册/文件，一个带 capture 走摄像头 -->
        <input ref="fileInput" type="file" accept="image/*" hidden @change="onFileChange" />
        <input ref="camInput" type="file" accept="image/*" capture="environment" hidden @change="onFileChange" />

        <h3 class="ds-section-title p2v-mt">2. 讲解设置</h3>
        <div class="p2v-fields">
          <DsField label="学科">
            <select v-model="subject" class="ds-select" :disabled="busy">
              <option v-for="s in SUBJECTS" :key="s" :value="s">{{ s }}</option>
            </select>
          </DsField>
          <DsField label="学段">
            <select v-model="grade" class="ds-select" :disabled="busy">
              <option v-for="g in GRADES" :key="g" :value="g">{{ g }}</option>
            </select>
          </DsField>
        </div>

        <DsButton
          variant="primary"
          size="lg"
          block
          :loading="busy"
          :disabled="!file"
          @click="handleSubmit"
        >
          {{ busy ? '正在生成…' : '生成讲解视频' }}
        </DsButton>
        <p class="ds-hint">生成约需 1–2 分钟，期间可以留在本页看进度。</p>
      </section>

      <!-- 右栏：进度 / 分镜 / 成片 -->
      <section class="p2v-main">
        <!-- 进度卡 -->
        <div v-if="task" class="ds-card p2v-panel">
          <div class="ds-row-between p2v-cardhead">
            <h3 class="ds-section-title">生成进度</h3>
            <span class="ds-tag" :class="{ 'is-ok': done, 'is-err': task.status === 'FAILED' }">
              {{ task.status === 'FAILED' ? '生成失败' : done ? '已完成' : '处理中' }}
            </span>
          </div>

          <!-- 8 段流水线步骤条：让用户知道卡在哪一步 -->
          <ol class="p2v-steps">
            <li
              v-for="(st, i) in STAGES"
              :key="st"
              :class="{ 'is-done': i < stageIndex, 'is-now': i === stageIndex && !done, 'is-fin': i === stageIndex && done }"
            >
              <span class="p2v-step-dot" />
              <span class="p2v-step-txt">{{ STAGE_TEXT[st] }}</span>
            </li>
          </ol>

          <DsProgress
            :value="task.progress"
            :status="task.status === 'FAILED' ? 'danger' : done ? 'success' : 'running'"
          />

          <div v-if="task.errMsg" class="p2v-err">
            生成失败：{{ task.errMsg }}（阶段：{{ STAGE_TEXT[task.stage] ?? task.stage }}）
          </div>

          <div class="p2v-stats">
            <DsStatCard label="学科" :value="subject" />
            <DsStatCard label="学段" :value="grade" />
            <DsStatCard label="分镜" :value="scenes.length || '—'" unit="段" />
            <DsStatCard label="成片时长" :value="task.durationMs ? fmtDuration(task.durationMs) : '—'" />
          </div>
        </div>

        <!-- 未开始时的空态 -->
        <div v-else class="ds-card p2v-panel">
          <DsEmpty
            title="还没有生成任务"
            description="上传一张题目照片，右侧会显示完整的生成流水线与分镜脚本。"
            size="lg"
          />
        </div>

        <!-- 分镜脚本：讲稿生成后即可见，先看结构再等成片 -->
        <div v-if="scenes.length" class="ds-card p2v-panel">
          <h3 class="ds-section-title">分镜脚本</h3>
          <ol class="p2v-scenes">
            <li v-for="(s, i) in scenes" :key="s.id">
              <div class="p2v-scene-head">
                <span class="p2v-scene-no">{{ i + 1 }}</span>
                <span class="ds-tag">{{ s.sceneType }}</span>
                <span class="p2v-scene-dur">{{ fmtDuration(s.durationMs) }}</span>
              </div>
              <p class="p2v-scene-text">{{ s.narration }}</p>
            </li>
          </ol>
        </div>

        <!-- 成片 -->
        <div v-if="task?.videoUrl" class="ds-card p2v-panel">
          <h3 class="ds-section-title">成片（{{ fmtDuration(task.durationMs ?? 0) }}）</h3>
          <video
            class="p2v-video"
            :src="task.videoUrl"
            :poster="task.coverUrl ?? undefined"
            controls
            playsinline
          />
          <div class="p2v-actions">
            <DsButton variant="primary" size="md" @click="downloadVideo">下载视频</DsButton>
            <DsButton variant="text" size="md" @click="resetAll">再拍一题</DsButton>
          </div>
        </div>
      </section>
    </div>
  </div>
</template>

<style scoped>
.p2v {
  max-width: var(--ds-content-max);
  margin: 0 auto;
  padding: var(--ds-space-6) var(--ds-space-4) var(--ds-space-8);
}

/* ---------- 页头 ---------- */
.p2v-head {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: var(--ds-space-3);
  margin-bottom: var(--ds-space-5);
}
.p2v-title {
  margin: 0;
  font-size: var(--ds-font-2xl);
  font-weight: 650;
  color: var(--ds-text);
  letter-spacing: -0.01em;
}
.p2v-sub {
  margin: 6px 0 0;
  font-size: var(--ds-font-sm);
  color: var(--ds-text-3);
}

/* ---------- 两栏布局 ---------- */
.p2v-grid {
  display: grid;
  grid-template-columns: minmax(0, 5fr) minmax(0, 6fr);
  gap: var(--ds-space-4);
  align-items: start;
}
.p2v-panel {
  padding: var(--ds-space-5);
}
.p2v-main {
  display: flex;
  flex-direction: column;
  gap: var(--ds-space-4);
  min-width: 0;
}
.p2v-cardhead {
  margin-bottom: var(--ds-space-3);
}
.p2v-mt {
  margin-top: var(--ds-space-5);
}

/* ---------- 投放区 ---------- */
.p2v-drop {
  position: relative;
  border: 1.5px dashed var(--ds-border);
  border-radius: var(--ds-radius-lg);
  background: var(--ds-bg-soft);
  min-height: 220px;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  overflow: hidden;
  transition: border-color var(--ds-dur) var(--ds-ease), background var(--ds-dur) var(--ds-ease);
}
.p2v-drop:hover {
  border-color: var(--ds-brand);
  background: var(--ds-bg-hover);
}
.p2v-drop.is-drag {
  border-color: var(--ds-brand);
  background: var(--ds-brand-soft);
}
.p2v-drop.has-img {
  border-style: solid;
  background: #000;
}
.p2v-drop img {
  max-width: 100%;
  max-height: 340px;
  object-fit: contain;
  display: block;
}
.p2v-drop-empty {
  text-align: center;
  color: var(--ds-text-3);
  padding: var(--ds-space-6) var(--ds-space-4);
}
.p2v-drop-empty p {
  margin: 10px 0 4px;
  font-size: var(--ds-font-sm);
  color: var(--ds-text-2);
}
.p2v-drop-empty small {
  font-size: var(--ds-font-xs);
}
.p2v-repick {
  position: absolute;
  right: 10px;
  bottom: 10px;
  padding: 5px 12px;
  font-size: var(--ds-font-xs);
  color: #fff;
  background: rgba(0, 0, 0, 0.55);
  border: none;
  border-radius: var(--ds-radius-full);
  cursor: pointer;
  backdrop-filter: blur(4px);
}
.p2v-repick:hover {
  background: rgba(0, 0, 0, 0.72);
}

.p2v-camrow {
  display: flex;
  align-items: center;
  gap: var(--ds-space-3);
  margin-top: var(--ds-space-3);
}

/* ---------- 表单 ---------- */
.p2v-fields {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: var(--ds-space-3);
  margin-bottom: var(--ds-space-4);
}

/* ---------- 步骤条 ---------- */
.p2v-steps {
  list-style: none;
  display: flex;
  flex-wrap: wrap;
  gap: 6px 14px;
  margin: 0 0 var(--ds-space-4);
  padding: 0;
}
.p2v-steps li {
  display: flex;
  align-items: center;
  gap: 6px;
  font-size: var(--ds-font-xs);
  color: var(--ds-text-3);
}
.p2v-step-dot {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: var(--ds-border);
  flex: none;
}
.p2v-steps li.is-done {
  color: var(--ds-success);
}
.p2v-steps li.is-done .p2v-step-dot {
  background: var(--ds-success);
}
.p2v-steps li.is-now {
  color: var(--ds-brand);
  font-weight: 600;
}
.p2v-steps li.is-now .p2v-step-dot {
  background: var(--ds-brand);
  animation: p2v-pulse 1.4s ease-in-out infinite;
}
.p2v-steps li.is-fin {
  color: var(--ds-success);
  font-weight: 600;
}
.p2v-steps li.is-fin .p2v-step-dot {
  background: var(--ds-success);
}
@keyframes p2v-pulse {
  0%, 100% { box-shadow: 0 0 0 0 var(--ds-brand-soft); }
  50% { box-shadow: 0 0 0 5px var(--ds-brand-soft); }
}

.p2v-err {
  margin-top: var(--ds-space-3);
  padding: 10px 12px;
  font-size: var(--ds-font-sm);
  color: var(--ds-danger);
  background: var(--ds-bg-soft);
  border-radius: var(--ds-radius-md);
}

.p2v-stats {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
  gap: var(--ds-space-3);
  margin-top: var(--ds-space-4);
}

/* ---------- 分镜 ---------- */
.p2v-scenes {
  list-style: none;
  margin: 0;
  padding: 0;
  display: flex;
  flex-direction: column;
  gap: var(--ds-space-3);
}
.p2v-scenes li {
  padding: var(--ds-space-3) var(--ds-space-4);
  background: var(--ds-bg-soft);
  border-radius: var(--ds-radius-md);
}
.p2v-scene-head {
  display: flex;
  align-items: center;
  gap: 8px;
}
.p2v-scene-no {
  width: 20px;
  height: 20px;
  border-radius: 50%;
  background: var(--ds-brand);
  color: #fff;
  font-size: 11px;
  display: flex;
  align-items: center;
  justify-content: center;
  flex: none;
}
.p2v-scene-dur {
  margin-left: auto;
  font-size: var(--ds-font-xs);
  color: var(--ds-text-3);
  font-variant-numeric: tabular-nums;
}
.p2v-scene-text {
  margin: 8px 0 0;
  font-size: var(--ds-font-sm);
  line-height: 1.7;
  color: var(--ds-text-2);
}

/* ---------- 成片 ---------- */
.p2v-video {
  width: 100%;
  border-radius: var(--ds-radius-md);
  background: #000;
  display: block;
}
.p2v-actions {
  display: flex;
  align-items: center;
  gap: var(--ds-space-3);
  margin-top: var(--ds-space-4);
}
.p2v-actions a {
  text-decoration: none;
}

/* ---------- 窄屏堆叠 ---------- */
@media (max-width: 960px) {
  .p2v-grid {
    grid-template-columns: 1fr;
  }
  .p2v-fields {
    grid-template-columns: 1fr;
  }
}
</style>
