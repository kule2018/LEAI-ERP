<template>
  <BaseDrawer :visible="visible" title="发布内容" size="680px" @update:visible="onVisible">
    <div class="pd">
      <!-- 内容概览 -->
      <section class="pd__section">
        <div class="pd__label">待发布内容</div>
        <div class="pd__content">
          <b>{{ content?.title || '—' }}</b>
          <p>{{ excerpt }}</p>
        </div>
      </section>

      <!-- 账号选择 -->
      <section class="pd__section">
        <div class="pd__label">
          发布账号
          <span class="pd__count">已选 {{ selectedIds.length }} / 可用 {{ activeAccounts.length }}</span>
          <DsButton variant="text" size="sm" @click="toggleAll">
            {{ selectedIds.length === activeAccounts.length ? '取消全选' : '全选可用账号' }}
          </DsButton>
        </div>

        <div v-if="loading" class="pd__empty">账号加载中…</div>
        <div v-else-if="!accounts.length" class="pd__empty">还没有账号，请先在「矩阵账号」中接入</div>
        <div v-else class="pd__accounts">
          <label
            v-for="a in accounts"
            :key="a.id"
            class="pd__acc"
            :class="{ 'is-checked': selectedIds.includes(a.id), 'is-disabled': a.status !== 'active' }"
          >
            <DsCheckbox
              :model-value="selectedIds.includes(a.id)"
              :disabled="a.status !== 'active'"
              @update:model-value="toggle(a.id)"
            />
            <span class="pd__acc-name" :title="a.accountName">{{ a.accountName }}</span>
            <DsTag size="sm" :color="platformColor(a.platform)">{{ platformLabel(a.platform) }}</DsTag>
            <DsTag v-if="a.status !== 'active'" size="sm" color="neutral">未启用</DsTag>
            <DsTag v-else-if="useVariants && variantPlatforms.includes(a.platform)" size="sm" color="brand">版本</DsTag>
            <DsTag v-else-if="useVariants" size="sm" color="neutral">原文</DsTag>
            <span v-else-if="a.healthScore < 60" class="pd__acc-warn">健康分 {{ a.healthScore }}</span>
          </label>
        </div>
      </section>

      <!-- 多平台差异化版本：有版本时默认按账号平台选用，没生成的平台回退原稿 -->
      <section v-if="hasVariants" class="pd__section">
        <div class="pd__label">
          多平台差异化版本
          <DsSwitch v-model="useVariants" size="sm" />
          <span class="pd__count">{{ useVariants ? '按账号平台选用版本' : '全部使用原文' }}</span>
        </div>
        <div class="pd__variants">
          <DsTag v-for="p in variantPlatforms" :key="p" size="sm" color="brand">{{ platformLabel(p) }}</DsTag>
          <span class="pd__hint-inline">未生成版本的平台自动回退原稿，结果里会逐账号说明。</span>
        </div>
      </section>

      <!-- 时间与策略 -->
      <section class="pd__row">
        <div class="pd__field">
          <div class="pd__label">发布时间</div>
          <DsDatePicker v-model="form.scheduledAt" type="datetime" placeholder="留空表示立即发布" />
        </div>
        <div class="pd__field">
          <div class="pd__label">随机化窗口（分钟）</div>
          <DsInputNumber v-model="form.jitterMinutes" :min="0" :max="60" :precision="0" />
        </div>
      </section>
      <p class="pd__hint">
        发布时间留空则立即进入队列；随机化窗口会在计划时刻 ±N 分钟内取随机点，降低整点批量发布的机械特征。
        内容会逐账号过合规卡口：命中禁止级敏感词的任务不会入队。
      </p>

      <!-- 结果 -->
      <section v-if="result" class="pd__result">
        <DsAlert
          :type="result.skipped.length ? 'warning' : 'success'"
          :title="`已创建 ${result.created?.length || 0} 条任务${result.skipped.length ? `，跳过 ${result.skipped.length} 条` : ''}`"
          :description="result.skipped.length ? '以下账号未创建成功，请按提示处理后可再次提交：' : '任务已进入排期队列，可在「发布任务」查看状态。'"
        />
        <div v-for="s in result.skipped" :key="s.accountId" class="pd__skip">
          <span class="pd__skip-id">账号 #{{ s.accountId }}</span>
          <span>{{ s.reason }}</span>
        </div>
        <div v-for="s in originalFallbacks" :key="`fb-${s.accountId}`" class="pd__skip">
          <span class="pd__skip-id">账号 #{{ s.accountId }}</span>
          <span>{{ platformLabel(s.platform) || '未知平台' }}：{{ s.reason || '回退原稿' }}</span>
        </div>
      </section>
    </div>

    <template #footer>
      <div class="pd__foot">
        <DsButton variant="default" size="md" @click="close">取消</DsButton>
        <DsButton
          variant="primary"
          size="md"
          :loading="submitting"
          :disabled="!selectedIds.length || !content"
          @click="submit"
        >
          创建发布任务
        </DsButton>
      </div>
    </template>
  </BaseDrawer>
</template>

<script setup lang="ts">
import { computed, reactive, ref, watch } from 'vue';
import { useToast } from '@ds';
import { accountsApi } from '@/api/accounts';
import { publishApi } from '@/api/publish';
import { platformColor, platformLabel } from '@/constants/platform';
import { toIsoString } from '@/utils/date';

/**
 * 内容 → 发布 抽屉。
 *
 * 业务闭环：创作台审核通过的内容，在这里选一个或多个账号批量分发；
 * 真正的校验（审核状态 / 账号可用性 / 合规词 / 重复排期）都在后端，
 * 前端只负责把「选了什么」如实提交，并把逐账号的跳过原因展示出来。
 *
 * 内容带 platformVariants 时可按账号平台自动选用差异化版本，
 * 未生成版本的账号回退原稿，避免一稿原样群发到整个矩阵。
 */
const props = defineProps<{
  visible: boolean;
  content: { id: number; title: string; body?: string; platformVariants?: Record<string, any> } | null;
}>();
const emit = defineEmits<{ (e: 'update:visible', v: boolean): void; (e: 'done'): void }>();

const toast = useToast();
const loading = ref(false);
const submitting = ref(false);
const accounts = ref<any[]>([]);
const selectedIds = ref<number[]>([]);
const result = ref<any>(null);
const useVariants = ref(false);

const form = reactive<{ scheduledAt: string; jitterMinutes: number | null }>({
  scheduledAt: '',
  jitterMinutes: 5,
});

const activeAccounts = computed(() => accounts.value.filter((a) => a.status === 'active'));
/** 只认「标题 + 正文齐全」的版本，与后端 pickPlatformVariant 口径一致 */
const variantPlatforms = computed(() =>
  Object.entries(props.content?.platformVariants || {})
    .filter(([, v]: [string, any]) => !!v && !!String(v?.title || '').trim() && !!String(v?.body || '').trim())
    .map(([p]) => p),
);
const hasVariants = computed(() => variantPlatforms.value.length > 0);
const originalFallbacks = computed(() =>
  (result.value?.variantSelections || []).filter((s: any) => s?.used === 'original'),
);
const excerpt = computed(() => {
  const body = (props.content?.body || '').replace(/\s+/g, ' ').trim();
  if (!body) return '（无正文）';
  return body.length > 120 ? `${body.slice(0, 120)}…` : body;
});

watch(
  () => props.visible,
  (v) => {
    if (!v) return;
    result.value = null;
    form.scheduledAt = '';
    form.jitterMinutes = 5;
    // 有可用版本时默认按平台分发，用户可一键切回原文
    useVariants.value = hasVariants.value;
    void loadAccounts();
  },
  { immediate: true },
);

/** 账号下拉：只取前 200 个，够覆盖常规矩阵规模 */
async function loadAccounts(): Promise<void> {
  loading.value = true;
  try {
    const res = await accountsApi.list({ page: 1, pageSize: 200 });
    accounts.value = res?.list || [];
    // 默认全选可用账号：矩阵分发的常见诉求
    selectedIds.value = activeAccounts.value.map((a) => a.id);
  } catch (e: any) {
    toast.error(e?.message || '账号列表加载失败');
  } finally {
    loading.value = false;
  }
}

function toggle(id: number): void {
  const account = accounts.value.find((a) => a.id === id);
  if (!account || account.status !== 'active') return;
  selectedIds.value = selectedIds.value.includes(id)
    ? selectedIds.value.filter((n) => n !== id)
    : [...selectedIds.value, id];
}

function toggleAll(): void {
  selectedIds.value =
    selectedIds.value.length === activeAccounts.value.length ? [] : activeAccounts.value.map((a) => a.id);
}

/** DsDatePicker 返回 `YYYY-MM-DD HH:mm`，统一转 ISO 再提交 */
function toIso(value: string): string | undefined {
  return toIsoString(value);
}

async function submit(): Promise<void> {
  if (!props.content) return;
  if (!selectedIds.value.length) {
    toast.error('请至少选择一个发布账号');
    return;
  }
  submitting.value = true;
  try {
    const res: any = await publishApi.createFromContent({
      contentId: props.content.id,
      accountIds: selectedIds.value,
      scheduledAt: toIso(form.scheduledAt),
      jitterMinutes: form.jitterMinutes ?? 5,
      usePlatformVariants: useVariants.value && hasVariants.value,
    });
    result.value = {
      created: res?.created || [],
      skipped: res?.skipped || [],
      variantSelections: res?.variantSelections || [],
    };
    emit('done');
    if (!result.value.skipped.length) {
      toast.success(`已创建 ${result.value.created.length} 条发布任务`);
      close();
    } else {
      toast.warning(`创建 ${result.value.created.length} 条，跳过 ${result.value.skipped.length} 条`);
    }
  } catch (e: any) {
    toast.error(e?.message || '创建发布任务失败');
  } finally {
    submitting.value = false;
  }
}

function onVisible(v: boolean): void {
  emit('update:visible', v);
}

function close(): void {
  emit('update:visible', false);
}
</script>

<style scoped>
.pd {
  display: flex;
  flex-direction: column;
  gap: 14px;
}
.pd__section {
  display: flex;
  flex-direction: column;
  gap: 8px;
}
.pd__label {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: var(--ds-font-sm);
  color: var(--ds-text-2);
  font-weight: 500;
}
.pd__count {
  color: var(--ds-text-3);
  font-size: var(--ds-font-xs);
  font-weight: 400;
}
.pd__label .ds-button {
  margin-left: auto;
}
.pd__content {
  padding: 10px 12px;
  border: 1px solid var(--ds-border);
  border-radius: var(--ds-radius);
  background: var(--ds-bg-soft);
}
.pd__content b {
  font-size: var(--ds-font-md, 15px);
}
.pd__content p {
  margin: 6px 0 0;
  color: var(--ds-text-2);
  font-size: var(--ds-font-sm);
  line-height: 1.7;
  word-break: break-word;
}
.pd__accounts {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(260px, 1fr));
  gap: 8px;
  max-height: 260px;
  overflow: auto;
  padding: 2px;
}
.pd__acc {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 8px 10px;
  border: 1px solid var(--ds-border);
  border-radius: var(--ds-radius-sm);
  cursor: pointer;
  min-width: 0;
}
.pd__acc.is-checked {
  border-color: var(--ds-brand);
  background: var(--ds-bg-soft);
}
.pd__acc.is-disabled {
  cursor: not-allowed;
  opacity: 0.6;
}
.pd__acc-name {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  font-size: var(--ds-font-sm);
}
.pd__acc-warn {
  color: var(--ds-warning);
  font-size: var(--ds-font-xs);
}
.pd__variants {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 6px;
}
.pd__hint-inline {
  color: var(--ds-text-3);
  font-size: var(--ds-font-xs);
}
.pd__empty {
  padding: 18px;
  text-align: center;
  color: var(--ds-text-3);
  font-size: var(--ds-font-sm);
  border: 1px dashed var(--ds-border);
  border-radius: var(--ds-radius-sm);
}
.pd__row {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 12px;
}
.pd__field {
  display: flex;
  flex-direction: column;
  gap: 6px;
}
.pd__hint {
  margin: 0;
  color: var(--ds-text-3);
  font-size: var(--ds-font-xs);
  line-height: 1.8;
}
.pd__result {
  display: flex;
  flex-direction: column;
  gap: 6px;
}
.pd__skip {
  display: flex;
  gap: 8px;
  padding: 6px 10px;
  border-radius: var(--ds-radius-sm);
  background: var(--ds-bg-soft);
  font-size: var(--ds-font-sm);
  color: var(--ds-text-2);
}
.pd__skip-id {
  flex: 0 0 auto;
  color: var(--ds-text-3);
}
.pd__foot {
  display: flex;
  justify-content: flex-end;
  gap: 8px;
}
</style>
