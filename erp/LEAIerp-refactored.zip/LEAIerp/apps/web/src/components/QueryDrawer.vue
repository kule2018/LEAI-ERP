<!--
 * QueryDrawer 高级查询抽屉组件（DeepSeek UI 版）
 * 职责：基于 fields 字段配置动态生成查询表单（复用 BaseForm），提供「重置 / 查询」底部操作，
 *       查询时把表单模型通过 search 事件回传父组件，重置时清空模型并触发 reset 事件。
 * 与旧版区别：基于自绘 BaseDrawer + BaseForm（均为 ds 风格），不再依赖 Element Plus。
 * 页面位置 / 用途：用于列表页的「高级筛选」侧滑表单。
 * 核心 props：title 标题、size 抽屉宽度、fields 表单字段配置（必填）、loading 内容区加载态。
 * 核心 emits：search 查询（携带表单模型）、reset 重置。
 * 双向绑定：visible 控制抽屉显隐（父组件 v-model:visible）。
 -->
<template>
  <!-- 高级查询抽屉：基于 JSON 配置动态生成查询表单 -->
  <BaseDrawer v-model:visible="visible" :title="title || '高级查询'" :size="size" :loading="loading">
    <!-- 复用 BaseForm 按 fields 配置渲染表单；模型原地修改，无需整体替换（避免 v-model 对 reactive 常量告警） -->
    <BaseForm :model-value="model" :fields="fields" label-position="top" @update:model-value="onModelUpdate" />

    <!-- 底部操作：重置 + 查询 -->
    <template #footer>
      <DsButton variant="default" size="md" @click="onReset">重置</DsButton>
      <DsButton variant="primary" size="md" @click="onSearch">查询</DsButton>
    </template>
  </BaseDrawer>
</template>

<script setup lang="ts">
// reactive 声明响应式查询模型；BaseDrawer 抽屉容器；BaseForm 配置化表单；DsButton 按钮
import { reactive } from "vue";
import BaseDrawer from "./BaseDrawer.vue";
import BaseForm from "./BaseForm.vue";
import type { FormField } from "./types";
import DsButton from "./ds/DsButton.vue";

// visible 双向绑定（父组件 v-model:visible），表示抽屉是否显示
const visible = defineModel<boolean>("visible", { required: true });

const props = withDefaults(
  defineProps<{
    /** 标题 */
    title?: string;
    /** 抽屉宽度 */
    size?: string | number;
    /** 表单字段配置（必填） */
    fields: FormField[];
    /** 内容区加载态 */
    loading?: boolean;
  }>(),
  { loading: false }
);

const emit = defineEmits<{
  (e: "search", model: Record<string, any>): void;
  (e: "reset"): void;
}>();

// 内部查询模型：以 fields 的 prop 初始化空对象
const model = reactive<Record<string, any>>(
  Object.fromEntries(props.fields.map((f) => [f.prop, undefined]))
);

/**
 * 模型更新回调：BaseForm 默认原地修改字段（同一对象引用）；
 * 若未来整体替换模型对象，则把新值合并进原 reactive 对象，保持引用与响应式稳定。
 * @param next BaseForm 回传的模型对象
 * @returns 无
 */
function onModelUpdate(next: Record<string, any>): void {
  if (next && next !== model) Object.assign(model, next);
}

/**
 * 点击「查询」：把当前表单模型展开为普通对象快照后通过 search 事件回传父组件。
 * @returns 无
 */
function onSearch(): void {
  emit("search", { ...model });
}

/**
 * 点击「重置」：遍历 fields 把所有字段置回 undefined 清空表单，并触发 reset 事件。
 * @returns 无
 */
function onReset(): void {
  for (const f of props.fields) model[f.prop] = undefined;
  emit("reset");
}
</script>
