# DeepSeek UI 组件库

一套零第三方 UI 依赖的 Vue 3 组件库，视觉语言对齐 DeepSeek：品牌蓝 `#4d6bfe`、克制的灰阶文字阶梯、细边框、圆角卡片、线性图标，支持明暗双主题。

- **46 个 `Ds*` 设计系统组件**：通用 UI 积木（按钮 / 表单 / 数据展示 / 导航 / 反馈 / 对话）
- **19 个 `Base*` 业务组件**：在 ds 设计系统上重实现的业务级组件（配置化表单 / 数据表格 / 查询抽屉 / 上传等），API 与旧版兼容，业务侧可无缝迁移

技术栈：Vue 3（`<script setup>` + TypeScript）+ Scoped CSS。不依赖 Element Plus / Ant Design 等任何 UI 框架，图标为自绘 SVG 线性图标库（约 50 个）。

---

## 一、快速开始

### 方式 1：一键全局注册（推荐）

```ts
// main.ts
import { createApp } from 'vue';
import { installDsUi } from './components';

installDsUi(createApp(App)); // 注册全部 65 个组件 + 引入主题样式
```

### 方式 2：仅注册全局样式与工具（按需引入组件）

```ts
import { registerGlobalComponents } from './components';
registerGlobalComponents(app); // 等价于 installDsUi
```

### 方式 3：按需 import

```vue
<script setup lang="ts">
import { DsButton, DsCard, BaseForm } from './components';
</script>
```

---

## 二、组件清单

### ds 设计系统（46）

| 分类 | 组件 |
| --- | --- |
| 基础 | `DsButton` `DsSpinner` `DsDivider` `DsCard` `DsField` `DsEmpty` |
| 表单 | `DsInput` `DsSelect` `DsCheckbox` `DsRadio` `DsSwitch` `DsSlider` `DsRate` `DsDatePicker` `DsCascader` `DsTreeSelect` |
| 数据展示 | `DsTable` `DsTree` `DsTag` `DsBadge` `DsAvatar` `DsStatCard` `DsDescriptions` `DsSteps` `DsSkeleton` `DsProgress` `DsSegmented` `DsPagination` `DsResult` |
| 导航 | `DsMenu` `DsBreadcrumb` `DsTabs` `DsCollapse` / `DsCollapseItem` `DsDropdown` `DsAppShell` |
| 反馈 / 浮层 | `DsAlert` `DsToast` `DsModal` `DsDrawer` `DsPopover` `DsTooltip` `DsUploader` |
| 对话 | `DsChatView` `DsComposer` `DsMarkdown` |

\* 图标不通过组件使用，而是根目录 `IconFont.vue` 与 `getIcon()`，见「工具函数」。

### 业务组件（19）

| 组件 | 用途 | 关键 API |
| --- | --- | --- |
| `BaseForm` | 24 列栅格配置化表单，15 种控件 | `fields` / `v-model` / `validate()` / `resetFields()` / `#field-{prop}` 插槽 |
| `BaseGrid` | 数据表格（取数函数驱动） | `columns` / `fetch` / `selection` / `exportable` / `#action` 插槽 / expose `reload/getSelection` |
| `BaseTable` | BaseGrid 全功能版 | 增加 `searchable` / `sizeable` / `serverSort` / `expandable` / `showSummary` / 懒加载树形 |
| `BaseDialog` | 自绘弹窗 | `v-model:visible` / `draggable` / `fullscreen` / `confirmText` |
| `BaseDrawer` | 抽屉容器 | `v-model:visible` / `fullscreen` 切换 / `loading` |
| `DetailDrawer` | 详情抽屉 | `data` + `items`（label/prop/span/formatter）/ `#item-{prop}` 插槽 |
| `QueryDrawer` | 高级查询抽屉 | `fields` / emits `search(reset)` |
| `BaseSelect` | 远程搜索下拉 | `fetch(keyword)` / `multiple` / `allowCreate` / expose `reload` |
| `BaseTree` | 树选择 | `data` / `checkable` / `lazy` + `lazyLoad` / expose `getCheckedKeys/filter/expandAll` |
| `BaseUpload` | 文件上传 | `action` / `listType` / `drag` / `limit` / `maxSize` / expose `clear` |
| `TopSearch` | 全局菜单搜索 | `routes` 注入 / `historyEnabled` / emits `navigate` |
| `PhotoToVideo` | 照片转视频任务页 | 三个 API 可选注入（默认 fetch 实现）/ 轮询进度 |
| `StatCard` | 统计卡片 | `title` / `value` / `trend`（涨红跌绿）/ `loading` 骨架屏 |
| `Panel` / `Tbar` | 面板 / 工具条 | `#title` / `#extra` 插槽 |
| `EmptyState` | 空态 | `description` / `#image` / 默认插槽 |
| `IconFont` / `IconButton` | 图标 / 图标按钮 | 约 50 个线性图标名 |
| `ParentView` | 路由分组占位 | 仅渲染 `<router-view />` |

---

## 三、主题系统

### 切换明暗主题

```ts
import { useTheme } from './components';

const { isDark, toggleTheme } = useTheme();
toggleTheme(); // 写入 localStorage('ds-theme')，初次跟随 prefers-color-scheme
```

### 设计令牌（`ds/theme.css`）

| 类别 | 令牌 |
| --- | --- |
| 品牌 | `--ds-brand: #4d6bfe` / `--ds-brand-soft` / `--ds-brand-active` |
| 背景 | `--ds-bg` / `--ds-bg-soft` / `--ds-bg-elevated` / `--ds-bg-hover` / `--ds-bg-active` |
| 文字 | `--ds-text` / `--ds-text-2` / `--ds-text-3` |
| 边框 | `--ds-border` / `--ds-border-strong` / `--ds-divider` |
| 圆角 | `--ds-radius-xs/sm/md/lg/full` |
| 字号 | `--ds-font-xs/sm/md/lg/xl` |
| 间距 | `--ds-space-1 ~ --ds-space-8` |
| 动效 | `--ds-dur-fast/base/slow` / `--ds-ease` |
| 阴影 | `--ds-shadow-sm/md/lg` |
| 布局 | `--ds-sidebar-w` / `--ds-content-max` / `--ds-ctl-h-sm/md/lg` |
| 涨跌 | `--ds-up`（红）/ `--ds-down`（绿），遵循 A 股习惯 |

暗色模式：`:root[data-theme='dark']` 统一切换。

---

## 四、工具函数

```ts
import { useToast, formatBytes, formatDuration, copyText, renderMarkdown, getIcon, DS_ICONS } from './components';

useToast().success('保存成功');        // 全局 Toast，最多堆叠 5 条
formatBytes(1536);                     // → '1.5 KB'
copyText('待复制内容');                 // clipboard API + execCommand 降级
renderMarkdown('# 标题\n**加粗**');     // 自研极简 Markdown → HTML（全量转义）
getIcon('Plus');                       // → SVG path d（约 50 个线性图标）
```

---

## 五、依赖说明

- **零第三方 UI 依赖**：无 Element Plus / Ant Design / 自建图标 CDN。
- **vue-router / vue-i18n 为可选**：`TopSearch` 与 `DsAppShell` 通过 `appContext.config.globalProperties` 获取 `$router` / `$route` / `$t`，宿主安装则启用 SPA 导航与翻译，未安装则自动降级（`<a href>` 整页跳转 + 内置中文文案）。构建期不再静态引用这两个包。
- **导出 Excel**：`BaseGrid` / `BaseTable` 的 `exportable` 动态 `import('xlsx')`，宿主未安装时自动降级为 CSV（带 BOM）。
- **PhotoToVideo / TopSearch** 的后端与路由均通过 props 注入 + 默认实现，组件文件夹可独立复用。

---

## 六、演示页

`demo.html` 为纯静态风格指南（按钮 / 表单 / 数据展示 / 导航 / 反馈 / 接入方式六大区块），右上角可切换明暗主题，浏览器直接打开即可预览，无需构建。

---

## 七、质量验证

本目录交付前执行了三套自动化验证（Node + @vue/compiler-sfc + jsdom）：

1. **静态检查**：65 个 SFC 全部通过编译器解析；import 路径全部可解析；无 Element Plus / `el-*` 残留。
2. **运行时挂载**：65/65 组件在 jsdom 中成功渲染（自动填充 props + 驱动交互）。
3. **Scoped 样式命中**：编译全部 scoped 选择器并逐条断言命中真实 DOM；修复了 `DsTree` 因节点由 `h()` 子组件渲染导致整段样式失效的问题（该段已改用 `:deep()` 穿透，并以 17 条选择器全命中复核）。

> 已知设计约束：`DsTree` 含两个 `<style scoped>` 块（第二段面向递归子组件 `DsTreeNode`，必须 `:deep()`）；`ParentView` 为纯模板组件，无脚本块。
