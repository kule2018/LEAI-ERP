<!--
 * 电子签名画板（文档第 32 章：电子签名 / 合同签收签章）。
 * ---------------------------------------------------------------------------
 * 用原生 canvas 手写，输出 base64 PNG，可直接附在审批、签收、合同单据上。
 * 不引入签名库，保持零新依赖；支持鼠标与触摸事件。
 -->
<template>
  <div class="sign-pad">
    <canvas
      ref="canvasRef"
      class="sign-canvas"
      @mousedown="start"
      @mousemove="move"
      @mouseup="end"
      @mouseleave="end"
      @touchstart.prevent="startTouch"
      @touchmove.prevent="moveTouch"
      @touchend="end"
    />
    <div class="sign-tools">
      <span class="sign-tip">请在此处手写签名</span>
      <DsButton size="sm" @click="clear">清除</DsButton>
      <DsButton size="sm" variant="primary" @click="confirm">确认签名</DsButton>
    </div>
  </div>
</template>

<script setup lang="ts">
/** 手写签名：按下开始绘制，抬起结束，确认后输出 base64 */
import { onMounted, ref } from 'vue';

const props = defineProps<{ modelValue?: string }>();
const emit = defineEmits<{ (e: 'update:modelValue', value: string): void; (e: 'confirm', value: string): void }>();

const canvasRef = ref<HTMLCanvasElement | null>(null);
let drawing = false;
let context: CanvasRenderingContext2D | null = null;

/** 初始化画布尺寸与画笔样式 */
onMounted(() => {
  const canvas = canvasRef.value;
  if (!canvas) return;
  canvas.width = canvas.clientWidth * 2;
  canvas.height = canvas.clientHeight * 2;
  context = canvas.getContext('2d');
  if (context) {
    context.scale(2, 2);
    context.lineWidth = 2.5;
    context.lineCap = 'round';
    context.lineJoin = 'round';
    context.strokeStyle = '#1a1d21';
  }
  if (props.modelValue) {
    const image = new Image();
    image.onload = () => context?.drawImage(image, 0, 0, canvas.clientWidth, canvas.clientHeight);
    image.src = props.modelValue;
  }
});

/** 取鼠标在画布内的坐标 */
function point(event: MouseEvent | Touch): { x: number; y: number } {
  const rect = canvasRef.value!.getBoundingClientRect();
  return { x: event.clientX - rect.left, y: event.clientY - rect.top };
}

function start(event: MouseEvent): void {
  drawing = true;
  const p = point(event);
  context?.beginPath();
  context?.moveTo(p.x, p.y);
}
function move(event: MouseEvent): void {
  if (!drawing) return;
  const p = point(event);
  context?.lineTo(p.x, p.y);
  context?.stroke();
}
function startTouch(event: TouchEvent): void {
  drawing = true;
  const p = point(event.touches[0]);
  context?.beginPath();
  context?.moveTo(p.x, p.y);
}
function moveTouch(event: TouchEvent): void {
  if (!drawing) return;
  const p = point(event.touches[0]);
  context?.lineTo(p.x, p.y);
  context?.stroke();
}
function end(): void { drawing = false; }

/** 清空画布 */
function clear(): void {
  const canvas = canvasRef.value;
  if (canvas && context) context.clearRect(0, 0, canvas.clientWidth, canvas.clientHeight);
  emit('update:modelValue', '');
}

/** 导出签名并发事件 */
function confirm(): void {
  const canvas = canvasRef.value;
  if (!canvas) return;
  const value = canvas.toDataURL('image/png');
  emit('update:modelValue', value);
  emit('confirm', value);
}
</script>

<style scoped>
.sign-pad { border: 1px solid var(--ds-border, #e8eaed); border-radius: var(--ds-radius, 10px); overflow: hidden; }
.sign-canvas { width: 100%; height: 180px; display: block; background: #fff; cursor: crosshair; touch-action: none; }
.sign-tools { display: flex; align-items: center; gap: 8px; padding: 8px 12px; background: var(--ds-bg-soft, #f7f8fa); border-top: 1px solid var(--ds-border, #e8eaed); }
.sign-tip { flex: 1; font-size: 12px; color: var(--ds-text-3, #8a9099); }
</style>
