<!--
 * StatCard 统计卡片组件（DeepSeek UI 版）
 * 职责：用于 Dashboard 数据概览，展示指标标题、数值（支持前后缀）、图标、以及同比/环比趋势，
 *       加载时展示骨架屏。颜色遵循中国习惯：涨为红、跌为绿。
 * 与旧版区别：基于 ds 设计令牌自绘，不再依赖 Element Plus 卡片 / 图标 / 骨架屏。
 * 页面位置 / 用途：作为数据看板顶部概览卡片。
 * 核心 props：title 标题、value 数值、icon ds 图标名、color 图标主题色、trend 涨跌幅百分比、
 *            sub 趋势副文案、prefix 数值前缀、suffix 数值后缀、loading 加载态。
 -->
<template>
  <!-- 统计卡片：用于 Dashboard 数据概览 -->
  <div class="stat-card" :class="{ 'is-loading': loading }">
    <!-- 加载态：骨架屏占位 -->
    <div v-if="loading" class="stat-card__skeleton">
      <span class="stat-card__sk-title" />
      <span class="stat-card__sk-value" />
      <span class="stat-card__sk-trend" />
    </div>

    <template v-else>
      <div class="stat-card__main">
        <!-- 图标区：color 主题色 + 12% 透明度背景；icon 为空时不渲染 -->
        <div v-if="icon" class="stat-card__icon" :style="{ background: color + '1f', color }">
          <svg viewBox="0 0 24 24" aria-hidden="true"><path :d="iconD" /></svg>
        </div>
        <div class="stat-card__content">
          <!-- 指标标题 -->
          <div class="stat-card__title">{{ title }}</div>
          <div class="stat-card__value">
            <!-- 数值前缀（如 ¥） -->
            <span v-if="prefix" class="stat-card__affix">{{ prefix }}</span>
            <!-- 主数值（等宽数字，刷新不抖动） -->
            <span class="stat-card__num">{{ value }}</span>
            <!-- 数值后缀（如 %） -->
            <span v-if="suffix" class="stat-card__affix">{{ suffix }}</span>
          </div>
        </div>
      </div>
      <!-- 底部说明：有趋势时展示涨跌，仅有 sub 时只展示副文案 -->
      <div v-if="trend !== undefined || sub" class="stat-card__footer">
        <!-- 涨跌幅：trend >= 0 标红（涨），否则标绿（跌），并展示绝对值百分比 -->
        <span v-if="trend !== undefined" :class="['stat-card__trend', trend >= 0 ? 'is-up' : 'is-down']">
          <svg viewBox="0 0 24 24" aria-hidden="true">
            <path :d="trend >= 0 ? 'm6 15 6-6 6 6' : 'm6 9 6 6 6-6'" />
          </svg>
          {{ Math.abs(trend) }}%
        </span>
        <!-- 趋势副文案，如「较昨日」 -->
        <span class="stat-card__sub">{{ sub }}</span>
      </div>
    </template>
  </div>
</template>

<script setup lang="ts">
// computed 派生图标 path；getIcon 从 ds 图标字典取 path
import { computed } from "vue";
import { getIcon } from "./ds/icons";

const props = withDefaults(
  defineProps<{
    /** 标题 */
    title?: string;
    /** 数值 */
    value?: string | number;
    /** ds 图标名，如 'User' / 'File' */
    icon?: string;
    /** 图标主题色（CSS 颜色） */
    color?: string;
    /** 同比/环比百分比，正红负绿（按中国习惯涨跌色） */
    trend?: number;
    /** 趋势副文案 */
    sub?: string;
    /** 数值前缀，如 ¥ */
    prefix?: string;
    /** 数值后缀，如 % */
    suffix?: string;
    /** 加载态：显示骨架屏 */
    loading?: boolean;
  }>(),
  { color: "var(--ds-brand)", sub: "较昨日", loading: false }
);

/**
 * 图标 path 解析。
 * @returns SVG path 的 d 属性
 */
const iconD = computed(() => getIcon(props.icon));
</script>

<style scoped>
.stat-card {
  background: var(--ds-bg-elevated);
  border: 1px solid var(--ds-border);
  border-radius: var(--ds-radius-lg);
  padding: 16px 18px;
  display: flex;
  flex-direction: column;
  gap: 10px;
  transition: box-shadow var(--ds-dur) var(--ds-ease), border-color var(--ds-dur) var(--ds-ease);
}
.stat-card:hover { box-shadow: var(--ds-shadow-sm); border-color: var(--ds-border-strong); }

.stat-card__main { display: flex; align-items: center; gap: 14px; }
.stat-card__icon {
  width: 44px;
  height: 44px;
  flex: none;
  border-radius: var(--ds-radius-md);
  display: grid;
  place-items: center;
}
.stat-card__icon svg {
  width: 22px;
  height: 22px;
  fill: none;
  stroke: currentColor;
  stroke-width: 1.8;
  stroke-linecap: round;
  stroke-linejoin: round;
}

.stat-card__content { flex: 1; min-width: 0; }
.stat-card__title { font-size: var(--ds-font-sm); color: var(--ds-text-3); }
.stat-card__value {
  margin-top: 4px;
  display: flex;
  align-items: baseline;
  gap: 2px;
  color: var(--ds-text);
}
.stat-card__num {
  font-size: 24px;
  font-weight: 650;
  line-height: 1.2;
  font-variant-numeric: tabular-nums;
  letter-spacing: -0.01em;
}
.stat-card__affix { font-size: var(--ds-font-lg); font-weight: 500; color: var(--ds-text-2); }

.stat-card__footer {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: var(--ds-font-xs);
}
.stat-card__trend {
  display: inline-flex;
  align-items: center;
  gap: 2px;
  font-weight: 600;
  font-variant-numeric: tabular-nums;
}
.stat-card__trend svg {
  width: 12px;
  height: 12px;
  fill: none;
  stroke: currentColor;
  stroke-width: 2.4;
  stroke-linecap: round;
  stroke-linejoin: round;
}
.stat-card__trend.is-up { color: var(--ds-up); } /* 涨 = 红 */
.stat-card__trend.is-down { color: var(--ds-down); } /* 跌 = 绿 */
.stat-card__sub { color: var(--ds-text-3); }

/* ---- 骨架屏 ---- */
.stat-card__skeleton { display: flex; flex-direction: column; gap: 10px; }
.stat-card__sk-title,
.stat-card__sk-value,
.stat-card__sk-trend {
  border-radius: var(--ds-radius-xs);
  background: var(--ds-bg-skeleton);
  animation: ds-skel-breathe 1.6s ease-in-out infinite;
}
.stat-card__sk-title { width: 40%; height: 13px; }
.stat-card__sk-value { width: 60%; height: 24px; }
.stat-card__sk-trend { width: 30%; height: 12px; }
@keyframes ds-skel-breathe {
  0%, 100% { opacity: 1; }
  50% { opacity: 0.45; }
}
</style>
