<!--
 * Tbar 顶部操作栏组件（DeepSeek UI 版）
 * 职责：页面级标题栏，左侧放标题与 left 插槽内容、右侧放 right 插槽操作区，可选底部分隔线，
 *       统一各页面顶部操作区的布局与间距。
 * 与旧版区别：基于 ds 设计令牌自绘，间距 / 字号与 DsAppShell 顶栏一致。
 * 页面位置 / 用途：作为页面基础布局积木，通常放在页面内容最上方。
 * 核心 props：title 左侧主标题、bordered 是否显示底部分隔线。
 * 插槽：left 标题左侧扩展内容、right 右侧操作区（按钮等）。
 -->
<template>
  <!-- 顶部操作栏：页面级标题 + 右侧操作区 -->
  <div class="tbar" :class="{ 'tbar--bordered': bordered }">
    <div class="tbar__left">
      <!-- 左侧扩展插槽（如图标、面包屑） -->
      <slot name="left" />
      <!-- 主标题：有 title 时显示 -->
      <span v-if="title" class="tbar__title">{{ title }}</span>
    </div>
    <div class="tbar__right">
      <!-- 右侧操作区插槽（按钮、筛选器等） -->
      <slot name="right" />
    </div>
  </div>
</template>

<script setup lang="ts">
defineProps<{
  /** 左侧主标题 */
  title?: string;
  /** 是否显示底部分隔线 */
  bordered?: boolean;
}>();
</script>

<style scoped>
.tbar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  min-height: 44px;
  margin-bottom: var(--ds-space-3);
}
.tbar--bordered {
  padding-bottom: var(--ds-space-3);
  border-bottom: 1px solid var(--ds-divider);
}
.tbar__left {
  display: flex;
  align-items: center;
  gap: var(--ds-space-2);
  min-width: 0;
}
.tbar__title {
  font-weight: 600;
  font-size: var(--ds-font-lg);
  color: var(--ds-text);
  letter-spacing: -0.01em;
}
.tbar__right {
  display: flex;
  align-items: center;
  gap: var(--ds-space-2);
  flex: none;
}
</style>
