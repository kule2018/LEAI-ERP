<!--
 * TopSearch 顶部导航搜索组件（DeepSeek UI 版）
 * 职责：在后台顶栏提供全局菜单搜索能力，支持本地搜索历史、按分组分类筛选、关键词高亮、键盘上下选择、回车跳转。
 * 与旧版区别：
 *   1) 视觉全面切换为 ds 设计令牌（输入框 / 浮层 / 标签 / 高亮）；
 *   2) 路由表通过 routes prop 注入（不再强依赖 ../router/routes 静态路径），组件可独立使用；
 *   3) i18n 与 vue-router 均做容错：经 appContext 全局属性可选获取，宿主未安装时自动降级
 *      （t 回落内置中文文案，跳转走 navigate 事件）。
 * 在页面中的位置/用途：通常固定在顶栏（Header）右侧，用于根据路由菜单标题快速定位并跳转到对应页面。
 * 依赖的核心 props：routes 路由表（RouteRecordRaw[]）、historyEnabled（是否启用本地历史）、placeholder（自定义占位符）。
 * 依赖的核心 emits：navigate（携带路由 name，宿主自行决定跳转方式；有 router 时已自动 push）。
 -->
<template>
  <div ref="root" class="top-search">
    <!-- 输入框：前缀搜索图标 + 可清空 -->
    <div class="top-search__box">
      <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M11 19a8 8 0 1 0 0-16 8 8 0 0 0 0 16Zm10 2-4.35-4.35" /></svg>
      <input
        v-model="keyword"
        type="text"
        class="top-search__input"
        :placeholder="placeholder || t('topSearch.placeholder')"
        @focus="onFocus"
        @blur="onBlur"
        @keydown="onKeydown"
      />
      <button v-if="keyword" type="button" class="top-search__clear" title="清空" @click="keyword = ''">✕</button>
    </div>

    <!-- 下拉面板：历史记录 / 分类 + 结果 -->
    <div v-if="showPanel" class="top-search__panel" @mousedown.prevent>
      <!-- 分支一：关键词为空时，展示历史记录（或空态） -->
      <template v-if="!keyword.trim()">
        <div v-if="historyEnabled && history.length" class="top-search__history">
          <div class="top-search__row">
            <span class="top-search__label">{{ t('topSearch.history') }}</span>
            <button type="button" class="top-search__link" @click="clearHistory">
              {{ t('topSearch.clearHistory') }}
            </button>
          </div>
          <div class="top-search__tags">
            <!-- 历史标签：点击回填关键词并触发搜索 -->
            <span v-for="(h, i) in history" :key="i" class="top-search__tag" @click="applyHistory(h)">{{ h }}</span>
          </div>
        </div>
        <div v-else-if="historyEnabled" class="top-search__empty">{{ t('topSearch.noHistory') }}</div>
      </template>

      <!-- 分支二：有输入关键词时，展示分类切换条 + 匹配结果列表 -->
      <template v-else>
        <div class="top-search__cats">
          <span
            v-for="cat in categories"
            :key="cat"
            class="top-search__cat"
            :class="{ active: activeCategory === cat }"
            @click="activeCategory = cat"
          >
            {{ catLabel(cat) }}
          </span>
        </div>

        <div class="top-search__results">
          <div
            v-for="(item, i) in results"
            :key="item.key"
            class="top-search__item"
            :class="{ active: i === activeIndex }"
            @mouseenter="activeIndex = i"
            @click="select(item)"
          >
            <!-- 标题：highlight 处理后高亮匹配片段（已转义，安全 v-html） -->
            <div class="top-search__item-title" v-html="highlight(item.title, keyword)"></div>
            <!-- 业务结果显示摘要，菜单结果只显示分组 -->
            <div v-if="item.description" class="top-search__item-desc">{{ item.description }}</div>
            <div class="top-search__item-group">{{ item.group }}</div>
          </div>
          <div v-if="!results.length" class="top-search__empty">{{ t('topSearch.noResult') }}</div>
        </div>
      </template>
    </div>
  </div>
</template>

<script setup lang="ts">
// ref/computed/watch/nextTick 状态与派生；路由类型仅作类型标注（import type 不产生运行时依赖）
// vue-router / vue-i18n 均通过 appContext 全局属性可选获取，宿主未安装时自动降级
import { ref, computed, watch, nextTick, getCurrentInstance } from "vue";
import type { RouteRecordRaw } from "vue-router";

const props = withDefaults(
  defineProps<{
    /** 路由表（构建静态搜索索引的数据来源；宿主未提供时搜索为空） */
    routes?: RouteRecordRaw[];
    /** 是否启用本地搜索历史（默认 true） */
    historyEnabled?: boolean;
    /** 自定义占位符（默认读取 i18n topSearch.placeholder） */
    placeholder?: string;
    /** 远程业务搜索（可选）：返回带 link 的实体结果，与菜单结果合并展示 */
    remote?: (q: string) => Promise<any[]>;
  }>(),
  { routes: () => [], historyEnabled: true }
);

/** 事件：选中结果（宿主可用其自行跳转；内部已尝试 router.push） */
const emit = defineEmits<{ (e: "navigate", name: string): void }>();

/* ---- 可选依赖容错：宿主未安装 vue-i18n / vue-router 时降级 ---- */

/** 内置中文文案（无 i18n 时的默认显示，避免直接把 key 抛给用户） */
const DEFAULT_TEXTS: Record<string, string> = {
  "topSearch.placeholder": "搜索菜单",
  "topSearch.history": "搜索历史",
  "topSearch.clearHistory": "清空",
  "topSearch.noHistory": "暂无搜索历史",
  "topSearch.noResult": "无匹配结果",
};

/**
 * 翻译函数（三级解析）。
 * 思路：优先取全局 $t（宿主以 i18n 传统模式注册时存在）；
 *       其次用内置中文默认；最后原样返回 key。
 * @param key 文案 key
 * @returns 最终展示文案
 */
const t = (key: string): string => {
  const gp = getCurrentInstance()?.appContext.config.globalProperties as Record<string, any> | undefined;
  if (gp?.$t) {
    const v = gp.$t(key);
    if (v && v !== key) return String(v);
  }
  return DEFAULT_TEXTS[key] ?? key;
};

/**
 * 路由实例：取全局 $router（宿主安装 vue-router 时由 app.use(router) 注册）。
 * @returns 路由实例或 undefined（未安装时跳转交由 navigate 事件兜底）
 */
const router = getCurrentInstance()?.appContext.config.globalProperties?.$router as
  | { push: (to: any) => Promise<unknown> }
  | undefined;

/** 菜单搜索索引项 */
interface MenuIndexItem {
  /** 路由名（用于跳转） */
  name: string;
  /** 标题 i18n key */
  titleKey: string;
  /** 所属分组 key */
  groupKey?: string;
}

/**
 * 递归遍历路由表，收集带 meta.title 的叶子菜单作为可搜索项。
 * @param list 路由列表
 * @param groupKey 上层分组 key
 * @returns 索引项数组
 */
function buildMenuIndex(list: RouteRecordRaw[], groupKey?: string): MenuIndexItem[] {
  const out: MenuIndexItem[] = [];
  for (const r of list) {
    const titleKey = r.meta?.title as string | undefined;
    if (r.children?.length) {
      out.push(...buildMenuIndex(r.children, titleKey || groupKey));
    } else if (titleKey && r.name) {
      out.push({ name: String(r.name), titleKey, groupKey });
    }
  }
  return out;
}

/** 菜单索引：随 routes prop 变化重建 */
const menuIndex = computed(() => buildMenuIndex(props.routes));

/** 远程业务搜索结果 */
const remoteHits = ref<any[]>([]);

/** 菜单项与业务实体合并后的统一展示结构 */
interface DisplayItem {
  key: string;
  title: string;
  group: string;
  description?: string;
  link?: string;
  name?: string;
}



// fallback：菜单项无分组 key 时的默认分组显示名
const fallback = "主导航";
// HISTORY_KEY：本地历史存储键名
const HISTORY_KEY = "pc_search_history";
// HISTORY_MAX：历史最多保留条数
const HISTORY_MAX = 10;

// keyword：当前输入的关键词
const keyword = ref("");

/** 防抖远程搜索：菜单结果即时，业务实体 250ms 后异步补充 */
let remoteTimer: ReturnType<typeof setTimeout> | null = null;
watch(keyword, (kw) => {
  const value = kw.trim();
  if (!props.remote || !value) {
    remoteHits.value = [];
    return;
  }
  if (remoteTimer) clearTimeout(remoteTimer);
  remoteTimer = setTimeout(async () => {
    try {
      remoteHits.value = await props.remote!(value);
    } catch {
      remoteHits.value = [];
    }
  }, 250);
});
// showPanel：下拉面板是否展开
const showPanel = ref(false);
// activeCategory：当前分类筛选
const activeCategory = ref("全部");
// activeIndex：键盘 / 鼠标高亮项下标
const activeIndex = ref(0);
// history：本地搜索历史
const history = ref<string[]>(loadHistory());
// root：根元素引用
const root = ref<HTMLElement>();
void root.value;
// inputRef：输入框引用（编程式聚焦）
const inputRef = ref<HTMLInputElement | null>(null);

/**
 * 读取本地搜索历史。
 * @returns 历史数组
 */
function loadHistory(): string[] {
  if (!props.historyEnabled) return [];
  try {
    const raw = localStorage.getItem(HISTORY_KEY);
    return raw ? (JSON.parse(raw) as string[]) : [];
  } catch {
    return [];
  }
}

/**
 * 写入本地搜索历史（去重 + 置顶 + 截断）。
 * @param list 历史列表
 * @returns 无
 */
function saveHistory(list: string[]): void {
  if (!props.historyEnabled) return;
  history.value = list.slice(0, HISTORY_MAX);
  try {
    localStorage.setItem(HISTORY_KEY, JSON.stringify(history.value));
  } catch {
    /* 隐私模式：不持久化但不报错 */
  }
}

/**
 * 记录关键词到历史。
 * @param kw 关键词
 * @returns 无
 */
function pushHistory(kw: string): void {
  const v = kw.trim();
  if (!v || !props.historyEnabled) return;
  saveHistory([v, ...history.value.filter((h) => h !== v)]);
}

/** 分类选项：全部 + 各菜单分组 */
const categories = computed(() => {
  const set = new Set<string>();
  menuIndex.value.forEach((i) => set.add(i.groupKey || fallback));
  remoteHits.value.forEach((h) => set.add(h.typeLabel || "业务实体"));
  return ["全部", ...Array.from(set)];
});

/**
 * 分类展示文案。
 * @param cat 分类 key
 * @returns 文案
 */
function catLabel(cat: string): string {
  if (cat === "全部") return t("topSearch.all");
  return cat === fallback ? fallback : t(cat);
}

/** 结果列表：远程业务实体优先，其后为匹配的菜单项；统一结构供模板与键盘交互使用 */
const results = computed<DisplayItem[]>(() => {
  const kw = keyword.value.trim().toLowerCase();
  if (!kw) return [];
  const menu: DisplayItem[] = menuIndex.value
    .filter((item) => {
      const title = t(item.titleKey).toLowerCase();
      const group = item.groupKey ? t(item.groupKey).toLowerCase() : "";
      const cat = item.groupKey || fallback;
      return (
        (title.includes(kw) || group.includes(kw)) &&
        (activeCategory.value === "全部" || cat === activeCategory.value)
      );
    })
    .map((item) => ({
      key: `menu:${item.name}`,
      title: t(item.titleKey),
      group: item.groupKey ? t(item.groupKey) : fallback,
      name: item.name,
    }));
  const remote: DisplayItem[] = remoteHits.value
    .filter((hit) => activeCategory.value === "全部" || (hit.typeLabel || "业务实体") === activeCategory.value)
    .map((hit, i) => ({
      key: `${hit.type || "biz"}:${hit.id || 0}:${i}`,
      title: hit.title || "未命名",
      group: hit.typeLabel || "业务实体",
      description: hit.description || "",
      link: hit.link,
    }));
  return [...remote, ...menu];
});

// 关键词或分类变化后，重置高亮项到首项
watch([results, activeCategory], () => {
  activeIndex.value = 0;
});

/**
 * 转义正则特殊字符，防止用户输入破坏高亮正则。
 * @param s 原始串
 * @returns 转义后
 */
function escapeRegExp(s: string): string {
  return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

/**
 * 转义 HTML，避免 v-html 注入。
 * @param s 原始串
 * @returns 转义后
 */
function escapeHtml(s: string): string {
  return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

/**
 * 标题中高亮匹配片段（先转义再包裹 <mark>，安全）。
 * @param text 标题
 * @param kw 关键词
 * @returns 带 <mark> 的 HTML
 */
function highlight(text: string, kw: string): string {
  const safe = escapeHtml(text);
  const k = kw.trim();
  if (!k) return safe;
  const re = new RegExp(`(${escapeRegExp(escapeHtml(k))})`, "ig");
  return safe.replace(re, "<mark>$1</mark>");
}

/**
 * 选中某条结果：记历史 + 跳转 + 收起面板。
 * @param item 索引项
 * @returns 无
 */
function select(item: DisplayItem): void {
  pushHistory(keyword.value);
  showPanel.value = false;
  inputRef.value?.blur();
  // 业务实体按 link 跳转（可带参数）；菜单项按 name 跳转
  try {
    if (item.link) void router?.push(item.link)?.catch(() => {});
    else if (item.name) void router?.push({ name: item.name })?.catch(() => {});
  } catch {
    /* 同步异常静默，交由事件消费方兜底 */
  }
  emit("navigate", item.name || item.link || "");
}

/**
 * 点击历史标签：回填关键词并触发搜索。
 * @param h 历史词
 * @returns 无
 */
function applyHistory(h: string): void {
  keyword.value = h;
  activeCategory.value = "全部";
  void nextTick(() => inputRef.value?.focus());
}

/** 清空历史 */
function clearHistory(): void {
  saveHistory([]);
}

/** 输入框获得焦点：展开面板 */
function onFocus(): void {
  showPanel.value = true;
}

/** 输入框失去焦点：延迟收起（mousedown.prevent 已阻止面板内点击失焦） */
function onBlur(): void {
  setTimeout(() => (showPanel.value = false), 150);
}

/** 键盘交互：↑/↓ 移动高亮，Enter 选中，Esc 关闭 */
function onKeydown(e: KeyboardEvent): void {
  if (e.key === "ArrowDown") {
    e.preventDefault();
    if (results.value.length) activeIndex.value = (activeIndex.value + 1) % results.value.length;
  } else if (e.key === "ArrowUp") {
    e.preventDefault();
    if (results.value.length)
      activeIndex.value = (activeIndex.value - 1 + results.value.length) % results.value.length;
  } else if (e.key === "Enter") {
    const item = results.value[activeIndex.value];
    if (item) select(item);
  } else if (e.key === "Escape") {
    showPanel.value = false;
    inputRef.value?.blur();
  }
}
</script>

<style scoped>
/* 根容器：相对定位，作为下拉面板的定位上下文 */
.top-search { position: relative; width: 320px; }

/* 输入框 */
.top-search__box {
  display: flex;
  align-items: center;
  gap: 8px;
  height: var(--ds-ctl-h-md);
  padding: 0 12px;
  background: var(--ds-bg-elevated);
  border: 1px solid var(--ds-border);
  border-radius: var(--ds-radius-full);
  transition: border-color var(--ds-dur-fast) var(--ds-ease), box-shadow var(--ds-dur-fast) var(--ds-ease);
}
.top-search__box:focus-within { border-color: var(--ds-brand); box-shadow: 0 0 0 3px var(--ds-brand-soft); }
.top-search__box svg {
  width: 15px; height: 15px; flex: none;
  fill: none; stroke: var(--ds-text-3); stroke-width: 2; stroke-linecap: round;
}
.top-search__input {
  flex: 1; min-width: 0;
  border: 0; outline: none; background: transparent;
  color: var(--ds-text); font-size: var(--ds-font-sm); font-family: inherit;
}
.top-search__input::placeholder { color: var(--ds-text-3); }
.top-search__clear {
  border: 0; background: transparent; color: var(--ds-text-3);
  cursor: pointer; font-size: var(--ds-font-xs); padding: 2px; border-radius: 50%;
}
.top-search__clear:hover { background: var(--ds-bg-hover); color: var(--ds-text); }

/* 下拉面板 */
.top-search__panel {
  position: absolute;
  top: calc(100% + 8px);
  left: 0; right: 0;
  z-index: 2000;
  padding: 10px;
  background: var(--ds-bg-elevated);
  border: 1px solid var(--ds-border);
  border-radius: var(--ds-radius);
  box-shadow: var(--ds-shadow-md);
  max-height: 420px;
  overflow: auto;
}

.top-search__row {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 8px;
}
.top-search__label { font-size: var(--ds-font-xs); color: var(--ds-text-3); }
.top-search__link {
  border: 0; background: transparent;
  color: var(--ds-brand); font-size: var(--ds-font-xs);
  cursor: pointer; padding: 2px 4px; border-radius: var(--ds-radius-xs);
}
.top-search__link:hover { background: var(--ds-brand-soft); }

/* 历史标签 */
.top-search__tags { display: flex; flex-wrap: wrap; gap: 6px; }
.top-search__tag {
  padding: 2px 10px;
  border-radius: var(--ds-radius-full);
  background: var(--ds-bg-hover);
  color: var(--ds-text-2);
  font-size: var(--ds-font-xs);
  cursor: pointer;
  transition: background var(--ds-dur-fast) var(--ds-ease), color var(--ds-dur-fast) var(--ds-ease);
}
.top-search__tag:hover { background: var(--ds-brand-soft); color: var(--ds-brand); }

/* 分类条 */
.top-search__cats {
  display: flex; flex-wrap: wrap; gap: 6px;
  margin-bottom: 8px; padding-bottom: 8px;
  border-bottom: 1px solid var(--ds-divider);
}
.top-search__cat {
  font-size: var(--ds-font-xs);
  padding: 2px 10px;
  border-radius: var(--ds-radius-full);
  cursor: pointer;
  color: var(--ds-text-2);
  background: var(--ds-bg-hover);
  transition: all var(--ds-dur-fast) var(--ds-ease);
}
.top-search__cat:hover { color: var(--ds-text); }
.top-search__cat.active { color: #fff; background: var(--ds-brand); }

/* 结果项 */
.top-search__item {
  padding: 8px 10px;
  border-radius: var(--ds-radius-xs);
  cursor: pointer;
  transition: background var(--ds-dur-fast) var(--ds-ease);
}
.top-search__item.active { background: var(--ds-bg-hover); }
.top-search__item-title { font-size: var(--ds-font-sm); color: var(--ds-text); line-height: 1.5; }
/* 高亮 <mark>：品牌色加粗 */
.top-search__item-title :deep(mark) {
  background: transparent;
  color: var(--ds-brand);
  font-weight: 700;
}
.top-search__item-desc {
  font-size: var(--ds-font-xs); color: var(--ds-text-2);
  line-height: 1.5; margin-top: 2px;
  overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
}
.top-search__item-group { font-size: var(--ds-font-xs); color: var(--ds-text-3); margin-top: 2px; }

/* 空态 */
.top-search__empty {
  text-align: center;
  color: var(--ds-text-3);
  font-size: var(--ds-font-xs);
  padding: 16px 0;
}
</style>
