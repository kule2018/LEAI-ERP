<!--
 * 我的视图配置（文档第 24 章：列表配置化）。
 * ---------------------------------------------------------------------------
 * 列显隐、列顺序、行密度、每页条数按「路由 + 角色」保存，
 * 下次进入同一列表自动恢复。配置同时写入本地存储与 mock 接口。
 -->
<template>
  <DsDrawer v-model="visible" title="我的视图配置" :size="380">
    <div class="view-cfg">
      <p class="view-hint">配置只影响你自己的列表视图，按当前页面自动保存。</p>
      <b>显示的列</b>
      <div class="view-cols">
        <label v-for="col in localColumns" :key="col.prop" class="view-col">
          <input v-model="col.visible" type="checkbox" /> <span>{{ col.label }}</span>
          <small class="view-order">
            <button type="button" @click="move(col, -1)">↑</button>
            <button type="button" @click="move(col, 1)">↓</button>
          </small>
        </label>
      </div>
      <b>行密度</b>
      <div class="view-row">
        <DsSegmented v-model="density" :options="[{ label: '宽松', value: 'default' }, { label: '紧凑', value: 'compact' }]" />
      </div>
      <b>每页条数</b>
      <div class="view-row">
        <select v-model="pageSize" class="ds-select">
          <option v-for="n in [10, 20, 50, 100]" :key="n" :value="n">{{ n }} 条 / 页</option>
        </select>
      </div>
    </div>
    <template #footer>
      <div class="view-foot"><DsButton @click="visible = false">取消</DsButton><DsButton variant="primary" @click="save">保存视图</DsButton></div>
    </template>
  </DsDrawer>
</template>

<script setup lang="ts">
/** 列表视图配置：本地即时生效，后端留痕 */
import { reactive, ref, watch } from 'vue';
import { useRoute } from 'vue-router';
import { mockPost } from '../api/mockAdapter';
import { useToast } from '../components/ds/toast';

interface ColumnOption { label: string; prop: string; visible: boolean }

const props = defineProps<{ modelValue: boolean; columns: Array<{ label: string; prop: string }> }>();
const emit = defineEmits<{ (e: 'update:modelValue', value: boolean): void; (e: 'apply', config: any): void }>();
const route = useRoute();
const toast = useToast();

/** 抽屉显示状态，同步 v-model */
const visible = ref(props.modelValue);
watch(() => props.modelValue, (v) => { if (v) load(); visible.value = v; });
watch(visible, (v) => emit('update:modelValue', v));

const localColumns = reactive<ColumnOption[]>([]);
const density = ref<string>('default');
const pageSize = ref(20);

/** 当前页面的存储键 */
function storageKey(): string { return 'erp_view_' + route.path.replace(/\//g, '_'); }

/** 加载已保存配置 */
function load(): void {
  localColumns.splice(0, localColumns.length, ...props.columns.map((c) => ({ ...c, visible: true })));
  try {
    const saved = JSON.parse(localStorage.getItem(storageKey()) || 'null');
    if (!saved) return;
    density.value = saved.density || 'default';
    pageSize.value = saved.pageSize || 20;
    for (const col of localColumns) {
      const hit = saved.columns?.find((c: any) => c.prop === col.prop);
      if (hit) col.visible = hit.visible;
    }
    if (saved.columns?.length) {
      const order = saved.columns.map((c: any) => c.prop);
      localColumns.sort((a, b) => order.indexOf(a.prop) - order.indexOf(b.prop));
    }
  } catch { /* 配置损坏时使用默认值 */ }
}

/** 调整列顺序 */
function move(col: ColumnOption, step: number): void {
  const index = localColumns.indexOf(col);
  const target = index + step;
  if (index < 0 || target < 0 || target >= localColumns.length) return;
  localColumns.splice(index, 1);
  localColumns.splice(target, 0, col);
}

/** 保存配置并通知列表页应用 */
async function save(): Promise<void> {
  const config = { columns: localColumns.map((c) => ({ prop: c.prop, visible: c.visible })), density: density.value, pageSize: pageSize.value };
  localStorage.setItem(storageKey(), JSON.stringify(config));
  await mockPost('/api/v1/ux/view-configs', { route: route.path, ...config });
  toast.success('视图配置已保存');
  emit('apply', config);
  visible.value = false;
}
</script>

<style scoped>
.view-cfg { padding: 4px 8px; }
.view-hint { color: var(--ds-text-3); font-size: 12px; margin: 0 0 16px; }
.view-cfg b { display: block; font-size: 13px; margin: 16px 0 8px; }
.view-cols { display: flex; flex-direction: column; gap: 6px; }
.view-col { display: flex; align-items: center; gap: 8px; font-size: 13px; padding: 5px 0; }
.view-col span { flex: 1; }
.view-order button { border: none; background: none; cursor: pointer; color: var(--ds-text-3); }
.view-row .ds-select { width: 100%; }
.view-foot { display: flex; justify-content: flex-end; gap: 8px; }
</style>
