<!--
 * 虚拟滚动表格（文档第 24 章：万行虚拟表格）。
 * ---------------------------------------------------------------------------
 * 只渲染可视区内的行，上下用空白占位撑开滚动条，DOM 节点数始终可控。
 * 约定：行高固定；列通过 columns 配置，也支持 #cell 插槽自定义渲染。
 -->
<template>
  <div ref="viewport" class="virtual-table" :style="{ height: height + 'px' }" @scroll="onScroll">
    <div class="virtual-inner" :style="{ height: totalHeight + 'px' }">
      <div class="virtual-rows" :style="{ transform: `translateY(${offsetY}px)` }">
        <div v-for="row in visibleRows" :key="row.__index" class="virtual-row" :class="{ 'is-compact': density === 'compact' }" :style="{ height: rowHeight + 'px' }">
          <div v-for="col in columns" :key="col.prop" class="virtual-cell" :style="col.width ? { width: col.width + 'px', flex: 'none' } : { flex: 1 }">
            <slot name="cell" :row="row.data" :column="col">{{ row.data[col.prop] }}</slot>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
/** 虚拟表格：根据滚动位置计算可见区间 */
import { computed, onMounted, ref, watch } from 'vue';

interface Column { label: string; prop: string; width?: number }

const props = withDefaults(defineProps<{
  rows: any[];
  columns: Column[];
  height?: number;
  rowHeight?: number;
  density?: 'default' | 'compact';
}>(), { height: 420, rowHeight: 42, density: 'default' });

const viewport = ref<HTMLElement | null>(null);
const scrollTop = ref(0);
const buffer = 6;
const totalHeight = computed(() => props.rows.length * props.rowHeight);

/** 可见行的起止下标，前后多渲染几行避免滚动白屏 */
const startIndex = computed(() => Math.max(0, Math.floor(scrollTop.value / props.rowHeight) - buffer));
const endIndex = computed(() => Math.min(props.rows.length, Math.ceil((scrollTop.value + props.height) / props.rowHeight) + buffer));
const offsetY = computed(() => startIndex.value * props.rowHeight);
const visibleRows = computed(() => props.rows.slice(startIndex.value, endIndex.value).map((data, i) => ({ data, __index: startIndex.value + i })));

/** 滚动时只更新一个数字，避免整表重算 */
function onScroll(event: Event): void {
  scrollTop.value = (event.target as HTMLElement).scrollTop;
}

/** 数据变化时回到顶部 */
watch(() => props.rows.length, () => {
  scrollTop.value = 0;
  if (viewport.value) viewport.value.scrollTop = 0;
});

onMounted(() => { /* 初次渲染时 scrollTop 已是 0，无需额外处理 */ });
</script>

<style scoped>
.virtual-table { overflow-y: auto; border: 1px solid var(--ds-border, #e8eaed); border-radius: var(--ds-radius, 10px); background: var(--ds-bg-elevated, #fff); }
.virtual-inner { position: relative; }
.virtual-rows { position: absolute; left: 0; right: 0; top: 0; }
.virtual-row { display: flex; align-items: center; border-bottom: 1px solid var(--ds-divider, #f0f1f3); box-sizing: border-box; }
.virtual-row:hover { background: var(--ds-bg-hover, #f7f8fa); }
.virtual-cell { flex: 1; min-width: 0; padding: 0 12px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; font-size: 13px; }
.is-compact .virtual-cell { font-size: 12px; }
</style>
