<template>
  <div class="wf-node" :class="[`wf-node--${type}`, state ? `is-${state}` : '']">
    <Handle type="target" :position="Position.Left" />
    <div class="wf-node__type">{{ typeLabel }}</div>
    <div class="wf-node__title">{{ label }}</div>
    <div v-if="detail" class="wf-node__detail">{{ detail }}</div>
    <div v-if="state" class="wf-node__state">{{ stateLabel }}</div>
    <Handle type="source" :position="Position.Right" />
  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import { Handle, Position } from '@vue-flow/core'

const props = withDefaults(defineProps<{
  props: { id: string; data: Record<string, any>; type?: string }
  state?: string
}>(), { state: '' })

const type = computed(() => props.props.type || 'node')
const label = computed(() => String(props.props.data?.label || props.props.id))
const typeLabel = computed(() => ({
  start: '开始', agent: 'Agent', knowledge: '知识库', tool: '工具', condition: '条件', end: '结束',
}[type.value] || type.value))
const detail = computed(() => {
  const d = props.props.data || {}
  if (type.value === 'agent') return String(d.model || '')
  if (type.value === 'knowledge') return `TopK ${d.topK || 5}`
  if (type.value === 'tool') return String(d.tool || '')
  if (type.value === 'condition') return String(d.expression || '')
  return ''
})
const stateLabel = computed(() => ({
  running: '执行中', success: '成功', failed: '失败', pending: '等待中',
}[props.state] || props.state))
</script>

<style scoped>
.wf-node {
  min-width: 150px; max-width: 210px; padding: 10px 12px; border-radius: 10px;
  border: 1px solid var(--ds-border-strong); background: var(--ds-bg-elevated);
  box-shadow: var(--ds-shadow-sm); position: relative;
}
.wf-node__type { font-size: 10px; color: var(--ds-brand); letter-spacing: .08em; text-transform: uppercase; }
.wf-node__title { font-size: 13px; font-weight: 600; margin-top: 4px; }
.wf-node__detail { font-size: 11px; color: var(--ds-text-3); margin-top: 4px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.wf-node__state {
  position: absolute;
  top: -9px;
  right: 8px;
  font-size: 10px;
  padding: 1px 6px;
  border-radius: 99px;
  background: var(--ds-brand-soft);
  color: var(--ds-brand)
}
.wf-node.is-success { border-color: var(--ds-success); }
.wf-node.is-running { border-color: var(--ds-brand); box-shadow: 0 0 0 3px var(--ds-brand-soft); }
.wf-node.is-failed { border-color: var(--ds-danger); }
</style>
