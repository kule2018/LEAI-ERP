<!-- src/components/ds/DsAlert.vue -->
<script setup lang="ts">
/**
 * DsAlert —— 警告提示。
 *
 * 整块的行内提示：图标 + 标题 + 描述 + 可选关闭按钮；
 * banner 模式贴顶通栏（无圆角，适合页面级公告）。
 */
import { computed, ref } from 'vue';

/** 组件入参 */
const props = withDefaults(
  defineProps<{
    /** 类型：info / success / warning / danger */
    type?: 'info' | 'success' | 'warning' | 'danger';
    /** 标题（不传则只显示描述） */
    title?: string;
    /** 描述文案 */
    description?: string;
    /** 是否可关闭 */
    closable?: boolean;
    /** 是否通栏模式（无圆角） */
    banner?: boolean;
    /** 是否显示图标 */
    showIcon?: boolean;
  }>(),
  { type: 'info', title: '', description: '', closable: false, banner: false, showIcon: true },
);

/** 事件 */
const emit = defineEmits<{ (e: 'close'): void }>();

/** 是否已关闭（关闭后整块移除） */
const closed = ref(false);

/** 各类型的图标与配色 */
const theme = computed(() => {
  switch (props.type) {
    case 'success':
      return { color: 'var(--ds-success)', bg: 'rgba(22,163,74,0.08)', icon: 'M20 6 9 17l-5-5' };
    case 'warning':
      return { color: 'var(--ds-warning)', bg: 'rgba(217,119,6,0.08)', icon: 'M12 9v4m0 4h.01M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0Z' };
    case 'danger':
      return { color: 'var(--ds-danger)', bg: 'rgba(220,38,38,0.08)', icon: 'M18 6 6 18M6 6l12 12' };
    default:
      return { color: 'var(--ds-brand)', bg: 'var(--ds-brand-soft)', icon: 'M12 16v-4m0-4h.01M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20Z' };
  }
});

/**
 * 关闭：本地移除 + 通知父组件。
 * @returns 无
 */
function onClose(): void {
  closed.value = true;
  emit('close');
}
</script>

<template>
  <div
    v-if="!closed"
    class="ds-alert"
    :class="[`is-${type}`, { 'is-banner': banner }]"
    :style="{ background: theme.bg }"
    role="alert"
  >
    <!-- 图标 -->
    <svg v-if="showIcon" class="ds-alert-icon" :style="{ color: theme.color }" viewBox="0 0 24 24" aria-hidden="true">
      <path :d="theme.icon" />
    </svg>
    <!-- 文案 -->
    <div class="ds-alert-content">
      <p v-if="title" class="ds-alert-title">{{ title }}</p>
      <p v-if="description || $slots.default" class="ds-alert-desc">
        <slot>{{ description }}</slot>
      </p>
    </div>
    <!-- 关闭 -->
    <button v-if="closable" type="button" class="ds-alert-close" title="关闭" @click="onClose">✕</button>
  </div>
</template>

<style scoped>
.ds-alert {
  display: flex;
  align-items: flex-start;
  gap: 10px;
  padding: 10px 14px;
  border-radius: var(--ds-radius-md);
  font-size: var(--ds-font-sm);
  line-height: 1.6;
}
.ds-alert.is-banner { border-radius: 0; }

.ds-alert-icon {
  width: 17px; height: 17px; flex: none; margin-top: 2px;
  fill: none; stroke: currentColor; stroke-width: 2; stroke-linecap: round; stroke-linejoin: round;
}

.ds-alert-content { flex: 1; min-width: 0; }
.ds-alert-title { margin: 0; font-weight: 600; color: var(--ds-text); }
.ds-alert-desc { margin: 2px 0 0; color: var(--ds-text-2); }
.ds-alert-title + .ds-alert-desc { margin-top: 2px; }

.ds-alert-close {
  flex: none;
  border: 0;
  background: transparent;
  color: var(--ds-text-3);
  cursor: pointer;
  font-size: var(--ds-font-xs);
  padding: 2px;
  border-radius: var(--ds-radius-xs);
}
.ds-alert-close:hover { background: rgba(0, 0, 0, 0.08); color: var(--ds-text); }
</style>
