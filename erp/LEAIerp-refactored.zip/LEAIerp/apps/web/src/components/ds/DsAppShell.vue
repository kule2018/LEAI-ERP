<!-- src/components/ds/DsAppShell.vue -->
<script setup lang="ts">
/**
 * DsAppShell —— 全站外壳框架（侧边栏 + 顶栏 + 内容区）。
 *
 * 整体思路（一比一对齐 DeepSeek 网页版）：
 *   1) 左侧是浅灰侧边栏：顶部品牌区、主操作按钮、导航列表、底部主题切换与折叠开关；
 *   2) 右侧是内容区：顶部一条轻量顶栏（当前标题 + 右侧操作插槽），下方滚动内容；
 *   3) 侧边栏可折叠（收起后只留图标列），并在 <960px 时自动变成抽屉 + 遮罩；
 *      同时支持 Ctrl / ⌘ + B 快捷折叠；
 *   4) 全局 Toast 容器在这里挂载一次，业务组件只需调用 useToast() 即可，无需自己放容器；
 *   5) 顶栏同时提供明暗主题切换按钮，状态由 lib/theme.ts 持久化到 localStorage；
 *   6) 导航按 group 分组渲染，组首显示小标题，使「工作区 / 管理 / 支持」层次清晰。
 *
 * 用法：
 *   <DsAppShell title="文件整理 Agent" :nav="nav">
 *     <template #actions><DsButton block>+ 新建任务</DsButton></template>
 *     <template #header><span>运行记录</span></template>
 *     <RouterView />
 *   </DsAppShell>
 */
import { computed, ref, watch, onMounted, onBeforeUnmount, getCurrentInstance } from 'vue';
import DsToast from './DsToast.vue';
import { useTheme } from './theme';

import type { NavItem } from './types';

/**
 * 路由环境探测（不静态依赖 vue-router，宿主未安装时降级）：
 *   $route / $router 由 vue-router 的 app.use(router) 注册到全局属性；
 *   取到即按 SPA 导航渲染，取不到则退化为原生 <a href> 跳转。
 */
const globalProps = getCurrentInstance()?.appContext.config.globalProperties as Record<string, any> | undefined;
const router = globalProps?.$router as { push: (to: any) => Promise<unknown> } | undefined;

/** 单个导航项（类型定义见 ds/types.ts，Vue SFC 的 script setup 不允许 export） */

const props = withDefaults(
  defineProps<{
    /** 产品名（显示在侧边栏品牌区与顶栏） */
    title: string;
    /** 产品副标题 / 一句话定位，显示在品牌区第二行 */
    subtitle?: string;
    /** 导航列表 */
    nav?: NavItem[];
    /** 是否允许折叠侧边栏，默认允许 */
    collapsible?: boolean;
    /** 顶栏是否显示，默认显示 */
    showHeader?: boolean;
  }>(),
  { subtitle: '', nav: () => [], collapsible: true, showHeader: true },
);

/** 主题状态：mode / isDark / toggleTheme */
const { isDark, toggleTheme } = useTheme();

/** 侧边栏是否已折叠（宽屏记忆在 localStorage，避免每次刷新都要手动展开） */
const COLLAPSE_KEY = 'ds-shell-collapsed';
const collapsed = ref(false);
/** 窄屏下侧边栏是否以抽屉形式打开 */
const drawerOpen = ref(false);
/** 当前是否处于窄屏（<960px） */
const isNarrow = ref(false);

/**
 * 当前路径。
 *
 * vue-router 把 $route 以 getter 形式挂在 globalProperties 上，getter 内部读取
 * 响应式的 currentRoute，所以放进 computed 后每次路由切换都会重新求值——
 * 导航选中态因此能跟着路由走，不会固定停在初始路径那一项。
 * 没有路由环境（宿主未安装 vue-router）时退回浏览器 location，由 popstate 兜底。
 */
const fallbackPath = ref(typeof location !== 'undefined' ? location.pathname : '/');
const route = computed(() => {
  const current = globalProps?.$route as { path?: string; fullPath?: string } | undefined;
  if (current && typeof current.path === 'string') {
    return { path: current.path, fullPath: current.fullPath || current.path };
  }
  return { path: fallbackPath.value, fullPath: fallbackPath.value };
});

/** 顶栏标题：优先取当前匹配的导航项文案，否则回退到产品名 */
const headerTitle = computed(() => {
  const hit = props.nav.find((n) => n.to === route.value.path);
  return hit ? hit.label : props.title;
});

/** 品牌区首字：取产品名前两个字做图标，避免依赖图标库 */
const brandMark = computed(() => props.title.replace(/[^\u4e00-\u9fa5A-Za-z0-9]/g, '').slice(0, 2) || 'AI');

/**
 * 把扁平的导航列表按 group 折叠成分组结构，保持原有顺序。
 * 规则：相邻且 group 相同的项归为一组；无 group 的项归入「无标题组」。
 * @returns [{ title, items }]，title 为空串时表示该组不显示小标题
 */
const navGroups = computed(() => {
  const groups: { title: string; items: NavItem[] }[] = [];
  for (const item of props.nav) {
    const title = item.group ?? '';
    const last = groups[groups.length - 1];
    if (last && last.title === title) last.items.push(item);
    else groups.push({ title, items: [item] });
  }
  return groups;
});

/**
 * 判断某个导航项是否处于激活态。
 * 规则：完全相等，或当前路径以其为前缀（支持 /a 高亮 /a/1 这类详情页）。
 */
function isActive(to: string): boolean {
  if (to === '/') return route.value.path === '/';
  return route.value.path === to || route.value.path.startsWith(to + '/');
}

/**
 * 导航点击：有 $router 走 SPA push，否则让 <a> 默认跳转（整页刷新）。
 * @param to 目标路径
 * @returns 无
 */
function onNav(to: string): void {
  drawerOpen.value = false;
  if (router) {
    router.push(to).catch(() => {
      /* 路由不存在时静默，保留 <a> 的默认行为由浏览器处理 */
    });
  }
}

/** 折叠 / 展开切换，并持久化 */
function toggleCollapse(): void {
  collapsed.value = !collapsed.value;
  try {
    localStorage.setItem(COLLAPSE_KEY, collapsed.value ? '1' : '0');
  } catch {
    /* 隐私模式下 localStorage 可能不可用，忽略即可 */
  }
}

/** 视口变化监听：进入窄屏强制关闭抽屉，离开窄屏复位 */
function onResize(): void {
  const narrow = window.innerWidth < 960;
  if (narrow !== isNarrow.value) {
    isNarrow.value = narrow;
    if (!narrow) drawerOpen.value = false;
  }
}

/**
 * 全局快捷键：Ctrl / ⌘ + B 折叠或展开侧边栏。
 * 在输入框（input / textarea / contenteditable）里不拦截，避免影响打字。
 * @param e 键盘事件
 * @returns 无
 */
function onKeydown(e: KeyboardEvent): void {
  if (!(e.ctrlKey || e.metaKey) || e.key.toLowerCase() !== 'b') return;
  const el = e.target as HTMLElement | null;
  const tag = el?.tagName?.toLowerCase();
  if (tag === 'input' || tag === 'textarea' || el?.isContentEditable) return;
  e.preventDefault();
  if (!props.collapsible) return;
  if (isNarrow.value) drawerOpen.value = !drawerOpen.value;
  else toggleCollapse();
}

// 路由变化时自动关闭窄屏抽屉，避免点击后遮罩挡住内容
watch(route, () => { drawerOpen.value = false; });
// 没有路由环境时，用 popstate 兜底同步路径
if (!router && typeof window !== 'undefined') {
  window.addEventListener('popstate', () => {
    fallbackPath.value = location.pathname;
    drawerOpen.value = false;
  });
}

onMounted(() => {
  try {
    collapsed.value = localStorage.getItem(COLLAPSE_KEY) === '1';
  } catch {
    /* 忽略读取失败 */
  }
  onResize();
  window.addEventListener('resize', onResize);
  window.addEventListener('keydown', onKeydown);
});

onBeforeUnmount(() => {
  window.removeEventListener('resize', onResize);
  window.removeEventListener('keydown', onKeydown);
});
</script>

<template>
  <div class="ds-shell" :class="{ 'is-collapsed': collapsed }">
    <!-- 窄屏遮罩：点击关闭抽屉 -->
    <div v-if="drawerOpen" class="ds-shell__mask" @click="drawerOpen = false" />

    <!-- ========== 侧边栏 ========== -->
    <aside class="ds-shell__side" :class="{ 'is-open': drawerOpen }">
      <!-- 品牌区：图标 + 产品名（折叠时只留图标） -->
      <div class="ds-shell__brand" :title="title">
        <span class="ds-shell__mark">{{ brandMark }}</span>
        <span v-show="!collapsed" class="ds-shell__names">
          <b class="ds-shell__title">{{ title }}</b>
          <small v-if="subtitle" class="ds-shell__sub">{{ subtitle }}</small>
        </span>
      </div>

      <!-- 主操作区：由业务方通过 #actions 插槽注入（通常是「新建」按钮） -->
      <div v-if="$slots.actions" class="ds-shell__actions">
        <slot name="actions" :collapsed="collapsed" />
      </div>

      <!-- 导航列表：按分组渲染，组首显示小标题（折叠时隐藏） -->
      <nav class="ds-shell__nav">
        <!-- 每组独立容器：组内间距小、组间间距大，层级一眼可辨 -->
        <div v-for="(g, gi) in navGroups" :key="gi" class="ds-shell__navgroup">
          <div v-if="g.title && !collapsed" class="ds-shell__group">{{ g.title }}</div>
          <a
            v-for="item in g.items"
            :key="item.to"
            :href="item.to"
            class="ds-shell__link"
            :class="{ 'is-active': isActive(item.to) }"
            :title="item.label"
            @click.prevent="onNav(item.to)"
          >
            <span class="ds-shell__icon">
              <!-- 有图标用图标，没有图标用圆点占位，保证对齐 -->
              <svg v-if="item.icon && item.icon.length > 6" viewBox="0 0 24 24" aria-hidden="true">
                <path :d="item.icon" />
              </svg>
              <em v-else>{{ item.icon || '•' }}</em>
            </span>
            <span v-show="!collapsed" class="ds-shell__label ds-ellipsis">{{ item.label }}</span>
            <span v-show="!collapsed && item.badge" class="ds-shell__badge">{{ item.badge }}</span>
          </a>
        </div>
      </nav>

      <!-- 侧边栏底部：主题切换 + 折叠开关 -->
      <div class="ds-shell__foot">
        <button class="ds-shell__mini" :title="isDark ? '切换到浅色' : '切换到深色'" @click="toggleTheme()">
          <svg viewBox="0 0 24 24" aria-hidden="true">
            <path v-if="isDark" d="M12 3v2m0 14v2M3 12h2m14 0h2M5.6 5.6l1.4 1.4m10 10 1.4 1.4M5.6 18.4 7 17m10-10 1.4-1.4M16 12a4 4 0 1 1-8 0 4 4 0 0 1 8 0Z" />
            <path v-else d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8Z" />
          </svg>
          <span v-show="!collapsed">{{ isDark ? '浅色模式' : '深色模式' }}</span>
        </button>
        <button v-if="collapsible" class="ds-shell__mini" title="折叠侧边栏" @click="toggleCollapse">
          <svg viewBox="0 0 24 24" aria-hidden="true">
            <path d="M4 6h16M4 12h10M4 18h16" />
          </svg>
          <span v-show="!collapsed">收起侧边栏</span>
        </button>
      </div>
    </aside>

    <!-- ========== 右侧主区 ========== -->
    <div class="ds-shell__main">
      <!-- 顶栏 -->
      <header v-if="showHeader" class="ds-shell__header">
        <div class="ds-shell__hleft">
          <!-- 窄屏汉堡按钮 -->
          <button v-if="isNarrow" class="ds-shell__burger" title="菜单" @click="drawerOpen = true">
            <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 7h16M4 12h16M4 17h16" /></svg>
          </button>
          <b class="ds-shell__htitle ds-ellipsis">{{ headerTitle }}</b>
        </div>
        <!-- 右侧操作区：主题切换（窄屏兜底）+ 业务插槽 -->
        <div class="ds-shell__hright">
          <slot name="header" />
          <button class="ds-shell__iconbtn" :title="isDark ? '浅色模式' : '深色模式'" @click="toggleTheme()">
            <svg viewBox="0 0 24 24" aria-hidden="true">
              <path v-if="isDark" d="M12 3v2m0 14v2M3 12h2m14 0h2M5.6 5.6l1.4 1.4m10 10 1.4 1.4M5.6 18.4 7 17m10-10 1.4-1.4M16 12a4 4 0 1 1-8 0 4 4 0 0 1 8 0Z" />
              <path v-else d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8Z" />
            </svg>
          </button>
        </div>
      </header>

      <!-- 内容滚动区：业务页面渲染在这里 -->
      <main class="ds-shell__body">
        <slot />
      </main>
    </div>

    <!-- 全局提示容器：整站只挂一次 -->
    <DsToast />
  </div>
</template>

<style scoped>
/* ===== 外壳骨架 ===== */
.ds-shell {
  /* 侧栏度量：所有同级区块共用同一组变量，改一处即可全局保持一致 */
  --side-pad-x: 12px;                       /* 侧栏两侧留白 */
  --side-item-pad-x: 10px;                  /* 行内左右内边距 */
  --side-item-h: 40px;                      /* 最小点击区域高度 */
  --side-item-radius: var(--ds-radius);      /* 与卡片内二级面板同级，圆角统一 */
  --side-icon: 16px;                        /* 图标略小于文字视觉块 */
  --side-icon-gap: 10px;                    /* 图文间距 */
  --side-font: var(--ds-font-sm);           /* 行文字统一字号 */
  --side-gap-inner: 2px;                    /* 组内间距 */
  --side-gap-group: 18px;                   /* 组间间距（明显大于组内） */
  display: flex;
  height: 100vh;
  height: 100dvh;
  overflow: hidden;
  background: var(--ds-bg);
  color: var(--ds-text);
}

/* ===== 侧边栏 ===== */
.ds-shell__side {
  width: var(--ds-sidebar-w);
  flex: 0 0 var(--ds-sidebar-w);
  display: flex;
  flex-direction: column;
  gap: 10px;
  padding: 14px var(--side-pad-x) 10px;
  background: var(--ds-bg-soft);
  border-right: 1px solid var(--ds-border);
  transition: width var(--ds-dur) var(--ds-ease), flex-basis var(--ds-dur) var(--ds-ease);
}
.ds-shell.is-collapsed .ds-shell__side { width: 64px; flex-basis: 64px; padding-left: 8px; padding-right: 8px; }

/* 品牌区：左右留白与导航行对齐，圆角与同级面板一致 */
.ds-shell__brand { display: flex; align-items: center; gap: var(--side-icon-gap); padding: 4px 0 10px; min-width: 0; }
.ds-shell__mark {
  width: 32px; height: 32px; flex: 0 0 32px;
  display: grid; place-items: center;
  border-radius: var(--side-item-radius);
  background: var(--ds-brand);
  color: #fff; font-size: 13px; font-weight: 700; letter-spacing: .5px;
}
.ds-shell__names { display: flex; flex-direction: column; min-width: 0; }
.ds-shell__title { font-size: var(--ds-font-md); font-weight: 600; color: var(--ds-text); }
.ds-shell__sub { font-size: var(--ds-font-xs); color: var(--ds-text-3); margin-top: 2px; }

/* 主操作区 */
.ds-shell__actions { padding: 0 0 8px; }
.ds-shell.is-collapsed .ds-shell__brand { justify-content: center; }

/* 导航：组间间距 > 组内间距，遵循同一套变量 */
.ds-shell__nav {
  flex: 1; display: flex; flex-direction: column;
  gap: var(--side-gap-group);
  overflow-y: auto; overflow-x: hidden;
}
.ds-shell__navgroup { display: flex; flex-direction: column; gap: var(--side-gap-inner); }
/* 分组小标题：字小、色浅，左右内边距与导航行完全一致 */
.ds-shell__group {
  padding: 0 var(--side-item-pad-x);
  margin-bottom: 6px;
  font-size: var(--ds-font-xs); font-weight: 600; letter-spacing: .4px; line-height: 1.4;
  color: var(--ds-text-3); text-transform: none;
}
.ds-shell__link {
  display: flex; align-items: center; gap: var(--side-icon-gap);
  min-height: var(--side-item-h);
  padding: 0 var(--side-item-pad-x);
  border-radius: var(--side-item-radius);
  color: var(--ds-text-2); font-size: var(--side-font); line-height: 1.4;
  cursor: pointer; text-decoration: none;
  transition: background var(--ds-dur-fast) var(--ds-ease), color var(--ds-dur-fast) var(--ds-ease);
}
.ds-shell__link:hover { background: var(--ds-bg-hover); color: var(--ds-text); }
.ds-shell__link.is-active { background: var(--ds-brand-weak); color: var(--ds-brand); font-weight: 600; }
.ds-shell__icon { width: var(--side-icon); flex: 0 0 var(--side-icon); display: grid; place-items: center; }
.ds-shell__icon svg {
  width: var(--side-icon);
  height: var(--side-icon);
  fill: none;
  stroke: currentColor;
  stroke-width: 1.7;
  stroke-linecap: round;
  stroke-linejoin: round
}
.ds-shell__icon em { font-style: normal; font-size: var(--ds-font-xs); opacity: .8; }
.ds-shell__label { flex: 1; min-width: 0; font-size: var(--side-font); }
.ds-shell__badge {
  min-width: 18px; height: 18px; padding: 0 5px;
  display: inline-grid; place-items: center;
  border-radius: var(--ds-radius-full); background: var(--ds-brand); color: #fff;
  font-size: var(--ds-font-xs); font-weight: 600;
}
/* 折叠态：图标列居中，点击区域高度与圆角不变 */
.ds-shell.is-collapsed .ds-shell__link { justify-content: center; padding: 0; }

/* 侧边栏底部操作：与导航行同字号、同圆角、同点击区域 */
.ds-shell__foot {
  display: flex; flex-direction: column; gap: var(--side-gap-inner);
  padding-top: 10px; border-top: 1px solid var(--ds-border);
}
.ds-shell__mini {
  display: flex; align-items: center; gap: var(--side-icon-gap);
  min-height: var(--side-item-h);
  padding: 0 var(--side-item-pad-x);
  border: 0; border-radius: var(--side-item-radius);
  background: transparent; color: var(--ds-text-3);
  font-size: var(--side-font); font-family: inherit; line-height: 1.4; cursor: pointer;
  transition: background var(--ds-dur-fast) var(--ds-ease), color var(--ds-dur-fast) var(--ds-ease);
}
.ds-shell__mini:hover { background: var(--ds-bg-hover); color: var(--ds-text); }
.ds-shell__mini svg {
  width: var(--side-icon);
  height: var(--side-icon);
  flex: 0 0 var(--side-icon);
  fill: none;
  stroke: currentColor;
  stroke-width: 1.7;
  stroke-linecap: round;
  stroke-linejoin: round
}
.ds-shell.is-collapsed .ds-shell__mini { justify-content: center; padding: 0; }

/* ===== 右侧主区 ===== */
.ds-shell__main { flex: 1; min-width: 0; display: flex; flex-direction: column; }

/* 顶栏 */
.ds-shell__header {
  height: 56px; flex: 0 0 56px;
  display: flex; align-items: center; justify-content: space-between; gap: 12px;
  padding: 0 20px;
  border-bottom: 1px solid var(--ds-border);
  background: var(--ds-bg);
}
.ds-shell__hleft { display: flex; align-items: center; gap: 10px; min-width: 0; }
.ds-shell__htitle { font-size: 15px; font-weight: 600; color: var(--ds-text); }
.ds-shell__hright { display: flex; align-items: center; gap: 8px; }
.ds-shell__burger, .ds-shell__iconbtn {
  width: 32px; height: 32px; display: grid; place-items: center;
  border: 0; border-radius: var(--ds-radius-sm);
  background: transparent; color: var(--ds-text-2); cursor: pointer;
  transition: background var(--ds-dur-fast) var(--ds-ease);
}
.ds-shell__burger:hover, .ds-shell__iconbtn:hover { background: var(--ds-bg-hover); color: var(--ds-text); }
.ds-shell__burger svg, .ds-shell__iconbtn svg {
  width: 18px;
  height: 18px;
  fill: none;
  stroke: currentColor;
  stroke-width: 1.8;
  stroke-linecap: round;
  stroke-linejoin: round
}

/* 内容区 */
.ds-shell__body { flex: 1; overflow-y: auto; overflow-x: hidden; }

/* ===== 窄屏抽屉 ===== */
.ds-shell__mask { position: fixed; inset: 0; background: rgba(0, 0, 0, .38); z-index: 40; }

@media (max-width: 960px) {
  .ds-shell__side {
    position: fixed; top: 0; bottom: 0; left: 0; z-index: 50;
    width: var(--ds-sidebar-w); flex-basis: var(--ds-sidebar-w);
    transform: translateX(-100%);
    transition: transform var(--ds-dur) var(--ds-ease);
    box-shadow: var(--ds-shadow-md);
  }
  .ds-shell__side.is-open { transform: translateX(0); }
  /* 抽屉里一律展开文字，两侧留白、点击区域与展开态保持一致 */
  .ds-shell.is-collapsed .ds-shell__side {
    width: var(--ds-sidebar-w); flex-basis: var(--ds-sidebar-w);
    padding-left: var(--side-pad-x); padding-right: var(--side-pad-x);
  }
  .ds-shell.is-collapsed .ds-shell__link,
  .ds-shell.is-collapsed .ds-shell__mini { justify-content: flex-start; padding: 0 var(--side-item-pad-x); }
  .ds-shell.is-collapsed .ds-shell__brand { justify-content: flex-start; }
}
</style>
