<!-- src/components/ds/DsAvatar.vue -->
<script setup lang="ts">
/**
 * DsAvatar —— 头像。
 *
 * 优先显示图片（src），图片加载失败或未提供时降级为文字头像
 * （取 name 首字）或图标；shape 支持圆形 / 圆角方；size 支持数字或预设档。
 */
import { computed, ref } from 'vue';

/** 组件入参 */
const props = withDefaults(
  defineProps<{
    /** 图片地址 */
    src?: string;
    /** 文字名（无图时取首字符显示） */
    name?: string;
    /** 尺寸：px 数字或 sm / md / lg / xl */
    size?: number | 'sm' | 'md' | 'lg' | 'xl';
    /** 形状：circle 圆 / square 圆角方 */
    shape?: 'circle' | 'square';
    /** 背景色（文字头像用，默认品牌色） */
    color?: string;
    /** 是否显示状态点（在线绿点） */
    dot?: boolean;
  }>(),
  { src: '', name: '', size: 'md', shape: 'circle', color: '', dot: false },
);

/** 图片是否加载失败（失败则降级文字头像） */
const failed = ref(false);

/** 预设尺寸映射 */
const SIZE_MAP: Record<string, number> = { sm: 28, md: 36, lg: 44, xl: 56 };

/** 实际像素尺寸 */
const px = computed(() => (typeof props.size === 'number' ? props.size : SIZE_MAP[props.size] ?? 36));

/** 文字头像的首字符（中文取第一个字，英文取首字母大写） */
const initial = computed(() => {
  const n = (props.name || '').trim();
  if (!n) return '';
  return /[a-zA-Z]/.test(n[0]) ? n[0].toUpperCase() : n[0];
});

/** 背景色：未指定时按名字长度取一个稳定的品牌色阶 */
const bg = computed(() => props.color || 'var(--ds-brand)');
</script>

<template>
  <span
    class="ds-avatar"
    :class="`is-${shape}`"
    :style="{ width: px + 'px', height: px + 'px', fontSize: Math.round(px * 0.42) + 'px' }"
  >
    <!-- 有图且未失败：图片 -->
    <img v-if="src && !failed" :src="src" :alt="name" @error="failed = true" />
    <!-- 无图：文字或图标 -->
    <span v-else class="ds-avatar-fallback" :style="{ background: bg }">{{ initial || 'U' }}</span>
    <!-- 状态点 -->
    <span v-if="dot" class="ds-avatar-dot" />
  </span>
</template>

<style scoped>
.ds-avatar {
  position: relative;
  display: inline-grid;
  place-items: center;
  flex: none;
  overflow: visible;
  vertical-align: middle;
}
.ds-avatar.is-circle { border-radius: 50%; }
.ds-avatar.is-square { border-radius: var(--ds-radius-sm); }

.ds-avatar img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  border-radius: inherit;
  display: block;
}
.ds-avatar-fallback {
  width: 100%;
  height: 100%;
  display: grid;
  place-items: center;
  border-radius: inherit;
  color: #fff;
  font-weight: 600;
  line-height: 1;
  user-select: none;
}

/* 在线状态点：右下角 8px 绿点 + 白描边（深色主题描边跟随底色） */
.ds-avatar-dot {
  position: absolute;
  right: 0;
  bottom: 0;
  width: 9px;
  height: 9px;
  border-radius: 50%;
  background: var(--ds-success);
  border: 2px solid var(--ds-bg-elevated);
}
</style>
