<!-- src/components/ds/DsBadge.vue -->
<script setup lang="ts">
/**
 * DsBadge —— 徽标数。
 *
 * 两种用法：
 *   1) 独立徽标：<DsBadge :count="9" /> —— 直接显示一个胶囊；
 *   2) 包裹模式：<DsBadge :count="9"><DsButton>消息</DsButton></DsBadge> ——
 *      徽标浮在包裹内容的右上角（消息 / 通知红点的标准形态）。
 * count 为 0 且未开 showZero 时自动隐藏；dot 模式只显示小圆点。
 */
import { computed, useSlots } from 'vue';

/** 组件入参 */
const props = withDefaults(
  defineProps<{
    /** 徽标数（超出 max 显示 max+） */
    count?: number;
    /** 上限（默认 99） */
    max?: number;
    /** 是否只显示圆点（忽略数字） */
    dot?: boolean;
    /** 0 是否也显示 */
    showZero?: boolean;
    /** 语义色：brand 红点常用 / danger / success / neutral */
    color?: 'brand' | 'danger' | 'success' | 'neutral';
    /** 独立模式下的位置（仅无包裹内容时生效） */
    standalone?: boolean;
  }>(),
  { count: 0, max: 99, dot: false, showZero: false, color: 'danger', standalone: false },
);

/** 展示文案：超上限折叠为 max+ */
const text = computed(() => (props.count > props.max ? `${props.max}+` : String(props.count)));

/** 是否隐藏 */
const hidden = computed(() => !props.dot && !props.count && !props.showZero);

/** 是否包裹模式（有默认插槽内容时，徽标浮在右上角） */
const slots = useSlots();
const wrapped = computed(() => !!slots.default);
</script>

<template>
  <!-- 包裹模式：相对定位容器 + 右上角浮层 -->
  <span v-if="wrapped" class="ds-badge-wrap">
    <slot />
    <sup v-if="!hidden" class="ds-badge" :class="[`is-${color}`, { 'is-dot': dot }]">
      {{ dot ? '' : text }}
    </sup>
  </span>

  <!-- 独立模式 -->
  <sup v-else-if="!hidden" class="ds-badge is-standalone" :class="[`is-${color}`, { 'is-dot': dot }]">
    {{ dot ? '' : text }}
  </sup>
</template>

<style scoped>
.ds-badge-wrap { position: relative; display: inline-flex; }

.ds-badge {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  min-width: 18px;
  height: 18px;
  padding: 0 5px;
  border-radius: var(--ds-radius-full);
  background: var(--ds-danger);
  color: #fff;
  font-size: 11px;
  font-weight: 600;
  line-height: 1;
  font-variant-numeric: tabular-nums;
}
.ds-badge.is-brand { background: var(--ds-brand); }
.ds-badge.is-success { background: var(--ds-success); }
.ds-badge.is-neutral { background: var(--ds-text-3); }

/* 圆点模式：无数字，缩成 8px */
.ds-badge.is-dot { min-width: 8px; width: 8px; height: 8px; padding: 0; }

/* 包裹模式：浮在右上角 */
.ds-badge-wrap .ds-badge {
  position: absolute;
  top: 0;
  right: 0;
  transform: translate(50%, -50%);
  z-index: 1;
}
.ds-badge-wrap .ds-badge.is-dot { transform: translate(40%, -40%); }

/* 独立模式 */
.ds-badge.is-standalone { position: static; transform: none; }
</style>
