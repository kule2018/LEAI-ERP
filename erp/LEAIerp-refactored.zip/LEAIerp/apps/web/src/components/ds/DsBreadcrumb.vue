<!-- src/components/ds/DsBreadcrumb.vue -->
<script setup lang="ts">
/**
 * DsBreadcrumb —— 面包屑。
 *
 * items 配置驱动；最后一项自动加粗且不可点（当前页语义）；
 * 支持自定义分隔符插槽与「点击项」事件（不内置路由，由业务决定跳转方式）。
 */
import type { CrumbItem } from './types';


/** 组件入参 */
const props = withDefaults(
  defineProps<{
    /** 面包屑项（最后一项为当前页） */
    items: CrumbItem[];
    /** 分隔符文案 */
    separator?: string;
  }>(),
  { separator: '/' },
);

/** 事件 */
const emit = defineEmits<{ (e: 'click', item: CrumbItem, index: number): void }>();

/**
 * 点击某一项（最后一项不触发）。
 * @param item 被点击项
 * @param index 下标
 * @returns 无
 */
function onClick(item: CrumbItem, index: number): void {
  if (item.disabled || index === props.items.length - 1) return;
  emit('click', item, index);
}
</script>

<template>
  <nav class="ds-breadcrumb" aria-label="面包屑">
    <template v-for="(item, i) in items" :key="i">
      <!-- 当前页：加粗不可点 -->
      <span v-if="i === items.length - 1" class="ds-crumb is-current" aria-current="page">
        {{ item.label }}
      </span>
      <!-- 历史项：可点 -->
      <span
        v-else
        class="ds-crumb"
        :class="{ 'is-disabled': item.disabled }"
        @click="onClick(item, i)"
      >
        {{ item.label }}
      </span>
      <!-- 分隔符 -->
      <span v-if="i < items.length - 1" class="ds-crumb-sep">
        <slot name="separator">{{ separator }}</slot>
      </span>
    </template>
  </nav>
</template>

<style scoped>
.ds-breadcrumb {
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: 2px;
  font-size: var(--ds-font-sm);
  line-height: 1.6;
}
.ds-crumb {
  color: var(--ds-text-2);
  cursor: pointer;
  padding: 1px 4px;
  border-radius: var(--ds-radius-xs);
  transition: color var(--ds-dur-fast) var(--ds-ease);
}
.ds-crumb:hover:not(.is-current):not(.is-disabled) { color: var(--ds-brand); }
.ds-crumb.is-current { color: var(--ds-text); font-weight: 600; cursor: default; }
.ds-crumb.is-disabled { color: var(--ds-text-3); cursor: not-allowed; }
.ds-crumb-sep {
  color: var(--ds-text-3);
  user-select: none;
  padding: 0 2px;
}
</style>
