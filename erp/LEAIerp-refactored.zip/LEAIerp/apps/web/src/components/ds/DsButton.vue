<!-- src/components/ds/DsButton.vue -->
<script setup lang="ts">
/**
 * 通用按钮
 * ------------------------------------------------------------------
 * 统一产品里所有按钮的尺寸、圆角与语义色，避免各处手写样式导致不一致。
 * 支持：5 种语义（primary/default/ghost/danger/text）、3 种尺寸、加载态、图标插槽、块级。
 */
import { computed } from 'vue';

/** 组件入参 */
const props = withDefaults(
  defineProps<{
    /** 语义类型：primary 主操作 / default 次操作 / ghost 描边 / danger 危险 / text 文字按钮 */
    variant?: 'primary' | 'default' | 'ghost' | 'danger' | 'text';
    /** 尺寸：sm 小 / md 中 / lg 大 */
    size?: 'sm' | 'md' | 'lg';
    /** 是否禁用 */
    disabled?: boolean;
    /** 是否处于加载中（自动禁用并显示转圈） */
    loading?: boolean;
    /** 是否块级（宽度撑满父容器） */
    block?: boolean;
    /** 原生 type（表单内提交按钮用 submit） */
    type?: 'button' | 'submit' | 'reset';
  }>(),
  { variant: 'default', size: 'md', disabled: false, loading: false, block: false, type: 'button' },
);

/** 事件：点击（加载中/禁用时不触发由模板的 :disabled 保证） */
const emit = defineEmits<{ (e: 'click', ev: MouseEvent): void }>();

/** 是否真的不可点：外部禁用或加载中 */
const isDisabled = computed(() => props.disabled || props.loading);

/**
 * 点击事件转发。
 * @param ev 原生鼠标事件
 */
function onClick(ev: MouseEvent): void {
  if (isDisabled.value) return;
  emit('click', ev);
}
</script>

<template>
  <button
    class="ds-btn"
    :class="[`ds-btn-${variant}`, `ds-btn-${size}`, { 'is-block': block, 'is-loading': loading }]"
    :type="type"
    :disabled="isDisabled"
    @click="onClick"
  >
    <!-- 加载图标：内联 SVG，不依赖图标库 -->
    <span v-if="loading" class="ds-btn-spin" aria-hidden="true" />
    <!-- 前缀图标插槽 -->
    <span v-else-if="$slots.icon" class="ds-btn-icon"><slot name="icon" /></span>
    <span class="ds-btn-label"><slot /></span>
  </button>
</template>

<style scoped>
.ds-btn {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: var(--ds-gap-inner);
  border-radius: var(--ds-radius-ctl);
  font-weight: 500;
  white-space: nowrap;
  transition: background-color var(--ds-dur-fast) var(--ds-ease),
    border-color var(--ds-dur-fast) var(--ds-ease), color var(--ds-dur-fast) var(--ds-ease),
    box-shadow var(--ds-dur-fast) var(--ds-ease), transform var(--ds-dur-fast) var(--ds-ease);
  border: 1px solid transparent;
  user-select: none;
}

/* 尺寸：与输入控件共用高度阶梯，保证同行字段与按钮等高；点击热区达标 */
.ds-btn-sm { height: var(--ds-ctl-h-sm); padding: 0 var(--ds-space-3); font-size: var(--ds-font-sm); }
.ds-btn-md { height: var(--ds-ctl-h-md); padding: 0 var(--ds-space-4); font-size: var(--ds-font-md); }
.ds-btn-lg { height: var(--ds-ctl-h-lg); padding: 0 var(--ds-space-5); font-size: var(--ds-font-lg); }

/* 语义：主操作 */
.ds-btn-primary { background: var(--ds-brand); color: #fff; }
.ds-btn-primary:hover:not(:disabled) { background: var(--ds-brand-hover); }
.ds-btn-primary:active:not(:disabled) { background: var(--ds-brand-active); }

/* 语义：次级（白底描边） */
.ds-btn-default { background: var(--ds-bg-elevated); color: var(--ds-text-2); border-color: var(--ds-border); }
.ds-btn-default:hover:not(:disabled) { background: var(--ds-bg-hover); color: var(--ds-text); border-color: var(--ds-border-strong); }

/* 语义：描边（品牌色） */
.ds-btn-ghost { background: transparent; color: var(--ds-brand); border-color: var(--ds-border-strong); }
.ds-btn-ghost:hover:not(:disabled) { background: var(--ds-brand-soft); border-color: var(--ds-brand); }

/* 语义：危险 */
.ds-btn-danger { background: var(--ds-danger); color: #fff; }
.ds-btn-danger:hover:not(:disabled) { filter: brightness(1.08); }

/* 语义：文字按钮 —— 视觉轻量，但点击热区 ≥40px（桌面）/44px（触屏） */
.ds-btn-text {
  background: transparent;
  color: var(--ds-text-2);
  padding: 0 var(--ds-space-2);
  min-height: var(--ds-hit);
}
.ds-btn-text:hover:not(:disabled) { background: var(--ds-bg-hover); color: var(--ds-text); }
@media (pointer: coarse) {
  .ds-btn-sm, .ds-btn-md, .ds-btn-lg, .ds-btn-text { min-height: var(--ds-hit-touch); }
}

/* 块级 */
.is-block { display: flex; width: 100%; }

/* 禁用 */
.ds-btn:disabled { opacity: 0.5; }

/* 加载态隐藏文字抖动：保留占位，避免宽度跳变 */
.is-loading .ds-btn-label { opacity: 0.85; }

/* 内联转圈 */
.ds-btn-spin {
  width: 14px;
  height: 14px;
  border: 2px solid currentColor;
  border-right-color: transparent;
  border-radius: 50%;
  animation: ds-spin 0.7s linear infinite;
  opacity: 0.9;
}

.ds-btn-icon { display: inline-flex; align-items: center; }
</style>
