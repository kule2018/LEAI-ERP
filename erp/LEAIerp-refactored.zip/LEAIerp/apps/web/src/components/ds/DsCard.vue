<!-- src/components/ds/DsCard.vue -->
<script setup lang="ts">
/**
 * DsCard —— 卡片容器。
 *
 * 页面内容的标准积木：标题栏（标题 + 右侧操作区）+ 内容区。
 * 支持无边框浮起（flat）、阴影悬停（hover）、内容区内边距开关（pad），
 * 以及 collapsible 折叠。简单包裹场景也可以直接用全局类 .ds-card。
 */
import { ref } from 'vue';

/** 组件入参 */
const props = withDefaults(
  defineProps<{
    /** 标题（无标题且无 title 插槽时不渲染标题栏） */
    title?: string;
    /** 副标题（标题下方小字） */
    subtitle?: string;
    /** 是否显示边框 */
    bordered?: boolean;
    /** 是否浮起（无边框 + 轻阴影） */
    flat?: boolean;
    /** 悬停时显示阴影 */
    hoverable?: boolean;
    /** 内容区是否有内边距 */
    pad?: boolean;
    /** 是否可折叠 */
    collapsible?: boolean;
    /** 是否默认折叠 */
    defaultCollapsed?: boolean;
    /** 内容区加载态 */
    loading?: boolean;
  }>(),
  {
    title: '',
    subtitle: '',
    bordered: true,
    flat: false,
    hoverable: false,
    pad: true,
    collapsible: false,
    defaultCollapsed: false,
    loading: false,
  },
);

/** 折叠状态（仅 collapsible 时生效） */
const collapsed = ref(props.defaultCollapsed);
</script>

<template>
  <section
    class="ds-card-c"
    :class="{
      'is-flat': flat,
      'is-hoverable': hoverable,
      'no-pad': !pad,
      'is-collapsed': collapsed,
    }"
    :style="bordered && !flat ? { borderColor: 'var(--ds-border)' } : { borderColor: 'transparent' }"
  >
    <!-- 标题栏 -->
    <header v-if="title || subtitle || $slots.title || $slots.extra || collapsible" class="ds-card-c__head">
      <div class="ds-card-c__titles">
        <slot name="title">
          <span v-if="title" class="ds-card-c__title">{{ title }}</span>
          <span v-if="subtitle" class="ds-card-c__sub">{{ subtitle }}</span>
        </slot>
      </div>
      <div class="ds-card-c__extra">
        <slot name="extra" />
        <!-- 折叠按钮 -->
        <button
          v-if="collapsible"
          type="button"
          class="ds-card-c__fold"
          :title="collapsed ? '展开' : '收起'"
          @click="collapsed = !collapsed"
        >
          <svg viewBox="0 0 24 24" aria-hidden="true"><path d="m6 9 6 6 6-6" /></svg>
        </button>
      </div>
    </header>

    <!-- 内容区 -->
    <div v-show="!collapsed" class="ds-card-c__body">
      <!-- 加载态：转圈覆盖 -->
      <div v-if="loading" class="ds-card-c__loading"><span class="ds-card-c__spin" /> 加载中…</div>
      <slot v-else />
    </div>
  </section>
</template>

<style scoped>
.ds-card-c {
  display: flex;
  flex-direction: column;
  background: var(--ds-bg-elevated);
  border: 1px solid var(--ds-border);
  border-radius: var(--ds-radius-lg);
  transition: box-shadow var(--ds-dur) var(--ds-ease), border-color var(--ds-dur) var(--ds-ease);
}
.ds-card-c.is-hoverable:hover { box-shadow: var(--ds-shadow-sm); }
.ds-card-c.is-flat { border-color: transparent; box-shadow: var(--ds-shadow-sm); }

/* 标题栏 */
.ds-card-c__head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: var(--ds-space-3);
  padding: var(--ds-space-3) var(--ds-space-4);
  min-height: var(--ds-hit);
  border-bottom: 1px solid var(--ds-divider);
}
.ds-card-c.is-collapsed .ds-card-c__head { border-bottom-color: transparent; }
.ds-card-c__titles { display: flex; flex-direction: column; min-width: 0; }
.ds-card-c__title { font-size: var(--ds-font-lg); font-weight: 600; color: var(--ds-text); line-height: 1.4; }
.ds-card-c__sub { font-size: var(--ds-font-xs); color: var(--ds-text-3); margin-top: var(--ds-space-1); }
.ds-card-c__extra { display: flex; align-items: center; gap: var(--ds-gap-inner); flex: none; }
.ds-card-c__fold {
  width: var(--ds-hit); height: var(--ds-hit);
  display: grid; place-items: center;
  border: 0; border-radius: var(--ds-radius-ctl);
  background: transparent; color: var(--ds-text-3); cursor: pointer;
  transition: background var(--ds-dur-fast) var(--ds-ease);
}
.ds-card-c__fold:hover { background: var(--ds-bg-hover); color: var(--ds-text); }
.ds-card-c__fold svg {
  width: 16px; height: 16px;
  fill: none; stroke: currentColor; stroke-width: 2; stroke-linecap: round; stroke-linejoin: round;
  transition: transform var(--ds-dur) var(--ds-ease);
}
.ds-card-c.is-collapsed .ds-card-c__fold svg { transform: rotate(180deg); }

/* 内容区 */
.ds-card-c__body { flex: 1; padding: var(--ds-space-4); }
.ds-card-c.no-pad .ds-card-c__body { padding: 0; }
.ds-card-c__loading {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  min-height: 80px;
  color: var(--ds-text-3);
  font-size: var(--ds-font-sm);
}
.ds-card-c__spin {
  width: 16px; height: 16px;
  border: 2px solid var(--ds-border);
  border-top-color: var(--ds-brand);
  border-radius: 50%;
  animation: ds-spin 0.7s linear infinite;
}
</style>
