<!-- src/components/ds/DsCascader.vue -->
<script setup lang="ts">
/**
 * DsCascader —— 级联选择器。
 *
 * 多层级选项以「浮层内多列」形式展开：选中某一列后会展开下一列，
 * 路径值以数组形式写入 v-model（如 ['浙江', '杭州', '西湖区']）。
 * 支持 click / hover 两种展开触发方式与「仅叶子可选」约束。
 */
import { computed, ref, watch } from 'vue';
import { usePopover } from './usePopover';
import type { CascaderOption } from './types';


/** 组件入参 */
const props = withDefaults(
  defineProps<{
    /** 选中路径（v-model，数组，如 ['zj', 'hz']） */
    modelValue: any[];
    /** 级联数据 */
    options: CascaderOption[];
    /** 占位文案 */
    placeholder?: string;
    /** 是否禁用 */
    disabled?: boolean;
    /** 是否可清空 */
    clearable?: boolean;
    /** 下一级展开方式：click 点击 / hover 悬停 */
    expandTrigger?: 'click' | 'hover';
    /** 是否仅叶子节点可选（默认 true） */
    leafOnly?: boolean;
  }>(),
  {
    options: () => [],
    placeholder: '请选择',
    disabled: false,
    clearable: true,
    expandTrigger: 'click',
    leafOnly: true,
  },
);

/** 事件 */
const emit = defineEmits<{ (e: 'update:modelValue', v: any[]): void; (e: 'change', v: any[]): void }>();

// 浮层控制
const { open, rootRef, toggle, close } = usePopover();
void rootRef;

/** 当前激活路径（展开到第几层的记录；长度 = 列数） */
const activePath = ref<any[]>([]);

/** 根据路径取每一列的选项列表 */
const columns = computed<CascaderOption[][]>(() => {
  const cols: CascaderOption[][] = [props.options];
  let cur = props.options;
  for (const val of activePath.value) {
    const hit = cur.find((o) => o.value === val);
    if (!hit?.children?.length) break;
    cols.push(hit.children);
    cur = hit.children;
  }
  return cols;
});

/** 选中路径的展示文案（如 "浙江 / 杭州"） */
const labelText = computed(() => {
  const labels: string[] = [];
  let cur = props.options;
  for (const val of props.modelValue || []) {
    const hit = cur.find((o) => o.value === val);
    if (!hit) break;
    labels.push(hit.label);
    cur = hit.children || [];
  }
  return labels.join(' / ');
});

/** 某个值在对应列是否被激活 */
function isActive(val: any): boolean {
  return activePath.value.includes(val);
}

/**
 * 点击某一列的某个选项：记录路径、展开下一级；叶子则提交并收起。
 * @param opt 被点击选项
 * @param level 所在列下标
 * @returns 无
 */
function pick(opt: CascaderOption, level: number): void {
  if (opt.disabled) return;
  // 截断到当前层，再追加本级
  const path = activePath.value.slice(0, level);
  path.push(opt.value);
  activePath.value = path;

  const isLeaf = !opt.children?.length;
  if (isLeaf || !props.leafOnly) {
    emit('update:modelValue', path);
    emit('change', path);
    if (isLeaf) close();
  }
}

/** 悬停展开（hover 模式） */
function onHover(opt: CascaderOption, level: number): void {
  if (props.expandTrigger !== 'hover') return;
  if (opt.disabled) return;
  activePath.value = [...activePath.value.slice(0, level), opt.value];
}

/** 清空 */
function clearValue(): void {
  activePath.value = [];
  emit('update:modelValue', []);
  emit('change', []);
}

// 每次展开：用当前值回填展开路径，让用户看到自己选到哪一级
watch(open, (v) => {
  if (v) activePath.value = [...(props.modelValue || [])];
  else activePath.value = [];
});
</script>

<template>
  <div ref="rootRef" class="ds-cascader" :class="{ 'is-disabled': disabled, 'is-open': open }">
    <!-- 触发器 -->
    <div class="ds-cascader-trigger" @click="!disabled && toggle()">
      <span class="ds-cascader-text" :class="{ 'is-ph': !labelText }">{{ labelText || placeholder }}</span>
      <button v-if="clearable && labelText && !disabled" type="button" class="ds-cascader-clear" title="清空" @click.stop="clearValue">✕</button>
      <svg class="ds-cascader-arrow" :class="{ 'is-flip': open }" viewBox="0 0 24 24" aria-hidden="true"><path d="m6 9 6 6 6-6" /></svg>
    </div>

    <!-- 浮层：多列 -->
    <div v-if="open" class="ds-cascader-pop">
      <div v-for="(col, level) in columns" :key="level" class="ds-cascader-col">
        <div
          v-for="opt in col"
          :key="String(opt.value)"
          class="ds-cascader-opt"
          :class="{
            'is-active': isActive(opt.value),
            'is-disabled': opt.disabled,
            'has-child': !!opt.children?.length,
          }"
          @click="pick(opt, level)"
          @mouseenter="onHover(opt, level)"
        >
          <span>{{ opt.label }}</span>
          <!-- 有子级显示右箭头 -->
          <svg v-if="opt.children?.length" class="ds-cascader-next" viewBox="0 0 24 24" aria-hidden="true"><path d="m9 6 6 6-6 6" /></svg>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.ds-cascader { position: relative; width: 100%; }

.ds-cascader-trigger {
  display: flex;
  align-items: center;
  gap: 6px;
  min-height: var(--ds-ctl-h-md);
  padding: 0 10px;
  background: var(--ds-bg-elevated);
  border: 1px solid var(--ds-border);
  border-radius: var(--ds-radius-sm);
  cursor: pointer;
  transition: border-color var(--ds-dur-fast) var(--ds-ease), box-shadow var(--ds-dur-fast) var(--ds-ease);
}
.ds-cascader-trigger:hover { border-color: var(--ds-border-strong); }
.ds-cascader.is-open:not(.is-disabled) .ds-cascader-trigger { border-color: var(--ds-brand); box-shadow: 0 0 0 3px var(--ds-brand-soft); }
.ds-cascader.is-disabled .ds-cascader-trigger { background: var(--ds-bg-hover); cursor: not-allowed; }

.ds-cascader-text {
  flex: 1;
  min-width: 0;
  color: var(--ds-text);
  font-size: var(--ds-font-md);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap
}
.ds-cascader-text.is-ph { color: var(--ds-text-3); }
.ds-cascader-clear {
  border: 0; background: transparent; color: var(--ds-text-3);
  cursor: pointer; font-size: var(--ds-font-xs); padding: 2px; border-radius: var(--ds-radius-xs);
}
.ds-cascader-clear:hover { background: var(--ds-bg-hover); color: var(--ds-text); }
.ds-cascader-arrow {
  width: 16px; height: 16px; flex: none;
  fill: none; stroke: var(--ds-text-3); stroke-width: 2; stroke-linecap: round; stroke-linejoin: round;
  transition: transform var(--ds-dur-fast) var(--ds-ease);
}
.ds-cascader-arrow.is-flip { transform: rotate(180deg); }

/* ---- 浮层 ---- */
.ds-cascader-pop {
  position: absolute;
  top: calc(100% + 6px);
  left: 0;
  z-index: 100;
  display: flex;
  background: var(--ds-bg-elevated);
  border: 1px solid var(--ds-border);
  border-radius: var(--ds-radius);
  box-shadow: var(--ds-shadow-md);
  overflow: hidden;
}
.ds-cascader-col {
  width: 132px;
  max-height: 240px;
  overflow-y: auto;
  padding: 4px;
  border-right: 1px solid var(--ds-divider);
}
.ds-cascader-col:last-child { border-right: none; }

.ds-cascader-opt {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 6px;
  padding: 7px 10px;
  border-radius: var(--ds-radius-xs);
  color: var(--ds-text-2);
  font-size: var(--ds-font-sm);
  cursor: pointer;
  white-space: nowrap;
}
.ds-cascader-opt:hover { background: var(--ds-bg-hover); }
.ds-cascader-opt.is-active { color: var(--ds-brand); background: var(--ds-brand-soft); font-weight: 500; }
.ds-cascader-opt.is-disabled { opacity: 0.45; cursor: not-allowed; }
.ds-cascader-next {
  width: 13px; height: 13px; flex: none;
  fill: none; stroke: currentColor; stroke-width: 2; stroke-linecap: round; stroke-linejoin: round;
}
</style>
