<!-- src/components/ds/DsChatView.vue -->
<script setup lang="ts">
/**
 * 会话消息流
 * ------------------------------------------------------------------
 * 复刻 DeepSeek 的对话呈现：
 *   - 用户消息：右侧蓝色气泡，最长 78%，圆角不对称（右下角收窄）；
 *   - AI 消息：左侧无气泡纯文本 + 品牌小图标，宽度铺满；
 *   - 深度思考：可折叠卡片，收起时显示「已深度思考（用时 x 秒）」；
 *   - AI 消息底部：复制 / 重新生成（仅在非流式时显示）；
 *   - 自动滚动：默认贴底，用户手动上滑后停止自动跟随（并出现「回到底部」）。
 */
import { ref, watch, nextTick, onMounted } from 'vue';
import DsMarkdown from './DsMarkdown.vue';
import { copyText, formatDuration } from './format';
import { useToast } from './toast';

import type { ChatMessage } from './types';

/** 组件入参 */
const props = withDefaults(
  defineProps<{
    /** 消息列表 */
    messages: ChatMessage[];
    /** 空态标题 */
    emptyTitle?: string;
    /** 空态说明 */
    emptyDesc?: string;
    /** 是否显示「重新生成」按钮 */
    regenerable?: boolean;
  }>(),
  { emptyTitle: '', emptyDesc: '', regenerable: true },
);

/** 事件 */
const emit = defineEmits<{ (e: 'regenerate', msg: ChatMessage): void }>();

const toast = useToast();
/** 滚动容器 */
const scrollRef = ref<HTMLDivElement | null>(null);
/** 是否处于底部（决定是否自动跟随） */
const atBottom = ref(true);
/** 每条思考卡片的展开状态 */
const openReasoning = ref<Record<string, boolean>>({});
/** 每条消息的引用来源展开状态 */
const openCitations = ref<Record<string, boolean>>({});

/**
 * 滚动到底部。
 * @param smooth 是否平滑滚动（流式输出时用 auto 更跟手）
 */
async function scrollToBottom(smooth = false): Promise<void> {
  await nextTick();
  const el = scrollRef.value;
  if (!el) return;
  el.scrollTo({ top: el.scrollHeight, behavior: smooth ? 'smooth' : 'auto' });
}

/**
 * 监听滚动：距底 80px 内视为贴底。
 */
function onScroll(): void {
  const el = scrollRef.value;
  if (!el) return;
  atBottom.value = el.scrollHeight - el.scrollTop - el.clientHeight < 80;
}

/**
 * 复制整条消息正文。
 * @param m 消息
 */
async function onCopy(m: ChatMessage): Promise<void> {
  const ok = await copyText(m.content);
  toast[ok ? 'success' : 'error'](ok ? '已复制' : '复制失败');
}

/** 切换某条消息的思考过程折叠 */
function toggleReasoning(id: string): void {
  openReasoning.value[id] = !openReasoning.value[id];
}

/** 切换引用来源的展开状态 */
function toggleCitations(id: string): void {
  openCitations.value[id] = !openCitations.value[id];
}

// 消息变化或流式内容增长时，若用户在底部则自动跟随
watch(
  () => props.messages.map((m) => m.content.length + (m.reasoning?.length || 0)).join(','),
  () => { if (atBottom.value) void scrollToBottom(); },
);

onMounted(() => { void scrollToBottom(); });

/** 对外暴露滚动方法，便于父组件在发送后调用 */
defineExpose({ scrollToBottom });
</script>

<template>
  <div class="ds-chat">
    <div ref="scrollRef" class="ds-chat-scroll" @scroll="onScroll">
      <!-- 空态：居中欢迎语 -->
      <div v-if="!messages.length" class="ds-chat-empty">
        <div class="ds-chat-logo" aria-hidden="true">
          <svg width="34" height="34" viewBox="0 0 24 24" fill="none">
            <rect x="3" y="3" width="18" height="18" rx="5" fill="currentColor" opacity="0.14" />
            <path
d="M7.5 13.5c1.6 2.2 3.3 3.3 5 3.3s3.4-1.1 5-3.3" stroke="currentColor"
                  stroke-width="1.8" stroke-linecap="round" />
            <circle cx="9" cy="10" r="1.2" fill="currentColor" />
            <circle cx="15" cy="10" r="1.2" fill="currentColor" />
          </svg>
        </div>
        <h2 class="ds-chat-empty-title">{{ emptyTitle }}</h2>
        <p v-if="emptyDesc" class="ds-chat-empty-desc">{{ emptyDesc }}</p>
      </div>

      <!-- 消息列表 -->
      <div v-else class="ds-chat-list">
        <div
          v-for="m in messages"
          :key="m.id"
          class="ds-msg"
          :class="m.role === 'user' ? 'is-user' : 'is-assistant'"
        >
          <!-- AI 头像 -->
          <div v-if="m.role === 'assistant'" class="ds-msg-avatar" aria-hidden="true">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
              <rect x="3" y="3" width="18" height="18" rx="5" fill="currentColor" opacity="0.16" />
              <path
d="M7.5 13.5c1.6 2.2 3.3 3.3 5 3.3s3.4-1.1 5-3.3" stroke="currentColor"
                    stroke-width="1.8" stroke-linecap="round" />
            </svg>
          </div>

          <div class="ds-msg-main">
            <!-- 思考过程（可折叠） -->
            <div v-if="m.role === 'assistant' && (m.reasoning || m.streaming)" class="ds-think">
              <button class="ds-think-head" type="button" @click="toggleReasoning(m.id)">
                <span class="ds-think-dot" />
                <span v-if="m.streaming && !m.content">正在深度思考…</span>
                <span v-else>
                  已深度思考<template v-if="m.reasoningMs">（用时 {{ formatDuration(m.reasoningMs, true) }}）</template>
                </span>
                <span class="ds-think-arrow" :class="{ 'is-open': openReasoning[m.id] }">›</span>
              </button>
              <div v-show="openReasoning[m.id]" class="ds-think-body">
                <DsMarkdown :content="m.reasoning || ''" :streaming="m.streaming && !m.content" />
              </div>
            </div>

            <!-- 正文 -->
            <div v-if="m.error" class="ds-msg-error">
              {{ m.error }}
            </div>
            <div v-else-if="m.role === 'user'" class="ds-msg-bubble">{{ m.content }}</div>
            <DsMarkdown v-else :content="m.content" :streaming="m.streaming" />

            <!-- 引用来源：回答依据的知识库片段，可展开核查 -->
            <div v-if="m.role === 'assistant' && m.citations?.length" class="ds-citations">
              <button class="ds-cite-head" type="button" @click="toggleCitations(m.id)">
                <span class="ds-cite-dot" />
                引用了 {{ m.citations.length }} 条知识库片段
                <span class="ds-think-arrow" :class="{ 'is-open': openCitations[m.id] }">›</span>
              </button>
              <div v-show="openCitations[m.id]" class="ds-cite-body">
                <div v-for="(cite, index) in m.citations" :key="cite.chunkId || index" class="ds-cite-item">
                  <div class="ds-cite-title">
                    [{{ index + 1 }}] {{ cite.documentName || '未命名文档' }}
                    <span v-if="cite.score != null" class="ds-cite-score">相关度 {{ Number(cite.score).toFixed(2) }}</span>
                  </div>
                  <div class="ds-cite-snippet">{{ cite.snippet }}</div>
                </div>
              </div>
            </div>

            <!-- AI 消息操作条（失败时也要给「重试」入口，否则用户只能干等） -->
            <div v-if="m.role === 'assistant' && !m.streaming && (m.content || m.error)" class="ds-msg-actions">
              <button class="ds-msg-act" type="button" @click="onCopy(m)">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none">
                  <rect x="9" y="9" width="11" height="11" rx="2.5" stroke="currentColor" stroke-width="1.8" />
                  <path
d="M15 5.5A2.5 2.5 0 0 0 12.5 3h-7A2.5 2.5 0 0 0 3 5.5v7A2.5 2.5 0 0 0 5.5 15"
                        stroke="currentColor" stroke-width="1.8" stroke-linecap="round" />
                </svg>
                复制
              </button>
              <button
                v-if="regenerable"
                class="ds-msg-act"
                type="button"
                @click="emit('regenerate', m)"
              >
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none">
                  <path
d="M20 11a8 8 0 1 0-2.3 5.7" stroke="currentColor" stroke-width="1.8"
                        stroke-linecap="round" />
                  <path
d="M20 4v7h-7" stroke="currentColor" stroke-width="1.8"
                        stroke-linecap="round" stroke-linejoin="round" />
                </svg>
                {{ m.error ? '重试' : '重新生成' }}
              </button>
            </div>

            <!-- 附加插槽：业务侧可挂工具调用记录、意图标签、引用来源等自定义内容 -->
            <slot name="footer" :msg="m" />
          </div>
        </div>
      </div>
    </div>

    <!-- 回到底部 -->
    <Transition name="ds-fade">
      <button v-if="!atBottom && messages.length" class="ds-chat-down" type="button" @click="scrollToBottom(true)">
        ↓
      </button>
    </Transition>
  </div>
</template>

<style scoped>
.ds-chat { position: relative; flex: 1; min-height: 0; display: flex; }

.ds-chat-scroll {
  flex: 1;
  overflow-y: auto;
  padding: 20px 0 8px;
  scroll-behavior: auto;
}

/* ============ 空态 ============ */
.ds-chat-empty {
  height: 100%;
  min-height: 240px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 8px;
  text-align: center;
  padding: 0 20px;
}

.ds-chat-logo { color: var(--ds-brand); margin-bottom: 4px; }
.ds-chat-empty-title { font-size: 24px; font-weight: 600; margin: 0; }
.ds-chat-empty-desc { color: var(--ds-text-3); font-size: var(--ds-font-md); margin: 0; }

/* ============ 消息列表 ============ */
.ds-chat-list {
  max-width: var(--ds-content-max);
  margin: 0 auto;
  padding: 0 var(--ds-space-5);
  display: flex;
  flex-direction: column;
  gap: 22px;
}

.ds-msg { display: flex; gap: 10px; align-items: flex-start; }

/* 用户消息：整体右对齐 */
.ds-msg.is-user { justify-content: flex-end; }

.ds-msg-avatar {
  width: 28px;
  height: 28px;
  border-radius: 8px;
  background: var(--ds-bg-hover);
  color: var(--ds-brand);
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  margin-top: 2px;
}

.ds-msg-main { min-width: 0; max-width: 100%; }
.ds-msg.is-user .ds-msg-main { max-width: 78%; }

/* 用户气泡：蓝色 + 右下角收窄，贴 DeepSeek */
.ds-msg-bubble {
  background: var(--ds-bg-user);
  color: var(--ds-text-user);
  padding: 10px 14px;
  border-radius: var(--ds-radius-lg) var(--ds-radius-lg) 4px var(--ds-radius-lg);
  font-size: var(--ds-font-md);
  line-height: 1.7;
  white-space: pre-wrap;
  word-break: break-word;
}

.ds-msg-error {
  background: rgba(239, 68, 68, 0.08);
  border: 1px solid rgba(239, 68, 68, 0.25);
  color: var(--ds-danger);
  padding: 10px 14px;
  border-radius: var(--ds-radius-md);
  font-size: var(--ds-font-md);
}

/* ============ 思考过程 ============ */
.ds-think {
  margin-bottom: 10px;
  border: 1px solid var(--ds-border);
  border-radius: var(--ds-radius-md);
  background: var(--ds-bg-hover);
  overflow: hidden;
  max-width: 100%;
}

.ds-think-head {
  display: flex;
  align-items: center;
  gap: 8px;
  width: 100%;
  padding: 8px 12px;
  font-size: var(--ds-font-sm);
  color: var(--ds-text-3);
  text-align: left;
}

.ds-think-head:hover { color: var(--ds-text-2); }

/* 思考中的呼吸点 */
.ds-think-dot {
  width: 7px;
  height: 7px;
  border-radius: 50%;
  background: var(--ds-brand);
  animation: ds-blink 1.1s ease-in-out infinite;
  flex-shrink: 0;
}

.ds-think-arrow {
  margin-left: auto;
  transition: transform var(--ds-dur) var(--ds-ease);
  font-size: 16px;
  line-height: 1;
}

.ds-think-arrow.is-open { transform: rotate(90deg); }

.ds-think-body {
  padding: 0 12px 10px;
  font-size: var(--ds-font-sm);
  color: var(--ds-text-3);
  border-top: 1px dashed var(--ds-border);
  padding-top: 8px;
  max-height: 320px;
  overflow-y: auto;
}

/* ============ 引用来源 ============ */
.ds-citations {
  margin-top: 10px;
  border: 1px solid var(--ds-border);
  border-radius: var(--ds-radius-md);
  background: var(--ds-bg-hover);
  overflow: hidden;
  max-width: 100%;
}
.ds-cite-head {
  display: flex;
  align-items: center;
  gap: 8px;
  width: 100%;
  padding: 7px 12px;
  font-size: var(--ds-font-sm);
  color: var(--ds-text-3);
  text-align: left;
}
.ds-cite-head:hover { color: var(--ds-text-2); }
.ds-cite-dot {
  width: 6px; height: 6px; border-radius: 50%;
  background: var(--ds-brand);
  flex-shrink: 0;
}
.ds-cite-body { padding: 4px 12px 10px; border-top: 1px dashed var(--ds-border); }
.ds-cite-item { margin-top: 8px; }
.ds-cite-title { font-size: var(--ds-font-sm); font-weight: 600; color: var(--ds-text-2); }
.ds-cite-score { margin-left: 8px; font-size: var(--ds-font-xs); color: var(--ds-text-3); font-weight: 400; }
.ds-cite-snippet {
  margin-top: 3px;
  font-size: var(--ds-font-xs);
  color: var(--ds-text-3);
  line-height: 1.7;
}

/* ============ 操作条 ============ */
.ds-msg-actions { display: flex; gap: 4px; margin-top: 8px; }

.ds-msg-act {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  height: 26px;
  padding: 0 8px;
  border-radius: var(--ds-radius-sm);
  font-size: var(--ds-font-xs);
  color: var(--ds-text-3);
  transition: background-color var(--ds-dur-fast) var(--ds-ease), color var(--ds-dur-fast) var(--ds-ease);
}

.ds-msg-act:hover { background: var(--ds-bg-hover); color: var(--ds-text); }

/* ============ 回到底部 ============ */
.ds-chat-down {
  position: absolute;
  right: 20px;
  bottom: 12px;
  width: 32px;
  height: 32px;
  border-radius: 50%;
  background: var(--ds-bg-elevated);
  border: 1px solid var(--ds-border);
  box-shadow: var(--ds-shadow-md);
  color: var(--ds-text-2);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 2;
}

.ds-chat-down:hover { color: var(--ds-brand); border-color: var(--ds-brand); }

.ds-fade-enter-active, .ds-fade-leave-active { transition: opacity var(--ds-dur) var(--ds-ease); }
.ds-fade-enter-from, .ds-fade-leave-to { opacity: 0; }

@media (max-width: 768px) {
  .ds-chat-list { padding: 0 var(--ds-space-4); }
  .ds-msg.is-user .ds-msg-main { max-width: 86%; }
}
</style>
