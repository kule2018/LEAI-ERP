<!-- src/components/ds/DsCheckbox.vue -->
<script setup lang="ts">
/**
 * DsCheckbox —— 复选框（双模式）。
 *
 * 两种用法：
 *   1) 独立布尔：<DsCheckbox v-model="agree" /> —— modelValue 为 boolean；
 *   2) 组内成员：<DsCheckbox v-model="checkedList" value="apple" /> —— 传了 value 时
 *      modelValue 视为数组，勾选状态 = 数组是否包含该 value，切换时吐回新数组。
 *      这样不需要额外的 Group 组件，父组件一个数组即可管理多选框组。
 */
import { computed } from 'vue';

/** 组件入参 */
const props = withDefaults(
  defineProps<{
    /** 选中值：布尔（独立模式）或数组（组模式，需同时传 value） */
    modelValue: boolean | any[];
    /** 组模式下的选项值（传入即启用组模式） */
    value?: any;
    /** 是否禁用 */
    disabled?: boolean;
    /** 半选态（仅视觉，常用于「全选」父项） */
    indeterminate?: boolean;
    /** 尺寸：sm / md */
    size?: 'sm' | 'md';
  }>(),
  { disabled: false, indeterminate: false, size: 'md' },
);

/** 事件 */
const emit = defineEmits<{ (e: 'update:modelValue', v: boolean | any[]): void; (e: 'change', v: boolean | any[]): void }>();

/** 是否组模式 */
const isGroup = computed(() => props.value !== undefined);

/** 当前是否勾选 */
const checked = computed(() => {
  if (isGroup.value) return Array.isArray(props.modelValue) && props.modelValue.includes(props.value);
  return props.modelValue === true;
});

/**
 * 切换勾选：组模式吐新数组，独立模式吐布尔。
 * @returns 无
 */
function toggle(): void {
  if (props.disabled) return;
  let next: boolean | any[];
  if (isGroup.value) {
    const arr = Array.isArray(props.modelValue) ? [...props.modelValue] : [];
    const i = arr.indexOf(props.value);
    if (i >= 0) arr.splice(i, 1);
    else arr.push(props.value);
    next = arr;
  } else {
    next = !checked.value;
  }
  emit('update:modelValue', next);
  emit('change', next);
}
</script>

<template>
  <label class="ds-checkbox" :class="[`is-${size}`, { 'is-disabled': disabled, 'is-indeterminate': indeterminate }]" @click.prevent="toggle">
    <input type="checkbox" :checked="checked" :disabled="disabled" tabindex="-1" />
    <span class="ds-checkbox-label"><slot>{{ isGroup ? String(value) : '' }}</slot></span>
  </label>
</template>

<style scoped>
.ds-checkbox { display: inline-flex; align-items: center; gap: 8px; cursor: pointer; user-select: none; }
.ds-checkbox.is-sm { font-size: var(--ds-font-sm); }
.ds-checkbox.is-disabled { cursor: not-allowed; opacity: 0.55; }
.ds-checkbox-label { color: var(--ds-text-2); line-height: 1.5; }
</style>
