<!-- src/components/ds/DsCollapse.vue -->
<script setup lang="ts">
/**
 * DsCollapse —— 折叠面板。
 *
 * 手风琴（accordion）模式下同时只展开一个；非手风琴可同时展开多个。
 * 用 items 配置驱动，也支持默认插槽逐个放 DsCollapseItem。
 */
import { provide, computed } from 'vue';
import type { CollapseItem } from './types';


/** 组件入参 */
const props = withDefaults(
  defineProps<{
    /** 当前展开的值（v-model；手风琴为单值，普通模式为数组） */
    modelValue: string | string[];
    /** 面板配置（items 模式） */
    items?: CollapseItem[];
    /** 是否手风琴模式 */
    accordion?: boolean;
    /** 是否显示面板边框 */
    bordered?: boolean;
  }>(),
  { items: () => [], accordion: false, bordered: true },
);

/** 事件 */
const emit = defineEmits<{ (e: 'update:modelValue', v: string | string[]): void; (e: 'change', v: string | string[]): void }>();

/** 规范化当前展开值为数组，统一处理 */
const openList = computed<string[]>(() => {
  if (Array.isArray(props.modelValue)) return props.modelValue;
  return props.modelValue ? [props.modelValue] : [];
});

/**
 * 切换某个面板的展开态。
 * @param value 面板值
 * @returns 无
 */
function toggle(value: string): void {
  const isOpen = openList.value.includes(value);
  let next: string | string[];
  if (props.accordion) {
    // 手风琴：只保留当前操作的面板（再点一次 = 收起）
    next = isOpen ? '' : value;
  } else {
    const arr = [...openList.value];
    if (isOpen) arr.splice(arr.indexOf(value), 1);
    else arr.push(value);
    next = arr;
  }
  emit('update:modelValue', next);
  emit('change', next);
}

// 子项注入：让 DsCollapseItem 能拿到 accordion / toggle / 展开态
provide('ds-collapse', { accordion: props.accordion, toggle, isOpen: (v: string) => openList.value.includes(v) });
</script>

<template>
  <div class="ds-collapse" :class="{ 'is-bordered': bordered, 'is-accordion': accordion }">
    <!-- items 模式：标题 + 内容插槽 #content-{value} -->
    <template v-if="items.length">
      <div v-for="it in items" :key="it.value" class="ds-collapse-panel">
        <button
          type="button"
          class="ds-collapse-head"
          :class="{ 'is-open': openList.includes(it.value), 'is-disabled': it.disabled }"
          :disabled="it.disabled"
          @click="!it.disabled && toggle(it.value)"
        >
          <span class="ds-collapse-title">{{ it.label }}</span>
          <svg class="ds-collapse-arrow" viewBox="0 0 24 24" aria-hidden="true"><path d="m6 9 6 6 6-6" /></svg>
        </button>
        <div v-show="openList.includes(it.value)" class="ds-collapse-body">
          <slot :name="`content-${it.value}`" />
        </div>
      </div>
    </template>
    <!-- 插槽模式：直接放 DsCollapseItem -->
    <slot v-else />
  </div>
</template>

<style scoped>
.ds-collapse { display: flex; flex-direction: column; gap: 8px; }
.ds-collapse.is-bordered { gap: 0; }

.ds-collapse-panel { background: var(--ds-bg-elevated); }
.ds-collapse.is-bordered .ds-collapse-panel {
  border: 1px solid var(--ds-border);
  border-radius: var(--ds-radius-md);
  overflow: hidden;
}
.ds-collapse.is-bordered .ds-collapse-panel + .ds-collapse-panel {
  border-top: 1px solid var(--ds-border);
  border-radius: 0 0 var(--ds-radius-md) var(--ds-radius-md);
  margin-top: -1px
}
.ds-collapse.is-bordered .ds-collapse-panel:first-child { border-radius: var(--ds-radius-md) var(--ds-radius-md) 0 0; }
.ds-collapse.is-bordered .ds-collapse-panel:last-child { border-radius: 0 0 var(--ds-radius-md) var(--ds-radius-md); }

.ds-collapse-head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  width: 100%;
  padding: 12px 16px;
  border: 0;
  background: transparent;
  font-family: inherit;
  font-size: var(--ds-font-md);
  font-weight: 500;
  color: var(--ds-text);
  text-align: left;
  cursor: pointer;
  transition: background var(--ds-dur-fast) var(--ds-ease);
}
.ds-collapse-head:hover:not(:disabled) { background: var(--ds-bg-hover); }
.ds-collapse-head.is-open { color: var(--ds-brand); }
.ds-collapse-head.is-disabled { opacity: 0.5; cursor: not-allowed; }

.ds-collapse-arrow {
  width: 16px; height: 16px; flex: none;
  fill: none; stroke: currentColor; stroke-width: 2; stroke-linecap: round; stroke-linejoin: round;
  transition: transform var(--ds-dur) var(--ds-ease);
}
.ds-collapse-head.is-open .ds-collapse-arrow { transform: rotate(180deg); }

.ds-collapse-body {
  padding: 4px 16px 14px;
  font-size: var(--ds-font-sm);
  color: var(--ds-text-2);
  line-height: 1.7;
}
</style>
