<!-- src/components/ds/DsCollapseItem.vue -->
<script setup lang="ts">
/**
 * DsCollapseItem —— 折叠面板单项（DsCollapse 插槽模式的子组件）。
 *
 * 通过 inject 拿到父级 DsCollapse 的 toggle / 展开态，
 * 因此只能在 <DsCollapse> 内部使用。
 */
import { inject, computed } from 'vue';

/** 组件入参 */
const props = withDefaults(
  defineProps<{
    /** 唯一值 */
    value: string;
    /** 标题 */
    label?: string;
    /** 是否禁用 */
    disabled?: boolean;
  }>(),
  { label: '', disabled: false },
);

/** 父级注入的折叠上下文 */
const ctx = inject<{
  accordion: boolean;
  toggle: (v: string) => void;
  isOpen: (v: string) => boolean;
} | null>('ds-collapse', null);

/** 是否展开 */
const isOpen = computed(() => !!ctx?.isOpen(props.value));

/**
 * 点击标题切换展开。
 * @returns 无
 */
function onClick(): void {
  if (props.disabled) return;
  ctx?.toggle(props.value);
}
</script>

<template>
  <div class="ds-collapse-item" :class="{ 'is-open': isOpen }">
    <button
      type="button"
      class="ds-collapse-item__head"
      :class="{ 'is-disabled': disabled }"
      :disabled="disabled"
      @click="onClick"
    >
      <span class="ds-collapse-item__title"><slot name="label">{{ label }}</slot></span>
      <svg class="ds-collapse-item__arrow" viewBox="0 0 24 24" aria-hidden="true"><path d="m6 9 6 6 6-6" /></svg>
    </button>
    <div v-show="isOpen" class="ds-collapse-item__body">
      <slot />
    </div>
  </div>
</template>

<style scoped>
.ds-collapse-item {
  background: var(--ds-bg-elevated);
  border: 1px solid var(--ds-border);
  border-radius: var(--ds-radius-md);
  overflow: hidden;
}
.ds-collapse-item + .ds-collapse-item { margin-top: 8px; }

.ds-collapse-item__head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  width: 100%;
  padding: 12px 16px;
  border: 0;
  background: transparent;
  font-family: inherit;
  font-size: var(--ds-font-md);
  font-weight: 500;
  color: var(--ds-text);
  text-align: left;
  cursor: pointer;
  transition: background var(--ds-dur-fast) var(--ds-ease);
}
.ds-collapse-item__head:hover:not(:disabled) { background: var(--ds-bg-hover); }
.ds-collapse-item.is-open .ds-collapse-item__head { color: var(--ds-brand); }
.ds-collapse-item__head.is-disabled { opacity: 0.5; cursor: not-allowed; }

.ds-collapse-item__arrow {
  width: 16px; height: 16px; flex: none;
  fill: none; stroke: currentColor; stroke-width: 2; stroke-linecap: round; stroke-linejoin: round;
  transition: transform var(--ds-dur) var(--ds-ease);
}
.ds-collapse-item.is-open .ds-collapse-item__arrow { transform: rotate(180deg); }

.ds-collapse-item__body {
  padding: 4px 16px 14px;
  font-size: var(--ds-font-sm);
  color: var(--ds-text-2);
  line-height: 1.7;
}
</style>
