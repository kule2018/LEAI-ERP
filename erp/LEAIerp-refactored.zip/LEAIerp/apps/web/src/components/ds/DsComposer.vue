<!-- src/components/ds/DsComposer.vue -->
<script setup lang="ts">
/**
 * 输入区（DeepSeek 同款大输入框）
 * ------------------------------------------------------------------
 * 交互要点（对齐 DeepSeek）：
 *   1) 一个圆角大卡片，上半部分是自增高 textarea，下半部分是工具行；
 *   2) 工具行左侧是「深度思考 / 联网搜索」两个可切换的胶囊按钮，右侧是发送；
 *   3) Enter 发送、Shift+Enter 换行，IME 输入法组合期间不触发发送；
 *   4) 生成中发送按钮变成「停止」方块按钮；
 *   5) 底部提示：内容由 AI 生成，请谨慎甄别。
 */
import { ref, computed, nextTick, watch } from 'vue';

/** 组件入参 */
const props = withDefaults(
  defineProps<{
    /** 输入内容（v-model） */
    modelValue: string;
    /** 占位文案 */
    placeholder?: string;
    /** 是否处于生成中（发送按钮变为停止） */
    streaming?: boolean;
    /** 是否禁用 */
    disabled?: boolean;
    /** 最大输入长度 */
    maxLength?: number;
    /** 是否显示「深度思考」开关 */
    showReasoning?: boolean;
    /** 是否显示「联网搜索」开关 */
    showSearch?: boolean;
    /** 底部免责说明（空则不显示） */
    disclaimer?: string;
  }>(),
  {
    placeholder: '给 AI 发送消息…',
    streaming: false,
    disabled: false,
    maxLength: 4000,
    showReasoning: false,
    showSearch: false,
    disclaimer: '内容由 AI 生成，请仔细甄别',
  },
);

/** 事件 */
const emit = defineEmits<{
  (e: 'update:modelValue', v: string): void;
  (e: 'send', text: string): void;
  (e: 'stop'): void;
  (e: 'update:reasoning', v: boolean): void;
  (e: 'update:search', v: boolean): void;
}>();

/** textarea 元素引用 */
const taRef = ref<HTMLTextAreaElement | null>(null);
/** 输入法组合态标记：中文候选框弹出时不应触发发送 */
const composing = ref(false);
/** 深度思考开关 */
const reasoning = ref(false);
/** 联网搜索开关 */
const search = ref(false);

/** 是否可以发送：有内容且不在生成中 */
const canSend = computed(() => !!props.modelValue.trim() && !props.streaming && !props.disabled);

/**
 * 输入时同步到父组件，并自动调整高度。
 */
function onInput(): void {
  emit('update:modelValue', (taRef.value?.value ?? ''));
  autoGrow();
}

/**
 * 自适应高度：先归零再取 scrollHeight，最高 200px 后转为内部滚动。
 */
function autoGrow(): void {
  const el = taRef.value;
  if (!el) return;
  el.style.height = 'auto';
  el.style.height = `${Math.min(el.scrollHeight, 200)}px`;
}

/**
 * 键盘处理：
 *   - Enter：发送（Shift+Enter 换行）
 *   - Cmd/Ctrl+Enter：强制发送（不换行，兼容习惯用快捷键发送的用户）
 *   - Esc：生成中中断输出
 * @param e 键盘事件
 */
function onKeydown(e: KeyboardEvent): void {
  // 输入法组合中（如拼音候选）直接放行，避免回车上屏误发送
  if (composing.value) return;

  // Esc：生成中停止；非生成态交还给页面（如关闭弹层）
  if (e.key === 'Escape') {
    if (props.streaming) {
      e.preventDefault();
      emit('stop');
    }
    return;
  }

  if (e.key !== 'Enter') return;

  // Cmd/Ctrl+Enter：显式发送
  if (e.metaKey || e.ctrlKey) {
    e.preventDefault();
    doSend();
    return;
  }

  // Enter：发送；Shift+Enter：换行
  if (!e.shiftKey) {
    e.preventDefault();
    doSend();
  }
}

/**
 * 点击发送（或停止）。
 */
function doSend(): void {
  if (props.streaming) { emit('stop'); return; }
  if (!canSend.value) return;
  emit('send', props.modelValue.trim());
}

/** 切换开关时同步给父组件 */
function toggleReasoning(): void {
  reasoning.value = !reasoning.value;
  emit('update:reasoning', reasoning.value);
}

function toggleSearch(): void {
  search.value = !search.value;
  emit('update:search', search.value);
}

/** 清空输入并把高度复位（发送成功后由父组件调用） */
function reset(): void {
  emit('update:modelValue', '');
  void nextTick(() => {
    if (taRef.value) taRef.value.style.height = 'auto';
  });
}

// 外部清空内容时同步复位高度
watch(
  () => props.modelValue,
  (v) => { if (!v) void nextTick(autoGrow); },
);

/** 对外暴露：清空、聚焦 */
defineExpose({ reset, focus: () => taRef.value?.focus() });
</script>

<template>
  <div class="ds-composer" :class="{ 'is-disabled': disabled }">
    <!-- 输入卡片 -->
    <div class="ds-composer-box">
      <textarea
        ref="taRef"
        class="ds-composer-input"
        :value="modelValue"
        :placeholder="placeholder"
        :disabled="disabled"
        :maxlength="maxLength"
        rows="1"
        @input="onInput"
        @keydown="onKeydown"
        @compositionstart="composing = true"
        @compositionend="composing = false"
      />

      <!-- 工具行 -->
      <div class="ds-composer-bar">
        <div class="ds-composer-tools">
          <!-- 深度思考：开启后高亮为品牌浅底 -->
          <button
            v-if="showReasoning"
            class="ds-chip"
            :class="{ 'is-on': reasoning }"
            type="button"
            @click="toggleReasoning"
          >
            <span class="ds-chip-dot" />深度思考
          </button>

          <!-- 联网搜索 -->
          <button
            v-if="showSearch"
            class="ds-chip"
            :class="{ 'is-on': search }"
            type="button"
            @click="toggleSearch"
          >
            <span class="ds-chip-globe" />联网搜索
          </button>

          <!-- 附件 / 额外操作插槽 -->
          <slot name="tools" />
        </div>

        <div class="ds-composer-right">
          <!-- 字数提示（接近上限才显示） -->
          <span v-if="modelValue.length > maxLength * 0.8" class="ds-composer-count">
            {{ modelValue.length }}/{{ maxLength }}
          </span>

          <!-- 发送 / 停止 -->
          <button
            class="ds-send"
            :class="{ 'is-stop': streaming, 'is-active': canSend }"
            type="button"
            :disabled="!canSend && !streaming"
            :aria-label="streaming ? '停止生成' : '发送'"
            @click="doSend"
          >
            <span v-if="streaming" class="ds-send-stop" />
            <svg v-else width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden="true">
              <path
d="M12 19V5M12 5l-6 6M12 5l6 6" stroke="currentColor" stroke-width="2"
                    stroke-linecap="round" stroke-linejoin="round" />
            </svg>
          </button>
        </div>
      </div>
    </div>

    <!-- 底部说明 -->
    <p v-if="disclaimer" class="ds-composer-tip">
      {{ disclaimer }}
      <span class="ds-composer-keys">Enter 发送 · Shift+Enter 换行 · Cmd/Ctrl+Enter 发送 · Esc 停止生成</span>
    </p>
  </div>
</template>

<style scoped>
.ds-composer { width: 100%; }

.ds-composer-box {
  background: var(--ds-bg-elevated);
  border: 1px solid var(--ds-border);
  border-radius: var(--ds-radius-xl);
  padding: 12px 12px 8px;
  box-shadow: var(--ds-shadow-sm);
  transition: border-color var(--ds-dur) var(--ds-ease), box-shadow var(--ds-dur) var(--ds-ease);
}

/* 聚焦时整块高亮，和 DeepSeek 一致 */
.ds-composer-box:focus-within {
  border-color: var(--ds-brand);
  box-shadow: var(--ds-shadow-md), var(--ds-shadow-focus);
}

.ds-composer.is-disabled .ds-composer-box { opacity: 0.6; }

.ds-composer-input {
  width: 100%;
  border: none;
  outline: none;
  resize: none;
  background: transparent;
  font-size: var(--ds-font-md);
  line-height: 1.65;
  color: var(--ds-text);
  max-height: 200px;
  padding: 4px 6px;
  font-family: inherit;
}

.ds-composer-input::placeholder { color: var(--ds-text-3); }

/* ============ 工具行 ============ */
.ds-composer-bar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 10px;
  padding-top: 8px;
}

.ds-composer-tools { display: flex; align-items: center; gap: 8px; flex-wrap: wrap; }
.ds-composer-right { display: flex; align-items: center; gap: 10px; }

/* 胶囊开关 */
.ds-chip {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  height: 30px;
  padding: 0 12px;
  border-radius: var(--ds-radius-full);
  border: 1px solid var(--ds-border);
  background: var(--ds-bg-elevated);
  color: var(--ds-text-2);
  font-size: var(--ds-font-sm);
  transition: all var(--ds-dur-fast) var(--ds-ease);
}

.ds-chip:hover { border-color: var(--ds-border-strong); color: var(--ds-text); }

.ds-chip.is-on {
  background: var(--ds-brand-soft);
  border-color: var(--ds-brand);
  color: var(--ds-brand);
}

/* 胶囊里的小圆点（深度思考） */
.ds-chip-dot {
  width: 7px;
  height: 7px;
  border-radius: 50%;
  background: var(--ds-text-3);
}

.ds-chip.is-on .ds-chip-dot { background: var(--ds-brand); }

/* 胶囊里的小地球（联网搜索）：用 CSS 画两个椭圆 */
.ds-chip-globe {
  width: 11px;
  height: 11px;
  border-radius: 50%;
  border: 1.4px solid currentColor;
  position: relative;
  opacity: 0.85;
}

.ds-chip-globe::after {
  content: '';
  position: absolute;
  inset: 1.5px 0;
  border-top: 1.4px solid currentColor;
  border-bottom: 1.4px solid currentColor;
  border-radius: 50%;
}

.ds-composer-count { font-size: var(--ds-font-xs); color: var(--ds-text-3); }

/* ============ 发送按钮 ============ */
.ds-send {
  width: 34px;
  height: 34px;
  border-radius: var(--ds-radius-full);
  display: inline-flex;
  align-items: center;
  justify-content: center;
  background: var(--ds-bg-hover);
  color: var(--ds-text-3);
  transition: all var(--ds-dur-fast) var(--ds-ease);
  flex-shrink: 0;
}

.ds-send.is-active { background: var(--ds-brand); color: #fff; }
.ds-send.is-active:hover { background: var(--ds-brand-hover); }
.ds-send.is-stop { background: var(--ds-text-2); color: #fff; }
.ds-send:disabled { opacity: 0.5; }

.ds-send-stop {
  width: 12px;
  height: 12px;
  border-radius: 2px;
  background: currentColor;
}

.ds-composer-tip {
  margin: 8px 0 0;
  text-align: center;
  font-size: var(--ds-font-xs);
  color: var(--ds-text-3);
}

/* 快捷键提示 */
.ds-composer-keys {
  display: block;
  margin-top: 2px;
  font-size: var(--ds-font-xs);
  color: var(--ds-text-3);
  opacity: 0.8;
}
</style>
