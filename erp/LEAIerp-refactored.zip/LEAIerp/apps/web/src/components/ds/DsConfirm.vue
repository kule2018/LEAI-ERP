<!-- src/components/ds/DsConfirm.vue -->
<script setup lang="ts">
/**
 * 全局确认弹窗：与 useConfirm 的 confirm() 配套。
 * 在 App.vue 挂载一次即可，业务侧无需关心渲染。
 */
import { confirmState, resolveConfirm } from './useConfirm';

/** 点击遮罩视为取消 */
function onUpdateVisible(v: boolean): void {
  if (!v) resolveConfirm(false);
}
</script>

<template>
  <DsModal
    :model-value="confirmState.visible"
    :title="confirmState.title"
    :width="420"
    :close-on-mask="false"
    :resizable="false"
    @update:model-value="onUpdateVisible"
  >
    <p class="ds-confirm-msg">{{ confirmState.message }}</p>
    <template #footer>
      <div class="ds-confirm-foot">
        <DsButton @click="resolveConfirm(false)">取消</DsButton>
        <DsButton variant="primary" @click="resolveConfirm(true)">确定</DsButton>
      </div>
    </template>
  </DsModal>
</template>

<style scoped>
.ds-confirm-msg {
  margin: 0;
  color: var(--ds-text-2);
  font-size: var(--ds-font-md);
  line-height: 1.6;
  word-break: break-all;
}
.ds-confirm-foot {
  display: flex;
  justify-content: flex-end;
  gap: 8px;
}
</style>
