<!-- src/components/ds/DsDatePicker.vue -->
<script setup lang="ts">
/**
 * DsDatePicker —— 日期 / 时间选择器（自绘，无第三方日历库）。
 *
 * 支持三种形态：
 *   date     仅日期（YYYY-MM-DD）
 *   datetime 日期 + 时分（YYYY-MM-DD HH:mm）
 *   time     仅时分（HH:mm）
 * 交互：点击输入框展开日历面板；←/→ 翻年月，Enter 选中今日，Esc 收起；
 * 时间部分用数字输入（24 小时制），失焦时自动补零。
 */
import { computed, ref, watch } from 'vue';
import { usePopover } from './usePopover';

/** 星期表头（周日历，与 Date.getDay() 对应） */
const WEEK = ['日', '一', '二', '三', '四', '五', '六'];

/** 组件入参 */
const props = withDefaults(
  defineProps<{
    /** 选中值（v-model，字符串格式见组件说明） */
    modelValue: string;
    /** 形态：date / datetime / time */
    type?: 'date' | 'datetime' | 'time';
    /** 占位文案 */
    placeholder?: string;
    /** 是否禁用 */
    disabled?: boolean;
    /** 是否可清空 */
    clearable?: boolean;
  }>(),
  { type: 'date', placeholder: '请选择日期', disabled: false, clearable: true },
);

/** 事件 */
const emit = defineEmits<{ (e: 'update:modelValue', v: string): void; (e: 'change', v: string): void }>();

// 浮层控制
const { open, rootRef, toggle, close } = usePopover();
void rootRef;

/** 解析 modelValue 得到日期部分与时间部分 */
const parsed = computed(() => {
  const raw = props.modelValue || '';
  if (props.type === 'time') {
    const m = raw.match(/^(\d{1,2}):(\d{1,2})/);
    return { date: '', hh: m ? m[1] : '', mm: m ? m[2] : '' };
  }
  const m = raw.match(/^(\d{4})-(\d{1,2})-(\d{1,2})(?:\s+(\d{1,2}):(\d{1,2}))?/);
  return {
    date: m ? `${m[1]}-${pad(m[2])}-${pad(m[3])}` : '',
    hh: m?.[4] ?? '',
    mm: m?.[5] ?? '',
  };
});

/** 两位数补零 */
function pad(n: string | number): string {
  return String(n).padStart(2, '0');
}

/** 面板当前视图年月（"2026-10"）；默认取选中值或今天 */
const view = ref(parsed.value.date ? parsed.value.date.slice(0, 7) : monthOf(new Date()));
/** 时间编辑态（datetime / time 用） */
const hh = ref(parsed.value.hh);
const mm = ref(parsed.value.mm);

/** 取某日期的 "YYYY-MM" */
function monthOf(d: Date): string {
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}`;
}

/** 取某日期是否被选中 */
function isSameDay(y: number, m: number, d: number): boolean {
  return parsed.value.date === `${y}-${pad(m)}-${pad(d)}`;
}

/** 是否是今天 */
function isToday(y: number, m: number, d: number): boolean {
  const n = new Date();
  return n.getFullYear() === y && n.getMonth() + 1 === m && n.getDate() === d;
}

/** 当前视图的 42 格日历（含上下月补白） */
const cells = computed(() => {
  const [y, m] = view.value.split('-').map(Number);
  const first = new Date(y, m - 1, 1);
  const startIdx = first.getDay(); // 本月 1 号是周几
  const out: { y: number; m: number; d: number; out: boolean }[] = [];
  // 向上补上个月尾巴
  const prevDays = new Date(y, m - 1, 0).getDate();
  for (let i = startIdx - 1; i >= 0; i--) {
    const pm = m === 1 ? 12 : m - 1;
    const py = m === 1 ? y - 1 : y;
    out.push({ y: py, m: pm, d: prevDays - i, out: true });
  }
  // 本月
  const days = new Date(y, m, 0).getDate();
  for (let d = 1; d <= days; d++) out.push({ y, m, d, out: false });
  // 向下补下个月开头，凑满 42 格
  let nd = 1;
  while (out.length < 42) {
    const nm = m === 12 ? 1 : m + 1;
    const ny = m === 12 ? y + 1 : y;
    out.push({ y: ny, m: nm, d: nd++, out: true });
  }
  return out;
});

/** 面板标题（"2026 年 10 月"） */
const viewTitle = computed(() => {
  const [y, m] = view.value.split('-');
  return `${y} 年 ${Number(m)} 月`;
});

/** 上 / 下月翻页 */
function shiftMonth(delta: number): void {
  const [y, m] = view.value.split('-').map(Number);
  const d = new Date(y, m - 1 + delta, 1);
  view.value = monthOf(d);
}

/**
 * 组装并提交值：把面板上的日期与编辑态的时间拼成字符串。
 * @param dateStr "YYYY-MM-DD"（time 模式下传空串）
 * @returns 无
 */
function commit(dateStr: string): void {
  let v = dateStr;
  if (props.type === 'datetime') v = `${dateStr} ${pad(hh.value || '0')}:${pad(mm.value || '0')}`;
  if (props.type === 'time') v = `${pad(hh.value || '0')}:${pad(mm.value || '0')}`;
  emit('update:modelValue', v);
  emit('change', v);
  if (props.type !== 'datetime') close();
}

/**
 * 点击某天：写入日期；datetime 模式保持面板打开以便继续选时间。
 * @param c 日期格
 * @returns 无
 */
function pickDay(c: { y: number; m: number; d: number }): void {
  if (props.disabled || props.type === 'time') return;
  commit(`${c.y}-${pad(c.m)}-${pad(c.d)}`);
}

/** 清空 */
function clearValue(): void {
  emit('update:modelValue', '');
  emit('change', '');
}

/**
 * 时间输入规范化：只留数字、夹到合法范围、失焦补零。
 * @param which 小时还是分钟
 * @returns 无
 */
function onTimeInput(which: 'hh' | 'mm'): void {
  const max = which === 'hh' ? 23 : 59;
  let v = (which === 'hh' ? hh.value : mm.value).replace(/\D/g, '');
  const n = Number(v || 0);
  if (n > max) v = String(max);
  if (which === 'hh') hh.value = v;
  else mm.value = v;
}

/** 时间输入失焦：补零并同步值 */
function onTimeBlur(): void {
  hh.value = pad(Number(hh.value || 0));
  mm.value = pad(Number(mm.value || 0));
  if (props.modelValue) commit(parsed.value.date);
}

// 外部值变化时同步面板与时间编辑态
watch(
  () => props.modelValue,
  () => {
    const p = parsed.value;
    if (p.date) view.value = p.date.slice(0, 7);
    hh.value = p.hh;
    mm.value = p.mm;
  },
);
</script>

<template>
  <div ref="rootRef" class="ds-dp" :class="{ 'is-disabled': disabled, 'is-open': open }">
    <!-- 触发器 -->
    <div class="ds-dp-trigger" @click="!disabled && toggle()">
      <svg class="ds-dp-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M8 2v4M16 2v4M3 10h18M5 4h14a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2Z" /></svg>
      <span class="ds-dp-text" :class="{ 'is-ph': !modelValue }">{{ modelValue || placeholder }}</span>
      <button v-if="clearable && modelValue && !disabled" type="button" class="ds-dp-clear" title="清空" @click.stop="clearValue">✕</button>
    </div>

    <!-- 面板 -->
    <div v-if="open" class="ds-dp-pop">
      <!-- 时间模式：只有时分 -->
      <template v-if="type === 'time'">
        <div class="ds-dp-time">
          <input :value="hh" maxlength="2" placeholder="时" @input="onTimeInput('hh')" @blur="onTimeBlur" />
          <span>:</span>
          <input :value="mm" maxlength="2" placeholder="分" @input="onTimeInput('mm')" @blur="onTimeBlur" />
        </div>
        <div class="ds-dp-foot">
          <button type="button" class="ds-dp-now" @click="hh = pad(new Date().getHours()); mm = pad(new Date().getMinutes()); commit('')">此刻</button>
        </div>
      </template>

      <!-- 日期 / 日期时间 -->
      <template v-else>
        <!-- 头部：翻页 + 年月标题 -->
        <div class="ds-dp-head">
          <button type="button" title="上个月" @click="shiftMonth(-1)">‹</button>
          <span>{{ viewTitle }}</span>
          <button type="button" title="下个月" @click="shiftMonth(1)">›</button>
        </div>
        <!-- 星期表头 -->
        <div class="ds-dp-weeks">
          <span v-for="w in WEEK" :key="w">{{ w }}</span>
        </div>
        <!-- 日期格 -->
        <div class="ds-dp-grid">
          <button
            v-for="(c, i) in cells"
            :key="i"
            type="button"
            class="ds-dp-cell"
            :class="{ 'is-out': c.out, 'is-sel': isSameDay(c.y, c.m, c.d), 'is-today': isToday(c.y, c.m, c.d) }"
            @click="pickDay(c)"
          >
            {{ c.d }}
          </button>
        </div>
        <!-- datetime：日历下方补一行时间输入 -->
        <div v-if="type === 'datetime'" class="ds-dp-time">
          <input :value="hh" maxlength="2" placeholder="时" @input="onTimeInput('hh')" @blur="onTimeBlur" />
          <span>:</span>
          <input :value="mm" maxlength="2" placeholder="分" @input="onTimeInput('mm')" @blur="onTimeBlur" />
        </div>
        <div class="ds-dp-foot">
          <button type="button" class="ds-dp-now" @click="pickDay({ y: new Date().getFullYear(), m: new Date().getMonth() + 1, d: new Date().getDate() })">今天</button>
        </div>
      </template>
    </div>
  </div>
</template>

<style scoped>
.ds-dp { position: relative; width: 100%; }

.ds-dp-trigger {
  display: flex;
  align-items: center;
  gap: 8px;
  min-height: var(--ds-ctl-h-md);
  padding: 0 10px;
  background: var(--ds-bg-elevated);
  border: 1px solid var(--ds-border);
  border-radius: var(--ds-radius-sm);
  cursor: pointer;
  transition: border-color var(--ds-dur-fast) var(--ds-ease), box-shadow var(--ds-dur-fast) var(--ds-ease);
}
.ds-dp-trigger:hover { border-color: var(--ds-border-strong); }
.ds-dp.is-open:not(.is-disabled) .ds-dp-trigger { border-color: var(--ds-brand); box-shadow: 0 0 0 3px var(--ds-brand-soft); }
.ds-dp.is-disabled .ds-dp-trigger { background: var(--ds-bg-hover); cursor: not-allowed; }

.ds-dp-icon {
  width: 15px;
  height: 15px;
  flex: none;
  fill: none;
  stroke: var(--ds-text-3);
  stroke-width: 1.8;
  stroke-linecap: round;
  stroke-linejoin: round;
}
.ds-dp-text { flex: 1; min-width: 0; color: var(--ds-text); font-size: var(--ds-font-md); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.ds-dp-text.is-ph { color: var(--ds-text-3); }
.ds-dp-clear {
  border: 0; background: transparent; color: var(--ds-text-3);
  cursor: pointer; font-size: var(--ds-font-xs); padding: 2px; border-radius: var(--ds-radius-xs);
}
.ds-dp-clear:hover { background: var(--ds-bg-hover); color: var(--ds-text); }

/* ---- 面板 ---- */
.ds-dp-pop {
  position: absolute;
  top: calc(100% + 6px);
  left: 0;
  z-index: 100;
  width: 252px;
  padding: 10px;
  background: var(--ds-bg-elevated);
  border: 1px solid var(--ds-border);
  border-radius: var(--ds-radius);
  box-shadow: var(--ds-shadow-md);
}

.ds-dp-head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 8px;
  font-size: var(--ds-font-md);
  font-weight: 600;
  color: var(--ds-text);
}
.ds-dp-head button {
  width: 26px;
  height: 26px;
  border: 0;
  border-radius: var(--ds-radius-xs);
  background: transparent;
  color: var(--ds-text-2);
  font-size: 15px;
  cursor: pointer;
  line-height: 1;
}
.ds-dp-head button:hover { background: var(--ds-bg-hover); color: var(--ds-text); }

.ds-dp-weeks {
  display: grid;
  grid-template-columns: repeat(7, 1fr);
  margin-bottom: 2px;
}
.ds-dp-weeks span {
  text-align: center;
  font-size: var(--ds-font-xs);
  color: var(--ds-text-3);
  padding: 4px 0;
}

.ds-dp-grid {
  display: grid;
  grid-template-columns: repeat(7, 1fr);
  gap: 2px;
}
.ds-dp-cell {
  height: 30px;
  border: 0;
  border-radius: var(--ds-radius-xs);
  background: transparent;
  color: var(--ds-text-2);
  font-size: var(--ds-font-sm);
  font-family: inherit;
  cursor: pointer;
  transition: background var(--ds-dur-fast) var(--ds-ease);
}
.ds-dp-cell:hover { background: var(--ds-bg-hover); }
.ds-dp-cell.is-out { color: var(--ds-text-3); opacity: 0.6; }
.ds-dp-cell.is-today { color: var(--ds-brand); font-weight: 600; }
.ds-dp-cell.is-sel { background: var(--ds-brand); color: #fff; font-weight: 600; }
.ds-dp-cell.is-sel:hover { background: var(--ds-brand-hover); }

/* 时间输入行 */
.ds-dp-time {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  margin-top: 8px;
  padding-top: 8px;
  border-top: 1px solid var(--ds-divider);
}
.ds-dp-time input {
  width: 52px;
  height: 30px;
  text-align: center;
  border: 1px solid var(--ds-border);
  border-radius: var(--ds-radius-xs);
  background: var(--ds-bg);
  color: var(--ds-text);
  font-size: var(--ds-font-md);
  font-family: inherit;
  outline: none;
}
.ds-dp-time input:focus { border-color: var(--ds-brand); }
.ds-dp-time span { color: var(--ds-text-3); }

.ds-dp-foot {
  margin-top: 8px;
  text-align: right;
}
.ds-dp-now {
  border: 0;
  background: transparent;
  color: var(--ds-brand);
  font-size: var(--ds-font-sm);
  cursor: pointer;
  padding: 4px 8px;
  border-radius: var(--ds-radius-xs);
}
.ds-dp-now:hover { background: var(--ds-brand-soft); }
</style>
