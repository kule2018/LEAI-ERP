<!-- src/components/ds/DsDescriptions.vue -->
<script setup lang="ts">
/**
 * DsDescriptions —— 描述列表（详情页字段展示）。
 *
 * 按 items 配置渲染「标签: 值」网格：支持跨列（span）、边框（bordered）、
 * 列数（column）与字段级插槽（#item-{key}）。
 * 空值统一显示「-」，与 DetailDrawer 的历史行为保持一致。
 */
import { computed } from 'vue';
import type { DescItem } from './types';


/** 组件入参 */
const props = withDefaults(
  defineProps<{
    /** 描述项配置 */
    items: DescItem[];
    /** 详情数据 */
    data?: Record<string, any>;
    /** 每行列数 */
    column?: number;
    /** 是否显示边框 */
    bordered?: boolean;
    /** 空值占位文案 */
    emptyText?: string;
  }>(),
  { data: () => ({}), column: 2, bordered: true, emptyText: '-' },
);

/**
 * 取字段展示值：插槽 > formatter > 默认规则（空值占位）。
 * @param it 描述项
 * @returns 展示值
 */
function valueOf(it: DescItem): string {
  const raw = props.data?.[it.key];
  if (it.formatter) return String(it.formatter(raw) ?? props.emptyText);
  if (raw === null || raw === undefined || raw === '') return props.emptyText;
  if (typeof raw === 'boolean') return raw ? '是' : '否';
  return String(raw);
}

/** 按列数切分成行 */
const rows = computed(() => {
  const out: DescItem[][] = [];
  let cur: DescItem[] = [];
  let used = 0;
  for (const it of props.items) {
    const span = Math.min(it.span ?? 1, props.column);
    if (used + span > props.column) {
      out.push(cur);
      cur = [];
      used = 0;
    }
    cur.push(it);
    used += span;
    if (used >= props.column) {
      out.push(cur);
      cur = [];
      used = 0;
    }
  }
  if (cur.length) out.push(cur);
  return out;
});
</script>

<template>
  <div class="ds-desc" :class="{ 'is-bordered': bordered }">
    <div v-for="(row, ri) in rows" :key="ri" class="ds-desc-row">
      <template v-for="it in row" :key="it.key">
        <!-- 标签 -->
        <div class="ds-desc-label" :style="{ flex: `0 0 ${(it.span ?? 1) * 100}%`, maxWidth: (it.span ?? 1) * 100 + '%' }">
          {{ it.label }}
        </div>
        <!-- 值 -->
        <div class="ds-desc-value">
          <slot :name="`item-${it.key}`" :value="data?.[it.key]">{{ valueOf(it) }}</slot>
        </div>
      </template>
    </div>
  </div>
</template>

<style scoped>
.ds-desc {
  width: 100%;
  font-size: var(--ds-font-sm);
  border-radius: var(--ds-radius-md);
  overflow: hidden;
}
.ds-desc-row {
  display: flex;
  align-items: stretch;
}
.ds-desc-row + .ds-desc-row { margin-top: -1px; }

/* 无边框：标签淡色、值常规 */
.ds-desc:not(.is-bordered) .ds-desc-label {
  color: var(--ds-text-3);
  padding: 8px 12px 8px 0;
}
.ds-desc:not(.is-bordered) .ds-desc-value {
  padding: 8px 12px 8px 0;
}

/* 有边框：网格线 + 浅灰标签底 */
.ds-desc.is-bordered { border: 1px solid var(--ds-border); }
.ds-desc.is-bordered .ds-desc-label {
  background: var(--ds-bg-soft);
  color: var(--ds-text-2);
  padding: 10px 14px;
  border-right: 1px solid var(--ds-border);
  border-bottom: 1px solid var(--ds-border);
  font-weight: 500;
}
.ds-desc.is-bordered .ds-desc-value {
  padding: 10px 14px;
  border-bottom: 1px solid var(--ds-border);
  color: var(--ds-text);
  flex: 1;
  min-width: 0;
  word-break: break-word;
}
.ds-desc.is-bordered .ds-desc-row:last-child .ds-desc-label,
.ds-desc.is-bordered .ds-desc-row:last-child .ds-desc-value {
  border-bottom: none;
}
</style>
