<!-- src/components/ds/DsDivider.vue -->
<script setup lang="ts">
/**
 * DsDivider —— 分割线。
 *
 * 水平 / 垂直两种方向；可带文字（如「或」）居中或偏置；
 * 线条颜色用更浅的 --ds-divider，避免在卡片里显得突兀。
 */
withDefaults(
  defineProps<{
    /** 方向：horizontal 水平 / vertical 垂直 */
    orientation?: 'horizontal' | 'vertical';
    /** 文字位置（仅水平 + 有文字时）：left / center / right */
    align?: 'left' | 'center' | 'right';
    /** 是否虚线 */
    dashed?: boolean;
    /** 垂直方向的高度（CSS 值） */
    height?: string;
  }>(),
  { orientation: 'horizontal', align: 'center', dashed: false, height: '1em' },
);
</script>

<template>
  <!-- 水平分割线 -->
  <div
    v-if="orientation === 'horizontal'"
    class="ds-divider"
    :class="[`is-${align}`, { 'is-dashed': dashed, 'has-text': !!$slots.default }]"
    role="separator"
  >
    <span v-if="$slots.default" class="ds-divider-text"><slot /></span>
  </div>

  <!-- 垂直分割线 -->
  <span
    v-else
    class="ds-divider is-vertical"
    :class="{ 'is-dashed': dashed }"
    :style="{ height }"
    role="separator"
  />
</template>

<style scoped>
.ds-divider {
  border: none;
  margin: 0;
  background: var(--ds-divider);
}
/* 水平：1px 高，通栏 */
.ds-divider:not(.is-vertical) {
  width: 100%;
  height: 1px;
  margin: 16px 0;
  display: flex;
  align-items: center;
  justify-content: center;
}
.ds-divider.is-dashed:not(.is-vertical) {
  background: none;
  border-top: 1px dashed var(--ds-divider);
  height: 0;
}
/* 带文字：文字两侧的线用渐变绘制 */
.ds-divider.has-text {
  background: none;
  height: auto;
  gap: 12px;
}
.ds-divider.has-text::before,
.ds-divider.has-text::after {
  content: '';
  flex: 1;
  height: 1px;
  background: var(--ds-divider);
}
.ds-divider.has-text.is-dashed::before,
.ds-divider.has-text.is-dashed::after {
  background: none;
  border-top: 1px dashed var(--ds-divider);
}
.ds-divider.has-text.is-left::before { flex: 0 0 16px; }
.ds-divider.has-text.is-right::after { flex: 0 0 16px; }
.ds-divider-text {
  flex: none;
  font-size: var(--ds-font-xs);
  color: var(--ds-text-3);
  white-space: nowrap;
}
/* 垂直：1px 宽，高度由 prop 决定（内联样式） */
.ds-divider.is-vertical {
  display: inline-block;
  width: 1px;
  align-self: stretch;
  margin: 0 8px;
}
.ds-divider.is-vertical.is-dashed {
  background: none;
  border-left: 1px dashed var(--ds-divider);
  width: 0;
}
</style>
