<!-- src/components/ds/DsDrawer.vue -->
<script setup lang="ts">
/**
 * DsDrawer —— 抽屉（通用浮层容器）。
 *
 * 四向滑出（默认右侧）；遮罩点击关闭、ESC 关闭、打开时锁定 body 滚动；
 * 头部 / 内容 / 底部三个区域均可插槽定制。BaseDrawer 在此之上叠加全屏切换。
 */
import { watch, onBeforeUnmount } from 'vue';

/** 组件入参 */
const props = withDefaults(
  defineProps<{
    /** 是否显示（v-model） */
    modelValue: boolean;
    /** 标题 */
    title?: string;
    /** 滑出方向 */
    placement?: 'left' | 'right' | 'top' | 'bottom';
    /** 尺寸：左右方向为宽，上下方向为高（px 或 CSS 值） */
    size?: number | string;
    /** 是否显示右上角关闭按钮 */
    closable?: boolean;
    /** 点击遮罩是否关闭 */
    maskClosable?: boolean;
    /** 按 ESC 是否关闭 */
    closeOnEscape?: boolean;
    /** 是否显示遮罩 */
    mask?: boolean;
    /** 层级 */
    zIndex?: number;
  }>(),
  {
    title: '',
    placement: 'right',
    size: 420,
    closable: true,
    maskClosable: true,
    closeOnEscape: true,
    mask: true,
    zIndex: 1000,
  },
);

/** 事件 */
const emit = defineEmits<{ (e: 'update:modelValue', v: boolean): void; (e: 'close'): void; (e: 'opened'): void; (e: 'closed'): void }>();

/**
 * 关闭抽屉：同步 v-model 并抛 close。
 * @returns 无
 */
function close(): void {
  emit('update:modelValue', false);
  emit('close');
}

/** 遮罩点击（仅当点在遮罩本身） */
function onMask(e: MouseEvent): void {
  if (props.maskClosable && e.target === e.currentTarget) close();
}

/** ESC 关闭 */
function onKey(e: KeyboardEvent): void {
  if (e.key === 'Escape') close();
}

// 打开：锁滚动 + 监听 ESC；关闭：恢复
watch(
  () => props.modelValue,
  (open) => {
    if (typeof document === 'undefined') return;
    document.body.style.overflow = open ? 'hidden' : '';
    if (open) {
      document.addEventListener('keydown', onKey);
      // 下一帧抛 opened，等过渡真正开始
      requestAnimationFrame(() => emit('opened'));
    } else {
      document.removeEventListener('keydown', onKey);
      requestAnimationFrame(() => emit('closed'));
    }
  },
);

// 卸载兜底：恢复滚动与监听，防止异常路径把页面锁死
onBeforeUnmount(() => {
  if (typeof document === 'undefined') return;
  document.body.style.overflow = '';
  document.removeEventListener('keydown', onKey);
});

/** 尺寸样式：左右用 width，上下用 height */
const sizeStyle = () => {
  const v = typeof props.size === 'number' ? props.size + 'px' : props.size;
  return props.placement === 'left' || props.placement === 'right' ? { width: v } : { height: v };
};
</script>

<template>
  <Teleport to="body">
    <!-- 遮罩 -->
    <Transition name="ds-drawer-mask">
      <div v-if="modelValue && mask" class="ds-drawer-mask" :style="{ zIndex }" @click="onMask" />
    </Transition>

    <!-- 抽屉主体 -->
    <Transition :name="`ds-drawer-${placement}`">
      <aside
        v-if="modelValue"
        class="ds-drawer"
        :class="`is-${placement}`"
        :style="{ ...sizeStyle(), zIndex }"
        role="dialog"
        aria-modal="true"
      >
        <!-- 头部 -->
        <header class="ds-drawer-head">
          <slot name="header">
            <span class="ds-drawer-title">{{ title }}</span>
            <button v-if="closable" type="button" class="ds-drawer-close" title="关闭" @click="close">✕</button>
          </slot>
        </header>

        <!-- 内容区 -->
        <div class="ds-drawer-body">
          <slot />
        </div>

        <!-- 底部（有内容才渲染） -->
        <footer v-if="$slots.footer" class="ds-drawer-foot">
          <slot name="footer" />
        </footer>
      </aside>
    </Transition>
  </Teleport>
</template>

<style scoped>
/* 遮罩 */
.ds-drawer-mask {
  position: fixed;
  inset: 0;
  background: var(--ds-mask);
}

/* 抽屉主体 */
.ds-drawer {
  position: fixed;
  display: flex;
  flex-direction: column;
  background: var(--ds-bg-elevated);
  box-shadow: var(--ds-shadow-lg);
}
.ds-drawer.is-right { top: 0; right: 0; bottom: 0; border-radius: var(--ds-radius-lg) 0 0 var(--ds-radius-lg); }
.ds-drawer.is-left { top: 0; left: 0; bottom: 0; border-radius: 0 var(--ds-radius-lg) var(--ds-radius-lg) 0; }
.ds-drawer.is-top { top: 0; left: 0; right: 0; border-radius: 0 0 var(--ds-radius-lg) var(--ds-radius-lg); }
.ds-drawer.is-bottom { bottom: 0; left: 0; right: 0; border-radius: var(--ds-radius-lg) var(--ds-radius-lg) 0 0; }

/* 头部 */
.ds-drawer-head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  padding: 14px 18px;
  border-bottom: 1px solid var(--ds-divider);
  flex: none;
}
.ds-drawer-title { font-size: var(--ds-font-lg); font-weight: 600; color: var(--ds-text); }
.ds-drawer-close {
  width: 30px; height: 30px;
  display: grid; place-items: center;
  border: 0; border-radius: var(--ds-radius-xs);
  background: transparent; color: var(--ds-text-3);
  cursor: pointer; font-size: var(--ds-font-sm);
  transition: background var(--ds-dur-fast) var(--ds-ease);
}
.ds-drawer-close:hover { background: var(--ds-bg-hover); color: var(--ds-text); }

/* 内容区 */
.ds-drawer-body { flex: 1; overflow-y: auto; padding: 18px; }

/* 底部 */
.ds-drawer-foot {
  flex: none;
  display: flex;
  justify-content: flex-end;
  gap: 10px;
  padding: 12px 18px;
  border-top: 1px solid var(--ds-divider);
  background: var(--ds-bg-elevated);
}

/* ---- 过渡动画 ---- */
.ds-drawer-mask-enter-active,
.ds-drawer-mask-leave-active { transition: opacity var(--ds-dur) var(--ds-ease); }
.ds-drawer-mask-enter-from,
.ds-drawer-mask-leave-to { opacity: 0; }

.ds-drawer-right-enter-active,
.ds-drawer-right-leave-active,
.ds-drawer-left-enter-active,
.ds-drawer-left-leave-active { transition: transform var(--ds-dur-slow) var(--ds-ease); }
.ds-drawer-right-enter-from,
.ds-drawer-right-leave-to { transform: translateX(100%); }
.ds-drawer-left-enter-from,
.ds-drawer-left-leave-to { transform: translateX(-100%); }

.ds-drawer-top-enter-active,
.ds-drawer-top-leave-active,
.ds-drawer-bottom-enter-active,
.ds-drawer-bottom-leave-active { transition: transform var(--ds-dur-slow) var(--ds-ease); }
.ds-drawer-top-enter-from,
.ds-drawer-top-leave-to { transform: translateY(-100%); }
.ds-drawer-bottom-enter-from,
.ds-drawer-bottom-leave-to { transform: translateY(100%); }
</style>
