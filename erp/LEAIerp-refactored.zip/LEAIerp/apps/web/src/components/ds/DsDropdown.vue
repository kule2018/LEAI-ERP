<!-- src/components/ds/DsDropdown.vue -->
<script setup lang="ts">
/**
 * DsDropdown —— 下拉菜单。
 *
 * 点击触发器展开菜单；菜单项支持图标、禁用、分隔线（divider）与
 * 分组标题；选中项通过 command 事件抛给父组件（不内置业务逻辑）。
 */
import { watch } from 'vue';
import { usePopover } from './usePopover';
import { getIcon } from './icons';
import type { DropdownItem } from './types';


/** 组件入参 */
withDefaults(
  defineProps<{
    /** 菜单项列表 */
    items: DropdownItem[];
    /** 弹出方向相对触发器 */
    placement?: 'bottom-start' | 'bottom-end' | 'top-start' | 'top-end';
    /** 是否禁用 */
    disabled?: boolean;
  }>(),
  { items: () => [], placement: 'bottom-start', disabled: false },
);

/** 事件 */
const emit = defineEmits<{ (e: 'command', cmd: string | number): void; (e: 'open-change', open: boolean): void }>();

// 浮层控制
const { open, rootRef, toggle, close } = usePopover();
void rootRef;

/**
 * 点击菜单项：抛 command 并收起。
 * @param item 菜单项
 * @returns 无
 */
function pick(item: DropdownItem): void {
  if (item.disabled || item.divider || item.group) return;
  emit('command', item.command);
  close();
}

// 开合状态同步给父组件（如用于切换箭头方向）
watch(open, (v) => emit('open-change', v));
</script>

<template>
  <span ref="rootRef" class="ds-dropdown">
    <!-- 触发器 -->
    <span class="ds-dropdown-ref" @click="!disabled && toggle()">
      <slot />
    </span>

    <!-- 菜单 -->
    <Transition name="ds-dd">
      <div v-if="open" class="ds-dropdown-menu" :class="`is-${placement}`" role="menu">
        <template v-for="(item, i) in items" :key="i">
          <!-- 分隔线 -->
          <div v-if="item.divider" class="ds-dropdown-divider" />
          <!-- 分组标题 -->
          <div v-else-if="item.group" class="ds-dropdown-group">{{ item.label }}</div>
          <!-- 菜单项 -->
          <div
            v-else
            class="ds-dropdown-item"
            :class="{ 'is-disabled': item.disabled }"
            role="menuitem"
            @click="pick(item)"
          >
            <svg v-if="item.icon" class="ds-dropdown-icon" viewBox="0 0 24 24" aria-hidden="true">
              <path :d="getIcon(item.icon)" />
            </svg>
            <span class="ds-dropdown-label">{{ item.label }}</span>
          </div>
        </template>
      </div>
    </Transition>
  </span>
</template>

<style scoped>
.ds-dropdown { position: relative; display: inline-flex; }
.ds-dropdown-ref { display: inline-flex; }

.ds-dropdown-menu {
  position: absolute;
  z-index: 200;
  min-width: 148px;
  padding: 4px;
  background: var(--ds-bg-elevated);
  border: 1px solid var(--ds-border);
  border-radius: var(--ds-radius);
  box-shadow: var(--ds-shadow-md);
}
.ds-dropdown-menu.is-bottom-start { top: calc(100% + 6px); left: 0; }
.ds-dropdown-menu.is-bottom-end { top: calc(100% + 6px); right: 0; }
.ds-dropdown-menu.is-top-start { bottom: calc(100% + 6px); left: 0; }
.ds-dropdown-menu.is-top-end { bottom: calc(100% + 6px); right: 0; }

.ds-dropdown-item {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 7px 10px;
  border-radius: var(--ds-radius-xs);
  font-size: var(--ds-font-sm);
  color: var(--ds-text-2);
  cursor: pointer;
  white-space: nowrap;
  transition: background var(--ds-dur-fast) var(--ds-ease);
}
.ds-dropdown-item:hover { background: var(--ds-bg-hover); color: var(--ds-text); }
.ds-dropdown-item.is-disabled { opacity: 0.45; cursor: not-allowed; }
.ds-dropdown-item.is-disabled:hover { background: transparent; }

.ds-dropdown-icon {
  width: 15px; height: 15px; flex: none;
  fill: none; stroke: currentColor; stroke-width: 1.8; stroke-linecap: round; stroke-linejoin: round;
}
.ds-dropdown-divider { height: 1px; margin: 4px 8px; background: var(--ds-divider); }
.ds-dropdown-group {
  padding: 6px 10px 4px;
  font-size: var(--ds-font-xs);
  color: var(--ds-text-3);
}

/* 进出动画 */
.ds-dd-enter-active,
.ds-dd-leave-active { transition: opacity var(--ds-dur-fast) var(--ds-ease), transform var(--ds-dur-fast) var(--ds-ease); }
.ds-dd-enter-from,
.ds-dd-leave-to { opacity: 0; transform: translateY(-4px); }
</style>
