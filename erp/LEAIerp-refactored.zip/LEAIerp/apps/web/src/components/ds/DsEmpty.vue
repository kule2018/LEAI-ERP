<!-- src/components/ds/DsEmpty.vue -->
<script setup lang="ts">
/**
 * 空状态占位
 * ------------------------------------------------------------------
 * 统一的「还没有数据」呈现：插画 + 主文案 + 说明 + 行动按钮槽位。
 * 所有列表/看板的空态都用它，避免每个页面画一个不一样的。
 */
withDefaults(
  defineProps<{
    /** 主文案 */
    title?: string;
    /** 补充说明 */
    description?: string;
    /** 尺寸：sm 紧凑（用于卡片内）/ md 常规 / lg 整页 */
    size?: 'sm' | 'md' | 'lg';
  }>(),
  { title: '暂无数据', description: '', size: 'md' },
);
</script>

<template>
  <div class="ds-empty" :class="`ds-empty-${size}`">
    <!-- 极简插画：用 CSS 画的「空盒子」，不引入图片资源 -->
    <div class="ds-empty-art" aria-hidden="true">
      <span class="ds-empty-box" />
      <span class="ds-empty-line l1" />
      <span class="ds-empty-line l2" />
    </div>
    <p class="ds-empty-title">{{ title }}</p>
    <p v-if="description" class="ds-empty-desc">{{ description }}</p>
    <!-- 行动区：通常放一个「新建」按钮 -->
    <div v-if="$slots.action" class="ds-empty-action"><slot name="action" /></div>
    <slot />
  </div>
</template>

<style scoped>
.ds-empty {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  text-align: center;
  color: var(--ds-text-3);
}

.ds-empty-sm { padding: 20px 12px; gap: 4px; }
.ds-empty-md { padding: 40px 16px; gap: 6px; }
.ds-empty-lg { padding: 72px 16px; gap: 8px; }

/* 插画：一个开口的盒子 + 两条横线 */
.ds-empty-art {
  position: relative;
  width: 64px;
  height: 48px;
  margin-bottom: 8px;
  opacity: 0.75;
}

.ds-empty-box {
  position: absolute;
  left: 4px;
  bottom: 0;
  width: 56px;
  height: 34px;
  border: 2px solid var(--ds-border-strong);
  border-radius: 6px;
  border-top: none;
}

.ds-empty-line {
  position: absolute;
  left: 12px;
  height: 2px;
  border-radius: 2px;
  background: var(--ds-border-strong);
}

.ds-empty-line.l1 { bottom: 22px; width: 30px; }
.ds-empty-line.l2 { bottom: 14px; width: 18px; }

.ds-empty-title { font-size: var(--ds-font-md); color: var(--ds-text-2); font-weight: 500; margin: 0; }
.ds-empty-desc { font-size: var(--ds-font-sm); margin: 0; max-width: 320px; }
.ds-empty-action { margin-top: 10px; }

.ds-empty-sm .ds-empty-art { display: none; }
</style>
