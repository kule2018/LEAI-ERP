<!-- src/components/ds/DsField.vue -->
<script setup lang="ts">
/**
 * 表单项容器
 * ------------------------------------------------------------------
 * 负责「标签 + 必填星号 + 控件 + 说明 + 错误」这一整行的排版，
 * 控件本身用插槽传入（配合 form.css 的 .ds-input/.ds-select 等），
 * 这样输入框/下拉/上传器都能共用同一套标签与错误展示。
 */
withDefaults(
  defineProps<{
    /** 标签文案 */
    label?: string;
    /** 是否必填（显示红色星号） */
    required?: boolean;
    /** 底部说明 */
    hint?: string;
    /** 错误文案（有值时高亮为红色） */
    error?: string;
  }>(),
  { label: '', required: false, hint: '', error: '' },
);
</script>

<template>
  <div class="ds-field">
    <label v-if="label" class="ds-field-label" :class="{ 'ds-field-required': required }">
      {{ label }}
    </label>
    <!-- 控件插槽 -->
    <slot />
    <span v-if="error" class="ds-field-error">{{ error }}</span>
    <span v-else-if="hint" class="ds-field-hint">{{ hint }}</span>
  </div>
</template>

<style scoped>
/* 布局与文字样式已在 styles/form.css 中全局定义，这里只补充容器间距 */
.ds-field { width: 100%; }
</style>
