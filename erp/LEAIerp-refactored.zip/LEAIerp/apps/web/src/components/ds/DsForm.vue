<!-- src/components/ds/DsForm.vue -->
<script setup lang="ts">
/**
 * DsForm —— 表单容器（布局 + 校验编排）。
 *
 * 职责：
 *   1) 提供统一的标签排版（top / left 两种标签位置、统一的控件尺寸与间距）；
 *   2) 收集子项 DsFormItem 的校验能力，暴露 validate() / resetFields() / clearValidate()；
 *   3) 回车提交：内部识别 Enter（在单行输入框内），触发 submit 事件。
 *
 * 校验时机：
 *   - 显式调用 validate()（提交按钮 / 回车）
 *   - 子项失焦（仅在「已经校验过一次」之后，避免用户刚开始填就看到红字）
 */
import { computed, provide, reactive, ref } from 'vue';
import { FORM_CTX, type FormContext, type FormItemHandle, type FormSize } from './formContext';
import type { FormRules } from './types';

/** 组件入参 */
const props = withDefaults(
  defineProps<{
    /** 表单模型（响应式对象，字段名与 rules 的 key 对齐） */
    model: Record<string, any>;
    /** 校验规则 */
    rules?: FormRules;
    /** 标签位置：top 上方 / left 左侧 */
    labelPosition?: 'top' | 'left';
    /** 标签宽度（labelPosition='left' 时生效） */
    labelWidth?: string;
    /** 控件尺寸（子项默认继承，可被单项覆盖） */
    size?: FormSize;
    /** 是否整体禁用所有控件（子项读取 context.disabled） */
    disabled?: boolean;
    /** 是否显示必填星号（默认显示） */
    showRequiredMark?: boolean;
  }>(),
  {
    labelPosition: 'top',
    labelWidth: '96px',
    size: 'md',
    disabled: false,
    showRequiredMark: true,
  },
);

/** 事件 */
const emit = defineEmits<{
  /** 回车提交 */
  (e: 'submit'): void;
  /** 校验结果变化（失败时带回第一条错误文案） */
  (e: 'validate', ok: boolean, firstError: string): void;
}>();

/** 错误集合（字段路径 -> 文案） */
const errors = reactive<Record<string, string>>({});
/** 已注册的子项 */
const items = ref<FormItemHandle[]>([]);
/** 是否已尝试提交过（控制失焦实时校验） */
const attempted = ref(false);

/**
 * 注册子项。
 * @param item 子项句柄
 * @returns 无
 */
function register(item: FormItemHandle): void {
  items.value.push(item);
}

/**
 * 注销子项：组件卸载或 prop 变化时调用。
 * @param uid 子项唯一 ID
 * @returns 无
 */
function unregister(uid: number): void {
  items.value = items.value.filter((it) => it.uid !== uid);
}

/**
 * 写入 / 清除某字段错误。
 * @param prop 字段路径
 * @param message 错误文案（空串表示清除）
 * @returns 无
 */
function setError(prop: string | undefined, message: string): void {
  if (!prop) return;
  if (message) errors[prop] = message;
  else delete errors[prop];
}

/** 提供给子项的上下文（用 getter 读取 props，保证父级更新后子项拿到最新值） */
const ctx: FormContext = {
  get model() {
    return props.model;
  },
  get rules() {
    return props.rules;
  },
  errors,
  get size() {
    return props.size;
  },
  get disabled() {
    return props.disabled;
  },
  get attempted() {
    return attempted.value;
  },
  register,
  unregister,
  setError,
};
provide(FORM_CTX, ctx);

/** 必填字段集合（供 DsFormItem 自动显示星号） */
const requiredProps = computed(() => {
  const out = new Set<string>();
  for (const [prop, rule] of Object.entries(props.rules ?? {})) {
    const list = Array.isArray(rule) ? rule : [rule];
    if (list.some((r) => r.required)) out.add(prop);
  }
  return out;
});

/**
 * 校验全部字段。
 * @returns 全部通过返回 true；否则 false，并把错误写入 errors
 */
function validate(): Promise<boolean> {
  attempted.value = true;
  let firstError = '';
  for (const item of items.value) {
    if (!item.prop) continue;
    const msg = item.validate();
    if (msg && !firstError) firstError = msg;
  }
  const ok = !firstError;
  emit('validate', ok, firstError);
  return Promise.resolve(ok);
}

/**
 * 只校验指定字段。
 * @param prop 字段路径
 * @returns 通过返回 true
 */
function validateField(prop: string): boolean {
  const item = items.value.find((it) => it.prop === prop);
  if (!item) return true;
  return !item.validate();
}

/**
 * 清空全部错误（不动物件值）。
 * @returns 无
 */
function clearValidate(): void {
  for (const key of Object.keys(errors)) delete errors[key];
  attempted.value = false;
  for (const item of items.value) item.clear();
}

/**
 * 复位：清空错误并让子项把值恢复为挂载时的初始值。
 * @returns 无
 */
function resetFields(): void {
  for (const item of items.value) item.reset();
  clearValidate();
}

/**
 * 回车提交：只处理来自单行 input 的 Enter（textarea 里的回车是换行）。
 * @param e 键盘事件
 * @returns 无
 */
function onKeydown(e: KeyboardEvent): void {
  if (e.key !== 'Enter') return;
  const el = e.target as HTMLElement;
  if (el.tagName === 'TEXTAREA') return;
  e.preventDefault();
  emit('submit');
}

defineExpose({ validate, validateField, clearValidate, resetFields, errors, requiredProps });

/** 表单类名（标签位置 + 尺寸） */
const classes = computed(() => [`is-label-${props.labelPosition}`, `is-size-${props.size}`]);
</script>

<template>
  <form
    class="ds-form"
    :class="classes"
    :style="{ '--ds-form-label-w': labelWidth }"
    novalidate
    @submit.prevent="emit('submit')"
    @keydown="onKeydown"
  >
    <slot />
  </form>
</template>

<style scoped>
.ds-form {
  display: flex;
  flex-direction: column;
  gap: 14px;
}

/* 左侧标签：两列栅格，标签列宽由 --ds-form-label-w 控制 */
.ds-form.is-label-left {
  gap: 12px;
}
.ds-form.is-label-left :deep(.ds-form-item) {
  display: grid;
  grid-template-columns: var(--ds-form-label-w) minmax(0, 1fr);
  align-items: start;
  gap: 12px;
  column-gap: 12px;
}
.ds-form.is-label-left :deep(.ds-form-item-label) {
  justify-content: flex-end;
  padding-top: 9px;
  text-align: right;
}
/* 左侧标签时，错误文案要落在控件列下方，而不是标签列 */
.ds-form.is-label-left :deep(.ds-form-item-error),
.ds-form.is-label-left :deep(.ds-form-item-hint) {
  grid-column: 2;
  margin-top: -6px;
}
.ds-form.is-label-left :deep(.ds-form-item-control) {
  min-width: 0;
}
</style>
