<!-- src/components/ds/DsFormItem.vue -->
<script setup lang="ts">
/**
 * DsFormItem —— 表单项（标签 + 控件 + 提示/错误）。
 *
 * 用法：
 *   <DsFormItem label="邮箱" prop="email">
 *     <DsInput v-model="form.email" />
 *   </DsFormItem>
 *
 * 校验由外层 DsForm 编排：本项负责「取出本字段的规则 + 当前值 → 算出错误文案」，
 * 并把结果写回表单的 errors，从而让所有字段的错误在同一次提交里统一呈现。
 * 也支持脱离 DsForm 单独使用（此时仅做排版，不校验）。
 */
import { computed, inject, onBeforeUnmount, onMounted, ref, watch } from 'vue';
import { FORM_CTX, getByPath, validateValue } from './formContext';

/** 组件入参 */
const props = withDefaults(
  defineProps<{
    /** 标签文案 */
    label?: string;
    /** 字段路径（与 DsForm 的 rules / model 对应，支持 'a.b'） */
    prop?: string;
    /** 是否必填（不传则按 rules 里是否声明 required 自动判断） */
    required?: boolean;
    /** 控件下方的灰色说明 */
    hint?: string;
    /** 外部强制指定的错误文案（优先级最高，用于服务端字段错误回填） */
    error?: string;
    /** 控件尺寸覆盖 */
    size?: 'sm' | 'md' | 'lg';
    /** 标签是否占据整行（多行文本类控件用） */
    block?: boolean;
  }>(),
  { label: '', hint: '', error: '' },
);

/** 表单上下文（可能不存在：脱离 DsForm 单独使用） */
const form = inject(FORM_CTX, null);

/** 本项唯一 ID（卸载时注销） */
const uid = ++UID_SEQ;

/** 内部错误（由本项校验得出） */
const innerError = ref('');

/** 挂载时的初始值，用于 resetFields */
let initialValue: any;

/** 最终展示的错误：外部传入 > 内部校验 */
const displayError = computed(() => props.error || innerError.value);

/** 是否必填：显式传入 > 规则里的 required */
const isRequired = computed(() => {
  if (props.required !== undefined) return props.required;
  if (!form || !props.prop) return false;
  const rule = form.rules?.[props.prop];
  if (!rule) return false;
  const list = (Array.isArray(rule) ? rule : [rule]);
  return list.some((r) => r.required);
});

/** 控件尺寸：单项 > 表单 */
const controlSize = computed(() => props.size ?? form?.size ?? 'md');

/**
 * 执行本项校验。
 * @returns 通过返回空串，失败返回错误文案
 */
function validate(): string {
  if (!props.prop) return '';
  const msg = validateValue(form?.rules?.[props.prop], getByPath(form?.model, props.prop), form?.model ?? {});
  innerError.value = msg;
  form?.setError(props.prop, msg);
  return msg;
}

/**
 * 失焦校验：仅在「提交过一次」之后触发，避免边填边报红。
 * @returns 无
 */
function onFocusOut(): void {
  if (!form?.attempted) return;
  validate();
}

/**
 * 复位：清空错误，并把值恢复为挂载时的快照。
 * @returns 无
 */
function reset(): void {
  innerError.value = '';
  if (!props.prop || !form) return;
  const segs = props.prop.split('.');
  const last = segs.pop() as string;
  const parent = segs.reduce<any>((acc, k) => (acc == null ? undefined : acc[k]), form.model);
  if (parent) parent[last] = initialValue;
}

/** 仅清空错误 */
function clear(): void {
  innerError.value = '';
}

onMounted(() => {
  initialValue = getByPath(form?.model, props.prop);
  form?.register({ uid, prop: props.prop, validate, reset, clear });
});

onBeforeUnmount(() => form?.unregister(uid));

// 提交过之后：值一变就重新校验，让红字随修正即时消失
watch(
  () => getByPath(form?.model, props.prop),
  () => {
    if (form?.attempted) validate();
  },
);
</script>

<script lang="ts">
/** 模块级自增序号（每实例 +1；放在普通 script 里便于初始化前使用） */
let UID_SEQ = 0;
</script>

<template>
  <div
    class="ds-form-item"
    :class="{ 'is-error': !!displayError, 'is-block': block, 'is-disabled': form?.disabled }"
  >
    <!-- 标签行 -->
    <label v-if="label" class="ds-form-item-label">
      <span class="ds-form-item-text">{{ label }}</span>
      <span v-if="isRequired" class="ds-form-item-star" aria-hidden="true">*</span>
    </label>

    <!-- 控件区 -->
    <div class="ds-form-item-control" :class="`is-size-${controlSize}`" @focusout="onFocusOut">
      <slot />
    </div>

    <!-- 错误 / 说明 -->
    <p v-if="displayError" class="ds-form-item-error">{{ displayError }}</p>
    <p v-else-if="hint" class="ds-form-item-hint">{{ hint }}</p>
  </div>
</template>

<style scoped>
.ds-form-item {
  display: flex;
  flex-direction: column;
  gap: 6px;
  min-width: 0;
}

.ds-form-item-label {
  display: inline-flex;
  align-items: center;
  gap: 3px;
  font-size: var(--ds-font-sm);
  font-weight: 550;
  color: var(--ds-text-2);
  line-height: 1.4;
}
.ds-form-item-star {
  color: var(--ds-danger);
  font-size: var(--ds-font-sm);
  line-height: 1;
}

.ds-form-item-control {
  min-width: 0;
}
/* 尺寸继承：把 DsForm 的 size 透传给内部控件（子组件未显式传 size 时） */
.is-size-sm :deep(input),
.is-size-sm :deep(textarea),
.is-size-sm :deep(.ds-num) {
  font-size: var(--ds-font-sm);
}

.ds-form-item-error,
.ds-form-item-hint {
  margin: 0;
  font-size: var(--ds-font-xs);
  line-height: 1.5;
}
.ds-form-item-error {
  color: var(--ds-danger);
}
.ds-form-item-hint {
  color: var(--ds-text-3);
}

/* 出错态：把内部控件的边框染红（覆盖常见控件根节点） */
.ds-form-item.is-error :deep(input),
.ds-form-item.is-error :deep(textarea),
.ds-form-item.is-error :deep(.ds-select-trigger),
.ds-form-item.is-error :deep(.ds-num) {
  border-color: var(--ds-danger);
}
.ds-form-item.is-disabled {
  opacity: 0.75;
}
</style>
