<!-- src/components/ds/DsImage.vue -->
<script setup lang="ts">
/**
 * DsImage —— 图片展示 + 点击大图预览。
 *
 * 业务场景：对话里的图片附件、证件照、渠道二维码等。默认点击即预览，
 * 预览层支持 Esc / 点击遮罩 / 右上角关闭，滚轮可缩放（1x ~ 3x）。
 * 传 previewList 即进入图集模式：预览层可左右切换同一组图片（对话多图场景）。
 * 不依赖任何图片预览库，加载失败时降级为占位提示。
 */
import { computed, onBeforeUnmount, ref, watch } from 'vue';

/** 组件入参 */
const props = withDefaults(
  defineProps<{
    /** 图片地址 */
    src: string;
    /** 无障碍描述 / 加载失败时的替代文案 */
    alt?: string;
    /** 宽度（px 或 CSS 值） */
    width?: number | string;
    /** 高度（px 或 CSS 值） */
    height?: number | string;
    /** 填充方式：cover 裁剪铺满 / contain 完整显示 */
    fit?: 'cover' | 'contain';
    /** 圆角（CSS 值） */
    radius?: string;
    /** 是否开启点击预览 */
    preview?: boolean;
    /** 图集模式：预览时可切换的同组图片地址列表 */
    previewList?: string[];
    /** 图集模式下的起始下标（不传则按 src 在列表中的位置推断） */
    initialIndex?: number;
  }>(),
  { alt: '', fit: 'cover', radius: 'var(--ds-radius-sm)', preview: true, previewList: () => [] },
);

/** 是否已加载完成（控制骨架） */
const loaded = ref(false);
/** 是否加载失败 */
const failed = ref(false);
/** 预览层是否打开 */
const open = ref(false);
/** 预览缩放倍数 */
const zoom = ref(1);
/** 图集模式下当前预览的下标 */
const cursor = ref(0);

/** 是否处于图集模式（列表里有不止一张） */
const isGallery = computed(() => props.previewList.length > 1);

/** 预览层实际显示的图片地址 */
const previewSrc = computed(() =>
  isGallery.value ? (props.previewList[cursor.value] ?? props.src) : props.src,
);

/** 外层样式 */
const boxStyle = computed(() => ({
  width: typeof props.width === 'number' ? `${props.width}px` : props.width,
  height: typeof props.height === 'number' ? `${props.height}px` : props.height,
  borderRadius: props.radius,
}));

/** 预览图样式（限制最大可视区域，避免超大图撑破屏幕） */
const previewStyle = computed(() => ({
  transform: `scale(${zoom.value})`,
  maxWidth: '92vw',
  maxHeight: '88vh',
  objectFit: 'contain' as const,
}));

/**
 * 打开预览。
 * 图集模式下把 cursor 定位到当前这张（优先用显式 initialIndex）。
 * @returns 无
 */
function openPreview(): void {
  if (!props.preview || failed.value) return;
  zoom.value = 1;
  if (isGallery.value) {
    const byProp = props.initialIndex;
    const bySrc = props.previewList.indexOf(props.src);
    cursor.value =
      byProp !== undefined && byProp >= 0 && byProp < props.previewList.length
        ? byProp
        : bySrc >= 0
          ? bySrc
          : 0;
  }
  open.value = true;
  if (typeof document !== 'undefined') document.body.style.overflow = 'hidden';
}

/**
 * 图集模式下切换到上一张 / 下一张（循环）。
 * @param step 位移，-1 上一张 / 1 下一张
 * @returns 无
 */
function step(stepValue: number): void {
  const total = props.previewList.length;
  if (total <= 1) return;
  cursor.value = (cursor.value + stepValue + total) % total;
  zoom.value = 1;
}

/**
 * 关闭预览并恢复页面滚动。
 * @returns 无
 */
function closePreview(): void {
  open.value = false;
  if (typeof document !== 'undefined') document.body.style.overflow = '';
}

/**
 * 滚轮缩放（0.5 ~ 3 倍）。
 * @param e 滚轮事件
 * @returns 无
 */
function onWheel(e: WheelEvent): void {
  e.preventDefault();
  const next = zoom.value + (e.deltaY < 0 ? 0.2 : -0.2);
  zoom.value = Math.min(3, Math.max(0.5, Number(next.toFixed(2))));
}

/**
 * 键盘操作：Esc 关闭预览，图集模式下左右方向键切换。
 * @param e 键盘事件
 * @returns 无
 */
function onKey(e: KeyboardEvent): void {
  if (e.key === 'Escape') closePreview();
  else if (e.key === 'ArrowLeft') step(-1);
  else if (e.key === 'ArrowRight') step(1);
}

// 预览打开时监听 Esc；关闭时移除，避免全局残留
watch(open, (v) => {
  if (typeof document === 'undefined') return;
  if (v) document.addEventListener('keydown', onKey);
  else document.removeEventListener('keydown', onKey);
});

onBeforeUnmount(() => {
  if (typeof document === 'undefined') return;
  document.removeEventListener('keydown', onKey);
  document.body.style.overflow = '';
});
</script>

<template>
  <div class="ds-img" :style="boxStyle" :class="{ 'is-clickable': preview && !failed }">
    <!-- 加载中骨架 -->
    <span v-if="!loaded && !failed" class="ds-img-skeleton" aria-hidden="true" />

    <!-- 加载失败占位 -->
    <span v-if="failed" class="ds-img-failed">{{ alt || '图片不可用' }}</span>

    <img
      v-else
      class="ds-img-inner"
      :src="src"
      :alt="alt"
      :style="{ objectFit: fit, opacity: loaded ? 1 : 0 }"
      loading="lazy"
      @load="loaded = true"
      @error="
        failed = true;
        loaded = true;
      "
      @click="openPreview"
    />

    <!-- 预览层 -->
    <Teleport to="body">
      <div v-if="open" class="ds-img-mask" @click.self="closePreview" @wheel="onWheel">
        <img class="ds-img-preview" :src="previewSrc" :alt="alt" :style="previewStyle" />
        <!-- 图集模式：左右切换 + 计数 -->
        <template v-if="isGallery">
          <button
            class="ds-img-nav is-prev"
            type="button"
            aria-label="上一张"
            @click.stop="step(-1)"
          >
            ‹
          </button>
          <button
            class="ds-img-nav is-next"
            type="button"
            aria-label="下一张"
            @click.stop="step(1)"
          >
            ›
          </button>
          <span class="ds-img-count">{{ cursor + 1 }} / {{ previewList.length }}</span>
        </template>
        <button class="ds-img-close" type="button" aria-label="关闭预览" @click="closePreview">✕</button>
        <span class="ds-img-zoom">{{ Math.round(zoom * 100) }}%</span>
      </div>
    </Teleport>
  </div>
</template>

<style scoped>
.ds-img {
  position: relative;
  display: inline-block;
  overflow: hidden;
  background: var(--ds-bg-hover);
  vertical-align: middle;
}
.ds-img.is-clickable .ds-img-inner {
  cursor: zoom-in;
}

.ds-img-inner {
  display: block;
  width: 100%;
  height: 100%;
  transition: opacity var(--ds-dur-base) var(--ds-ease);
}

.ds-img-skeleton {
  position: absolute;
  inset: 0;
  background: linear-gradient(90deg, var(--ds-bg-hover), var(--ds-bg-soft), var(--ds-bg-hover));
  background-size: 200% 100%;
  animation: ds-img-shimmer 1.2s ease-in-out infinite;
}
@keyframes ds-img-shimmer {
  from {
    background-position: 200% 0;
  }
  to {
    background-position: -200% 0;
  }
}

.ds-img-failed {
  display: grid;
  place-items: center;
  width: 100%;
  height: 100%;
  padding: 6px;
  color: var(--ds-text-3);
  font-size: var(--ds-font-xs);
  text-align: center;
}

/* ---- 预览层 ---- */
.ds-img-mask {
  position: fixed;
  inset: 0;
  z-index: 1200;
  display: grid;
  place-items: center;
  background: rgba(8, 12, 20, 0.82);
  backdrop-filter: blur(3px);
  cursor: zoom-out;
}
.ds-img-preview {
  border-radius: var(--ds-radius-sm);
  transition: transform var(--ds-dur-fast) var(--ds-ease);
  cursor: default;
}
.ds-img-close {
  position: absolute;
  top: 18px;
  right: 20px;
  width: 32px;
  height: 32px;
  border: 0;
  border-radius: 50%;
  background: rgba(255, 255, 255, 0.14);
  color: #fff;
  font-size: 14px;
  cursor: pointer;
}
.ds-img-close:hover {
  background: rgba(255, 255, 255, 0.26);
}
/* 图集模式：左右切页按钮贴在两侧中部 */
.ds-img-nav {
  position: absolute;
  top: 50%;
  width: 40px;
  height: 40px;
  transform: translateY(-50%);
  border: 0;
  border-radius: 50%;
  background: rgba(255, 255, 255, 0.14);
  color: #fff;
  font-size: 24px;
  line-height: 1;
  cursor: pointer;
}
.ds-img-nav:hover {
  background: rgba(255, 255, 255, 0.26);
}
.ds-img-nav.is-prev {
  left: 20px;
}
.ds-img-nav.is-next {
  right: 20px;
}
/* 图集模式：右下角显示进度 */
.ds-img-count {
  position: absolute;
  right: 20px;
  bottom: 18px;
  padding: 3px 10px;
  border-radius: var(--ds-radius-full);
  background: rgba(255, 255, 255, 0.14);
  color: #fff;
  font-size: var(--ds-font-xs);
  font-variant-numeric: tabular-nums;
}
.ds-img-zoom {
  position: absolute;
  bottom: 18px;
  left: 50%;
  transform: translateX(-50%);
  padding: 3px 10px;
  border-radius: var(--ds-radius-full);
  background: rgba(255, 255, 255, 0.14);
  color: #fff;
  font-size: var(--ds-font-xs);
}
</style>
