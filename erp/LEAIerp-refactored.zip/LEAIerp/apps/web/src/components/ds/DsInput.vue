<!-- src/components/ds/DsInput.vue -->
<script setup lang="ts">
/**
 * DsInput —— 输入框 / 文本域（二合一）。
 *
 * 设计要点：
 *   1) type 支持 text / number / password / textarea 四种形态，
 *      textarea 支持 rows 固定高度或 autosize 自增高；
 *   2) 统一三档尺寸（sm 30 / md 36 / lg 42），与 DsButton、DsSelect 对齐节奏；
 *   3) clearable 显示清空按钮（仅在有值时），showCount 显示字数统计；
 *   4) prefix / suffix 插槽放图标或小按钮（如密码可见切换）；
 *   5) 焦点态用品牌色细环（box-shadow），不改变布局避免抖动。
 */
import { computed, ref } from 'vue';

/** 组件入参 */
const props = withDefaults(
  defineProps<{
    /** 输入值（v-model） */
    modelValue: string | number;
    /** 形态：text 文本 / number 数字 / password 密码 / textarea 多行 */
    type?: 'text' | 'number' | 'password' | 'textarea';
    /** 占位文案 */
    placeholder?: string;
    /** 是否禁用 */
    disabled?: boolean;
    /** 是否只读 */
    readonly?: boolean;
    /** 尺寸：sm / md / lg */
    size?: 'sm' | 'md' | 'lg';
    /** 是否可清空（有值时显示清空按钮） */
    clearable?: boolean;
    /** 最大字符数（textarea 常用） */
    maxlength?: number;
    /** 是否显示 「已输入 / 上限」 计数（需配合 maxlength） */
    showCount?: boolean;
    /** textarea 固定行数 */
    rows?: number;
    /** textarea 是否随内容自动增高 */
    autosize?: boolean;
    /** textarea 自动增高的最大高度（px） */
    maxHeight?: number;
    /** 原生 name（表单提交用） */
    name?: string;
    /** 原生 min（number 类型的最小值约束，如不允许负数填 0） */
    min?: number | string;
    /** 原生 max（number 类型的最大值约束） */
    max?: number | string;
    /** 原生 step（number 类型的步进精度，如金额 0.01、单价 0.0001） */
    step?: number | string;
  }>(),
  {
    type: 'text',
    placeholder: '',
    disabled: false,
    readonly: false,
    size: 'md',
    clearable: false,
    maxlength: undefined,
    showCount: false,
    rows: 3,
    autosize: false,
    maxHeight: 200,
    name: '',
    min: undefined,
    max: undefined,
    step: undefined,
  },
);

/** 事件 */
const emit = defineEmits<{
  (e: 'update:modelValue', v: string | number): void;
  (e: 'input', v: string | number): void;
  (e: 'change', v: string | number): void;
  (e: 'focus', ev: FocusEvent): void;
  (e: 'blur', ev: FocusEvent): void;
  (e: 'clear'): void;
}>();

/** 文本域元素引用（自增高用） */
const taRef = ref<HTMLTextAreaElement | null>(null);
/** 密码是否可见（点击后缀图标切换） */
const pwVisible = ref(false);

/** 是否多行形态 */
const isTextarea = computed(() => props.type === 'textarea');
/** 是否显示清空按钮：开启 clearable、有值、未禁用 */
const showClear = computed(() => props.clearable && !!String(props.modelValue ?? '') && !props.disabled);
/** 已输入字符数 */
const count = computed(() => String(props.modelValue ?? '').length);

/**
 * 输入处理：数字类型做一次合法化（空串保留，便于用户清空重输）。
 * @param ev 原生输入事件
 * @returns 无
 */
function onInput(ev: Event): void {
  const el = ev.target as HTMLInputElement;
  let v: string | number = el.value;
  if (props.type === 'number') {
    // 数字框：只过滤出合法数字字符，非法输入直接忽略
    if (v !== '' && !/^-?\d*(\.\d+)?$/.test(v)) return;
    v = v === '' ? '' : Number(v);
  }
  emit('update:modelValue', v);
  emit('input', v);
  if (isTextarea.value) autoGrow();
}

/**
 * 文本域自适应高度：先归零再取 scrollHeight，封顶 maxHeight。
 * @returns 无
 */
function autoGrow(): void {
  if (!props.autosize) return;
  const el = taRef.value;
  if (!el) return;
  el.style.height = 'auto';
  const h = Math.min(el.scrollHeight, props.maxHeight);
  el.style.height = h + 'px';
  // 超过最大高度后转为内部滚动
  el.style.overflowY = el.scrollHeight > props.maxHeight ? 'auto' : 'hidden';
}

/**
 * 清空输入。
 * @returns 无
 */
function clear(): void {
  emit('update:modelValue', '');
  emit('clear');
}

// 密码框失焦后自动收起可见状态，避免敏感信息长期暴露
function onBlur(ev: FocusEvent): void {
  if (props.type === 'password') pwVisible.value = false;
  emit('blur', ev);
}
</script>

<template>
  <div
    class="ds-input-wrap"
    :class="[`is-${size}`, { 'is-disabled': disabled, 'is-textarea': isTextarea }]"
  >
    <!-- 前缀插槽：图标 / 单位 -->
    <span v-if="$slots.prefix" class="ds-input-prefix"><slot name="prefix" /></span>

    <!-- 多行形态 -->
    <textarea
      v-if="isTextarea"
      ref="taRef"
      class="ds-input-el"
      :value="modelValue"
      :placeholder="placeholder"
      :disabled="disabled"
      :readonly="readonly"
      :rows="rows"
      :maxlength="maxlength"
      :name="name"
      @input="onInput"
      @focus="emit('focus', $event)"
      @blur="onBlur"
    />

    <!-- 单行形态 -->
    <input
      v-else
      class="ds-input-el"
      :value="modelValue"
      :type="type === 'password' ? (pwVisible ? 'text' : 'password') : type"
      :placeholder="placeholder"
      :disabled="disabled"
      :readonly="readonly"
      :maxlength="maxlength"
      :name="name"
      :min="min"
      :max="max"
      :step="step"
      @input="onInput"
      @change="emit('change', modelValue)"
      @focus="emit('focus', $event)"
      @blur="onBlur"
    />

    <!-- 后缀区：清空按钮 / 密码可见切换 / 自定义后缀 -->
    <span v-if="showClear || type === 'password' || $slots.suffix" class="ds-input-suffix">
      <button v-if="showClear" type="button" class="ds-input-clear" title="清空" @click="clear">✕</button>
      <button
        v-else-if="type === 'password'"
        type="button"
        class="ds-input-clear"
        :title="pwVisible ? '隐藏密码' : '显示密码'"
        @click="pwVisible = !pwVisible"
      >
        {{ pwVisible ? ' Oj ' : ' ● ' }}
      </button>
      <slot v-else name="suffix" />
    </span>

    <!-- 字数统计：绝对定位在右下角，不占布局 -->
    <span v-if="showCount && maxlength" class="ds-input-count">{{ count }}/{{ maxlength }}</span>
  </div>
</template>

<style scoped>
.ds-input-wrap {
  position: relative;
  display: inline-flex;
  align-items: center;
  width: 100%;
  background: var(--ds-bg-elevated);
  border: 1px solid var(--ds-border);
  border-radius: var(--ds-radius-sm);
  transition: border-color var(--ds-dur-fast) var(--ds-ease), box-shadow var(--ds-dur-fast) var(--ds-ease);
}

.ds-input-wrap:hover:not(.is-disabled) { border-color: var(--ds-border-strong); }
.ds-input-wrap:focus-within { border-color: var(--ds-brand); box-shadow: 0 0 0 3px var(--ds-brand-soft); }
.ds-input-wrap.is-disabled { background: var(--ds-bg-hover); cursor: not-allowed; }

/* 尺寸：与 DsButton 高度对齐 */
.ds-input-wrap.is-sm .ds-input-el { height: var(--ds-ctl-h-sm); font-size: var(--ds-font-sm); }
.ds-input-wrap.is-md .ds-input-el { height: var(--ds-ctl-h-md); }
.ds-input-wrap.is-lg .ds-input-el { height: var(--ds-ctl-h-lg); font-size: var(--ds-font-lg); }

/* 输入元素本体：裸形态，边框与焦点环由容器负责 */
.ds-input-el {
  flex: 1;
  min-width: 0;
  border: 0;
  outline: none;
  background: transparent;
  color: var(--ds-text);
  font-family: inherit;
  font-size: var(--ds-font-md);
  padding: 0 12px;
  line-height: 1.5;
}
.ds-input-el::placeholder { color: var(--ds-text-3); }
.ds-input-el:disabled { color: var(--ds-text-3); cursor: not-allowed; background: transparent; }

/* 多行形态：容器高度跟随内容（初始高度由原生 rows 属性决定） */
.ds-input-wrap.is-textarea { align-items: flex-start; padding: 6px 0; }
.ds-input-wrap.is-textarea .ds-input-el {
  height: auto;
  padding: 2px 12px;
  resize: none;
  line-height: 1.6;
}

/* 前后缀 */
.ds-input-prefix,
.ds-input-suffix {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  flex: none;
  color: var(--ds-text-3);
  font-size: var(--ds-font-sm);
}
.ds-input-prefix { padding-left: 10px; }
.ds-input-suffix { padding-right: 10px; }

/* 清空 / 密码切换小按钮 */
.ds-input-clear {
  border: 0;
  background: transparent;
  color: var(--ds-text-3);
  cursor: pointer;
  padding: 2px 4px;
  border-radius: var(--ds-radius-xs);
  font-size: var(--ds-font-xs);
  line-height: 1;
  letter-spacing: 0;
}
.ds-input-clear:hover { background: var(--ds-bg-hover); color: var(--ds-text); }

/* 字数统计 */
.ds-input-count {
  position: absolute;
  right: 10px;
  bottom: 4px;
  font-size: var(--ds-font-xs);
  color: var(--ds-text-3);
  pointer-events: none;
  font-variant-numeric: tabular-nums;
}
.ds-input-wrap.is-textarea .ds-input-count { bottom: 8px; }
</style>
