<!-- src/components/ds/DsInputNumber.vue -->
<script setup lang="ts">
/**
 * DsInputNumber —— 数字输入框（带步进器）。
 *
 * 为什么单独做一个组件：原生 input[type=number] 在各浏览器里的步进样式、
 * 滚轮行为与精度表现不一致，业务侧又需要「最小值 / 最大值 / 步长 / 小数位」
 * 的确定性约束（配额、限流、排序号都用得上）。这里用文本框 + 自绘步进按钮，
 * 输入过程允许临时非法值，失焦时统一收敛（夹取范围 + 定点精度）。
 */
import { computed, ref, watch } from 'vue';

/** 组件入参 */
const props = withDefaults(
  defineProps<{
    /** 绑定值（为空表示未填写，提交前由业务侧决定是否必填） */
    modelValue: number | null;
    /** 最小值（缺省不限制） */
    min?: number;
    /** 最大值（缺省不限制） */
    max?: number;
    /** 步进值（负数表示允许递减，0 表示禁用步进按钮） */
    step?: number;
    /** 小数位数（0 表示整数；缺省按 step 的小数位推断） */
    precision?: number;
    /** 占位文案 */
    placeholder?: string;
    /** 是否禁用 */
    disabled?: boolean;
    /** 尺寸：sm / md / lg */
    size?: 'sm' | 'md' | 'lg';
    /** 是否显示两侧步进按钮 */
    controls?: boolean;
    /** 文本对齐：数值表格内常用 right */
    align?: 'left' | 'center' | 'right';
  }>(),
  {
    modelValue: null,
    step: 1,
    placeholder: '',
    disabled: false,
    size: 'md',
    controls: true,
    align: 'left',
  },
);

/** 事件 */
const emit = defineEmits<{
  (e: 'update:modelValue', v: number | null): void;
  (e: 'change', v: number | null): void;
}>();

/** 实际生效的小数位（必须声明在 format / text 之前，否则初始化 text 时访问 digits 会触发 TDZ） */
const digits = computed(() => props.precision ?? precisionOf(props.step));

/**
 * 由 step 推断小数位：step=1 → 0 位，step=0.01 → 2 位。
 * @param step 步进值
 * @returns 小数位数
 */
function precisionOf(step: number): number {
  const s = String(Math.abs(step));
  const i = s.indexOf('.');
  return i < 0 ? 0 : s.length - i - 1;
}

/** 输入框内的编辑态文本（允许「-」「1.」这类中间态） */
const text = ref(format(props.modelValue));

/**
 * 把数值格式化为展示文本。
 * @param v 数值（null 表示空）
 * @returns 展示字符串
 */
function format(v: number | null): string {
  if (v === null || v === undefined || Number.isNaN(v)) return '';
  return digits.value > 0 ? v.toFixed(digits.value) : String(v);
}

/**
 * 夹取到 [min, max] 并按精度定点。
 * @param v 原始数值
 * @returns 合法数值
 */
function clamp(v: number): number {
  let n = v;
  if (props.min !== undefined && n < props.min) n = props.min;
  if (props.max !== undefined && n > props.max) n = props.max;
  const p = 10 ** digits.value;
  return Math.round(n * p) / p;
}

/**
 * 提交一个数值：夹取 → 回写文本 → 触发事件。
 * @param v 目标数值（null 表示清空）
 * @returns 无
 */
function commit(v: number | null): void {
  if (v === null) {
    text.value = '';
    emit('update:modelValue', null);
    emit('change', null);
    return;
  }
  const n = clamp(v);
  text.value = format(n);
  emit('update:modelValue', n);
  emit('change', n);
}

/**
 * 输入过程：只保留数字、小数点与前置负号，不立刻夹取（避免打断输入）。
 * @param e 原生 input 事件
 * @returns 无
 */
function onInput(e: Event): void {
  const el = e.target as HTMLInputElement;
  let v = el.value.replace(/[^\d.-]/g, '');
  // 只允许一个负号且在首位、一个小数点
  v = v.replace(/(?!^)-/g, '');
  const dot = v.indexOf('.');
  if (dot >= 0) v = v.slice(0, dot + 1) + v.slice(dot + 1).replace(/\./g, '');
  el.value = v;
  text.value = v;
  // 中间态（'' / '-' / '.' / '1.'）不向上同步，等失焦收敛
  if (v === '' || v === '-' || v === '.' || v.endsWith('.')) return;
  const n = Number(v);
  if (!Number.isNaN(n)) emit('update:modelValue', clamp(n));
}

/**
 * 失焦：把中间态收敛成合法值。
 * @returns 无
 */
function onBlur(): void {
  const raw = text.value.trim();
  if (raw === '' || raw === '-' || raw === '.' || Number.isNaN(Number(raw))) {
    commit(null);
    return;
  }
  commit(Number(raw));
}

/**
 * 步进：按 step 增减并夹取。
 * @param dir 1 增加 / -1 减少
 * @returns 无
 */
function stepBy(dir: 1 | -1): void {
  if (props.disabled) return;
  const cur = props.modelValue ?? props.min ?? 0;
  commit(cur + dir * Math.abs(props.step));
}

/** 外部值变化时同步文本（仅当与当前文本不等，避免打断输入） */
watch(
  () => props.modelValue,
  (v) => {
    if (v !== null && v !== undefined && Number(text.value) === v) return;
    text.value = format(v);
  },
);

/** 步进按钮的禁用态：到达边界 */
const canUp = computed(() => props.max === undefined || (props.modelValue ?? 0) < props.max);
const canDown = computed(() => props.min === undefined || (props.modelValue ?? 0) > props.min);
</script>

<template>
  <div class="ds-num" :class="[`is-${size}`, { 'is-disabled': disabled }]">
    <button
      v-if="controls"
      type="button"
      class="ds-num-btn"
      :disabled="disabled || !canDown"
      aria-label="减少"
      @click="stepBy(-1)"
    >
      −
    </button>
    <input
      class="ds-num-input"
      type="text"
      inputmode="decimal"
      :value="text"
      :placeholder="placeholder"
      :disabled="disabled"
      :style="{ textAlign: align }"
      @input="onInput"
      @blur="onBlur"
      @keydown.up.prevent="stepBy(1)"
      @keydown.down.prevent="stepBy(-1)"
    />
    <button
      v-if="controls"
      type="button"
      class="ds-num-btn"
      :disabled="disabled || !canUp"
      aria-label="增加"
      @click="stepBy(1)"
    >
      ＋
    </button>
  </div>
</template>

<style scoped>
.ds-num {
  display: inline-flex;
  align-items: stretch;
  width: 100%;
  background: var(--ds-bg-elevated);
  border: 1px solid var(--ds-border);
  border-radius: var(--ds-radius-sm);
  overflow: hidden;
  transition: border-color var(--ds-dur-fast) var(--ds-ease), box-shadow var(--ds-dur-fast) var(--ds-ease);
  height: var(--ds-ctl-h-md);
}
.ds-num:focus-within {
  border-color: var(--ds-brand);
  box-shadow: 0 0 0 3px var(--ds-brand-soft);
}
.ds-num.is-sm { height: var(--ds-ctl-h-sm); }
.ds-num.is-lg { height: var(--ds-ctl-h-lg); }
.ds-num.is-disabled { background: var(--ds-bg-hover); cursor: not-allowed; }

.ds-num-input {
  flex: 1;
  min-width: 0;
  padding: 0 10px;
  border: 0;
  background: transparent;
  color: var(--ds-text);
  font-family: inherit;
  font-size: var(--ds-font-md);
  outline: none;
}
.ds-num.is-sm .ds-num-input { font-size: var(--ds-font-sm); }
.ds-num-input::placeholder { color: var(--ds-text-3); }
.ds-num-input:disabled { cursor: not-allowed; color: var(--ds-text-3); }

.ds-num-btn {
  flex: none;
  width: 30px;
  border: 0;
  border-left: 1px solid var(--ds-border);
  background: var(--ds-bg-soft);
  color: var(--ds-text-2);
  font-size: 13px;
  line-height: 1;
  cursor: pointer;
  transition: background var(--ds-dur-fast) var(--ds-ease), color var(--ds-dur-fast) var(--ds-ease);
}
.ds-num-btn:last-child { border-left: 0; border-right: 0; border-left: 1px solid var(--ds-border); }
.ds-num-btn:hover:not(:disabled) { background: var(--ds-bg-hover); color: var(--ds-text); }
.ds-num-btn:disabled { color: var(--ds-text-3); opacity: 0.55; cursor: not-allowed; }
</style>
