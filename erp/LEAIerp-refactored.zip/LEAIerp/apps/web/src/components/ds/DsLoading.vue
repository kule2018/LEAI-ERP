<!-- src/components/ds/DsLoading.vue -->
<script setup lang="ts">
/**
 * DsLoading —— 区块级加载遮罩（局部刷新时压在已有内容之上）。
 *
 * 用法：
 *   <DsLoading :loading="loading">
 *     <div>任意内容</div>
 *   </DsLoading>
 *
 * 与 DsSkeleton 的分工：骨架屏用于首屏（还不知道内容形状时占位），
 * 本组件用于「已有内容、正在局部刷新」的场景（保留旧内容，压一层半透明遮罩）。
 */
import DsSpinner from './DsSpinner.vue';

/** 组件入参 */
withDefaults(
  defineProps<{
    /** 是否加载中 */
    loading?: boolean;
    /** 遮罩上的文案（留空只显示转圈） */
    text?: string;
    /** 最小高度（px 或 CSS 值），防止空内容时遮罩塌陷 */
    minHeight?: number | string;
    /** 是否禁用遮罩的点击（加载中通常要挡住交互，默认挡住） */
    blockInteraction?: boolean;
  }>(),
  { loading: false, text: '', minHeight: '', blockInteraction: true },
);
</script>

<template>
  <div class="ds-loading" :class="{ 'is-loading': loading }">
    <slot />

    <Transition name="ds-loading-fade">
      <div v-if="loading" class="ds-loading-mask" :class="{ 'is-passive': !blockInteraction }">
        <DsSpinner :size="20" />
        <span v-if="text" class="ds-loading-text">{{ text }}</span>
      </div>
    </Transition>
  </div>
</template>

<style scoped>
.ds-loading {
  position: relative;
  min-height: 40px;
}

.ds-loading-mask {
  position: absolute;
  inset: 0;
  z-index: 4;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  background: color-mix(in srgb, var(--ds-bg-elevated) 72%, transparent);
  border-radius: inherit;
  cursor: progress;
}
.ds-loading-mask.is-passive {
  pointer-events: none;
}

.ds-loading-text {
  color: var(--ds-text-2);
  font-size: var(--ds-font-sm);
}

.ds-loading-fade-enter-active,
.ds-loading-fade-leave-active {
  transition: opacity var(--ds-dur-fast) var(--ds-ease);
}
.ds-loading-fade-enter-from,
.ds-loading-fade-leave-to {
  opacity: 0;
}
</style>
