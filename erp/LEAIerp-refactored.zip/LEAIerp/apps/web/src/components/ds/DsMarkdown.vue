<!-- src/components/ds/DsMarkdown.vue -->
<script setup lang="ts">
/**
 * Markdown 渲染器
 * ------------------------------------------------------------------
 * 把 AI/系统输出的 Markdown 文本渲染成排版良好的 HTML：
 *   - 标题 / 列表 / 引用 / 表格 / 分割线 / 段落
 *   - 代码块：语言标签 + 一键复制（事件委托，不需要给每个按钮绑事件）
 *   - 流式输出：内容变化时只重算一次，配合 .ds-md-caret 显示打字光标
 *
 * 安全：renderMarkdown 内部已做 HTML 转义，可安全 v-html。
 */
import { computed, ref } from 'vue';
import { renderMarkdown, inFence } from './markdown';
import { copyText } from './format';
import { useToast } from './toast';

/** 组件入参 */
const props = withDefaults(
  defineProps<{
    /** Markdown 源文本 */
    content: string;
    /** 是否正在流式输出（显示闪烁光标） */
    streaming?: boolean;
  }>(),
  { streaming: false },
);

const toast = useToast();
/** 根元素引用（用于事件委托取复制按钮） */
const rootRef = ref<HTMLDivElement | null>(null);
void rootRef.value;

/** 渲染结果：内容变化时才重算 */
const html = computed(() => {
  let src = props.content || '';
  // 流式输出中若代码块未闭合，补一个收尾围栏，避免渲染出半个乱块
  if (props.streaming && inFence(src)) src += '\n```';
  return renderMarkdown(src);
});

/**
 * 点击复制：用事件委托从 data-code 取原始代码。
 * @param e 鼠标事件
 */
async function onClick(e: MouseEvent): Promise<void> {
  const target = e.target as HTMLElement;
  if (!target.classList.contains('ds-code-copy')) return;
  const code = target.dataset.code || '';
  const ok = await copyText(code);
  if (ok) {
    toast.success('代码已复制');
    const old = target.textContent;
    target.textContent = '已复制';
    window.setTimeout(() => { target.textContent = old; }, 1200);
  } else {
    toast.error('复制失败，请手动选择');
  }
}
</script>

<template>
  <div ref="rootRef" class="ds-md" @click="onClick">
    <!-- eslint-disable-next-line vue/no-v-html -- 内容已在 renderMarkdown 中转义 -->
    <div class="ds-md-body" v-html="html" />
    <span v-if="streaming" class="ds-md-caret" aria-hidden="true" />
  </div>
</template>

<style scoped>
.ds-md { font-size: var(--ds-font-md); line-height: 1.75; color: var(--ds-text); }

/* ============ 标题 ============ */
.ds-md :deep(.ds-md-h1) { font-size: 22px; font-weight: 600; margin: 18px 0 10px; }
.ds-md :deep(.ds-md-h2) { font-size: 19px; font-weight: 600; margin: 16px 0 8px; }
.ds-md :deep(.ds-md-h3) { font-size: 16px; font-weight: 600; margin: 14px 0 6px; }
.ds-md :deep(.ds-md-h4),
.ds-md :deep(.ds-md-h5),
.ds-md :deep(.ds-md-h6) { font-size: 15px; font-weight: 600; margin: 12px 0 6px; }

/* ============ 段落与列表 ============ */
.ds-md :deep(.ds-md-p) { margin: 0 0 12px; }
.ds-md :deep(.ds-md-p:last-child) { margin-bottom: 0; }

.ds-md :deep(.ds-md-ul),
.ds-md :deep(.ds-md-ol) { margin: 0 0 12px; padding-left: 22px; }

.ds-md :deep(.ds-md-ul) { list-style: disc; }
.ds-md :deep(.ds-md-ol) { list-style: decimal; }

.ds-md :deep(.ds-md-ul li),
.ds-md :deep(.ds-md-ol li) { margin: 4px 0; }

/* ============ 引用 ============ */
.ds-md :deep(.ds-md-quote) {
  margin: 10px 0;
  padding: 8px 14px;
  border-left: 3px solid var(--ds-brand);
  background: var(--ds-bg-hover);
  border-radius: 0 var(--ds-radius-sm) var(--ds-radius-sm) 0;
  color: var(--ds-text-2);
}

/* ============ 分割线 ============ */
.ds-md :deep(.ds-md-hr) {
  border: none;
  border-top: 1px solid var(--ds-divider);
  margin: 16px 0;
}

/* ============ 表格 ============ */
.ds-md :deep(.ds-md-table-wrap) { overflow-x: auto; margin: 12px 0; }

.ds-md :deep(.ds-md-table) {
  border-collapse: collapse;
  font-size: var(--ds-font-sm);
  width: 100%;
}

.ds-md :deep(.ds-md-table th),
.ds-md :deep(.ds-md-table td) {
  border: 1px solid var(--ds-border);
  padding: 7px 12px;
  text-align: left;
}

.ds-md :deep(.ds-md-table th) { background: var(--ds-bg-hover); font-weight: 600; }

/* ============ 代码块 ============ */
.ds-md :deep(.ds-code-block) {
  margin: 12px 0;
  border: 1px solid var(--ds-border);
  border-radius: var(--ds-radius-md);
  overflow: hidden;
  background: var(--ds-bg-code);
}

.ds-md :deep(.ds-code-head) {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 6px 12px;
  background: var(--ds-bg-hover);
  border-bottom: 1px solid var(--ds-border);
}

.ds-md :deep(.ds-code-lang) {
  font-size: var(--ds-font-xs);
  color: var(--ds-text-3);
  text-transform: uppercase;
  letter-spacing: 0.4px;
}

.ds-md :deep(.ds-code-copy) {
  font-size: var(--ds-font-xs);
  color: var(--ds-text-3);
  padding: 2px 8px;
  border-radius: var(--ds-radius-xs);
}

.ds-md :deep(.ds-code-copy:hover) { background: var(--ds-bg-active); color: var(--ds-text); }

.ds-md :deep(.ds-code-pre) {
  margin: 0;
  padding: 14px 16px;
  overflow-x: auto;
  font-size: 13px;
  line-height: 1.7;
}

.ds-md :deep(.ds-code-pre code) { background: none; padding: 0; }

/* 语法高亮配色（跟随主题） */
.ds-md :deep(.ds-hl-comment) { color: var(--ds-text-3); font-style: italic; }
.ds-md :deep(.ds-hl-string) { color: #0a7d55; }
.ds-md :deep(.ds-hl-number) { color: #c2410c; }
.ds-md :deep(.ds-hl-keyword) { color: #7c3aed; }
.ds-md :deep(.ds-hl-builtin) { color: #0284c7; }
.ds-md :deep(.ds-hl-fn) { color: #1d4ed8; }
.ds-md :deep(.ds-hl-tag) { color: #be123c; }

:root[data-theme='dark'] .ds-md :deep(.ds-hl-string) { color: #7ee2b8; }
:root[data-theme='dark'] .ds-md :deep(.ds-hl-number) { color: #fdba74; }
:root[data-theme='dark'] .ds-md :deep(.ds-hl-keyword) { color: #c4b5fd; }
:root[data-theme='dark'] .ds-md :deep(.ds-hl-builtin) { color: #7dd3fc; }
:root[data-theme='dark'] .ds-md :deep(.ds-hl-fn) { color: #93c5fd; }
:root[data-theme='dark'] .ds-md :deep(.ds-hl-tag) { color: #fda4af; }

/* ============ 流式光标 ============ */
.ds-md-caret {
  display: inline-block;
  width: 7px;
  height: 15px;
  margin-left: 2px;
  background: var(--ds-brand);
  border-radius: 1px;
  vertical-align: text-bottom;
  animation: ds-blink 1s steps(1, end) infinite;
}
</style>
