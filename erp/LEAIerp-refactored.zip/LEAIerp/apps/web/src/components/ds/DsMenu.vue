<!-- src/components/ds/DsMenu.vue -->
<script setup lang="ts">
/**
 * DsMenu —— 垂直导航菜单（支持多级嵌套子菜单）。
 *
 * 扁平 items + 可选分组（group）渲染一级；带 children 的项渲染为可展开子菜单，
 * 递归支持任意层级。当前项品牌色高亮，支持徽标；点击叶子通过 select 事件抛 item，
 * 业务侧自行决定路由跳转或其他行为（组件不依赖 vue-router）。
 */
import { computed, ref, watch } from 'vue';
import type { NavItem } from './types';

/** 组件入参 */
const props = withDefaults(
  defineProps<{
    /** 当前选中值（v-model） */
    modelValue: string | number;
    /** 菜单项（支持 children 嵌套） */
    items: NavItem[];
    /** 是否折叠为纯图标（窄侧边栏场景） */
    collapsed?: boolean;
    /** 菜单宽度（px） */
    width?: number;
  }>(),
  { items: () => [], collapsed: false, width: 220 },
);

/** 事件 */
const emit = defineEmits<{ (e: 'update:modelValue', v: string | number): void; (e: 'select', item: NavItem): void }>();

/** 展开状态的父节点 to 集合 */
const expanded = ref<Set<string>>(new Set());

/**
 * 是否选中（支持前缀高亮：/a 高亮 /a/1）。
 *
 * 菜单项的 to 允许带 query —— 同一张物理表按业务标识拆页时会写成
 * `/crud/kuyou_enclosure?type=1`（采购附件）与 `?type=2`（销售附件）。
 * 这类「同路径不同 query」的项必须连 query 一起比对，否则两个入口会同时
 * 高亮、且谁都不算激活导致父级不自动展开。
 *
 * @param to 菜单项目标地址（可含 query）
 * @returns 是否命中当前激活地址
 */
function isActive(to: string): boolean {
  const cur = String(props.modelValue ?? '');
  const [curPath, curQuery = ''] = cur.split('?');
  const [toPath, toQuery = ''] = String(to ?? '').split('?');
  if (toQuery) {
    // 带 query 的项：路径相同还不够，query 必须完全一致才能区分开
    return curPath === toPath && curQuery === toQuery;
  }
  if (curPath === toPath) return true;
  return curPath.startsWith(toPath + '/');
}

/** 某父节点是否为当前激活路径的祖先（用于默认展开） */
function isAncestorOfActive(item: NavItem): boolean {
  if (!item.children?.length) return false;
  return item.children.some((c) => isActive(c.to) || isAncestorOfActive(c));
}

/** 默认展开包含当前激活项的全部父级 */
function syncExpand(): void {
  const set = new Set<string>();
  const walk = (list: NavItem[]) => {
    for (const it of list) {
      if (it.children?.length && isAncestorOfActive(it)) {
        set.add(it.to);
        walk(it.children);
      }
    }
  };
  walk(props.items);
  expanded.value = set;
}
watch(() => [props.modelValue, props.items], syncExpand, { immediate: true, deep: true });

/**
 * 点击菜单项：父节点切换展开，叶子节点抛出 select。
 * @param item 菜单项
 * @returns 无
 */
function pick(item: NavItem): void {
  if (item.disabled) return;
  if (item.children?.length) {
    const s = new Set(expanded.value);
    if (s.has(item.to)) s.delete(item.to);
    else s.add(item.to);
    expanded.value = s;
    return;
  }
  emit('update:modelValue', item.to);
  emit('select', item);
}
</script>

<template>
  <nav class="ds-menu" :class="{ 'is-collapsed': collapsed }" :style="{ width: (collapsed ? 64 : width) + 'px' }">
    <DsMenuNode
      v-for="item in items"
      :key="item.to"
      :node="item"
      :depth="0"
      :model-value="modelValue"
      :expanded="expanded"
      :collapsed="collapsed"
      @pick="pick"
    />
  </nav>
</template>

<script lang="ts">
/**
 * DsMenuNode —— 递归菜单节点（父/子共用，支持无限层级）。
 * 通过普通 <script> 块 + components 选项注册到 DsMenu 作用域实现自引用。
 */
import { defineComponent, h, type PropType } from 'vue';

const DsMenuNode = defineComponent({
  name: 'DsMenuNode',
  props: {
    node: { type: Object as PropType<any>, required: true },
    depth: { type: Number, default: 0 },
    modelValue: { type: [String, Number], default: '' },
    expanded: { type: Object as PropType<Set<string>>, required: true },
    collapsed: { type: Boolean, default: false },
  },
  emits: ['pick'],
  setup(props, { emit }) {
    const hasChildren = computed(() => !!props.node.children?.length);
    const isOpen = computed(() => props.expanded.has(props.node.to));
    const active = computed(() => {
      const cur = String(props.modelValue);
      return cur === props.node.to || cur.startsWith(props.node.to + '/');
    });
    // 图标：长度>6 视为 SVG path d，否则当文本
    const isSvg = computed(() => !!props.node.icon && props.node.icon.length > 6);

    return () => {
      const n = props.node;
      // 缩进：顶级左内距与容器右内距相同（两侧留白一致），每级再缩进 16px
      const pad = 12 + props.depth * 16;

      const labelEl = h(
        'span',
        { class: 'ds-menu-label' },
        props.collapsed && props.depth === 0 ? null : n.label,
      );
      const iconEl = h(
        'span',
        { class: 'ds-menu-icon' },
        isSvg.value
          ? h('svg', { viewBox: '0 0 24 24', innerHTML: `<path d="${n.icon}" />` })
          : h('em', n.icon || '•'),
      );
      const badgeEl = !props.collapsed && n.badge ? h('span', { class: 'ds-menu-badge' }, String(n.badge)) : null;

      // 父节点：可展开，渲染 caret + 递归子节点
      if (hasChildren.value) {
        const caret = h('span', { class: ['ds-menu-caret', { 'is-open': isOpen.value }] }, '›');
        const head = h(
          'div',
          {
            class: ['ds-menu-item', 'is-parent', { 'is-active': active.value, 'is-disabled': n.disabled }],
            style: { paddingLeft: pad + 'px' },
            title: props.collapsed ? n.label : undefined,
            onClick: () => emit('pick', n),
          },
          props.collapsed && props.depth === 0
            ? [iconEl]
            : [iconEl, labelEl, badgeEl, caret],
        );
        const children = isOpen.value
          ? h(
              'div',
              { class: 'ds-menu-children' },
              n.children!.map((c: NavItem) =>
                h(DsMenuNode, {
                  key: c.to,
                  node: c,
                  depth: props.depth + 1,
                  modelValue: props.modelValue as any,
                  expanded: props.expanded,
                  collapsed: props.collapsed,
                  onPick: (nn: any) => emit('pick', nn),
                }),
              ),
            )
          : null;
        return h('div', { class: 'ds-menu-group' }, [head, children]);
      }

      // 叶子节点：渲染成真实链接，保留新标签页打开 / 聚焦 / 右键等原生行为；
      // 普通左键仍走 SPA 路由（交给 select 事件），带修饰键时放行浏览器默认行为。
      const leaf = h(
        'a',
        {
          class: ['ds-menu-item', { 'is-active': active.value, 'is-disabled': n.disabled }],
          style: { paddingLeft: pad + 'px' },
          href: n.disabled ? undefined : n.to,
          title: props.collapsed ? n.label : undefined,
          onClick: (e: MouseEvent) => {
            if (n.disabled || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey || e.button !== 0) return;
            e.preventDefault();
            emit('pick', n);
          },
        },
        props.collapsed && props.depth === 0 ? [iconEl] : [iconEl, labelEl, badgeEl],
      );
      return leaf;
    };
  },
});

export default defineComponent({
  name: 'DsMenuScope',
  components: { DsMenuNode },
});
</script>

<style scoped>
.ds-menu {
  /* 侧栏间距统一规则：组内(4) < 组间(12)；缩进 / 图标 / 圆角全部走令牌，便于整体调参 */
  --menu-pad-x: var(--ds-space-3); /* 左右留白：与容器 padding 一致，保证两侧等距 */
  --menu-radius: var(--ds-radius); /* 圆角与同类面板统一（10px） */
  --menu-text: var(--ds-font-sm); /* 统一字号 13px */
  --menu-icon: 12px; /* 图标略小于文字（文字 13px） */
  --menu-gap-in: var(--ds-space-1); /* 组内条目间距 4px */
  --menu-gap-out: var(--ds-space-3); /* 组间间距 12px（比组内更松） */

  display: flex;
  flex-direction: column;
  gap: var(--menu-gap-out); /* 顶级分组 / 单条之间更松 */
  height: 100%;
  padding: var(--ds-space-3); /* 侧栏两侧留白一致（上下 12 / 左右 12） */
  overflow-y: auto;
  overflow-x: hidden;
  background: var(--ds-bg-soft);
  border-right: 1px solid var(--ds-border);
  transition: width var(--ds-dur) var(--ds-ease);
}
</style>

<style scoped>
/* 节点元素由 DsMenuNode（h() 渲染）产出，用 :deep() 穿透 scoped */
:deep(.ds-menu-item) {
  display: flex;
  align-items: center;
  gap: var(--ds-space-2); /* 图文间距统一 8px */
  padding: 10px var(--menu-pad-x); /* 上下留白充足，点击区域够大 */
  min-height: 36px; /* 保证足够大的可点击高度 */
  border-radius: var(--menu-radius); /* 圆角统一 */
  color: var(--ds-text-2);
  font-size: var(--menu-text); /* 统一字号 13px */
  line-height: 1.4;
  cursor: pointer;
  white-space: nowrap;
  transition: background var(--ds-dur-fast) var(--ds-ease), color var(--ds-dur-fast) var(--ds-ease);
}
:deep(a.ds-menu-item) { text-decoration: none; outline: none; }
:deep(a.ds-menu-item:focus-visible) { box-shadow: 0 0 0 2px var(--ds-brand-weak); }
:deep(.ds-menu-item:hover) { background: var(--ds-bg-hover); color: var(--ds-text); }
:deep(.ds-menu-item.is-active) { background: var(--ds-brand-weak); color: var(--ds-brand); font-weight: 600; }
:deep(.ds-menu-item.is-disabled) { opacity: 0.45; cursor: not-allowed; }

:deep(.ds-menu-icon) {
  width: var(--menu-icon);
  flex: 0 0 var(--menu-icon);
  display: grid;
  place-items: center;
  color: currentColor;
}
:deep(.ds-menu-icon svg) {
  width: var(--menu-icon);
  height: var(--menu-icon);
  fill: none; stroke: currentColor; stroke-width: 1.8; stroke-linecap: round; stroke-linejoin: round;
}
:deep(.ds-menu-icon em) { font-style: normal; font-size: var(--ds-font-xs); opacity: 0.8; }
:deep(.ds-menu-label) { flex: 1; min-width: 0; overflow: hidden; text-overflow: ellipsis; }

:deep(.ds-menu-caret) {
  margin-left: auto;
  font-size: 14px;
  line-height: 1;
  color: var(--ds-text-3);
  transition: transform var(--ds-dur-fast) var(--ds-ease);
}
:deep(.ds-menu-caret.is-open) { transform: rotate(90deg); }

/* 间距递进规则（统一令牌）：子项↔子项 4 < 父项↔首子项(=顶级分组间) 12，组间明显比组内更松 */
:deep(.ds-menu-group) { display: flex; flex-direction: column; gap: var(--menu-gap-out); }
:deep(.ds-menu-children) { display: flex; flex-direction: column; gap: var(--menu-gap-in); }

:deep(.ds-menu-badge) {
  min-width: 18px; height: 18px; padding: 0 5px;
  display: inline-grid; place-items: center;
  border-radius: 9px; background: var(--ds-brand); color: #fff;
  font-size: 11px; font-weight: 600;
}

/* 折叠态（仅一级显示图标）：保持对称居中，点击区同样够大 */
.ds-menu.is-collapsed :deep(.ds-menu-item) { justify-content: center; padding: 10px 0; }
</style>
