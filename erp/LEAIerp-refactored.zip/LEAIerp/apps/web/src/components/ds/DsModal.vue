<!-- src/components/ds/DsModal.vue -->
<script setup lang="ts">
/**
 * 弹窗
 * ------------------------------------------------------------------
 * 居中对话框：遮罩点击关闭、ESC 关闭、打开时锁定 body 滚动、出场动画、底部操作区插槽。
 * 支持拖拽右下角 / 右边缘 / 下边缘改变大小，并可一键最大化 / 还原（resizable=false 时关闭该能力）。
 * 不引入任何弹层库。
 */
import { computed, watch, onBeforeUnmount, ref } from 'vue';

/** 组件入参 */
const props = withDefaults(
  defineProps<{
    /** 是否显示（v-model 绑定） */
    modelValue: boolean;
    /** 标题 */
    title?: string;
    /** 初始宽度（px） */
    width?: number;
    /** 是否点击遮罩关闭 */
    closeOnMask?: boolean;
    /** 是否显示右上角关闭按钮 */
    closable?: boolean;
    /** 是否允许拖拽改大小 / 最大化（表单类弹窗建议开启，确认框建议关闭） */
    resizable?: boolean;
  }>(),
  { title: '', width: 520, closeOnMask: true, closable: true, resizable: true },
);

/** 事件 */
const emit = defineEmits<{
  (e: 'update:modelValue', v: boolean): void;
  (e: 'close'): void;
}>();

/* ---------------- 尺寸状态 ---------------- */
const MIN_W = 380;
const MIN_H = 200;
const customW = ref<number | null>(null);
const customH = ref<number | null>(null);
const maximized = ref(false);
const resizing = ref(false);

const dialogStyle = computed<Record<string, string>>(() => {
  if (maximized.value) return { width: '94vw', height: '90vh' };
  const style: Record<string, string> = { width: `${customW.value ?? Math.max(MIN_W, props.width)}px` };
  if (customH.value) style.height = `${customH.value}px`;
  return style;
});

function toggleMax(): void {
  if (!props.resizable) return;
  maximized.value = !maximized.value;
}

type ResizeAxis = 'x' | 'y' | 'both';

/** 拖拽改大小：以当前渲染尺寸为基准，避免从 auto 高度起步时跳动 */
function startResize(e: PointerEvent, axis: ResizeAxis): void {
  if (!props.resizable || maximized.value) return;
  const el = (e.currentTarget as HTMLElement)?.parentElement;
  if (!el) return;
  e.preventDefault();
  e.stopPropagation();
  resizing.value = true;

  const rect = el.getBoundingClientRect();
  const startX = e.clientX;
  const startY = e.clientY;
  const startW = rect.width;
  const startH = rect.height;
  customW.value = Math.round(startW);
  customH.value = Math.round(startH);

  const maxW = () => Math.max(MIN_W, window.innerWidth - 48);
  const maxH = () => Math.max(MIN_H, window.innerHeight - 64);

  const onMove = (ev: PointerEvent) => {
    if (axis === 'x' || axis === 'both') {
      customW.value = Math.min(maxW(), Math.max(MIN_W, Math.round(startW + (ev.clientX - startX))));
    }
    if (axis === 'y' || axis === 'both') {
      customH.value = Math.min(maxH(), Math.max(MIN_H, Math.round(startH + (ev.clientY - startY))));
    }
  };
  const onUp = () => {
    resizing.value = false;
    window.removeEventListener('pointermove', onMove);
    window.removeEventListener('pointerup', onUp);
  };
  window.addEventListener('pointermove', onMove);
  window.addEventListener('pointerup', onUp);
}

/**
 * 关闭弹窗：通知父组件并触发 close 事件。
 */
function close(): void {
  emit('update:modelValue', false);
  emit('close');
}

/** 点击遮罩（仅当点在遮罩本身而非内容区） */
function onMask(e: MouseEvent): void {
  if (props.closeOnMask && e.target === e.currentTarget) close();
}

/**
 * 键盘 ESC 关闭。
 * @param e 键盘事件
 */
function onKey(e: KeyboardEvent): void {
  if (e.key === 'Escape') close();
}

// 打开时：锁定页面滚动 + 监听 ESC；关闭时恢复
watch(
  () => props.modelValue,
  (open) => {
    if (typeof document === 'undefined') return;
    document.body.style.overflow = open ? 'hidden' : '';
    if (open) {
      document.addEventListener('keydown', onKey);
    } else {
      document.removeEventListener('keydown', onKey);
      // 关闭后复位尺寸，下次打开回到默认大小
      customW.value = null;
      customH.value = null;
      maximized.value = false;
      resizing.value = false;
    }
  },
);

// 组件卸载兜底：无论如何把滚动恢复，避免异常路径下页面卡死
onBeforeUnmount(() => {
  if (typeof document === 'undefined') return;
  document.body.style.overflow = '';
  document.removeEventListener('keydown', onKey);
});
</script>

<template>
  <Teleport to="body">
    <Transition name="ds-modal">
      <div v-if="modelValue" class="ds-modal-mask" @click="onMask">
        <div
          class="ds-modal"
          :class="{ 'is-resizing': resizing, 'is-max': maximized }"
          :style="dialogStyle"
          role="dialog"
          aria-modal="true"
        >
          <!-- 头部 -->
          <header class="ds-modal-head">
            <h3 class="ds-modal-title">{{ title }}</h3>
            <div class="ds-modal-ops">
              <button
                v-if="resizable"
                class="ds-modal-ico"
                type="button"
                :title="maximized ? '还原' : '最大化'"
                @click="toggleMax"
              >
                {{ maximized ? '❐' : '⛶' }}
              </button>
              <button v-if="closable" class="ds-modal-close" type="button" aria-label="关闭" @click="close">✕</button>
            </div>
          </header>

          <!-- 内容 -->
          <div class="ds-modal-body"><slot /></div>

          <!-- 底部操作区（没有内容则不渲染） -->
          <footer v-if="$slots.footer" class="ds-modal-foot"><slot name="footer" /></footer>

          <!-- 拖拽热区 -->
          <template v-if="resizable && !maximized">
            <span class="ds-modal-rz ds-modal-rz--x" @pointerdown="startResize($event, 'x')" />
            <span class="ds-modal-rz ds-modal-rz--y" @pointerdown="startResize($event, 'y')" />
            <span class="ds-modal-rz ds-modal-rz--corner" title="拖动调整大小" @pointerdown="startResize($event, 'both')" />
          </template>
        </div>
      </div>
    </Transition>
  </Teleport>
</template>

<style scoped>
.ds-modal-mask {
  position: fixed;
  inset: 0;
  background: rgba(15, 20, 28, 0.45);
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 20px;
  z-index: 1000;
  backdrop-filter: blur(2px);
}

.ds-modal {
  position: relative;
  background: var(--ds-bg-elevated);
  border-radius: var(--ds-radius-lg);
  box-shadow: var(--ds-shadow-lg);
  max-width: 100%;
  max-height: 86vh;
  display: flex;
  flex-direction: column;
  overflow: hidden;
}
.ds-modal.is-resizing {
  user-select: none;
}

.ds-modal-head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 16px 20px;
  border-bottom: 1px solid var(--ds-divider);
  flex: 0 0 auto;
}

.ds-modal-title { font-size: var(--ds-font-lg); font-weight: 600; margin: 0; }

.ds-modal-ops { display: flex; align-items: center; gap: 2px; }

.ds-modal-ico,
.ds-modal-close {
  width: 28px;
  height: 28px;
  border: 0;
  border-radius: var(--ds-radius-sm);
  background: transparent;
  color: var(--ds-text-3);
  display: inline-flex;
  align-items: center;
  justify-content: center;
  font-size: 14px;
  cursor: pointer;
}

.ds-modal-ico:hover,
.ds-modal-close:hover { background: var(--ds-bg-hover); color: var(--ds-text); }

.ds-modal-body { padding: 18px 20px; overflow-y: auto; flex: 1; min-height: 0; }

.ds-modal-foot {
  padding: 12px 20px;
  border-top: 1px solid var(--ds-divider);
  display: flex;
  justify-content: flex-end;
  gap: 10px;
  flex: 0 0 auto;
}

/* 拖拽热区 */
.ds-modal-rz { position: absolute; z-index: 4; }
.ds-modal-rz--x { top: 0; right: 0; width: 6px; height: 100%; cursor: ew-resize; }
.ds-modal-rz--y { left: 0; bottom: 0; width: 100%; height: 6px; cursor: ns-resize; }
.ds-modal-rz--corner { right: 0; bottom: 0; width: 16px; height: 16px; cursor: nwse-resize; }
.ds-modal-rz--x:hover,
.ds-modal-rz--y:hover { background: var(--ds-bg-hover); }

/* 出场动画：淡入 + 轻微上浮 */
.ds-modal-enter-active,
.ds-modal-leave-active { transition: opacity var(--ds-dur) var(--ds-ease); }

.ds-modal-enter-active .ds-modal,
.ds-modal-leave-active .ds-modal { transition: transform var(--ds-dur) var(--ds-ease); }

.ds-modal-enter-from,
.ds-modal-leave-to { opacity: 0; }

.ds-modal-enter-from .ds-modal,
.ds-modal-leave-to .ds-modal { transform: translateY(12px) scale(0.98); }
</style>
