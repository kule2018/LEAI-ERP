<!-- src/components/ds/DsPagination.vue -->
<script setup lang="ts">
/**
 * DsPagination —— 分页器。
 *
 * 兼容 Element Plus 的 layout 字符串写法（total, sizes, prev, pager, next, jumper），
 * 零依赖自绘：上一页 / 下一页 + 数字页码（带省略号折叠）+ 每页条数切换 + 总数展示。
 * 页码变化同时更新 v-model:currentPage 与 v-model:pageSize。
 */
import { computed } from 'vue';

/** 组件入参 */
const props = withDefaults(
  defineProps<{
    /** 当前页（v-model:currentPage） */
    currentPage: number;
    /** 每页条数（v-model:pageSize） */
    pageSize: number;
    /** 总条数 */
    total: number;
    /** 每页条数选项 */
    pageSizes?: number[];
    /** 布局（逗号分隔：total / sizes / prev / pager / next / jumper） */
    layout?: string;
    /** 最多显示几个数字页码（其余折叠为 …） */
    maxPages?: number;
  }>(),
  { pageSizes: () => [10, 20, 50], layout: 'total, sizes, prev, pager, next', maxPages: 7 },
);

/** 事件 */
const emit = defineEmits<{
  (e: 'update:currentPage', v: number): void;
  (e: 'update:pageSize', v: number): void;
  (e: 'change', page: number, pageSize: number): void;
}>();

/** 布局开关集合（把 layout 字符串拆成查表） */
const parts = computed(() => new Set(props.layout.split(',').map((s) => s.trim())));

/** 总页数 */
const pageCount = computed(() => Math.max(1, Math.ceil(props.total / Math.max(1, props.pageSize))));

/**
 * 数字页码列表：当前页附近连续展示，远处用 '…' 折叠。
 * @returns 页码数组（元素为数字或字符串 '…'）
 */
const pages = computed<(number | string)[]>(() => {
  const cur = props.currentPage;
  const total = pageCount.value;
  const max = Math.max(5, props.maxPages);
  if (total <= max) return Array.from({ length: total }, (_, i) => i + 1);
  const half = Math.floor(max / 2);
  let start = cur - half;
  let end = cur + half;
  if (start < 1) {
    start = 1;
    end = max;
  }
  if (end > total) {
    end = total;
    start = total - max + 1;
  }
  const out: (number | string)[] = [];
  if (start > 1) {
    out.push(1);
    if (start > 2) out.push('…');
  }
  for (let i = start; i <= end; i++) out.push(i);
  if (end < total) {
    if (end < total - 1) out.push('…');
    out.push(total);
  }
  return out;
});

/**
 * 跳转到指定页（夹在合法范围，无变化不触发）。
 * @param p 目标页
 * @returns 无
 */
function go(p: number): void {
  const next = Math.min(pageCount.value, Math.max(1, p));
  if (next === props.currentPage) return;
  emit('update:currentPage', next);
  emit('change', next, props.pageSize);
}

/**
 * 切换每页条数：保持「当前页第一条数据」仍在视野内，重新计算页码。
 * @param size 新的每页条数
 * @returns 无
 */
function onSize(size: number): void {
  const firstIndex = (props.currentPage - 1) * props.pageSize;
  const nextPage = Math.floor(firstIndex / size) + 1;
  emit('update:pageSize', size);
  emit('update:currentPage', nextPage);
  emit('change', nextPage, size);
}
</script>

<template>
  <div class="ds-pager">
    <!-- 总数 -->
    <span v-if="parts.has('total')" class="ds-pager__total">共 {{ total }} 条</span>

    <!-- 每页条数 -->
    <label v-if="parts.has('sizes')" class="ds-pager__sizes">
      <select :value="pageSize" @change="onSize(Number(($event.target as HTMLSelectElement).value))">
        <option v-for="s in pageSizes" :key="s" :value="s">{{ s }} 条/页</option>
      </select>
    </label>

    <!-- 上一页 -->
    <button
      v-if="parts.has('prev')"
      type="button"
      class="ds-pager__btn"
      :disabled="currentPage <= 1"
      title="上一页"
      @click="go(currentPage - 1)"
    >
      ‹
    </button>

    <!-- 数字页码 -->
    <template v-if="parts.has('pager')">
      <button
        v-for="(p, i) in pages"
        :key="i"
        type="button"
        class="ds-pager__num"
        :class="{ 'is-active': p === currentPage, 'is-gap': p === '…' }"
        :disabled="p === '…'"
        @click="typeof p === 'number' && go(p)"
      >
        {{ p }}
      </button>
    </template>

    <!-- 下一页 -->
    <button
      v-if="parts.has('next')"
      type="button"
      class="ds-pager__btn"
      :disabled="currentPage >= pageCount"
      title="下一页"
      @click="go(currentPage + 1)"
    >
      ›
    </button>

    <!-- 快速跳转 -->
    <span v-if="parts.has('jumper')" class="ds-pager__jumper">
      跳至
      <input
        type="text"
        :value="currentPage"
        @keydown.enter="go(Number(($event.target as HTMLInputElement).value))"
      />
      页
    </span>
  </div>
</template>

<style scoped>
.ds-pager {
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: var(--ds-gap-inner);
  font-size: var(--ds-font-sm);
  color: var(--ds-text-2);
  user-select: none;
}
.ds-pager__total { color: var(--ds-text-3); margin-right: var(--ds-space-1); font-variant-numeric: tabular-nums; }

.ds-pager__sizes select {
  height: var(--ds-ctl-h-sm);
  padding: 0 var(--ds-space-2);
  border: 1px solid var(--ds-border);
  border-radius: var(--ds-radius-ctl);
  background: var(--ds-bg-elevated);
  color: var(--ds-text-2);
  font-size: var(--ds-font-xs);
  font-family: inherit;
  cursor: pointer;
}
.ds-pager__sizes select:focus { outline: none; border-color: var(--ds-brand); }

.ds-pager__btn,
.ds-pager__num {
  min-width: var(--ds-hit);
  height: var(--ds-hit);
  padding: 0 var(--ds-space-2);
  border: 1px solid var(--ds-border);
  border-radius: var(--ds-radius-ctl);
  background: var(--ds-bg-elevated);
  color: var(--ds-text-2);
  font-size: var(--ds-font-sm);
  font-family: inherit;
  cursor: pointer;
  transition: all var(--ds-dur-fast) var(--ds-ease);
  font-variant-numeric: tabular-nums;
}
.ds-pager__btn:hover:not(:disabled),
.ds-pager__num:hover:not(:disabled):not(.is-active) { border-color: var(--ds-brand); color: var(--ds-brand); }
.ds-pager__btn:disabled { opacity: 0.45; cursor: not-allowed; }
.ds-pager__num.is-active { background: var(--ds-brand); border-color: var(--ds-brand); color: #fff; font-weight: 600; }
.ds-pager__num.is-gap { border: none; background: none; cursor: default; color: var(--ds-text-3); }

.ds-pager__jumper { display: inline-flex; align-items: center; gap: var(--ds-space-1); color: var(--ds-text-3); }
.ds-pager__jumper input {
  width: 48px;
  height: var(--ds-ctl-h-sm);
  text-align: center;
  border: 1px solid var(--ds-border);
  border-radius: var(--ds-radius-ctl);
  background: var(--ds-bg-elevated);
  color: var(--ds-text);
  font-size: var(--ds-font-sm);
  font-family: inherit;
  outline: none;
}
.ds-pager__jumper input:focus { border-color: var(--ds-brand); }
</style>
