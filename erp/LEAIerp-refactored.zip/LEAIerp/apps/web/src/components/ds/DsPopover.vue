<!-- src/components/ds/DsPopover.vue -->
<script setup lang="ts">
/**
 * DsPopover —— 气泡卡片。
 *
 * 与 Tooltip 的区别：Popover 承载「富内容」（标题 + 任意 DOM / 组件），
 * 点击触发；Tooltip 只承载纯文字、悬停触发。
 * 定位为简化实现：上下左右四个方向相对触发器偏移，不做碰撞检测
 * （页面边缘场景可用 placement 换方向解决）。
 */
import { usePopover } from './usePopover';

/** 组件入参 */
const props = withDefaults(
  defineProps<{
    /** 气泡标题 */
    title?: string;
    /** 弹出方向 */
    placement?: 'top' | 'bottom' | 'left' | 'right';
    /** 触发方式：click 点击 / hover 悬停 */
    trigger?: 'click' | 'hover';
    /** 是否禁用 */
    disabled?: boolean;
    /** 气泡宽度（px） */
    width?: number;
  }>(),
  { title: '', placement: 'bottom', trigger: 'click', disabled: false, width: 240 },
);

// 浮层控制
const { open, rootRef, toggle, close } = usePopover();
void rootRef;

/**
 * 触发器鼠标进入（hover 模式）。
 * @returns 无
 */
function onEnter(): void {
  if (props.trigger === 'hover' && !props.disabled) toggle();
}

/**
 * 触发器鼠标离开（hover 模式）。
 * @returns 无
 */
function onLeave(): void {
  if (props.trigger === 'hover') close();
}
</script>

<template>
  <span
    ref="rootRef"
    class="ds-popover"
    @click="trigger === 'click' && !disabled && toggle()"
    @mouseenter="onEnter"
    @mouseleave="onLeave"
  >
    <!-- 触发器 -->
    <span class="ds-popover-ref"><slot name="reference" /></span>

    <!-- 气泡 -->
    <Transition name="ds-pop">
      <span
        v-if="open"
        class="ds-popover-pop"
        :class="`is-${placement}`"
        :style="{ width: width + 'px' }"
        @click.stop
      >
        <span v-if="title || $slots.title" class="ds-popover-title">
          <slot name="title">{{ title }}</slot>
        </span>
        <span class="ds-popover-body"><slot /></span>
      </span>
    </Transition>
  </span>
</template>

<style scoped>
.ds-popover { position: relative; display: inline-flex; }
.ds-popover-ref { display: inline-flex; }

.ds-popover-pop {
  position: absolute;
  z-index: 200;
  display: flex;
  flex-direction: column;
  gap: 4px;
  padding: 10px 12px;
  background: var(--ds-bg-elevated);
  border: 1px solid var(--ds-border);
  border-radius: var(--ds-radius);
  box-shadow: var(--ds-shadow-md);
  font-size: var(--ds-font-sm);
  color: var(--ds-text-2);
  line-height: 1.6;
}
/* 四个方向的偏移 */
.ds-popover-pop.is-bottom { top: calc(100% + 8px); left: 50%; transform: translateX(-50%); }
.ds-popover-pop.is-top { bottom: calc(100% + 8px); left: 50%; transform: translateX(-50%); }
.ds-popover-pop.is-left { right: calc(100% + 8px); top: 50%; transform: translateY(-50%); }
.ds-popover-pop.is-right { left: calc(100% + 8px); top: 50%; transform: translateY(-50%); }

.ds-popover-title { font-weight: 600; color: var(--ds-text); }

/* 进出动画 */
.ds-pop-enter-active,
.ds-pop-leave-active { transition: opacity var(--ds-dur-fast) var(--ds-ease), transform var(--ds-dur-fast) var(--ds-ease); }
.ds-pop-enter-from,
.ds-pop-leave-to { opacity: 0; }
.ds-pop-enter-from.is-bottom,
.ds-pop-leave-to.is-bottom { transform: translateX(-50%) translateY(-4px); }
.ds-pop-enter-from.is-top,
.ds-pop-leave-to.is-top { transform: translateX(-50%) translateY(4px); }
</style>
