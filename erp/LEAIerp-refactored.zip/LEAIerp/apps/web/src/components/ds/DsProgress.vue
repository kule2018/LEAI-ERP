<!-- src/components/ds/DsProgress.vue -->
<script setup lang="ts">
/**
 * 进度条
 * ------------------------------------------------------------------
 * 支持普通进度、状态色（进行中/成功/失败）、是否显示百分比文案。
 * 用于：任务执行进度、上传进度、配额占用等。
 */
import { computed } from 'vue';

/** 组件入参 */
const props = withDefaults(
  defineProps<{
    /** 当前值（0~1 的小数，或 0~100 的整数——由 max 决定） */
    value?: number;
    /** percentage 别名：兼容 <DsProgress :percentage="60" /> 的写法（与 value 等价） */
    percentage?: number;
    /** 最大值，默认 100（此时 value / percentage 传 0~100） */
    max?: number;
    /** 状态色：running 蓝 / success 绿 / danger 红 / warning 橙；exception 视为 danger */
    status?: 'running' | 'success' | 'danger' | 'warning' | 'exception';
    /** 是否显示右侧百分比 */
    showText?: boolean;
    /** 细条（用于卡片内嵌） */
    thin?: boolean;
    /** 未知进度：走条纹动画（如「排队中」） */
    indeterminate?: boolean;
  }>(),
  { value: 0, percentage: undefined, max: 100, status: 'running', showText: false, thin: false, indeterminate: false },
);

/** value 与 percentage 等价：都没传时取 0，避免调用方传错属性导致进度条恒为 0 */
const current = computed(() => {
  const v = Number(props.value ?? props.percentage);
  return Number.isFinite(v) ? v : 0;
});

/** 归一化到 0~100 的百分比 */
const percent = computed(() => {
  if (props.indeterminate) return 100;
  const m = Number(props.max) || 100;
  return Math.max(0, Math.min(100, (current.value / m) * 100));
});

/** exception 是 Element 语义的「异常」，内部统一按 danger 渲染 */
const barStatus = computed(() => (props.status === 'exception' ? 'danger' : props.status));
</script>

<template>
  <div class="ds-progress" :class="{ 'is-thin': thin }">
    <div class="ds-progress-track">
      <div
        class="ds-progress-bar"
        :class="[`is-${barStatus}`, { 'is-indeterminate': indeterminate }]"
        :style="{ width: percent + '%' }"
      />
    </div>
    <span v-if="showText && !indeterminate" class="ds-progress-text">{{ Math.round(percent) }}%</span>
  </div>
</template>

<style scoped>
.ds-progress {
  display: flex;
  align-items: center;
  gap: 8px;
  width: 100%;
}

.ds-progress-track {
  flex: 1;
  height: 8px;
  background: var(--ds-bg-hover);
  border-radius: var(--ds-radius-full);
  overflow: hidden;
}

.is-thin .ds-progress-track { height: 4px; }

.ds-progress-bar {
  height: 100%;
  border-radius: var(--ds-radius-full);
  transition: width var(--ds-dur-slow) var(--ds-ease), background-color var(--ds-dur) var(--ds-ease);
}

.ds-progress-bar.is-running { background: var(--ds-brand); }
.ds-progress-bar.is-success { background: var(--ds-success); }
.ds-progress-bar.is-danger { background: var(--ds-danger); }
.ds-progress-bar.is-warning { background: var(--ds-warning); }

/* 未知进度：来回流动的条纹 */
.ds-progress-bar.is-indeterminate {
  background-image: linear-gradient(
    90deg,
    transparent 0%,
    var(--ds-brand) 45%,
    var(--ds-brand) 55%,
    transparent 100%
  );
  background-size: 220% 100%;
  animation: ds-progress-flow 1.2s linear infinite;
  width: 40% !important;
}

@keyframes ds-progress-flow {
  0% { background-position: 120% 0; }
  100% { background-position: -20% 0; }
}

.ds-progress-text {
  font-size: var(--ds-font-sm);
  color: var(--ds-text-3);
  min-width: 38px;
  text-align: right;
  font-variant-numeric: tabular-nums;
}
</style>
