<!-- 全局输入弹窗：与 usePrompt 配套，在 App.vue 挂载一次 -->
<script setup lang="ts">
import { promptState, resolvePrompt } from './usePrompt';
</script>

<template>
  <DsModal
    :model-value="promptState.visible"
    :title="promptState.title"
    :width="420"
    :close-on-mask="false"
    :resizable="false"
    @update:model-value="(v) => !v && resolvePrompt(null)"
  >
    <p class="ds-prompt-msg">{{ promptState.message }}</p>
    <DsInput v-model="promptState.value" :placeholder="promptState.placeholder" />
    <template #footer>
      <div class="ds-prompt-foot">
        <DsButton @click="resolvePrompt(null)">取消</DsButton>
        <DsButton variant="primary" @click="resolvePrompt(String(promptState.value ?? ''))">确定</DsButton>
      </div>
    </template>
  </DsModal>
</template>

<style scoped>
.ds-prompt-msg { margin: 0 0 10px; color: var(--ds-text-2); font-size: var(--ds-font-md); line-height: 1.6; }
.ds-prompt-foot { display: flex; justify-content: flex-end; gap: 8px; }
</style>
