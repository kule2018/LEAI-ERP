<!-- src/components/ds/DsRadio.vue -->
<script setup lang="ts">
/**
 * DsRadio —— 单选框。
 *
 * 组模式：多个 DsRadio 绑定同一个 v-model，各传不同 value，
 * 选中即写入；用法与 DsCheckbox 组模式对称，不需要额外 Group 组件。
 */
import { computed } from 'vue';

/** 组件入参 */
const props = withDefaults(
  defineProps<{
    /** 当前组的选中值（v-model） */
    modelValue: any;
    /** 本选项的值 */
    value: any;
    /** 是否禁用 */
    disabled?: boolean;
    /** 尺寸：sm / md */
    size?: 'sm' | 'md';
  }>(),
  { disabled: false, size: 'md' },
);

/** 事件 */
const emit = defineEmits<{ (e: 'update:modelValue', v: any): void; (e: 'change', v: any): void }>();

/** 是否选中 */
const checked = computed(() => props.modelValue === props.value);

/**
 * 选中本项（已选中则忽略，与原生 radio 行为一致）。
 * @returns 无
 */
function pick(): void {
  if (props.disabled || checked.value) return;
  emit('update:modelValue', props.value);
  emit('change', props.value);
}
</script>

<template>
  <label class="ds-radio" :class="[`is-${size}`, { 'is-disabled': disabled }]" @click.prevent="pick">
    <input type="radio" :checked="checked" :disabled="disabled" tabindex="-1" />
    <span class="ds-radio-label"><slot>{{ String(value) }}</slot></span>
  </label>
</template>

<style scoped>
.ds-radio { display: inline-flex; align-items: center; gap: 8px; cursor: pointer; user-select: none; }
.ds-radio.is-sm { font-size: var(--ds-font-sm); }
.ds-radio.is-disabled { cursor: not-allowed; opacity: 0.55; }
.ds-radio-label { color: var(--ds-text-2); line-height: 1.5; }
</style>
