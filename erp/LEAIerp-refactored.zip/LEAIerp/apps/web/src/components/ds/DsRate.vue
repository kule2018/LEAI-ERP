<!-- src/components/ds/DsRate.vue -->
<script setup lang="ts">
/**
 * DsRate —— 评分（星级）。
 *
 * 支持半星（allowHalf）、自定义星数、只读展示与「x 分」文案；
 * hover 时实时预览选中效果，鼠标移出后恢复真实值。
 */
import { computed, ref } from 'vue';

/** 组件入参 */
const props = withDefaults(
  defineProps<{
    /** 当前分值（v-model） */
    modelValue: number;
    /** 星星总数 */
    count?: number;
    /** 是否允许半星 */
    allowHalf?: boolean;
    /** 是否禁用 */
    disabled?: boolean;
    /** 是否显示 「x.x 分」 文案 */
    showText?: boolean;
    /** 星星尺寸（px） */
    size?: number;
  }>(),
  { count: 5, allowHalf: false, disabled: false, showText: false, size: 20 },
);

/** 事件 */
const emit = defineEmits<{ (e: 'update:modelValue', v: number): void; (e: 'change', v: number): void }>();

/** hover 预览值（-1 表示没有预览） */
const hover = ref(-1);

/** 实际展示值：hover 优先于真实值 */
const display = computed(() => (hover.value >= 0 ? hover.value : props.modelValue));

/**
 * 鼠标移到星星上：计算预览值（允许半星时按左右半边区分）。
 * @param e 鼠标事件
 * @param i 星星下标（从 1 开始）
 * @returns 无
 */
function onMove(e: MouseEvent, i: number): void {
  if (props.disabled) return;
  if (!props.allowHalf) {
    hover.value = i;
    return;
  }
  const el = e.currentTarget as HTMLElement;
  const rect = el.getBoundingClientRect();
  hover.value = e.clientX - rect.left < rect.width / 2 ? i - 0.5 : i;
}

/**
 * 点击选中：写入 hover 预览值。
 * @returns 无
 */
function onClick(): void {
  if (props.disabled || hover.value < 0) return;
  emit('update:modelValue', hover.value);
  emit('change', hover.value);
}

/** 文案 */
const text = computed(() => `${props.modelValue} 分`);

/**
 * 单颗星的填充比例（0~1），用于半星裁切。
 * @param i 星星下标
 * @returns 0 / 0.5 / 1
 */
function fill(i: number): number {
  const v = display.value;
  if (v >= i) return 1;
  if (v >= i - 0.5) return 0.5;
  return 0;
}
</script>

<template>
  <div class="ds-rate" :class="{ 'is-disabled': disabled }" @mouseleave="hover = -1">
    <span
      v-for="i in count"
      :key="i"
      class="ds-rate-star"
      :style="{ width: size + 'px', height: size + 'px' }"
      @mousemove="onMove($event, i)"
      @click="onClick"
    >
      <!-- 底层：空心星 -->
      <svg class="ds-rate-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="m12 2 3 6.6 7 .8-5.2 4.8 1.4 7L12 17.6 5.8 21.2l1.4-7L2 9.4l7-.8Z" /></svg>
      <!-- 上层：按填充比例裁切的实心星 -->
      <svg
        class="ds-rate-icon is-fill"
        :style="{ clipPath: `inset(0 ${(1 - fill(i)) * 100}% 0 0)` }"
        viewBox="0 0 24 24"
        aria-hidden="true"
      >
        <path d="m12 2 3 6.6 7 .8-5.2 4.8 1.4 7L12 17.6 5.8 21.2l1.4-7L2 9.4l7-.8Z" />
      </svg>
    </span>
    <span v-if="showText" class="ds-rate-text">{{ text }}</span>
  </div>
</template>

<style scoped>
.ds-rate {
  display: inline-flex;
  align-items: center;
  gap: 6px;
}
.ds-rate.is-disabled { opacity: 0.6; }

.ds-rate-star {
  position: relative;
  display: inline-block;
  cursor: pointer;
}
.ds-rate.is-disabled .ds-rate-star { cursor: not-allowed; }

.ds-rate-icon {
  position: absolute;
  inset: 0;
  width: 100%;
  height: 100%;
  fill: none;
  stroke: var(--ds-border-strong);
  stroke-width: 1.5;
  transition: stroke var(--ds-dur-fast) var(--ds-ease);
}
.ds-rate-icon.is-fill {
  fill: var(--ds-warning);
  stroke: var(--ds-warning);
}
.ds-rate-star:hover .ds-rate-icon { stroke: var(--ds-warning); }
</style>
