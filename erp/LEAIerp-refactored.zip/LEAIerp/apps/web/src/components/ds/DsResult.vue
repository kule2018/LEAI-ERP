<!-- src/components/ds/DsResult.vue -->
<script setup lang="ts">
/**
 * DsResult —— 结果页（成功 / 失败 / 信息 / 404）。
 *
 * 用于「提交完成」「审核未通过」「无权限」等整块结果呈现：
 * 大图标 + 主标题 + 副标题 + 操作区插槽。
 */
import { computed } from 'vue';

/** 组件入参 */
const props = withDefaults(
  defineProps<{
    /** 状态：success 成功 / danger 失败 / info 一般 / 404 */
    status?: 'success' | 'danger' | 'info' | '404';
    /** 主标题 */
    title?: string;
    /** 副标题 */
    subtitle?: string;
    /** 尺寸：sm / md / lg */
    size?: 'sm' | 'md' | 'lg';
  }>(),
  { status: 'info', title: '', subtitle: '', size: 'md' },
);

/** 各状态的图标与配色 */
const MAP = computed(() => {
  switch (props.status) {
    case 'success':
      return { color: 'var(--ds-success)', icon: 'M20 6 9 17l-5-5', title: props.title || '操作成功' };
    case 'danger':
      return { color: 'var(--ds-danger)', icon: 'M18 6 6 18M6 6l12 12', title: props.title || '操作失败' };
    case '404':
      return { color: 'var(--ds-text-3)', icon: 'M12 8v4m0 4h.01M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18Z', title: props.title || '页面不存在' };
    default:
      return { color: 'var(--ds-brand)', icon: 'M12 16v-4m0-4h.01M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20Z', title: props.title || '信息' };
  }
});
</script>

<template>
  <div class="ds-result" :class="`is-${size}`">
    <!-- 图标：圆环 + 内部符号 -->
    <span class="ds-result-icon" :style="{ color: MAP.color, borderColor: MAP.color }">
      <svg viewBox="0 0 24 24" aria-hidden="true"><path :d="MAP.icon" /></svg>
    </span>
    <!-- 文案 -->
    <p class="ds-result-title">{{ MAP.title }}</p>
    <p v-if="subtitle" class="ds-result-sub">{{ subtitle }}</p>
    <!-- 操作区 -->
    <div v-if="$slots.default || $slots.extra" class="ds-result-extra">
      <slot name="extra" />
      <slot />
    </div>
  </div>
</template>

<style scoped>
.ds-result {
  display: flex;
  flex-direction: column;
  align-items: center;
  text-align: center;
  padding: 32px 16px;
}
.ds-result.is-sm { padding: 20px 12px; }
.ds-result.is-lg { padding: 56px 16px; }

.ds-result-icon {
  width: 56px; height: 56px;
  display: grid; place-items: center;
  border-radius: 50%;
  border: 2px solid;
  margin-bottom: 16px;
}
.ds-result.is-sm .ds-result-icon { width: 40px; height: 40px; margin-bottom: 10px; }
.ds-result.is-lg .ds-result-icon { width: 72px; height: 72px; margin-bottom: 20px; }
.ds-result-icon svg {
  width: 55%; height: 55%;
  fill: none; stroke: currentColor; stroke-width: 2.4; stroke-linecap: round; stroke-linejoin: round;
}

.ds-result-title { margin: 0; font-size: var(--ds-font-lg); font-weight: 600; color: var(--ds-text); }
.ds-result-sub { margin: 6px 0 0; font-size: var(--ds-font-sm); color: var(--ds-text-3); max-width: 420px; }
.ds-result-extra { margin-top: 20px; display: flex; align-items: center; gap: 10px; }
</style>
