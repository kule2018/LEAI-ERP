<!-- src/components/ds/DsSegmented.vue -->
<script setup lang="ts">
/**
 * DsSegmented —— 分段控制器。
 *
 * 比 DsTabs 更轻的「切换」形态：一个灰底圆角条 + 若干等分选项，
 * 选中项白底浮起 + 轻阴影（与 DeepSeek 顶部的视图切换一致）。
 */
import { computed } from 'vue';

/** 组件入参 */
const props = withDefaults(
  defineProps<{
    /** 当前选中值（v-model） */
    modelValue: string | number;
    /** 选项：{ label, value, disabled? } */
    options: { label: string; value: string | number; disabled?: boolean }[];
    /** 是否禁用整个控件 */
    disabled?: boolean;
    /** 是否块级（撑满父容器） */
    block?: boolean;
    /** 尺寸：sm / md */
    size?: 'sm' | 'md';
  }>(),
  { disabled: false, block: false, size: 'md' },
);

/** 事件 */
const emit = defineEmits<{ (e: 'update:modelValue', v: string | number): void; (e: 'change', v: string | number): void }>();

/** 选中项下标（用于滑块定位） */
const activeIndex = computed(() => Math.max(0, props.options.findIndex((o) => o.value === props.modelValue)));

/**
 * 点击某个选项。
 * @param opt 选项
 * @returns 无
 */
function pick(opt: { value: string | number; disabled?: boolean }): void {
  if (opt.disabled || props.disabled || opt.value === props.modelValue) return;
  emit('update:modelValue', opt.value);
  emit('change', opt.value);
}
</script>

<template>
  <div class="ds-segmented" :class="[`is-${size}`, { 'is-block': block, 'is-disabled': disabled }]">
    <!-- 选中滑块：绝对定位，切换时位移过渡 -->
    <span
      class="ds-segmented__thumb"
      :style="{
        width: `${100 / Math.max(1, options.length)}%`,
        transform: `translateX(${activeIndex * 100}%)`,
      }"
    />
    <!-- 选项 -->
    <button
      v-for="opt in options"
      :key="String(opt.value)"
      type="button"
      class="ds-segmented__item"
      :class="{ 'is-active': opt.value === modelValue, 'is-disabled': opt.disabled }"
      :disabled="opt.disabled || disabled"
      @click="pick(opt)"
    >
      {{ opt.label }}
    </button>
  </div>
</template>

<style scoped>
.ds-segmented {
  position: relative;
  display: inline-flex;
  align-items: center;
  padding: 3px;
  background: var(--ds-bg-soft);
  border-radius: var(--ds-radius);
}
.ds-segmented.is-block { display: flex; width: 100%; }
.ds-segmented.is-disabled { opacity: 0.55; pointer-events: none; }

/* 选中滑块 */
.ds-segmented__thumb {
  position: absolute;
  top: 3px;
  bottom: 3px;
  left: 0;
  background: var(--ds-bg-elevated);
  border-radius: calc(var(--ds-radius) - 3px);
  box-shadow: var(--ds-shadow-sm);
  transition: transform var(--ds-dur) var(--ds-ease), width var(--ds-dur) var(--ds-ease);
  pointer-events: none;
}

.ds-segmented__item {
  position: relative;
  z-index: 1;
  flex: 1;
  min-width: 0;
  border: 0;
  background: transparent;
  font-family: inherit;
  color: var(--ds-text-2);
  cursor: pointer;
  white-space: nowrap;
  border-radius: calc(var(--ds-radius) - 3px);
  transition: color var(--ds-dur-fast) var(--ds-ease);
}
.ds-segmented.is-md .ds-segmented__item { height: 28px; padding: 0 14px; font-size: var(--ds-font-sm); }
.ds-segmented.is-sm .ds-segmented__item { height: 24px; padding: 0 10px; font-size: var(--ds-font-xs); }
.ds-segmented__item:hover:not(:disabled):not(.is-active) { color: var(--ds-text); }
.ds-segmented__item.is-active { color: var(--ds-brand); font-weight: 600; }
.ds-segmented__item.is-disabled { opacity: 0.45; cursor: not-allowed; }
</style>
