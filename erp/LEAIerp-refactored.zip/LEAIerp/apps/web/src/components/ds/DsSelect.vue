<!-- src/components/ds/DsSelect.vue -->
<script setup lang="ts">
/**
 * DsSelect —— 下拉选择器（零依赖自绘）。
 *
 * 设计要点（对齐 DeepSeek 设置页的 select 观感）：
 *   1) 触发器 = 圆角描边框 + 选中文案 + 右侧箭头；多选时选中项以标签形式展示，可单个移除；
 *   2) 浮层为「搜索框（可选）+ 选项列表」，支持键盘 ↑/↓/Enter/Esc；
 *   3) filterable 时在浮层内过滤（而不是触发器的 remote 搜索，远程搜索用 BaseSelect）；
 *   4) 空选项 / 加载中 / 禁用 三种状态都有对应呈现；
 *   5) 浮层开合、外部点击收起由 usePopover 统一处理。
 */
import { computed, ref, watch, nextTick } from 'vue';
import { usePopover } from './usePopover';
import DsSpinner from './DsSpinner.vue';
import type { DsOption } from './types';


/** 组件入参 */
const props = withDefaults(
  defineProps<{
    /** 选中值（v-model）；多选时为数组 */
    modelValue: any;
    /** 选项列表 */
    options: DsOption[];
    /** 占位文案 */
    placeholder?: string;
    /** 是否多选 */
    multiple?: boolean;
    /** 是否可清空 */
    clearable?: boolean;
    /** 浮层内是否显示搜索框 */
    filterable?: boolean;
    /** 远程搜索：本地不过滤，搜索词经 search 事件抛给父级更新 options */
    remote?: boolean;
    /** 是否加载中（显示转圈） */
    loading?: boolean;
    /** 是否禁用 */
    disabled?: boolean;
    /** 尺寸：sm / md / lg */
    size?: 'sm' | 'md' | 'lg';
    /** 浮层最大高度（px） */
    listHeight?: number;
  }>(),
  {
    options: () => [],
    placeholder: '请选择',
    multiple: false,
    clearable: true,
    filterable: false,
    remote: false,
    loading: false,
    disabled: false,
    size: 'md',
    listHeight: 260,
  },
);

/** 事件 */
const emit = defineEmits<{
  (e: 'update:modelValue', v: any): void;
  (e: 'change', v: any): void;
  (e: 'search', kw: string): void;
}>();

// 浮层控制：open 展开态 / rootRef 外层引用 / toggle / close
const { open, rootRef, toggle, close } = usePopover();

/** 浮层内过滤关键字 */
const keyword = ref('');
/** 键盘高亮项下标 */
const activeIndex = ref(0);

/** 过滤后的选项（远程模式下不做本地过滤，交由父级更新 options） */
const shownOptions = computed(() => {
  if (props.remote) return props.options;
  const kw = keyword.value.trim().toLowerCase();
  if (!kw) return props.options;
  return props.options.filter((o) => String(o.label).toLowerCase().includes(kw));
});

/** 选中项的展示文案（单选） */
const selectedLabel = computed(() => {
  if (props.multiple) return '';
  const hit = props.options.find((o) => o.value === props.modelValue);
  return hit ? hit.label : '';
});

/** 已选选项对象列表（多选，用于标签展示与移除） */
const selectedOptions = computed(() => {
  if (!props.multiple || !Array.isArray(props.modelValue)) return [];
  return props.modelValue
    .map((v) => props.options.find((o) => o.value === v))
    .filter((o): o is DsOption => !!o);
});

/** 是否显示清空按钮 */
const showClear = computed(
  () => props.clearable && !props.disabled && hasValue.value,
);

/** 当前是否有值（空串 / 空数组都视为无值） */
const hasValue = computed(() => {
  if (props.multiple) return Array.isArray(props.modelValue) && props.modelValue.length > 0;
  return props.modelValue !== '' && props.modelValue !== undefined && props.modelValue !== null;
});

/**
 * 判断某个选项是否已选中。
 * @param opt 选项
 * @returns 是否选中
 */
function isActive(opt: DsOption): boolean {
  if (props.multiple) return Array.isArray(props.modelValue) && props.modelValue.includes(opt.value);
  return props.modelValue === opt.value;
}

/**
 * 点击某个选项：单选直接写入并收起；多选切换勾选态。
 * @param opt 被点击选项
 * @returns 无
 */
function pick(opt: DsOption): void {
  if (opt.disabled) return;
  if (props.multiple) {
    const arr = Array.isArray(props.modelValue) ? [...props.modelValue] : [];
    const i = arr.indexOf(opt.value);
    if (i >= 0) arr.splice(i, 1);
    else arr.push(opt.value);
    emit('update:modelValue', arr);
    emit('change', arr);
  } else {
    emit('update:modelValue', opt.value);
    emit('change', opt.value);
    close();
  }
}

/**
 * 多选模式下移除某个已选标签。
 * @param opt 要移除的选项
 * @returns 无
 */
function removeTag(opt: DsOption): void {
  if (!props.multiple || !Array.isArray(props.modelValue)) return;
  const arr = props.modelValue.filter((v) => v !== opt.value);
  emit('update:modelValue', arr);
  emit('change', arr);
}

/**
 * 清空全部选择。
 * @returns 无
 */
function clearAll(): void {
  emit('update:modelValue', props.multiple ? [] : '');
  emit('change', props.multiple ? [] : '');
}

/**
 * 浮层内键盘导航：↑/↓ 移动高亮，Enter 选中，Esc 收起。
 * @param e 键盘事件
 * @returns 无
 */
function onKeydown(e: KeyboardEvent): void {
  const list = shownOptions.value.filter((o) => !o.disabled);
  if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
    e.preventDefault();
    if (!list.length) return;
    const dir = e.key === 'ArrowDown' ? 1 : -1;
    activeIndex.value = (activeIndex.value + dir + list.length) % list.length;
  } else if (e.key === 'Enter') {
    const opt = list[activeIndex.value];
    if (opt) {
      e.preventDefault();
      pick(opt);
    }
  } else if (e.key === 'Escape') {
    close();
  }
}

// 每次展开：重置过滤词与高亮项，过滤模式自动聚焦搜索框
watch(open, async (v) => {
  if (!v) return;
  keyword.value = '';
  activeIndex.value = 0;
  if (props.filterable) {
    await nextTick();
    rootRef.value?.querySelector<HTMLInputElement>('.ds-select-search input')?.focus();
  }
});

// 远程搜索：搜索词变化时抛给父级（父级拉取选项后更新 options）
watch(keyword, (kw) => {
  if (props.remote) emit('search', kw);
});

// 暴露给父组件：以编程方式收起浮层（如表单提交后）
defineExpose({ close, open });
</script>

<template>
  <div ref="rootRef" class="ds-select" :class="[`is-${size}`, { 'is-disabled': disabled, 'is-open': open }]">
    <!-- 触发器 -->
    <div class="ds-select-trigger" :tabindex="disabled ? -1 : 0" @click="!disabled && toggle()">
      <!-- 多选：已选标签 -->
      <span v-if="multiple" class="ds-select-tags">
        <span v-for="opt in selectedOptions" :key="String(opt.value)" class="ds-select-tag">
          {{ opt.label }}
          <button type="button" title="移除" @click.stop="removeTag(opt)">✕</button>
        </span>
        <span v-if="!selectedOptions.length" class="ds-select-ph">{{ placeholder }}</span>
      </span>
      <!-- 单选：文案或占位符 -->
      <span v-else class="ds-select-value" :class="{ 'is-ph': !hasValue }">
        {{ hasValue ? selectedLabel : placeholder }}
      </span>

      <!-- 右侧功能区：加载 / 清空 / 箭头 -->
      <span class="ds-select-icons">
        <DsSpinner v-if="loading" :size="12" />
        <button v-else-if="showClear" type="button" class="ds-select-clear" title="清空" @click.stop="clearAll">✕</button>
        <svg class="ds-select-arrow" :class="{ 'is-flip': open }" viewBox="0 0 24 24" aria-hidden="true">
          <path d="m6 9 6 6 6-6" />
        </svg>
      </span>
    </div>

    <!-- 浮层 -->
    <div v-if="open" class="ds-select-pop">
      <!-- 搜索框（filterable 时） -->
      <div v-if="filterable" class="ds-select-search">
        <input v-model="keyword" type="text" placeholder="搜索…" @keydown="onKeydown" />
      </div>
      <!-- 选项列表 -->
      <ul v-if="shownOptions.length" class="ds-select-list" :style="{ maxHeight: listHeight + 'px' }">
        <li
          v-for="(opt, i) in shownOptions"
          :key="String(opt.value)"
          class="ds-select-opt"
          :class="{ 'is-active': isActive(opt), 'is-hl': i === activeIndex, 'is-disabled': opt.disabled }"
          @click="pick(opt)"
          @mouseenter="activeIndex = i"
        >
          <span class="ds-select-opt-label">{{ opt.label }}</span>
          <svg v-if="isActive(opt)" class="ds-select-check" viewBox="0 0 24 24" aria-hidden="true">
            <path d="M20 6 9 17l-5-5" />
          </svg>
        </li>
      </ul>
      <!-- 空态 -->
      <div v-else class="ds-select-empty">暂无选项</div>
    </div>
  </div>
</template>

<style scoped>
.ds-select {
  position: relative;
  width: 100%;
  font-size: var(--ds-font-md);
}

/* ---- 触发器 ---- */
.ds-select-trigger {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
  min-height: var(--ds-ctl-h-md);
  padding: 0 10px 0 12px;
  background: var(--ds-bg-elevated);
  border: 1px solid var(--ds-border);
  border-radius: var(--ds-radius-sm);
  cursor: pointer;
  transition: border-color var(--ds-dur-fast) var(--ds-ease), box-shadow var(--ds-dur-fast) var(--ds-ease);
}
.ds-select.is-sm .ds-select-trigger { min-height: var(--ds-ctl-h-sm); font-size: var(--ds-font-sm); }
.ds-select.is-lg .ds-select-trigger { min-height: var(--ds-ctl-h-lg); font-size: var(--ds-font-lg); }

.ds-select:not(.is-disabled) .ds-select-trigger:hover { border-color: var(--ds-border-strong); }
.ds-select.is-open:not(.is-disabled) .ds-select-trigger {
  border-color: var(--ds-brand);
  box-shadow: 0 0 0 3px var(--ds-brand-soft);
}
.ds-select.is-disabled .ds-select-trigger { background: var(--ds-bg-hover); cursor: not-allowed; }

.ds-select-value,
.ds-select-ph {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  color: var(--ds-text);
  text-align: left;
}
.ds-select-value.is-ph { color: var(--ds-text-3); }

/* 多选标签 */
.ds-select-tags {
  flex: 1;
  display: flex;
  flex-wrap: wrap;
  gap: 4px;
  padding: 4px 0;
  min-width: 0;
}
.ds-select-tag {
  display: inline-flex;
  align-items: center;
  gap: 2px;
  padding: 1px 4px 1px 8px;
  background: var(--ds-brand-soft);
  color: var(--ds-brand);
  border-radius: var(--ds-radius-xs);
  font-size: var(--ds-font-xs);
  line-height: 1.6;
}
.ds-select-tag button {
  border: 0;
  background: transparent;
  color: inherit;
  cursor: pointer;
  font-size: 10px;
  padding: 0 2px;
  border-radius: 50%;
  line-height: 1;
}
.ds-select-tag button:hover { background: rgba(0, 0, 0, 0.12); }

/* 右侧图标区 */
.ds-select-icons {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  flex: none;
  color: var(--ds-text-3);
}
.ds-select-clear {
  border: 0;
  background: transparent;
  color: var(--ds-text-3);
  cursor: pointer;
  font-size: var(--ds-font-xs);
  line-height: 1;
  padding: 2px;
  border-radius: var(--ds-radius-xs);
}
.ds-select-clear:hover { background: var(--ds-bg-hover); color: var(--ds-text); }
.ds-select-arrow {
  width: 16px;
  height: 16px;
  fill: none;
  stroke: currentColor;
  stroke-width: 2;
  stroke-linecap: round;
  stroke-linejoin: round;
  transition: transform var(--ds-dur-fast) var(--ds-ease);
}
.ds-select-arrow.is-flip { transform: rotate(180deg); }

/* ---- 浮层 ---- */
.ds-select-pop {
  position: absolute;
  top: calc(100% + 6px);
  left: 0;
  right: 0;
  z-index: 100;
  background: var(--ds-bg-elevated);
  border: 1px solid var(--ds-border);
  border-radius: var(--ds-radius);
  box-shadow: var(--ds-shadow-md);
  overflow: hidden;
  animation: ds-select-in var(--ds-dur-fast) var(--ds-ease);
}
@keyframes ds-select-in {
  from { opacity: 0; transform: translateY(-4px); }
  to { opacity: 1; transform: none; }
}

.ds-select-search {
  padding: 8px;
  border-bottom: 1px solid var(--ds-divider);
}
.ds-select-search input {
  width: 100%;
  height: 30px;
  padding: 0 10px;
  border: 1px solid var(--ds-border);
  border-radius: var(--ds-radius-xs);
  background: var(--ds-bg);
  color: var(--ds-text);
  font-size: var(--ds-font-sm);
  outline: none;
}
.ds-select-search input:focus { border-color: var(--ds-brand); }

.ds-select-list {
  margin: 0;
  padding: 4px;
  list-style: none;
  overflow-y: auto;
}
.ds-select-opt {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
  padding: 7px 10px;
  border-radius: var(--ds-radius-xs);
  color: var(--ds-text-2);
  font-size: var(--ds-font-sm);
  cursor: pointer;
  transition: background var(--ds-dur-fast) var(--ds-ease);
}
.ds-select-opt-label { flex: 1; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.ds-select-opt.is-hl { background: var(--ds-bg-hover); }
.ds-select-opt.is-active { color: var(--ds-brand); font-weight: 500; background: var(--ds-brand-soft); }
.ds-select-opt.is-disabled { opacity: 0.45; cursor: not-allowed; }
.ds-select-check {
  width: 14px;
  height: 14px;
  flex: none;
  fill: none;
  stroke: currentColor;
  stroke-width: 2.5;
  stroke-linecap: round;
  stroke-linejoin: round;
}
.ds-select-empty {
  padding: 20px 0;
  text-align: center;
  color: var(--ds-text-3);
  font-size: var(--ds-font-sm);
}
</style>
