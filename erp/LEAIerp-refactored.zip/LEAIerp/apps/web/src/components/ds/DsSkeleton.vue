<!-- src/components/ds/DsSkeleton.vue -->
<script setup lang="ts">
/**
 * DsSkeleton —— 骨架屏。
 *
 * 列表 / 卡片加载占位：标题行 + N 个内容行，可选头像圆形占位；
 * animated 开启呼吸动画。行宽按「递减」排布，观感更接近真实文本。
 */
import { computed } from 'vue';

/** 组件入参 */
const props = withDefaults(
  defineProps<{
    /** 内容行数 */
    rows?: number;
    /** 是否显示标题行 */
    title?: boolean;
    /** 是否显示头像占位 */
    avatar?: boolean;
    /** 是否开启动画 */
    animated?: boolean;
    /** 是否显示底部按钮占位 */
    action?: boolean;
  }>(),
  { rows: 3, title: true, avatar: false, animated: true, action: false },
);

/** 每行的宽度百分比：从 100% 递减到最后一行 60% */
const widths = computed(() =>
  Array.from({ length: props.rows }, (_, i) => {
    const w = 100 - (i / Math.max(1, props.rows)) * 40;
    return Math.round(w) + '%';
  }),
);
</script>

<template>
  <div class="ds-skeleton" :class="{ 'is-animated': animated }">
    <!-- 标题行 -->
    <div v-if="title" class="ds-skel-row is-title">
      <span v-if="avatar" class="ds-skel-avatar" />
      <span class="ds-skel-line" style="width: 40%" />
    </div>
    <!-- 内容行 -->
    <div v-for="(w, i) in widths" :key="i" class="ds-skel-row">
      <span v-if="avatar && i === 0 && !title" class="ds-skel-avatar" />
      <span class="ds-skel-line" :style="{ width: w }" />
    </div>
    <!-- 按钮占位 -->
    <div v-if="action" class="ds-skel-row">
      <span class="ds-skel-line is-btn" />
    </div>
  </div>
</template>

<style scoped>
.ds-skeleton { display: flex; flex-direction: column; gap: 12px; width: 100%; }
.ds-skel-row { display: flex; align-items: center; gap: 12px; }

.ds-skel-line {
  height: 14px;
  border-radius: var(--ds-radius-xs);
  background: var(--ds-bg-skeleton);
}
.ds-skel-row.is-title .ds-skel-line { height: 18px; }
.ds-skel-line.is-btn { width: 88px; height: 32px; border-radius: var(--ds-radius-sm); }
.ds-skel-avatar {
  width: 36px; height: 36px; flex: none;
  border-radius: 50%;
  background: var(--ds-bg-skeleton);
}

/* 呼吸动画：透明度 1 -> 0.45 -> 1 */
.ds-skeleton.is-animated .ds-skel-line,
.ds-skeleton.is-animated .ds-skel-avatar {
  animation: ds-skel-breathe 1.6s ease-in-out infinite;
}
@keyframes ds-skel-breathe {
  0%, 100% { opacity: 1; }
  50% { opacity: 0.45; }
}
</style>
