<!-- src/components/ds/DsSlider.vue -->
<script setup lang="ts">
/**
 * DsSlider —— 滑块。
 *
 * 支持单值（number）与区间（[number, number]）两种模式；
 * 区间模式下两个手柄互相不越界；均支持步进、禁用、快捷键（←/→ 微调）。
 */
import { computed, ref } from 'vue';

/** 组件入参 */
const props = withDefaults(
  defineProps<{
    /** 当前值：单值数字或区间数组 */
    modelValue: number | [number, number];
    /** 最小值 */
    min?: number;
    /** 最大值 */
    max?: number;
    /** 步进（0 表示连续） */
    step?: number;
    /** 是否区间模式 */
    range?: boolean;
    /** 是否禁用 */
    disabled?: boolean;
    /** 是否在右侧显示当前值 */
    showValue?: boolean;
  }>(),
  { min: 0, max: 100, step: 1, range: false, disabled: false, showValue: false },
);

/** 事件 */
const emit = defineEmits<{ (e: 'update:modelValue', v: number | [number, number]): void; (e: 'change', v: number | [number, number]): void }>();

/** 轨道元素引用（用于把点击坐标换算成数值） */
const trackRef = ref<HTMLElement | null>(null);
/** 正在拖动的手柄下标（单值模式固定为 0） */
const dragging = ref(-1);

/** 归一化的单值/双值（内部统一按双值处理） */
const values = computed<[number, number]>(() => {
  if (props.range) {
    const arr = props.modelValue as [number, number];
    return [arr?.[0] ?? props.min, arr?.[1] ?? props.max];
  }
  return [Number(props.modelValue) || props.min, props.min];
});

/**
 * 把像素坐标换算成数值：先算百分比，再按 step 对齐，最后夹在 [min,max]。
 * @param clientX 鼠标 / 触摸的页面 X 坐标
 * @returns 对齐后的数值
 */
function posToValue(clientX: number): number {
  const el = trackRef.value;
  if (!el) return props.min;
  const rect = el.getBoundingClientRect();
  const ratio = Math.min(1, Math.max(0, (clientX - rect.left) / rect.width));
  const raw = props.min + ratio * (props.max - props.min);
  if (!props.step) return Math.round(raw * 100) / 100;
  return Math.round((raw - props.min) / props.step) * props.step + props.min;
}

/**
 * 提交新值：区分单值 / 区间模式。
 * @param next 新的单值或双值
 * @returns 无
 */
function commit(next: number | [number, number]): void {
  emit('update:modelValue', next);
  emit('change', next);
}

/**
 * 轨道点击 / 拖动中：单值模式直接跟手；区间模式移动较近的手柄。
 * @param e 鼠标事件
 * @returns 无
 */
function onTrackClick(e: MouseEvent): void {
  if (props.disabled) return;
  const v = posToValue(e.clientX);
  if (props.range) {
    const [a, b] = values.value;
    // 谁离得近就动谁
    if (Math.abs(v - a) <= Math.abs(v - b)) commit([Math.min(v, b), b]);
    else commit([a, Math.max(v, a)]);
  } else {
    commit(v);
  }
}

/**
 * 手柄按下：记录拖动下标，并挂上临时监听（move + up）。
 * @param e 鼠标事件
 * @param index 手柄下标
 * @returns 无
 */
function onHandleDown(e: MouseEvent, index: number): void {
  if (props.disabled) return;
  e.preventDefault();
  dragging.value = index;
  const move = (ev: MouseEvent) => onDrag(ev, index);
  const up = () => {
    dragging.value = -1;
    document.removeEventListener('mousemove', move);
    document.removeEventListener('mouseup', up);
  };
  document.addEventListener('mousemove', move);
  document.addEventListener('mouseup', up);
}

/**
 * 拖动中：按手柄下标更新对应值（区间模式保持 a <= b）。
 * @param e 鼠标事件
 * @param index 手柄下标
 * @returns 无
 */
function onDrag(e: MouseEvent, index: number): void {
  if (props.disabled) return;
  const v = posToValue(e.clientX);
  if (props.range) {
    const [a, b] = values.value;
    if (index === 0) commit([Math.min(v, b), b]);
    else commit([a, Math.max(v, a)]);
  } else {
    commit(v);
  }
}

/**
 * 手柄键盘微调：←/↓ 减一步，→/↑ 加一步。
 * @param e 键盘事件
 * @param index 手柄下标
 * @returns 无
 */
function onKeydown(e: KeyboardEvent, index: number): void {
  if (props.disabled || !props.step) return;
  const dir = e.key === 'ArrowRight' || e.key === 'ArrowUp' ? 1 : e.key === 'ArrowLeft' || e.key === 'ArrowDown' ? -1 : 0;
  if (!dir) return;
  e.preventDefault();
  const v = values.value[index] + dir * props.step;
  if (props.range) {
    const [a, b] = values.value;
    if (index === 0) commit([Math.min(v, b), b]);
    else commit([a, Math.max(v, a)]);
  } else {
    commit(v);
  }
}

/** 滑块位置百分比（用于 CSS left） */
const pct = (v: number) => ((v - props.min) / (props.max - props.min)) * 100;

/** 数值展示文案 */
const valueText = computed(() => (props.range ? `${values.value[0]} – ${values.value[1]}` : String(values.value[0])));
</script>

<template>
  <div class="ds-slider" :class="{ 'is-disabled': disabled }">
    <!-- 轨道 -->
    <div ref="trackRef" class="ds-slider-track" @click="onTrackClick">
      <!-- 已选区间（区间模式下为两手柄之间） -->
      <div
        class="ds-slider-fill"
        :style="range
          ? { left: pct(values[0]) + '%', width: pct(values[1]) - pct(values[0]) + '%' }
          : { left: 0, width: pct(values[0]) + '%' }"
      />
      <!-- 手柄 -->
      <template v-if="range">
        <span
          v-for="(v, i) in values"
          :key="i"
          class="ds-slider-handle"
          :class="{ 'is-drag': dragging === i }"
          :style="{ left: pct(v) + '%' }"
          tabindex="0"
          role="slider"
          @mousedown="onHandleDown($event, i)"
          @keydown="onKeydown($event, i)"
        />
      </template>
      <span
        v-else
        class="ds-slider-handle"
        :class="{ 'is-drag': dragging === 0 }"
        :style="{ left: pct(values[0]) + '%' }"
        tabindex="0"
        role="slider"
        @mousedown="onHandleDown($event, 0)"
        @keydown="onKeydown($event, 0)"
      />
    </div>
    <!-- 数值展示 -->
    <span v-if="showValue" class="ds-slider-value">{{ valueText }}</span>
  </div>
</template>

<style scoped>
.ds-slider {
  display: flex;
  align-items: center;
  gap: 12px;
  width: 100%;
  padding: 6px 0;
}
.ds-slider.is-disabled { opacity: 0.55; }

.ds-slider-track {
  position: relative;
  flex: 1;
  height: 4px;
  border-radius: var(--ds-radius-full);
  background: var(--ds-bg-hover);
  cursor: pointer;
}
.ds-slider.is-disabled .ds-slider-track { cursor: not-allowed; }

/* 已选部分 */
.ds-slider-fill {
  position: absolute;
  top: 0;
  bottom: 0;
  border-radius: var(--ds-radius-full);
  background: var(--ds-brand);
}

/* 手柄 */
.ds-slider-handle {
  position: absolute;
  top: 50%;
  width: 16px;
  height: 16px;
  margin-left: -8px;
  border-radius: 50%;
  background: #fff;
  border: 2px solid var(--ds-brand);
  box-shadow: var(--ds-shadow-sm);
  transform: translateY(-50%);
  cursor: grab;
  transition: transform var(--ds-dur-fast) var(--ds-ease), box-shadow var(--ds-dur-fast) var(--ds-ease);
}
.ds-slider-handle:hover,
.ds-slider-handle.is-drag {
  transform: translateY(-50%) scale(1.15);
  box-shadow: 0 0 0 4px var(--ds-brand-soft);
}
.ds-slider-handle:focus-visible { outline: none; box-shadow: 0 0 0 4px var(--ds-brand-soft); }

.ds-slider-value {
  flex: none;
  min-width: 56px;
  text-align: right;
  font-size: var(--ds-font-sm);
  color: var(--ds-text-2);
  font-variant-numeric: tabular-nums;
}
</style>
