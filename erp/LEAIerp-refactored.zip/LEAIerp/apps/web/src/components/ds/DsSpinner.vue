<!-- src/components/ds/DsSpinner.vue -->
<script setup lang="ts">
/**
 * 加载指示器
 * ------------------------------------------------------------------
 * 两种用法：
 *   1) 单独放在容器中间表示「这块在加载」；
 *   2) 配合 text 属性显示「加载中…」之类的文案。
 */
withDefaults(
  defineProps<{
    /** 直径（px） */
    size?: number;
    /** 附加文案 */
    text?: string;
    /** 是否整块覆盖父容器（需要父级 position: relative） */
    overlay?: boolean;
  }>(),
  { size: 22, text: '', overlay: false },
);
</script>

<template>
  <div class="ds-spinner" :class="{ 'is-overlay': overlay }">
    <span class="ds-spinner-ring" :style="{ width: size + 'px', height: size + 'px' }" />
    <span v-if="text" class="ds-spinner-text">{{ text }}</span>
  </div>
</template>

<style scoped>
.ds-spinner {
  display: inline-flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 8px;
}

/* 覆盖模式：半透明遮住父容器，防止加载中用户重复操作 */
.ds-spinner.is-overlay {
  position: absolute;
  inset: 0;
  background: var(--ds-frosted);
  border-radius: inherit;
  z-index: 5;
}

.ds-spinner-ring {
  border: 2.5px solid var(--ds-border);
  border-top-color: var(--ds-brand);
  border-radius: 50%;
  animation: ds-spin 0.75s linear infinite;
}

.ds-spinner-text {
  font-size: var(--ds-font-sm);
  color: var(--ds-text-3);
}
</style>
