<!-- src/components/ds/DsStatCard.vue -->
<script setup lang="ts">
/**
 * 指标卡
 * ------------------------------------------------------------------
 * 看板/概览页的统计块：数值 + 标题 + 可选趋势 + 可选图标。
 * 数值用等宽数字（tabular-nums），刷新时不会左右抖动。
 */
import { computed } from 'vue';

/** 组件入参 */
const props = withDefaults(
  defineProps<{
    /** 标题 */
    label: string;
    /** 数值（字符串可带单位，如 "1,234" / "75.3%"） */
    value: string | number;
    /** 单位后缀（如 个 / 次 / 元） */
    unit?: string;
    /** 趋势：相对上期变化，正数为涨、负数为跌 */
    trend?: number | null;
    /** 提示说明（鼠标悬停 title） */
    hint?: string;
    /** 强调色：brand/success/warning/danger/neutral */
    tone?: 'brand' | 'success' | 'warning' | 'danger' | 'neutral';
  }>(),
  { unit: '', trend: null, hint: '', tone: 'neutral' },
);

/** 趋势文案（带正负号与百分号） */
const trendText = computed(() => {
  if (props.trend === null || props.trend === undefined) return '';
  const v = Number(props.trend);
  if (Number.isNaN(v)) return '';
  return `${v > 0 ? '+' : ''}${(v * 100).toFixed(1)}%`;
});
</script>

<template>
  <div class="ds-stat" :class="`is-${tone}`" :title="hint">
    <span class="ds-stat-label">{{ label }}</span>
    <div class="ds-stat-value-row">
      <span class="ds-stat-value">{{ value }}</span>
      <span v-if="unit" class="ds-stat-unit">{{ unit }}</span>
      <span
        v-if="trendText"
        class="ds-stat-trend"
        :class="{ up: Number(trend) > 0, down: Number(trend) < 0 }"
      >{{ trendText }}</span>
    </div>
    <slot />
  </div>
</template>

<style scoped>
.ds-stat {
  background: var(--ds-bg-elevated);
  border: 1px solid var(--ds-border);
  border-radius: var(--ds-radius-md);
  padding: 14px 16px;
  display: flex;
  flex-direction: column;
  gap: 4px;
  transition: box-shadow var(--ds-dur) var(--ds-ease), border-color var(--ds-dur) var(--ds-ease);
}

.ds-stat:hover { box-shadow: var(--ds-shadow-sm); border-color: var(--ds-border-strong); }

.ds-stat-label { font-size: var(--ds-font-sm); color: var(--ds-text-3); }
.ds-stat-value-row { display: flex; align-items: baseline; gap: 6px; }

.ds-stat-value {
  font-size: 24px;
  font-weight: 600;
  line-height: 1.2;
  color: var(--ds-text);
  font-variant-numeric: tabular-nums;
}

.ds-stat-unit { font-size: var(--ds-font-sm); color: var(--ds-text-3); }

.ds-stat-trend { font-size: var(--ds-font-xs); font-weight: 500; }
/* 涨跌色遵循中国习惯：涨 = 红，跌 = 绿 */
.ds-stat-trend.up { color: var(--ds-up); }
.ds-stat-trend.down { color: var(--ds-down); }

/* 强调色：数值着色 */
.is-brand .ds-stat-value { color: var(--ds-brand); }
.is-success .ds-stat-value { color: var(--ds-success); }
.is-warning .ds-stat-value { color: var(--ds-warning); }
.is-danger .ds-stat-value { color: var(--ds-danger); }
</style>
