<!-- src/components/ds/DsSteps.vue -->
<script setup lang="ts">
/**
 * DsSteps —— 步骤条。
 *
 * 水平 / 垂直两个方向；三种状态：已完成（绿勾）、进行中（品牌色）、
 * 未开始（灰）。current 之前的步骤自动视为完成，适合任务流水线展示。
 */
import { computed } from 'vue';
import type { StepItem } from './types';


/** 组件入参 */
const props = withDefaults(
  defineProps<{
    /** 步骤列表 */
    items: StepItem[];
    /** 当前步骤下标（从 0 开始；之前的为已完成） */
    current?: number;
    /** 方向：horizontal 水平 / vertical 垂直 */
    direction?: 'horizontal' | 'vertical';
    /** 是否可点击已完成步骤（发出 change 事件） */
    clickable?: boolean;
  }>(),
  { current: 0, direction: 'horizontal', clickable: false },
);

/** 事件 */
const emit = defineEmits<{ (e: 'change', index: number): void }>();

/** 单个步骤的状态 */
const statusOf = computed(() => (i: number) => {
  if (i < props.current) return 'done';
  if (i === props.current) return 'now';
  return 'wait';
});

/**
 * 点击步骤（仅允许回看已完成步骤）。
 * @param i 步骤下标
 * @returns 无
 */
function onClick(i: number): void {
  if (!props.clickable || i >= props.current) return;
  emit('change', i);
}
</script>

<template>
  <div class="ds-steps" :class="`is-${direction}`">
    <template v-for="(it, i) in items" :key="i">
      <!-- 步骤节点 -->
      <div
        class="ds-step"
        :class="[`is-${statusOf(i)}`, { 'is-clickable': clickable && i < current }]"
        @click="onClick(i)"
      >
        <!-- 圆点 / 图标 -->
        <span class="ds-step__dot">
          <svg v-if="statusOf(i) === 'done'" viewBox="0 0 24 24" aria-hidden="true"><path d="M20 6 9 17l-5-5" /></svg>
          <template v-else>{{ i + 1 }}</template>
        </span>
        <!-- 文案 -->
        <span class="ds-step__texts">
          <span class="ds-step__label">{{ it.label }}</span>
          <span v-if="it.description" class="ds-step__desc">{{ it.description }}</span>
        </span>
      </div>
      <!-- 连接线（最后一个不画） -->
      <span v-if="i < items.length - 1" class="ds-step__line" :class="i < current ? 'is-done' : ''" />
    </template>
  </div>
</template>

<style scoped>
.ds-steps { display: flex; align-items: flex-start; }
.ds-steps.is-vertical { flex-direction: column; }

.ds-step {
  display: flex;
  align-items: flex-start;
  gap: 10px;
  flex: none;
}
.ds-steps.is-vertical .ds-step { padding-bottom: 18px; }
.ds-step.is-clickable { cursor: pointer; }

/* 圆点 */
.ds-step__dot {
  width: 24px; height: 24px; flex: none;
  display: grid; place-items: center;
  border-radius: 50%;
  border: 1px solid var(--ds-border-strong);
  background: var(--ds-bg-elevated);
  color: var(--ds-text-3);
  font-size: var(--ds-font-xs);
  font-weight: 600;
  transition: all var(--ds-dur) var(--ds-ease);
}
.ds-step__dot svg {
  width: 12px; height: 12px;
  fill: none; stroke: currentColor; stroke-width: 3; stroke-linecap: round; stroke-linejoin: round;
}

/* 状态：完成 */
.ds-step.is-done .ds-step__dot { background: var(--ds-success); border-color: var(--ds-success); color: #fff; }
.ds-step.is-done .ds-step__label { color: var(--ds-text-2); }
/* 状态：进行中 */
.ds-step.is-now .ds-step__dot { background: var(--ds-brand); border-color: var(--ds-brand); color: #fff; }
.ds-step.is-now .ds-step__label { color: var(--ds-brand); font-weight: 600; }
/* 状态：等待 */
.ds-step.is-wait .ds-step__label { color: var(--ds-text-3); }

.ds-step__texts { display: flex; flex-direction: column; gap: 2px; padding-top: 2px; }
.ds-step__label { font-size: var(--ds-font-md); line-height: 1.4; }
.ds-step__desc { font-size: var(--ds-font-xs); color: var(--ds-text-3); }

/* 连接线 */
.ds-step__line {
  flex: 1;
  min-width: 24px;
  height: 1px;
  margin: 12px 10px 0;
  background: var(--ds-border);
  transition: background var(--ds-dur) var(--ds-ease);
}
.ds-step__line.is-done { background: var(--ds-success); }
.ds-steps.is-vertical .ds-step__line {
  width: 1px;
  height: 18px;
  flex: none;
  margin: 0 0 0 11px;
}
</style>
