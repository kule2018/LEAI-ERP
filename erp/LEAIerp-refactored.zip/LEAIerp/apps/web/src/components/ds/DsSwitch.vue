<!-- src/components/ds/DsSwitch.vue -->
<script setup lang="ts">
/**
 * DsSwitch —— 开关。
 *
 * 设计要点：
 *   1) 40×22 轨道 + 滑块位移过渡，与 DeepSeek 设置页开关一致；
 *   2) 加载态：滑块变成转圈，防止重复点击；
 *   3) 支持内嵌文字（开 / 关文案显示在轨道两侧或滑块内，由 checkedText/uncheckedText 控制）；
 *   4) 点击区域 = 整个 label（含文字），好点中。
 */
import { computed } from 'vue';

/** 组件入参 */
const props = withDefaults(
  defineProps<{
    /** 开关值（v-model） */
    modelValue: boolean;
    /** 是否加载中（禁用并显示转圈） */
    loading?: boolean;
    /** 是否禁用 */
    disabled?: boolean;
    /** 尺寸：sm / md / lg */
    size?: 'sm' | 'md' | 'lg';
    /** 选中时轨道内文案 */
    checkedText?: string;
    /** 未选中时轨道内文案 */
    uncheckedText?: string;
  }>(),
  { loading: false, disabled: false, size: 'md', checkedText: '', uncheckedText: '' },
);

/** 事件 */
const emit = defineEmits<{ (e: 'update:modelValue', v: boolean): void; (e: 'change', v: boolean): void }>();

/** 是否真的不可点 */
const isDisabled = computed(() => props.disabled || props.loading);

/** 是否显示内嵌文字（两个文案至少给一个） */
const hasInnerText = computed(() => !!props.checkedText || !!props.uncheckedText);

/**
 * 切换开关。
 * @returns 无
 */
function toggle(): void {
  if (isDisabled.value) return;
  const next = !props.modelValue;
  emit('update:modelValue', next);
  emit('change', next);
}
</script>

<template>
  <button
    type="button"
    class="ds-switch"
    :class="[
      `is-${size}`,
      { 'is-on': modelValue, 'is-disabled': isDisabled, 'is-loading': loading, 'has-text': hasInnerText },
    ]"
    role="switch"
    :aria-checked="modelValue"
    :disabled="isDisabled"
    @click="toggle"
  >
    <span class="ds-switch__track">
      <span v-if="loading" class="ds-switch__spin" aria-hidden="true" />
      <span v-else-if="hasInnerText" class="ds-switch__text">
        {{ modelValue ? checkedText : uncheckedText }}
      </span>
    </span>
    <!-- 外部说明文字（可选） -->
    <span v-if="$slots.default" class="ds-switch__label"><slot /></span>
  </button>
</template>

<style scoped>
.ds-switch {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  border: 0;
  background: transparent;
  padding: 0;
  font-family: inherit;
  cursor: pointer;
}
.ds-switch.is-disabled { cursor: not-allowed; opacity: 0.55; }

/* 轨道 */
.ds-switch__track {
  position: relative;
  flex: none;
  width: 40px;
  height: 22px;
  border-radius: var(--ds-radius-full);
  background: var(--ds-border-strong);
  transition: background var(--ds-dur) var(--ds-ease);
}
.ds-switch.is-sm .ds-switch__track { width: 32px; height: 18px; }
.ds-switch.is-lg .ds-switch__track { width: 48px; height: 26px; }

/* 滑块：用 ::after 画，位移即开关 */
.ds-switch__track::after {
  content: '';
  position: absolute;
  top: 2px;
  left: 2px;
  width: 18px;
  height: 18px;
  border-radius: 50%;
  background: #fff;
  box-shadow: var(--ds-shadow-sm);
  transition: transform var(--ds-dur) var(--ds-ease);
}
.ds-switch.is-sm .ds-switch__track::after { width: 14px; height: 14px; }
.ds-switch.is-lg .ds-switch__track::after { width: 22px; height: 22px; }
.ds-switch.is-sm.is-on .ds-switch__track::after { transform: translateX(14px); }
.ds-switch.is-md.is-on .ds-switch__track::after { transform: translateX(18px); }
.ds-switch.is-lg.is-on .ds-switch__track::after { transform: translateX(22px); }

.ds-switch.is-on .ds-switch__track { background: var(--ds-brand); }
.ds-switch:not(.is-disabled):hover .ds-switch__track { filter: brightness(1.05); }

/* 加载态：隐藏滑块，仅在轨道内显示转圈 */
.ds-switch.is-loading .ds-switch__track::after { opacity: 0; }
.ds-switch__spin {
  position: absolute;
  top: 50%;
  left: 50%;
  width: 14px;
  height: 14px;
  margin: -7px 0 0 -7px;
  border: 2px solid #fff;
  border-right-color: transparent;
  border-radius: 50%;
  animation: ds-spin 0.7s linear infinite;
}

/* 内嵌文字 */
.ds-switch__text {
  position: absolute;
  top: 0;
  bottom: 0;
  display: flex;
  align-items: center;
  font-size: 10px;
  color: #fff;
  padding: 0 6px;
  line-height: 1;
}
.ds-switch.is-on .ds-switch__text { right: 0; }
.ds-switch:not(.is-on) .ds-switch__text { left: 0; color: var(--ds-text-3); }

/* 外部文字 */
.ds-switch__label { font-size: var(--ds-font-md); color: var(--ds-text-2); }
</style>
