<!-- src/components/ds/DsTable.vue -->
<script setup lang="ts">
/**
 * 数据表格
 * ------------------------------------------------------------------
 * 用「列配置 + 数据」驱动，内置：空态、加载态、行点击、自定义单元格插槽。
 * 为对齐 kuyou（Element Plus）业务，额外支持：
 *   1) 行多选（selection）：首列出现复选框，emit selection-change（与 el-table 同名事件，回传选中行数组）；
 *   2) 固定列（column.fixed = 'left' | 'right'）：基于 sticky 实现左右冻结；
 *   3) 列排序（column.sortable）：点击表头在 升/降/无 间循环，emit sort-change({ key, order })。
 * 不引第三方表格库，保持零依赖；复杂场景（虚拟滚动）再按需替换。
 */

import { computed, ref, watch } from 'vue';
import type { DsColumn } from './types';

  /** 组件入参 */
  const props = withDefaults(
    defineProps<{
      /** 列配置 */
      columns: DsColumn[];
      /** 数据行 */
      data: any[];
      /** 行唯一键字段名，或取键函数（合并表等复合键场景） */
      rowKey?: string | ((row: any, index: number) => string | number);
      /** 是否加载中 */
      loading?: boolean;
      /** 加载失败时的错误信息（有值时展示错误态与重试按钮） */
      error?: string | null;
      /** 错误态标题 */
      errorTitle?: string;
      /** 空态文案 */
      emptyText?: string;
      /** 是否可点击行（鼠标悬停高亮 + 触发 row-click） */
      clickable?: boolean;
      /** 斑马纹 */
      striped?: boolean;
      /** 是否显示行多选（首列复选框） */
      selection?: boolean;
      /** 已选中行的 key 列表（受控，可选；不传则组件内部自维护） */
      selectedKeys?: (string | number)[];
      /** 跨页保留勾选（选中状态不随 data 变化丢失，selection-change 回传全部选中行） */
      reserveSelection?: boolean;
      /** 高度（px 或 CSS 值）；设置后表头吸顶、表体内部滚动 */
      height?: string | number;
      /** 行类名回调（如汇总表的小计/合计行高亮，对齐 el-table 的 row-class-name） */
      rowClass?: (row: any, index: number) => string;
      /** 是否显示页脚合计行（数据取 summaryData，按列 key 匹配） */
      showSummary?: boolean;
      /** 页脚合计数据（列 key -> 展示值） */
      summaryData?: Record<string, any>;
      /**
       * 单元格合并回调（对齐 el-table 的 span-method）。
       * 返回 { rowspan, colspan }；rowspan=0 表示该格被合并吸收（不渲染）。
       */
      spanMethod?: (params: { column: any; row: any; rowIndex: number; columnIndex: number }) => { rowspan: number; colspan: number } | undefined;
    }>(),
    {
      rowKey: 'id',
      loading: false,
      error: null,
      errorTitle: '加载失败',
      emptyText: '暂无数据',
      clickable: false,
      striped: false,
      selection: false,
      selectedKeys: undefined,
      reserveSelection: false,
      height: undefined,
      rowClass: undefined,
      showSummary: false,
      summaryData: undefined,
      spanMethod: undefined,
    },
  );

/** 事件 */
const emit = defineEmits<{
  (e: 'row-click', row: any, index: number): void;
  (e: 'selection-change', rows: any[]): void;
  (e: 'update:selectedKeys', keys: (string | number)[]): void;
  (e: 'sort-change', payload: { key: string; order: 'asc' | 'desc' | null }): void;
  (e: 'retry'): void;
}>();

/**
 * 按路径取对象的嵌套值（如 'user.name'）。
 * @param obj 数据行
 * @param path 字段路径
 * @returns 取到的值（取不到返回空串）
 */
function pick(obj: any, path: string): any {
  if (!obj) return '';
  return path.split('.').reduce((acc, k) => (acc == null ? '' : acc[k]), obj) ?? '';
}

/** 行的 key（支持字段名或函数） */
function rowId(row: any, i: number): string | number {
  if (typeof props.rowKey === 'function') return props.rowKey(row, i);
  return row?.[props.rowKey] ?? i;
}

/**
 * 单元格的悬浮提示文案。
 * 单元格默认单行 + 省略号，内容被截断时靠 title 展示全文（仅纯文本列需要）。
 *
 * @param row 当前行数据
 * @param key 列 key
 * @returns 提示文案；空值返回 undefined 以避免出现空 tooltip
 */
function titleOf(row: any, key: string): string | undefined {
  const v = pick(row, key);
  if (v === null || v === undefined || v === '') return undefined;
  const s = String(v);
  return s.length > 12 ? s : undefined;
}

/* ============================ 多选 ============================ */
const innerSelected = ref<Set<string | number>>(new Set());
/** reserve 模式：跨页持久化的选中行（key -> row） */
const persistedRows = ref<Map<string | number, any>>(new Map());
/** 实际生效的选中集合：受控优先，否则内部 */
const selected = computed<Set<string | number>>(() => {
  if (props.selectedKeys) return new Set(props.selectedKeys);
  return innerSelected.value;
});

/** 是否全选（仅统计当前页数据） */
const allChecked = computed(
  () => props.data.length > 0 && props.data.every((r) => selected.value.has(rowId(r, 0))),
);
/** 半选态 */
const someChecked = computed(
  () => !allChecked.value && props.data.some((r) => selected.value.has(rowId(r, 0))),
);

/**
 * 切换单行选中。
 * @param row 行数据
 * @returns 无
 */
function toggleRow(row: any): void {
  const id = rowId(row, 0);
  const set = new Set(selected.value);
  if (set.has(id)) set.delete(id);
  else set.add(id);
  innerSelected.value = set;
  if (props.reserveSelection) {
    const m = new Map(persistedRows.value);
    if (set.has(id)) m.set(id, row);
    else m.delete(id);
    persistedRows.value = m;
  }
  emit('update:selectedKeys', [...set]);
  emit('selection-change', emitSelection());
}

/** 表头全选/取消 */
function toggleAll(): void {
  // 先读原状态（allChecked 由 selected 派生，需在改动前取）
  const wasAll = allChecked.value;
  const set = new Set<string | number>();
  if (!wasAll) props.data.forEach((r) => set.add(rowId(r, 0)));
  innerSelected.value = set;
  if (props.reserveSelection) {
    const m = new Map(persistedRows.value);
    if (wasAll) {
      // 取消当前页全部
      for (const r of props.data) m.delete(rowId(r, 0));
    } else {
      for (const r of props.data) m.set(rowId(r, 0), r);
    }
    persistedRows.value = m;
  }
  emit('update:selectedKeys', [...set]);
  emit('selection-change', emitSelection());
}

/** selection-change 回传的选中行：reserve 模式为跨页全量，否则当前页 */
function emitSelection(): any[] {
  if (props.reserveSelection) return [...persistedRows.value.values()];
  return props.data.filter((r) => selected.value.has(rowId(r, 0)));
}

// reserve 模式：data 变化（翻页/重载）后用持久化选中集重新播种内部集合
watch(
  () => props.data,
  () => {
    if (!props.reserveSelection) return;
    const set = new Set<string | number>();
    for (const r of props.data) {
      const id = rowId(r, 0);
      if (persistedRows.value.has(id)) set.add(id);
    }
    innerSelected.value = set;
  },
);

/** 某行是否选中 */
function isRowChecked(row: any): boolean {
  return selected.value.has(rowId(row, 0));
}

/* ============================ 固定列 ============================ */
/** 左侧冻结列累计宽度（像素数值，用于 sticky left 偏移） */
const leftOffsets = computed<Record<string, number>>(() => {
  const map: Record<string, number> = {};
  let acc = 0;
  for (const c of props.columns) {
    if (c.fixed === 'left') {
      map[c.key] = acc;
      acc += parseWidth(c.width);
    }
  }
  return map;
});
/** 右侧冻结列累计宽度（像素数值，用于 sticky right 偏移） */
const rightOffsets = computed<Record<string, number>>(() => {
  const map: Record<string, number> = {};
  let acc = 0;
  const rights = props.columns.filter((c) => c.fixed === 'right');
  for (const c of rights) {
    map[c.key] = acc;
    acc += parseWidth(c.width);
  }
  return map;
});
/** 选择列（首列）宽度 */
const SELECT_W = 44;

/** 把列宽字符串（如 '120px' / '20%'）尽量转成数字像素，未知按 120 计 */
function parseWidth(w?: string): number {
  if (!w) return 120;
  const m = w.match(/^(\d+)/);
  return m ? Number(m[1]) : 120;
}

/** 单元格/表头单元格的固定定位样式 */
function fixedStyle(c: DsColumn, isHead = false): Record<string, string> {
  const style: Record<string, string> = {};
  if (c.fixed === 'left') {
    // 选择列始终在最左
    const offset = props.selection ? SELECT_W : 0;
    // 偏移表已是像素数值，缺失按 0 处理（避免 Number('0px') = NaN 使样式失效）
    const extra = c.key === '__select__' ? 0 : leftOffsets.value[c.key] ?? 0;
    style.position = 'sticky';
    style.left = offset + extra + 'px';
    style.zIndex = isHead ? '3' : '2';
    style.background = isHead ? 'var(--ds-bg-soft)' : 'var(--ds-bg-elevated)';
  } else if (c.fixed === 'right') {
    const extra = rightOffsets.value[c.key] ?? 0;
    style.position = 'sticky';
    style.right = extra + 'px';
    style.zIndex = isHead ? '3' : '2';
    style.background = isHead ? 'var(--ds-bg-soft)' : 'var(--ds-bg-elevated)';
  }
  return style;
}

/* ============================ 排序 ============================ */
/** 当前排序状态 */
const sortState = ref<{ key: string; order: 'asc' | 'desc' | null }>({ key: '', order: null });

/**
 * 点击可排序列表头：循环 无 -> 升 -> 降 -> 无。
 * @param c 列
 * @returns 无
 */
function onSort(c: DsColumn): void {
  if (!c.sortable) return;
  if (sortState.value.key !== c.key) sortState.value = { key: c.key, order: 'asc' };
  else if (sortState.value.order === 'asc') sortState.value = { key: c.key, order: 'desc' };
  else if (sortState.value.order === 'desc') sortState.value = { key: '', order: null };
  else sortState.value = { key: c.key, order: 'asc' };
  emit('sort-change', { ...sortState.value });
}

/** 某列当前排序方向 */
function sortOrderOf(c: DsColumn): 'asc' | 'desc' | null {
  return sortState.value.key === c.key ? sortState.value.order : null;
}

/* ============================ 行点击 ============================ */
/**
 * 行点击转发（忽略选择列点击）。
 * @param row 行数据
 * @param i 行下标
 */
function onRow(row: any, i: number): void {
  if (!props.clickable) return;
  emit('row-click', row, i);
}

/** 表体高度样式 */
const bodyHeightStyle = computed(() => {
  if (!props.height) return {};
  const h = typeof props.height === 'number' ? props.height + 'px' : props.height;
  return { height: h };
});

/**
 * 取单元格合并结果（无 spanMethod 时恒为单格）。
 * @param c 列配置
 * @param row 行数据
 * @param rowIndex 行下标
 * @param columnIndex 列下标
 * @returns { rowspan, colspan }（rowspan=0 表示被合并吸收）
 */
/** 骨架行数：按列数粗略给一个稳定的行数 */
const skeletonRows = computed(() => Math.min(8, Math.max(4, props.columns.length ? 5 : 4)));

/**
 * 骨架条宽度：按列 key 做稳定哈希，保证每次渲染位置一致（不闪烁）。
 * @param c 列配置
 * @returns 百分比宽度
 */
function skeletonWidth(c: any): string {
  let h = 0;
  const key = String(c.key || '');
  for (let i = 0; i < key.length; i += 1) h = (h * 31 + key.charCodeAt(i)) % 1000;
  return `${45 + (h % 40)}%`;
}

function cellSpan(c: DsColumn, row: any, rowIndex: number, columnIndex: number): { rowspan: number; colspan: number } {
  if (!props.spanMethod) return { rowspan: 1, colspan: 1 };
  const r = props.spanMethod({ column: { ...c, property: c.key }, row, rowIndex, columnIndex });
  return r || { rowspan: 1, colspan: 1 };
}
</script>

<template>
  <div class="ds-table-wrap" :style="bodyHeightStyle">
    <table class="ds-table" :class="{ 'is-striped': striped, 'has-fixed': columns.some((c) => c.fixed) }">
      <thead>
        <tr>
          <!-- 选择列 -->
          <th
            v-if="selection"
            class="ds-table-sel"
            :class="{ 'is-fixed-left': true }"
            :style="{ width: SELECT_W + 'px', position: 'sticky', left: '0px', zIndex: '3', background: 'var(--ds-bg-soft)' }"
          >
            <span
              class="ds-table-check"
              :class="{ 'is-checked': allChecked, 'is-indeterminate': someChecked && !allChecked }"
              @click="toggleAll"
            />
          </th>
          <!-- 数据列 -->
          <th
            v-for="c in columns"
            :key="c.key"
            :style="{ width: c.width, minWidth: c.minWidth, textAlign: c.align || 'left', ...fixedStyle(c, true) }"
            :class="{ 'is-sortable': c.sortable, [`is-fixed-${c.fixed}`]: c.fixed }"
            @click="onSort(c)"
          >
            <span class="ds-th-inner">
              {{ c.title }}
              <span v-if="c.sortable" class="ds-sort" :class="`is-${sortOrderOf(c)}`">
                <i class="ds-sort-caret up" />
                <i class="ds-sort-caret down" />
              </span>
            </span>
          </th>
        </tr>
      </thead>

      <tbody>
        <!-- 骨架行：首次加载给出结构占位，避免表格空白后突然闪现 -->
        <template v-if="loading && !data.length">
          <tr v-for="i in skeletonRows" :key="`sk-${i}`" class="ds-table-skeleton">
            <td v-if="selection" class="ds-table-sel" />
            <td v-for="c in columns" :key="c.key">
              <span class="ds-skeleton-bar" :style="{ width: skeletonWidth(c) }" />
            </td>
          </tr>
        </template>
        <tr
          v-for="(row, i) in data"
          :key="rowId(row, i)"
          :class="{ 'is-clickable': clickable, 'is-checked': selection && isRowChecked(row), [rowClass?.(row, i) || '']: true }"
          @click="onRow(row, i)"
        >
          <!-- 选择列 -->
          <td
            v-if="selection"
            class="ds-table-sel"
            :style="{ width: SELECT_W + 'px', position: 'sticky', left: '0px', zIndex: '2', background: isRowChecked(row) ? 'var(--ds-brand-soft)' : 'var(--ds-bg-elevated)' }"
            @click.stop="toggleRow(row)"
          >
            <span class="ds-table-check" :class="{ 'is-checked': isRowChecked(row) }" />
          </td>
          <!-- 数据列 -->
          <template v-for="(c, ci) in columns" :key="c.key">
            <td
              v-if="cellSpan(c, row, i, ci).rowspan !== 0"
              :rowspan="cellSpan(c, row, i, ci).rowspan > 1 ? cellSpan(c, row, i, ci).rowspan : undefined"
              :style="{ textAlign: c.align || 'left', ...fixedStyle(c, false) }"
              :class="[
                `is-fixed-${c.fixed}`,
                {
                  'ds-td-wrap': c.wrap,
                  'ds-td-slot': !c.wrap && !!$slots[c.key],
                },
              ]"
              :title="c.wrap || $slots[c.key] ? undefined : titleOf(row, c.key)"
            >
              <!-- 有 formatter 且未用插槽时按 formatter 渲染 -->
              <slot :name="c.key" :row="row" :index="i" :value="pick(row, c.key)">
                <template v-if="c.formatter">{{ c.formatter(pick(row, c.key), row, i) }}</template>
                <template v-else>{{ pick(row, c.key) }}</template>
              </slot>
            </td>
          </template>
        </tr>
      </tbody>

      <!-- 页脚合计行 -->
      <tfoot v-if="showSummary">
        <tr>
          <td
            v-for="(c, ci) in columns"
            :key="c.key"
            :style="{ textAlign: c.align || 'left' }"
            class="ds-table-sum"
          >
            <template v-if="ci === 0">合计</template>
            <template v-else>{{ summaryData?.[c.key] ?? '—' }}</template>
          </td>
        </tr>
      </tfoot>
    </table>

    <!-- 错误态：给出原因与重试入口，避免用户面对空表格不知所措 -->
    <div v-if="error" class="ds-table-error">
      <div class="ds-table-error-title">{{ errorTitle }}</div>
      <div class="ds-table-error-msg">{{ error }}</div>
      <button class="ds-table-retry" type="button" @click="emit('retry')">重新加载</button>
    </div>

    <!-- 空态 -->
    <div v-else-if="!loading && !data.length" class="ds-table-empty">{{ emptyText }}</div>

    <!-- 加载态：覆盖在表格上方（已有数据时的刷新） -->
    <div v-if="loading && data.length" class="ds-table-loading">加载中…</div>
  </div>
</template>

<style scoped>
.ds-table-wrap {
  position: relative;
  width: 100%;
  overflow: auto;
  border: 1px solid var(--ds-border);
  border-radius: var(--ds-radius-panel);
  background: var(--ds-bg-elevated);
}

.ds-table {
  width: 100%;
  /* 必须用 separate：Chrome 下 border-collapse:collapse 会让 td/th 的 position:sticky 失效，
     导致 fixed:'right' 的操作列随超宽表格一起滚出可视区（按钮不可点） */
  border-collapse: separate;
  border-spacing: 0;
  font-size: var(--ds-font-sm);
}

.ds-table th {
  padding: var(--ds-space-3) var(--ds-space-4);
  font-weight: 500;
  color: var(--ds-text-3);
  background: var(--ds-bg-soft);
  border-bottom: 1px solid var(--ds-border);
  white-space: nowrap;
  text-align: left;
  line-height: 1.5;
}
.ds-table th.is-sortable { cursor: pointer; user-select: none; }
.ds-table th.is-sortable:hover { color: var(--ds-text); }

.ds-table td {
  padding: var(--ds-space-3) var(--ds-space-4);
  color: var(--ds-text-2);
  border-bottom: 1px solid var(--ds-divider);
  vertical-align: middle;
  line-height: 1.5;
  /* 数据网格惯例：默认单行 + 省略号，避免长文本把行撑高、列宽被挤乱；
     需要换行的列在配置里加 wrap，会走下面的 .ds-td-wrap 覆盖 */
  max-width: 320px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ds-td-wrap {
  white-space: normal;
  overflow: visible;
  text-overflow: clip;
  max-width: none;
}
/* 插槽列（操作按钮 / 状态标签 / 自定义渲染）：单行但绝不裁切，避免按钮被吃掉 */
.ds-td-slot {
  white-space: nowrap;
  overflow: visible;
  text-overflow: clip;
  max-width: none;
}

.ds-table tbody tr:last-child td { border-bottom: none; }

/* 页脚合计行 */
.ds-table tfoot td {
  padding: var(--ds-space-3) var(--ds-space-4);
  font-weight: 600;
  color: var(--ds-text);
  background: var(--ds-bg-soft);
  border-top: 1px solid var(--ds-border);
  white-space: nowrap;
}

.ds-table.is-striped tbody tr:nth-child(even) { background: var(--ds-bg-hover); }

.ds-table tbody tr.is-clickable { cursor: pointer; transition: background-color var(--ds-dur-fast) var(--ds-ease); }
.ds-table tbody tr.is-clickable:hover { background: var(--ds-brand-soft); }
.ds-table tbody tr.is-checked { background: var(--ds-brand-soft); }

/* 固定列阴影提示 */
.ds-table.has-fixed .is-fixed-left.is-checked,
.ds-table.has-fixed td.is-fixed-left { box-shadow: 2px 0 0 var(--ds-border); }
.ds-table.has-fixed .is-fixed-right { box-shadow: -2px 0 0 var(--ds-border); }

/* 选择列：视觉 16px，点击热区扩展到 ≥40px（伪元素，不改变布局） */
.ds-table-sel { text-align: center; }
.ds-table-check {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: var(--ds-hit); height: var(--ds-hit);
  border: 0;
  position: relative;
  cursor: pointer;
  vertical-align: middle;
}
.ds-table-check::before {
  content: '';
  width: 16px; height: 16px;
  border: 1px solid var(--ds-border-strong);
  border-radius: var(--ds-radius-mini);
  background: var(--ds-bg-elevated);
  transition: background var(--ds-dur-fast) var(--ds-ease), border-color var(--ds-dur-fast) var(--ds-ease);
}
.ds-table-check:hover::before { border-color: var(--ds-brand); }
.ds-table-check.is-checked::before {
  background: var(--ds-brand) url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='11' height='11' viewBox='0 0 24 24' fill='none' stroke='white' stroke-width='3.5' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='M20 6 9 17l-5-5'/%3E%3C/svg%3E") center/11px no-repeat;
  border-color: var(--ds-brand);
}
.ds-table-check.is-indeterminate::after {
  content: ''; position: absolute; left: 50%; top: 50%; transform: translate(-50%, -50%);
  width: 8px; height: 2px; border-radius: 1px; background: var(--ds-brand);
}

/* 排序指示 */
.ds-th-inner { display: inline-flex; align-items: center; gap: 4px; }
.ds-sort { display: inline-flex; flex-direction: column; line-height: 0; }
.ds-sort-caret {
  width: 0; height: 0; border-left: 4px solid transparent; border-right: 4px solid transparent;
  opacity: 0.3;
}
.ds-sort-caret.up { border-bottom: 5px solid currentColor; margin-bottom: 1px; }
.ds-sort-caret.down { border-top: 5px solid currentColor; }
.ds-sort.is-asc .up { opacity: 1; color: var(--ds-brand); }
.ds-sort.is-desc .down { opacity: 1; color: var(--ds-brand); }

.ds-table-empty {
  padding: var(--ds-space-8) var(--ds-space-4);
  text-align: center;
  color: var(--ds-text-3);
  font-size: var(--ds-font-sm);
}

.ds-table-loading {
  position: absolute;
  inset: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  background: var(--ds-frosted);
  color: var(--ds-text-3);
  font-size: var(--ds-font-sm);
}

/* 骨架行：首屏加载时给出结构占位 */
.ds-table-skeleton td { border-bottom: 1px solid var(--ds-divider); }
.ds-skeleton-bar {
  display: block;
  height: 10px;
  border-radius: 5px;
  background: linear-gradient(90deg, var(--ds-bg-soft) 25%, var(--ds-bg-hover) 37%, var(--ds-bg-soft) 63%);
  background-size: 400% 100%;
  animation: ds-skeleton 1.4s ease infinite;
}
@keyframes ds-skeleton {
  0% { background-position: 100% 50%; }
  100% { background-position: 0 50%; }
}

/* 错误态：给出原因与重试入口 */
.ds-table-error {
  padding: var(--ds-space-6) var(--ds-space-4);
  text-align: center;
}
.ds-table-error-title { font-size: var(--ds-font-md); font-weight: 600; color: var(--ds-text); }
.ds-table-error-msg {
  margin-top: var(--ds-space-2);
  font-size: var(--ds-font-sm);
  color: var(--ds-text-3);
  line-height: 1.6;
}
.ds-table-retry {
  margin-top: var(--ds-space-3);
  height: var(--ds-ctl-h-md);
  padding: 0 var(--ds-space-4);
  border: 1px solid var(--ds-brand);
  border-radius: var(--ds-radius-ctl);
  background: var(--ds-brand);
  color: #fff;
  font-size: var(--ds-font-sm);
  cursor: pointer;
}
.ds-table-retry:hover { opacity: .9; }
</style>
