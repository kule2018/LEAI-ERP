<!-- src/components/ds/DsTabs.vue -->
<script setup lang="ts">
/**
 * DsTabs —— 选项卡切换器。
 *
 * 设计要点：
 *   1) 两种风格：line（下划线，适合页面级分区）、pill（胶囊，适合卡片内的轻切换）；
 *   2) 支持 v-model 双向绑定，也支持不传值时的纯展示（内部自维护选中项）；
 *   3) 支持徽标（如「待处理 12」）与禁用项；
 *   4) 底部有一条滑动指示条（line 模式），按激活项实测宽定位，切换时带缓动位移，观感接近 DeepSeek 设置页。
 */
import { computed, nextTick, onBeforeUnmount, onMounted, ref, watch } from 'vue';

import type { TabItem } from './types';

const props = withDefaults(
  defineProps<{
    /** 当前选中值（配合 v-model 使用） */
    modelValue?: string | number;
    /** 选项卡列表 */
    items: TabItem[];
    /** 风格：line 下划线 / pill 胶囊 */
    variant?: 'line' | 'pill';
    /** 是否占满宽度（每项等分） */
    block?: boolean;
  }>(),
  { modelValue: undefined, variant: 'line', block: false },
);

const emit = defineEmits<{
  /** 选中值变化 */
  (e: 'update:modelValue', v: string | number): void;
  /** 切换完成（携带新值与旧值，方便业务侧做懒加载） */
  (e: 'change', v: string | number, old: string | number): void;
}>();

/** 未受控模式下的内部选中值 */
const inner = ref<string | number>(props.items[0]?.value ?? '');

/** 实际生效的选中值：受控优先，否则取内部值 */
const current = computed(() => (props.modelValue === undefined ? inner.value : props.modelValue));

// 受控值变化时同步给非受控内部值，避免两种模式混用时状态打架
watch(
  () => props.modelValue,
  (v) => { if (v !== undefined) inner.value = v; },
);

/**
 * 点击选项卡。
 * @param item 被点击的项
 */
function pick(item: TabItem): void {
  if (item.disabled || item.value === current.value) return;
  const old = current.value;
  inner.value = item.value;
  emit('update:modelValue', item.value);
  emit('change', item.value, old);
}

/** 根容器引用，指示条定位的测量基准 */
const root = ref<HTMLElement | null>(null);

/** 指示条实测几何：相对根容器的 left 与自身 width（px）；null 表示尚未测到（未挂载或容器隐藏） */
const bar = ref<{ left: number; width: number } | null>(null);

/**
 * 测量激活项位置并更新指示条几何。
 * 思路：直接读取激活按钮的 offsetLeft / offsetWidth（相对于 position:relative 的根容器），
 * 适配文字宽度不均、徽标、block 等分等任意布局；替代早期「按项数等分平移」的估算方案。
 */
function measure(): void {
  if (!root.value) return;
  const btn = root.value.querySelector<HTMLElement>('.ds-tabs__item.is-active');
  // 隐藏状态下 offsetWidth 为 0，先不定位，待 ResizeObserver 在容器可见时补测
  if (!btn || btn.offsetWidth === 0) { bar.value = null; return; }
  bar.value = { left: btn.offsetLeft, width: btn.offsetWidth };
}

/** 指示条样式：按实测值定位；未测到时先隐藏，避免闪现错位 */
const indicatorStyle = computed(() =>
  bar.value
    ? { width: `${bar.value.width}px`, transform: `translateX(${bar.value.left}px)`, opacity: '1' }
    : { opacity: '0' },
);

// 选中项或列表变化后，等 DOM 更新完成再测量
watch(current, async () => { await nextTick(); measure(); });
watch(() => props.items, async () => { await nextTick(); measure(); }, { deep: true });

// 挂载后完成首测；并用 ResizeObserver + window resize 兜底各类布局变化
// （含容器从隐藏到显示、窗口缩放、徽标出现导致激活项宽度变化等场景）
let ro: ResizeObserver | null = null;
onMounted(async () => {
  await nextTick();
  measure();
  if (typeof ResizeObserver !== 'undefined' && root.value) {
    ro = new ResizeObserver(() => measure());
    ro.observe(root.value);
  }
  window.addEventListener('resize', measure);
});

onBeforeUnmount(() => {
  ro?.disconnect();
  ro = null;
  window.removeEventListener('resize', measure);
});
</script>

<template>
  <div ref="root" class="ds-tabs" :class="[`is-${variant}`, { 'is-block': block }]">
    <button
      v-for="item in items"
      :key="item.value"
      type="button"
      class="ds-tabs__item"
      :class="{ 'is-active': item.value === current, 'is-disabled': item.disabled }"
      :disabled="item.disabled"
      @click="pick(item)"
    >
      <span>{{ item.label }}</span>
      <em v-if="item.badge !== undefined && item.badge !== ''" class="ds-tabs__badge">{{ item.badge }}</em>
    </button>

    <!-- 滑动指示条：仅 line 模式展示 -->
    <i v-if="variant === 'line'" class="ds-tabs__bar" :style="indicatorStyle" />
  </div>
</template>

<style scoped>
.ds-tabs { position: relative; display: flex; align-items: center; }

/* ===== line 模式 ===== */
.ds-tabs.is-line {
  gap: 4px;
  border-bottom: 1px solid var(--ds-border);
}
.ds-tabs.is-line .ds-tabs__item {
  position: relative;
  padding: 10px 14px;
  border: 0; background: transparent;
  color: var(--ds-text-2); font-size: 14px; font-family: inherit; cursor: pointer;
  border-radius: var(--ds-radius-sm) var(--ds-radius-sm) 0 0;
  transition: color var(--ds-dur-fast) var(--ds-ease), background var(--ds-dur-fast) var(--ds-ease);
}
.ds-tabs.is-line .ds-tabs__item:hover:not(.is-disabled) { color: var(--ds-text); background: var(--ds-bg-hover); }
.ds-tabs.is-line .ds-tabs__item.is-active { color: var(--ds-brand); font-weight: 600; }
.ds-tabs__bar {
  position: absolute; left: 0; bottom: -1px; height: 2px;
  background: var(--ds-brand); border-radius: 2px;
  transition: transform var(--ds-dur) var(--ds-ease), width var(--ds-dur) var(--ds-ease), opacity var(--ds-dur-fast) var(--ds-ease);
  pointer-events: none;
}

/* ===== pill 模式 ===== */
.ds-tabs.is-pill {
  gap: 2px; padding: 3px;
  background: var(--ds-bg-soft);
  border-radius: var(--ds-radius);
}
.ds-tabs.is-pill .ds-tabs__item {
  padding: 6px 14px;
  border: 0; background: transparent;
  color: var(--ds-text-2); font-size: 13px; font-family: inherit; cursor: pointer;
  border-radius: calc(var(--ds-radius) - 3px);
  transition: background var(--ds-dur-fast) var(--ds-ease), color var(--ds-dur-fast) var(--ds-ease);
}
.ds-tabs.is-pill .ds-tabs__item:hover:not(.is-disabled) { color: var(--ds-text); }
.ds-tabs.is-pill .ds-tabs__item.is-active { background: var(--ds-bg); color: var(--ds-brand); font-weight: 600; box-shadow: var(--ds-shadow-sm); }

/* ===== 通用 ===== */
.ds-tabs.is-block { display: grid; grid-auto-flow: column; grid-auto-columns: 1fr; }
.ds-tabs.is-block .ds-tabs__item { justify-content: center; }
.ds-tabs__item { display: inline-flex; align-items: center; gap: 6px; white-space: nowrap; }
.ds-tabs__item.is-disabled { opacity: .45; cursor: not-allowed; }
.ds-tabs__badge {
  min-width: 18px; height: 18px; padding: 0 5px;
  display: inline-grid; place-items: center;
  border-radius: 9px; background: var(--ds-brand-weak); color: var(--ds-brand);
  font-size: 11px; font-style: normal; font-weight: 600;
}
</style>
