<!-- src/components/ds/DsTag.vue -->
<script setup lang="ts">
/**
 * DsTag —— 标签。
 *
 * 支持 5 种语义色 + 3 种变体（淡底 soft / 描边 outline / 实底 solid）+ 可关闭；
 * 关闭按钮仅在传了 closable 时出现，点击后由父组件决定是否真的移除
 * （组件不擅自删数据，保持受控）。
 */
import { computed } from 'vue';

/** 语义色 */
type TagColor = 'brand' | 'success' | 'warning' | 'danger' | 'neutral';
/** 视觉变体 */
type TagVariant = 'soft' | 'outline' | 'solid';

/** 组件入参 */
const props = withDefaults(
  defineProps<{
    /** 语义色 */
    color?: TagColor;
    /** 变体：soft 淡底 / outline 描边 / solid 实底 */
    variant?: TagVariant;
    /** 尺寸：sm / md */
    size?: 'sm' | 'md';
    /** 是否显示关闭按钮 */
    closable?: boolean;
    /** 是否禁用（置灰且不可点） */
    disabled?: boolean;
  }>(),
  { color: 'neutral', variant: 'soft', size: 'md', closable: false, disabled: false },
);

/** 事件 */
const emit = defineEmits<{ (e: 'close'): void; (e: 'click'): void }>();

/** 是否可交互（有关闭功能时阻止冒泡由模板保证） */
const interactive = computed(() => !props.disabled);

/**
 * 点击关闭按钮。
 * @returns 无
 */
function onClose(): void {
  if (props.disabled) return;
  emit('close');
}

/**
 * 点击标签本体。
 * @returns 无
 */
function onClick(): void {
  if (props.disabled) return;
  emit('click');
}
</script>

<template>
  <span
    class="ds-tag-c"
    :class="[`is-${color}`, `is-${variant}`, `is-${size}`, { 'is-disabled': disabled }]"
    @click="onClick"
  >
    <!-- 前缀图标插槽 -->
    <span v-if="$slots.icon" class="ds-tag-c-icon"><slot name="icon" /></span>
    <span class="ds-tag-c-text"><slot /></span>
    <!-- 关闭按钮 -->
    <button v-if="closable && interactive" type="button" class="ds-tag-c-close" title="移除" @click.stop="onClose">✕</button>
  </span>
</template>

<style scoped>
.ds-tag-c {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  border-radius: var(--ds-radius-full);
  font-weight: 500;
  line-height: 1.6;
  white-space: nowrap;
  border: 1px solid transparent;
  transition: opacity var(--ds-dur-fast) var(--ds-ease);
}
.ds-tag-c.is-md { padding: 2px 10px; font-size: var(--ds-font-xs); }
.ds-tag-c.is-sm { padding: 0 8px; font-size: 11px; }

/* ---- 语义色 × 淡底（默认） ---- */
.is-brand.is-soft { background: var(--ds-brand-soft); color: var(--ds-brand); }
.is-success.is-soft { background: rgba(22, 163, 74, 0.12); color: var(--ds-success); }
.is-warning.is-soft { background: rgba(217, 119, 6, 0.12); color: var(--ds-warning); }
.is-danger.is-soft { background: rgba(220, 38, 38, 0.12); color: var(--ds-danger); }
.is-neutral.is-soft { background: var(--ds-bg-hover); color: var(--ds-text-2); }

/* ---- 描边 ---- */
.is-brand.is-outline { border-color: var(--ds-brand); color: var(--ds-brand); }
.is-success.is-outline { border-color: var(--ds-success); color: var(--ds-success); }
.is-warning.is-outline { border-color: var(--ds-warning); color: var(--ds-warning); }
.is-danger.is-outline { border-color: var(--ds-danger); color: var(--ds-danger); }
.is-neutral.is-outline { border-color: var(--ds-border-strong); color: var(--ds-text-2); }

/* ---- 实底 ---- */
.is-brand.is-solid { background: var(--ds-brand); color: var(--ds-on-brand); }
.is-success.is-solid { background: var(--ds-success); color: #fff; }
.is-warning.is-solid { background: var(--ds-warning); color: #fff; }
.is-danger.is-solid { background: var(--ds-danger); color: #fff; }
.is-neutral.is-solid { background: var(--ds-text-2); color: #fff; }

.ds-tag-c.is-disabled { opacity: 0.5; }
.ds-tag-c-icon { display: inline-flex; align-items: center; }
.ds-tag-c-close {
  border: 0;
  background: transparent;
  color: inherit;
  cursor: pointer;
  font-size: 10px;
  line-height: 1;
  padding: 0 2px;
  border-radius: 50%;
  opacity: 0.7;
}
.ds-tag-c-close:hover { opacity: 1; background: rgba(0, 0, 0, 0.12); }
</style>
