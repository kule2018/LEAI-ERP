<!-- src/components/ds/DsToast.vue -->
<script setup lang="ts">
/**
 * 全局提示容器
 * ------------------------------------------------------------------
 * 由 DsAppShell 挂载一次即可，业务代码通过 useToast() 推消息。
 * 右上角堆叠展示，带图标、进度条与滑入动画。
 */
import { useToast } from './toast';

const { items, remove } = useToast();

/** 各类型对应的图标字符（避免引入图标库） */
const ICONS: Record<string, string> = {
  success: '✓',
  error: '✕',
  warning: '!',
  info: 'i',
};
</script>

<template>
  <div class="ds-toast-host" role="status" aria-live="polite">
    <TransitionGroup name="ds-toast">
      <div
        v-for="t in items"
        :key="t.id"
        class="ds-toast"
        :class="`is-${t.type}`"
        @click="remove(t.id)"
      >
        <span class="ds-toast-icon">{{ ICONS[t.type] || 'i' }}</span>
        <span class="ds-toast-msg">{{ t.message }}</span>
      </div>
    </TransitionGroup>
  </div>
</template>

<style scoped>
.ds-toast-host {
  position: fixed;
  top: 16px;
  left: 50%;
  transform: translateX(-50%);
  display: flex;
  flex-direction: column;
  gap: 8px;
  z-index: 2000;
  pointer-events: none;
}

.ds-toast {
  pointer-events: auto;
  display: flex;
  align-items: center;
  gap: 8px;
  max-width: 460px;
  padding: 9px 16px;
  border-radius: var(--ds-radius-md);
  background: var(--ds-bg-elevated);
  border: 1px solid var(--ds-border);
  box-shadow: var(--ds-shadow-md);
  font-size: var(--ds-font-sm);
  color: var(--ds-text);
  cursor: pointer;
}

.ds-toast-icon {
  width: 18px;
  height: 18px;
  border-radius: 50%;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  font-size: 11px;
  font-weight: 700;
  color: #fff;
  flex-shrink: 0;
}

.is-success .ds-toast-icon { background: var(--ds-success); }
.is-error .ds-toast-icon { background: var(--ds-danger); }
.is-warning .ds-toast-icon { background: var(--ds-warning); }
.is-info .ds-toast-icon { background: var(--ds-brand); }

.ds-toast-msg { line-height: 1.5; word-break: break-word; }

/* 进出动画 */
.ds-toast-enter-active,
.ds-toast-leave-active { transition: all var(--ds-dur) var(--ds-ease); }

.ds-toast-enter-from { opacity: 0; transform: translateY(-10px) scale(0.96); }
.ds-toast-leave-to { opacity: 0; transform: translateY(-6px) scale(0.98); }
.ds-toast-move { transition: transform var(--ds-dur) var(--ds-ease); }
</style>
