<!-- src/components/ds/DsTooltip.vue -->
<script setup lang="ts">
/**
 * DsTooltip —— 文字提示。
 *
 * 悬停 / 聚焦触发，纯文字内容，深色底白字（经典 tooltip 形态，
 * 不随主题反转为浅色，保证在任意背景上可读）。
 */
import { ref } from 'vue';

/** 组件入参 */
const props = withDefaults(
  defineProps<{
    /** 提示文字 */
    content: string;
    /** 弹出方向 */
    placement?: 'top' | 'bottom' | 'left' | 'right';
    /** 是否禁用 */
    disabled?: boolean;
  }>(),
  { placement: 'top', disabled: false },
);

/** 是否可见 */
const show = ref(false);

/**
 * 显示。
 * @returns 无
 */
function onEnter(): void {
  if (!props.disabled) show.value = true;
}

/** 隐藏 */
function onLeave(): void {
  show.value = false;
}
</script>

<template>
  <span class="ds-tooltip" @mouseenter="onEnter" @mouseleave="onLeave" @focusin="onEnter" @focusout="onLeave">
    <!-- 触发器 -->
    <span class="ds-tooltip-ref"><slot /></span>

    <!-- 提示泡 -->
    <Transition name="ds-tip">
      <span v-if="show && content" class="ds-tooltip-pop" :class="`is-${placement}`" role="tooltip">
        {{ content }}
      </span>
    </Transition>
  </span>
</template>

<style scoped>
.ds-tooltip { position: relative; display: inline-flex; }
.ds-tooltip-ref { display: inline-flex; }

.ds-tooltip-pop {
  position: absolute;
  z-index: 300;
  max-width: 260px;
  padding: 5px 10px;
  border-radius: var(--ds-radius-xs);
  background: #1a1d21;
  color: #fff;
  font-size: var(--ds-font-xs);
  line-height: 1.5;
  white-space: normal;
  word-break: break-word;
  box-shadow: var(--ds-shadow-md);
  pointer-events: none;
}
:root[data-theme='dark'] .ds-tooltip-pop { background: #3a3b42; }

.ds-tooltip-pop.is-top { bottom: calc(100% + 6px); left: 50%; transform: translateX(-50%); }
.ds-tooltip-pop.is-bottom { top: calc(100% + 6px); left: 50%; transform: translateX(-50%); }
.ds-tooltip-pop.is-left { right: calc(100% + 6px); top: 50%; transform: translateY(-50%); }
.ds-tooltip-pop.is-right { left: calc(100% + 6px); top: 50%; transform: translateY(-50%); }

/* 进出动画 */
.ds-tip-enter-active,
.ds-tip-leave-active { transition: opacity var(--ds-dur-fast) var(--ds-ease); }
.ds-tip-enter-from,
.ds-tip-leave-to { opacity: 0; }
</style>
