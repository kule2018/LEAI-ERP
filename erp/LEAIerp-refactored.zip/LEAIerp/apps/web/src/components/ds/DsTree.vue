<!-- src/components/ds/DsTree.vue -->
<script setup lang="ts">
/**
 * DsTree —— 树形控件（零依赖自绘）。
 *
 * 能力矩阵（对齐 Element Plus el-tree 的常用子集）：
 *   1) 字段映射：nodeKey / labelKey / childrenKey 可配，适配任意后端结构；
 *   2) 关键字过滤：命中节点或其子孙即保留，并自动展开命中路径；
 *   3) 勾选模式：父子级联（默认）/ 父子独立（checkStrictly），父节点支持半选态；
 *   4) 懒加载：lazy + lazyLoad(node, resolve)，首次展开时按需拉子级；
 *   5) 单选高亮：highlight-current 当前节点蓝底；
 *   6) 默认展开：defaultExpandAll / defaultExpandedKeys。
 *
 * 数据结构说明：懒加载写入时直接修改数据对象的 childrenKey 字段
 * （与 el-tree 行为一致），父组件传入的数组会被原地更新。
 */
import { ref, computed, watch } from 'vue';
import type { TreeNode, LazyLoad } from './types';

/** 组件入参 */
const props = withDefaults(
  defineProps<{
    /** 树数据 */
    data: TreeNode[];
    /** 节点唯一字段（默认 id） */
    nodeKey?: string;
    /** 显示字段（默认 label） */
    labelKey?: string;
    /** 子节点字段（默认 children） */
    childrenKey?: string;
    /** 是否显示过滤框 */
    filterable?: boolean;
    /** 是否显示勾选框 */
    checkable?: boolean;
    /** 父子勾选是否独立（默认 false 级联） */
    checkStrictly?: boolean;
    /** 是否默认展开全部 */
    defaultExpandAll?: boolean;
    /** 默认展开的 key 列表 */
    defaultExpandedKeys?: (string | number)[];
    /** 是否懒加载 */
    lazy?: boolean;
    /** 懒加载回调 */
    lazyLoad?: LazyLoad;
    /** 是否高亮当前选中节点 */
    highlightCurrent?: boolean;
    /** 是否点击节点标签即展开 / 收起 */
    expandOnClick?: boolean;
  }>(),
  {
    nodeKey: 'id',
    labelKey: 'label',
    childrenKey: 'children',
    filterable: false,
    checkable: false,
    checkStrictly: false,
    defaultExpandAll: false,
    defaultExpandedKeys: () => [],
    lazy: false,
    highlightCurrent: true,
    expandOnClick: false,
  },
);

/** 事件 */
const emit = defineEmits<{
  (e: 'select', node: TreeNode): void;
  (e: 'check', keys: (string | number)[], nodes: TreeNode[]): void;
  (e: 'node-expand', node: TreeNode, expanded: boolean): void;
}>();

/** 展开的 key 集合 */
const expanded = ref<Set<string | number>>(new Set());
/** 勾选的 key 集合（级联模式下含父级） */
const checked = ref<Set<string | number>>(new Set());
/** 当前选中 key */
const current = ref<string | number | null>(null);
/** 过滤关键字 */
const keyword = ref('');
/** 正在懒加载的 key 集合（显示转圈） */
const loadingKeys = ref<Set<string | number>>(new Set());

/* ============================ 内部工具 ============================ */

/**
 * 递归遍历整棵树（前序）。
 * @param list 节点数组
 * @param fn 访问函数
 * @returns 无
 */
function walk(list: TreeNode[] | undefined, fn: (n: TreeNode) => void): void {
  if (!Array.isArray(list)) return;
  for (const n of list) {
    fn(n);
    walk(n[props.childrenKey], fn);
  }
}

/** 节点 key 读取 */
const keyOf = (n: TreeNode) => n[props.nodeKey];
/** 是否有子节点数据 */
const hasChildren = (n: TreeNode) => Array.isArray(n[props.childrenKey]) && n[props.childrenKey].length > 0;
/** 是否可能还有子级（懒加载占位：有 lazyLoad 且没展开过就当可能有） */
const mayHaveChildren = (n: TreeNode) => hasChildren(n) || (props.lazy && !n.__loaded);

/**
 * 收集某节点全部子孙 key（不含自身）。
 * @param n 节点
 * @returns key 数组
 */
function descendantKeys(n: TreeNode): (string | number)[] {
  const out: (string | number)[] = [];
  walk(n[props.childrenKey], (c) => out.push(keyOf(c)));
  return out;
}

/** 某节点是否勾选：级联模式下父节点勾选 = 自身在集合内 */
const isChecked = (n: TreeNode) => checked.value.has(keyOf(n));

/**
 * 某节点是否半选：自身未勾选，但有子孙被勾选。
 * @param n 节点
 * @returns 是否半选
 */
function isIndeterminate(n: TreeNode): boolean {
  if (!props.checkable || props.checkStrictly) return false;
  if (isChecked(n)) return false;
  return descendantKeys(n).some((k) => checked.value.has(k));
}

/**
 * 切换勾选：级联模式联动子孙与祖先。
 * @param n 节点
 * @returns 无
 */
function toggleCheck(n: TreeNode): void {
  const set = new Set(checked.value);
  const self = keyOf(n);
  const kin = descendantKeys(n);
  if (props.checkStrictly) {
    // 父子独立：只动自己
    if (set.has(self)) set.delete(self);
    else set.add(self);
  } else {
    // 级联：全勾 -> 全撤；否则祖孙全勾
    const allChecked = set.has(self) && kin.every((k) => set.has(k));
    if (allChecked) {
      set.delete(self);
      kin.forEach((k) => set.delete(k));
    } else {
      set.add(self);
      kin.forEach((k) => set.add(k));
    }
  }
  checked.value = set;
  emitCheck();
}

/** 勾选变化后统一出口：把 key 列表与节点列表抛给父组件 */
function emitCheck(): void {
  const nodes: TreeNode[] = [];
  if (props.data) {
    walk(props.data, (n) => {
      if (checked.value.has(keyOf(n))) nodes.push(n);
    });
  }
  emit('check', [...checked.value], nodes);
}

/**
 * 已勾选节点（对外语义）：顶层勾选项。
 * 级联模式下父级全勾时只返回父级，避免父子和子级同时出现造成重复。
 * @returns 顶层勾选节点数组
 */
function checkedNodes(): TreeNode[] {
  const out: TreeNode[] = [];
  const visit = (list: TreeNode[]) => {
    for (const n of list) {
      if (checked.value.has(keyOf(n))) out.push(n);
      else visit(n[props.childrenKey] || []);
    }
  };
  visit(props.data || []);
  return out;
}

/**
 * 展开 / 收起；懒加载节点首次展开时触发回调。
 * @param n 节点
 * @returns 无
 */
function toggleExpand(n: TreeNode): void {
  const k = keyOf(n);
  const set = new Set(expanded.value);
  if (set.has(k)) {
    set.delete(k);
    expanded.value = set;
    emit('node-expand', n, false);
    return;
  }
  set.add(k);
  expanded.value = set;
  emit('node-expand', n, true);
  // 懒加载：标记未加载过、当前无子级，则拉数据
  if (props.lazy && !n.__loaded && !hasChildren(n)) {
    loadingKeys.value.add(k);
    props.lazyLoad?.(n, (data) => {
      // 把子级写回数据对象（原地修改，父组件数组同步可见）
      n[props.childrenKey] = data || [];
      n.__loaded = true;
      loadingKeys.value.delete(k);
    });
  }
}

/**
 * 点击节点：单选高亮 + emit select；expandOnClick 时顺带展开。
 * @param n 节点
 * @returns 无
 */
function onNodeClick(n: TreeNode): void {
  current.value = keyOf(n);
  emit('select', n);
  if (props.expandOnClick && mayHaveChildren(n)) toggleExpand(n);
}

/* ============================ 过滤 ============================ */

/**
 * 关键字匹配：自身命中，或任一子孙命中（命中则保留整条路径）。
 * @param n 节点
 * @param kw 关键字（已转小写）
 * @returns 是否保留
 */
function match(n: TreeNode, kw: string): boolean {
  if (!kw) return true;
  if (String(n[props.labelKey] ?? '').toLowerCase().includes(kw)) return true;
  return (n[props.childrenKey] || []).some((c: TreeNode) => match(c, kw));
}

/** 过滤后的树（无关键字时原样返回） */
const shownData = computed<TreeNode[]>(() => {
  const kw = keyword.value.trim().toLowerCase();
  if (!kw) return props.data || [];
  const prune = (list: TreeNode[]): TreeNode[] =>
    list
      .filter((n) => match(n, kw))
      .map((n) => {
        const kids = prune(n[props.childrenKey] || []);
        return kids.length ? { ...n, [props.childrenKey]: kids } : n;
      });
  return prune(props.data || []);
});

// 过滤时自动展开全部，方便看到命中的深层节点
watch(keyword, (v) => {
  if (v.trim()) {
    const set = new Set<string | number>();
    walk(shownData.value, (n) => {
      if (mayHaveChildren(n)) set.add(keyOf(n));
    });
    expanded.value = set;
  }
});

/* ============================ 初始化 ============================ */

// 默认展开：展开全部 or 指定 key
function initExpanded(): void {
  const set = new Set<string | number>(props.defaultExpandedKeys || []);
  if (props.defaultExpandAll) walk(props.data, (n) => set.add(keyOf(n)));
  expanded.value = set;
}
initExpanded();
// 数据源整体变化时重来（如切换部门树）
watch(() => props.data, () => initExpanded(), { deep: false });

/* ============================ 对外方法 ============================ */
defineExpose({
  /** 获取已勾选 key（级联模式含父级） */
  getCheckedKeys: () => [...checked.value],
  /** 获取已勾选节点（顶层语义） */
  getCheckedNodes: checkedNodes,
  /**
   * 设置勾选（回显用）。
   * @param keys key 列表
   * @returns 无
   */
  setCheckedKeys: (keys: (string | number)[]) => {
    checked.value = new Set(keys || []);
    emitCheck();
  },
  /** 手动过滤 */
  filter: (kw: string) => (keyword.value = kw),
  /** 懒加载完成后刷新某节点子级（与 lazyLoad 的 resolve 等价） */
  updateKeyChildren: (key: string | number, children: TreeNode[]) => {
    walk(props.data, (n) => {
      if (keyOf(n) === key) {
        n[props.childrenKey] = children;
        n.__loaded = true;
      }
    });
  },
  /** 全部展开 */
  expandAll: () => {
    const set = new Set<string | number>();
    walk(props.data, (n) => set.add(keyOf(n)));
    expanded.value = set;
  },
  /** 全部收起 */
  collapseAll: () => (expanded.value = new Set()),
});
</script>

<template>
  <div class="ds-tree">
    <!-- 过滤框 -->
    <div v-if="filterable" class="ds-tree-filter">
      <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M11 19a8 8 0 1 0 0-16 8 8 0 0 0 0 16Zm10 2-4.35-4.35" /></svg>
      <input v-model="keyword" type="text" placeholder="输入关键字过滤" />
    </div>

      <!-- 树体：递归节点 -->
      <div class="ds-tree-body">
        <DsTreeNode
          v-for="n in shownData"
          :key="String(n[nodeKey])"
          :node="n"
          :depth="0"
          :tree-props="props"
          :expanded="expanded"
          :checked="checked"
          :loading-keys="loadingKeys"
          :current="current"
          :indeterminate-fn="isIndeterminate"
          :may-have-children-fn="mayHaveChildren"
          @toggle-expand="toggleExpand"
          @toggle-check="toggleCheck"
          @click="onNodeClick"
        />
      <!-- 空态 -->
      <div v-if="!shownData.length" class="ds-tree-empty">暂无数据</div>
    </div>
  </div>
</template>

<script lang="ts">
/**
 * DsTreeNode —— 树节点（递归子组件，不在 <script setup> 里注册，
 * 通过普通 <script> + components 选项挂到 DsTree 作用域内使用）。
 *
 * 说明：Vue 的递归组件要求「组件引用自身」，拆成子文件会让 props 透传变复杂；
 * 放在同文件的普通 <script> 块里，配合 template 里的 <DsTreeNode> 自引用即可。
 */
import { defineComponent, h, type Component, type PropType } from 'vue';

/**
 * 节点渲染所需的全部注入（由 DsTree 传入，避免重复定义 props）。
 *
 * 显式标注为 Component：递归组件在自己的渲染函数里引用自身，
 * 不标注会让 TS 无法收敛推断（TS7022/TS7024）。
 */
const DsTreeNode: Component = defineComponent({
  name: 'DsTreeNode',
  props: {
    /** 节点数据 */
    node: { type: Object as PropType<TreeNode>, required: true },
    /** 层级深度（控制缩进） */
    depth: { type: Number, default: 0 },
    /** DsTree 的 props（字段映射等） */
    treeProps: { type: Object, required: true },
    /** 展开集合引用 */
    expanded: { type: Object, required: true },
    /** 勾选集合引用 */
    checked: { type: Object, required: true },
    /** 懒加载中的 key 集合 */
    loadingKeys: { type: Object, required: true },
    /** 当前选中 key */
    current: { type: [String, Number], default: null },
    /** 半选判定函数 */
    indeterminateFn: { type: Function, required: true },
    /** 是否可能有子级 */
    mayHaveChildrenFn: { type: Function, required: true },
  },
  emits: ['toggle-expand', 'toggle-check', 'click'],
  setup(props, { emit }) {
    return () => {
      const p = props.treeProps as any;
      const n = props.node;
      const k = n[p.nodeKey];
      const isOpen = props.expanded.has(k);
      const isChecked = props.checked.has(k);
      const isIndeterminate = props.indeterminateFn(n);
      const isCurrent = props.current === k;
      const isLoading = props.loadingKeys.has(k);
      const kids: TreeNode[] = n[p.childrenKey] || [];
      const mayKids = props.mayHaveChildrenFn(n);

      // 行本体
      const row = h(
        'div',
        {
          class: ['ds-tree-node', { 'is-current': isCurrent, 'is-checked': isChecked }],
          style: { paddingLeft: 8 + props.depth * 18 + 'px' },
          onClick: () => emit('click', n),
        },
        [
          // 展开箭头（可能含子级才显示）
          mayKids
            ? h(
                'span',
                {
                  class: ['ds-tree-arrow', { 'is-open': isOpen }],
                  onClick: (e: MouseEvent) => {
                    e.stopPropagation();
                    emit('toggle-expand', n);
                  },
                },
                isLoading ? h('span', { class: 'ds-tree-arrow-spin' }) : '›',
              )
            : h('span', { class: 'ds-tree-arrow is-hidden' }),
          // 勾选框
          p.checkable
            ? h('span', {
                class: ['ds-tree-check', { 'is-indeterminate': isIndeterminate }],
                onClick: (e: MouseEvent) => {
                  e.stopPropagation();
                  emit('toggle-check', n);
                },
              })
            : null,
          // 标签
          h('span', { class: 'ds-tree-label' }, String(n[p.labelKey] ?? '')),
        ],
      );

      // 子级（展开时递归渲染自身）
      const children =
        isOpen && kids.length
          ? h(
              'div',
              { class: 'ds-tree-children' },
              kids.map((c) =>
                h(DsTreeNode, {
                  key: String(c[p.nodeKey]),
                  node: c,
                  depth: props.depth + 1,
                  treeProps: props.treeProps,
                  expanded: props.expanded,
                  checked: props.checked,
                  loadingKeys: props.loadingKeys,
                  current: props.current,
                  indeterminateFn: props.indeterminateFn,
                  mayHaveChildrenFn: props.mayHaveChildrenFn,
                  onToggleExpand: (nn: TreeNode) => emit('toggle-expand', nn),
                  onToggleCheck: (nn: TreeNode) => emit('toggle-check', nn),
                  onClick: (nn: TreeNode) => emit('click', nn),
                }),
              ),
            )
          : null;

      return h('div', { class: 'ds-tree-item' }, [row, children]);
    };
  },
});

/**
 * DsTree 的普通 <script> 块：只负责把递归子组件注册进模板作用域。
 * 渲染完全由 <script setup> 的模板负责，这里不提供 render。
 */
export default defineComponent({
  name: 'DsTreeScope',
  components: { DsTreeNode },
});
</script>

<style scoped>
.ds-tree { display: flex; flex-direction: column; height: 100%; min-width: 0; }

.ds-tree-filter {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-bottom: 8px;
  padding: 0 10px;
  height: var(--ds-ctl-h-sm);
  border: 1px solid var(--ds-border);
  border-radius: var(--ds-radius-sm);
  background: var(--ds-bg-elevated);
}
.ds-tree-filter:focus-within { border-color: var(--ds-brand); }
.ds-tree-filter svg {
  width: 14px; height: 14px; flex: none;
  fill: none; stroke: var(--ds-text-3); stroke-width: 2; stroke-linecap: round;
}
.ds-tree-filter input {
  flex: 1; min-width: 0; border: 0; outline: none; background: transparent;
  color: var(--ds-text); font-size: var(--ds-font-sm); font-family: inherit;
}

.ds-tree-body { flex: 1; overflow: auto; }
.ds-tree-empty {
  padding: 20px 0; text-align: center;
  color: var(--ds-text-3); font-size: var(--ds-font-sm);
}
</style>

<style scoped>
/*
 * 节点相关元素由 DsTreeNode（h() 渲染的子组件）产出，
 * 其内部元素不会带上本文件的 scope id，故整段用 :deep() 穿透。
 * （Vue scoped 机制：仅子组件根元素继承父级 scope id）
 */
/* 节点行 */
:deep(.ds-tree-node) {
  display: flex;
  align-items: center;
  gap: 4px;
  height: 30px;
  padding-right: 8px;
  border-radius: var(--ds-radius-xs);
  color: var(--ds-text-2);
  font-size: var(--ds-font-sm);
  cursor: pointer;
  transition: background var(--ds-dur-fast) var(--ds-ease);
}
:deep(.ds-tree-node:hover) { background: var(--ds-bg-hover); }
:deep(.ds-tree-node.is-current) { background: var(--ds-brand-soft); color: var(--ds-brand); font-weight: 500; }

/* 展开箭头 */
:deep(.ds-tree-arrow) {
  width: 18px;
  height: 18px;
  flex: none;
  display: grid;
  place-items: center;
  border-radius: var(--ds-radius-xs);
  color: var(--ds-text-3);
  font-size: 14px;
  line-height: 1;
  transition: transform var(--ds-dur-fast) var(--ds-ease), background var(--ds-dur-fast) var(--ds-ease);
}
:deep(.ds-tree-arrow:hover) { background: var(--ds-bg-active); }
:deep(.ds-tree-arrow.is-open) { transform: rotate(90deg); }
:deep(.ds-tree-arrow.is-hidden) { visibility: hidden; }
:deep(.ds-tree-arrow-spin) {
  width: 10px; height: 10px;
  border: 2px solid var(--ds-border-strong);
  border-top-color: var(--ds-brand);
  border-radius: 50%;
  animation: ds-spin 0.7s linear infinite;
}

/* 勾选框（复用主题令牌配色） */
:deep(.ds-tree-check) {
  width: 15px; height: 15px; flex: none;
  border: 1px solid var(--ds-border-strong);
  border-radius: var(--ds-radius-xs);
  background: var(--ds-bg-elevated);
  position: relative;
  transition: background var(--ds-dur-fast) var(--ds-ease), border-color var(--ds-dur-fast) var(--ds-ease);
}
:deep(.ds-tree-check:hover) { border-color: var(--ds-brand); }
:deep(.ds-tree-node.is-checked .ds-tree-check) {
  background: var(--ds-brand) url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='11' height='11' viewBox='0 0 24 24' fill='none' stroke='white' stroke-width='3.5' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='M20 6 9 17l-5-5'/%3E%3C/svg%3E") center/11px no-repeat;
  border-color: var(--ds-brand);
}
:deep(.ds-tree-check.is-indeterminate::after) {
  content: '';
  position: absolute;
  inset: 0;
  margin: auto;
  width: 7px; height: 2px;
  border-radius: 1px;
  background: var(--ds-brand);
}

:deep(.ds-tree-label) { flex: 1; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
</style>
