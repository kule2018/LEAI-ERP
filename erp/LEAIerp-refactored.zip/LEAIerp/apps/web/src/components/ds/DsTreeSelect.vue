<!-- src/components/ds/DsTreeSelect.vue -->
<script setup lang="ts">
/**
 * DsTreeSelect —— 树选择器（下拉形态）。
 *
 * 触发器显示选中节点标签；浮层内嵌 DsTree，支持单选与多选（勾选框）、
 * 关键字过滤；多选时已选标签可逐个移除。适合部门 / 分类等层级数据选择。
 */
import { computed, ref, watch } from 'vue';
import { usePopover } from './usePopover';
import DsTree from './DsTree.vue';
import type { TreeNode } from './types';

/** 组件入参 */
const props = withDefaults(
  defineProps<{
    /** 选中值（v-model）：单选为 key，多选为 key 数组 */
    modelValue: string | number | (string | number)[];
    /** 树数据 */
    data: TreeNode[];
    /** 节点唯一字段 */
    nodeKey?: string;
    /** 显示字段 */
    labelKey?: string;
    /** 子节点字段 */
    childrenKey?: string;
    /** 是否多选 */
    multiple?: boolean;
    /** 占位文案 */
    placeholder?: string;
    /** 是否可清空 */
    clearable?: boolean;
    /** 是否禁用 */
    disabled?: boolean;
  }>(),
  {
    data: () => [],
    nodeKey: 'id',
    labelKey: 'label',
    childrenKey: 'children',
    multiple: false,
    placeholder: '请选择',
    clearable: true,
    disabled: false,
  },
);

/** 事件 */
const emit = defineEmits<{ (e: 'update:modelValue', v: any): void; (e: 'change', v: any): void }>();

// 浮层控制
const { open, rootRef, toggle, close } = usePopover();
void rootRef;
/** DsTree 实例引用（读取勾选结果） */
const treeRef = ref<InstanceType<typeof DsTree>>();

/** 扁平查找：按 key 找节点 */
function findNode(key: string | number): TreeNode | undefined {
  let hit: TreeNode | undefined;
  const walk = (list: TreeNode[]) => {
    for (const n of list) {
      if (n[props.nodeKey] === key) hit = n;
      else walk(n[props.childrenKey] || []);
    }
  };
  walk(props.data);
  return hit;
}

/** 单选：选中的节点 */
const selectedNode = computed(() => (props.multiple ? undefined : findNode(props.modelValue as string | number)));

/** 多选：选中的节点列表 */
const selectedNodes = computed<TreeNode[]>(() => {
  if (!props.multiple || !Array.isArray(props.modelValue)) return [];
  return props.modelValue.map((k) => findNode(k)).filter((n): n is TreeNode => !!n);
});

/** 触发器文案 */
const text = computed(() => {
  if (props.multiple) return selectedNodes.value.map((n) => n[props.labelKey]).join('、');
  return selectedNode.value ? String(selectedNode.value[props.labelKey]) : '';
});

/**
 * 树节点点击（单选模式）。
 * @param n 节点
 * @returns 无
 */
function onSelect(n: TreeNode): void {
  if (props.multiple) return;
  emit('update:modelValue', n[props.nodeKey]);
  emit('change', n[props.nodeKey]);
  close();
}

/**
 * 树勾选变化（多选模式）。
 * @param keys 已勾选 key 列表
 * @returns 无
 */
function onCheck(keys: (string | number)[]): void {
  if (!props.multiple) return;
  emit('update:modelValue', keys);
  emit('change', keys);
}

/**
 * 移除某个已选标签（多选）。
 * @param n 节点
 * @returns 无
 */
function removeTag(n: TreeNode): void {
  if (!props.multiple || !Array.isArray(props.modelValue)) return;
  const next = props.modelValue.filter((k) => k !== n[props.nodeKey]);
  emit('update:modelValue', next);
  emit('change', next);
}

/** 清空 */
function clearValue(): void {
  const v = props.multiple ? [] : '';
  emit('update:modelValue', v);
  emit('change', v);
}

// 每次展开：把当前值回填到树的勾选 / 高亮态
watch(open, (v) => {
  if (!v || !treeRef.value) return;
  if (props.multiple && Array.isArray(props.modelValue)) treeRef.value.setCheckedKeys(props.modelValue);
});
</script>

<template>
  <div ref="rootRef" class="ds-treeselect" :class="{ 'is-disabled': disabled, 'is-open': open }">
    <!-- 触发器 -->
    <div class="ds-treeselect-trigger" @click="!disabled && toggle()">
      <span class="ds-treeselect-text" :class="{ 'is-ph': !text }">{{ text || placeholder }}</span>
      <button v-if="clearable && text && !disabled" type="button" class="ds-treeselect-clear" title="清空" @click.stop="clearValue">✕</button>
      <svg class="ds-treeselect-arrow" :class="{ 'is-flip': open }" viewBox="0 0 24 24" aria-hidden="true"><path d="m6 9 6 6 6-6" /></svg>
    </div>

    <!-- 浮层：内嵌树 -->
    <div v-if="open" class="ds-treeselect-pop">
      <DsTree
        ref="treeRef"
        :data="data"
        :node-key="nodeKey"
        :label-key="labelKey"
        :children-key="childrenKey"
        :checkable="multiple"
        :check-strictly="false"
        filterable
        default-expand-all
        @select="onSelect"
        @check="onCheck"
      />
    </div>

    <!-- 多选：已选标签（触发器下方展示，避免长文本挤爆触发器） -->
    <div v-if="multiple && selectedNodes.length" class="ds-treeselect-tags">
      <span v-for="n in selectedNodes" :key="String(n[nodeKey])" class="ds-treeselect-tag">
        {{ n[labelKey] }}
        <button type="button" title="移除" @click.stop="removeTag(n)">✕</button>
      </span>
    </div>
  </div>
</template>

<style scoped>
.ds-treeselect { position: relative; width: 100%; }

.ds-treeselect-trigger {
  display: flex;
  align-items: center;
  gap: 6px;
  min-height: var(--ds-ctl-h-md);
  padding: 0 10px;
  background: var(--ds-bg-elevated);
  border: 1px solid var(--ds-border);
  border-radius: var(--ds-radius-sm);
  cursor: pointer;
  transition: border-color var(--ds-dur-fast) var(--ds-ease), box-shadow var(--ds-dur-fast) var(--ds-ease);
}
.ds-treeselect-trigger:hover { border-color: var(--ds-border-strong); }
.ds-treeselect.is-open:not(.is-disabled) .ds-treeselect-trigger { border-color: var(--ds-brand); box-shadow: 0 0 0 3px var(--ds-brand-soft); }
.ds-treeselect.is-disabled .ds-treeselect-trigger { background: var(--ds-bg-hover); cursor: not-allowed; }

.ds-treeselect-text {
  flex: 1;
  min-width: 0;
  color: var(--ds-text);
  font-size: var(--ds-font-md);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap
}
.ds-treeselect-text.is-ph { color: var(--ds-text-3); }
.ds-treeselect-clear {
  border: 0; background: transparent; color: var(--ds-text-3);
  cursor: pointer; font-size: var(--ds-font-xs); padding: 2px; border-radius: var(--ds-radius-xs);
}
.ds-treeselect-clear:hover { background: var(--ds-bg-hover); color: var(--ds-text); }
.ds-treeselect-arrow {
  width: 16px; height: 16px; flex: none;
  fill: none; stroke: var(--ds-text-3); stroke-width: 2; stroke-linecap: round; stroke-linejoin: round;
  transition: transform var(--ds-dur-fast) var(--ds-ease);
}
.ds-treeselect-arrow.is-flip { transform: rotate(180deg); }

.ds-treeselect-pop {
  position: absolute;
  top: calc(100% + 6px);
  left: 0;
  right: 0;
  z-index: 100;
  max-height: 280px;
  overflow: auto;
  padding: 8px;
  background: var(--ds-bg-elevated);
  border: 1px solid var(--ds-border);
  border-radius: var(--ds-radius);
  box-shadow: var(--ds-shadow-md);
}

.ds-treeselect-tags {
  display: flex;
  flex-wrap: wrap;
  gap: 4px;
  margin-top: 6px;
}
.ds-treeselect-tag {
  display: inline-flex;
  align-items: center;
  gap: 2px;
  padding: 1px 4px 1px 8px;
  background: var(--ds-brand-soft);
  color: var(--ds-brand);
  border-radius: var(--ds-radius-xs);
  font-size: var(--ds-font-xs);
  line-height: 1.6;
}
.ds-treeselect-tag button {
  border: 0; background: transparent; color: inherit;
  cursor: pointer; font-size: 10px; line-height: 1; padding: 0 2px; border-radius: 50%;
}
.ds-treeselect-tag button:hover { background: rgba(0, 0, 0, 0.12); }
</style>
