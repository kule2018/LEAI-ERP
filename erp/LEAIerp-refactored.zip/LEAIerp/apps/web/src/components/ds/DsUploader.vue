<!-- src/components/ds/DsUploader.vue -->
<script setup lang="ts">
/**
 * 文件上传器
 * ------------------------------------------------------------------
 * 支持点击选择与拖拽上传，带文件列表、体积展示、删除与错误提示。
 * 只负责「选文件 + 预览 + 校验」；真正的上传由父组件通过 select 事件处理，
 * 这样上传接口（OSS / 后端 multipart）可以自由替换。
 */
import { ref } from 'vue';
import { formatBytes } from './format';

/** 组件入参 */
const props = withDefaults(
  defineProps<{
    /** 接受的文件类型（如 '.pdf,image/*'） */
    accept?: string;
    /** 是否多选 */
    multiple?: boolean;
    /** 单文件大小上限（字节），0 表示不限制 */
    maxSize?: number;
    /** 提示文案 */
    tip?: string;
    /** 是否禁用 */
    disabled?: boolean;
  }>(),
  { accept: '', multiple: false, maxSize: 0, tip: '', disabled: false },
);

/** 事件 */
const emit = defineEmits<{
  /** 选中并通过校验的文件 */
  (e: 'select', files: File[]): void;
  /** 校验失败信息 */
  (e: 'error', msg: string): void;
}>();

/** 隐藏的 input 元素引用 */
const inputRef = ref<HTMLInputElement | null>(null);
/** 已选文件（用于列表展示） */
const files = ref<File[]>([]);
/** 是否处于拖拽悬停态 */
const dragging = ref(false);

/**
 * 触发系统文件选择框。
 */
function openPicker(): void {
  if (props.disabled) return;
  inputRef.value?.click();
}

/**
 * 处理选择结果：做体积与数量的校验，通过后通知父组件。
 * @param e 原生 change 事件
 */
function onChange(e: Event): void {
  const el = e.target as HTMLInputElement;
  const picked = Array.from(el.files || []);
  handleFiles(picked);
  // 清空 value：允许重复选择同一个文件也能触发 change
  el.value = '';
}

/**
 * 拖拽放下。
 * @param e 拖放事件
 */
function onDrop(e: DragEvent): void {
  dragging.value = false;
  if (props.disabled) return;
  const dropped = Array.from(e.dataTransfer?.files || []);
  handleFiles(dropped);
}

/**
 * 文件校验与落地。
 * @param list 待处理文件
 */
function handleFiles(list: File[]): void {
  if (!list.length) return;
  const ok: File[] = [];
  for (const f of list) {
    if (props.maxSize > 0 && f.size > props.maxSize) {
      emit('error', `「${f.name}」超过 ${formatBytes(props.maxSize)} 限制`);
      continue;
    }
    ok.push(f);
  }
  if (!ok.length) return;
  files.value = props.multiple ? [...files.value, ...ok] : ok;
  emit('select', ok);
}

/**
 * 移除某个文件。
 * @param i 下标
 */
function removeAt(i: number): void {
  files.value.splice(i, 1);
}

/** 暴露给父组件：清空已选（上传成功后调用） */
defineExpose({ clear: () => { files.value = []; } });
</script>

<template>
  <div class="ds-uploader">
    <!--
      触发器：提供 #trigger 插槽时只渲染该插槽（紧凑形态，适合工具栏行内），
      否则渲染默认的大块「点击/拖拽」区域。
    -->
    <div
      v-if="$slots.trigger"
      class="ds-uploader-trigger"
      :class="{ 'is-disabled': disabled, 'is-drag': dragging }"
      @click="openPicker"
      @dragover.prevent="dragging = true"
      @dragleave="dragging = false"
      @drop.prevent="onDrop"
    >
      <slot name="trigger" :dragging="dragging" />
    </div>

    <!-- 拖拽/点击区域 -->
    <div
      v-else
      class="ds-uploader-area"
      :class="{ 'is-drag': dragging, 'is-disabled': disabled }"
      @click="openPicker"
      @dragover.prevent="dragging = true"
      @dragleave="dragging = false"
      @drop.prevent="onDrop"
    >
      <span class="ds-uploader-icon" aria-hidden="true">＋</span>
      <p class="ds-uploader-main">
        点击上传<span v-if="multiple">或拖拽多个文件到此处</span><span v-else>或拖拽文件到此处</span>
      </p>
      <p v-if="tip" class="ds-uploader-tip">{{ tip }}</p>
    </div>

    <!-- 隐藏的原始 input -->
    <input
      ref="inputRef"
      class="ds-uploader-input"
      type="file"
      :accept="accept"
      :multiple="multiple"
      :disabled="disabled"
      @change="onChange"
    />

    <!-- 已选文件列表 -->
    <ul v-if="files.length" class="ds-uploader-list">
      <li v-for="(f, i) in files" :key="f.name + i" class="ds-uploader-item">
        <span class="ds-uploader-name ds-ellipsis">{{ f.name }}</span>
        <span class="ds-uploader-size">{{ formatBytes(f.size) }}</span>
        <button class="ds-uploader-del" type="button" @click.stop="removeAt(i)">移除</button>
      </li>
    </ul>
  </div>
</template>

<style scoped>
.ds-uploader { width: 100%; }

.ds-uploader-area {
  border: 1.5px dashed var(--ds-border-strong);
  border-radius: var(--ds-radius-lg);
  padding: 24px 16px;
  text-align: center;
  cursor: pointer;
  background: var(--ds-bg-elevated);
  transition: border-color var(--ds-dur) var(--ds-ease), background-color var(--ds-dur) var(--ds-ease);
}

/* 紧凑触发形态：包住业务自带的按钮，不做形态干预，只负责点击与拖拽接收 */
.ds-uploader-trigger {
  display: inline-flex;
  align-items: center;
  cursor: pointer;
}
.ds-uploader-trigger.is-drag { outline: 1.5px dashed var(--ds-brand); outline-offset: 2px; border-radius: var(--ds-radius-md); }
.ds-uploader-trigger.is-disabled { cursor: not-allowed; opacity: 0.55; }

.ds-uploader-area:hover { border-color: var(--ds-brand); background: var(--ds-brand-soft); }
.ds-uploader-area.is-drag { border-color: var(--ds-brand); background: var(--ds-brand-soft); }
.ds-uploader-area.is-disabled { opacity: 0.55; cursor: not-allowed; }

.ds-uploader-icon {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 34px;
  height: 34px;
  border-radius: 50%;
  background: var(--ds-brand-soft);
  color: var(--ds-brand);
  font-size: 20px;
  margin-bottom: 8px;
}

.ds-uploader-main { font-size: var(--ds-font-md); color: var(--ds-text-2); margin: 0; }
.ds-uploader-tip { font-size: var(--ds-font-xs); color: var(--ds-text-3); margin: 4px 0 0; }

.ds-uploader-input { display: none; }

.ds-uploader-list { margin-top: 10px; display: flex; flex-direction: column; gap: 6px; }

.ds-uploader-item {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 7px 12px;
  background: var(--ds-bg-hover);
  border-radius: var(--ds-radius-sm);
  font-size: var(--ds-font-sm);
}

.ds-uploader-name { flex: 1; color: var(--ds-text); }
.ds-uploader-size { color: var(--ds-text-3); flex-shrink: 0; }

.ds-uploader-del {
  color: var(--ds-danger);
  font-size: var(--ds-font-xs);
  flex-shrink: 0;
}

.ds-uploader-del:hover { text-decoration: underline; }
</style>
