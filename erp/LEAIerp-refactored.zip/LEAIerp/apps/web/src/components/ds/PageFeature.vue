<!--
 * PageFeature：页面专属功能区
 * ---------------------------------------------------------------------------
 * 同一个 BusinessPage 骨架会显得「千篇一律」，本组件根据页面画像提供的 type，
 * 把当前页的**真实数据**渲染成完全不同的主体界面：
 *   cards / kanban / timeline / tree / config / progress / preview /
 *   queue / inbox / chart / matrix / switchboard
 * 每个页面选用不同 type，于是布局、信息密度与交互入口各不相同。
-->
<template>
  <div class="page-feature" :class="`pf-${type}`">
    <!-- 卡片墙：店铺 / 角色 / 文件 / 视图 -->
    <div v-if="type === 'cards'" class="pf-cards">
      <div v-for="(c, i) in cards" :key="i" class="pf-card" :class="{ 'is-off': isOff(c.raw) }">
        <div class="pf-card__top">
          <span class="pf-card__icon">{{ c.icon }}</span>
          <span class="pf-card__status" :class="statusTone(c.status)">{{ c.status }}</span>
        </div>
        <div class="pf-card__title">{{ c.title }}</div>
        <div class="pf-card__sub">{{ c.sub }}</div>
        <div v-if="c.metrics.length" class="pf-card__metrics">
          <div v-for="m in c.metrics" :key="m.label"><span>{{ m.label }}</span><b>{{ m.value }}</b></div>
        </div>
      </div>
      <div v-if="!cards.length" class="pf-empty">暂无数据</div>
    </div>

    <!-- 状态看板：订单 / 工单 -->
    <div v-else-if="type === 'kanban'" class="pf-kanban">
      <div v-for="col in kanban" :key="col.name" class="pf-kanban__col">
        <div class="pf-kanban__head"><span class="pf-dot" :class="col.tone"></span>{{ col.name }}<b>{{ col.items.length }}</b></div>
        <div class="pf-kanban__body">
          <div v-for="item in col.items" :key="item.id" class="pf-kanban__card">
            <b>{{ item.title }}</b>
            <span>{{ item.sub }}</span>
            <small v-if="item.extra">{{ item.extra }}</small>
          </div>
          <div v-if="!col.items.length" class="pf-kanban__empty">无</div>
        </div>
      </div>
    </div>

    <!-- 时间线：审计 / 登录 / 活动 -->
    <div v-else-if="type === 'timeline'" class="pf-timeline">
      <div v-for="(t, i) in timeline" :key="i" class="pf-timeline__item">
        <span class="pf-timeline__dot" :class="t.tone"></span>
        <div class="pf-timeline__body">
          <div class="pf-timeline__row"><b>{{ t.title }}</b><time>{{ t.time }}</time></div>
          <p>{{ t.desc }}</p>
          <div v-if="t.tags?.length" class="pf-timeline__tags"><span v-for="(g, j) in t.tags" :key="j">{{ g }}</span></div>
        </div>
      </div>
      <div v-if="!timeline.length" class="pf-empty">暂无数据</div>
    </div>

    <!-- 树：组织 / 权限 / 字典 -->
    <div v-else-if="type === 'tree'" class="pf-tree">
      <div v-for="(n, i) in tree" :key="i" class="pf-tree__node">
        <span class="pf-tree__line" :class="{ last: i === tree.length - 1 }"></span>
        <span class="pf-tree__icon">{{ n.icon }}</span>
        <div class="pf-tree__content"><b>{{ n.title }}</b><span>{{ n.sub }}</span></div>
        <span class="pf-tree__badge" :class="statusTone(n.status)">{{ n.status }}</span>
      </div>
      <div v-if="!tree.length" class="pf-empty">暂无数据</div>
    </div>

    <!-- 配置项：系统参数 / 告警规则 / 编号 -->
    <div v-else-if="type === 'config'" class="pf-config">
      <div v-for="(c, i) in configs" :key="i" class="pf-config__item">
        <div class="pf-config__label"><b>{{ c.label }}</b><code>{{ c.key }}</code></div>
        <div class="pf-config__control">
          <span v-if="c.kind === 'switch'" class="pf-switch" :class="{ on: c.on }"><i></i></span>
          <input v-else class="pf-input" :value="c.value" readonly />
        </div>
        <div class="pf-config__hint">{{ c.hint }}</div>
      </div>
      <div v-if="!configs.length" class="pf-empty">暂无配置项</div>
    </div>

    <!-- 进度：核销 / 映射 / 风险 -->
    <div v-else-if="type === 'progress'" class="pf-progress">
      <div v-for="(p, i) in progresses" :key="i" class="pf-progress__item">
        <div class="pf-progress__head"><b>{{ p.label }}</b><span>{{ p.text }}</span></div>
        <div class="pf-progress__bar"><i :class="p.tone" :style="{ width: p.percent + '%' }"></i></div>
        <div class="pf-progress__foot">{{ p.foot }}</div>
      </div>
      <div v-if="!progresses.length" class="pf-empty">暂无数据</div>
    </div>

    <!-- 预览：单据模板 / 标签 / 编号 -->
    <div v-else-if="type === 'preview'" class="pf-preview">
      <div class="pf-preview__paper">
        <div class="pf-preview__head"><span>{{ title }}</span><small>预览 · 实时数据</small></div>
        <div v-for="(l, i) in previewLines" :key="i" class="pf-preview__line"><span>{{ l.k }}</span><b>{{ l.v }}</b></div>
        <div class="pf-preview__foot">{{ rows.length }} 条记录 · 示例按当前数据渲染</div>
      </div>
      <div class="pf-preview__side">
        <div class="pf-preview__side-title">排版设置</div>
        <label v-for="opt in previewOptions" :key="opt.k"><span>{{ opt.k }}</span><b>{{ opt.v }}</b></label>
      </div>
    </div>

    <!-- 队列：打印 / 定时任务 -->
    <div v-else-if="type === 'queue'" class="pf-queue">
      <div class="pf-queue__stats">
        <div v-for="q in queueStats" :key="q.label"><span>{{ q.label }}</span><b :class="q.tone">{{ q.value }}</b></div>
      </div>
      <div class="pf-queue__list">
        <div v-for="(j, i) in queueItems" :key="i" class="pf-queue__job">
          <span class="pf-queue__no">{{ j.no }}</span>
          <span class="pf-queue__name">{{ j.name }}</span>
          <span class="pf-queue__channel">{{ j.channel }}</span>
          <span class="pf-queue__state" :class="statusTone(j.state)">{{ j.state }}</span>
        </div>
        <div v-if="!queueItems.length" class="pf-empty">暂无任务</div>
      </div>
    </div>

    <!-- 收件箱：通知 -->
    <div v-else-if="type === 'inbox'" class="pf-inbox">
      <div v-for="(m, i) in inbox" :key="i" class="pf-inbox__item" :class="{ unread: m.unread }">
        <span class="pf-inbox__dot"></span>
        <div class="pf-inbox__body"><b>{{ m.title }}</b><p>{{ m.desc }}</p><time>{{ m.time }}</time></div>
        <span class="pf-inbox__tag">{{ m.tag }}</span>
      </div>
      <div v-if="!inbox.length" class="pf-empty">暂无消息</div>
    </div>

    <!-- 图表：AI 洞察 -->
    <div v-else-if="type === 'chart'" class="pf-chart">
      <div class="pf-chart__bars">
        <div v-for="(b, i) in bars" :key="i" class="pf-chart__bar">
          <div class="pf-chart__value">{{ b.value }}</div>
          <div class="pf-chart__column" :class="b.tone" :style="{ height: b.height + '%' }"></div>
          <div class="pf-chart__label">{{ b.label }}</div>
        </div>
      </div>
      <div class="pf-chart__notes">
        <div v-for="(n, i) in insights" :key="i" class="pf-chart__note"><span>{{ n.k }}</span><b :class="n.tone">{{ n.v }}</b></div>
      </div>
    </div>

    <!-- 矩阵：科目匹配 / 数据权限 -->
    <div v-else-if="type === 'matrix'" class="pf-matrix">
      <div class="pf-matrix__grid">
        <div class="pf-matrix__cell head" v-for="h in matrixHead" :key="h">{{ h }}</div>
        <template v-for="(r, i) in matrixRows" :key="i">
          <div class="pf-matrix__cell">{{ r.a }}</div>
          <div class="pf-matrix__cell">{{ r.b }}</div>
          <div class="pf-matrix__cell"><span class="pf-matrix__tag" :class="statusTone(r.state)">{{ r.state }}</span></div>
        </template>
      </div>
      <div v-if="!matrixRows.length" class="pf-empty">暂无数据</div>
    </div>

    <!-- 开关面板：消息订阅 -->
    <div v-else-if="type === 'switchboard'" class="pf-switchboard">
      <div v-for="(s, i) in switches" :key="i" class="pf-switchboard__item">
        <span class="pf-switchboard__icon">{{ s.icon }}</span>
        <div><b>{{ s.title }}</b><p>{{ s.desc }}</p></div>
        <span class="pf-switch" :class="{ on: s.on }"><i></i></span>
      </div>
      <div v-if="!switches.length" class="pf-empty">暂无订阅</div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue';

const props = defineProps<{
  type: string;
  title: string;
  rows: any[];
  config?: Record<string, any>;
}>();

/** 状态语气：用于统一标签配色 */
function statusTone(v: any): string {
  const s = String(v ?? '');
  if (/启用|正常|已授权|已完成|已解决|进行中|ACTIVE|ENABLED|DONE|CLOSED|已读|成功|RUNNING|INDEXED|AUTHORIZED|已处理/.test(s)) return 'ok';
  if (/停用|关闭|已结束|已过期|EXPIRED|CLOSED|FAIL|失败|驳回|ERROR|未读/.test(s)) return 'off';
  if (/待|排队|PENDING|TODO|WARNING|处理中|RUNNING/.test(s)) return 'warn';
  return 'info';
}
function isOff(r: any): boolean { return /停用|关闭|EXPIRED|CLOSED|已结束|FAIL/.test(String(r?.status ?? '')); }
function val(r: any, keys: string[]): any { for (const k of keys) if (r?.[k] !== undefined && r?.[k] !== '') return r[k]; return ''; }
function pick(keys: string[]): any[] { return props.rows.slice(0, 8).map((r) => { const o: any = { id: r.id, raw: r }; keys.forEach((k) => o[k] = r[k]); return o; }); }

const labelOf = (r: any) => String(val(r, ['name', 'title', 'code', 'bizType', 'platform', 'type', 'ruleType', 'logLevel', 'key', 'source']) || '记录');
const statusOf = (r: any) => String(val(r, ['status', 'state', 'isActive', 'enabled', 'payStatus']) ?? '正常');

/* ---------- 卡片 ---------- */
const cards = computed(() => props.rows.slice(0, 8).map((r) => {
  const metrics: Array<{ label: string; value: any }> = [];
  const map: Record<string, string> = { orderCount: '累计订单', amount: '金额', priceDiff: '价格差', usedQty: '已使用', totalQty: '总量', runQty: '运行', efficiency: '效率', commissionRate: '佣金' };
  Object.keys(map).forEach((k) => { if (r[k] !== undefined) metrics.push({ label: map[k], value: r[k] }); });
  const sub = String(val(r, ['platform', 'sellerId', 'code', 'ruleType', 'storage', 'type', 'bizType', 'module', 'model']) || '');
  const desc = String(val(r, ['description', 'remark', 'condition', 'content', 'rule', 'name']) || '');
  return {
    icon: /店|shop/i.test(sub) ? '🏬' : /角色|role/i.test(labelOf(r)) ? '🎭' : /文件|file/i.test(sub) ? '📄' : '📌',
    status: statusOf(r), raw: r,
    title: labelOf(r),
    sub: sub || desc.slice(0, 22) || '业务记录',
    metrics: metrics.slice(0, 3),
  };
}));

/* ---------- 看板 ---------- */
const kanban = computed(() => {
  const groups: Record<string, any[]> = {};
  props.rows.forEach((r) => {
    const k = statusOf(r);
    (groups[k] ||= []).push({
      id: r.id,
      title: labelOf(r),
      sub: String(val(r, ['buyer', 'submitter', 'operator', 'customerName', 'code', 'orderNo', 'ticketNo']) || `#${r.id}`),
      extra: String(val(r, ['amount', 'totalAmount', 'handler', 'createdAt']) || ''),
    });
  });
  const tone = (k: string) => statusTone(k);
  return Object.keys(groups).map((k) => ({ name: k, tone: tone(k), items: groups[k] }));
});

/* ---------- 时间线 ---------- */
const timeline = computed(() => props.rows.slice(0, 8).map((r) => ({
  tone: statusTone(statusOf(r)),
  title: labelOf(r),
  time: String(val(r, ['createdAt', 'printedAt', 'updatedAt', 'startDate', 'loginAt', 'operatedAt', 'date']) || ''),
  desc: String(val(r, ['detail', 'content', 'action', 'description', 'request', 'reason', 'rule', 'message']) || ''),
  tags: [val(r, ['operator', 'module', 'printedBy', 'ip', 'handler', 'level'])].filter(Boolean).map(String),
})));

/* ---------- 树 ---------- */
const tree = computed(() => props.rows.slice(0, 8).map((r) => ({
  icon: /公司|组织|部门/.test(labelOf(r)) ? '🏢' : /权限|角色/.test(labelOf(r)) ? '🔑' : '📂',
  title: labelOf(r),
  sub: String(val(r, ['code', 'description', 'dictType', 'parentName', 'type']) || ''),
  status: statusOf(r),
})));

/* ---------- 配置项 ---------- */
const configs = computed(() => props.rows.slice(0, 8).map((r) => ({
  label: labelOf(r),
  key: String(val(r, ['cfgKey', 'code', 'prefix', 'ruleType', 'bizType']) || `#${r.id}`),
  value: String(val(r, ['cfgValue', 'threshold', 'condition', 'lastNo', 'nextNo', 'value']) || ''),
  hint: String(val(r, ['description', 'remark', 'notifyWay', 'receiver', 'resetCycle']) || ''),
  kind: /enabled|active|status/i.test(JSON.stringify(r)) ? 'text' : 'text',
  on: /1|启用|true/i.test(String(r.status ?? r.enabled ?? '')),
})));

/* ---------- 进度 ---------- */
const progresses = computed(() => props.rows.slice(0, 6).map((r) => {
  const used = Number(r.usedQty ?? r.scanCount ?? r.currentSeq ?? r.hitCount ?? 0);
  const total = Number(r.totalQty ?? r.total ?? 0);
  const pct = total > 0 ? Math.min(100, Math.round(used / total * 100)) : (Number(r.confidence ?? r.rate ?? 0) || 40);
  return {
    label: labelOf(r),
    percent: pct,
    text: pct + '%',
    tone: pct > 80 ? 'ok' : pct > 40 ? 'warn' : 'info',
    foot: String(val(r, ['code', 'riskLevel', 'level', 'status', 'handler']) || ''),
  };
}));

/* ---------- 预览 ---------- */
const previewLines = computed(() => props.rows.slice(0, 4).map((r) => ({
  k: labelOf(r),
  v: String(val(r, ['code', 'bizType', 'paper', 'paperSize', 'size', 'nextNo', 'platformSku', 'field']) || `#${r.id}`),
})));
const previewOptions = computed(() => [
  { k: '纸张', v: String(props.config?.paper || 'A4') },
  { k: '模板版本', v: String(props.config?.version || 'v1.0') },
  { k: '打印通道', v: String(props.config?.channel || 'SERVER_PDF') },
]);

/* ---------- 队列 ---------- */
const queueStats = computed(() => {
  const count = (re: RegExp) => props.rows.filter((r) => re.test(statusOf(r))).length;
  return [
    { label: '全部任务', value: props.rows.length, tone: 'info' },
    { label: '进行中', value: count(/排队|打印中|RUNNING|PENDING|执行中/), tone: 'warn' },
    { label: '已完成', value: count(/完成|成功|DONE|SUCCESS/), tone: 'ok' },
    { label: '失败', value: count(/失败|FAIL|ERROR/), tone: 'off' },
  ];
});
const queueItems = computed(() => props.rows.slice(0, 8).map((r) => ({
  no: String(val(r, ['jobNo', 'taskNo', 'printNo', 'code', 'no']) || `#${r.id}`),
  name: labelOf(r),
  channel: String(val(r, ['channel', 'printMode', 'taskType', 'trigger']) || ''),
  state: statusOf(r),
})));

/* ---------- 收件箱 ---------- */
const inbox = computed(() => props.rows.slice(0, 8).map((r) => ({
  unread: /0|未读|false/i.test(String(r.isRead ?? r.read ?? r.status ?? '0')),
  title: labelOf(r),
  desc: String(val(r, ['content', 'message', 'description', 'response', 'question']) || ''),
  time: String(val(r, ['createdAt', 'sendAt', 'date', 'printedAt']) || ''),
  tag: String(val(r, ['type', 'level', 'module', 'capability']) || ''),
})));

/* ---------- 图表 ---------- */
const bars = computed(() => props.rows.slice(0, 6).map((r) => {
  const n = Number(val(r, ['confidence', 'changeRate', 'amount', 'value', 'loadRate', 'rate']) || 0);
  const h = Math.min(100, Math.max(8, Math.abs(n) > 100 ? Math.abs(n) / 5 : Math.abs(n) || 30));
  return { label: labelOf(r).slice(0, 6), value: n, height: h, tone: n < 0 ? 'off' : 'ok' };
}));
const insights = computed(() => props.rows.slice(0, 3).map((r) => ({
  k: String(val(r, ['metricName', 'reportName', 'name']) || '指标'),
  v: String(val(r, ['metricValue', 'insightText', 'changeRate']) || ''),
  tone: Number(r.changeRate) < 0 ? 'off' : 'ok',
})));

/* ---------- 矩阵 ---------- */
const matrixHead = computed(() => (props.config?.head as string[]) || ['对象', '匹配/范围', '状态']);
const matrixRows = computed(() => props.rows.slice(0, 8).map((r) => ({
  a: labelOf(r),
  b: String(val(r, ['matchedSubject', 'subjectCode', 'code', 'scope', 'level', 'receiver']) || ''),
  state: statusOf(r),
})));

/* ---------- 开关 ---------- */
const switches = computed(() => props.rows.slice(0, 10).map((r) => ({
  icon: /事件|event/i.test(labelOf(r)) ? '📡' : /通知|notify/i.test(labelOf(r)) ? '🔔' : '🔗',
  title: labelOf(r),
  desc: String(val(r, ['description', 'handler', 'source', 'remark', 'code']) || ''),
  on: /1|启用|true|启用中|正常/i.test(String(r.status ?? r.enabled ?? '')),
})));
</script>

<style scoped>
.page-feature { background: var(--ds-bg-elevated, #fff); border: 1px solid var(--ds-border, #e8eaed); border-radius: var(--ds-radius-panel); padding: var(--ds-space-4); }
.pf-empty { text-align: center; color: var(--ds-text-3, #8a9099); padding: var(--ds-space-8); font-size: var(--ds-font-sm); }
.pf-dot { width: 8px; height: 8px; border-radius: 50%; display: inline-block; background: var(--ds-brand); }
.pf-dot.ok, .pf-tag.ok { background: var(--ds-success); } .pf-dot.warn { background: var(--ds-warning); } .pf-dot.off { background: var(--ds-danger); }

/* 卡片墙 */
.pf-cards { display: grid; grid-template-columns: repeat(auto-fill, minmax(220px, 1fr)); gap: var(--ds-gap-field); }
.pf-card { border: 1px solid var(--ds-border); border-radius: var(--ds-radius-panel); padding: var(--ds-space-3); display: flex; flex-direction: column; gap: var(--ds-space-2); background: var(--ds-bg-soft, #fafbfc); }
.pf-card.is-off { opacity: .7; }
.pf-card__top { display: flex; align-items: center; justify-content: space-between; }
.pf-card__icon { font-size: 20px; }
.pf-card__status { font-size: var(--ds-font-xs); padding: 2px 8px; border-radius: var(--ds-radius-pill); background: var(--ds-brand-soft); color: var(--ds-brand); }
.pf-card__status.ok { background: #e7f7ee; color: #12864b; } .pf-card__status.off { background: #fdeaea; color: #c0392b; } .pf-card__status.warn { background: #fff4e0; color: #b26a00; }
.pf-card__title { font-weight: 600; font-size: var(--ds-font-md); }
.pf-card__sub { font-size: var(--ds-font-xs); color: var(--ds-text-3); }
.pf-card__metrics { display: flex; gap: var(--ds-space-4); margin-top: 4px; }
.pf-card__metrics div { display: flex; flex-direction: column; }
.pf-card__metrics span { font-size: 11px; color: var(--ds-text-3); }
.pf-card__metrics b { font-size: var(--ds-font-md); }

/* 看板 */
.pf-kanban { display: flex; gap: var(--ds-gap-field); overflow-x: auto; padding-bottom: 4px; }
.pf-kanban__col { flex: 1 0 220px; background: var(--ds-bg-soft, #fafbfc); border-radius: var(--ds-radius-panel); padding: var(--ds-space-2); }
.pf-kanban__head { display: flex; align-items: center; gap: 6px; font-size: var(--ds-font-sm); font-weight: 600; padding: var(--ds-space-2); }
.pf-kanban__head b { margin-left: auto; color: var(--ds-text-3); }
.pf-kanban__body { display: flex; flex-direction: column; gap: var(--ds-space-2); }
.pf-kanban__card { background: #fff; border: 1px solid var(--ds-border); border-radius: var(--ds-radius-ctl); padding: var(--ds-space-3); display: flex; flex-direction: column; gap: 4px; }
.pf-kanban__card b { font-size: var(--ds-font-sm); }
.pf-kanban__card span, .pf-kanban__card small { font-size: var(--ds-font-xs); color: var(--ds-text-3); }
.pf-kanban__empty { text-align: center; color: var(--ds-text-3); font-size: var(--ds-font-xs); padding: var(--ds-space-4); }

/* 时间线 */
.pf-timeline { position: relative; padding-left: var(--ds-space-5); }
.pf-timeline::before { content: ''; position: absolute; left: 7px; top: 6px; bottom: 6px; width: 2px; background: var(--ds-border); }
.pf-timeline__item { position: relative; padding-bottom: var(--ds-space-4); }
.pf-timeline__dot { position: absolute; left: calc(-1 * var(--ds-space-5) + 3px); top: 4px; width: 10px; height: 10px; border-radius: 50%; background: var(--ds-brand); border: 2px solid #fff; box-shadow: 0 0 0 1px var(--ds-border); }
.pf-timeline__dot.ok { background: var(--ds-success); } .pf-timeline__dot.warn { background: var(--ds-warning); } .pf-timeline__dot.off { background: var(--ds-danger); }
.pf-timeline__row { display: flex; justify-content: space-between; gap: var(--ds-space-3); }
.pf-timeline__row b { font-size: var(--ds-font-sm); }
.pf-timeline__row time { font-size: var(--ds-font-xs); color: var(--ds-text-3); }
.pf-timeline__item p { margin: 4px 0; font-size: var(--ds-font-xs); color: var(--ds-text-2); }
.pf-timeline__tags { display: flex; gap: 6px; }
.pf-timeline__tags span { font-size: 11px; color: var(--ds-text-3); background: var(--ds-bg-soft); padding: 2px 6px; border-radius: var(--ds-radius-pill); }

/* 树 */
.pf-tree { display: flex; flex-direction: column; gap: var(--ds-space-2); }
.pf-tree__node { position: relative; display: flex; align-items: center; gap: var(--ds-space-3); padding: var(--ds-space-2) var(--ds-space-3); background: var(--ds-bg-soft, #fafbfc); border-radius: var(--ds-radius-ctl); }
.pf-tree__line { position: absolute; left: 12px; top: -8px; bottom: 50%; width: 1px; background: var(--ds-border); }
.pf-tree__line.last { bottom: 50%; }
.pf-tree__icon { font-size: 16px; }
.pf-tree__content { display: flex; flex-direction: column; gap: 2px; flex: 1; }
.pf-tree__content b { font-size: var(--ds-font-sm); }
.pf-tree__content span { font-size: var(--ds-font-xs); color: var(--ds-text-3); }
.pf-tree__badge { font-size: 11px; color: var(--ds-brand); }

/* 配置 */
.pf-config { display: grid; grid-template-columns: repeat(auto-fill, minmax(260px, 1fr)); gap: var(--ds-gap-field); }
.pf-config__item { border: 1px solid var(--ds-border); border-radius: var(--ds-radius-panel); padding: var(--ds-space-3); display: grid; grid-template-columns: 1fr auto; gap: 4px var(--ds-space-2); }
.pf-config__label { display: flex; flex-direction: column; }
.pf-config__label b { font-size: var(--ds-font-sm); }
.pf-config__label code { font-size: 11px; color: var(--ds-text-3); }
.pf-config__control { grid-column: 2; grid-row: 1 / span 2; align-self: center; }
.pf-config__hint { grid-column: 1; font-size: var(--ds-font-xs); color: var(--ds-text-3); }
.pf-input { border: 1px solid var(--ds-border); border-radius: var(--ds-radius-ctl); padding: 6px 8px; font-size: var(--ds-font-xs); max-width: 130px; background: var(--ds-bg-soft); }
.pf-switch { width: 38px; height: 20px; border-radius: 999px; background: #cbd0d8; display: inline-block; position: relative; transition: background .2s; }
.pf-switch i { position: absolute; left: 2px; top: 2px; width: 16px; height: 16px; border-radius: 50%; background: #fff; transition: left .2s; }
.pf-switch.on { background: var(--ds-success); } .pf-switch.on i { left: 20px; }

/* 进度 */
.pf-progress { display: flex; flex-direction: column; gap: var(--ds-space-4); }
.pf-progress__head { display: flex; justify-content: space-between; font-size: var(--ds-font-sm); }
.pf-progress__head span { color: var(--ds-text-3); }
.pf-progress__bar { height: 8px; border-radius: 999px; background: var(--ds-bg-soft); overflow: hidden; margin: 6px 0 4px; }
.pf-progress__bar i { display: block; height: 100%; border-radius: 999px; background: var(--ds-brand); }
.pf-progress__bar i.ok { background: var(--ds-success); } .pf-progress__bar i.warn { background: var(--ds-warning); }
.pf-progress__foot { font-size: var(--ds-font-xs); color: var(--ds-text-3); }

/* 预览 */
.pf-preview { display: grid; grid-template-columns: 1fr 220px; gap: var(--ds-gap-field); }
.pf-preview__paper { border: 1px solid var(--ds-border); border-radius: var(--ds-radius-panel); padding: var(--ds-space-4); background: #fff; box-shadow: 0 1px 3px rgba(0,0,0,.04); }
.pf-preview__head { display: flex; justify-content: space-between; align-items: center; border-bottom: 2px solid var(--ds-text); padding-bottom: var(--ds-space-2); margin-bottom: var(--ds-space-3); }
.pf-preview__head span { font-weight: 700; font-size: var(--ds-font-lg); }
.pf-preview__head small { color: var(--ds-text-3); }
.pf-preview__line { display: flex; justify-content: space-between; padding: var(--ds-space-2) 0; border-bottom: 1px dashed var(--ds-border); font-size: var(--ds-font-sm); }
.pf-preview__line span { color: var(--ds-text-3); }
.pf-preview__foot { margin-top: var(--ds-space-3); font-size: var(--ds-font-xs); color: var(--ds-text-3); text-align: right; }
.pf-preview__side { background: var(--ds-bg-soft); border-radius: var(--ds-radius-panel); padding: var(--ds-space-3); }
.pf-preview__side-title { font-weight: 600; font-size: var(--ds-font-sm); margin-bottom: var(--ds-space-3); }
.pf-preview__side label { display: flex; justify-content: space-between; padding: var(--ds-space-2) 0; font-size: var(--ds-font-xs); border-bottom: 1px solid var(--ds-border); }
.pf-preview__side label span { color: var(--ds-text-3); }

/* 队列 */
.pf-queue__stats { display: grid; grid-template-columns: repeat(4, 1fr); gap: var(--ds-gap-field); margin-bottom: var(--ds-space-4); }
.pf-queue__stats div { background: var(--ds-bg-soft); border-radius: var(--ds-radius-ctl); padding: var(--ds-space-3); display: flex; flex-direction: column; gap: 4px; }
.pf-queue__stats span { font-size: var(--ds-font-xs); color: var(--ds-text-3); }
.pf-queue__stats b { font-size: var(--ds-font-xl); }
.pf-queue__stats b.ok { color: var(--ds-success); } .pf-queue__stats b.warn { color: var(--ds-warning); } .pf-queue__stats b.off { color: var(--ds-danger); }
.pf-queue__list { display: flex; flex-direction: column; }
.pf-queue__job { display: grid; grid-template-columns: 140px 1fr 120px 90px; gap: var(--ds-space-3); align-items: center; padding: var(--ds-space-3); border-bottom: 1px solid var(--ds-border); font-size: var(--ds-font-sm); }
.pf-queue__no { color: var(--ds-text-3); font-size: var(--ds-font-xs); }
.pf-queue__channel { color: var(--ds-text-3); font-size: var(--ds-font-xs); }
.pf-queue__state { text-align: right; font-size: var(--ds-font-xs); }
.pf-queue__state.ok { color: var(--ds-success); } .pf-queue__state.warn { color: var(--ds-warning); } .pf-queue__state.off { color: var(--ds-danger); }

/* 收件箱 */
.pf-inbox { display: flex; flex-direction: column; }
.pf-inbox__item { display: flex; gap: var(--ds-space-3); padding: var(--ds-space-3); border-bottom: 1px solid var(--ds-border); align-items: flex-start; }
.pf-inbox__dot { width: 8px; height: 8px; border-radius: 50%; background: var(--ds-border); margin-top: 6px; flex: none; }
.pf-inbox__item.unread .pf-inbox__dot { background: var(--ds-brand); }
.pf-inbox__body { flex: 1; }
.pf-inbox__body b { font-size: var(--ds-font-sm); }
.pf-inbox__body p { font-size: var(--ds-font-xs); color: var(--ds-text-2); margin: 4px 0; }
.pf-inbox__body time { font-size: 11px; color: var(--ds-text-3); }
.pf-inbox__tag { font-size: 11px; color: var(--ds-text-3); background: var(--ds-bg-soft); padding: 2px 8px; border-radius: var(--ds-radius-pill); }

/* 图表 */
.pf-chart { display: grid; grid-template-columns: 1fr 260px; gap: var(--ds-gap-field); }
.pf-chart__bars { display: flex; align-items: flex-end; gap: var(--ds-space-3); height: 200px; padding: var(--ds-space-3); background: var(--ds-bg-soft); border-radius: var(--ds-radius-panel); }
.pf-chart__bar { flex: 1; display: flex; flex-direction: column; align-items: center; justify-content: flex-end; gap: 4px; height: 100%; }
.pf-chart__value { font-size: 11px; color: var(--ds-text-3); }
.pf-chart__column { width: 60%; min-height: 6px; background: var(--ds-brand); border-radius: 4px 4px 0 0; }
.pf-chart__column.ok { background: var(--ds-success); } .pf-chart__column.off { background: var(--ds-danger); }
.pf-chart__label { font-size: 11px; color: var(--ds-text-2); text-align: center; }
.pf-chart__notes { display: flex; flex-direction: column; gap: var(--ds-space-2); }
.pf-chart__note { display: flex; justify-content: space-between; gap: var(--ds-space-2); padding: var(--ds-space-3); border: 1px solid var(--ds-border); border-radius: var(--ds-radius-ctl); font-size: var(--ds-font-xs); }
.pf-chart__note span { color: var(--ds-text-3); } .pf-chart__note b.ok { color: var(--ds-success); } .pf-chart__note b.off { color: var(--ds-danger); }

/* 矩阵 */
.pf-matrix__grid { display: grid; grid-template-columns: 1.4fr 1.4fr 0.8fr; }
.pf-matrix__cell { padding: var(--ds-space-3); border-bottom: 1px solid var(--ds-border); font-size: var(--ds-font-sm); }
.pf-matrix__cell.head { background: var(--ds-bg-soft); color: var(--ds-text-3); font-weight: 600; }
.pf-matrix__tag { font-size: var(--ds-font-xs); padding: 2px 8px; border-radius: var(--ds-radius-pill); background: var(--ds-brand-soft); color: var(--ds-brand); }
.pf-matrix__tag.ok { background: #e7f7ee; color: #12864b; } .pf-matrix__tag.off { background: #fdeaea; color: #c0392b; } .pf-matrix__tag.warn { background: #fff4e0; color: #b26a00; }

/* 开关面板 */
.pf-switchboard { display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: var(--ds-gap-field); }
.pf-switchboard__item { display: flex; align-items: center; gap: var(--ds-space-3); padding: var(--ds-space-3); border: 1px solid var(--ds-border); border-radius: var(--ds-radius-panel); }
.pf-switchboard__icon { font-size: 20px; }
.pf-switchboard__item div { flex: 1; }
.pf-switchboard__item b { font-size: var(--ds-font-sm); }
.pf-switchboard__item p { font-size: var(--ds-font-xs); color: var(--ds-text-3); margin: 2px 0 0; }

@media (max-width: 900px) {
  .pf-preview, .pf-chart { grid-template-columns: 1fr; }
  .pf-queue__job { grid-template-columns: 1fr 1fr; }
}
</style>
