// src/components/ds/formContext.ts
/**
 * 表单上下文与校验执行器（DsForm / DsFormItem 之间共享）。
 *
 * 为什么单独成文件：
 *   1) <script setup> 不能导出类型/工具，两个组件都要用到；
 *   2) 校验规则的解释逻辑集中在这里，避免「表单说必填、字段说没问题」这类分叉。
 */
import type { InjectionKey } from 'vue';
import type { FormRules } from './types';

/** 尺寸档位 */
export type FormSize = 'sm' | 'md' | 'lg';

/** 单个表单项注册给表单的能力 */
export interface FormItemHandle {
  /** 唯一自增 ID（组件卸载时按它注销） */
  uid: number;
  /** 字段路径（如 'name' / 'quota.max_tokens'）；无 prop 的项不参与校验 */
  prop?: string;
  /**
   * 执行本项校验。
   * @returns 通过返回空串，失败返回错误文案
   */
  validate: () => string;
  /** 复位本项（清空错误、可选复位值） */
  reset: () => void;
  /** 仅清空本项错误 */
  clear: () => void;
}

/** 表单提供给子项的上下文 */
export interface FormContext {
  /** 表单模型（响应式对象，子项只读访问） */
  model: Record<string, any>;
  /** 规则集合 */
  rules?: FormRules;
  /** 错误集合：字段路径 -> 文案 */
  errors: Record<string, string>;
  /** 控件尺寸（子项透传给控件） */
  size: FormSize;
  /** 是否整体禁用 */
  disabled: boolean;
  /** 是否已经提交过一次（用于「提交后才实时校验」的交互） */
  attempted: boolean;
  /** 注册子项 */
  register: (item: FormItemHandle) => void;
  /** 注销子项 */
  unregister: (uid: number) => void;
  /** 写入 / 清除某字段错误 */
  setError: (prop: string | undefined, message: string) => void;
}

/** 注入 key：表单上下文 */
export const FORM_CTX: InjectionKey<FormContext> = Symbol('ds-form');

/**
 * 按路径取值（支持 'a.b.c'）。
 * @param obj 源对象
 * @param path 路径
 * @returns 取到的值（不存在时为 undefined）
 */
export function getByPath(obj: Record<string, any> | undefined, path?: string): any {
  if (!obj || !path) return undefined;
  return path.split('.').reduce<any>((acc, key) => (acc == null ? undefined : acc[key]), obj);
}

/**
 * 判断一个值是否「空」：空串、纯空白串、空数组、null、undefined 均视为空。
 * 数字 0 与布尔 false 不算空（配额填 0 是合法业务值）。
 * @param v 待判断的值
 * @returns 是否为空
 */
export function isEmpty(v: any): boolean {
  if (v === null || v === undefined) return true;
  if (typeof v === 'string') return v.trim() === '';
  if (Array.isArray(v)) return v.length === 0;
  return false;
}

/**
 * 按规则逐条校验一个值。
 *
 * @param rules 规则（单条或数组，undefined 表示无规则）
 * @param value 当前值
 * @param model 整个表单模型（供自定义 validator 使用）
 * @returns 通过返回空串，失败返回第一条错误文案
 */
export function validateValue(
  rules: FormRules[string] | undefined,
  value: any,
  model: Record<string, any>,
): string {
  if (!rules) return '';
  const list = Array.isArray(rules) ? rules : [rules];

  for (const rule of list) {
    // 必填：空值直接失败
    if (rule.required && isEmpty(value)) {
      return rule.message || '此项为必填';
    }
    // 非必填且为空：跳过后续长度/格式校验（避免"没填也算格式错"）
    if (!rule.required && isEmpty(value)) continue;

    if (rule.len !== undefined) {
      const len = typeof value === 'string' || Array.isArray(value) ? value.length : NaN;
      if (len !== rule.len) return rule.message || `长度必须为 ${rule.len}`;
    }
    if (rule.min !== undefined) {
      const ok =
        typeof value === 'number' ? value >= rule.min : String(value ?? '').length >= rule.min;
      if (!ok) {
        return (
          rule.message ||
          (typeof value === 'number' ? `不能小于 ${rule.min}` : `至少 ${rule.min} 个字符`)
        );
      }
    }
    if (rule.max !== undefined) {
      const ok =
        typeof value === 'number' ? value <= rule.max : String(value ?? '').length <= rule.max;
      if (!ok) {
        return (
          rule.message ||
          (typeof value === 'number' ? `不能大于 ${rule.max}` : `最多 ${rule.max} 个字符`)
        );
      }
    }
    if (rule.pattern && !rule.pattern.test(String(value ?? ''))) {
      return rule.message || '格式不正确';
    }
    if (rule.validator) {
      const ret = rule.validator(value, model);
      if (ret === false) return rule.message || '校验未通过';
      if (typeof ret === 'string' && ret) return ret;
    }
  }
  return '';
}
