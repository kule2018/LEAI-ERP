// ds/format.ts
/**
 * 通用格式化工具：体积 / 时长 / 复制到剪贴板。
 *
 * 单独成文件的原因：Vue SFC 的 <script setup> 不允许 export，
 * 需要跨组件复用的纯函数统一放这里。
 */

/**
 * 把字节数格式化为人类可读体积。
 * 规则：<1KB 显示 B；<1MB 显示 KB（保留 0 位小数）；否则 MB（1 位小数）。
 * @param bytes 字节数
 * @returns 形如 "1.8 MB" / "356 KB" / "820 B"
 */
export function formatBytes(bytes: number): string {
  const b = Number(bytes) || 0;
  if (b < 1024) return `${b} B`;
  if (b < 1024 * 1024) return `${Math.round(b / 1024)} KB`;
  return `${(b / 1024 / 1024).toFixed(1)} MB`;
}

/**
 * 把毫秒格式化为时长文案。
 * 规则：<1 分钟精确到 0.1 秒；>=1 分钟用「x 分 y 秒」。
 * @param ms 毫秒数
 * @param withUnit 是否带单位（true 时附加 " 秒" / " 分"/" 秒"）
 * @returns 形如 "3.2" / "3.2 秒" / "1 分 5 秒"
 */
export function formatDuration(ms: number, withUnit = false): string {
  const msec = Number(ms) || 0;
  const totalSec = msec / 1000;
  if (totalSec < 60) {
    const s = totalSec < 10 ? totalSec.toFixed(1) : String(Math.round(totalSec));
    return withUnit ? `${s} 秒` : s;
  }
  const m = Math.floor(totalSec / 60);
  const s = Math.round(totalSec % 60);
  return withUnit ? `${m} 分 ${s} 秒` : `${m}:${String(s).padStart(2, '0')}`;
}

/**
 * 复制文本到剪贴板（带降级方案）。
 * 优先用 navigator.clipboard（https / localhost 可用）；
 * 不可用时降级到 textarea + execCommand，覆盖 http 旧环境。
 * @param text 待复制文本
 * @returns Promise<boolean> 是否复制成功
 */
export async function copyText(text: string): Promise<boolean> {
  const value = String(text ?? '');
  if (!value) return false;
  try {
    if (navigator.clipboard?.writeText) {
      await navigator.clipboard.writeText(value);
      return true;
    }
  } catch {
    /* 走降级方案 */
  }
  try {
    const ta = document.createElement('textarea');
    ta.value = value;
    ta.style.cssText = 'position:fixed;opacity:0;pointer-events:none';
    document.body.appendChild(ta);
    ta.select();
    const ok = document.execCommand('copy');
    document.body.removeChild(ta);
    return ok;
  } catch {
    return false;
  }
}
