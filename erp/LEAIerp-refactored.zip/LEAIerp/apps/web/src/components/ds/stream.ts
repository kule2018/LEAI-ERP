/**
 * SSE 控制帧解析。
 *
 * 服务端在正文增量中用前缀标记控制帧（与后端 agent.service 的 emit 约定一致）：
 *   [meta]xxx      本次运行的 traceId 等元信息
 *   [citations]x   引用来源（JSON 数组）
 *   [thinking]xxx  思维链
 *   [tool]xxx      工具调用提示
 *   [note]xxx      网关提示
 * 未匹配前缀的内容视为正文。
 */

export type StreamFrameType = 'text' | 'meta' | 'citations' | 'thinking' | 'tool' | 'note'

export interface StreamFrame {
  type: StreamFrameType
  /** 帧内的文本内容（控制帧通常为空） */
  text: string
  /** 控制帧的 JSON 载荷 */
  payload?: any
}

function safeJson(raw: string): any {
  try {
    return JSON.parse(raw)
  } catch {
    return null
  }
}

export function parseStreamFrame(chunk: string): StreamFrame {
  const raw = String(chunk || '')
  if (raw.startsWith('[meta]')) return { type: 'meta', text: '', payload: safeJson(raw.slice(6)) }
  if (raw.startsWith('[citations]')) return { type: 'citations', text: '', payload: safeJson(raw.slice(11)) }
  if (raw.startsWith('[thinking]')) return { type: 'thinking', text: raw.slice(10) }
  if (raw.startsWith('[tool]')) return { type: 'tool', text: raw.slice(6) }
  if (raw.startsWith('[note]')) return { type: 'note', text: raw.slice(6) }
  return { type: 'text', text: raw }
}
