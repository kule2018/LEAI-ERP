// ds/theme.ts
/**
 * 主题状态管理（明 / 暗双主题）。
 *
 * 设计要点：
 *   1) 状态是模块级单例：任何组件调用 useTheme() 拿到的都是同一份引用，
 *      侧边栏与顶栏的切换按钮天然同步，不需要 event bus；
 *   2) 落地方式：把主题写到 <html data-theme="dark|light">，theme.css 里的
 *      两套 --ds-* 变量随之切换，组件本身零改动；
 *   3) 持久化：localStorage 记住用户选择；首次访问跟随系统 prefers-color-scheme；
 *   4) 容错：隐私模式下 localStorage 读写都包了 try，失败只影响记忆不影响功能。
 */
import { ref, type App, type Ref } from 'vue';

/** 主题模式 */
export type ThemeMode = 'light' | 'dark';

/** localStorage 键名 */
const STORAGE_KEY = 'ds-theme';

/** 模块级单例：当前是否深色（所有调用方共享同一状态） */
const isDark = ref(false);

/**
 * 读取初始主题：本地记忆优先，否则跟随系统偏好。
 * @returns 'dark' | 'light'
 */
function initialMode(): ThemeMode {
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved === 'dark' || saved === 'light') return saved;
  } catch {
    /* 忽略读取失败，走系统偏好 */
  }
  if (typeof window !== 'undefined' && window.matchMedia?.('(prefers-color-scheme: dark)').matches) {
    return 'dark';
  }
  return 'light';
}

/**
 * 把当前状态同步到 <html data-theme>。
 * @returns 无
 */
function apply(): void {
  if (typeof document === 'undefined') return;
  document.documentElement.dataset.theme = isDark.value ? 'dark' : 'light';
}

// 模块加载即应用一次，避免首屏闪白（深色用户看到一瞬间白底）
isDark.value = initialMode() === 'dark';
apply();

/** useTheme 对外句柄：方法声明为属性类型（this: void 语义），解构调用不会丢失 this */
export interface ThemeHandle {
  /** 当前是否深色 */
  isDark: Ref<boolean>;
  /** 明暗互切并持久化 */
  toggleTheme: () => void;
  /** 直接指定模式 */
  setTheme: (mode: ThemeMode) => void;
}

/**
 * 主题 composable：在任意组件里解构使用。
 *
 * 用法：
 *   const { isDark, toggleTheme } = useTheme();
 *
 * @returns {{ isDark: Ref<boolean>; toggleTheme: () => void; setTheme: (m: ThemeMode) => void }}
 *   isDark 当前是否深色；toggleTheme 明暗互切；setTheme 直接指定模式
 */
export function useTheme(): ThemeHandle {
  return {
    isDark,
    /** 明暗互切并持久化 */
    toggleTheme(): void {
      isDark.value = !isDark.value;
      try {
        localStorage.setItem(STORAGE_KEY, isDark.value ? 'dark' : 'light');
      } catch {
        /* 隐私模式：不记忆但不报错 */
      }
      apply();
    },
    /**
     * 直接设置主题。
     * @param mode 目标模式
     * @returns 无
     */
    setTheme(mode: ThemeMode): void {
      isDark.value = mode === 'dark';
      try {
        localStorage.setItem(STORAGE_KEY, mode);
      } catch {
        /* 同上 */
      }
      apply();
    },
  };
}

/**
 * 组件库安装入口：引入全局样式 + 注册全部组件（全局标签形式可用）。
 *
 * 用法（main.ts）：
 *   import { createApp } from 'vue';
 *   import { installDsUi } from './components';
 *   installDsUi(createApp(App));
 *
 * 注意：本函数只做「注册」，不做路由 / 状态库假设；
 * 使用了 vue-router 的组件（DsAppShell）需要宿主应用已安装 vue-router。
 *
 * @param app Vue 应用实例
 * @returns 原 App 实例（方便链式调用）
 */
export async function installDsUi(app: App): Promise<App> {
  // 动态引入样式：让 main.ts 只需 import 一个函数即可拿到完整设计系统
  await import('./theme.css');
  const mod = await import('../index');
  mod.registerGlobalComponents(app);
  return app;
}
