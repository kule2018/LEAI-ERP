// ds/toast.ts
/**
 * 全局轻提示（Toast）状态管理。
 *
 * 设计要点：
 *   1) 模块级单例：业务组件任意位置调用 useToast().success('…') 都能推消息，
 *      容器（DsToast）由 DsAppShell 全局挂载一次；单独使用组件库时，
 *      在页面里放一个 <DsToast /> 即可；
 *   2) 自动消失：默认 3s，错误消息 5s（给人留阅读时间），支持手动移除；
 *   3) 堆叠上限：同时最多 5 条，超出挤掉最旧的，防止刷屏；
 *   4) 卸载安全：定时器句柄集中管理，避免组件销毁后回调报错。
 */
import { ref } from 'vue';

/** 提示类型 */
export type ToastType = 'success' | 'error' | 'warning' | 'info';

/** 单条提示 */
export interface ToastItem {
  /** 唯一 ID（自增） */
  id: number;
  /** 类型，决定图标与配色 */
  type: ToastType;
  /** 提示正文 */
  message: string;
  /** 停留毫秒数 */
  duration: number;
}

/** 同时最多展示几条（超出挤掉最旧） */
const MAX_ITEMS = 5;

/** 默认停留时长：错误留久一点 */
const DEFAULT_DURATION: Record<ToastType, number> = {
  success: 3000,
  error: 5000,
  warning: 4000,
  info: 3000,
};

/** 消息列表（单例，DsToast 直接渲染它） */
const items = ref<ToastItem[]>([]);

/** 自增 ID，保证 TransitionGroup 的 key 稳定唯一 */
let seq = 0;

/** 自动消失定时器表：id -> timer */
const timers = new Map<number, number>();

/**
 * 通用入队逻辑：建条目、入队、排量、设定时消失。
 * @param type 提示类型
 * @param message 提示正文
 * @param duration 停留毫秒（缺省按类型取默认值）
 * @returns 无
 */
function push(type: ToastType, message: string, duration?: number): void {
  const item: ToastItem = {
    id: ++seq,
    type,
    message: String(message ?? ''),
    duration: duration ?? DEFAULT_DURATION[type],
  };
  items.value = [...items.value, item].slice(-MAX_ITEMS);
  // 到期自动移除（duration <= 0 表示常驻，需手动点掉）
  if (item.duration > 0) {
    timers.set(
      item.id,
      window.setTimeout(() => remove(item.id), item.duration),
    );
  }
}

/**
 * 手动移除某条提示。
 * @param id 提示 ID
 * @returns 无
 */
function remove(id: number): void {
  const timer = timers.get(id);
  if (timer) {
    clearTimeout(timer);
    timers.delete(id);
  }
  items.value = items.value.filter((t) => t.id !== id);
}

/**
 * Toast composable：解构即用。
 *
 * 用法：
 *   const toast = useToast();
 *   toast.success('保存成功');
 *   toast.error('保存失败', 8000); // 自定义停留时长
 *
 * @returns {{ items: Ref<ToastItem[]>; remove: (id: number) => void; success/error/warning/info: (msg: string, duration?: number) => void }}
 */
export function useToast() {
  return {
    items,
    remove,
    /** 成功提示 */
    success: (message: string, duration?: number) => push('success', message, duration),
    /** 错误提示 */
    error: (message: string, duration?: number) => push('error', message, duration),
    /** 警告提示 */
    warning: (message: string, duration?: number) => push('warning', message, duration),
    /** 一般提示 */
    info: (message: string, duration?: number) => push('info', message, duration),
  };
}
