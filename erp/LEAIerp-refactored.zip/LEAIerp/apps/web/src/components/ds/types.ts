// src/components/ds/types.ts
/**
 * ds 组件库对外暴露的共享类型。
 *
 * 为什么要单独放一个文件：
 *   Vue 的 <script setup> 不允许出现 ES 模块导出（export），
 *   因此组件需要对外暴露的接口类型统一放这里，组件与业务页面都从本文件导入。
 */

/** 标签语义色（DsTag） */
export type TagColor = 'brand' | 'success' | 'warning' | 'danger' | 'neutral';

/** 侧边栏导航项（DsMenu / DsAppShell） */
export interface NavItem {
  /** 显示文案 */
  label: string;
  /** 路由地址（叶子节点点击跳转；父节点作为分组仅展开/收起） */
  to: string;
  /** 可选图标：SVG path 的 d，或 1~6 个字符的短文本；留空显示圆点 */
  icon?: string;
  /** 右上角徽标 */
  badge?: string | number;
  /**
   * 分组名。相同分组的导航项会连在一起，并在组首显示小标题；
   * 留空表示「主工作区」，不显示小标题。
   */
  group?: string;
  /** 子菜单项（支持多级嵌套，父节点点击展开/收起） */
  children?: NavItem[];
  /** 是否禁用 */
  disabled?: boolean;
}

/** 表格列配置（DsTable） */
export interface DsColumn {
  /** 列标题 */
  title: string;
  /** 取值字段名，支持 'a.b' 形式的嵌套路径 */
  key: string;
  /** 列宽（CSS 宽度值） */
  width?: string;
  /** 最小列宽（CSS 宽度值，默认 80px，防止内容挤压） */
  minWidth?: string;
  /** 对齐方式 */
  align?: 'left' | 'center' | 'right';
  /** 自定义单元格插槽名（true 表示启用与 key 同名的插槽） */
  slot?: boolean;
  /** 是否固定列：left 左侧冻结 / right 右侧冻结 */
  fixed?: 'left' | 'right';
  /** 是否可排序（点击表头切换 升/降/无） */
  sortable?: boolean;
  /** 取值自定义格式化（返回展示内容，优先级高于同名插槽以外的默认取值） */
  formatter?: (value: any, row: any, index: number) => any;
  /** 是否允许换行（默认 false 单行省略，长文本列可开启） */
  wrap?: boolean;
}

/** 选项卡项（DsTabs） */
export interface TabItem {
  /** 显示文案 */
  label: string;
  /** 唯一值 */
  value: string | number;
  /** 是否禁用 */
  disabled?: boolean;
  /** 右侧徽标 */
  badge?: string | number;
}

/** 树节点（DsTree / BaseTree）：字段名由 nodeKey / labelKey / childrenKey 决定 */
export interface TreeNode {
  [key: string]: any;
}

/** 懒加载回调：父节点 node 与 resolve(results) */
export type LazyLoad = (node: TreeNode, resolve: (data: TreeNode[]) => void) => void;

/**
 * 对话消息（DsChatView）。
 * 业务侧把后端返回的数据映射成这个结构即可直接渲染，
 * 无需关心气泡、思考折叠、复制等交互细节。
 */
export interface ChatMessage {
  /** 消息唯一 ID（统一用字符串，便于作为对象键使用） */
  id: string;
  /** 角色：用户 / AI */
  role: 'user' | 'assistant';
  /** 正文（支持 Markdown） */
  content: string;
  /** 思维链内容（有值则展示可折叠的「已深度思考」卡片） */
  reasoning?: string;
  /** 思考耗时（毫秒，展示为「用时 x 秒」） */
  reasoningMs?: number;
  /** 创建时间戳（毫秒） */
  createdAt?: number;
  /** 是否正在流式输出（显示打字光标、隐藏操作条） */
  streaming?: boolean;
  /** 失败原因（有值则红色提示并保留重新生成入口） */
  error?: string;
  /** 本次运行链路 ID（用于点赞/点踩反馈闭环，由 SSE 首帧下发） */
  traceId?: string;
  /** 用户对本条回答的评价：up 点赞 / down 点踩 */
  feedback?: 'up' | 'down';
  /** 引用来源：本次回答依据的知识库片段，供答案核查 */
  citations?: ChatCitation[];
}

/** 引用片段 */
export interface ChatCitation {
  /** 切片 ID */
  chunkId?: number;
  /** 文档 ID */
  documentId?: number;
  /** 文档名 */
  documentName?: string;
  /** 知识库 ID */
  kbId?: number;
  /** 相关度得分 */
  score?: number;
  /** 片段摘要 */
  snippet?: string;
}

/* ============================ 表单校验（DsForm） ============================ */

/**
 * 单条校验规则。
 *
 * 语义与常见表单库对齐：
 *   - required 判空（空串 / 空数组 / null / undefined 均视为空）
 *   - min / max 对字符串按「长度」、对数字按「大小」解释
 *   - len 精确长度（字符串或数组）
 *   - pattern 正则匹配
 *   - validator 自定义校验，返回 true / undefined 表示通过，返回字符串表示错误文案
 */
export interface FormRule {
  /** 是否必填 */
  required?: boolean;
  /** 校验失败文案（自定义 validator 未返回文案时兜底） */
  message?: string;
  /** 字符串长度下限 / 数字大小下限 */
  min?: number;
  /** 字符串长度上限 / 数字大小上限 */
  max?: number;
  /** 字符串或数组的精确长度 */
  len?: number;
  /** 正则校验 */
  pattern?: RegExp;
  /**
   * 自定义校验函数。
   * @param value 当前字段值
   * @param model 整个表单模型
   * @returns 通过返回 true 或 undefined；失败返回错误文案
   */
  validator?: (value: any, model: Record<string, any>) => boolean | string | undefined;
  /** 触发时机（当前实现统一在失焦与提交时校验，此字段仅作语义标注） */
  trigger?: 'blur' | 'change';
}

/** 表单规则集合：字段名 -> 单条或数组 */
export type FormRules = Record<string, FormRule | FormRule[]>;

/* ============================ 选项 / 条目类型 ============================ */
/**
 * 下面这些类型原本写在各自组件的 <script setup> 里，业务页面无法导入
 * （<script setup> 只能是模块私有的）。统一收拢到这里，
 * 页面可以直接 `import type { DsOption, DescItem } from '@/components'`。
 */

/** 下拉选项（DsSelect） */
export interface DsOption {
  /** 展示文案 */
  label: string;
  /** 选项值 */
  value: any;
  /** 是否禁用 */
  disabled?: boolean;
}

/** 描述项（DsDescriptions） */
export interface DescItem {
  /** 标签 */
  label: string;
  /** 取值字段名 */
  key: string;
  /** 跨列数（默认 1） */
  span?: number;
  /** 自定义格式化 */
  formatter?: (v: any) => any;
}

/** 面包屑条目（DsBreadcrumb） */
export interface CrumbItem {
  /** 文案 */
  label: string;
  /** 点击携带的值（下标或路径，由业务解释） */
  value?: any;
  /** 是否禁用点击 */
  disabled?: boolean;
}

/** 级联选项（DsCascader） */
export interface CascaderOption {
  /** 展示文案 */
  label: string;
  /** 选项值 */
  value: any;
  /** 子级（有子级视为非叶子） */
  children?: CascaderOption[];
  /** 是否禁用 */
  disabled?: boolean;
}

/** 折叠面板项（DsCollapse） */
export interface CollapseItem {
  /** 唯一值 */
  value: string;
  /** 标题 */
  label: string;
  /** 是否禁用 */
  disabled?: boolean;
}

/** 下拉菜单项（DsDropdown） */
export interface DropdownItem {
  /** 唯一命令值（点击时通过 command 事件抛出） */
  command: string | number;
  /** 文案 */
  label: string;
  /** 图标名（见 ds/icons） */
  icon?: string;
  /** 是否禁用 */
  disabled?: boolean;
  /** 是否为分隔线（忽略其他字段） */
  divider?: boolean;
  /** 是否为分组标题（不可点） */
  group?: boolean;
}

/** 步骤项（DsSteps） */
export interface StepItem {
  /** 步骤标题 */
  label: string;
  /** 步骤描述（可选小字） */
  description?: string;
}

