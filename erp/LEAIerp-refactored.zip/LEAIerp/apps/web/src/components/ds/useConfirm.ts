// ds/useConfirm.ts
/**
 * 全局确认弹窗（单例，供任意业务代码调用）。
 *
 * 用法：
 *   import { confirm } from '@/components/ds/useConfirm';
 *   if (await confirm('确认删除？', '提示')) { ... }
 *
 * 实现：模块级单例状态 + App.vue 全局挂载的 <DsConfirm /> 渲染，
 * confirm() 返回 Promise<boolean>（确定 true / 取消 false）。
 */
import { reactive } from 'vue';

/** 确认框状态（单例，供 DsConfirm 绑定） */
export const confirmState = reactive({
  visible: false,
  title: '提示',
  message: '',
  /** 待定的 Promise resolve（打开时暂存，关闭时调用） */
  _resolve: null as ((ok: boolean) => void) | null,
});

/**
 * 弹出确认框并等待用户选择。
 * @param message 确认文案
 * @param title 标题（默认「提示」）
 * @returns 用户点了「确定」返回 true，「取消」/关闭返回 false
 */
export function confirm(message: string, title = '提示'): Promise<boolean> {
  confirmState.message = message;
  confirmState.title = title;
  confirmState.visible = true;
  return new Promise<boolean>((resolve) => {
    confirmState._resolve = resolve;
  });
}

/** 关闭确认框并回传结果（供 DsConfirm 调用） */
export function resolveConfirm(ok: boolean): void {
  confirmState.visible = false;
  confirmState._resolve?.(ok);
  confirmState._resolve = null;
}
