// ds/useLoading.ts
/**
 * 加载态 composable：把「布尔开关 + 异步函数包装」压缩成一行。
 *
 * 用法：
 *   const { loading, withLoading } = useLoading();
 *   const res = await withLoading(() => fetch('/api/list'));
 * withLoading 在执行期间自动置 true，结束后置 false（异常也置回，不会卡在加载中）。
 */
import { ref } from 'vue';

/**
 * 创建一组加载态状态。
 * @returns {{ loading: Ref<boolean>; withLoading: <T>(fn: () => Promise<T>) => Promise<T> }}
 *   loading 加载标记（可直接绑给任意需要加载态的 UI）；
 *   withLoading 包装异步函数，自动管理 loading
 */
export function useLoading() {
  /** 是否加载中 */
  const loading = ref(false);

  /**
   * 用加载态包裹一个异步任务。
   * @param fn 返回 Promise 的任务函数
   * @returns Promise<T> 原任务的返回值（透传结果与异常）
   */
  async function withLoading<T>(fn: () => Promise<T>): Promise<T> {
    loading.value = true;
    try {
      return await fn();
    } finally {
      // finally 保证：任务抛错时 loading 也能归位，避免界面永久转圈
      loading.value = false;
    }
  }

  return { loading, withLoading };
}
