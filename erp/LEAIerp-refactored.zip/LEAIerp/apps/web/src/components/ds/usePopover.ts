// ds/usePopover.ts
/**
 * 浮层 composable：下拉 / 弹层类组件（DsSelect、DsCascader、DsDatePicker 等）
 * 共用的一套「开合状态 + 外部点击关闭 + ESC 关闭」逻辑。
 *
 * 用法：
 *   const { open, rootRef, toggle, close } = usePopover();
 *   <div ref="rootRef"><button @click="toggle">…</button><div v-if="open">…</div></div>
 *
 * 注意：rootRef 必须绑到「触发器 + 浮层」的共同外层容器上，
 * 这样点击浮层内部不会误判为外部点击。
 */
import { ref, onMounted, onBeforeUnmount } from 'vue';

/**
 * 创建浮层控制状态。
 * @returns {{ open: Ref<boolean>; rootRef: Ref<HTMLElement | undefined>; toggle: () => void; close: () => void }}
 */
export function usePopover() {
  /** 浮层是否展开 */
  const open = ref(false);
  /** 外层容器引用（判断外部点击用） */
  const rootRef = ref<HTMLElement>();

  /** 切换展开 / 收起 */
  function toggle(): void {
    open.value = !open.value;
  }

  /** 强制收起 */
  function close(): void {
    open.value = false;
  }

  /**
   * 文档级点击监听：点在容器外则收起。
   * @param e 鼠标事件
   * @returns 无
   */
  function onDocClick(e: MouseEvent): void {
    if (!open.value) return;
    const el = rootRef.value;
    if (el && !el.contains(e.target as Node)) close();
  }

  /**
   * 文档级键盘监听：ESC 收起。
   * @param e 键盘事件
   * @returns 无
   */
  function onDocKey(e: KeyboardEvent): void {
    if (e.key === 'Escape') close();
  }

  // 挂载期间监听；卸载必须移除，否则内存泄漏 + 幽灵关闭
  onMounted(() => {
    document.addEventListener('click', onDocClick);
    document.addEventListener('keydown', onDocKey);
  });
  onBeforeUnmount(() => {
    document.removeEventListener('click', onDocClick);
    document.removeEventListener('keydown', onDocKey);
  });

  return { open, rootRef, toggle, close };
}
