// ds/usePrompt.ts
/** 全局输入弹窗单例：替代原生 window.prompt，样式与 Ds 设计系统一致。 */
import { reactive } from 'vue';

export const promptState = reactive({
  visible: false,
  title: '请输入',
  message: '',
  value: '',
  placeholder: '',
  _resolve: null as ((value: string | null) => void) | null,
});

/** 弹出输入框；确定返回文本，取消返回 null */
export function prompt(message: string, defaultValue = '', title = '请输入', placeholder = ''): Promise<string | null> {
  promptState.title = title;
  promptState.message = message;
  promptState.value = defaultValue;
  promptState.placeholder = placeholder;
  promptState.visible = true;
  return new Promise((resolve) => { promptState._resolve = resolve; });
}

export function resolvePrompt(value: string | null): void {
  promptState.visible = false;
  promptState._resolve?.(value);
  promptState._resolve = null;
}
