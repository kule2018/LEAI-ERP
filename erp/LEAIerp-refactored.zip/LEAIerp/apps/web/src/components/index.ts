// src/components/index.ts
/**
 * 组件库统一入口。
 *
 * 内容分两部分：
 *   1) ds/  —— DeepSeek UI 设计系统组件（Ds 前缀，通用 UI 积木）；
 *   2) 根目录 —— 业务组件（Base* 系列，基于 ds 设计系统重新实现）。
 *
 * 使用方式（main.ts）：
 *   import { createApp } from 'vue';
 *   import { installDsUi } from './components';
 *   installDsUi(createApp(App));
 *
 * 或者按需引入：
 *   import { DsButton, BaseForm } from './components';
 */
import type { App } from "vue";
// 全局样式：设计令牌 + 基础控件 + 工具类（明暗双主题）
import "./ds/theme.css";
// 表单排版系统：标签字号、字段间距、筛选栏/表头/弹窗栅格（全站唯一来源）
import "./ds/form.css";

/* ============================ ds 设计系统组件 ============================ */
import DsAppShell from "./ds/DsAppShell.vue";
import DsAlert from "./ds/DsAlert.vue";
import DsAvatar from "./ds/DsAvatar.vue";
import DsBadge from "./ds/DsBadge.vue";
import DsBreadcrumb from "./ds/DsBreadcrumb.vue";
import DsButton from "./ds/DsButton.vue";
import DsCard from "./ds/DsCard.vue";
import DsCascader from "./ds/DsCascader.vue";
import DsChatView from "./ds/DsChatView.vue";
import DsCheckbox from "./ds/DsCheckbox.vue";
import DsCollapse from "./ds/DsCollapse.vue";
import DsCollapseItem from "./ds/DsCollapseItem.vue";
import DsComposer from "./ds/DsComposer.vue";
import DsConfirm from "./ds/DsConfirm.vue";
import DsDatePicker from "./ds/DsDatePicker.vue";
import DsDescriptions from "./ds/DsDescriptions.vue";
import DsDivider from "./ds/DsDivider.vue";
import DsDrawer from "./ds/DsDrawer.vue";
import DsDropdown from "./ds/DsDropdown.vue";
import DsEmpty from "./ds/DsEmpty.vue";
import DsField from "./ds/DsField.vue";
import DsForm from "./ds/DsForm.vue";
import DsFormItem from "./ds/DsFormItem.vue";
import DsImage from "./ds/DsImage.vue";
import DsInput from "./ds/DsInput.vue";
import DsInputNumber from "./ds/DsInputNumber.vue";
import DsLoading from "./ds/DsLoading.vue";
import DsMarkdown from "./ds/DsMarkdown.vue";
import DsMenu from "./ds/DsMenu.vue";
import DsModal from "./ds/DsModal.vue";
import DsPagination from "./ds/DsPagination.vue";
import DsPopover from "./ds/DsPopover.vue";
import DsProgress from "./ds/DsProgress.vue";
import DsRadio from "./ds/DsRadio.vue";
import DsRate from "./ds/DsRate.vue";
import DsResult from "./ds/DsResult.vue";
import DsSegmented from "./ds/DsSegmented.vue";
import DsSelect from "./ds/DsSelect.vue";
import DsSkeleton from "./ds/DsSkeleton.vue";
import DsSlider from "./ds/DsSlider.vue";
import DsSpinner from "./ds/DsSpinner.vue";
import DsStatCard from "./ds/DsStatCard.vue";
import DsSteps from "./ds/DsSteps.vue";
import DsSwitch from "./ds/DsSwitch.vue";
import DsTable from "./ds/DsTable.vue";
import DsTabs from "./ds/DsTabs.vue";
import DsTag from "./ds/DsTag.vue";
import DsToast from "./ds/DsToast.vue";
import DsTooltip from "./ds/DsTooltip.vue";
import DsTree from "./ds/DsTree.vue";
import DsTreeSelect from "./ds/DsTreeSelect.vue";
import DsUploader from "./ds/DsUploader.vue";

/* ============================ 业务组件（根目录） ============================ */
import AsyncState from "./AsyncState.vue";
import ErrorBoundary from "./ErrorBoundary.vue";
import ChunkedUpload from "./ChunkedUpload.vue";
import BaseDialog from "./BaseDialog.vue";
import BaseDrawer from "./BaseDrawer.vue";
import BaseForm from "./BaseForm.vue";
import BaseGrid from "./BaseGrid.vue";
import BaseSelect from "./BaseSelect.vue";
import BaseTable from "./BaseTable.vue";
import BaseTree from "./BaseTree.vue";
import BaseUpload from "./BaseUpload.vue";
import DetailDrawer from "./DetailDrawer.vue";
import EmptyState from "./EmptyState.vue";
import IconButton from "./IconButton.vue";
import IconFont from "./IconFont.vue";
import Panel from "./Panel.vue";
import ParentView from "./ParentView.vue";
import PhotoToVideo from "./PhotoToVideo.vue";
import QueryDrawer from "./QueryDrawer.vue";
import StatCard from "./StatCard.vue";
import Tbar from "./Tbar.vue";
import TopSearch from "./TopSearch.vue";
import FirstGuide from "./FirstGuide.vue";
import SignaturePad from "./SignaturePad.vue";
import DocumentComments from "./DocumentComments.vue";
import VirtualTable from "./VirtualTable.vue";
import ViewConfigDrawer from "./ViewConfigDrawer.vue";
import BatchResultDialog from "./BatchResultDialog.vue";

/** ds 设计系统组件清单（name -> component） */
const DS_COMPONENTS: Record<string, any> = {
  DsAppShell, DsAlert, DsAvatar, DsBadge, DsBreadcrumb, DsButton, DsCard, DsCascader,
  DsChatView, DsCheckbox, DsCollapse, DsCollapseItem, DsComposer, DsConfirm, DsDatePicker,
  DsDescriptions, DsDivider, DsDrawer, DsDropdown, DsEmpty, DsField, DsForm, DsFormItem,
  DsImage, DsInput, DsInputNumber, DsLoading, DsMarkdown, DsMenu, DsModal, DsPagination,
  DsPopover, DsProgress, DsRadio, DsRate, DsResult, DsSegmented, DsSelect, DsSkeleton,
  DsSlider, DsSpinner, DsStatCard, DsSteps, DsSwitch, DsTable, DsTabs, DsTag, DsToast,
  DsTooltip, DsTree, DsTreeSelect, DsUploader,
};

/** 业务组件清单（name -> component） */
const BASE_COMPONENTS: Record<string, any> = {
  AsyncState, ErrorBoundary, ChunkedUpload, BaseDialog, BaseDrawer, BaseForm, BaseGrid, BaseSelect, BaseTable, BaseTree,
  BaseUpload, DetailDrawer, EmptyState, IconButton, IconFont, Panel, ParentView,
  PhotoToVideo, QueryDrawer, StatCard, Tbar, TopSearch,
  FirstGuide, SignaturePad, DocumentComments, VirtualTable, ViewConfigDrawer, BatchResultDialog,
};

/**
 * 全局业务组件注册（课程第 7 章）。
 * 在 main.ts 中调用一次，组件即可在任意页面以标签形式使用。
 *
 * @param app Vue 应用实例
 * @returns 无
 */
export function registerGlobalComponents(app: App): void {
  // ds 设计系统：DsXxx 全局标签
  for (const [name, comp] of Object.entries(DS_COMPONENTS)) {
    app.component(name, comp);
  }
  // 业务组件：原标签名
  for (const [name, comp] of Object.entries(BASE_COMPONENTS)) {
    app.component(name, comp);
  }
}

/**
 * 组件库一键安装（registerGlobalComponents 的别名，语义更清晰）。
 * @param app Vue 应用实例
 * @returns 无
 */
export function installDsUi(app: App): void {
  registerGlobalComponents(app);
}

export {
  // ds 设计系统
  DsAppShell, DsAlert, DsAvatar, DsBadge, DsBreadcrumb, DsButton, DsCard, DsCascader,
  DsChatView, DsCheckbox, DsCollapse, DsCollapseItem, DsComposer, DsConfirm, DsDatePicker,
  DsDescriptions, DsDivider, DsDrawer, DsDropdown, DsEmpty, DsField, DsForm, DsFormItem,
  DsImage, DsInput, DsInputNumber, DsLoading, DsMarkdown, DsMenu, DsModal, DsPagination,
  DsPopover, DsProgress, DsRadio, DsRate, DsResult, DsSegmented, DsSelect, DsSkeleton,
  DsSlider, DsSpinner, DsStatCard, DsSteps, DsSwitch, DsTable, DsTabs, DsTag, DsToast,
  DsTooltip, DsTree, DsTreeSelect, DsUploader,
  // 业务组件
  AsyncState, ErrorBoundary, ChunkedUpload, BaseDialog, BaseDrawer, BaseForm, BaseGrid, BaseSelect, BaseTable, BaseTree,
  BaseUpload, DetailDrawer, EmptyState, IconButton, IconFont, Panel, ParentView,
  PhotoToVideo, QueryDrawer, StatCard, Tbar, TopSearch,
  FirstGuide, SignaturePad, DocumentComments, VirtualTable, ViewConfigDrawer, BatchResultDialog,
};

// 主题与工具（useTheme / useToast / installDsUi 的完整版）
export { useTheme, installDsUi as installDsUiWithTheme } from "./ds/theme";
export { useToast } from "./ds/toast";
export { confirm } from "./ds/useConfirm";
export { formatBytes, formatDuration, copyText } from "./ds/format";
export { renderMarkdown, inFence } from "./ds/markdown";
export { DS_ICONS, getIcon } from "./ds/icons";

// 共享类型
export type * from "./types";
export type * from "./ds/types";
