// src/components/types.ts
/**
 * 根目录业务组件（BaseForm / BaseGrid / BaseTable / BaseSelect 等）的共享类型。
 *
 * 为什么要单独放一个文件：Vue 的 <script setup> 不允许出现 ES 模块导出（export），
 * 组件需要对外暴露的接口类型统一放这里，业务页面与组件之间都从本文件导入。
 */

/** 下拉选项（BaseSelect / DsSelect） */
export interface SelectOption {
  /** 展示文案 */
  label: string;
  /** 选项值 */
  value: any;
  /** 是否禁用 */
  disabled?: boolean;
}

/** 表单项配置（BaseForm） */
export interface FormField {
  /** 字段名（数据模型的键） */
  prop: string;
  /** 标签文案 */
  label: string;
  /** 控件类型 */
  type?:
    | 'input'
    | 'number'
    | 'textarea'
    | 'select'
    | 'remote-select'
    | 'radio'
    | 'checkbox'
    | 'cascader'
    | 'tree-select'
    | 'switch'
    | 'rate'
    | 'slider'
    | 'date'
    | 'datetime'
    | 'time'
    | 'upload';
  /** 占位文案 */
  placeholder?: string;
  /** 是否单独禁用（叠加在 readonly 之上） */
  disabled?: boolean;
  /** 栅格宽度，默认 24（满分） */
  span?: number;
  /** 是否必填（触发内置校验） */
  required?: boolean;
  /** 字段级帮助文案：渲染在控件下方 */
  hint?: string;
  /** 选项：select / radio / checkbox / cascader / tree-select */
  options?: { label: string; value: any; children?: any[] }[];
  /** remote-select 专用：传入关键字返回选项数组 */
  fetch?: (keyword: string) => Promise<SelectOption[]>;
  /** remote-select 专用：是否多选 */
  multiple?: boolean;
}

/** 列配置（BaseGrid） */
export interface GridColumn {
  /** 取值字段名 */
  prop: string;
  /** 列标题 */
  label: string;
  /** 列宽 */
  width?: number | string;
  /** 最小列宽 */
  minWidth?: number | string;
  /** 单元格格式化函数 */
  formatter?: (row: any) => string;
  /** 是否允许客户端排序（true=客户端排序；'custom'=服务端排序，配合 serverSort） */
  sortable?: boolean | 'custom';
  /** 内容超出是否显示省略（默认 true） */
  showOverflowTooltip?: boolean;
}

/** 列配置（BaseTable，在 GridColumn 之上新增 fixed / align） */
export interface TableColumn extends GridColumn {
  /** 固定列：left / right / true */
  fixed?: 'left' | 'right' | boolean;
  /** 对齐方式 */
  align?: 'left' | 'center' | 'right';
}

/** 详情字段配置（DetailDrawer） */
export interface DetailItem {
  /** 显示名 */
  label: string;
  /** 取值路径 */
  prop: string;
  /** 跨列数 */
  span?: number;
  /** 自定义格式化 */
  formatter?: (v: any) => any;
}

/** 拍照讲解任务（PhotoToVideo 对接后端的数据结构） */
export interface PhotoVideoTask {
  /** 任务 ID */
  id: number | string;
  /** 当前阶段（见 PhotoToVideo 的 STAGES） */
  stage: string;
  /** 任务状态 */
  status: string;
  /** 进度 0~100 */
  progress: number;
  /** 失败原因 */
  errMsg?: string;
  /** 成片地址 */
  videoUrl?: string;
  /** 封面地址 */
  coverUrl?: string;
  /** 成片时长（毫秒） */
  durationMs?: number;
}

/** 分镜脚本（PhotoToVideo） */
export interface PhotoVideoScene {
  /** 分镜 ID */
  id: number | string;
  /** 分镜类型 */
  sceneType: string;
  /** 旁白文案 */
  narration: string;
  /** 时长（毫秒） */
  durationMs: number;
}
