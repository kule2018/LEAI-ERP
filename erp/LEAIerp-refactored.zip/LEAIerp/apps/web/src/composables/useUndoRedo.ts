/**
 * 撤销 / 重做（文档第 24 章：本地操作栈 30 步 + 服务端 revision 快照）。
 * ---------------------------------------------------------------------------
 * 采用"调用方持有数据、本模块只存快照"的设计：
 *   - record(当前值)：变更前调用，把当前值压入过去栈；
 *   - undo(当前值)：把当前值压入未来栈，返回上一个快照给调用方恢复；
 *   - redo(当前值)：反向操作。
 * 这样既能用于 reactive 表单，也能用于普通 ref，不需要劫持数据本身。
 */
import { ref } from 'vue';

/** 默认保留步数 */
const DEFAULT_LIMIT = 30;

/** 深拷贝快照，避免快照与表单共享引用 */
function clone<T>(value: T): T {
  return JSON.parse(JSON.stringify(value));
}

/**
 * 创建撤销/重做栈。
 * @param limit 最多保留多少步，默认 30
 * @returns 栈操作方法
 */
export function useUndoRedo<T = any>(limit: number = DEFAULT_LIMIT) {
  // 用 any[] 规避 Vue 深层响应式对泛型 T 的 UnwrapRef 约束，外部接口仍保持 T
  const past = ref<any[]>([]);
  const future = ref<any[]>([]);

  /** 有可撤销步骤 */
  const canUndo = () => past.value.length > 0;
  /** 有可重做步骤 */
  const canRedo = () => future.value.length > 0;

  /**
   * 记录一个变更前快照，同时清空重做栈。
   * @param snapshot 当前数据
   * @returns 无
   */
  function record(snapshot: T): void {
    past.value.push(clone(snapshot));
    if (past.value.length > limit) past.value.shift();
    future.value = [];
  }

  /**
   * 撤销：返回上一快照。
   * @param current 当前数据（会被压入重做栈）
   * @returns 上一快照；没有可撤销步骤时返回 null
   */
  function undo(current: T): T | null {
    if (!past.value.length) return null;
    future.value.push(clone(current));
    return past.value.pop()!;
  }

  /**
   * 重做：返回下一快照。
   * @param current 当前数据（会被压入撤销栈）
   * @returns 下一快照；没有可重做步骤时返回 null
   */
  function redo(current: T): T | null {
    if (!future.value.length) return null;
    past.value.push(clone(current));
    return future.value.pop()!;
  }

  /** 清空全部历史（切换单据时调用） */
  function clear(): void {
    past.value = [];
    future.value = [];
  }

  return { past, future, canUndo, canRedo, record, undo, redo, clear, limit };
}
