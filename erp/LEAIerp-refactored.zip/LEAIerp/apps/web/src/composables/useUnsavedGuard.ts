/**
 * 未保存提醒 + 本地草稿自动保存（文档第 24 章）。
 * ---------------------------------------------------------------------------
 * 两个能力合在一起：
 *   1. 表单变脏后，离开页面/关闭浏览器时拦截并提示；
 *   2. 每 30 秒把草稿写入 localStorage，页面刷新后可恢复。
 * 组件卸载时务必清理定时器与事件监听，避免内存泄漏。
 */
import { onBeforeUnmount, onMounted, type Ref } from 'vue';

/** 草稿存储前缀 */
const DRAFT_PREFIX = 'erp_draft_';

/**
 * 注册未保存保护。
 * @param getDraft 返回当前草稿内容的函数
 * @param key 草稿标识，建议用路由路径或单据 ID
 * @param dirty 是否变脏的响应式标记
 * @param onRestore 恢复草稿时的回调（由页面决定如何写回表单）
 * @returns 手动清理草稿与读取草稿的方法
 */
export function useUnsavedGuard(
  getDraft: () => any,
  key: string,
  dirty: Ref<boolean>,
  onRestore?: (draft: any) => void,
) {
  /** 完整存储键 */
  const storageKey = DRAFT_PREFIX + key;
  let timer: number | undefined;

  /** 把草稿写入 localStorage */
  function saveDraft(): void {
    if (!dirty.value) return;
    try { localStorage.setItem(storageKey, JSON.stringify({ at: Date.now(), data: getDraft() })); }
    catch { /* 存储空间不足时静默失败，不影响编辑 */ }
  }

  /** 浏览器关闭/刷新拦截 */
  function onBeforeUnload(event: BeforeUnloadEvent): void {
    if (!dirty.value) return;
    event.preventDefault();
    event.returnValue = '';
  }

  /** 读取已保存草稿 */
  function loadDraft(): any | null {
    try {
      const raw = localStorage.getItem(storageKey);
      if (!raw) return null;
      const parsed = JSON.parse(raw);
      // 超过 7 天的草稿视为过期
      if (Date.now() - parsed.at > 7 * 24 * 3600 * 1000) { clearDraft(); return null; }
      return parsed.data;
    } catch { return null; }
  }

  /** 清除草稿（保存成功后调用） */
  function clearDraft(): void { localStorage.removeItem(storageKey); }

  onMounted(() => {
    timer = window.setInterval(saveDraft, 30_000);
    window.addEventListener('beforeunload', onBeforeUnload);
    const draft = loadDraft();
    if (draft && onRestore) onRestore(draft);
  });

  onBeforeUnmount(() => {
    if (timer) window.clearInterval(timer);
    window.removeEventListener('beforeunload', onBeforeUnload);
    saveDraft();
  });

  return { saveDraft, loadDraft, clearDraft };
}
