/**
 * 业务引擎注册表（Business Engine Registry）
 * ---------------------------------------------------------------------------
 * 目的：把《ERP完整产品与技术文档》要求的「状态机 + 业务动作 + 跨单据联动 +
 *      方案设置 + 审计留痕」做成一份声明式配置，供两处共同消费：
 *        1) web/src/views/generic/BusinessPage.vue：渲染真实功能页；
 *        2) web/src/api/mockAdapter.ts：在 Mock 层真正执行动作与联动。
 *
 * 设计原则：
 *   - 纯数据 + 纯函数，不 import 任何组件或 mockAdapter，避免循环依赖；
 *   - 分类（category）由集合名/接口/标题关键字推断，126 个页面无需逐个维护；
 *   - 状态机由页面已有 status 列的下拉选项推导，天然贴合各页真实状态文案；
 *   - 副作用按集合名关键字匹配处理器（库存/凭证/收付款/考勤等），便于扩展。
 */

/** 页面业务分类 */
export type BizCategory = 'doc' | 'master' | 'report' | 'log' | 'setting';

/** 一种状态机动作 */
export interface BizAction {
  /** 动作标识：submit/approve/reject/confirm/execute/void/toggle/print/copy */
  key: string;
  /** 按钮文案 */
  label: string;
  /** 允许触发的当前状态（字符串化比较）；为空表示任意状态 */
  from: string[];
  /** 执行后的目标状态；为空表示不变更状态 */
  to?: string;
  /** 按钮风格 */
  variant?: 'primary' | 'danger' | 'warning' | 'default';
  /** 是否需要二次确认 */
  confirm?: boolean;
  /** 是否触发后端副作用（库存/凭证/通知/审计） */
  effect?: boolean;
}

/** 由列配置推导出的状态元数据 */
export interface StatusMeta {
  /** 状态字段名 */
  field: string;
  /** 值 -> 文案 */
  labels: Record<string, string>;
}

/** 单个业务流的完整配置 */
export interface BizFlow {
  collection: string;
  category: BizCategory;
  title: string;
  status: StatusMeta | null;
  actions: BizAction[];
  /** 方案设置（可在页面「业务方案」抽屉里调整，并真实影响联动） */
  scheme: Array<{ key: string; label: string; value: any; type: 'number' | 'text' | 'switch'; hint?: string }>;
  /** 页面业务说明：由模块专属注册表提供，用于区分各页面的业务定位 */
  purpose?: string;
  /** 覆盖默认推断的副作用列表 */
  effects?: string[];
  /** 触发过账/凭证的动作键 */
  postingActions?: string[];
}

/** 三大模块的专属业务流（财务/协同/人事，按集合名索引） */
import { MODULE_FLOWS } from './moduleFlows';

/* -------------------------------------------------------------------------- */
/*                              分类推断                                       */
/* -------------------------------------------------------------------------- */

/** 报表/分析类关键字：只读取数 + 导出 + 打印 */
const REPORT_WORDS = /report|aging|turnover|aging|cost|capacity|profit|trial|balance|analysis|statistic|summary|账龄|周转|库龄|成本|产能|毛利|报表|汇总|分析|余额|流水|明细|追踪|看板/i;
/** 日志/只读类关键字 */
const LOG_WORDS = /log|audit|record|trace|event|日志|审计|记录|事件|流水/i;
/** 设置类关键字 */
const SETTING_WORDS = /config|setting|dict|sequence|nos|rule|job|scheme|template|参数|设置|字典|编码|编号|规则|任务|方案|模板|视图|字段|权限/i;
/** 单据类关键字：有状态流转 + 过账联动 */
const DOC_WORDS = /order|leave|expense|income|payment|transfer|adjust|stocktake|transfer|issue|return|finish|qc|quotation|contract|receipt|ship|pick|wave|putaway|crossdock|bill|voucher| payroll|请假|费用|收入|收款|付款|调拨|调整|盘点|领料|退料|完工|质检|报价|合同|入库|出库|出货|收货|退货|换货|拣货|波次|上架|单据|凭证|工资|账单/i;

/**
 * 推断页面业务分类。
 * @param collection 集合名（如 hrLeaves）
 * @param api 接口路径（如 /api/v1/hr/leaves）
 * @param title 页面标题
 * @returns 业务分类
 */
export function inferCategory(collection: string, api = '', title = ''): BizCategory {
  const s = `${collection} ${api} ${title}`;
  if (REPORT_WORDS.test(s)) return 'report';
  if (LOG_WORDS.test(s)) return 'log';
  if (SETTING_WORDS.test(s)) return 'setting';
  if (DOC_WORDS.test(s)) return 'doc';
  return 'master';
}

/* -------------------------------------------------------------------------- */
/*                              状态机推导                                     */
/* -------------------------------------------------------------------------- */

/** 从列定义中找出状态字段（prop=status / state / isActive 且有 options） */
export function inferStatusMeta(columns: any[] = []): StatusMeta | null {
  const statusCol = columns.find((c: any) => {
    if (!c || !c.prop) return false;
    if (c.options?.length) return /status|state|状态|阶段|stage/i.test(c.prop + c.label);
    return false;
  });
  if (!statusCol) return null;
  const labels: Record<string, string> = {};
  for (const o of statusCol.options) labels[String(o.value)] = String(o.label);
  return { field: statusCol.prop, labels };
}

/** 规范化状态：把中文文案映射到规范状态 */
export function canonicalState(label: string): string {
  const s = String(label || '');
  if (/草稿|新建|新建|待提交|draft/i.test(s)) return 'draft';
  if (/待审|待核|待审|提交|pending|submitted|待处理/i.test(s)) return 'pending';
  if (/通过|已确认|已审|批准|approved|confirmed|同意/i.test(s)) return 'approved';
  if (/驳回|拒绝|reject|不通过/i.test(s)) return 'rejected';
  if (/完成|已完成|生效|done|finished|结束/i.test(s)) return 'done';
  if (/作废|取消|关闭|终止|void|cancel|停用|禁用/i.test(s)) return 'void';
  return 'other';
}

/**
 * 根据状态文案推导通用单据状态机动作。
 * @param status 状态元数据
 * @returns 动作数组（含 from/to 守卫）
 */
export function docActions(status: StatusMeta | null): BizAction[] {
  const labels = status?.labels || {};
  const find = (canon: string) => Object.keys(labels).find((k) => canonicalState(labels[k]) === canon);
  const draft = find('draft');
  const pending = find('pending');
  const approved = find('approved');
  const done = find('done');
  const voided = find('void');
  const acts: BizAction[] = [];
  if (draft !== undefined && pending !== undefined) {
    acts.push({ key: 'submit', label: '提交审批', from: [String(draft)], to: String(pending), variant: 'primary', confirm: true, effect: true });
  }
  if (pending !== undefined && approved !== undefined) {
    acts.push({ key: 'approve', label: '审批通过', from: [String(pending)], to: String(approved), variant: 'primary', confirm: true, effect: true });
  }
  if (pending !== undefined) {
    acts.push({ key: 'reject', label: '驳回', from: [String(pending)], to: find('rejected') ?? voided ?? pending, variant: 'danger', confirm: true, effect: true });
  }
  if (approved !== undefined && done !== undefined) {
    acts.push({ key: 'execute', label: '执行/过账', from: [String(approved)], to: String(done), variant: 'primary', confirm: true, effect: true });
  } else if (approved !== undefined) {
    acts.push({ key: 'execute', label: '确认生效', from: [String(approved)], variant: 'primary', confirm: true, effect: true });
  }
  if (voided !== undefined) {
    acts.push({ key: 'void', label: '作废', from: [String(draft), String(pending), String(done), ''].filter((v, i, a) => a.indexOf(v) === i), to: String(voided), variant: 'danger', confirm: true, effect: true });
  }
  return acts;
}

/** 主数据：启用 / 停用（toggle） */
const MASTER_ACTIONS: BizAction[] = [
  { key: 'toggle', label: '停用', from: ['1', 'true', '启用', '正常', '是'], to: '0', variant: 'warning', confirm: true, effect: true },
  { key: 'enable', label: '启用', from: ['0', 'false', '停用', '禁用', '否'], to: '1', variant: 'primary', confirm: false, effect: true },
  { key: 'copy', label: '复制', from: [], variant: 'default', effect: false },
];

/** 报表：导出 + 打印 + 刷新（无状态） */
const REPORT_ACTIONS: BizAction[] = [
  { key: 'export', label: '导出', from: [], effect: false },
  { key: 'print', label: '打印', from: [], effect: false },
  { key: 'refresh', label: '刷新数据', from: [], effect: false },
];

/** 日志：查看 + 导出 */
const LOG_ACTIONS: BizAction[] = [
  { key: 'detail', label: '查看', from: [], effect: false },
  { key: 'export', label: '导出', from: [], effect: false },
];

/** 设置：保存方案 + 试算 + 生效 */
const SETTING_ACTIONS: BizAction[] = [
  { key: 'apply', label: '保存并生效', from: [], variant: 'primary', confirm: true, effect: true },
  { key: 'test', label: '试算/校验', from: [], effect: false },
];

/* -------------------------------------------------------------------------- */
/*                              方案设置                                       */
/* -------------------------------------------------------------------------- */

/** 通用方案项（影响联动的真实参数） */
function schemeFor(category: BizCategory): BizFlow['scheme'] {
  const base: BizFlow['scheme'] = [
    { key: 'approvalAmount', label: '审批触发金额', value: 10000, type: 'number', hint: '单据金额超过该值生成总监审批待办' },
    { key: 'autoPost', label: '自动过账', value: 1, type: 'switch', hint: '执行动作时自动生成凭证/库存流水' },
    { key: 'notifyOnAction', label: '动作后通知', value: 1, type: 'switch', hint: '状态流转后写入通知中心' },
  ];
  if (category === 'doc') return base;
  if (category === 'setting') return [{ key: 'effective', label: '方案立即生效', value: 1, type: 'switch' }, ...base];
  return base.slice(1);
}

/* -------------------------------------------------------------------------- */
/*                              流配置入口                                     */
/* -------------------------------------------------------------------------- */

/**
 * 构建一个业务流配置。
 * @param collection 集合名
 * @param title 页面标题
 * @param api 接口路径
 * @param columns 页面列定义（用于推导状态机）
 * @returns 业务流配置
 */
export function buildFlow(collection: string, title: string, api: string, columns: any[] = [], flowKey = ''): BizFlow {
  const status = inferStatusMeta(columns);
  // 优先使用模块专属业务流：财务/协同/人事的每个页面都有独立动作与副作用，
  // 不能靠集合名关键字推断，否则会全部退化成同一套通用审批/启停动作。
  const custom = MODULE_FLOWS[flowKey || collection];
  if (custom) {
    return {
      collection,
      category: custom.category,
      title,
      status,
      actions: custom.actions,
      scheme: custom.scheme || schemeFor(custom.category),
      purpose: custom.purpose,
      effects: custom.effects,
      postingActions: custom.postingActions,
    };
  }
  const category = inferCategory(collection, api, title);
  let actions: BizAction[];
  switch (category) {
    case 'doc': actions = docActions(status); if (!actions.length) actions = docActions({ field: 'status', labels: { '0': '草稿', '1': '待审核', '2': '已确认', '4': '已完成', '9': '已作废' } }); break;
    case 'setting': actions = SETTING_ACTIONS; break;
    case 'report': actions = REPORT_ACTIONS; break;
    case 'log': actions = LOG_ACTIONS; break;
    default: actions = MASTER_ACTIONS;
  }
  return { collection, category, title, status, actions, scheme: schemeFor(category) };
}

/**
 * 副作用类型：由集合名关键字决定执行哪种跨单据联动。
 * @param collection 集合名
 * @returns 副作用标识数组
 */
export function sideEffectsFor(collection: string): string[] {
  const c = collection.toLowerCase();
  const effects: string[] = [];
  if (/adjust|stocktake|transfer|receipt|inventoryout|pick|issue|finish|assembly|return|crossdock|putaway/.test(c)) effects.push('stock');
  if (/expense|income|payment|voucher|transfer|cost|depreciation|payroll/.test(c)) effects.push('voucher');
  if (/receivable|paymentin/.test(c)) effects.push('receivable');
  if (/payable|paymentout/.test(c)) effects.push('payable');
  if (/leave|attendance|payroll/.test(c)) effects.push('attendance');
  return effects;
}
