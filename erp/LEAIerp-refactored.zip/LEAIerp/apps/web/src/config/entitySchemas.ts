/**
 * 业务实体 Schema 注册表
 * ---------------------------------------------------------------------------
 * 目的：让每一个「通用实体页」(EntityPage.vue) 不再显示千篇一律的
 *       "演示数据 1/2/3"，而是按《ERP完整产品与技术文档》定义的真实业务
 *       字段、中文标签与真实种子数据渲染。
 *
 * 设计：
 *   - collection：api 路径经 collectionOf() 推导出的集合名（handleMock 的 key）；
 *   - label：菜单/实体中文名；
 *   - fields：字段定义（prop / label / type / 选项 / 是否表单字段）；
 *   - seed：符合业务语义的真实种子数据；
 *   - statusField / statusLabels：状态字段与文案。
 *
 * 使用方：
 *   1) mockAdapter.handleMock 的兜底分支优先读取本表生成真实种子；
 *   2) EntityPage 首屏优先用本表的 fields 渲染列与表单。
 */

// 业务域真实字段覆盖层：把早期占位集合（仅名称/编码/说明/状态）替换为真实业务模型。
// 覆盖文件按域拆分，便于维护；合并后 ENTITY_SCHEMAS 即为唯一权威来源。
import { financeOverrides } from './schemaOverrides/finance';
import { inventoryOverrides } from './schemaOverrides/inventory';
import { systemOverrides } from './schemaOverrides/system';
import { hrOverrides, collabOverrides } from './schemaOverrides/hrCollab';
import { mesWmsOverrides, aiOverrides, printShopCrmOverrides } from './schemaOverrides/mesAiPrint';
import { apsOverrides } from './schemaOverrides/aps';
import { docGapOverrides } from './schemaOverrides/docGap';

export type FieldType = 'text' | 'number' | 'money' | 'date' | 'datetime' | 'select' | 'textarea' | 'switch';

export interface EntityField {
  prop: string;
  label: string;
  type?: FieldType;
  options?: Array<{ label: string; value: string | number }>;
  width?: number;
  /** 是否出现在新增/编辑表单（默认 true；id/时间戳默认排除） */
  form?: boolean;
}

export interface EntitySchema {
  /** api 路径推导出的集合名，如 crmcustomerGroups */
  collection: string;
  label: string;
  fields: EntityField[];
  seed: any[];
  statusField?: string;
  statusLabels?: Record<string, string>;
}

/** 状态文案：通用单据状态（数字） */
export const DOC_STATUS: Record<string, string> = {
  '0': '草稿', '1': '待审核', '2': '已确认', '3': '部分完成', '4': '已完成', '9': '已作废',
};
/** 启停状态 */
export const YES_NO: Record<string, string> = { '1': '是', '0': '否' };
/** 启用状态 */
export const ACTIVE_STATUS: Record<string, string> = { '1': '启用', '0': '停用' };

/** 客户分级 */
export const CUSTOMER_LEVELS: Array<{ label: string; value: string }> = [
  { label: 'A 级（战略）', value: 'A' }, { label: 'B 级（重点）', value: 'B' },
  { label: 'C 级（普通）', value: 'C' }, { label: 'D 级（潜在）', value: 'D' },
];

/** 字段定义简写，压缩后续实体的配置代码 */
const f = (prop: string, label: string, type: FieldType = 'text', width?: number, extra?: Partial<EntityField>): EntityField => ({ prop, label, type, width, ...extra });
/** 下拉字段简写 */
const sel = (prop: string, label: string, options: Array<{ label: string; value: string | number }>, width = 100): EntityField => f(prop, label, 'select', width, { options });
/** 单据状态的「值:标签」数组形式（供下拉选项生成） */
export const DOC_STATUS_LABELS = ['0:草稿', '1:待审核', '2:已确认', '3:部分完成', '4:已完成', '9:已作废'];
/** 由 ["值:标签", ...] 或 Record 生成下拉选项 */
const opt = (pairs: string[] | Record<string, string>): Array<{ label: string; value: string }> =>
  Array.isArray(pairs)
    ? pairs.map((p) => { const [value, label] = p.split(':'); return { value, label: label ?? value }; })
    : Object.entries(pairs).map(([value, label]) => ({ value, label }));
/** 通用启停状态选项 */
const ON_OFF = [{ label: '启用', value: 1 }, { label: '停用', value: 0 }];

/**
 * 全部业务实体 Schema。
 * key = collection 名（与 handleMock 的 collectionOf 结果一致）。
 */
export const ENTITY_SCHEMAS: Record<string, EntitySchema> = {

  crmCustomers: {
    collection: 'crmCustomers', label: '客户列表',
    fields: [
      { prop: 'id', label: 'ID', type: 'text', width: 70, form: false },
      { prop: 'name', label: '客户名称', type: 'text', width: 180 },
      { prop: 'code', label: '客户编码', type: 'text', width: 120 },
      { prop: 'level', label: '客户等级', type: 'select', options: CUSTOMER_LEVELS, width: 100 },
      { prop: 'groupName', label: '所属分组', type: 'text', width: 120 },
      { prop: 'contact', label: '联系人', type: 'text', width: 110 },
      { prop: 'phone', label: '联系电话', type: 'text', width: 130 },
      { prop: 'creditLimit', label: '信用额度', type: 'money', width: 120 },
      { prop: 'receivable', label: '应收余额', type: 'money', width: 120 },
      { prop: 'priceLevel', label: '价格等级', type: 'select', options: [{ label: '标准价', value: '标准价' }, { label: '批发价', value: '批发价' }, { label: 'VIP价', value: 'VIP价' }], width: 110 },
      { prop: 'status', label: '状态', type: 'select', options: [{ label: '合作中', value: '合作中' }, { label: '潜在', value: '潜在' }, { label: '停用', value: '停用' }], width: 100 },
      { prop: 'address', label: '地址', type: 'text', form: true },
      { prop: 'remark', label: '备注', type: 'textarea' },
    ],
    statusField: 'status',
    statusLabels: { 合作中: '合作中', 潜在: '潜在', 停用: '停用' },
    seed: [
      { id: 1, name: '蓝天实业有限公司', code: 'C001', level: 'A', groupName: '重点客户', contact: '陈经理', phone: '13800138001', creditLimit: 50000, receivable: 12800, priceLevel: 'VIP价', status: '合作中', address: '深圳市南山区科技园南区', remark: '战略合作伙伴，月结30天' },
      { id: 2, name: '深圳好再来商贸', code: 'C002', level: 'B', groupName: '渠道客户', contact: '刘老板', phone: '13800138002', creditLimit: 20000, receivable: 3200, priceLevel: '批发价', status: '合作中', address: '深圳市福田区华强北', remark: '批发渠道，现款现货' },
      { id: 3, name: '广州云科技有限公司', code: 'C003', level: 'A', groupName: '重点客户', contact: '周总', phone: '13800138003', creditLimit: 80000, receivable: 0, priceLevel: 'VIP价', status: '合作中', address: '广州市天河区珠江新城', remark: '重点开发，账期45天' },
      { id: 4, name: '东莞精工制造厂', code: 'C004', level: 'C', groupName: '普通客户', contact: '王厂长', phone: '13800138004', creditLimit: 10000, receivable: 5600, priceLevel: '标准价', status: '合作中', address: '东莞市长安镇工业园', remark: '稳定小批量采购' },
      { id: 5, name: '佛山顺德贸易行', code: 'C005', level: 'D', groupName: '潜在客户', contact: '李经理', phone: '13800138005', creditLimit: 5000, receivable: 0, priceLevel: '标准价', status: '潜在', address: '佛山市顺德区', remark: '待跟进，意向办公用品采购' },
    ],
  },

  crmCustomerGroups: {
    collection: 'crmCustomerGroups', label: '客户分组',
    fields: [
      { prop: 'id', label: 'ID', type: 'text', width: 70, form: false },
      { prop: 'name', label: '分组名称', type: 'text', width: 160 },
      { prop: 'code', label: '分组编码', type: 'text', width: 120 },
      { prop: 'customerCount', label: '客户数量', type: 'number', width: 110 },
      { prop: 'manager', label: '负责人', type: 'text', width: 110 },
      { prop: 'description', label: '分组说明', type: 'textarea' },
      { prop: 'status', label: '状态', type: 'select', options: [{ label: '启用', value: 1 }, { label: '停用', value: 0 }], width: 100 },
    ],
    statusField: 'status', statusLabels: { '1': '启用', '0': '停用' },
    seed: [
      { id: 1, name: '重点客户', code: 'CG01', customerCount: 2, manager: '张销售', description: '战略级大客户，专人跟进，享受 VIP 价与优先发货', status: 1 },
      { id: 2, name: '渠道客户', code: 'CG02', customerCount: 1, manager: '张销售', description: '批发与经销商渠道，走量为主', status: 1 },
      { id: 3, name: '普通客户', code: 'CG03', customerCount: 1, manager: '李业务', description: '常规零售与小批量客户', status: 1 },
      { id: 4, name: '潜在客户', code: 'CG04', customerCount: 1, manager: '李业务', description: '线索转化中的意向客户', status: 1 },
    ],
  },

  crmCustomerLevels: {
    collection: 'crmCustomerLevels', label: '客户等级',
    fields: [
      { prop: 'id', label: 'ID', type: 'text', width: 70, form: false },
      { prop: 'name', label: '等级名称', type: 'text', width: 140 },
      { prop: 'code', label: '等级编码', type: 'text', width: 100 },
      { prop: 'discount', label: '折扣率', type: 'number', width: 100 },
      { prop: 'minAmount', label: '最低消费', type: 'money', width: 120 },
      { prop: 'creditMultiple', label: '信用倍数', type: 'number', width: 110 },
      { prop: 'description', label: '说明', type: 'textarea' },
    ],
    seed: [
      { id: 1, name: 'A 级（战略）', code: 'A', discount: 0.85, minAmount: 50000, creditMultiple: 2, description: '战略客户，最高信用额度与最优价格' },
      { id: 2, name: 'B 级（重点）', code: 'B', discount: 0.9, minAmount: 20000, creditMultiple: 1.5, description: '重点客户，较高信用额度' },
      { id: 3, name: 'C 级（普通）', code: 'C', discount: 0.95, minAmount: 5000, creditMultiple: 1, description: '普通客户，标准信用政策' },
      { id: 4, name: 'D 级（潜在）', code: 'D', discount: 1, minAmount: 0, creditMultiple: 0, description: '潜在客户，现款现货' },
    ],
  },

  crmContacts: {
    collection: 'crmContacts', label: '客户联系人',
    fields: [
      { prop: 'id', label: 'ID', type: 'text', width: 70, form: false },
      { prop: 'name', label: '联系人', type: 'text', width: 120 },
      { prop: 'customerName', label: '所属客户', type: 'text', width: 170 },
      { prop: 'position', label: '职务', type: 'text', width: 110 },
      { prop: 'phone', label: '手机', type: 'text', width: 130 },
      { prop: 'tel', label: '办公电话', type: 'text', width: 130 },
      { prop: 'email', label: '邮箱', type: 'text', width: 170 },
      { prop: 'isPrimary', label: '主要联系人', type: 'select', options: [{ label: '是', value: 1 }, { label: '否', value: 0 }], width: 110 },
      { prop: 'remark', label: '备注', type: 'textarea' },
    ],
    seed: [
      { id: 1, name: '陈经理', customerName: '蓝天实业有限公司', position: '采购经理', phone: '13800138001', tel: '0755-26660001', email: 'chen@lantian.com', isPrimary: 1, remark: '负责办公用品采购决策' },
      { id: 2, name: '刘老板', customerName: '深圳好再来商贸', position: '总经理', phone: '13800138002', tel: '0755-83330002', email: 'liu@haozailai.com', isPrimary: 1, remark: '直接决策人，现款现货' },
      { id: 3, name: '周总', customerName: '广州云科技有限公司', position: '运营总监', phone: '13800138003', tel: '020-38880003', email: 'zhou@yunkj.com', isPrimary: 1, remark: '季度集中采购' },
      { id: 4, name: '王厂长', customerName: '东莞精工制造厂', position: '厂长', phone: '13800138004', tel: '0769-85330004', email: 'wang@jinggong.com', isPrimary: 1, remark: '生产物料采购' },
    ],
  },

  crmQuoteTemplates: {
    collection: 'crmQuoteTemplates', label: '报价模板',
    fields: [
      { prop: 'id', label: 'ID', type: 'text', width: 70, form: false },
      { prop: 'name', label: '模板名称', type: 'text', width: 180 },
      { prop: 'code', label: '模板编码', type: 'text', width: 120 },
      { prop: 'category', label: '适用类别', type: 'text', width: 120 },
      { prop: 'validDays', label: '有效期(天)', type: 'number', width: 110 },
      { prop: 'remark', label: '备注', type: 'textarea' },
      { prop: 'status', label: '状态', type: 'select', options: [{ label: '启用', value: 1 }, { label: '停用', value: 0 }], width: 100 },
    ],
    statusField: 'status', statusLabels: { '1': '启用', '0': '停用' },
    seed: [
      { id: 1, name: '办公用品标准报价', code: 'QT01', category: '办公用品', validDays: 30, remark: '含税价，量大专享折扣', status: 1 },
      { id: 2, name: '数码电子渠道报价', code: 'QT02', category: '数码电子', validDays: 15, remark: '渠道批发价格体系', status: 1 },
      { id: 3, name: '大客户年度框架报价', code: 'QT03', category: '通用', validDays: 365, remark: '年度框架协议价', status: 1 },
    ],
  },

  crmContracts: {
    collection: 'crmContracts', label: '销售合同',
    fields: [
      { prop: 'id', label: 'ID', type: 'text', width: 70, form: false },
      { prop: 'contractNo', label: '合同编号', type: 'text', width: 150 },
      { prop: 'customerName', label: '客户', type: 'text', width: 170 },
      { prop: 'title', label: '合同标题', type: 'text', width: 180 },
      { prop: 'amount', label: '合同金额', type: 'money', width: 130 },
      { prop: 'signDate', label: '签订日期', type: 'date', width: 120 },
      { prop: 'expireDate', label: '到期日期', type: 'date', width: 120 },
      { prop: 'status', label: '状态', type: 'select', options: [{ label: '执行中', value: '执行中' }, { label: '待签', value: '待签' }, { label: '已完成', value: '已完成' }], width: 100 },
    ],
    statusField: 'status', statusLabels: { 执行中: '执行中', 待签: '待签', 已完成: '已完成' },
    seed: [
      { id: 1, contractNo: 'HT20260001', customerName: '蓝天实业有限公司', title: '2026年度办公用品供货合同', amount: 128000, signDate: '2026-01-15', expireDate: '2026-12-31', status: '执行中' },
      { id: 2, contractNo: 'HT20260002', customerName: '广州云科技有限公司', title: '数码设备采购框架协议', amount: 86000, signDate: '2026-03-20', expireDate: '2027-03-19', status: '执行中' },
      { id: 3, contractNo: 'HT20260003', customerName: '佛山顺德贸易行', title: '渠道经销合作协议', amount: 30000, signDate: '2026-11-10', expireDate: '2027-11-09', status: '待签' },
    ],
  },

  crmPromotions: {
    collection: 'crmPromotions', label: '促销活动',
    fields: [
      { prop: 'id', label: 'ID', type: 'text', width: 70, form: false },
      { prop: 'name', label: '活动名称', type: 'text', width: 180 },
      { prop: 'type', label: '活动类型', type: 'select', options: [{ label: '满减', value: '满减' }, { label: '折扣', value: '折扣' }, { label: '满赠', value: '满赠' }, { label: '优惠券', value: '优惠券' }], width: 110 },
      { prop: 'rule', label: '活动规则', type: 'text', width: 200 },
      { prop: 'startDate', label: '开始日期', type: 'date', width: 120 },
      { prop: 'endDate', label: '结束日期', type: 'date', width: 120 },
      { prop: 'status', label: '状态', type: 'select', options: [{ label: '进行中', value: '进行中' }, { label: '未开始', value: '未开始' }, { label: '已结束', value: '已结束' }], width: 100 },
    ],
    statusField: 'status', statusLabels: { 进行中: '进行中', 未开始: '未开始', 已结束: '已结束' },
    seed: [
      { id: 1, name: '双十一办公用品满减', type: '满减', rule: '满1000减150，满3000减500', startDate: '2026-11-01', endDate: '2026-11-15', status: '进行中' },
      { id: 2, name: '新客户首单折扣', type: '折扣', rule: '新客户首单全场9折', startDate: '2026-10-01', endDate: '2026-12-31', status: '进行中' },
      { id: 3, name: '数码产品满赠', type: '满赠', rule: '购数码产品满2000赠无线鼠标', startDate: '2026-12-01', endDate: '2026-12-31', status: '未开始' },
    ],
  },

  salesReturns: {
    collection: 'salesReturns', label: '销售退货',
    fields: [
      { prop: 'id', label: 'ID', type: 'text', width: 70, form: false },
      { prop: 'returnNo', label: '退货单号', type: 'text', width: 150 },
      { prop: 'customerName', label: '客户', type: 'text', width: 170 },
      { prop: 'productName', label: '产品', type: 'text', width: 150 },
      { prop: 'qty', label: '退货数量', type: 'number', width: 110 },
      { prop: 'amount', label: '退货金额', type: 'money', width: 120 },
      { prop: 'reason', label: '退货原因', type: 'text', width: 150 },
      { prop: 'status', label: '状态', type: 'select', options: opt(DOC_STATUS), width: 100 },
    ],
    statusField: 'status', statusLabels: DOC_STATUS,
    seed: [
      { id: 1, returnNo: 'RT20261101-0001', customerName: '深圳好再来商贸', productName: '中性笔 0.5mm', qty: 20, amount: 80, reason: '质量问题', status: 4 },
      { id: 2, returnNo: 'RT20261102-0002', customerName: '东莞精工制造厂', productName: '得力订书机', qty: 5, amount: 160, reason: '发错货', status: 4 },
    ],
  },

  salesExchanges: {
    collection: 'salesExchanges', label: '换货单',
    fields: [
      { prop: 'id', label: 'ID', type: 'text', width: 70, form: false },
      { prop: 'exchangeNo', label: '换货单号', type: 'text', width: 150 },
      { prop: 'customerName', label: '客户', type: 'text', width: 170 },
      { prop: 'oldProduct', label: '换出产品', type: 'text', width: 140 },
      { prop: 'newProduct', label: '换入产品', type: 'text', width: 140 },
      { prop: 'qty', label: '数量', type: 'number', width: 90 },
      { prop: 'status', label: '状态', type: 'select', options: opt(DOC_STATUS), width: 100 },
    ],
    statusField: 'status', statusLabels: DOC_STATUS,
    seed: [
      { id: 1, exchangeNo: 'EX20261103-0001', customerName: '蓝天实业有限公司', oldProduct: '无线鼠标(黑色)', newProduct: '无线鼠标(白色)', qty: 10, status: 4 },
    ],
  },

  salesShipments: {
    collection: 'salesShipments', label: '出货单',
    fields: [
      { prop: 'id', label: 'ID', type: 'text', width: 70, form: false },
      { prop: 'shipmentNo', label: '出货单号', type: 'text', width: 150 },
      { prop: 'orderNo', label: '来源订单', type: 'text', width: 150 },
      { prop: 'customerName', label: '客户', type: 'text', width: 170 },
      { prop: 'qty', label: '出货数量', type: 'number', width: 110 },
      { prop: 'warehouseName', label: '发货仓库', type: 'text', width: 120 },
      { prop: 'shipDate', label: '出货日期', type: 'date', width: 120 },
      { prop: 'trackingNo', label: '物流单号', type: 'text', width: 140 },
      { prop: 'status', label: '状态', type: 'select', options: opt(DOC_STATUS), width: 100 },
    ],
    statusField: 'status', statusLabels: DOC_STATUS,
    seed: [
      { id: 1, shipmentNo: 'SH20261116-0001', orderNo: 'SO20261116-0001', customerName: '蓝天实业有限公司', qty: 134, warehouseName: '主仓库', shipDate: '2026-11-16', trackingNo: 'SF1234567890', status: 4 },
    ],
  },

  salesStatements: {
    collection: 'salesStatements', label: '客户对账单',
    fields: [
      { prop: 'id', label: 'ID', type: 'text', width: 70, form: false },
      { prop: 'statementNo', label: '对账单号', type: 'text', width: 150 },
      { prop: 'customerName', label: '客户', type: 'text', width: 170 },
      { prop: 'period', label: '对账期间', type: 'text', width: 120 },
      { prop: 'amount', label: '对账金额', type: 'money', width: 130 },
      { prop: 'paidAmount', label: '已收金额', type: 'money', width: 130 },
      { prop: 'status', label: '状态', type: 'select', options: [{ label: '已确认', value: '已确认' }, { label: '待确认', value: '待确认' }], width: 100 },
    ],
    statusField: 'status', statusLabels: { 已确认: '已确认', 待确认: '待确认' },
    seed: [
      { id: 1, statementNo: 'DZ202610-0001', customerName: '蓝天实业有限公司', period: '2026-10', amount: 12800, paidAmount: 8000, status: '已确认' },
      { id: 2, statementNo: 'DZ202610-0002', customerName: '深圳好再来商贸', period: '2026-10', amount: 3200, paidAmount: 0, status: '待确认' },
    ],
  },

  salesPos: {
    collection: 'salesPos', label: 'POS 收银',
    fields: [
      { prop: 'id', label: 'ID', type: 'text', width: 70, form: false },
      { prop: 'posNo', label: '单号', type: 'text', width: 150 },
      { prop: 'storeName', label: '门店', type: 'text', width: 130 },
      { prop: 'amount', label: '金额', type: 'money', width: 120 },
      { prop: 'payMethod', label: '支付方式', type: 'select', options: [{ label: '微信', value: '微信' }, { label: '支付宝', value: '支付宝' }, { label: '现金', value: '现金' }, { label: '银行卡', value: '银行卡' }], width: 110 },
      { prop: 'cashier', label: '收银员', type: 'text', width: 100 },
      { prop: 'status', label: '状态', type: 'select', options: opt(DOC_STATUS), width: 100 },
    ],
    statusField: 'status', statusLabels: DOC_STATUS,
    seed: [
      { id: 1, posNo: 'POS20261117-0001', storeName: '科技园门店', amount: 268, payMethod: '微信', cashier: '收银员01', status: 4 },
      { id: 2, posNo: 'POS20261117-0002', storeName: '科技园门店', amount: 129, payMethod: '支付宝', cashier: '收银员01', status: 4 },
      { id: 3, posNo: 'POS20261117-0003', storeName: '华强北门店', amount: 88, payMethod: '现金', cashier: '收银员02', status: 4 },
    ],
  },

  salesProfit: {
    collection: 'salesProfit', label: '销售毛利分析',
    fields: [
      { prop: 'id', label: 'ID', type: 'text', width: 70, form: false },
      { prop: 'period', label: '期间', type: 'text', width: 110 },
      { prop: 'productName', label: '产品', type: 'text', width: 160 },
      { prop: 'salesQty', label: '销量', type: 'number', width: 100 },
      { prop: 'salesAmount', label: '销售额', type: 'money', width: 130 },
      { prop: 'costAmount', label: '成本额', type: 'money', width: 130 },
      { prop: 'profit', label: '毛利', type: 'money', width: 120 },
      { prop: 'profitRate', label: '毛利率', type: 'text', width: 100 },
    ],
    seed: [
      { id: 1, period: '2026-11', productName: 'A4 复印纸', salesQty: 100, salesAmount: 2600, costAmount: 1800, profit: 800, profitRate: '30.77%' },
      { id: 2, period: '2026-11', productName: '华为耳机', salesQty: 34, salesAmount: 10200, costAmount: 6766, profit: 3434, profitRate: '33.67%' },
      { id: 3, period: '2026-11', productName: '无线鼠标', salesQty: 20, salesAmount: 3200, costAmount: 900, profit: 2300, profitRate: '71.88%' },
    ],
  },

  salesUnshipped: {
    collection: 'salesUnshipped', label: '未发货清单',
    fields: [
      { prop: 'id', label: 'ID', type: 'text', width: 70, form: false },
      { prop: 'orderNo', label: '订单号', type: 'text', width: 150 },
      { prop: 'customerName', label: '客户', type: 'text', width: 170 },
      { prop: 'orderDate', label: '下单日期', type: 'date', width: 120 },
      { prop: 'amount', label: '订单金额', type: 'money', width: 130 },
      { prop: 'unshippedQty', label: '未发数量', type: 'number', width: 110 },
      { prop: 'days', label: '滞留天数', type: 'number', width: 100 },
    ],
    seed: [
      { id: 1, orderNo: 'SO20261117-0002', customerName: '深圳好再来商贸', orderDate: '2026-11-17', amount: 3200, unshippedQty: 20, days: 1 },
    ],
  },

  inventoryLocations: {
    collection: 'inventoryLocations', label: '库位',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('name', '库位名称'), f('code', '库位编码', 'text', 110), f('warehouseName', '所属仓库', 'text', 120), f('zone', '库区', 'text', 100), sel('status', '状态', ON_OFF)],
    statusField: 'status', statusLabels: { '1': '启用', '0': '停用' },
    seed: [
      { id: 1, name: 'A区-01-01', code: 'A0101', warehouseName: '主仓库', zone: 'A区', status: 1 },
      { id: 2, name: 'A区-01-02', code: 'A0102', warehouseName: '主仓库', zone: 'A区', status: 1 },
      { id: 3, name: 'B区-02-01', code: 'B0201', warehouseName: '主仓库', zone: 'B区', status: 1 },
      { id: 4, name: '分仓-01', code: 'F0101', warehouseName: '深圳分仓', zone: '默认区', status: 1 },
    ],
  },

  inventorySafeStock: {
    collection: 'inventorySafeStock', label: '安全库存',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('productName', '产品', 'text', 160), f('warehouseName', '仓库', 'text', 120), f('safeQty', '安全库存', 'number', 110), f('maxQty', '库存上限', 'number', 110), f('currentQty', '当前可用', 'number', 110), sel('alert', '预警状态', opt(['启用:启用', '停用:停用']))],
    seed: [
      { id: 1, productName: 'USB-C 扩展坞', warehouseName: '主仓库', safeQty: 20, maxQty: 200, currentQty: 3, alert: '启用' },
      { id: 2, productName: '无线鼠标', warehouseName: '主仓库', safeQty: 15, maxQty: 100, currentQty: 6, alert: '启用' },
      { id: 3, productName: 'A4 复印纸', warehouseName: '主仓库', safeQty: 50, maxQty: 500, currentQty: 120, alert: '启用' },
    ],
  },

  inventoryAdjusts: {
    collection: 'inventoryAdjusts', label: '库存调整',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('adjustNo', '调整单号', 'text', 150), f('productName', '产品', 'text', 150), f('warehouseName', '仓库', 'text', 110), f('beforeQty', '调整前', 'number', 100), f('changeQty', '变动量', 'number', 100), f('afterQty', '调整后', 'number', 100), f('reason', '调整原因', 'text', 150), sel('status', '状态', opt(DOC_STATUS_LABELS))],
    statusField: 'status', statusLabels: DOC_STATUS,
    seed: [
      { id: 1, adjustNo: 'ADJ20261101-0001', productName: '得力订书机', warehouseName: '主仓库', beforeQty: 43, changeQty: 2, afterQty: 45, reason: '盘盈调整', status: '已完成' },
      { id: 2, adjustNo: 'ADJ20261102-0002', productName: '办公文件夹', warehouseName: '主仓库', beforeQty: 82, changeQty: -2, afterQty: 80, reason: '损耗调整', status: '已完成' },
    ],
  },

  inventoryPicks: {
    collection: 'inventoryPicks', label: '拣货清单',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('pickNo', '拣货单号', 'text', 150), f('orderNo', '关联订单', 'text', 140), f('productName', '产品', 'text', 150), f('qty', '应拣数量', 'number', 100), f('pickedQty', '已拣数量', 'number', 100), f('picker', '拣货员', 'text', 100), sel('status', '状态', opt(['待拣货:待拣货', '拣货中:拣货中', '已完成:已完成']))],
    statusField: 'status', statusLabels: { 待拣货: '待拣货', 拣货中: '拣货中', 已完成: '已完成' },
    seed: [
      { id: 1, pickNo: 'PK20261117-0001', orderNo: 'SO20261116-0001', productName: 'A4 复印纸', qty: 100, pickedQty: 100, picker: '王仓管', status: '已完成' },
      { id: 2, pickNo: 'PK20261118-0002', orderNo: 'SO20261117-0002', productName: '无线鼠标', qty: 20, pickedQty: 0, picker: '', status: '待拣货' },
    ],
  },

  inventoryReceipts: {
    collection: 'inventoryReceipts', label: '收货入库',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('receiptNo', '入库单号', 'text', 150), f('productName', '产品', 'text', 150), f('qty', '入库数量', 'number', 100), f('unitCost', '入库成本', 'money', 110), f('supplierName', '供应商', 'text', 160), f('warehouseName', '仓库', 'text', 110), f('receivedAt', '入库日期', 'date', 120), sel('status', '状态', opt(DOC_STATUS_LABELS))],
    statusField: 'status', statusLabels: DOC_STATUS,
    seed: [
      { id: 1, receiptNo: 'RK20261115-0001', productName: 'A4 复印纸', qty: 200, unitCost: 18, supplierName: '得力集团深圳分公司', warehouseName: '主仓库', receivedAt: '2026-11-15', status: '已完成' },
      { id: 2, receiptNo: 'RK20261116-0002', productName: '无线鼠标', qty: 50, unitCost: 45, supplierName: '华强北电子批发', warehouseName: '主仓库', receivedAt: '2026-11-16', status: '已完成' },
    ],
  },

  inventoryOuts: {
    collection: 'inventoryOuts', label: '销售出库',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('outNo', '出库单号', 'text', 150), f('orderNo', '关联订单', 'text', 140), f('productName', '产品', 'text', 150), f('qty', '出库数量', 'number', 100), f('warehouseName', '仓库', 'text', 110), f('outAt', '出库日期', 'date', 120), sel('status', '状态', opt(DOC_STATUS_LABELS))],
    statusField: 'status', statusLabels: DOC_STATUS,
    seed: [
      { id: 1, outNo: 'CK20261116-0001', orderNo: 'SO20261116-0001', productName: 'A4 复印纸', qty: 100, warehouseName: '主仓库', outAt: '2026-11-16', status: '已完成' },
      { id: 2, outNo: 'CK20261116-0002', orderNo: 'SO20261116-0001', productName: '华为耳机', qty: 34, warehouseName: '主仓库', outAt: '2026-11-16', status: '已完成' },
    ],
  },

  inventoryPicksOut: {
    collection: 'inventoryPicksOut', label: '领料出库',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('issueNo', '领料单号', 'text', 150), f('workorderNo', '关联工单', 'text', 140), f('productName', '物料', 'text', 150), f('qty', '领用数量', 'number', 100), f('warehouseName', '仓库', 'text', 110), f('issuedAt', '领料日期', 'date', 120), sel('status', '状态', opt(DOC_STATUS_LABELS))],
    statusField: 'status', statusLabels: DOC_STATUS,
    seed: [
      { id: 1, issueNo: 'LL20261117-0001', workorderNo: 'WO20261117-0001', productName: 'A4 复印纸', qty: 30, warehouseName: '主仓库', issuedAt: '2026-11-17', status: '已完成' },
    ],
  },

  inventoryReports: {
    collection: 'inventoryReports', label: '收发存报表',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('period', '期间', 'text', 100), f('productName', '产品', 'text', 160), f('beginQty', '期初', 'number', 100), f('inQty', '本期入库', 'number', 110), f('outQty', '本期出库', 'number', 110), f('endQty', '期末', 'number', 100), f('avgCost', '加权成本', 'money', 110)],
    seed: [
      { id: 1, period: '2026-11', productName: 'A4 复印纸', beginQty: 20, inQty: 200, outQty: 100, endQty: 120, avgCost: 18 },
      { id: 2, period: '2026-11', productName: '无线鼠标', beginQty: 10, inQty: 50, outQty: 20, endQty: 40, avgCost: 45 },
    ],
  },

  inventoryAging: {
    collection: 'inventoryAging', label: '库龄分析',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('productName', '产品', 'text', 160), f('batchNo', '批次', 'text', 120), f('qty', '数量', 'number', 100), f('ageDays', '库龄(天)', 'number', 100), f('amount', '金额', 'money', 120), sel('ageBucket', '库龄区间', opt(['0-30天:0-30天', '31-60天:31-60天', '61-90天:61-90天', '90天以上:90天以上']))],
    seed: [
      { id: 1, productName: 'A4 复印纸', batchNo: 'B20261101', qty: 120, ageDays: 16, amount: 2160, ageBucket: '0-30天' },
      { id: 2, productName: '得力订书机', batchNo: 'B20260915', qty: 20, ageDays: 63, amount: 440, ageBucket: '61-90天' },
    ],
  },

  inventoryTurnover: {
    collection: 'inventoryTurnover', label: '周转率',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('period', '期间', 'text', 100), f('productName', '产品', 'text', 160), f('avgStock', '平均库存', 'number', 110), f('salesCost', '销售成本', 'money', 120), f('turnoverRate', '周转率', 'text', 100), f('turnoverDays', '周转天数', 'number', 110)],
    seed: [
      { id: 1, period: '2026-11', productName: 'A4 复印纸', avgStock: 110, salesCost: 1800, turnoverRate: '16.36', turnoverDays: 2 },
      { id: 2, period: '2026-11', productName: '华为耳机', avgStock: 25, salesCost: 6766, turnoverRate: '270.64', turnoverDays: 1 },
    ],
  },

  inventorySlow: {
    collection: 'inventorySlow', label: '呆滞料',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('productName', '产品', 'text', 160), f('qty', '库存数量', 'number', 110), f('idleDays', '呆滞天数', 'number', 110), f('amount', '占用金额', 'money', 120), sel('level', '呆滞等级', opt(['轻度:轻度', '中度:中度', '严重:严重']))],
    seed: [
      { id: 1, productName: 'USB-C 扩展坞', qty: 3, idleDays: 95, amount: 264, level: '严重' },
      { id: 2, productName: '得力订书机', qty: 20, idleDays: 63, amount: 440, level: '中度' },
    ],
  },

  inventoryTrace: {
    collection: 'inventoryTrace', label: '序列号追溯',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('serialNo', '序列号', 'text', 160), f('productName', '产品', 'text', 150), f('batchNo', '批次', 'text', 120), f('inNo', '入库单', 'text', 130), f('outNo', '出库单', 'text', 130), f('customerName', '流向客户', 'text', 160), sel('status', '状态', opt(['在库:在库', '已售:已售', '锁定:锁定']))],
    statusField: 'status', statusLabels: { 在库: '在库', 已售: '已售', 锁定: '锁定' },
    seed: [
      { id: 1, serialNo: 'IMEI862000001', productName: '华为耳机', batchNo: 'B20261101', inNo: 'RK20261115-0001', outNo: 'CK20261116-0002', customerName: '蓝天实业有限公司', status: '已售' },
    ],
  },

  mesBom: {
    collection: 'mesBom', label: '物料清单 BOM',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('bomNo', 'BOM编号', 'text', 130), f('productName', '成品', 'text', 150), f('version', '版本', 'text', 80), f('materialCount', '物料数', 'number', 100), f('qty', '基准用量', 'number', 100), sel('status', '状态', opt(['启用:启用', '停用:停用']))],
    statusField: 'status', statusLabels: { 启用: '启用', 停用: '停用' },
    seed: [
      { id: 1, bomNo: 'BOM0001', productName: '智能温控器', version: 'V1.0', materialCount: 5, qty: 1, status: '启用' },
      { id: 2, bomNo: 'BOM0002', productName: '无线网关', version: 'V2.1', materialCount: 8, qty: 1, status: '启用' },
    ],
  },

  mesBomVersions: {
    collection: 'mesBomVersions', label: 'BOM 版本',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('productName', '成品', 'text', 150), f('version', '版本', 'text', 90), f('effectiveDate', '生效日期', 'date', 120), f('changeReason', '变更原因', 'text', 180), sel('isCurrent', '当前版本', opt(['1:是', '0:否']))],
    seed: [
      { id: 1, productName: '智能温控器', version: 'V1.0', effectiveDate: '2026-01-01', changeReason: '初始版本', isCurrent: '1' },
      { id: 2, productName: '智能温控器', version: 'V0.9', effectiveDate: '2025-08-01', changeReason: '旧版归档', isCurrent: '0' },
    ],
  },

  mesWorkCenters: {
    collection: 'mesWorkCenters', label: '工作中心/产线',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('name', '工作中心', 'text', 150), f('code', '编码', 'text', 100), f('type', '类型', 'text', 110), f('capacity', '日产能', 'number', 100), f('manager', '负责人', 'text', 100), sel('status', '状态', ON_OFF)],
    statusField: 'status', statusLabels: { '1': '启用', '0': '停用' },
    seed: [
      { id: 1, name: 'SMT 贴片一线', code: 'WC01', type: '生产线', capacity: 5000, manager: '李主管', status: 1 },
      { id: 2, name: '组装二线', code: 'WC02', type: '生产线', capacity: 3000, manager: '王主管', status: 1 },
      { id: 3, name: '质检中心', code: 'QC01', type: '质检', capacity: 8000, manager: '张质检', status: 1 },
    ],
  },

  mesDemands: {
    collection: 'mesDemands', label: '需求汇总',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('demandNo', '需求单号', 'text', 140), f('source', '需求来源', 'text', 130), f('productName', '产品', 'text', 150), f('qty', '需求数量', 'number', 100), f('demandDate', '需求日期', 'date', 120), sel('status', '状态', opt(['待运算:待运算', '已运算:已运算', '已下达:已下达']))],
    statusField: 'status', statusLabels: { 待运算: '待运算', 已运算: '已运算', 已下达: '已下达' },
    seed: [
      { id: 1, demandNo: 'DM20261117-0001', source: '销售订单', productName: '智能温控器', qty: 200, demandDate: '2026-11-20', status: '已运算' },
      { id: 2, demandNo: 'DM20261117-0002', source: '安全库存', productName: '无线网关', qty: 100, demandDate: '2026-11-22', status: '待运算' },
    ],
  },

  mesIssues: {
    collection: 'mesIssues', label: '领料单',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('issueNo', '领料单号', 'text', 150), f('workorderNo', '工单', 'text', 130), f('productName', '物料', 'text', 150), f('qty', '数量', 'number', 100), f('warehouseName', '仓库', 'text', 110), sel('status', '状态', opt(DOC_STATUS_LABELS))],
    statusField: 'status', statusLabels: DOC_STATUS,
    seed: [
      { id: 1, issueNo: 'LL20261117-0001', workorderNo: 'WO20261117-0001', productName: '智能温控器芯片', qty: 200, warehouseName: '主仓库', status: '已完成' },
    ],
  },

  mesMaterialReturns: {
    collection: 'mesMaterialReturns', label: '退料单',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('returnNo', '退料单号', 'text', 150), f('workorderNo', '工单', 'text', 130), f('productName', '物料', 'text', 150), f('qty', '数量', 'number', 100), f('reason', '退料原因', 'text', 150), sel('status', '状态', opt(DOC_STATUS_LABELS))],
    statusField: 'status', statusLabels: DOC_STATUS,
    seed: [
      { id: 1, returnNo: 'TL20261117-0001', workorderNo: 'WO20261117-0001', productName: '智能温控器芯片', qty: 5, reason: '工单取消余料退回', status: '已完成' },
    ],
  },

  mesFinishIns: {
    collection: 'mesFinishIns', label: '完工入库',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('finishNo', '入库单号', 'text', 150), f('workorderNo', '工单', 'text', 130), f('productName', '产成品', 'text', 150), f('qty', '入库数量', 'number', 100), f('unitCost', '入库成本', 'money', 110), f('warehouseName', '仓库', 'text', 110), sel('status', '状态', opt(DOC_STATUS_LABELS))],
    statusField: 'status', statusLabels: DOC_STATUS,
    seed: [
      { id: 1, finishNo: 'WR20261117-0001', workorderNo: 'WO20261117-0001', productName: '智能温控器', qty: 100, unitCost: 85, warehouseName: '主仓库', status: '已完成' },
    ],
  },

  mesCapacity: {
    collection: 'mesCapacity', label: '产能分析',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('period', '期间', 'text', 100), f('workCenter', '工作中心', 'text', 150), f('planCapacity', '计划产能', 'number', 110), f('actualOutput', '实际产出', 'number', 110), f('utilization', '稼动率', 'text', 100), f('yieldRate', '良率', 'text', 100)],
    seed: [
      { id: 1, period: '2026-11', workCenter: 'SMT 贴片一线', planCapacity: 5000, actualOutput: 4600, utilization: '92%', yieldRate: '98.5%' },
      { id: 2, period: '2026-11', workCenter: '组装二线', planCapacity: 3000, actualOutput: 2850, utilization: '95%', yieldRate: '99.2%' },
    ],
  },

  mesCosts: {
    collection: 'mesCosts', label: '成本归集',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('period', '期间', 'text', 100), f('workorderNo', '工单', 'text', 130), f('productName', '产品', 'text', 150), f('materialCost', '材料成本', 'money', 120), f('laborCost', '人工成本', 'money', 120), f('overhead', '制造费用', 'money', 120), f('totalCost', '合计', 'money', 120)],
    seed: [
      { id: 1, period: '2026-11', workorderNo: 'WO20261117-0001', productName: '智能温控器', materialCost: 6800, laborCost: 1200, overhead: 500, totalCost: 8500 },
    ],
  },

  purchasereturns: {
    collection: 'purchasereturns', label: '采购退货',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('returnNo', '退货单号', 'text', 150), f('supplierName', '供应商', 'text', 170), f('productName', '产品', 'text', 150), f('qty', '退货数量', 'number', 100), f('amount', '退货金额', 'money', 120), f('reason', '退货原因', 'text', 140), sel('status', '状态', opt(DOC_STATUS_LABELS))],
    statusField: 'status', statusLabels: DOC_STATUS,
    seed: [
      { id: 1, returnNo: 'PR20261101-0001', supplierName: '得力集团深圳分公司', productName: '中性笔 0.5mm', qty: 20, amount: 50, reason: '质量问题', status: '已完成' },
    ],
  },

  purchaseexchanges: {
    collection: 'purchaseexchanges', label: '采购换货',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('exchangeNo', '换货单号', 'text', 150), f('supplierName', '供应商', 'text', 170), f('oldProduct', '换出产品', 'text', 140), f('newProduct', '换入产品', 'text', 140), f('qty', '数量', 'number', 90), sel('status', '状态', opt(DOC_STATUS_LABELS))],
    statusField: 'status', statusLabels: DOC_STATUS,
    seed: [
      { id: 1, exchangeNo: 'PE20261102-0001', supplierName: '华强北电子批发', oldProduct: '无线鼠标(故障)', newProduct: '无线鼠标(良品)', qty: 8, status: '已完成' },
    ],
  },

  purchasepricetracking: {
    collection: 'purchasepricetracking', label: '价格追踪',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('productName', '产品', 'text', 160), f('supplierName', '供应商', 'text', 160), f('lastPrice', '上次进价', 'money', 110), f('currentPrice', '本次进价', 'money', 110), f('changeRate', '涨跌幅', 'text', 100), f('updateDate', '更新日期', 'date', 120)],
    seed: [
      { id: 1, productName: 'A4 复印纸', supplierName: '得力集团深圳分公司', lastPrice: 18, currentPrice: 18, changeRate: '0%', updateDate: '2026-11-15' },
      { id: 2, productName: '无线鼠标', supplierName: '华强北电子批发', lastPrice: 48, currentPrice: 45, changeRate: '-6.25%', updateDate: '2026-11-16' },
    ],
  },

  purchaseabnormalities: {
    collection: 'purchaseabnormalities', label: '采购异常',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('orderNo', '采购单号', 'text', 140), f('type', '异常类型', 'text', 130), f('description', '异常描述', 'text', 200), f('handler', '处理人', 'text', 100), sel('status', '状态', opt(['待处理:待处理', '处理中:处理中', '已解决:已解决']))],
    statusField: 'status', statusLabels: { 待处理: '待处理', 处理中: '处理中', 已解决: '已解决' },
    seed: [
      { id: 1, orderNo: 'PO20261116-0001', type: '到货延迟', description: '供应商发货延迟3天，影响生产计划', handler: '采购员01', status: '处理中' },
    ],
  },

  financereports: {
    collection: 'financereports', label: '财务报表',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('name', '报表名称', 'text', 180), f('type', '报表类型', 'text', 130), f('period', '期间', 'text', 100), f('generatedAt', '生成时间', 'text', 160), sel('status', '状态', opt(['已生成:已生成', '生成中:生成中', '失败:失败']))],
    statusField: 'status', statusLabels: { 已生成: '已生成', 生成中: '生成中', 失败: '失败' },
    seed: [
      { id: 1, name: '2026年10月利润表', type: '利润表', period: '2026-10', generatedAt: '2026-11-01 02:00', status: '已生成' },
      { id: 2, name: '2026年10月资产负债表', type: '资产负债表', period: '2026-10', generatedAt: '2026-11-01 02:05', status: '已生成' },
      { id: 3, name: '2026年10月现金流量表', type: '现金流量表', period: '2026-10', generatedAt: '2026-11-01 02:10', status: '已生成' },
    ],
  },

  financecashflow: {
    collection: 'financecashflow', label: '现金流量',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('period', '期间', 'text', 100), f('item', '项目', 'text', 180), f('direction', '方向', 'text', 90), f('amount', '金额', 'money', 130), f('date', '日期', 'date', 120)],
    seed: [
      { id: 1, period: '2026-11', item: '销售商品收到的现金', direction: '流入', amount: 12800, date: '2026-11-16' },
      { id: 2, period: '2026-11', item: '购买商品支付的现金', direction: '流出', amount: 5000, date: '2026-11-15' },
      { id: 3, period: '2026-11', item: '支付职工薪酬', direction: '流出', amount: 3200, date: '2026-11-10' },
    ],
  },

  financetax: {
    collection: 'financetax', label: '税务申报',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('period', '申报期间', 'text', 110), f('taxType', '税种', 'text', 130), f('taxableAmount', '计税金额', 'money', 130), f('taxRate', '税率', 'text', 90), f('taxAmount', '应纳税额', 'money', 130), sel('status', '状态', opt(['待申报:待申报', '已申报:已申报']))],
    statusField: 'status', statusLabels: { 待申报: '待申报', 已申报: '已申报' },
    seed: [
      { id: 1, period: '2026-10', taxType: '增值税', taxableAmount: 128000, taxRate: '13%', taxAmount: 16640, status: '已申报' },
      { id: 2, period: '2026-10', taxType: '企业所得税', taxableAmount: 28000, taxRate: '25%', taxAmount: 7000, status: '待申报' },
    ],
  },

  financeinvoiceRecords: {
    collection: 'financeinvoiceRecords', label: '发票记录',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('invoiceNo', '发票号码', 'text', 160), f('type', '发票类型', 'text', 130), f('title', '抬头', 'text', 180), f('amount', '金额', 'money', 120), f('invoiceDate', '开票日期', 'date', 120), sel('status', '状态', opt(['已开具:已开具', '已作废:已作废', '待开具:待开具']))],
    statusField: 'status', statusLabels: { 已开具: '已开具', 已作废: '已作废', 待开具: '待开具' },
    seed: [
      { id: 1, invoiceNo: 'FP20261116001', type: '增值税专用发票', title: '蓝天实业有限公司', amount: 12800, invoiceDate: '2026-11-16', status: '已开具' },
      { id: 2, invoiceNo: 'FP20261117002', type: '普通发票', title: '深圳好再来商贸', amount: 3200, invoiceDate: '2026-11-17', status: '待开具' },
    ],
  },

  collabnotifications: {
    collection: 'collabnotifications', label: '通知公告',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('title', '标题', 'text', 220), f('type', '类型', 'text', 110), f('author', '发布人', 'text', 100), f('publishedAt', '发布时间', 'text', 160), sel('read', '阅读状态', opt(['0:未读', '1:已读']))],
    seed: [
      { id: 1, title: '关于11月办公用品促销活动的通知', type: '公告', author: '管理员', publishedAt: '2026-11-01 09:00', read: '0' },
      { id: 2, title: '系统将于本周日 22:00-24:00 维护', type: '通知', author: '系统', publishedAt: '2026-11-15 18:00', read: '1' },
      { id: 3, title: '新员工入职流程已更新', type: '公告', author: '人事部', publishedAt: '2026-11-10 10:30', read: '1' },
    ],
  },

  collabmessages: {
    collection: 'collabmessages', label: '站内消息',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('from', '发送人', 'text', 120), f('to', '接收人', 'text', 120), f('content', '内容', 'text', 240), f('sentAt', '发送时间', 'text', 160), sel('read', '状态', opt(['0:未读', '1:已读']))],
    seed: [
      { id: 1, from: '张销售', to: '我', content: '蓝天实业的新订单已审批通过，请安排发货', sentAt: '2026-11-17 14:20', read: '0' },
      { id: 2, from: '李采购', to: '我', content: 'A4复印纸已到货，请安排入库质检', sentAt: '2026-11-16 09:15', read: '1' },
    ],
  },

  collabTasks: {
    collection: 'collabTasks', label: '任务中心',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('title', '任务', 'text', 200), f('assignee', '负责人', 'text', 110), f('dueDate', '截止日期', 'date', 120), f('priority', '优先级', 'text', 90), sel('status', '状态', opt(['待办:待办', '进行中:进行中', '已完成:已完成']))],
    statusField: 'status', statusLabels: { 待办: '待办', 进行中: '进行中', 已完成: '已完成' },
    seed: [
      { id: 1, title: '跟进佛山顺德贸易行意向客户', assignee: '李业务', dueDate: '2026-11-25', priority: '高', status: '待办' },
      { id: 2, title: '完成11月库存盘点', assignee: '王仓管', dueDate: '2026-11-30', priority: '中', status: '进行中' },
    ],
  },

  collabdocuments: {
    collection: 'collabdocuments', label: '文档中心',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('name', '文档名称', 'text', 220), f('category', '分类', 'text', 120), f('uploader', '上传人', 'text', 100), f('size', '大小', 'text', 90), f('uploadedAt', '上传时间', 'text', 160)],
    seed: [
      { id: 1, name: '2026年度供货合同模板.docx', category: '合同', uploader: '管理员', size: '128KB', uploadedAt: '2026-01-15' },
      { id: 2, name: '员工手册.pdf', category: '制度', uploader: '人事部', size: '2.1MB', uploadedAt: '2026-03-01' },
      { id: 3, name: '产品报价单模板.xlsx', category: '模板', uploader: '销售部', size: '56KB', uploadedAt: '2026-06-20' },
    ],
  },

  collabschedule: {
    collection: 'collabschedule', label: '工作日程',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('title', '日程', 'text', 200), f('date', '日期', 'date', 120), f('time', '时间', 'text', 100), f('location', '地点', 'text', 130), f('attendees', '参与人', 'text', 160)],
    seed: [
      { id: 1, title: '销售周会', date: '2026-11-18', time: '09:00-10:00', location: '会议室A', attendees: '销售部全员' },
      { id: 2, title: '库存盘点', date: '2026-11-20', time: '14:00-17:00', location: '主仓库', attendees: '仓储部' },
    ],
  },

  collabknowledges: {
    collection: 'collabknowledges', label: '知识库',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('title', '标题', 'text', 220), f('category', '分类', 'text', 120), f('author', '作者', 'text', 100), f('views', '浏览量', 'number', 90), f('updatedAt', '更新时间', 'text', 150)],
    seed: [
      { id: 1, title: '新客户开发流程指引', category: '销售', author: '销售部', views: 128, updatedAt: '2026-11-01' },
      { id: 2, title: '库存盘点操作规范', category: '仓储', author: '仓储部', views: 86, updatedAt: '2026-10-15' },
    ],
  },

  collabgoals: {
    collection: 'collabgoals', label: '目标管理',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('title', '目标', 'text', 200), f('owner', '责任人', 'text', 110), f('period', '周期', 'text', 100), f('target', '目标值', 'text', 110), f('actual', '实际值', 'text', 110), sel('status', '状态', opt(['进行中:进行中', '已达成:已达成', '未达成:未达成']))],
    statusField: 'status', statusLabels: { 进行中: '进行中', 已达成: '已达成', 未达成: '未达成' },
    seed: [
      { id: 1, title: '11月销售额突破50万', owner: '销售部', period: '2026-11', target: '500000', actual: '428000', status: '进行中' },
      { id: 2, title: '库存准确率提升到99%', owner: '仓储部', period: '2026-Q4', target: '99%', actual: '98.5%', status: '进行中' },
    ],
  },

  hrPositions: {
    collection: 'hrPositions', label: '职位管理',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('name', '职位名称', 'text', 150), f('code', '职位编码', 'text', 110), f('department', '所属部门', 'text', 130), f('level', '职级', 'text', 90), sel('status', '状态', ON_OFF)],
    statusField: 'status', statusLabels: { '1': '启用', '0': '停用' },
    seed: [
      { id: 1, name: '销售经理', code: 'POS01', department: '销售部', level: '经理级', status: 1 },
      { id: 2, name: '采购专员', code: 'POS02', department: '采购部', level: '专员级', status: 1 },
      { id: 3, name: '仓管员', code: 'POS03', department: '仓储部', level: '操作级', status: 1 },
    ],
  },

  hrEmployees: {
    collection: 'hrEmployees', label: '员工档案',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('name', '姓名', 'text', 110), f('code', '工号', 'text', 100), f('department', '部门', 'text', 120), f('position', '职位', 'text', 120), f('phone', '手机', 'text', 130), f('email', '邮箱', 'text', 170), f('hireDate', '入职日期', 'date', 120), sel('status', '状态', opt(['在职:在职', '离职:离职', '试用:试用']))],
    statusField: 'status', statusLabels: { 在职: '在职', 离职: '离职', 试用: '试用' },
    seed: [
      { id: 1, name: '张伟', code: 'E001', department: '销售部', position: '销售经理', phone: '13900000001', email: 'zhangwei@erp.com', hireDate: '2024-03-01', status: '在职' },
      { id: 2, name: '李娜', code: 'E002', department: '采购部', position: '采购专员', phone: '13900000002', email: 'lina@erp.com', hireDate: '2025-01-15', status: '在职' },
      { id: 3, name: '王强', code: 'E003', department: '仓储部', position: '仓管员', phone: '13900000003', email: 'wangqiang@erp.com', hireDate: '2025-06-20', status: '试用' },
    ],
  },

  hrAttendance: {
    collection: 'hrAttendance', label: '考勤记录',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('name', '员工', 'text', 110), f('date', '日期', 'date', 120), f('checkIn', '上班打卡', 'text', 110), f('checkOut', '下班打卡', 'text', 110), f('workHours', '工时', 'number', 90), sel('status', '状态', opt(['正常:正常', '迟到:迟到', '早退:早退', '缺勤:缺勤']))],
    statusField: 'status', statusLabels: { 正常: '正常', 迟到: '迟到', 早退: '早退', 缺勤: '缺勤' },
    seed: [
      { id: 1, name: '张伟', date: '2026-11-17', checkIn: '08:58', checkOut: '18:05', workHours: 9, status: '正常' },
      { id: 2, name: '李娜', date: '2026-11-17', checkIn: '09:12', checkOut: '18:30', workHours: 9, status: '迟到' },
    ],
  },

  hrmLeave: {
    collection: 'hrmLeave', label: '请假管理',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('leaveNo', '请假单号', 'text', 140), f('name', '员工', 'text', 110), f('type', '假别', 'text', 100), f('startDate', '开始日期', 'date', 120), f('endDate', '结束日期', 'date', 120), f('days', '天数', 'number', 90), f('reason', '事由', 'text', 160), sel('status', '状态', opt(DOC_STATUS_LABELS))],
    statusField: 'status', statusLabels: DOC_STATUS,
    seed: [
      { id: 1, leaveNo: 'QJ20261101-0001', name: '李娜', type: '年假', startDate: '2026-11-20', endDate: '2026-11-22', days: 3, reason: '个人事务', status: '待审核' },
    ],
  },

  hrmSalary: {
    collection: 'hrmSalary', label: '工资单',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('period', '期间', 'text', 100), f('name', '员工', 'text', 110), f('baseSalary', '基本工资', 'money', 120), f('bonus', '绩效奖金', 'money', 120), f('deduction', '扣款', 'money', 110), f('netSalary', '实发工资', 'money', 120), sel('status', '状态', opt(['草稿:草稿', '已发放:已发放']))],
    statusField: 'status', statusLabels: { 草稿: '草稿', 已发放: '已发放' },
    seed: [
      { id: 1, period: '2026-10', name: '张伟', baseSalary: 12000, bonus: 3000, deduction: 800, netSalary: 14200, status: '已发放' },
      { id: 2, period: '2026-10', name: '李娜', baseSalary: 8000, bonus: 1500, deduction: 500, netSalary: 9000, status: '已发放' },
    ],
  },

  hrmPerformance: {
    collection: 'hrmPerformance', label: '绩效考核',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('period', '期间', 'text', 100), f('name', '员工', 'text', 110), f('department', '部门', 'text', 120), f('score', '得分', 'number', 90), f('grade', '等级', 'text', 90), f('comment', '评语', 'text', 180)],
    seed: [
      { id: 1, period: '2026-Q3', name: '张伟', department: '销售部', score: 92, grade: 'A', comment: '业绩突出，超额完成目标' },
      { id: 2, period: '2026-Q3', name: '李娜', department: '采购部', score: 85, grade: 'B', comment: '工作稳定，成本管控良好' },
    ],
  },

  hrmRecruitment: {
    collection: 'hrmRecruitment', label: '招聘管理',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('name', '候选人', 'text', 110), f('position', '应聘职位', 'text', 130), f('phone', '手机', 'text', 130), f('source', '来源', 'text', 100), f('interviewDate', '面试日期', 'date', 120), sel('status', '状态', opt(['待筛选:待筛选', '面试中:面试中', '已录用:已录用', '未录用:未录用']))],
    statusField: 'status', statusLabels: { 待筛选: '待筛选', 面试中: '面试中', 已录用: '已录用', 未录用: '未录用' },
    seed: [
      { id: 1, name: '赵敏', position: '销售代表', phone: '13700000001', source: '招聘网站', interviewDate: '2026-11-20', status: '面试中' },
      { id: 2, name: '孙浩', position: '仓库主管', phone: '13700000002', source: '内部推荐', interviewDate: '2026-11-18', status: '待筛选' },
    ],
  },

  shopOrders: {
    collection: 'shopOrders', label: '商城订单',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('orderNo', '订单号', 'text', 150), f('buyer', '买家', 'text', 130), f('amount', '金额', 'money', 120), f('payMethod', '支付方式', 'text', 110), f('createdAt', '下单时间', 'text', 160), sel('status', '状态', opt(['待付款:待付款', '待发货:待发货', '已发货:已发货', '已完成:已完成']))],
    statusField: 'status', statusLabels: { 待付款: '待付款', 待发货: '待发货', 已发货: '已发货', 已完成: '已完成' },
    seed: [
      { id: 1, orderNo: 'MALL20261117-0001', buyer: '终端客户138****6666', amount: 268, payMethod: '微信支付', createdAt: '2026-11-17 10:30', status: '待发货' },
      { id: 2, orderNo: 'MALL20261116-0002', buyer: '终端客户139****8888', amount: 129, payMethod: '支付宝', createdAt: '2026-11-16 15:20', status: '已完成' },
    ],
  },

  shopProducts: {
    collection: 'shopProducts', label: '商城商品',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('name', '商品名称', 'text', 180), f('code', '商品编码', 'text', 110), f('category', '分类', 'text', 110), f('price', '售价', 'money', 110), f('stock', '库存', 'number', 90), f('sales', '销量', 'number', 90), sel('status', '状态', opt(['上架:上架', '下架:下架']))],
    statusField: 'status', statusLabels: { 上架: '上架', 下架: '下架' },
    seed: [
      { id: 1, name: '无线鼠标 京东自营', code: 'SP001', category: '数码配件', price: 69, stock: 40, sales: 156, status: '上架' },
      { id: 2, name: 'USB-C 扩展坞', code: 'SP002', category: '数码配件', price: 299, stock: 3, sales: 89, status: '上架' },
      { id: 3, name: 'A4 复印纸整箱', code: 'SP003', category: '办公用品', price: 26, stock: 120, sales: 320, status: '上架' },
    ],
  },

  shopCarts: {
    collection: 'shopCarts', label: '购物车',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('user', '用户', 'text', 130), f('productName', '商品', 'text', 170), f('qty', '数量', 'number', 90), f('price', '单价', 'money', 110), f('addedAt', '加入时间', 'text', 160)],
    seed: [
      { id: 1, user: '终端客户138****6666', productName: '无线鼠标 京东自营', qty: 2, price: 69, addedAt: '2026-11-17 10:25' },
      { id: 2, user: '终端客户139****8888', productName: 'A4 复印纸整箱', qty: 5, price: 26, addedAt: '2026-11-16 15:10' },
    ],
  },

  shopFavorites: {
    collection: 'shopFavorites', label: '收藏夹',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('user', '用户', 'text', 130), f('productName', '商品', 'text', 170), f('price', '单价', 'money', 110), f('favoritedAt', '收藏时间', 'text', 160)],
    seed: [
      { id: 1, user: '终端客户138****6666', productName: 'USB-C 扩展坞', price: 299, favoritedAt: '2026-11-17 10:28' },
    ],
  },

  shopPromotions: {
    collection: 'shopPromotions', label: '商城促销',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('name', '活动名称', 'text', 180), f('type', '类型', 'text', 110), f('rule', '活动规则', 'text', 200), f('startDate', '开始', 'date', 120), f('endDate', '结束', 'date', 120), sel('status', '状态', opt(['进行中:进行中', '未开始:未开始', '已结束:已结束']))],
    statusField: 'status', statusLabels: { 进行中: '进行中', 未开始: '未开始', 已结束: '已结束' },
    seed: [
      { id: 1, name: '双十二数码狂欢', type: '满减', rule: '满500减80', startDate: '2026-12-01', endDate: '2026-12-12', status: '未开始' },
      { id: 2, name: '新客首单立减', type: '优惠券', rule: '新用户首单减20', startDate: '2026-11-01', endDate: '2026-12-31', status: '进行中' },
    ],
  },

  shopCoupons: {
    collection: 'shopCoupons', label: '优惠券',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('name', '优惠券名称', 'text', 170), f('type', '类型', 'text', 110), f('value', '面额', 'text', 100), f('minAmount', '使用门槛', 'money', 110), f('validDays', '有效期(天)', 'number', 110), sel('status', '状态', ON_OFF)],
    statusField: 'status', statusLabels: { '1': '启用', '0': '停用' },
    seed: [
      { id: 1, name: '满100减20券', type: '满减券', value: '20', minAmount: 100, validDays: 30, status: 1 },
      { id: 2, name: '新客9折券', type: '折扣券', value: '9折', minAmount: 0, validDays: 15, status: 1 },
    ],
  },

  printTemplates: {
    collection: 'printTemplates', label: '打印模板',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('name', '模板名称', 'text', 180), f('code', '模板编码', 'text', 120), f('bizType', '业务类型', 'text', 130), f('paperSize', '纸张', 'text', 100), f('updatedAt', '更新时间', 'text', 160), sel('status', '状态', ON_OFF)],
    statusField: 'status', statusLabels: { '1': '启用', '0': '停用' },
    seed: [
      { id: 1, name: '销售单打印模板(A4)', code: 'PT01', bizType: '销售订单', paperSize: 'A4', updatedAt: '2026-11-01', status: 1 },
      { id: 2, name: '发货单打印模板(热敏)', code: 'PT02', bizType: '出货单', paperSize: '80mm热敏', updatedAt: '2026-10-20', status: 1 },
      { id: 3, name: '入库单打印模板', code: 'PT03', bizType: '收货入库', paperSize: 'A5', updatedAt: '2026-09-15', status: 1 },
    ],
  },

  printFonts: {
    collection: 'printFonts', label: '字体管理',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('name', '字体名称', 'text', 160), f('file', '字体文件', 'text', 180), f('size', '大小', 'text', 100), f('uploadedAt', '上传时间', 'text', 160), sel('status', '状态', ON_OFF)],
    statusField: 'status', statusLabels: { '1': '启用', '0': '停用' },
    seed: [
      { id: 1, name: '微软雅黑', file: 'msyh.ttf', size: '15MB', uploadedAt: '2026-01-01', status: 1 },
      { id: 2, name: '宋体', file: 'simsun.ttc', size: '10MB', uploadedAt: '2026-01-01', status: 1 },
    ],
  },

  printBarcodes: {
    collection: 'printBarcodes', label: '条码标签',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('name', '标签名称', 'text', 170), f('productName', '产品', 'text', 150), f('barcode', '条码', 'text', 160), f('spec', '规格', 'text', 120), f('copies', '打印份数', 'number', 100)],
    seed: [
      { id: 1, name: '价格标签', productName: '无线鼠标', barcode: '6901234567890', spec: '黑色/标准', copies: 20 },
      { id: 2, name: '库位标签', productName: 'A4 复印纸', barcode: '6901234567891', spec: 'A4/500张', copies: 10 },
    ],
  },

  aiTasks: {
    collection: 'aiTasks', label: 'AI 任务队列',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('name', '任务名称', 'text', 200), f('type', '任务类型', 'text', 130), f('model', '模型', 'text', 120), f('submittedAt', '提交时间', 'text', 160), sel('status', '状态', opt(['排队中:排队中', '处理中:处理中', '已完成:已完成', '失败:失败']))],
    statusField: 'status', statusLabels: { 排队中: '排队中', 处理中: '处理中', 已完成: '已完成', 失败: '失败' },
    seed: [
      { id: 1, name: '11月销售趋势预测', type: '销售预测', model: 'gpt-4o', submittedAt: '2026-11-17 09:00', status: '已完成' },
      { id: 2, name: '呆滞库存智能分析', type: '异常检测', model: 'gpt-4o', submittedAt: '2026-11-18 10:30', status: '处理中' },
    ],
  },

  aiRules: {
    collection: 'aiRules', label: 'AI 规则库',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('name', '规则名称', 'text', 180), f('type', '规则类型', 'text', 120), f('condition', '触发条件', 'text', 220), f('action', '执行动作', 'text', 220), sel('enabled', '启用', opt(['1:是', '0:否']))],
    seed: [
      { id: 1, name: '低库存自动预警', type: '库存预警', condition: '可用库存 < 安全库存', action: '生成预警并通知仓管', enabled: '1' },
      { id: 2, name: '超信用额度拦截', type: '风控', condition: '应收余额 > 信用额度', action: '阻断销售单确认', enabled: '1' },
      { id: 3, name: '应收逾期提醒', type: '财务', condition: '账龄 > 30天', action: '通知销售跟进', enabled: '1' },
    ],
  },

  sysdepartments: {
    collection: 'sysdepartments', label: '部门管理',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('name', '部门名称', 'text', 150), f('code', '部门编码', 'text', 110), f('parent', '上级部门', 'text', 120), f('leader', '部门负责人', 'text', 110), f('memberCount', '人数', 'number', 90), sel('status', '状态', ON_OFF)],
    statusField: 'status', statusLabels: { '1': '启用', '0': '停用' },
    seed: [
      { id: 1, name: '总经办', code: 'D01', parent: '-', leader: '总经理', memberCount: 3, status: 1 },
      { id: 2, name: '销售部', code: 'D02', parent: '总经办', leader: '张伟', memberCount: 12, status: 1 },
      { id: 3, name: '采购部', code: 'D03', parent: '总经办', leader: '李娜', memberCount: 5, status: 1 },
      { id: 4, name: '仓储部', code: 'D04', parent: '总经办', leader: '王强', memberCount: 8, status: 1 },
      { id: 5, name: '财务部', code: 'D05', parent: '总经办', leader: '陈会计', memberCount: 4, status: 1 },
    ],
  },

  sysroles: {
    collection: 'sysroles', label: '角色管理',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('name', '角色名称', 'text', 150), f('code', '角色编码', 'text', 110), f('description', '角色说明', 'text', 200), f('userCount', '用户数', 'number', 90), sel('status', '状态', ON_OFF)],
    statusField: 'status', statusLabels: { '1': '启用', '0': '停用' },
    seed: [
      { id: 1, name: '系统管理员', code: 'ADMIN', description: '拥有系统全部权限', userCount: 2, status: 1 },
      { id: 2, name: '销售经理', code: 'SALES_MGR', description: '管理销售业务与客户', userCount: 3, status: 1 },
      { id: 3, name: '仓管员', code: 'WAREHOUSE', description: '管理库存出入库', userCount: 5, status: 1 },
      { id: 4, name: '会计', code: 'ACCOUNTANT', description: '管理财务凭证与报表', userCount: 2, status: 1 },
    ],
  },

  syspermissions: {
    collection: 'syspermissions', label: '权限管理',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('name', '权限名称', 'text', 160), f('code', '权限标识', 'text', 150), f('module', '所属模块', 'text', 120), f('type', '类型', 'text', 100)],
    seed: [
      { id: 1, name: '查看销售单', code: 'sales:order:view', module: '销售管理', type: '菜单' },
      { id: 2, name: '新增销售单', code: 'sales:order:add', module: '销售管理', type: '按钮' },
      { id: 3, name: '审核销售单', code: 'sales:order:approve', module: '销售管理', type: '按钮' },
      { id: 4, name: '查看库存', code: 'inventory:view', module: '库存管理', type: '菜单' },
    ],
  },

  sysusers: {
    collection: 'sysusers', label: '用户管理',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('username', '用户名', 'text', 120), f('realName', '姓名', 'text', 110), f('department', '部门', 'text', 120), f('roles', '角色', 'text', 140), f('phone', '手机', 'text', 130), f('email', '邮箱', 'text', 170), f('lastLogin', '最后登录', 'text', 160), sel('status', '状态', ON_OFF)],
    statusField: 'status', statusLabels: { '1': '启用', '0': '停用' },
    seed: [
      { id: 1, username: 'admin', realName: '系统管理员', department: '总经办', roles: '系统管理员', phone: '13800138000', email: 'admin@erp.com', lastLogin: '2026-11-18 09:30', status: 1 },
      { id: 2, username: 'sales01', realName: '张伟', department: '销售部', roles: '销售经理', phone: '13900000001', email: 'zhangwei@erp.com', lastLogin: '2026-11-17 17:20', status: 1 },
      { id: 3, username: 'warehouse01', realName: '王强', department: '仓储部', roles: '仓管员', phone: '13900000003', email: 'wangqiang@erp.com', lastLogin: '2026-11-17 16:10', status: 1 },
    ],
  },

  sysdicts: {
    collection: 'sysdicts', label: '数据字典',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('type', '字典类型', 'text', 130), f('code', '字典编码', 'text', 110), f('label', '字典标签', 'text', 130), f('value', '字典值', 'text', 110), f('sort', '排序', 'number', 80), sel('status', '状态', ON_OFF)],
    statusField: 'status', statusLabels: { '1': '启用', '0': '停用' },
    seed: [
      { id: 1, type: '支付方式', code: 'PAY_WECHAT', label: '微信支付', value: '微信', sort: 1, status: 1 },
      { id: 2, type: '支付方式', code: 'PAY_ALIPAY', label: '支付宝', value: '支付宝', sort: 2, status: 1 },
      { id: 3, type: '客户等级', code: 'CUST_A', label: 'A级', value: 'A', sort: 1, status: 1 },
      { id: 4, type: '单位', code: 'UNIT_PCS', label: '个', value: '个', sort: 1, status: 1 },
    ],
  },

  syslogs: {
    collection: 'syslogs', label: '操作日志',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('user', '操作人', 'text', 110), f('module', '模块', 'text', 120), f('action', '操作', 'text', 140), f('detail', '详情', 'text', 220), f('ip', 'IP', 'text', 130), f('createdAt', '时间', 'text', 160)],
    seed: [
      { id: 1, user: 'admin', module: '销售管理', action: '审核销售单', detail: '审核通过销售单 SO20261116-0001', ip: '127.0.0.1', createdAt: '2026-11-17 14:20' },
      { id: 2, user: 'warehouse01', module: '库存管理', action: '采购收货', detail: 'A4复印纸入库200件', ip: '127.0.0.1', createdAt: '2026-11-15 10:05' },
      { id: 3, user: 'sales01', module: '客户管理', action: '新增客户', detail: '新增客户 佛山顺德贸易行', ip: '127.0.0.1', createdAt: '2026-11-10 16:30' },
    ],
  },

  sysloginLogs: {
    collection: 'sysloginLogs', label: '登录日志',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('user', '用户', 'text', 120), f('ip', 'IP地址', 'text', 130), f('browser', '浏览器', 'text', 140), f('result', '结果', 'text', 100), f('loginAt', '登录时间', 'text', 160)],
    seed: [
      { id: 1, user: 'admin', ip: '127.0.0.1', browser: 'Chrome 120', result: '成功', loginAt: '2026-11-18 09:30' },
      { id: 2, user: 'sales01', ip: '192.168.1.35', browser: 'Edge 120', result: '成功', loginAt: '2026-11-17 17:20' },
      { id: 3, user: 'unknown', ip: '103.45.22.11', browser: 'Unknown', result: '失败', loginAt: '2026-11-17 03:12' },
    ],
  },

  sysbackups: {
    collection: 'sysbackups', label: '数据备份',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('name', '备份文件', 'text', 200), f('size', '大小', 'text', 100), f('type', '备份类型', 'text', 110), f('createdAt', '备份时间', 'text', 160), sel('status', '状态', opt(['成功:成功', '失败:失败']))],
    statusField: 'status', statusLabels: { 成功: '成功', 失败: '失败' },
    seed: [
      { id: 1, name: 'backup_20261118_0200.sql', size: '45MB', type: '自动备份', createdAt: '2026-11-18 02:00', status: '成功' },
      { id: 2, name: 'backup_20261117_0200.sql', size: '44MB', type: '自动备份', createdAt: '2026-11-17 02:00', status: '成功' },
      { id: 3, name: 'backup_20261110_1000.sql', size: '42MB', type: '手动备份', createdAt: '2026-11-10 10:00', status: '成功' },
    ],
  },

  sysconfigs: {
    collection: 'sysconfigs', label: '系统参数',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('name', '参数名称', 'text', 160), f('code', '参数编码', 'text', 150), f('value', '参数值', 'text', 160), f('description', '说明', 'text', 200), sel('status', '状态', ON_OFF)],
    statusField: 'status', statusLabels: { '1': '启用', '0': '停用' },
    seed: [
      { id: 1, name: '公司名称', code: 'COMPANY_NAME', value: '示例科技有限公司', description: '显示在单据页眉', status: 1 },
      { id: 2, name: '默认仓库', code: 'DEFAULT_WAREHOUSE', value: '主仓库', description: '新建单据默认仓库', status: 1 },
      { id: 3, name: '税率', code: 'DEFAULT_TAX_RATE', value: '13%', description: '默认增值税率', status: 1 },
      { id: 4, name: '单据编号前缀', code: 'NO_PREFIX', value: '按模块', description: '销售SO/采购PO/库存CK', status: 1 },
    ],
  },

  syslogConfigs: {
    collection: 'syslogConfigs', label: '日志配置',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('name', '配置项', 'text', 160), f('code', '配置编码', 'text', 140), f('value', '配置值', 'text', 140), f('description', '说明', 'text', 200)],
    seed: [
      { id: 1, name: '日志保留天数', code: 'LOG_RETENTION_DAYS', value: '180', description: '操作日志保留180天' },
      { id: 2, name: '登录日志级别', code: 'LOGIN_LOG_LEVEL', value: 'INFO', description: '记录登录成功与失败' },
      { id: 3, name: '审计开关', code: 'AUDIT_ENABLED', value: 'true', description: '启用数据变更审计' },
    ],
  },

  sysprintLogs: {
    collection: 'sysprintLogs', label: '打印日志',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('bizType', '业务类型', 'text', 130), f('docNo', '单号', 'text', 150), f('template', '模板', 'text', 160), f('printer', '打印机', 'text', 140), f('copies', '份数', 'number', 80), f('printedAt', '打印时间', 'text', 160)],
    seed: [
      { id: 1, bizType: '销售订单', docNo: 'SO20261116-0001', template: '销售单打印模板(A4)', printer: 'HP-LaserJet', copies: 2, printedAt: '2026-11-17 14:25' },
      { id: 2, bizType: '出货单', docNo: 'SH20261116-0001', template: '发货单打印模板(热敏)', printer: '热敏打印机01', copies: 1, printedAt: '2026-11-16 16:10' },
    ],
  },

  crmQuotations: {
    collection: 'crmQuotations', label: '报价单',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }), f('quoteNo', '报价单号', 'text', 150), f('customerName', '客户', 'text', 160), f('title', '报价标题', 'text', 180), f('amount', '报价金额', 'money', 120), f('validDays', '有效期(天)', 'number', 100), f('quoteDate', '报价日期', 'date', 120), sel('status', '状态', opt(['草稿:草稿', '待审核:待审核', '已通过:已通过', '已失效:已失效'])),
    ],
    statusField: 'status', statusLabels: { 草稿: '草稿', 待审核: '待审核', 已通过: '已通过', 已失效: '已失效' },
    seed: [
      { id: 1, quoteNo: 'QT20261116-0001', customerName: '蓝天实业有限公司', title: '办公用品年度报价', amount: 12800, validDays: 30, quoteDate: '2026-11-16', status: '已通过' }, { id: 2, quoteNo: 'QT20261117-0002', customerName: '广州云科技有限公司', title: '数码设备采购报价', amount: 8600, validDays: 15, quoteDate: '2026-11-17', status: '待审核' },
    ],
  },

  inventoryLedger: {
    collection: 'inventoryLedger', label: '库存流水',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }), f('voucherNo', '流水单号', 'text', 150), f('productName', '产品', 'text', 160), f('warehouseName', '仓库', 'text', 110), f('voucherType', '业务类型', 'text', 120), f('qtyIn', '入库数量', 'number', 100), f('qtyOut', '出库数量', 'number', 100), f('balanceQty', '结存数量', 'number', 100), f('cost', '成本单价', 'money', 110), f('occurredAt', '发生时间', 'text', 160),
    ],
    seed: [
      { id: 1, voucherNo: 'LS20261116-0001', productName: 'A4 复印纸', warehouseName: '主仓库', voucherType: '采购入库', qtyIn: 200, qtyOut: 0, balanceQty: 220, cost: 18, occurredAt: '2026-11-16 10:30' }, { id: 2, voucherNo: 'LS20261116-0002', productName: 'A4 复印纸', warehouseName: '主仓库', voucherType: '销售出库', qtyIn: 0, qtyOut: 100, balanceQty: 120, cost: 18, occurredAt: '2026-11-16 15:20' }, { id: 3, voucherNo: 'LS20261117-0003', productName: '无线鼠标', warehouseName: '主仓库', voucherType: '采购入库', qtyIn: 50, qtyOut: 0, balanceQty: 60, cost: 45, occurredAt: '2026-11-17 09:10' },
    ],
  },

  inventoryAlerts: {
    collection: 'inventoryAlerts', label: '库存预警',
    fields: [
      { prop: 'id', label: 'ID', type: 'text', width: 70 },
      { prop: 'name', label: '名称', type: 'text', width: 170 },
      { prop: 'code', label: '编码', type: 'text', width: 110 },
      { prop: 'description', label: '说明', type: 'text', width: 200 },
      sel('status', '状态', opt(['正常:正常', '停用:停用'])),
    ],
    statusField: 'status', statusLabels: { 正常: '正常', 停用: '停用' },
    seed: [
      { id: 1, name: '库存预警示例一', code: 'INVE001', description: '业务库存预警基础数据', status: '正常' },
      { id: 2, name: '库存预警示例二', code: 'INVE002', description: '按文档定义的库存预警记录', status: '正常' },
      { id: 3, name: '库存预警示例三', code: 'INVE003', description: '可编辑的库存预警数据', status: '正常' },
    ],
  },

  inventoryCategories: {
    collection: 'inventoryCategories', label: '产品分类',
    fields: [
      { prop: 'id', label: 'ID', type: 'text', width: 70 },
      { prop: 'name', label: '名称', type: 'text', width: 170 },
      { prop: 'code', label: '编码', type: 'text', width: 110 },
      { prop: 'description', label: '说明', type: 'text', width: 200 },
      sel('status', '状态', opt(['正常:正常', '停用:停用'])),
    ],
    statusField: 'status', statusLabels: { 正常: '正常', 停用: '停用' },
    seed: [
      { id: 1, name: '产品分类示例一', code: 'INVE001', description: '业务产品分类基础数据', status: '正常' },
      { id: 2, name: '产品分类示例二', code: 'INVE002', description: '按文档定义的产品分类记录', status: '正常' },
      { id: 3, name: '产品分类示例三', code: 'INVE003', description: '可编辑的产品分类数据', status: '正常' },
    ],
  },

  inventoryBrands: {
    collection: 'inventoryBrands', label: '品牌',
    fields: [
      { prop: 'id', label: 'ID', type: 'text', width: 70 },
      { prop: 'name', label: '名称', type: 'text', width: 170 },
      { prop: 'code', label: '编码', type: 'text', width: 110 },
      { prop: 'description', label: '说明', type: 'text', width: 200 },
      sel('status', '状态', opt(['正常:正常', '停用:停用'])),
    ],
    statusField: 'status', statusLabels: { 正常: '正常', 停用: '停用' },
    seed: [
      { id: 1, name: '品牌示例一', code: 'INVE001', description: '业务品牌基础数据', status: '正常' },
      { id: 2, name: '品牌示例二', code: 'INVE002', description: '按文档定义的品牌记录', status: '正常' },
      { id: 3, name: '品牌示例三', code: 'INVE003', description: '可编辑的品牌数据', status: '正常' },
    ],
  },

  inventoryUnits: {
    collection: 'inventoryUnits', label: '计量单位',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }), f('name', '单位名称', 'text', 140), f('code', '单位编码', 'text', 110), f('symbol', '符号', 'text', 90), f('conversion', '换算关系', 'text', 150), sel('status', '状态', ON_OFF),
    ],
    statusField: 'status', statusLabels: { '1': '启用', '0': '停用' },
    seed: [
      { id: 1, name: '个', code: 'PCS', symbol: '个', conversion: '基本单位', status: 1 }, { id: 2, name: '箱', code: 'BOX', symbol: '箱', conversion: '1箱=500个', status: 1 }, { id: 3, name: '千克', code: 'KG', symbol: 'kg', conversion: '1kg=1000g', status: 1 }, { id: 4, name: '米', code: 'M', symbol: 'm', conversion: '1m=100cm', status: 1 },
    ],
  },

  inventoryWarehouses: {
    collection: 'inventoryWarehouses', label: '仓库',
    fields: [
      { prop: 'id', label: 'ID', type: 'text', width: 70 },
      { prop: 'name', label: '名称', type: 'text', width: 170 },
      { prop: 'code', label: '编码', type: 'text', width: 110 },
      { prop: 'description', label: '说明', type: 'text', width: 200 },
      sel('status', '状态', opt(['正常:正常', '停用:停用'])),
    ],
    statusField: 'status', statusLabels: { 正常: '正常', 停用: '停用' },
    seed: [
      { id: 1, name: '仓库示例一', code: 'INVE001', description: '业务仓库基础数据', status: '正常' },
      { id: 2, name: '仓库示例二', code: 'INVE002', description: '按文档定义的仓库记录', status: '正常' },
      { id: 3, name: '仓库示例三', code: 'INVE003', description: '可编辑的仓库数据', status: '正常' },
    ],
  },

  inventoryBatches: {
    collection: 'inventoryBatches', label: '批次',
    fields: [
      { prop: 'id', label: 'ID', type: 'text', width: 70 },
      { prop: 'name', label: '名称', type: 'text', width: 170 },
      { prop: 'code', label: '编码', type: 'text', width: 110 },
      { prop: 'description', label: '说明', type: 'text', width: 200 },
      sel('status', '状态', opt(['正常:正常', '停用:停用'])),
    ],
    statusField: 'status', statusLabels: { 正常: '正常', 停用: '停用' },
    seed: [
      { id: 1, name: '批次示例一', code: 'INVE001', description: '业务批次基础数据', status: '正常' },
      { id: 2, name: '批次示例二', code: 'INVE002', description: '按文档定义的批次记录', status: '正常' },
      { id: 3, name: '批次示例三', code: 'INVE003', description: '可编辑的批次数据', status: '正常' },
    ],
  },

  inventorySerials: {
    collection: 'inventorySerials', label: '序列号/IMEI',
    fields: [
      { prop: 'id', label: 'ID', type: 'text', width: 70 },
      { prop: 'name', label: '名称', type: 'text', width: 170 },
      { prop: 'code', label: '编码', type: 'text', width: 110 },
      { prop: 'description', label: '说明', type: 'text', width: 200 },
      sel('status', '状态', opt(['正常:正常', '停用:停用'])),
    ],
    statusField: 'status', statusLabels: { 正常: '正常', 停用: '停用' },
    seed: [
      { id: 1, name: '序列号/IMEI示例一', code: 'INVE001', description: '业务序列号/IMEI基础数据', status: '正常' },
      { id: 2, name: '序列号/IMEI示例二', code: 'INVE002', description: '按文档定义的序列号/IMEI记录', status: '正常' },
      { id: 3, name: '序列号/IMEI示例三', code: 'INVE003', description: '可编辑的序列号/IMEI数据', status: '正常' },
    ],
  },

  wmsStocktakes: {
    collection: 'wmsStocktakes', label: '库存盘点',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }), f('stocktakeNo', '盘点单号', 'text', 150), f('warehouseName', '盘点仓库', 'text', 120), f('planDate', '盘点日期', 'date', 120), f('totalLines', '盘点行数', 'number', 100), f('diffLines', '差异行数', 'number', 100), f('operator', '盘点人', 'text', 100), sel('status', '状态', opt(['待盘点:待盘点', '盘点中:盘点中', '已完成:已完成'])),
    ],
    statusField: 'status', statusLabels: { 待盘点: '待盘点', 盘点中: '盘点中', 已完成: '已完成' },
    seed: [
      { id: 1, stocktakeNo: 'PD20261115-0001', warehouseName: '主仓库', planDate: '2026-11-15', totalLines: 8, diffLines: 2, operator: '王仓管', status: '已完成' }, { id: 2, stocktakeNo: 'PD20261118-0002', warehouseName: '深圳分仓', planDate: '2026-11-18', totalLines: 5, diffLines: 0, operator: '李仓管', status: '盘点中' },
    ],
  },

  wmsTransfers: {
    collection: 'wmsTransfers', label: '调拨单',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }), f('transferNo', '调拨单号', 'text', 150), f('productName', '产品', 'text', 160), f('fromWarehouse', '调出仓库', 'text', 120), f('toWarehouse', '调入仓库', 'text', 120), f('qty', '调拨数量', 'number', 100), f('operator', '经办人', 'text', 100), f('transferDate', '调拨日期', 'date', 120), sel('status', '状态', opt(['待调拨:待调拨', '已完成:已完成'])),
    ],
    statusField: 'status', statusLabels: { 待调拨: '待调拨', 已完成: '已完成' },
    seed: [
      { id: 1, transferNo: 'DB20261116-0001', productName: 'A4 复印纸', fromWarehouse: '主仓库', toWarehouse: '深圳分仓', qty: 20, operator: '王仓管', transferDate: '2026-11-16', status: '已完成' }, { id: 2, transferNo: 'DB20261118-0002', productName: '无线鼠标', fromWarehouse: '主仓库', toWarehouse: '深圳分仓', qty: 10, operator: '王仓管', transferDate: '2026-11-18', status: '待调拨' },
    ],
  },

  wmsWaves: {
    collection: 'wmsWaves', label: '波次拣货',
    fields: [
      { prop: 'id', label: 'ID', type: 'text', width: 70 },
      { prop: 'name', label: '名称', type: 'text', width: 170 },
      { prop: 'code', label: '编码', type: 'text', width: 110 },
      { prop: 'description', label: '说明', type: 'text', width: 200 },
      sel('status', '状态', opt(['正常:正常', '停用:停用'])),
    ],
    statusField: 'status', statusLabels: { 正常: '正常', 停用: '停用' },
    seed: [
      { id: 1, name: '波次拣货示例一', code: 'WMSW001', description: '业务波次拣货基础数据', status: '正常' },
      { id: 2, name: '波次拣货示例二', code: 'WMSW002', description: '按文档定义的波次拣货记录', status: '正常' },
      { id: 3, name: '波次拣货示例三', code: 'WMSW003', description: '可编辑的波次拣货数据', status: '正常' },
    ],
  },

  wmsPutaways: {
    collection: 'wmsPutaways', label: '上架策略',
    fields: [
      { prop: 'id', label: 'ID', type: 'text', width: 70 },
      { prop: 'name', label: '名称', type: 'text', width: 170 },
      { prop: 'code', label: '编码', type: 'text', width: 110 },
      { prop: 'description', label: '说明', type: 'text', width: 200 },
      sel('status', '状态', opt(['正常:正常', '停用:停用'])),
    ],
    statusField: 'status', statusLabels: { 正常: '正常', 停用: '停用' },
    seed: [
      { id: 1, name: '上架策略示例一', code: 'WMSP001', description: '业务上架策略基础数据', status: '正常' },
      { id: 2, name: '上架策略示例二', code: 'WMSP002', description: '按文档定义的上架策略记录', status: '正常' },
      { id: 3, name: '上架策略示例三', code: 'WMSP003', description: '可编辑的上架策略数据', status: '正常' },
    ],
  },

  wmsCrossdocks: {
    collection: 'wmsCrossdocks', label: '越库直发',
    fields: [
      { prop: 'id', label: 'ID', type: 'text', width: 70 },
      { prop: 'name', label: '名称', type: 'text', width: 170 },
      { prop: 'code', label: '编码', type: 'text', width: 110 },
      { prop: 'description', label: '说明', type: 'text', width: 200 },
      sel('status', '状态', opt(['正常:正常', '停用:停用'])),
    ],
    statusField: 'status', statusLabels: { 正常: '正常', 停用: '停用' },
    seed: [
      { id: 1, name: '越库直发示例一', code: 'WMSC001', description: '业务越库直发基础数据', status: '正常' },
      { id: 2, name: '越库直发示例二', code: 'WMSC002', description: '按文档定义的越库直发记录', status: '正常' },
      { id: 3, name: '越库直发示例三', code: 'WMSC003', description: '可编辑的越库直发数据', status: '正常' },
    ],
  },

  mesRoutings: {
    collection: 'mesRoutings', label: '工艺路线',
    fields: [
      { prop: 'id', label: 'ID', type: 'text', width: 70 },
      { prop: 'name', label: '名称', type: 'text', width: 170 },
      { prop: 'code', label: '编码', type: 'text', width: 110 },
      { prop: 'description', label: '说明', type: 'text', width: 200 },
      sel('status', '状态', opt(['正常:正常', '停用:停用'])),
    ],
    statusField: 'status', statusLabels: { 正常: '正常', 停用: '停用' },
    seed: [
      { id: 1, name: '工艺路线示例一', code: 'MESR001', description: '业务工艺路线基础数据', status: '正常' },
      { id: 2, name: '工艺路线示例二', code: 'MESR002', description: '按文档定义的工艺路线记录', status: '正常' },
      { id: 3, name: '工艺路线示例三', code: 'MESR003', description: '可编辑的工艺路线数据', status: '正常' },
    ],
  },

  mesReports: {
    collection: 'mesReports', label: '工时报工',
    fields: [
      { prop: 'id', label: 'ID', type: 'text', width: 70 },
      { prop: 'name', label: '名称', type: 'text', width: 170 },
      { prop: 'code', label: '编码', type: 'text', width: 110 },
      { prop: 'description', label: '说明', type: 'text', width: 200 },
      sel('status', '状态', opt(['正常:正常', '停用:停用'])),
    ],
    statusField: 'status', statusLabels: { 正常: '正常', 停用: '停用' },
    seed: [
      { id: 1, name: '工时报工示例一', code: 'MESR001', description: '业务工时报工基础数据', status: '正常' },
      { id: 2, name: '工时报工示例二', code: 'MESR002', description: '按文档定义的工时报工记录', status: '正常' },
      { id: 3, name: '工时报工示例三', code: 'MESR003', description: '可编辑的工时报工数据', status: '正常' },
    ],
  },

  mesQc: {
    collection: 'mesQc', label: '质检单',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }), f('qcNo', '质检单号', 'text', 150), f('productName', '产品', 'text', 160), f('batchNo', '批次', 'text', 120), f('checkQty', '抽检数量', 'number', 100), f('passQty', '合格数量', 'number', 100), f('defectQty', '不良数量', 'number', 100), f('inspector', '检验员', 'text', 100), f('checkDate', '检验日期', 'date', 120), sel('result', '检验结果', opt(['合格:合格', '不合格:不合格', '待检:待检'])),
    ],
    statusField: 'result', statusLabels: { 合格: '合格', 不合格: '不合格', 待检: '待检' },
    seed: [
      { id: 1, qcNo: 'QC20261117-0001', productName: '智能温控器', batchNo: 'B20261117', checkQty: 50, passQty: 49, defectQty: 1, inspector: '张质检', checkDate: '2026-11-17', result: '合格' }, { id: 2, qcNo: 'QC20261118-0002', productName: '无线网关', batchNo: 'B20261118', checkQty: 30, passQty: 0, defectQty: 0, inspector: '张质检', checkDate: '2026-11-18', result: '待检' },
    ],
  },

  mesEquipments: {
    collection: 'mesEquipments', label: '设备管理',
    fields: [
      { prop: 'id', label: 'ID', type: 'text', width: 70 },
      { prop: 'name', label: '名称', type: 'text', width: 170 },
      { prop: 'code', label: '编码', type: 'text', width: 110 },
      { prop: 'description', label: '说明', type: 'text', width: 200 },
      sel('status', '状态', opt(['正常:正常', '停用:停用'])),
    ],
    statusField: 'status', statusLabels: { 正常: '正常', 停用: '停用' },
    seed: [
      { id: 1, name: '设备管理示例一', code: 'MESE001', description: '业务设备管理基础数据', status: '正常' },
      { id: 2, name: '设备管理示例二', code: 'MESE002', description: '按文档定义的设备管理记录', status: '正常' },
      { id: 3, name: '设备管理示例三', code: 'MESE003', description: '可编辑的设备管理数据', status: '正常' },
    ],
  },

  financeSubjects: {
    collection: 'financeSubjects', label: '会计科目表',
    fields: [
      { prop: 'id', label: 'ID', type: 'text', width: 70 },
      { prop: 'name', label: '名称', type: 'text', width: 170 },
      { prop: 'code', label: '编码', type: 'text', width: 110 },
      { prop: 'description', label: '说明', type: 'text', width: 200 },
      sel('status', '状态', opt(['正常:正常', '停用:停用'])),
    ],
    statusField: 'status', statusLabels: { 正常: '正常', 停用: '停用' },
    seed: [
      { id: 1, name: '会计科目表示例一', code: 'FINA001', description: '业务会计科目表基础数据', status: '正常' },
      { id: 2, name: '会计科目表示例二', code: 'FINA002', description: '按文档定义的会计科目表记录', status: '正常' },
      { id: 3, name: '会计科目表示例三', code: 'FINA003', description: '可编辑的会计科目表数据', status: '正常' },
    ],
  },

  financeAccounts: {
    collection: 'financeAccounts', label: '账户列表',
    fields: [
      { prop: 'id', label: 'ID', type: 'text', width: 70 },
      { prop: 'name', label: '名称', type: 'text', width: 170 },
      { prop: 'code', label: '编码', type: 'text', width: 110 },
      { prop: 'description', label: '说明', type: 'text', width: 200 },
      sel('status', '状态', opt(['正常:正常', '停用:停用'])),
    ],
    statusField: 'status', statusLabels: { 正常: '正常', 停用: '停用' },
    seed: [
      { id: 1, name: '账户列表示例一', code: 'FINA001', description: '业务账户列表基础数据', status: '正常' },
      { id: 2, name: '账户列表示例二', code: 'FINA002', description: '按文档定义的账户列表记录', status: '正常' },
      { id: 3, name: '账户列表示例三', code: 'FINA003', description: '可编辑的账户列表数据', status: '正常' },
    ],
  },

  financeTransfers: {
    collection: 'financeTransfers', label: '资金转账',
    fields: [
      { prop: 'id', label: 'ID', type: 'text', width: 70 },
      { prop: 'name', label: '名称', type: 'text', width: 170 },
      { prop: 'code', label: '编码', type: 'text', width: 110 },
      { prop: 'description', label: '说明', type: 'text', width: 200 },
      sel('status', '状态', opt(['正常:正常', '停用:停用'])),
    ],
    statusField: 'status', statusLabels: { 正常: '正常', 停用: '停用' },
    seed: [
      { id: 1, name: '资金转账示例一', code: 'FINA001', description: '业务资金转账基础数据', status: '正常' },
      { id: 2, name: '资金转账示例二', code: 'FINA002', description: '按文档定义的资金转账记录', status: '正常' },
      { id: 3, name: '资金转账示例三', code: 'FINA003', description: '可编辑的资金转账数据', status: '正常' },
    ],
  },

  financeExpenses: {
    collection: 'financeExpenses', label: '清单费用',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }), f('expenseNo', '费用单号', 'text', 150), f('category', '费用类别', 'text', 120), f('description', '费用说明', 'text', 200), f('amount', '金额', 'money', 120), f('expenseDate', '发生日期', 'date', 120), f('handler', '经办人', 'text', 100), sel('status', '状态', opt(DOC_STATUS_LABELS)),
    ],
    statusField: 'status', statusLabels: DOC_STATUS,
    seed: [
      { id: 1, expenseNo: 'FY20261110-0001', category: '差旅费', description: '深圳出差交通住宿', amount: 1200, expenseDate: '2026-11-10', handler: '张伟', status: '已确认' }, { id: 2, expenseNo: 'FY20261115-0002', category: '办公费', description: '办公用品采购', amount: 560, expenseDate: '2026-11-15', handler: '李娜', status: '待审核' },
    ],
  },

  financeIncomes: {
    collection: 'financeIncomes', label: '收入列表',
    fields: [
      { prop: 'id', label: 'ID', type: 'text', width: 70 },
      { prop: 'name', label: '名称', type: 'text', width: 170 },
      { prop: 'code', label: '编码', type: 'text', width: 110 },
      { prop: 'description', label: '说明', type: 'text', width: 200 },
      sel('status', '状态', opt(['正常:正常', '停用:停用'])),
    ],
    statusField: 'status', statusLabels: { 正常: '正常', 停用: '停用' },
    seed: [
      { id: 1, name: '收入列表示例一', code: 'FINA001', description: '业务收入列表基础数据', status: '正常' },
      { id: 2, name: '收入列表示例二', code: 'FINA002', description: '按文档定义的收入列表记录', status: '正常' },
      { id: 3, name: '收入列表示例三', code: 'FINA003', description: '可编辑的收入列表数据', status: '正常' },
    ],
  },

  financeExpenseCategories: {
    collection: 'financeExpenseCategories', label: '费用类别',
    fields: [
      { prop: 'id', label: 'ID', type: 'text', width: 70 },
      { prop: 'name', label: '名称', type: 'text', width: 170 },
      { prop: 'code', label: '编码', type: 'text', width: 110 },
      { prop: 'description', label: '说明', type: 'text', width: 200 },
      sel('status', '状态', opt(['正常:正常', '停用:停用'])),
    ],
    statusField: 'status', statusLabels: { 正常: '正常', 停用: '停用' },
    seed: [
      { id: 1, name: '费用类别示例一', code: 'FINA001', description: '业务费用类别基础数据', status: '正常' },
      { id: 2, name: '费用类别示例二', code: 'FINA002', description: '按文档定义的费用类别记录', status: '正常' },
      { id: 3, name: '费用类别示例三', code: 'FINA003', description: '可编辑的费用类别数据', status: '正常' },
    ],
  },

  financeIncomeCategories: {
    collection: 'financeIncomeCategories', label: '收入类别',
    fields: [
      { prop: 'id', label: 'ID', type: 'text', width: 70 },
      { prop: 'name', label: '名称', type: 'text', width: 170 },
      { prop: 'code', label: '编码', type: 'text', width: 110 },
      { prop: 'description', label: '说明', type: 'text', width: 200 },
      sel('status', '状态', opt(['正常:正常', '停用:停用'])),
    ],
    statusField: 'status', statusLabels: { 正常: '正常', 停用: '停用' },
    seed: [
      { id: 1, name: '收入类别示例一', code: 'FINA001', description: '业务收入类别基础数据', status: '正常' },
      { id: 2, name: '收入类别示例二', code: 'FINA002', description: '按文档定义的收入类别记录', status: '正常' },
      { id: 3, name: '收入类别示例三', code: 'FINA003', description: '可编辑的收入类别数据', status: '正常' },
    ],
  },

  financeReceivables: {
    collection: 'financeReceivables', label: '应收账单',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }), f('billNo', '账单号', 'text', 150), f('customerName', '客户', 'text', 170), f('sourceNo', '来源单据', 'text', 150), f('amount', '应收金额', 'money', 120), f('paidAmount', '已收金额', 'money', 120), f('remainAmount', '未收金额', 'money', 120), f('dueDate', '到期日期', 'date', 120), sel('status', '状态', opt(['未收款:未收款', '部分收款:部分收款', '已结清:已结清', '已逾期:已逾期'])),
    ],
    statusField: 'status', statusLabels: { 未收款: '未收款', 部分收款: '部分收款', 已结清: '已结清', 已逾期: '已逾期' },
    seed: [
      { id: 1, billNo: 'YS20261116-0001', customerName: '蓝天实业有限公司', sourceNo: 'SO20261116-0001', amount: 12800, paidAmount: 8000, remainAmount: 4800, dueDate: '2026-12-16', status: '部分收款' }, { id: 2, billNo: 'YS20261117-0002', customerName: '深圳好再来商贸', sourceNo: 'SO20261117-0002', amount: 3200, paidAmount: 0, remainAmount: 3200, dueDate: '2026-12-17', status: '未收款' },
    ],
  },

  financePaymentsIn: {
    collection: 'financePaymentsIn', label: '收款单',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }), f('payNo', '收款单号', 'text', 150), f('customerName', '客户', 'text', 170), f('amount', '收款金额', 'money', 120), f('payMethod', '收款方式', 'text', 110), f('payDate', '收款日期', 'date', 120), f('handler', '经办人', 'text', 100), f('remark', '备注', 'text', 180), sel('status', '状态', opt(['待确认:待确认', '已确认:已确认'])),
    ],
    statusField: 'status', statusLabels: { 待确认: '待确认', 已确认: '已确认' },
    seed: [
      { id: 1, payNo: 'SK20261116-0001', customerName: '蓝天实业有限公司', amount: 8000, payMethod: '银行转账', payDate: '2026-11-16', handler: '陈会计', remark: '部分货款', status: '已确认' }, { id: 2, payNo: 'SK20261117-0002', customerName: '东莞精工制造厂', amount: 5600, payMethod: '微信', payDate: '2026-11-17', handler: '陈会计', remark: '结清应收款', status: '已确认' },
    ],
  },

  financePayables: {
    collection: 'financePayables', label: '应付账单',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }), f('billNo', '账单号', 'text', 150), f('supplierName', '供应商', 'text', 170), f('sourceNo', '来源单据', 'text', 150), f('amount', '应付金额', 'money', 120), f('paidAmount', '已付金额', 'money', 120), f('remainAmount', '未付金额', 'money', 120), f('dueDate', '到期日期', 'date', 120), sel('status', '状态', opt(['未付款:未付款', '部分付款:部分付款', '已结清:已结清', '已逾期:已逾期'])),
    ],
    statusField: 'status', statusLabels: { 未付款: '未付款', 部分付款: '部分付款', 已结清: '已结清', 已逾期: '已逾期' },
    seed: [
      { id: 1, billNo: 'YF20261115-0001', supplierName: '得力集团深圳分公司', sourceNo: 'PO20261115-0001', amount: 3600, paidAmount: 0, remainAmount: 3600, dueDate: '2026-12-15', status: '未付款' }, { id: 2, billNo: 'YF20261116-0002', supplierName: '华强北电子批发', sourceNo: 'PO20261116-0001', amount: 2250, paidAmount: 1000, remainAmount: 1250, dueDate: '2026-12-16', status: '部分付款' },
    ],
  },

  financePaymentsOut: {
    collection: 'financePaymentsOut', label: '付款单',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }), f('payNo', '付款单号', 'text', 150), f('supplierName', '供应商', 'text', 170), f('amount', '付款金额', 'money', 120), f('payMethod', '付款方式', 'text', 110), f('payDate', '付款日期', 'date', 120), f('handler', '经办人', 'text', 100), f('remark', '备注', 'text', 180), sel('status', '状态', opt(['待确认:待确认', '已确认:已确认'])),
    ],
    statusField: 'status', statusLabels: { 待确认: '待确认', 已确认: '已确认' },
    seed: [
      { id: 1, payNo: 'FK20261116-0001', supplierName: '华强北电子批发', amount: 1000, payMethod: '银行转账', payDate: '2026-11-16', handler: '陈会计', remark: '部分货款', status: '已确认' },
    ],
  },

  financeReceivableAging: {
    collection: 'financeReceivableAging', label: '账龄分析',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }), f('customerName', '客户', 'text', 170), f('billNo', '账单号', 'text', 140), f('amount', '应收金额', 'money', 120), f('ageDays', '账龄(天)', 'number', 100), sel('bucket', '账龄区间', opt(['0-30天:0-30天', '31-60天:31-60天', '61-90天:61-90天', '90天以上:90天以上'])), f('amount30', '30天以内', 'money', 110), f('amount60', '31-60天', 'money', 110), f('amount90', '61-90天', 'money', 110), f('amountOver90', '90天以上', 'money', 110),
    ],
    seed: [
      { id: 1, customerName: '蓝天实业有限公司', billNo: 'YS20261116-0001', amount: 4800, ageDays: 2, bucket: '0-30天', amount30: 4800, amount60: 0, amount90: 0, amountOver90: 0 }, { id: 2, customerName: '东莞精工制造厂', billNo: 'YS20261015-0003', amount: 5600, ageDays: 34, bucket: '31-60天', amount30: 0, amount60: 5600, amount90: 0, amountOver90: 0 },
    ],
  },

  financeAssets: {
    collection: 'financeAssets', label: '固定资产',
    fields: [
      { prop: 'id', label: 'ID', type: 'text', width: 70 },
      { prop: 'name', label: '名称', type: 'text', width: 170 },
      { prop: 'code', label: '编码', type: 'text', width: 110 },
      { prop: 'description', label: '说明', type: 'text', width: 200 },
      sel('status', '状态', opt(['正常:正常', '停用:停用'])),
    ],
    statusField: 'status', statusLabels: { 正常: '正常', 停用: '停用' },
    seed: [
      { id: 1, name: '固定资产示例一', code: 'FINA001', description: '业务固定资产基础数据', status: '正常' },
      { id: 2, name: '固定资产示例二', code: 'FINA002', description: '按文档定义的固定资产记录', status: '正常' },
      { id: 3, name: '固定资产示例三', code: 'FINA003', description: '可编辑的固定资产数据', status: '正常' },
    ],
  },

  financeDepreciations: {
    collection: 'financeDepreciations', label: '折旧',
    fields: [
      { prop: 'id', label: 'ID', type: 'text', width: 70 },
      { prop: 'name', label: '名称', type: 'text', width: 170 },
      { prop: 'code', label: '编码', type: 'text', width: 110 },
      { prop: 'description', label: '说明', type: 'text', width: 200 },
      sel('status', '状态', opt(['正常:正常', '停用:停用'])),
    ],
    statusField: 'status', statusLabels: { 正常: '正常', 停用: '停用' },
    seed: [
      { id: 1, name: '折旧示例一', code: 'FINA001', description: '业务折旧基础数据', status: '正常' },
      { id: 2, name: '折旧示例二', code: 'FINA002', description: '按文档定义的折旧记录', status: '正常' },
      { id: 3, name: '折旧示例三', code: 'FINA003', description: '可编辑的折旧数据', status: '正常' },
    ],
  },

  financeInvoices: {
    collection: 'financeInvoices', label: '发票登记',
    fields: [
      { prop: 'id', label: 'ID', type: 'text', width: 70 },
      { prop: 'name', label: '名称', type: 'text', width: 170 },
      { prop: 'code', label: '编码', type: 'text', width: 110 },
      { prop: 'description', label: '说明', type: 'text', width: 200 },
      sel('status', '状态', opt(['正常:正常', '停用:停用'])),
    ],
    statusField: 'status', statusLabels: { 正常: '正常', 停用: '停用' },
    seed: [
      { id: 1, name: '发票登记示例一', code: 'FINA001', description: '业务发票登记基础数据', status: '正常' },
      { id: 2, name: '发票登记示例二', code: 'FINA002', description: '按文档定义的发票登记记录', status: '正常' },
      { id: 3, name: '发票登记示例三', code: 'FINA003', description: '可编辑的发票登记数据', status: '正常' },
    ],
  },

  financeTrialBalance: {
    collection: 'financeTrialBalance', label: '试算平衡表',
    fields: [
      { prop: 'id', label: 'ID', type: 'text', width: 70 },
      { prop: 'name', label: '名称', type: 'text', width: 170 },
      { prop: 'code', label: '编码', type: 'text', width: 110 },
      { prop: 'description', label: '说明', type: 'text', width: 200 },
      sel('status', '状态', opt(['正常:正常', '停用:停用'])),
    ],
    statusField: 'status', statusLabels: { 正常: '正常', 停用: '停用' },
    seed: [
      { id: 1, name: '试算平衡表示例一', code: 'FINA001', description: '业务试算平衡表基础数据', status: '正常' },
      { id: 2, name: '试算平衡表示例二', code: 'FINA002', description: '按文档定义的试算平衡表记录', status: '正常' },
      { id: 3, name: '试算平衡表示例三', code: 'FINA003', description: '可编辑的试算平衡表数据', status: '正常' },
    ],
  },

  financePeriods: {
    collection: 'financePeriods', label: '期末结账',
    fields: [
      { prop: 'id', label: 'ID', type: 'text', width: 70 },
      { prop: 'name', label: '名称', type: 'text', width: 170 },
      { prop: 'code', label: '编码', type: 'text', width: 110 },
      { prop: 'description', label: '说明', type: 'text', width: 200 },
      sel('status', '状态', opt(['正常:正常', '停用:停用'])),
    ],
    statusField: 'status', statusLabels: { 正常: '正常', 停用: '停用' },
    seed: [
      { id: 1, name: '期末结账示例一', code: 'FINA001', description: '业务期末结账基础数据', status: '正常' },
      { id: 2, name: '期末结账示例二', code: 'FINA002', description: '按文档定义的期末结账记录', status: '正常' },
      { id: 3, name: '期末结账示例三', code: 'FINA003', description: '可编辑的期末结账数据', status: '正常' },
    ],
  },

  financeCosts: {
    collection: 'financeCosts', label: '成本核算',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }), f('period', '核算期间', 'text', 110), f('productName', '产品', 'text', 160), f('beginCost', '期初成本', 'money', 120), f('purchaseCost', '本期入库', 'money', 120), f('saleCost', '本期发出', 'money', 120), f('endCost', '期末成本', 'money', 120), f('avgCost', '加权均价', 'money', 110),
    ],
    seed: [
      { id: 1, period: '2026-11', productName: 'A4 复印纸', beginCost: 360, purchaseCost: 3600, saleCost: 1800, endCost: 2160, avgCost: 18 }, { id: 2, period: '2026-11', productName: '无线鼠标', beginCost: 450, purchaseCost: 2250, saleCost: 900, endCost: 1800, avgCost: 45 },
    ],
  },

  collabChat: {
    collection: 'collabChat', label: '企业聊天',
    fields: [
      { prop: 'id', label: 'ID', type: 'text', width: 70 },
      { prop: 'name', label: '名称', type: 'text', width: 170 },
      { prop: 'code', label: '编码', type: 'text', width: 110 },
      { prop: 'description', label: '说明', type: 'text', width: 200 },
      sel('status', '状态', opt(['正常:正常', '停用:停用'])),
    ],
    statusField: 'status', statusLabels: { 正常: '正常', 停用: '停用' },
    seed: [
      { id: 1, name: '企业聊天示例一', code: 'COLL001', description: '业务企业聊天基础数据', status: '正常' },
      { id: 2, name: '企业聊天示例二', code: 'COLL002', description: '按文档定义的企业聊天记录', status: '正常' },
      { id: 3, name: '企业聊天示例三', code: 'COLL003', description: '可编辑的企业聊天数据', status: '正常' },
    ],
  },

  collabNotices: {
    collection: 'collabNotices', label: '公告',
    fields: [
      { prop: 'id', label: 'ID', type: 'text', width: 70 },
      { prop: 'name', label: '名称', type: 'text', width: 170 },
      { prop: 'code', label: '编码', type: 'text', width: 110 },
      { prop: 'description', label: '说明', type: 'text', width: 200 },
      sel('status', '状态', opt(['正常:正常', '停用:停用'])),
    ],
    statusField: 'status', statusLabels: { 正常: '正常', 停用: '停用' },
    seed: [
      { id: 1, name: '公告示例一', code: 'COLL001', description: '业务公告基础数据', status: '正常' },
      { id: 2, name: '公告示例二', code: 'COLL002', description: '按文档定义的公告记录', status: '正常' },
      { id: 3, name: '公告示例三', code: 'COLL003', description: '可编辑的公告数据', status: '正常' },
    ],
  },

  collabMeetings: {
    collection: 'collabMeetings', label: '会议',
    fields: [
      { prop: 'id', label: 'ID', type: 'text', width: 70 },
      { prop: 'name', label: '名称', type: 'text', width: 170 },
      { prop: 'code', label: '编码', type: 'text', width: 110 },
      { prop: 'description', label: '说明', type: 'text', width: 200 },
      sel('status', '状态', opt(['正常:正常', '停用:停用'])),
    ],
    statusField: 'status', statusLabels: { 正常: '正常', 停用: '停用' },
    seed: [
      { id: 1, name: '会议示例一', code: 'COLL001', description: '业务会议基础数据', status: '正常' },
      { id: 2, name: '会议示例二', code: 'COLL002', description: '按文档定义的会议记录', status: '正常' },
      { id: 3, name: '会议示例三', code: 'COLL003', description: '可编辑的会议数据', status: '正常' },
    ],
  },

  collabProjects: {
    collection: 'collabProjects', label: '项目',
    fields: [
      { prop: 'id', label: 'ID', type: 'text', width: 70 },
      { prop: 'name', label: '名称', type: 'text', width: 170 },
      { prop: 'code', label: '编码', type: 'text', width: 110 },
      { prop: 'description', label: '说明', type: 'text', width: 200 },
      sel('status', '状态', opt(['正常:正常', '停用:停用'])),
    ],
    statusField: 'status', statusLabels: { 正常: '正常', 停用: '停用' },
    seed: [
      { id: 1, name: '项目示例一', code: 'COLL001', description: '业务项目基础数据', status: '正常' },
      { id: 2, name: '项目示例二', code: 'COLL002', description: '按文档定义的项目记录', status: '正常' },
      { id: 3, name: '项目示例三', code: 'COLL003', description: '可编辑的项目数据', status: '正常' },
    ],
  },

  collabBoard: {
    collection: 'collabBoard', label: '任务板',
    fields: [
      { prop: 'id', label: 'ID', type: 'text', width: 70 },
      { prop: 'name', label: '名称', type: 'text', width: 170 },
      { prop: 'code', label: '编码', type: 'text', width: 110 },
      { prop: 'description', label: '说明', type: 'text', width: 200 },
      sel('status', '状态', opt(['正常:正常', '停用:停用'])),
    ],
    statusField: 'status', statusLabels: { 正常: '正常', 停用: '停用' },
    seed: [
      { id: 1, name: '任务板示例一', code: 'COLL001', description: '业务任务板基础数据', status: '正常' },
      { id: 2, name: '任务板示例二', code: 'COLL002', description: '按文档定义的任务板记录', status: '正常' },
      { id: 3, name: '任务板示例三', code: 'COLL003', description: '可编辑的任务板数据', status: '正常' },
    ],
  },

  collabMilestones: {
    collection: 'collabMilestones', label: '里程碑',
    fields: [
      { prop: 'id', label: 'ID', type: 'text', width: 70 },
      { prop: 'name', label: '名称', type: 'text', width: 170 },
      { prop: 'code', label: '编码', type: 'text', width: 110 },
      { prop: 'description', label: '说明', type: 'text', width: 200 },
      sel('status', '状态', opt(['正常:正常', '停用:停用'])),
    ],
    statusField: 'status', statusLabels: { 正常: '正常', 停用: '停用' },
    seed: [
      { id: 1, name: '里程碑示例一', code: 'COLL001', description: '业务里程碑基础数据', status: '正常' },
      { id: 2, name: '里程碑示例二', code: 'COLL002', description: '按文档定义的里程碑记录', status: '正常' },
      { id: 3, name: '里程碑示例三', code: 'COLL003', description: '可编辑的里程碑数据', status: '正常' },
    ],
  },

  collabProjectReports: {
    collection: 'collabProjectReports', label: '项目报告',
    fields: [
      { prop: 'id', label: 'ID', type: 'text', width: 70 },
      { prop: 'name', label: '名称', type: 'text', width: 170 },
      { prop: 'code', label: '编码', type: 'text', width: 110 },
      { prop: 'description', label: '说明', type: 'text', width: 200 },
      sel('status', '状态', opt(['正常:正常', '停用:停用'])),
    ],
    statusField: 'status', statusLabels: { 正常: '正常', 停用: '停用' },
    seed: [
      { id: 1, name: '项目报告示例一', code: 'COLL001', description: '业务项目报告基础数据', status: '正常' },
      { id: 2, name: '项目报告示例二', code: 'COLL002', description: '按文档定义的项目报告记录', status: '正常' },
      { id: 3, name: '项目报告示例三', code: 'COLL003', description: '可编辑的项目报告数据', status: '正常' },
    ],
  },

  collabFiles: {
    collection: 'collabFiles', label: '文件档案',
    fields: [
      { prop: 'id', label: 'ID', type: 'text', width: 70 },
      { prop: 'name', label: '名称', type: 'text', width: 170 },
      { prop: 'code', label: '编码', type: 'text', width: 110 },
      { prop: 'description', label: '说明', type: 'text', width: 200 },
      sel('status', '状态', opt(['正常:正常', '停用:停用'])),
    ],
    statusField: 'status', statusLabels: { 正常: '正常', 停用: '停用' },
    seed: [
      { id: 1, name: '文件档案示例一', code: 'COLL001', description: '业务文件档案基础数据', status: '正常' },
      { id: 2, name: '文件档案示例二', code: 'COLL002', description: '按文档定义的文件档案记录', status: '正常' },
      { id: 3, name: '文件档案示例三', code: 'COLL003', description: '可编辑的文件档案数据', status: '正常' },
    ],
  },

  aiRagDocs: {
    collection: 'aiRagDocs', label: '知识库',
    fields: [
      { prop: 'id', label: 'ID', type: 'text', width: 70 },
      { prop: 'name', label: '名称', type: 'text', width: 170 },
      { prop: 'code', label: '编码', type: 'text', width: 110 },
      { prop: 'description', label: '说明', type: 'text', width: 200 },
      sel('status', '状态', opt(['正常:正常', '停用:停用'])),
    ],
    statusField: 'status', statusLabels: { 正常: '正常', 停用: '停用' },
    seed: [
      { id: 1, name: '知识库示例一', code: 'AIRA001', description: '业务知识库基础数据', status: '正常' },
      { id: 2, name: '知识库示例二', code: 'AIRA002', description: '按文档定义的知识库记录', status: '正常' },
      { id: 3, name: '知识库示例三', code: 'AIRA003', description: '可编辑的知识库数据', status: '正常' },
    ],
  },

  systemOrgs: {
    collection: 'systemOrgs', label: '公司',
    fields: [
      { prop: 'id', label: 'ID', type: 'text', width: 70 },
      { prop: 'name', label: '名称', type: 'text', width: 170 },
      { prop: 'code', label: '编码', type: 'text', width: 110 },
      { prop: 'description', label: '说明', type: 'text', width: 200 },
      sel('status', '状态', opt(['正常:正常', '停用:停用'])),
    ],
    statusField: 'status', statusLabels: { 正常: '正常', 停用: '停用' },
    seed: [
      { id: 1, name: '公司示例一', code: 'SYST001', description: '业务公司基础数据', status: '正常' },
      { id: 2, name: '公司示例二', code: 'SYST002', description: '按文档定义的公司记录', status: '正常' },
      { id: 3, name: '公司示例三', code: 'SYST003', description: '可编辑的公司数据', status: '正常' },
    ],
  },

  hrShifts: {
    collection: 'hrShifts', label: '班次',
    fields: [
      { prop: 'id', label: 'ID', type: 'text', width: 70 },
      { prop: 'name', label: '名称', type: 'text', width: 170 },
      { prop: 'code', label: '编码', type: 'text', width: 110 },
      { prop: 'description', label: '说明', type: 'text', width: 200 },
      sel('status', '状态', opt(['正常:正常', '停用:停用'])),
    ],
    statusField: 'status', statusLabels: { 正常: '正常', 停用: '停用' },
    seed: [
      { id: 1, name: '班次示例一', code: 'HRSH001', description: '业务班次基础数据', status: '正常' },
      { id: 2, name: '班次示例二', code: 'HRSH002', description: '按文档定义的班次记录', status: '正常' },
      { id: 3, name: '班次示例三', code: 'HRSH003', description: '可编辑的班次数据', status: '正常' },
    ],
  },

  hrLeaves: {
    collection: 'hrLeaves', label: '请假',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }), f('leaveNo', '请假单号', 'text', 150), f('employeeName', '员工', 'text', 110), f('leaveType', '假别', 'text', 100), f('startDate', '开始日期', 'date', 120), f('endDate', '结束日期', 'date', 120), f('days', '天数', 'number', 90), f('reason', '事由', 'text', 180), sel('status', '状态', opt(['待审:待审', '通过:通过', '驳回:驳回'])),
    ],
    statusField: 'status', statusLabels: { 待审: '待审', 通过: '通过', 驳回: '驳回' },
    seed: [
      { id: 1, leaveNo: 'QJ20261101-0001', employeeName: '李娜', leaveType: '年假', startDate: '2026-11-20', endDate: '2026-11-22', days: 3, reason: '个人事务', status: '待审' }, { id: 2, leaveNo: 'QJ20261110-0002', employeeName: '张伟', leaveType: '事假', startDate: '2026-11-10', endDate: '2026-11-10', days: 1, reason: '家中有事', status: '通过' },
    ],
  },

  hrHolidays: {
    collection: 'hrHolidays', label: '节假日',
    fields: [
      { prop: 'id', label: 'ID', type: 'text', width: 70 },
      { prop: 'name', label: '名称', type: 'text', width: 170 },
      { prop: 'code', label: '编码', type: 'text', width: 110 },
      { prop: 'description', label: '说明', type: 'text', width: 200 },
      sel('status', '状态', opt(['正常:正常', '停用:停用'])),
    ],
    statusField: 'status', statusLabels: { 正常: '正常', 停用: '停用' },
    seed: [
      { id: 1, name: '节假日示例一', code: 'HRHO001', description: '业务节假日基础数据', status: '正常' },
      { id: 2, name: '节假日示例二', code: 'HRHO002', description: '按文档定义的节假日记录', status: '正常' },
      { id: 3, name: '节假日示例三', code: 'HRHO003', description: '可编辑的节假日数据', status: '正常' },
    ],
  },

  hrPayrolls: {
    collection: 'hrPayrolls', label: '工资单',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }), f('period', '期间', 'text', 100), f('employeeName', '员工', 'text', 110), f('department', '部门', 'text', 120), f('baseSalary', '基本工资', 'money', 120), f('bonus', '绩效奖金', 'money', 120), f('allowance', '补贴', 'money', 110), f('deduction', '扣款', 'money', 110), f('netSalary', '实发工资', 'money', 120), sel('status', '状态', opt(['草稿:草稿', '已发放:已发放'])),
    ],
    statusField: 'status', statusLabels: { 草稿: '草稿', 已发放: '已发放' },
    seed: [
      { id: 1, period: '2026-10', employeeName: '张伟', department: '销售部', baseSalary: 12000, bonus: 3000, allowance: 500, deduction: 800, netSalary: 14700, status: '已发放' }, { id: 2, period: '2026-10', employeeName: '李娜', department: '采购部', baseSalary: 8000, bonus: 1500, allowance: 300, deduction: 500, netSalary: 9300, status: '已发放' },
    ],
  },

  hrContracts: {
    collection: 'hrContracts', label: '合约',
    fields: [
      { prop: 'id', label: 'ID', type: 'text', width: 70 },
      { prop: 'name', label: '名称', type: 'text', width: 170 },
      { prop: 'code', label: '编码', type: 'text', width: 110 },
      { prop: 'description', label: '说明', type: 'text', width: 200 },
      sel('status', '状态', opt(['正常:正常', '停用:停用'])),
    ],
    statusField: 'status', statusLabels: { 正常: '正常', 停用: '停用' },
    seed: [
      { id: 1, name: '合约示例一', code: 'HRCO001', description: '业务合约基础数据', status: '正常' },
      { id: 2, name: '合约示例二', code: 'HRCO002', description: '按文档定义的合约记录', status: '正常' },
      { id: 3, name: '合约示例三', code: 'HRCO003', description: '可编辑的合约数据', status: '正常' },
    ],
  },

  crmLeads: {
    collection: 'crmLeads', label: '候选人',
    fields: [
      { prop: 'id', label: 'ID', type: 'text', width: 70 },
      { prop: 'name', label: '名称', type: 'text', width: 170 },
      { prop: 'code', label: '编码', type: 'text', width: 110 },
      { prop: 'description', label: '说明', type: 'text', width: 200 },
      sel('status', '状态', opt(['正常:正常', '停用:停用'])),
    ],
    statusField: 'status', statusLabels: { 正常: '正常', 停用: '停用' },
    seed: [
      { id: 1, name: '候选人示例一', code: 'CRML001', description: '业务候选人基础数据', status: '正常' },
      { id: 2, name: '候选人示例二', code: 'CRML002', description: '按文档定义的候选人记录', status: '正常' },
      { id: 3, name: '候选人示例三', code: 'CRML003', description: '可编辑的候选人数据', status: '正常' },
    ],
  },

  hrInterviews: {
    collection: 'hrInterviews', label: '面试',
    fields: [
      { prop: 'id', label: 'ID', type: 'text', width: 70 },
      { prop: 'name', label: '名称', type: 'text', width: 170 },
      { prop: 'code', label: '编码', type: 'text', width: 110 },
      { prop: 'description', label: '说明', type: 'text', width: 200 },
      sel('status', '状态', opt(['正常:正常', '停用:停用'])),
    ],
    statusField: 'status', statusLabels: { 正常: '正常', 停用: '停用' },
    seed: [
      { id: 1, name: '面试示例一', code: 'HRIN001', description: '业务面试基础数据', status: '正常' },
      { id: 2, name: '面试示例二', code: 'HRIN002', description: '按文档定义的面试记录', status: '正常' },
      { id: 3, name: '面试示例三', code: 'HRIN003', description: '可编辑的面试数据', status: '正常' },
    ],
  },

  hrAssets: {
    collection: 'hrAssets', label: '资产领用',
    fields: [
      { prop: 'id', label: 'ID', type: 'text', width: 70 },
      { prop: 'name', label: '名称', type: 'text', width: 170 },
      { prop: 'code', label: '编码', type: 'text', width: 110 },
      { prop: 'description', label: '说明', type: 'text', width: 200 },
      sel('status', '状态', opt(['正常:正常', '停用:停用'])),
    ],
    statusField: 'status', statusLabels: { 正常: '正常', 停用: '停用' },
    seed: [
      { id: 1, name: '资产领用示例一', code: 'HRAS001', description: '业务资产领用基础数据', status: '正常' },
      { id: 2, name: '资产领用示例二', code: 'HRAS002', description: '按文档定义的资产领用记录', status: '正常' },
      { id: 3, name: '资产领用示例三', code: 'HRAS003', description: '可编辑的资产领用数据', status: '正常' },
    ],
  },

  hrVehicles: {
    collection: 'hrVehicles', label: '车辆管理',
    fields: [
      { prop: 'id', label: 'ID', type: 'text', width: 70 },
      { prop: 'name', label: '名称', type: 'text', width: 170 },
      { prop: 'code', label: '编码', type: 'text', width: 110 },
      { prop: 'description', label: '说明', type: 'text', width: 200 },
      sel('status', '状态', opt(['正常:正常', '停用:停用'])),
    ],
    statusField: 'status', statusLabels: { 正常: '正常', 停用: '停用' },
    seed: [
      { id: 1, name: '车辆管理示例一', code: 'HRVE001', description: '业务车辆管理基础数据', status: '正常' },
      { id: 2, name: '车辆管理示例二', code: 'HRVE002', description: '按文档定义的车辆管理记录', status: '正常' },
      { id: 3, name: '车辆管理示例三', code: 'HRVE003', description: '可编辑的车辆管理数据', status: '正常' },
    ],
  },

  shopStores: {
    collection: 'shopStores', label: '线上店铺',
    fields: [
      { prop: 'id', label: 'ID', type: 'text', width: 70 },
      { prop: 'name', label: '名称', type: 'text', width: 170 },
      { prop: 'code', label: '编码', type: 'text', width: 110 },
      { prop: 'description', label: '说明', type: 'text', width: 200 },
      sel('status', '状态', opt(['正常:正常', '停用:停用'])),
    ],
    statusField: 'status', statusLabels: { 正常: '正常', 停用: '停用' },
    seed: [
      { id: 1, name: '线上店铺示例一', code: 'SHOP001', description: '业务线上店铺基础数据', status: '正常' },
      { id: 2, name: '线上店铺示例二', code: 'SHOP002', description: '按文档定义的线上店铺记录', status: '正常' },
      { id: 3, name: '线上店铺示例三', code: 'SHOP003', description: '可编辑的线上店铺数据', status: '正常' },
    ],
  },

  shopChannels: {
    collection: 'shopChannels', label: '渠道配置',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }), f('name', '渠道名称', 'text', 150), f('code', '渠道编码', 'text', 110), f('type', '渠道类型', 'text', 120), f('manager', '负责人', 'text', 110), f('commissionRate', '佣金比例', 'text', 110), f('settlementCycle', '结算周期', 'text', 120), sel('status', '状态', ON_OFF),
    ],
    statusField: 'status', statusLabels: { '1': '启用', '0': '停用' },
    seed: [
      { id: 1, name: '天猫旗舰店', code: 'CH_TMALL', type: '电商平台', manager: '张销售', commissionRate: '5%', settlementCycle: '月结', status: 1 }, { id: 2, name: '微信小程序', code: 'CH_WX', type: '社交电商', manager: '李业务', commissionRate: '0%', settlementCycle: '实时', status: 1 }, { id: 3, name: '线下经销商', code: 'CH_DEALER', type: '线下渠道', manager: '王渠道', commissionRate: '15%', settlementCycle: '季结', status: 1 },
    ],
  },

  shopGoodsMaps: {
    collection: 'shopGoodsMaps', label: '商品映射',
    fields: [
      { prop: 'id', label: 'ID', type: 'text', width: 70 },
      { prop: 'name', label: '名称', type: 'text', width: 170 },
      { prop: 'code', label: '编码', type: 'text', width: 110 },
      { prop: 'description', label: '说明', type: 'text', width: 200 },
      sel('status', '状态', opt(['正常:正常', '停用:停用'])),
    ],
    statusField: 'status', statusLabels: { 正常: '正常', 停用: '停用' },
    seed: [
      { id: 1, name: '商品映射示例一', code: 'SHOP001', description: '业务商品映射基础数据', status: '正常' },
      { id: 2, name: '商品映射示例二', code: 'SHOP002', description: '按文档定义的商品映射记录', status: '正常' },
      { id: 3, name: '商品映射示例三', code: 'SHOP003', description: '可编辑的商品映射数据', status: '正常' },
    ],
  },

  printJobs: {
    collection: 'printJobs', label: '打印执行',
    fields: [
      { prop: 'id', label: 'ID', type: 'text', width: 70 },
      { prop: 'name', label: '名称', type: 'text', width: 170 },
      { prop: 'code', label: '编码', type: 'text', width: 110 },
      { prop: 'description', label: '说明', type: 'text', width: 200 },
      sel('status', '状态', opt(['正常:正常', '停用:停用'])),
    ],
    statusField: 'status', statusLabels: { 正常: '正常', 停用: '停用' },
    seed: [
      { id: 1, name: '打印执行示例一', code: 'PRIN001', description: '业务打印执行基础数据', status: '正常' },
      { id: 2, name: '打印执行示例二', code: 'PRIN002', description: '按文档定义的打印执行记录', status: '正常' },
      { id: 3, name: '打印执行示例三', code: 'PRIN003', description: '可编辑的打印执行数据', status: '正常' },
    ],
  },

  printLabels: {
    collection: 'printLabels', label: '条码标签',
    fields: [
      { prop: 'id', label: 'ID', type: 'text', width: 70 },
      { prop: 'name', label: '名称', type: 'text', width: 170 },
      { prop: 'code', label: '编码', type: 'text', width: 110 },
      { prop: 'description', label: '说明', type: 'text', width: 200 },
      sel('status', '状态', opt(['正常:正常', '停用:停用'])),
    ],
    statusField: 'status', statusLabels: { 正常: '正常', 停用: '停用' },
    seed: [
      { id: 1, name: '条码标签示例一', code: 'PRIN001', description: '业务条码标签基础数据', status: '正常' },
      { id: 2, name: '条码标签示例二', code: 'PRIN002', description: '按文档定义的条码标签记录', status: '正常' },
      { id: 3, name: '条码标签示例三', code: 'PRIN003', description: '可编辑的条码标签数据', status: '正常' },
    ],
  },

  aiAnomalyScan: {
    collection: 'aiAnomalyScan', label: '异常检测',
    fields: [
      { prop: 'id', label: 'ID', type: 'text', width: 70 },
      { prop: 'name', label: '名称', type: 'text', width: 170 },
      { prop: 'code', label: '编码', type: 'text', width: 110 },
      { prop: 'description', label: '说明', type: 'text', width: 200 },
      sel('status', '状态', opt(['正常:正常', '停用:停用'])),
    ],
    statusField: 'status', statusLabels: { 正常: '正常', 停用: '停用' },
    seed: [
      { id: 1, name: '异常检测示例一', code: 'AIAN001', description: '业务异常检测基础数据', status: '正常' },
      { id: 2, name: '异常检测示例二', code: 'AIAN002', description: '按文档定义的异常检测记录', status: '正常' },
      { id: 3, name: '异常检测示例三', code: 'AIAN003', description: '可编辑的异常检测数据', status: '正常' },
    ],
  },

  aiSubjectMatch: {
    collection: 'aiSubjectMatch', label: '科目匹配',
    fields: [
      { prop: 'id', label: 'ID', type: 'text', width: 70 },
      { prop: 'name', label: '名称', type: 'text', width: 170 },
      { prop: 'code', label: '编码', type: 'text', width: 110 },
      { prop: 'description', label: '说明', type: 'text', width: 200 },
      sel('status', '状态', opt(['正常:正常', '停用:停用'])),
    ],
    statusField: 'status', statusLabels: { 正常: '正常', 停用: '停用' },
    seed: [
      { id: 1, name: '科目匹配示例一', code: 'AISU001', description: '业务科目匹配基础数据', status: '正常' },
      { id: 2, name: '科目匹配示例二', code: 'AISU002', description: '按文档定义的科目匹配记录', status: '正常' },
      { id: 3, name: '科目匹配示例三', code: 'AISU003', description: '可编辑的科目匹配数据', status: '正常' },
    ],
  },

  aiReportInsight: {
    collection: 'aiReportInsight', label: '报表解读',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }), f('title', '解读标题', 'text', 200), f('reportType', '报表类型', 'text', 120), f('period', '期间', 'text', 100), f('insight', 'AI 解读', 'textarea'), f('confidence', '置信度', 'text', 100), f('generatedAt', '生成时间', 'text', 160), sel('status', '状态', opt(['已生成:已生成', '生成中:生成中'])),
    ],
    statusField: 'status', statusLabels: { 已生成: '已生成', 生成中: '生成中' },
    seed: [
      { id: 1, title: '11月销售趋势解读', reportType: '销售报表', period: '2026-11', insight: '本月销售额环比增长12.5%，办公用品类目贡献主要增量，建议加大A4复印纸备货。', confidence: '92%', generatedAt: '2026-11-17 09:30', status: '已生成' }, { id: 2, title: '库存周转异常解读', reportType: '库存报表', period: '2026-11', insight: 'USB-C扩展坞库龄已达95天，存在呆滞风险，建议促销清库。', confidence: '88%', generatedAt: '2026-11-18 10:15', status: '已生成' },
    ],
  },

  aiCs: {
    collection: 'aiCs', label: '智能客服',
    fields: [
      { prop: 'id', label: 'ID', type: 'text', width: 70 },
      { prop: 'name', label: '名称', type: 'text', width: 170 },
      { prop: 'code', label: '编码', type: 'text', width: 110 },
      { prop: 'description', label: '说明', type: 'text', width: 200 },
      sel('status', '状态', opt(['正常:正常', '停用:停用'])),
    ],
    statusField: 'status', statusLabels: { 正常: '正常', 停用: '停用' },
    seed: [
      { id: 1, name: '智能客服示例一', code: 'AICS001', description: '业务智能客服基础数据', status: '正常' },
      { id: 2, name: '智能客服示例二', code: 'AICS002', description: '按文档定义的智能客服记录', status: '正常' },
      { id: 3, name: '智能客服示例三', code: 'AICS003', description: '可编辑的智能客服数据', status: '正常' },
    ],
  },

  systemRoles: {
    collection: 'systemRoles', label: '角色',
    fields: [
      { prop: 'id', label: 'ID', type: 'text', width: 70 },
      { prop: 'name', label: '名称', type: 'text', width: 170 },
      { prop: 'code', label: '编码', type: 'text', width: 110 },
      { prop: 'description', label: '说明', type: 'text', width: 200 },
      sel('status', '状态', opt(['正常:正常', '停用:停用'])),
    ],
    statusField: 'status', statusLabels: { 正常: '正常', 停用: '停用' },
    seed: [
      { id: 1, name: '角色示例一', code: 'SYST001', description: '业务角色基础数据', status: '正常' },
      { id: 2, name: '角色示例二', code: 'SYST002', description: '按文档定义的角色记录', status: '正常' },
      { id: 3, name: '角色示例三', code: 'SYST003', description: '可编辑的角色数据', status: '正常' },
    ],
  },

  systemPermissions: {
    collection: 'systemPermissions', label: '权限',
    fields: [
      { prop: 'id', label: 'ID', type: 'text', width: 70 },
      { prop: 'name', label: '名称', type: 'text', width: 170 },
      { prop: 'code', label: '编码', type: 'text', width: 110 },
      { prop: 'description', label: '说明', type: 'text', width: 200 },
      sel('status', '状态', opt(['正常:正常', '停用:停用'])),
    ],
    statusField: 'status', statusLabels: { 正常: '正常', 停用: '停用' },
    seed: [
      { id: 1, name: '权限示例一', code: 'SYST001', description: '业务权限基础数据', status: '正常' },
      { id: 2, name: '权限示例二', code: 'SYST002', description: '按文档定义的权限记录', status: '正常' },
      { id: 3, name: '权限示例三', code: 'SYST003', description: '可编辑的权限数据', status: '正常' },
    ],
  },

  systemDataScopes: {
    collection: 'systemDataScopes', label: '数据权限',
    fields: [
      { prop: 'id', label: 'ID', type: 'text', width: 70 },
      { prop: 'name', label: '名称', type: 'text', width: 170 },
      { prop: 'code', label: '编码', type: 'text', width: 110 },
      { prop: 'description', label: '说明', type: 'text', width: 200 },
      sel('status', '状态', opt(['正常:正常', '停用:停用'])),
    ],
    statusField: 'status', statusLabels: { 正常: '正常', 停用: '停用' },
    seed: [
      { id: 1, name: '数据权限示例一', code: 'SYST001', description: '业务数据权限基础数据', status: '正常' },
      { id: 2, name: '数据权限示例二', code: 'SYST002', description: '按文档定义的数据权限记录', status: '正常' },
      { id: 3, name: '数据权限示例三', code: 'SYST003', description: '可编辑的数据权限数据', status: '正常' },
    ],
  },

  systemSequences: {
    collection: 'systemSequences', label: '编码规则',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }), f('name', '规则名称', 'text', 150), f('code', '规则编码', 'text', 130), f('prefix', '前缀', 'text', 100), f('dateFormat', '日期格式', 'text', 120), f('seqLength', '序号位数', 'number', 100), f('currentSeq', '当前序号', 'number', 100), f('description', '说明', 'text', 180), sel('status', '状态', ON_OFF),
    ],
    statusField: 'status', statusLabels: { '1': '启用', '0': '停用' },
    seed: [
      { id: 1, name: '销售订单编号', code: 'SO_NO', prefix: 'SO', dateFormat: 'YYYYMMDD', seqLength: 4, currentSeq: 2, description: 'SO+日期+4位序号', status: 1 }, { id: 2, name: '采购订单编号', code: 'PO_NO', prefix: 'PO', dateFormat: 'YYYYMMDD', seqLength: 4, currentSeq: 1, description: 'PO+日期+4位序号', status: 1 }, { id: 3, name: '凭证编号', code: 'VCH_NO', prefix: 'VCH', dateFormat: 'YYYYMM', seqLength: 4, currentSeq: 1, description: 'VCH+年月+4位序号', status: 1 },
    ],
  },

  systemNos: {
    collection: 'systemNos', label: '单据编号',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }), f('bizType', '业务类型', 'text', 130), f('prefix', '编号前缀', 'text', 100), f('lastNo', '当前最大号', 'text', 160), f('resetCycle', '重置周期', 'text', 110), f('nextNo', '下一编号', 'text', 160), sel('status', '状态', ON_OFF),
    ],
    statusField: 'status', statusLabels: { '1': '启用', '0': '停用' },
    seed: [
      { id: 1, bizType: '销售订单', prefix: 'SO', lastNo: 'SO20261117-0002', resetCycle: '每日', nextNo: 'SO20261118-0001', status: 1 }, { id: 2, bizType: '采购订单', prefix: 'PO', lastNo: 'PO20261116-0001', resetCycle: '每日', nextNo: 'PO20261118-0001', status: 1 }, { id: 3, bizType: '会计凭证', prefix: 'VCH', lastNo: 'VCH202611-0001', resetCycle: '每月', nextNo: 'VCH202611-0002', status: 1 },
    ],
  },

  systemDicts: {
    collection: 'systemDicts', label: '数据字典',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }), f('dictType', '字典类型', 'text', 130), f('dictCode', '字典编码', 'text', 130), f('dictLabel', '字典标签', 'text', 130), f('dictValue', '字典值', 'text', 110), f('sort', '排序', 'number', 80), sel('status', '状态', ON_OFF),
    ],
    statusField: 'status', statusLabels: { '1': '启用', '0': '停用' },
    seed: [
      { id: 1, dictType: '支付方式', dictCode: 'PAY_WECHAT', dictLabel: '微信支付', dictValue: '微信', sort: 1, status: 1 }, { id: 2, dictType: '支付方式', dictCode: 'PAY_ALIPAY', dictLabel: '支付宝', dictValue: '支付宝', sort: 2, status: 1 }, { id: 3, dictType: '客户等级', dictCode: 'CUST_A', dictLabel: 'A级客户', dictValue: 'A', sort: 1, status: 1 }, { id: 4, dictType: '计量单位', dictCode: 'UNIT_PCS', dictLabel: '个', dictValue: '个', sort: 1, status: 1 },
    ],
  },

  systemConfigs: {
    collection: 'systemConfigs', label: '系统参数',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }), f('configName', '参数名称', 'text', 160), f('configKey', '参数键', 'text', 150), f('configValue', '参数值', 'text', 160), f('description', '说明', 'text', 200), sel('status', '状态', ON_OFF),
    ],
    statusField: 'status', statusLabels: { '1': '启用', '0': '停用' },
    seed: [
      { id: 1, configName: '公司名称', configKey: 'COMPANY_NAME', configValue: '示例科技有限公司', description: '显示在单据页眉', status: 1 }, { id: 2, configName: '默认仓库', configKey: 'DEFAULT_WAREHOUSE', configValue: '主仓库', description: '新建单据默认仓库', status: 1 }, { id: 3, configName: '默认税率', configKey: 'DEFAULT_TAX_RATE', configValue: '13%', description: '默认增值税率', status: 1 }, { id: 4, configName: '启用审批流', configKey: 'APPROVAL_ENABLED', configValue: 'true', description: '销售/采购单启用审批', status: 1 },
    ],
  },

  systemAuditLogs: {
    collection: 'systemAuditLogs', label: '审计日志',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }), f('operator', '操作人', 'text', 110), f('module', '模块', 'text', 120), f('operation', '操作', 'text', 140), f('method', '请求方法', 'text', 100), f('url', '请求地址', 'text', 180), f('ip', 'IP地址', 'text', 130), f('createdAt', '操作时间', 'text', 160),
    ],
    seed: [
      { id: 1, operator: 'admin', module: '销售管理', operation: '审核销售单', method: 'POST', url: '/api/v1/sales/orders/1/confirm', ip: '127.0.0.1', createdAt: '2026-11-17 14:20' }, { id: 2, operator: 'warehouse01', module: '库存管理', operation: '采购收货', method: 'POST', url: '/api/v1/purchase/orders/1/receive', ip: '192.168.1.35', createdAt: '2026-11-15 10:05' },
    ],
  },

  systemLoginLogs: {
    collection: 'systemLoginLogs', label: '登录日志',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }), f('username', '用户', 'text', 120), f('ip', 'IP地址', 'text', 130), f('browser', '浏览器', 'text', 140), f('os', '操作系统', 'text', 120), f('result', '登录结果', 'text', 100), f('loginAt', '登录时间', 'text', 160),
    ],
    seed: [
      { id: 1, username: 'admin', ip: '127.0.0.1', browser: 'Chrome 120', os: 'Windows 11', result: '成功', loginAt: '2026-11-18 09:30' }, { id: 2, username: 'sales01', ip: '192.168.1.35', browser: 'Edge 120', os: 'Windows 10', result: '成功', loginAt: '2026-11-17 17:20' }, { id: 3, username: 'unknown', ip: '103.45.22.11', browser: 'Unknown', os: 'Unknown', result: '失败', loginAt: '2026-11-17 03:12' },
    ],
  },

  systemNotifies: {
    collection: 'systemNotifies', label: '通知中心',
    fields: [
      { prop: 'id', label: 'ID', type: 'text', width: 70 },
      { prop: 'name', label: '名称', type: 'text', width: 170 },
      { prop: 'code', label: '编码', type: 'text', width: 110 },
      { prop: 'description', label: '说明', type: 'text', width: 200 },
      sel('status', '状态', opt(['正常:正常', '停用:停用'])),
    ],
    statusField: 'status', statusLabels: { 正常: '正常', 停用: '停用' },
    seed: [
      { id: 1, name: '通知中心示例一', code: 'SYST001', description: '业务通知中心基础数据', status: '正常' },
      { id: 2, name: '通知中心示例二', code: 'SYST002', description: '按文档定义的通知中心记录', status: '正常' },
      { id: 3, name: '通知中心示例三', code: 'SYST003', description: '可编辑的通知中心数据', status: '正常' },
    ],
  },

  systemFiles: {
    collection: 'systemFiles', label: '文件存储',
    fields: [
      { prop: 'id', label: 'ID', type: 'text', width: 70 },
      { prop: 'name', label: '名称', type: 'text', width: 170 },
      { prop: 'code', label: '编码', type: 'text', width: 110 },
      { prop: 'description', label: '说明', type: 'text', width: 200 },
      sel('status', '状态', opt(['正常:正常', '停用:停用'])),
    ],
    statusField: 'status', statusLabels: { 正常: '正常', 停用: '停用' },
    seed: [
      { id: 1, name: '文件存储示例一', code: 'SYST001', description: '业务文件存储基础数据', status: '正常' },
      { id: 2, name: '文件存储示例二', code: 'SYST002', description: '按文档定义的文件存储记录', status: '正常' },
      { id: 3, name: '文件存储示例三', code: 'SYST003', description: '可编辑的文件存储数据', status: '正常' },
    ],
  },

  systemJobs: {
    collection: 'systemJobs', label: '定时任务',
    fields: [
      { prop: 'id', label: 'ID', type: 'text', width: 70 },
      { prop: 'name', label: '名称', type: 'text', width: 170 },
      { prop: 'code', label: '编码', type: 'text', width: 110 },
      { prop: 'description', label: '说明', type: 'text', width: 200 },
      sel('status', '状态', opt(['正常:正常', '停用:停用'])),
    ],
    statusField: 'status', statusLabels: { 正常: '正常', 停用: '停用' },
    seed: [
      { id: 1, name: '定时任务示例一', code: 'SYST001', description: '业务定时任务基础数据', status: '正常' },
      { id: 2, name: '定时任务示例二', code: 'SYST002', description: '按文档定义的定时任务记录', status: '正常' },
      { id: 3, name: '定时任务示例三', code: 'SYST003', description: '可编辑的定时任务数据', status: '正常' },
    ],
  },

  systemEvents: {
    collection: 'systemEvents', label: '消息订阅',
    fields: [
      { prop: 'id', label: 'ID', type: 'text', width: 70 },
      { prop: 'name', label: '名称', type: 'text', width: 170 },
      { prop: 'code', label: '编码', type: 'text', width: 110 },
      { prop: 'description', label: '说明', type: 'text', width: 200 },
      sel('status', '状态', opt(['正常:正常', '停用:停用'])),
    ],
    statusField: 'status', statusLabels: { 正常: '正常', 停用: '停用' },
    seed: [
      { id: 1, name: '消息订阅示例一', code: 'SYST001', description: '业务消息订阅基础数据', status: '正常' },
      { id: 2, name: '消息订阅示例二', code: 'SYST002', description: '按文档定义的消息订阅记录', status: '正常' },
      { id: 3, name: '消息订阅示例三', code: 'SYST003', description: '可编辑的消息订阅数据', status: '正常' },
    ],
  },

  systemViewConfigs: {
    collection: 'systemViewConfigs', label: '我的视图',
    fields: [
      { prop: 'id', label: 'ID', type: 'text', width: 70 },
      { prop: 'name', label: '名称', type: 'text', width: 170 },
      { prop: 'code', label: '编码', type: 'text', width: 110 },
      { prop: 'description', label: '说明', type: 'text', width: 200 },
      sel('status', '状态', opt(['正常:正常', '停用:停用'])),
    ],
    statusField: 'status', statusLabels: { 正常: '正常', 停用: '停用' },
    seed: [
      { id: 1, name: '我的视图示例一', code: 'SYST001', description: '业务我的视图基础数据', status: '正常' },
      { id: 2, name: '我的视图示例二', code: 'SYST002', description: '按文档定义的我的视图记录', status: '正常' },
      { id: 3, name: '我的视图示例三', code: 'SYST003', description: '可编辑的我的视图数据', status: '正常' },
    ],
  },

  systemAlertRules: {
    collection: 'systemAlertRules', label: '告警规则',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }), f('name', '规则名称', 'text', 170), f('ruleType', '规则类型', 'text', 120), f('condition', '触发条件', 'text', 220), f('threshold', '阈值', 'text', 100), f('level', '告警级别', 'text', 100), f('receiver', '接收人', 'text', 120), sel('status', '状态', ON_OFF),
    ],
    statusField: 'status', statusLabels: { '1': '启用', '0': '停用' },
    seed: [
      { id: 1, name: '低库存告警', ruleType: '库存', condition: '可用库存 < 安全库存', threshold: '安全库存', level: '中', receiver: '王仓管', status: 1 }, { id: 2, name: '应收逾期告警', ruleType: '财务', condition: '账龄 > 30天', threshold: '30天', level: '高', receiver: '陈会计', status: 1 }, { id: 3, name: '超信用额度告警', ruleType: '销售', condition: '应收余额 > 信用额度', threshold: '信用额度', level: '高', receiver: '张销售', status: 1 },
    ],
  },

  systemFeedback: {
    collection: 'systemFeedback', label: '反馈与工单',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }), f('ticketNo', '工单号', 'text', 150), f('title', '标题', 'text', 200), f('type', '类型', 'text', 110), f('submitter', '提交人', 'text', 110), f('content', '反馈内容', 'textarea'), f('handler', '处理人', 'text', 110), f('createdAt', '提交时间', 'text', 160), sel('status', '状态', opt(['待处理:待处理', '处理中:处理中', '已解决:已解决'])),
    ],
    statusField: 'status', statusLabels: { 待处理: '待处理', 处理中: '处理中', 已解决: '已解决' },
    seed: [
      { id: 1, ticketNo: 'GD20261117-0001', title: '销售单打印模板错位', type: '问题反馈', submitter: '张伟', content: 'A4打印时表头错位，需要调整页边距', handler: '技术部', createdAt: '2026-11-17 15:30', status: '处理中' }, { id: 2, ticketNo: 'GD20261116-0002', title: '新增自定义字段需求', type: '功能建议', submitter: '李娜', content: '希望在产品上增加供应商字段', handler: '产品部', createdAt: '2026-11-16 10:20', status: '待处理' },
    ],
  },

};

/**
 * 把各业务域的真实字段覆盖合并进注册表。
 * 合并顺序即优先级：后合并的域覆盖同名的早期占位定义。
 * 注意：必须在上方字面量声明之后执行，getEntitySchema 才能读到覆盖后的结果。
 */
Object.assign(
  ENTITY_SCHEMAS,
  financeOverrides,
  inventoryOverrides,
  systemOverrides,
  hrOverrides,
  collabOverrides,
  mesWmsOverrides,
  aiOverrides,
  printShopCrmOverrides,
  apsOverrides,
  docGapOverrides,
);

/**
 * 取实体 Schema。
 * @param collection handleMock 推导出的集合名
 * @returns Schema 或 undefined
 */
export function getEntitySchema(collection: string): EntitySchema | undefined {
  return ENTITY_SCHEMAS[collection];
}
