/**
 * ERP 全量菜单与页面配置
 * ---------------------------------------------------------------------------
 * 功能：把文档第 3、11、12、14~35 章的菜单树整理成一份可驱动路由、侧边栏的配置。
 *       - 每个功能点指定专属 view（相对 views 目录）。
 *
 * 约定：每个菜单项 = 一级分组 group + 三级标题 title + 路由 path。
 *       path 均为相对根路径（如 sales/orders），最终 URL 为 #/sales/orders。
 */

/** 菜单项配置 */
export interface MenuEntry {
  /** 路由路径（相对根） */
  path: string;
  /** 菜单显示名 */
  title: string;
  /** 一级分组名（侧边栏分组标题） */
  group: string;
  /** 侧边栏图标（emoji，保持轻量、无第三方图标依赖） */
  icon?: string;
  /** 权限码，与后端 @RequirePerm 一致；演示账号拥有 * */
  perm?: string;
  /** 专属视图路径（相对 views 目录，不含 .vue） */
  view: string;
  /** 通用页使用的本地集合名（mockAdapter table key） */
  entity?: string;
  /** 通用页使用的接口路径（/api/v1 之后） */
  api?: string;
  /** 是否不在侧边栏显示（表单页等） */
  hidden?: boolean;
  /** 通用页的状态字段名与状态文案 */
  statusField?: string;
  statusLabels?: Record<string, string>;
  /** 通用页可执行的状态动作 */
  actions?: string[];
}

/**
 * 菜单图标缺省推断：为未显式声明 icon 的菜单项统一补一个语义图标，
 * 保证侧边栏每一行都图文并茂、结构一致。按「标题关键字 → 路径关键字」匹配，命中即返回。
 */
function guessIcon(title: string, path: string): string {
  const table: Array<[RegExp, string]> = [
    [/客户列表|联系人|分组|等级|客户/, 'Users'], [/供应商/, 'Box'], [/报价|询比价|价目|价格/, 'File'],
    [/合同/, 'File'], [/退货|换货/, 'Regenerate'], [/出货|发货|出库|拣货|波次|上架/, 'Upload'], [/收货|入库|到货/, 'Download'],
    [/对账|账单|应收|应付|结算/, 'File'], [/订单|清单销售/, 'File'], [/促销|活动|优惠券/, 'Star'],
    [/毛利|利润|分析|排行|趋势|周转|库龄|账龄|产能|成本|及时率/, 'ChartBar'], [/报表|报告|明细账|余额表/, 'File'],
    [/仓库|库位|批次|序列号|库存|安全库存|盘点|调拨|呆滞/, 'Box'], [/产品|物料|BOM|规格|属性/, 'Grid'],
    [/生产|工单|排产|计划|工艺|工作中心|产线/, 'Box'], [/领料|退料|报工|工时/, 'Setting'],
    [/质检|质量|异常|告警|检测/, 'CheckCircle'], [/设备|资产|固定资产|车辆/, 'Grid'],
    [/会计|分录|科目|凭证/, 'File'], [/账户|资金|转账|银行账户/, 'Home'], [/收款|付款|费用|收入/, 'File'],
    [/发票|票据/, 'File'], [/折旧/, 'ChartLine'], [/期末|结账|期间/, 'Calendar'],
    [/聊天|消息|通知|公告/, 'Chat'], [/会议|任务|项目|里程碑|任务板/, 'Aim'], [/审批|申请/, 'Edit'],
    [/流程|设计器|规则/, 'Connection'], [/文件|档案|知识库|文档/, 'Folder'], [/日历|节假日|班次|出勤|请假/, 'Calendar'],
    [/公司|组织|部门|岗位|雇员|人事|招聘|候选人|面试|工资|合约/, 'User'],
    [/店铺|渠道|商城|平台|开放平台|插件/, 'Inbox'], [/打印|标签/, 'File'],
    [/模型|配置|参数|系统|设置|编码规则|数据权限|字典|备份|定时任务|webhook|视图|字段|集成|订阅/, 'Setting'],
    [/用户|角色|权限|登录|审计|日志/, 'Setting'], [/语言|币种|币种/, 'Globe'],
    [/导入|导出|存储|文件/, 'FolderOpen'], [/AI|智能|识别|OCR|预测|RAG|知识/, 'Sparkles'],
    [/预警|监控/, 'Warning'], [/追溯|序列号/, 'Search'], [/物流|跟踪/, 'ExternalLink'], [/委外|外协/, 'Setting'],
    [/反馈|工单|投诉/, 'Chat'], [/版本|更新/, 'List'], [/默认|其他/, 'Grid'],
  ];
  for (const [re, icon] of table) if (re.test(title) || re.test(path)) return icon;
  return 'Grid';
}

/** 快捷辅助：创建一个专属视图菜单（自动补全缺省图标） */
function view(group: string, title: string, path: string, viewPath: string, extra: Partial<MenuEntry> = {}): MenuEntry {
  return { group, title, path, view: viewPath, icon: guessIcon(title, path), ...extra };
}

/** 单据通用状态（与 packages/shared 的 DocStatus 对应） */
const DOC_STATE: Record<string, string> = { '0': '草稿', '1': '待审核', '2': '已确认', '3': '部分完成', '4': '已完成', '9': '已作废' };

/**
 * 全量菜单清单：按文档一级模块分组。
 * 说明：路由直达但 hidden=true 的页面（表单/设计器）不会出现在侧边栏。
 */
export const MENUS: MenuEntry[] = [
  /* ------------------------------ 工作台 ------------------------------ */
  view('工作台', '个人工作台', 'dashboard', 'dashboard/index', { icon: 'ChartBar' }),
  view('工作台', '待办中心', 'workbench/todo', 'workbench/Todo', { icon: 'CheckCircle' }),
  view('工作台', '消息中心', 'workbench/messages', 'workbench/Messages', { icon: 'Bell' }),
  view('工作台', '经营日历', 'workbench/calendar', 'workbench/Calendar', { icon: 'Calendar' }),
  view('工作台', 'AI 每日简报', 'ai/forecast', 'ai/daily-brief', { icon: 'Sparkles' }),

  /* ---------------------------- 销售客户 ------------------------------ */
  view('销售客户', '清单销售', 'sales/orders', 'sales/order-list', { icon: 'Inbox', perm: 'sales:order:view' }),
  view('销售客户', '新建销售单', 'sales/orders/new', 'sales/order-form', { hidden: true, perm: 'sales:order:create' }),
  view('销售客户', '编辑销售单', 'sales/orders/:id', 'sales/EditOrder', { hidden: true, perm: 'sales:order:view' }),
  view('销售客户', '批量导入销售单', 'sales/orders/import', 'sales/ImportSalesOrders', { perm: 'sales:order:create' }),
  view('销售客户', '客户列表', 'sales/customers', 'sales/SalesCustomers', { icon: 'Users' }),
  view('销售客户', '客户分组', 'sales/customer-groups', 'sales/SalesCustomerGroups'),
  view('销售客户', '客户等级', 'sales/customer-levels', 'sales/SalesCustomerLevels'),
  view('销售客户', '客户联系人', 'sales/contacts', 'sales/SalesContacts'),
  view('销售客户', '报价单', 'sales/quotations', 'sales/SalesQuotations', { statusField: 'status' }),
  view('销售客户', '报价模板', 'sales/quote-templates', 'sales/SalesQuoteTemplates'),
  view('销售客户', '销售合同', 'sales/contracts', 'sales/SalesContracts', { statusField: 'status' }),
  view('销售客户', '促销活动', 'sales/promotions', 'sales/SalesPromotions', { statusField: 'status' }),
  view('销售客户', '销售退货', 'sales/returns', 'sales/SalesReturns', { statusField: 'status', statusLabels: DOC_STATE }),
  view('销售客户', '换货单', 'sales/exchanges', 'sales/SalesExchanges'),
  view('销售客户', '出货单', 'sales/shipments', 'sales/SalesShipments', { statusField: 'status', statusLabels: DOC_STATE }),
  view('销售客户', '客户对账单', 'sales/statements', 'sales/SalesStatements'),
  view('销售客户', 'POS 收银', 'sales/pos', 'sales/SalesPos'),
  view('销售客户', '销售毛利分析', 'sales/profit', 'sales/SalesProfit'),
  view('销售客户', '未发货清单', 'sales/unshipped', 'sales/SalesUnshipped'),
  view('销售客户', '销售明细', 'sales/details', 'sales/SalesDetails', { perm: 'sales:order:view' }),
  view('销售客户', '销售汇总', 'sales/summaries', 'sales/SalesSummaries', { perm: 'sales:order:view' }),
  view('销售客户', '畅销排行', 'sales/rankings', 'sales/SalesRankings', { perm: 'sales:order:view' }),
  view('销售客户', '退货原因', 'sales/return-reasons', 'sales/SalesReturnReasons'),
  view('销售客户', '佣金规则', 'sales/commissions', 'sales/SalesCommissions'),

  /* ---------------------------- 采购供应 ------------------------------ */
  view('采购供应', '采购订单', 'purchase/orders', 'purchase/order-list', { icon: 'ExternalLink', perm: 'purchase:order:view' }),
  view('采购供应', '采购履约台', 'purchase/fulfillment', 'purchase/PurchaseOrders', { icon: 'Inbox', perm: 'purchase:order:view' }),
  view('采购供应', '新建采购单', 'purchase/orders/new', 'purchase/order-form', { hidden: true, perm: 'purchase:order:create' }),
  view('采购供应', '导入采购订单', 'purchase/orders/import', 'purchase/ImportPurchaseOrders', { hidden: true, perm: 'purchase:order:create' }),
  view('采购供应', '供应商列表', 'purchase/suppliers', 'purchase/SupplierCenter', { icon: 'Box', perm: 'purchase:supplier:view' }),
  view('采购供应', '供应商分组', 'purchase/supplier-groups', 'purchase/PurSupplierGroups', { perm: 'purchase:supplier:view' }),
  view('采购供应', '供货评估', 'purchase/supplier-evaluates', 'purchase/SupplierAnalytics', { perm: 'purchase:supplier:evaluate' }),
  view('采购供应', '采购需求', 'purchase/requirements', 'purchase/PurRequirements', { perm: 'purchase:requirement:view' }),
  view('采购供应', '采购收货', 'purchase/receipts', 'purchase/ReceivingCenter', { perm: 'purchase:receive:view' }),
  view('采购供应', '采购入库', 'purchase/ins', 'purchase/PurIns', { perm: 'purchase:receive:view' }),
  view('采购供应', '采购退货', 'purchase/returns', 'purchase/PurReturns', { perm: 'purchase:return:view' }),
  view('采购供应', '采购对账单', 'purchase/statements', 'purchase/SettlementCenter', { perm: 'purchase:statement:view' }),
  view('采购供应', '询比价', 'purchase/quotations', 'purchase/QuotationCenter', { perm: 'purchase:quotation:view' }),
  view('采购供应', '采购合同', 'purchase/contracts', 'purchase/PurContracts', { perm: 'purchase:contract:view' }),
  view('采购供应', '委外加工', 'purchase/outsource', 'purchase/PurOutsource', { perm: 'purchase:outsource:view' }),
  view('采购供应', '物流跟踪', 'purchase/logistics', 'purchase/PurLogistics', { perm: 'purchase:logistics:view' }),
  view('采购供应', '采购价目表', 'purchase/prices', 'purchase/PriceCenter', { perm: 'purchase:price:view' }),
  view('采购供应', '到货及时率', 'purchase/on-time', 'purchase/PurOnTime', { perm: 'purchase:report:view' }),
  view('采购供应', '供应商联系人', 'purchase/supplier-contacts', 'purchase/SupplierContacts', { perm: 'purchase:supplier:view' }),
  view('采购供应', '采购批量导入', 'purchase/imports', 'purchase/PurchaseImports'),
  view('采购供应', '供应商罚款', 'purchase/fines', 'purchase/SupplierFines'),
  view('采购供应', '历史采购价', 'purchase/price-history', 'purchase/PurchasePriceHistory', { perm: 'purchase:report:view' }),
  view('采购供应', '采购明细', 'purchase/details', 'purchase/PurchaseDetails', { perm: 'purchase:report:view' }),
  view('采购供应', '采购汇总', 'purchase/summaries', 'purchase/PurchaseSummaries', { perm: 'purchase:report:view' }),
  view('采购供应', '供货排行', 'purchase/supplier-rankings', 'purchase/SupplierRankings', { perm: 'purchase:report:view' }),

  /* ---------------------------- 库存仓储 ------------------------------ */
  view('库存仓储', '产品列表', 'inventory/products', 'inventory/product-list', { icon: 'Box', perm: 'inventory:product:view' }),
  view('库存仓储', '库存查询', 'inventory/balance', 'inventory/balance', { icon: 'ChartLine', perm: 'inventory:balance:view' }),
  view('库存仓储', '库存流水', 'inventory/ledger', 'inventory/InventoryLedger'),
  view('库存仓储', '库存预警', 'inventory/alerts', 'inventory/InventoryAlerts', { statusField: 'handled' }),
  view('库存仓储', '产品分类', 'inventory/categories', 'inventory/InventoryCategories'),
  view('库存仓储', '品牌', 'inventory/brands', 'inventory/InventoryBrands'),
  view('库存仓储', '计量单位', 'inventory/units', 'inventory/InventoryUnits'),
  view('库存仓储', '仓库', 'inventory/warehouses', 'inventory/InventoryWarehouses'),
  view('库存仓储', '库位', 'inventory/locations', 'inventory/InventoryLocations'),
  view('库存仓储', '批次', 'inventory/batches', 'inventory/InventoryBatches'),
  view('库存仓储', '序列号/IMEI', 'inventory/serials', 'inventory/InventorySerials', { statusField: 'status' }),
  view('库存仓储', '产品属性/多规格', 'inventory/variants', 'inventory/SkuCenter', { icon: 'Grid' }),
  view('库存仓储', '安全库存', 'inventory/safe-stock', 'inventory/InventorySafeStock'),
  view('库存仓储', '库存调整', 'inventory/adjusts', 'inventory/InventoryAdjusts', { statusField: 'status', statusLabels: DOC_STATE }),
  view('库存仓储', '库存盘点', 'inventory/stocktakes', 'inventory/InventoryStocktakes', { statusField: 'status' }),
  view('库存仓储', '调拨单', 'inventory/transfers', 'inventory/InventoryTransfers', { statusField: 'status' }),
  view('库存仓储', '拆装单', 'inventory/disassembly', 'inventory/Disassembly', { icon: 'Setting' }),
  view('库存仓储', '组装单', 'inventory/assembly', 'inventory/Assembly', { icon: 'Setting' }),
  view('库存仓储', '拣货清单', 'inventory/picks', 'inventory/InventoryPicks'),
  view('库存仓储', '收货入库', 'inventory/receipts', 'inventory/InventoryReceipts'),
  view('库存仓储', '销售出库', 'inventory/outs', 'inventory/InventoryOuts'),
  view('库存仓储', '领料出库', 'inventory/picks-out', 'inventory/InventoryPicksOut'),
  view('库存仓储', '收发存报表', 'inventory/reports', 'inventory/InventoryReports'),
  view('库存仓储', '库龄分析', 'inventory/aging', 'inventory/InventoryAging'),
  view('库存仓储', '周转率', 'inventory/turnover', 'inventory/InventoryTurnover'),
  view('库存仓储', '呆滞料', 'inventory/slow', 'inventory/InventorySlow'),
  view('库存仓储', '波次拣货', 'inventory/waves', 'inventory/InventoryWaves', { statusField: 'status' }),
  view('库存仓储', '上架策略', 'inventory/putaways', 'inventory/InventoryPutaways', { statusField: 'status' }),
  view('库存仓储', '序列号追溯', 'inventory/trace', 'inventory/InventoryTrace'),
  view('库存仓储', '越库直发', 'inventory/crossdocks', 'inventory/InventoryCrossdocks'),
  view('库存仓储', '创建产品', 'inventory/product-creates', 'inventory/CreateProduct', { perm: 'inventory:product:edit' }),
  view('库存仓储', '导入产品', 'inventory/product-imports', 'inventory/ImportProducts', { perm: 'inventory:product:edit' }),
  view('库存仓储', '导入更新', 'inventory/product-import-updates', 'inventory/UpdateProductsFromFile', { perm: 'inventory:product:edit' }),
  view('库存仓储', '打印条形码', 'inventory/product-barcodes', 'inventory/ProductBarcodes', { perm: 'inventory:stock:view' }),
  view('库存仓储', '批次追踪', 'inventory/batch-traces', 'inventory/BatchTrace'),
  view('库存仓储', '退料入库', 'inventory/material-returns', 'inventory/MaterialReturnReceipts'),
  view('库存仓储', '其他出入库', 'inventory/other-in-outs', 'inventory/OtherStockMovements'),
  view('库存仓储', '负库存清单', 'inventory/negative-stocks', 'inventory/NegativeStocks', { perm: 'inventory:stock:view' }),

  /* ---------------------------- 生产制造 ------------------------------ */
  view('生产制造', 'MRP 运算', 'manufacturing/mrp', 'manufacturing/Mrp', { icon: 'Setting' }),
  view('生产制造', '物料清单 BOM', 'manufacturing/bom', 'manufacturing/ManufacturingBom'),
  view('生产制造', 'BOM 版本', 'manufacturing/bom-versions', 'manufacturing/ManufacturingBomVersions'),
  view('生产制造', '工艺路线', 'manufacturing/routings', 'manufacturing/ManufacturingRoutings'),
  view('生产制造', '工作中心/产线', 'manufacturing/work-centers', 'manufacturing/ManufacturingWorkCenters'),
  view('生产制造', '生产计划', 'aps/plans', 'aps/ApsPlans', { icon: 'Calendar', perm: 'aps:plan:view' }),
  view('生产制造', '生产计划与排产', 'aps/gantt', 'mes/PlanGantt', { icon: 'Calendar', perm: 'aps:schedule:view' }),
  view('生产制造', '排产工作台', 'aps/schedule', 'aps/ApsSchedule', { icon: 'Box', perm: 'aps:schedule:view' }),
  view('生产制造', '产能负荷', 'aps/loads', 'aps/ApsLoads', { perm: 'aps:schedule:view' }),
  view('生产制造', '齐套检查', 'aps/materials', 'aps/ApsMaterials', { perm: 'aps:material:view' }),
  view('生产制造', '排产预警', 'aps/alerts', 'aps/ApsAlerts', { perm: 'aps:schedule:view' }),
  view('生产制造', '工作中心日历', 'aps/calendar', 'aps/ApsResourceCalendar', { icon: 'Calendar', perm: 'aps:resource:view' }),
  view('生产制造', '排产记录', 'aps/runs', 'aps/ApsRunHistory', { icon: 'List', perm: 'aps:schedule:view' }),
  view('生产制造', '需求汇总', 'manufacturing/demands', 'manufacturing/ManufacturingDemands'),
  view('生产制造', '生产工单', 'manufacturing/workorders', 'mes/WorkorderCenter', { icon: 'Box' }),
  view('生产制造', '领料单', 'manufacturing/issues', 'manufacturing/ManufacturingIssues'),
  view('生产制造', '退料单', 'manufacturing/material-returns', 'manufacturing/ManufacturingMaterialReturns'),
  view('生产制造', '完工入库', 'manufacturing/finish-ins', 'manufacturing/ManufacturingFinishIns'),
  view('生产制造', '工时报工', 'manufacturing/reports', 'manufacturing/ManufacturingReports'),
  view('生产制造', '质检单', 'manufacturing/qc', 'manufacturing/ManufacturingQc', { statusField: 'status' }),
  view('生产制造', '设备管理', 'manufacturing/equipments', 'manufacturing/ManufacturingEquipments', { statusField: 'status' }),
  view('生产制造', '产能分析', 'manufacturing/capacity', 'manufacturing/ManufacturingCapacity'),
  view('生产制造', '成本归集', 'manufacturing/costs', 'manufacturing/ManufacturingCosts'),
  view('生产制造', '工单进度', 'manufacturing/work-order-progress', 'manufacturing/WorkOrderProgress'),
  view('生产制造', '损耗分析', 'manufacturing/loss-analysis', 'manufacturing/ProductionLossAnalysis'),

  /* ---------------------------- 财务结算 ------------------------------ */
  view('财务结算', '会计分录', 'finance/vouchers', 'finance/vouchers', { icon: 'File', perm: 'finance:voucher:view' }),
  view('财务结算', '财务报表', 'finance/reports', 'finance/reports', { icon: 'File' }),
  view('财务结算', '会计科目表', 'finance/subjects', 'finance/FinanceSubjects', { perm: 'finance:subject:view' }),
  view('财务结算', '账户列表', 'finance/accounts', 'finance/FinanceAccounts', { perm: 'finance:account:view' }),
  view('财务结算', '资金转账', 'finance/transfers', 'finance/FinanceTransfers'),
  view('财务结算', '清单费用', 'finance/expenses', 'finance/FinanceExpenses'),
  view('财务结算', '收入列表', 'finance/incomes', 'finance/FinanceIncomes'),
  view('财务结算', '费用类别', 'finance/expense-categories', 'finance/FinanceExpenseCategories'),
  view('财务结算', '收入类别', 'finance/income-categories', 'finance/FinanceIncomeCategories'),
  view('财务结算', '应收账单', 'finance/receivables', 'finance/FinanceReceivables'),
  view('财务结算', '收款单', 'finance/payments-in', 'finance/FinancePaymentsIn'),
  view('财务结算', '应付账单', 'finance/payables', 'finance/FinancePayables', { perm: 'finance:report:view' }),
  view('财务结算', '付款单', 'finance/payments-out', 'finance/FinancePaymentsOut'),
  view('财务结算', '账龄分析', 'finance/aging', 'finance/FinanceAging'),
  view('财务结算', '固定资产', 'finance/assets', 'finance/FinanceAssets'),
  view('财务结算', '折旧', 'finance/depreciations', 'finance/FinanceDepreciations'),
  view('财务结算', '发票登记', 'finance/invoices', 'finance/FinanceInvoices'),
  view('财务结算', '现金流量表', 'finance/cash-flow', 'finance/CashFlow', { icon: 'ChartLine' }),
  view('财务结算', '科目余额表', 'finance/subject-balances', 'finance/SubjectBalances', { icon: 'ChartBar' }),
  view('财务结算', '明细账', 'finance/ledger', 'finance/Ledger', { icon: 'BookOpen' }),
  view('财务结算', '利润中心', 'finance/profit-centers', 'finance/ProfitCenters', { icon: 'Star' }),
  view('财务结算', '试算平衡表', 'finance/trial-balance', 'finance/FinanceTrialBalance'),
  view('财务结算', '期末结账', 'finance/periods', 'finance/FinancePeriods'),
  view('财务结算', '成本核算', 'finance/costs', 'finance/FinanceCosts'),
  view('财务结算', '财务仪表盘', 'finance/dashboards', 'finance/FinanceDashboard', { perm: 'finance:report:view' }),
  view('财务结算', '损益表', 'finance/profit-loss', 'finance/ProfitLoss', { perm: 'finance:report:view' }),
  view('财务结算', '资产负债表', 'finance/balance-sheets', 'finance/BalanceSheet', { perm: 'finance:report:view' }),
  view('财务结算', '税务汇总报告', 'finance/tax-summaries', 'finance/TaxSummary', { perm: 'finance:report:view' }),
  view('财务结算', '新建支出', 'finance/expenses-new', 'finance/CreateExpense', { perm: 'finance:payment:create' }),
  view('财务结算', '新建收入', 'finance/incomes-new', 'finance/CreateIncome', { perm: 'finance:payment:create' }),
  view('财务结算', '坏账', 'finance/bad-debts', 'finance/BadDebts'),
  view('财务结算', '回款计划', 'finance/collection-plans', 'finance/CollectionPlans'),
  view('财务结算', '资产处置', 'finance/asset-disposals', 'finance/AssetDisposals'),
  view('财务结算', '资产盘点', 'finance/asset-checks', 'finance/AssetChecks'),
  view('财务结算', '税码', 'finance/tax-codes', 'finance/TaxCodes'),
  view('财务结算', '税率', 'finance/tax-rates', 'finance/TaxRates'),
  view('财务结算', '纳税申报', 'finance/tax-declarations', 'finance/TaxDeclarations', { perm: 'finance:report:view' }),

  /* ---------------------------- 协同办公 ------------------------------ */
  view('协同办公', '申请与审批', 'collab/approval', 'collab/Approval', { icon: 'Edit', perm: 'collab:approval:view' }),
  view('协同办公', '企业聊天', 'collab/chat', 'collab/CollabChat'),
  view('协同办公', '公告', 'collab/notices', 'collab/CollabNotices'),
  view('协同办公', '会议', 'collab/meetings', 'collab/CollabMeetings'),
  view('协同办公', '审批流程设计器', 'collab/flow-defs', 'collab/FlowDefs', { icon: 'Connection' }),
  view('协同办公', '项目', 'collab/projects', 'collab/CollabProjects', { perm: 'collab:project:view' }),
  view('协同办公', '任务', 'collab/tasks', 'collab/CollabTasks', { perm: 'collab:task:view' }),
  view('协同办公', '任务板', 'collab/board', 'collab/CollabBoard'),
  view('协同办公', '里程碑', 'collab/milestones', 'collab/CollabMilestones'),
  view('协同办公', '项目报告', 'collab/project-reports', 'collab/CollabProjectReports'),
  view('协同办公', '文件档案', 'collab/files', 'collab/CollabFiles'),
  view('协同办公', '知识库', 'collab/knowledge', 'collab/CollabKnowledge'),
  view('协同办公', '审批模板', 'collab/approval-templates', 'collab/ApprovalTemplates'),
  view('协同办公', '抄送设置', 'collab/approval-cc', 'collab/ApprovalCopies'),
  view('协同办公', '项目仪表盘', 'collab/project-dashboards', 'collab/ProjectDashboard', { perm: 'collab:project:view' }),
  view('协同办公', '时间表', 'collab/timesheets', 'collab/Timesheets'),

  /* ---------------------------- 人事行政 ------------------------------ */
  view('人事行政', '公司', 'hr/companies', 'hr/HrCompanies', { icon: 'Home', perm: 'hr:org:view' }),
  view('人事行政', '部门', 'hr/departments', 'hr/HrDepartments', { perm: 'hr:org:view' }),
  view('人事行政', '岗位', 'hr/positions', 'hr/HrPositions', { perm: 'hr:org:view' }),
  view('人事行政', '班次', 'hr/shifts', 'hr/HrShifts', { perm: 'hr:org:view' }),
  view('人事行政', '雇员', 'hr/employees', 'hr/HrEmployees', { perm: 'hr:employee:view' }),
  view('人事行政', '出勤率', 'hr/attendance', 'hr/HrAttendance'),
  view('人事行政', '请假', 'hr/leaves', 'hr/HrLeaves'),
  view('人事行政', '节假日', 'hr/holidays', 'hr/HrHolidays'),
  view('人事行政', '工资单', 'hr/payrolls', 'hr/HrPayrolls'),
  view('人事行政', '合约', 'hr/contracts', 'hr/HrContracts'),
  view('人事行政', '招聘管理', 'hr/recruitments', 'hr/Recruitment', { icon: 'User', perm: 'hr:recruitment:view' }),
  view('人事行政', '候选人', 'hr/candidates', 'hr/HrCandidates', { perm: 'hr:recruitment:view' }),
  view('人事行政', '面试', 'hr/interviews', 'hr/HrInterviews', { perm: 'hr:recruitment:view' }),
  view('人事行政', '资产领用', 'hr/assets', 'hr/HrAssets'),
  view('人事行政', '车辆管理', 'hr/vehicles', 'hr/HrVehicles'),
  view('人事行政', '录用', 'hr/hirings', 'hr/HiringRecords'),
  view('人事行政', '资产台账', 'hr/asset-ledgers', 'hr/AssetRegister'),
  view('人事行政', '资产归还', 'hr/asset-returns', 'hr/AssetReturns'),
  view('人事行政', '资产报废', 'hr/asset-scraps', 'hr/AssetScraps'),
  view('人事行政', '司机', 'hr/drivers', 'hr/DriverRegister'),
  view('人事行政', '用车申请', 'hr/vehicle-uses', 'hr/VehicleRequests'),
  view('人事行政', '加油记录', 'hr/fuel-records', 'hr/FuelRecords'),
  view('人事行政', '维保记录', 'hr/vehicle-maintains', 'hr/VehicleMaintenance'),

  /* ---------------------------- 商城渠道 ------------------------------ */
  view('商城渠道', '渠道运营中心', 'shop/center', 'ext/index', { icon: 'Inbox' }),
  view('商城渠道', '线上店铺', 'shop/stores', 'shop/ShopStores'),
  view('商城渠道', '渠道配置', 'shop/channels', 'shop/ShopChannels'),
  view('商城渠道', '商品映射', 'shop/goods-maps', 'shop/ShopGoodsMaps'),
  view('商城渠道', '平台订单', 'shop/orders', 'shop/ShopOrders'),
  view('商城渠道', '优惠券', 'shop/coupons', 'shop/ShopCoupons'),
  view('商城渠道', '促销活动', 'shop/promotions', 'shop/ShopPromotions'),
  view('商城渠道', '商品发布', 'shop/goods-publications', 'shop/ProductPublications'),
  view('商城渠道', '价格库存同步', 'shop/stock-syncs', 'shop/StockSyncRecords'),
  view('商城渠道', '订单同步', 'shop/order-syncs', 'shop/OrderSyncRecords'),
  view('商城渠道', '发货回传', 'shop/ship-callbacks', 'shop/ShipmentCallbacks'),
  view('商城渠道', '满减活动', 'shop/full-reductions', 'shop/SpendingDiscounts'),
  view('商城渠道', '秒杀活动', 'shop/flash-sales', 'shop/FlashSales'),

  /* ---------------------------- 打印中心 ------------------------------ */
  view('打印中心', '模板管理', 'print/templates', 'print/templates', { icon: 'File', perm: 'print:template:edit' }),
  view('打印中心', '模板设计器', 'print/designer', 'print/designer/index', { hidden: true, perm: 'print:template:design' }),
  view('打印中心', '单据模板', 'print/doc-templates', 'print/PrintDocTemplates'),
  view('打印中心', '打印执行', 'print/jobs', 'print/PrintJobs'),
  view('打印中心', '打印记录', 'print/records', 'print/records', { perm: 'print:record:view' }),
  view('打印中心', '条码标签', 'print/labels', 'print/PrintLabels'),

  /* ----------------------------- AI 助手 ------------------------------ */
  view('AI 助手', 'AI 助理', 'ai/copilot', 'ai/copilot', { icon: 'Sparkles', perm: 'ai:copilot:use' }),
  view('AI 助手', '智能建单', 'ai/doc-parse', 'ai/smart-entry', { icon: 'File', perm: 'ai:doc:parse' }),
  view('AI 助手', 'OCR 识别', 'ai/ocr', 'ai/OcrRecognition', { icon: 'Search', perm: 'ai:ocr' }),
  view('AI 助手', '预测与风控', 'ai/forecast-risk', 'ai/forecast', { perm: 'ai:recommend' }),
  view('AI 助手', '异常检测', 'ai/anomaly', 'ai/AiAnomaly', { perm: 'ai:anomaly:scan' }),
  view('AI 助手', '智能对账', 'ai/reconcile', 'ai/reconcile', { icon: 'Grid', perm: 'ai:reconcile:use' }),
  view('AI 助手', '科目匹配', 'ai/subject-match', 'ai/AiSubjectMatch', { perm: 'ai:subject:match' }),
  view('AI 助手', '报表解读', 'ai/report', 'ai/AiReport', { perm: 'ai:report' }),
  view('AI 助手', '智能客服', 'ai/cs', 'ai/AiCs', { perm: 'ai:cs:use' }),
  view('AI 助手', '知识库与 RAG', 'ai/knowledge', 'ai/rag', { icon: 'BookOpen', perm: 'ai:rag:use' }),
  view('AI 助手', '模型配置', 'ai/config', 'ai/ModelConfig', { icon: 'DeepThink' }),
  view('AI 助手', 'Prompt 模板管理', 'ai/prompts', 'ai/PromptTemplates', { icon: 'Edit' }),
  view('AI 助手', 'Function 工具管理', 'ai/functions', 'ai/FunctionTools', { icon: 'Setting' }),
  view('AI 助手', 'MCP 服务管理', 'ai/mcp', 'ai/McpManagement', { icon: 'Connection' }),
  view('AI 助手', 'AI 审计日志', 'ai/audits', 'ai/audits', { perm: 'system:audit:view' }),

  /* ---------------------------- 系统管理 ------------------------------ */
  view('系统管理', '用户与角色', 'system/users', 'system/users', { icon: 'Setting', perm: 'system:user:view' }),
  view('系统管理', '参数与审计', 'system/configs', 'system/configs', { perm: 'system:config:view' }),
  view('系统管理', '组织租户', 'system/orgs', 'system/SystemOrgs'),
  view('系统管理', '角色', 'system/roles', 'system/SystemRoles'),
  view('系统管理', '权限', 'system/permissions', 'system/SystemPermissions'),
  view('系统管理', '数据权限', 'system/data-scopes', 'system/SystemDataScopes'),
  view('系统管理', '编码规则', 'system/sequences', 'system/SystemSequences'),
  view('系统管理', '单据编号', 'system/nos', 'system/SystemNos'),
  view('系统管理', '数据字典', 'system/dicts', 'system/SystemDicts'),
  view('系统管理', '系统参数', 'system/settings', 'system/SystemSettings'),
  view('系统管理', '多语言多币种', 'system/i18n', 'system/CurrencyCenter', { icon: 'Globe' }),
  view('系统管理', '审计日志', 'system/audit-logs', 'system/SystemAuditLogs'),
  view('系统管理', '登录日志', 'system/login-logs', 'system/SystemLoginLogs'),
  view('系统管理', '通知中心', 'system/notifies', 'system/SystemNotifies'),
  view('系统管理', '文件存储', 'system/files', 'system/SystemFiles'),
  view('系统管理', '定时任务', 'system/jobs', 'system/SystemJobs'),
  view('系统管理', '开放平台', 'system/openapi', 'system/OpenPlatform'),
  view('系统管理', 'Webhook 日志', 'system/webhooks', 'system/WebhookLogs', { perm: 'system:audit:view' }),
  view('系统管理', '消息订阅', 'system/events', 'system/SystemEvents'),
  view('系统管理', '数据备份', 'system/backups', 'system/Backup'),
  view('系统管理', '我的视图', 'system/view-configs', 'system/SystemViewConfigs'),
  view('系统管理', '导入导出中心', 'system/import-export', 'system/ImportExportCenter'),
  view('系统管理', '自定义字段', 'system/custom-fields', 'system/CustomFields'),
  view('系统管理', '业务规则中心', 'system/rules', 'system/RuleCenter'),
  view('系统管理', '告警规则', 'system/alert-rules', 'system/SystemAlertRules'),
  view('系统管理', '报表设计器', 'system/report-designer', 'system/ReportDesigner'),
  view('系统管理', '插件市场', 'system/plugins', 'system/PluginMarket'),
  view('系统管理', '版本更新日志', 'system/changelog', 'system/Changelog', { icon: 'List' }),
  view('系统管理', '外部集成中心', 'system/integrations', 'system/IntegrationCenter', { icon: 'Connection' }),
  view('系统管理', '变更订阅', 'system/subscriptions', 'system/SubscriptionCenter', { icon: 'Bell' }),
  view('系统管理', '反馈与工单', 'system/feedback', 'system/SystemFeedback', { icon: 'Chat' }),
  view('系统管理', '主题配置', 'system/themes', 'system/ThemeSettings', { perm: 'system:config:view' }),
  view('系统管理', '支付配置', 'system/pay-configs', 'system/PaymentSettings', { perm: 'system:config:view' }),

  /* ---------------------------- 行业应用 ------------------------------ */
  view('行业应用', '零售 POS', 'industry/retail', 'industry/RetailPos', { icon: 'Home' }),
  view('行业应用', '餐饮', 'industry/catering', 'industry/Catering', { icon: 'Inbox' }),
  view('行业应用', '医药 GSP', 'industry/pharma', 'industry/PharmaGsp', { icon: 'Box' }),
  view('行业应用', '服装多规格', 'industry/apparel', 'industry/ApparelSku', { icon: 'Tag' }),
  view('行业应用', '生鲜计重', 'industry/fresh', 'industry/FreshWeigh', { icon: 'Aim' }),
];

/** 常用字段名中文映射：通用页自动列名时优先使用 */
export const FIELD_LABELS: Record<string, string> = {
  id: 'ID', name: '名称', title: '标题', code: '编码', no: '单号', orderNo: '单号', takeNo: '盘点单号',
  waveNo: '波次号', voucherNo: '凭证号', quoteNo: '报价单号', platformOrderNo: '平台单号', batchNo: '批号',
  skuCode: 'SKU 编码', serialNo: '序列号', barcode: '条码', customerId: '客户 ID', customerName: '客户',
  supplierId: '供应商 ID', supplierName: '供应商', warehouseId: '仓库 ID', warehouseName: '仓库',
  productId: '产品 ID', productName: '产品', qty: '数量', qtyOnHand: '实物库存', qtyOccupied: '锁定量',
  available: '可用量', unitPrice: '单价', price: '售价', cost: '成本', amount: '金额', totalAmount: '总金额',
  paidAmount: '已收金额', unpaid: '未收金额', status: '状态', payStatus: '支付状态', shipStatus: '发货状态',
  orderDate: '单据日期', createdAt: '创建时间', updatedAt: '更新时间', remark: '备注', phone: '电话',
  contact: '联系人', level: '等级', type: '类型', isActive: '启用', enabled: '启用', handled: '已处理',
  closed: '已结账', balance: '余额', score: '评分', company: '公司', stage: '阶段', probability: '赢率',
  message: '消息内容', content: '内容', model: '模型', capability: '能力码', channel: '渠道', copies: '份数',
  printedAt: '打印时间', trigger: '触发条件', threshold: '阈值', action: '动作', operator: '操作人',
  apiKey: 'API 密钥', url: '地址', fileUrl: '文件地址', description: '说明', reason: '原因',
};

/**
 * 根据菜单项推导通用页展示配置。
 * 功能：优先用菜单指定的状态字段，其余按常见字段名猜测；列在运行时由数据决定。
 * @param entry 菜单项
 * @returns 展示配置
 */
export function entityConfig(entry: MenuEntry) {
  return {
    title: entry.title,
    api: entry.api || '',
    entity: entry.entity || '',
    statusField: entry.statusField || '',
    statusLabels: entry.statusLabels || DOC_STATE,
    actions: entry.actions || [],
  };
}

/** 按一级分组归拢菜单，供侧边栏渲染（保持配置中的顺序） */
export function groupedMenus(): Array<{ group: string; items: MenuEntry[] }> {
  const groups: Array<{ group: string; items: MenuEntry[] }> = [];
  for (const item of MENUS) {
    if (item.hidden) continue;
    let g = groups.find((x) => x.group === item.group);
    if (!g) { g = { group: item.group, items: [] }; groups.push(g); }
    g.items.push(item);
  }
  return groups;
}
