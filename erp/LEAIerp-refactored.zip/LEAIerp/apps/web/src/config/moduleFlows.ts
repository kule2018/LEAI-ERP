/**
 * 三大模块专属业务流注册表
 * ---------------------------------------------------------------------------
 * 财务结算 / 协同办公 / 人事行政的每个页面都有独立的业务语义：
 * 会计科目是启用停用、资金转账是提交执行、项目是启动暂停完工、雇员是试用转正离职……
 * 早期版本靠关键字推断分类，导致这些页面全部退化成同一套「提交/审批/作废」或
 * 「停用/启用/复制」，流程与页面业务不符。
 *
 * 本表按集合名显式声明每个页面的用途、状态动作、副作用与方案参数。
 * businessFlows.buildFlow 优先读取本表，mockAdapter.genericBizAction 消费同一份配置，
 * 保证「页面按钮」与「后端状态机」永远一致。
 */
import type { BizAction, BizCategory, BizFlow } from './businessFlows';

/** 页面专属业务流配置 */
export interface ModuleFlowConfig {
  /** 页面业务说明（展示在页面头部，区别于其它页面） */
  purpose: string;
  category: BizCategory;
  actions: BizAction[];
  /** 覆盖默认副作用推断（voucher/receivable/payable/attendance/stock） */
  effects?: string[];
  /** 触发过账/凭证的动作键；未声明时按 execute/approve 推断 */
  postingActions?: string[];
  scheme?: BizFlow['scheme'];
}

/** 构造动作的简写 */
const a = (
  key: string,
  label: string,
  from: string[] = [],
  to?: string,
  variant: BizAction['variant'] = 'default',
  confirm = true,
): BizAction => ({ key, label, from, to, variant, confirm, effect: true });

/** 只读动作（导出/打印/刷新等，不改变状态） */
const ro = (key: string, label: string): BizAction => ({ key, label, from: [], variant: 'default', effect: false });

const COMMON_SCHEME: BizFlow['scheme'] = [
  { key: 'autoPost', label: '动作自动生成凭证/流水', value: 1, type: 'switch', hint: '终态动作执行时写入总账与业务台账' },
  { key: 'notifyOnAction', label: '动作后通知', value: 1, type: 'switch', hint: '状态流转后写入通知中心' },
];

/** key = 由接口路径推导出的集合名（与 BusinessPage.collection 一致） */
export const MODULE_FLOWS: Record<string, ModuleFlowConfig> = {
  /* --------------------------- 财务结算 --------------------------- */
  financeSubjects: {
    purpose: '维护会计科目体系、余额方向与启停状态，科目停用后不再允许新凭证引用。',
    category: 'setting', scheme: COMMON_SCHEME,
    actions: [
      a('enable', '启用科目', ['0'], '1', 'primary'),
      a('disable', '停用科目', ['1'], '0', 'warning'),
      a('copy', '复制科目'),
    ],
  },
  financeAccounts: {
    purpose: '管理银行账户、币种与余额；对账只生成核对记录，不直接改动余额。',
    category: 'master', scheme: COMMON_SCHEME,
    actions: [
      a('reconcile', '银行对账', [], undefined, 'primary', false),
      a('freeze', '冻结账户', ['1'], '0', 'warning'),
      a('unfreeze', '解冻账户', ['0'], '1', 'primary'),
    ],
  },
  financeTransfers: {
    purpose: '资金在账户间调拨：提交 → 执行 → 完成，执行后同步两账户余额并生成凭证。',
    category: 'doc', effects: ['voucher', 'account'], postingActions: ['execute'], scheme: COMMON_SCHEME,
    actions: [
      a('submit', '提交转账', ['0'], '2', 'primary'),
      a('execute', '执行转账', ['2'], '4', 'primary'),
      a('reject', '撤销转账', ['2'], '0', 'danger'),
    ],
  },
  financeExpenses: {
    purpose: '费用报销单：提交审批 → 审批通过 → 付款过账，付款后自动生成费用凭证。',
    category: 'doc', effects: ['voucher'], postingActions: ['execute'], scheme: COMMON_SCHEME,
    actions: [
      a('submit', '提交报销', ['0'], '1', 'primary'),
      a('approve', '审批通过', ['1'], '2', 'primary'),
      a('reject', '驳回报销', ['1'], '9', 'danger'),
      a('execute', '报销付款', ['2'], '4', 'primary'),
      a('void', '作废', ['0', '2'], '9', 'danger'),
    ],
  },
  financeIncomes: {
    purpose: '其他收入登记：确认收入 → 收款入账，入账后按收入类别生成凭证。',
    category: 'doc', effects: ['voucher'], postingActions: ['execute'], scheme: COMMON_SCHEME,
    actions: [
      a('confirm', '确认收入', ['0'], '2', 'primary'),
      a('execute', '收款入账', ['2'], '4', 'primary'),
      a('void', '作废', ['0', '2'], '9', 'danger'),
    ],
  },
  financeExpenseCategories: {
    purpose: '费用类别维护预算额度与对应科目，可调整预算但不允许直接删除在用类别。',
    category: 'setting', scheme: COMMON_SCHEME,
    actions: [
      a('budget', '调整预算', [], undefined, 'primary', false),
      a('enable', '启用类别', ['0'], '1'),
      a('disable', '停用类别', ['1'], '0', 'warning'),
      a('copy', '复制类别'),
    ],
  },
  financeIncomeCategories: {
    purpose: '收入类别维护收入科目与税率，税率变更需复核后生效。',
    category: 'setting', scheme: COMMON_SCHEME,
    actions: [
      a('verify', '税率复核', [], undefined, 'primary', false),
      a('enable', '启用类别', ['0'], '1'),
      a('disable', '停用类别', ['1'], '0', 'warning'),
      a('copy', '复制类别'),
    ],
  },
  financeReceivables: {
    purpose: '应收账单：催款提醒、收款核销与坏账处理，核销后回写来源销售单。',
    category: 'doc', effects: ['receivable'], postingActions: ['execute'], scheme: COMMON_SCHEME,
    actions: [
      a('remind', '催款提醒', ['未收款', '部分收款', '已逾期'], undefined, 'warning', false),
      a('execute', '收款核销', ['未收款', '部分收款', '已逾期'], '已结清', 'primary'),
      a('writeoff', '坏账处理', ['已逾期'], undefined, 'danger'),
    ],
  },
  financePaymentsIn: {
    purpose: '收款单：确认到账后核销应收并生成收款凭证，未确认的收款不参与对账。',
    category: 'doc', effects: ['receivable', 'voucher'], postingActions: ['execute'], scheme: COMMON_SCHEME,
    actions: [
      a('confirm', '确认到账', ['待确认'], '已确认', 'primary'),
      a('execute', '核销应收', ['已确认'], undefined, 'primary'),
      a('reject', '退回款项', ['待确认'], undefined, 'danger'),
    ],
  },
  financePayables: {
    purpose: '应付账单：付款预约、付款核销与争议挂起，核销后回写来源采购单。',
    category: 'doc', effects: ['payable'], postingActions: ['execute'], scheme: COMMON_SCHEME,
    actions: [
      a('remind', '付款预约', ['未付款', '部分付款', '已逾期'], undefined, 'warning', false),
      a('execute', '付款核销', ['未付款', '部分付款', '已逾期'], '已结清', 'primary'),
      a('hold', '争议挂起', ['未付款', '部分付款'], undefined, 'danger'),
    ],
  },
  financePaymentsOut: {
    purpose: '付款单：确认付款后核销应付并生成付款凭证，付款前需复核收款账户。',
    category: 'doc', effects: ['payable', 'voucher'], postingActions: ['execute'], scheme: COMMON_SCHEME,
    actions: [
      a('confirm', '确认付款', ['待确认'], '已确认', 'primary'),
      a('execute', '核销应付', ['已确认'], undefined, 'primary'),
      a('reject', '退回付款', ['待确认'], undefined, 'danger'),
    ],
  },
  financeReceivableAging: {
    purpose: '应收账龄分析：按账龄区间查看逾期分布，仅查询与导出，不改动账单。',
    category: 'report', effects: [],
    actions: [ro('refresh', '刷新账龄'), ro('export', '导出账龄表'), ro('print', '打印')],
  },
  financeAssets: {
    purpose: '固定资产台账：在用/闲置/处置全生命周期，处置时停止计提折旧。',
    category: 'master', scheme: COMMON_SCHEME,
    actions: [
      a('transfer', '部门调拨', ['USING', 'IDLE'], undefined, 'primary', false),
      a('idle', '转闲置', ['USING'], 'IDLE', 'warning'),
      a('dispose', '资产处置', ['USING', 'IDLE'], 'DISPOSED', 'danger'),
      a('copy', '复制资产'),
    ],
  },
  financeDepreciations: {
    purpose: '折旧计提：待计提 → 计提过账 → 已计提，过账后生成折旧凭证并回写资产累计折旧。',
    category: 'doc', effects: ['voucher', 'asset'], postingActions: ['execute'], scheme: COMMON_SCHEME,
    actions: [
      a('calculate', '试算折旧', ['0'], undefined, 'primary', false),
      a('execute', '计提过账', ['0'], '1', 'primary'),
      a('void', '作废计提', ['0'], '9', 'danger'),
    ],
  },
  financeInvoices: {
    purpose: '发票登记：待开票 → 已开票 → 已认证，认证前不可用于税前扣除。',
    category: 'doc', effects: [],
    actions: [
      a('issue', '登记开票', ['0'], '1', 'primary'),
      a('certify', '发票认证', ['1'], '2', 'primary'),
      a('void', '发票作废', ['0', '1'], '9', 'danger'),
    ],
  },
  financeTrialBalance: {
    purpose: '试算平衡表：校验本期借贷合计是否平衡，只读报表不产生凭证。',
    category: 'report', effects: [],
    actions: [a('check', '平衡校验', [], undefined, 'primary', false), ro('export', '导出平衡表'), ro('print', '打印')],
  },
  financePeriods: {
    purpose: '会计期间：开启后方可录凭证，结账后凭证只读，反结账需二次确认。',
    category: 'setting', scheme: COMMON_SCHEME,
    actions: [
      a('open', '开启期间', ['0'], '1', 'primary'),
      a('close', '期末结账', ['1'], '2', 'primary'),
      a('reopen', '反结账', ['2'], '1', 'danger'),
    ],
  },
  financeCosts: {
    purpose: '成本核算：归集材料/人工/制造费用，结转后写入产品成本。',
    category: 'doc', effects: ['voucher', 'cost'], postingActions: ['execute'], scheme: COMMON_SCHEME,
    actions: [
      a('calculate', '重新归集', ['0'], undefined, 'primary', false),
      a('execute', '成本结转', ['0'], '1', 'primary'),
      a('void', '作废核算', ['0'], '9', 'danger'),
    ],
  },

  /* --------------------------- 协同办公 --------------------------- */
  collabChat: {
    purpose: '企业聊天：按频道查看项目沟通记录，支持发送消息与归档频道。',
    category: 'log', effects: [],
    actions: [a('send', '发送消息', [], undefined, 'primary', false), a('archive', '归档频道', ['1'], '0', 'warning'), a('enable', '恢复频道', ['0'], '1')],
  },
  collabNotices: {
    purpose: '公告发布：草稿 → 发布 → 失效，发布后向全员推送通知。',
    category: 'doc', effects: ['notice'], postingActions: ['publish'], scheme: COMMON_SCHEME,
    actions: [
      a('publish', '发布公告', ['DRAFT'], 'PUBLISHED', 'primary'),
      a('update', '修订公告', ['PUBLISHED'], undefined, 'primary', false),
      a('expire', '公告失效', ['PUBLISHED'], 'EXPIRED', 'warning'),
      a('copy', '复制公告'),
    ],
  },
  collabMeetings: {
    purpose: '会议管理：待召开 → 进行中 → 已结束，结束后沉淀会议纪要。',
    category: 'doc', effects: ['notice'], postingActions: ['finish'], scheme: COMMON_SCHEME,
    actions: [
      a('start', '开始会议', ['PLAN'], 'DOING', 'primary'),
      a('finish', '结束会议', ['DOING'], 'DONE', 'primary'),
      a('cancel', '取消会议', ['PLAN', 'DOING'], 'CANCELED', 'danger'),
    ],
  },
  collabProjects: {
    purpose: '项目管理：规划 → 启动 → 暂停/完工，进度与预算随状态同步更新。',
    category: 'doc', effects: ['notice'], postingActions: ['finish'], scheme: COMMON_SCHEME,
    actions: [
      a('start', '启动项目', ['PLAN'], 'DOING', 'primary'),
      a('pause', '暂停项目', ['DOING'], 'PAUSED', 'warning'),
      a('resume', '恢复项目', ['PAUSED'], 'DOING', 'primary'),
      a('finish', '项目完工', ['DOING'], 'DONE', 'primary'),
    ],
  },
  collabTasks: {
    purpose: '任务执行：待办 → 进行中 → 已完成，可重新打开未完成的任务。',
    category: 'doc', effects: ['notice'], postingActions: ['complete'], scheme: COMMON_SCHEME,
    actions: [
      a('assign', '指派负责人', [], undefined, 'primary', false),
      a('start', '开始任务', ['待办'], '进行中', 'primary'),
      a('complete', '完成任务', ['进行中'], '已完成', 'primary'),
      a('reopen', '重新打开', ['已完成'], '待办', 'warning'),
    ],
  },
  collabBoard: {
    purpose: '任务看板：按待办/进行中/评审/完成四阶段推进，阶段变化即回写进度。',
    category: 'doc', effects: ['notice'], postingActions: ['done'], scheme: COMMON_SCHEME,
    actions: [
      a('doing', '进入进行中', ['TODO'], 'DOING', 'primary'),
      a('review', '提交评审', ['DOING'], 'REVIEW', 'primary'),
      a('done', '评审通过', ['REVIEW'], 'DONE', 'primary'),
      a('back', '退回待办', ['DOING', 'REVIEW'], 'TODO', 'warning'),
    ],
  },
  collabMilestones: {
    purpose: '项目里程碑：未开始 → 进行中 → 完成，延期需单独标记并通知项目负责人。',
    category: 'doc', effects: ['notice'], postingActions: ['finish'], scheme: COMMON_SCHEME,
    actions: [
      a('start', '开始里程碑', ['PENDING'], 'DOING', 'primary'),
      a('finish', '里程碑达成', ['DOING', 'DELAY'], 'DONE', 'primary'),
      a('delay', '标记延期', ['PENDING', 'DOING'], 'DELAY', 'danger'),
    ],
  },
  collabProjectReports: {
    purpose: '项目报告：汇总进度、预算与风险项，仅生成和导出，不直接改动项目数据。',
    category: 'report', effects: [],
    actions: [a('generate', '生成报告', [], undefined, 'primary', false), ro('export', '导出报告'), ro('print', '打印')],
  },
  collabFiles: {
    purpose: '文件档案：版本上传与归档，归档后文件仍可查看但不再参与协作。',
    category: 'setting', scheme: COMMON_SCHEME,
    actions: [
      a('newVersion', '上传新版本', [], undefined, 'primary', false),
      a('archive', '归档文件', ['1'], '0', 'warning'),
      a('restore', '恢复文件', ['0'], '1', 'primary'),
    ],
  },
  aiRagDocs: {
    purpose: '知识库：文档入库后才可被 AI 检索，下架后停止引用但保留历史。',
    category: 'setting', scheme: COMMON_SCHEME,
    actions: [
      a('index', '建立索引', [], undefined, 'primary', false),
      a('disable', '下架文档', ['1'], '0', 'warning'),
      a('enable', '重新上架', ['0'], '1'),
    ],
  },

  /* --------------------------- 人事行政 --------------------------- */
  hrCompanies: {
    purpose: '公司主体维护：登记工商与组织信息，停用后不再作为开票/签约主体。',
    category: 'setting', scheme: COMMON_SCHEME,
    actions: [a('enable', '启用主体', ['0'], '1', 'primary'), a('disable', '停用主体', ['1'], '0', 'warning'), a('copy', '复制主体')],
  },
  systemOrgs: {
    purpose: '组织部门维护：调整部门归属与负责人，停用后不再接收待办分派。',
    category: 'setting', scheme: COMMON_SCHEME,
    actions: [a('enable', '启用部门', ['0'], '1', 'primary'), a('disable', '停用部门', ['1'], '0', 'warning'), a('copy', '复制部门')],
  },
  hrDepartments: {
    purpose: '部门档案：维护部门编制、负责人与上下级关系，停用后不再接收待办分派。',
    category: 'setting', scheme: COMMON_SCHEME,
    actions: [a('enable', '启用部门', ['0'], '1', 'primary'), a('disable', '停用部门', ['1'], '0', 'warning'), a('transferDept', '调整归属', [], undefined, 'primary', false)],
  },
  hrPositions: {
    purpose: '岗位与编制：维护岗位级别、编制人数与薪资范围，编制满员前需审批。',
    category: 'setting', scheme: COMMON_SCHEME,
    actions: [
      a('enable', '启用岗位', ['0'], '1', 'primary'),
      a('disable', '停用岗位', ['1'], '0', 'warning'),
      a('copy', '复制岗位'),
    ],
  },
  hrShifts: {
    purpose: '排班管理：班次确认后写入考勤基准，取消需同步调整当日打卡规则。',
    category: 'doc', effects: ['attendance'], postingActions: ['confirm'], scheme: COMMON_SCHEME,
    actions: [
      a('confirm', '确认班次', ['0'], '1', 'primary'),
      a('cancel', '取消班次', ['0', '1'], '9', 'danger'),
      a('copy', '复制班次'),
    ],
  },
  hrEmployees: {
    purpose: '员工档案：试用转正、内部调岗与离职办理，离职后停止排班与薪资发放。',
    category: 'master', effects: ['attendance'], scheme: COMMON_SCHEME,
    actions: [
      a('onboard', '试用转正', ['试用'], '在职', 'primary'),
      a('transfer', '内部调岗', ['在职', '试用'], undefined, 'primary', false),
      a('offboard', '办理离职', ['在职', '试用'], '离职', 'danger'),
      a('copy', '复制档案'),
    ],
  },
  hrAttendance: {
    purpose: '出勤率统计：补卡/异常说明只更正当日考勤，不改动历史打卡原始记录。',
    category: 'log', effects: [],
    actions: [a('correct', '异常补卡', [], undefined, 'primary', false), ro('export', '导出考勤'), ro('print', '打印')],
  },
  hrLeaves: {
    purpose: '请假审批：提交 → 通过/驳回，通过后自动写入考勤并扣减可用假期。',
    category: 'doc', effects: ['attendance'], postingActions: ['approve'], scheme: COMMON_SCHEME,
    actions: [
      a('submit', '提交请假', ['0'], '1', 'primary'),
      a('approve', '审批通过', ['1'], '2', 'primary'),
      a('reject', '审批驳回', ['1'], '3', 'danger'),
      a('cancel', '撤销请假', ['0', '1'], '9', 'warning'),
    ],
  },
  hrHolidays: {
    purpose: '节假日与假期余额：确认后同步到全员日历，作废需二次确认。',
    category: 'setting', scheme: COMMON_SCHEME,
    actions: [
      a('confirm', '确认假期', ['PENDING'], 'APPROVED', 'primary'),
      a('cancel', '撤销假期', ['PENDING', 'APPROVED'], 'CANCELED', 'warning'),
      a('copy', '复制假期'),
    ],
  },
  hrPayrolls: {
    purpose: '工资单：核算薪资 → 发放工资，发放后生成应付职工薪酬凭证。',
    category: 'doc', effects: ['voucher', 'attendance'], postingActions: ['pay'], scheme: COMMON_SCHEME,
    actions: [
      a('calculate', '核算工资', ['0'], '1', 'primary'),
      a('pay', '发放工资', ['1'], '2', 'primary'),
      a('void', '作废工资单', ['0', '1'], '9', 'danger'),
    ],
  },
  hrContracts: {
    purpose: '劳动合同：生效中 → 即将到期 → 已到期/终止，续签需生成新合同。',
    category: 'doc', effects: [], scheme: COMMON_SCHEME,
    actions: [
      a('renew', '合同续签', ['EXPIRING', 'EXPIRED'], 'ACTIVE', 'primary'),
      a('expire', '标记到期', ['ACTIVE'], 'EXPIRED', 'warning'),
      a('terminate', '终止合同', ['ACTIVE', 'EXPIRING'], 'TERMINATED', 'danger'),
    ],
  },
  crmLeads: {
    purpose: '候选人筛选：待筛选 → 面试中 → 录用/淘汰，录用后转员工档案。',
    category: 'doc', effects: ['notice'], postingActions: ['hire'], scheme: COMMON_SCHEME,
    actions: [
      a('screen', '简历筛选', ['NEW'], 'FOLLOW', 'primary'),
      a('interview', '安排面试', ['FOLLOW'], undefined, 'primary', false),
      a('hire', '录用候选人', ['FOLLOW'], 'CONVERTED', 'primary'),
      a('reject', '候选人淘汰', ['NEW', 'FOLLOW'], 'LOST', 'danger'),
    ],
  },
  hrInterviews: {
    purpose: '面试安排：待定 → 通过/不通过 → 录用，评分低于合格线不可直接录用。',
    category: 'doc', effects: ['notice'], postingActions: ['hire'], scheme: COMMON_SCHEME,
    actions: [
      a('score', '录入评分', [], undefined, 'primary', false),
      a('pass', '面试通过', ['PENDING'], 'PASS', 'primary'),
      a('fail', '面试不通过', ['PENDING'], 'FAIL', 'danger'),
      a('hire', '确认录用', ['PASS'], 'HIRED', 'primary'),
    ],
  },
  hrAssets: {
    purpose: '员工资产领用：在用 → 归还/损坏/遗失，归还后资产回到可分配池。',
    category: 'master', scheme: COMMON_SCHEME,
    actions: [
      a('assign', '重新分配', ['RETURNED'], 'IN_USE', 'primary'),
      a('return', '资产归还', ['IN_USE'], 'RETURNED', 'primary'),
      a('damage', '报损', ['IN_USE'], 'DAMAGED', 'danger'),
      a('lost', '报失', ['IN_USE'], 'LOST', 'danger'),
    ],
  },
  hrVehicles: {
    purpose: '车辆管理：空闲派车、使用登记、保养与报废，保养期间禁止派车。',
    category: 'master', scheme: COMMON_SCHEME,
    actions: [
      a('dispatch', '派车', ['IDLE'], 'IN_USE', 'primary'),
      a('release', '收车', ['IN_USE'], 'IDLE', 'primary'),
      a('service', '送保养', ['IDLE', 'IN_USE'], 'MAINTAIN', 'warning'),
      a('scrap', '车辆报废', ['IDLE', 'MAINTAIN'], 'SCRAPPED', 'danger'),
    ],
  },
};
