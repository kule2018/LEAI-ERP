/**
 * 页面业务画像注册表（Page Profiles）
 * ---------------------------------------------------------------------------
 * 目的：让「商城渠道 / 打印中心 / AI 助手 / 系统管理」四个模块下的每一个页面
 *       拥有**专属的业务功能**，而不是共用一个千篇一律的通用 BusinessPage。
 *
 * 每个画像定义：页面定位说明、专属动作（含状态守卫）、专属统计卡、专属工具条
 * 与业务提示。BusinessPage 读取画像后按配置渲染，因此：
 *   - 不同页面的按钮、流程、统计口径、提示语各不相同；
 *   - 状态守卫严格按各业务真实状态文案匹配，避免「流程全错」；
 *   - 页面头部说明 + 统一间距，解决「内容乱、没间距」的问题。
 *
 * 该文件为纯数据 + 纯函数，不依赖任何组件或接口层，避免循环依赖。
 */

import type { BizCategory } from './businessFlows';

/** 动作风格 */
export type ProfileActionVariant = 'primary' | 'default' | 'danger' | 'warning';

/** 页面专属业务动作 */
export interface ProfileAction {
  /** 动作标识，交给业务引擎执行 */
  key: string;
  /** 按钮文案 */
  label: string;
  /** 图标（emoji，保持轻量） */
  icon?: string;
  /** 按钮风格 */
  variant?: ProfileActionVariant;
  /**
   * 允许触发的当前状态值（与 Schema 的 statusLabels 值或文案匹配）。
   * 留空表示任意状态均可触发。
   */
  from?: string[];
  /** 执行后的目标状态值 */
  to?: string;
  /** 是否需要二次确认 */
  confirm?: boolean;
  /** 是否为 destructive 动作（红色强调） */
  danger?: boolean;
  /** 是否支持批量执行 */
  batchable?: boolean;
  /** 点击后端副作用说明（用于确认弹窗提示） */
  effect?: string;
}

/** 统计卡口径 */
export interface ProfileStat {
  label: string;
  /** 计算方式 */
  compute: 'count' | 'sum' | 'status' | 'nonempty' | 'avg';
  /** sum / avg 使用的字段名，或 nonempty 判断的字段 */
  field?: string;
  /** status 计算匹配的状态值（可多个） */
  values?: string[];
  /** 数值前缀/后缀 */
  prefix?: string;
  suffix?: string;
  tone?: 'brand' | 'success' | 'warning' | 'danger' | '';
}

/** 页面画像 */
export interface PageProfile {
  /** 唯一标识（与各包装页 profile-key 对应） */
  key: string;
  /** 所属模块 */
  module: 'shop' | 'print' | 'ai' | 'system' | 'finance' | 'collab' | 'hr';
  /** 页面标题 */
  title: string;
  /** 页面定位说明（展示在页面头部，明确「这页是干什么的」） */
  subtitle: string;
  /** 页面图标 */
  icon: string;
  /** 主题色（用于页面头部强调条） */
  accent: string;
  /** 业务分类（决定兜底动作语义） */
  category: BizCategory;
  /** 专属动作列表 */
  actions: ProfileAction[];
  /** 4 张专属统计卡 */
  stats: ProfileStat[];
  /** 业务提示（展示在页面头部右侧，帮助用户理解流程） */
  tips: string[];
  /** 专属功能区：决定页面主体的呈现形态（卡片墙/看板/时间线/树/配置器等） */
  feature?: { type: string; config?: Record<string, any> };
}

/** 动作简写：减少重复配置 */
const act = (
  key: string,
  label: string,
  icon: string,
  extra: Partial<ProfileAction> = {},
): ProfileAction => ({ key, label, icon, variant: 'default', ...extra });

/** 统计简写 */
const stat = (
  label: string,
  compute: ProfileStat['compute'],
  extra: Partial<ProfileStat> = {},
): ProfileStat => ({ label, compute, ...extra });

/* ========================================================================== */
/*                              商城渠道                                       */
/* ========================================================================== */

const shopProfiles: PageProfile[] = [
  {
    key: 'shop-stores', module: 'shop', title: '线上店铺', icon: '🏬', accent: '#7c5cff',
    subtitle: '管理各电商平台店铺的授权、状态与订单汇总；支持授权校验、订单同步与店铺关闭，全流程可追溯。',
    category: 'master',
    tips: ['授权过期店铺需先「授权校验」再同步', '关闭店铺前请确认无在途订单'],
    actions: [
      act('authCheck', '授权校验', '🔑', { variant: 'primary', from: ['AUTHORIZED', 'EXPIRED', '已授权', '授权过期'], confirm: true, effect: '重新校验平台授权令牌并刷新店铺状态' }),
      act('syncOrders', '同步订单', '🔄', { variant: 'primary', from: ['AUTHORIZED', '已授权'], effect: '从平台拉取最新订单写入平台订单' }),
      act('closeStore', '关闭店铺', '🚫', { from: ['AUTHORIZED', 'EXPIRED', '已授权', '授权过期'], danger: true, variant: 'danger', confirm: true, effect: '关闭店铺并停止订单同步' }),
      act('copy', '复制', '📋', {}),
    ],
    stats: [
      stat('店铺总数', 'count', { tone: 'brand' }),
      stat('已授权', 'status', { values: ['AUTHORIZED', '已授权'], tone: 'success' }),
      stat('授权过期', 'status', { values: ['EXPIRED', '授权过期'], tone: 'warning' }),
      stat('累计订单', 'sum', { field: 'orderCount', suffix: ' 单' }),
    ],
  },
  {
    key: 'shop-channels', module: 'shop', title: '渠道配置', icon: '🔀', accent: '#5b8cff',
    subtitle: '配置各销售渠道的佣金比例与结算周期，控制渠道启停；佣金变更仅对新增订单生效。',
    category: 'setting',
    tips: ['佣金比例变更不影响历史订单', '停用渠道后该渠道不再接收新订单'],
    actions: [
      act('configCommission', '配置佣金', '💰', { variant: 'primary', confirm: true, effect: '更新渠道佣金比例与结算周期' }),
      act('generateSettle', '生成结算单', '🧾', { from: ['1', '启用'], confirm: true, effect: '按结算周期生成渠道结算单' }),
      act('toggle', '启用/停用', '🔘', { confirm: true }),
      act('copy', '复制', '📋', {}),
    ],
    stats: [
      stat('渠道总数', 'count', { tone: 'brand' }),
      stat('启用中', 'status', { values: ['1', '启用'], tone: 'success' }),
      stat('平均佣金', 'avg', { field: 'commissionRate', suffix: '%' }),
      stat('结算周期种类', 'nonempty', { field: 'settleCycle' }),
    ],
  },
  {
    key: 'shop-goods-maps', module: 'shop', title: '商品映射', icon: '🔗', accent: '#20a0a0',
    subtitle: '维护平台 SKU 与内部产品的映射关系，支持一键校验映射、同步平台价格与库存。',
    category: 'master',
    tips: ['价格差异过大时请先核对平台活动价', '映射失效会导致订单无法入库'],
    actions: [
      act('verifyMap', '校验映射', '✅', { variant: 'primary', confirm: true, effect: '校验平台 SKU 与内部产品映射有效性' }),
      act('syncPrice', '同步价格', '💵', { effect: '将内部售价同步至平台商品' }),
      act('syncStock', '同步库存', '📦', { effect: '将内部可用库存回传平台' }),
      act('toggle', '启用/停用', '🔘', { confirm: true }),
    ],
    stats: [
      stat('映射总数', 'count', { tone: 'brand' }),
      stat('已启用', 'status', { values: ['1', '启用'], tone: 'success' }),
      stat('有价格差', 'nonempty', { field: 'priceDiff', tone: 'warning' }),
      stat('关联店铺', 'nonempty', { field: 'storeName' }),
    ],
  },
  {
    key: 'shop-orders', module: 'shop', title: '平台订单', icon: '🧾', accent: '#ff8a3d',
    subtitle: 'OMS 平台订单全链路：拉取订单 → 审核 → 发货回传 → 完成对账，状态严格按平台订单流转。',
    category: 'doc',
    tips: ['仅「待发货」订单可发货回传', '发货后库存自动扣减并生成销售单'],
    actions: [
      act('pullOrder', '拉取订单', '⬇️', { variant: 'primary', effect: '从各平台拉取最新订单' }),
      act('review', '审核订单', '🔍', { variant: 'primary', from: ['待付款', '待发货'], confirm: true, effect: '校验地址、库存与风控后审核通过' }),
      act('ship', '发货回传', '🚚', { variant: 'primary', from: ['待发货'], to: '已发货', confirm: true, effect: '扣减库存、回传物流单号并生成销售单' }),
      act('reconcile', '对账', '🧮', { from: ['已发货', '已完成'], effect: '与平台账单核对金额与手续费' }),
      act('cancelOrder', '取消订单', '🚫', { from: ['待付款', '待发货'], danger: true, variant: 'danger', confirm: true, effect: '取消订单并回滚库存占用' }),
    ],
    stats: [
      stat('订单总数', 'count', { tone: 'brand' }),
      stat('待发货', 'status', { values: ['待发货'], tone: 'warning' }),
      stat('已发货', 'status', { values: ['已发货'], tone: 'success' }),
      stat('订单金额', 'sum', { field: 'amount', prefix: '¥' }),
    ],
  },
  {
    key: 'shop-coupons', module: 'shop', title: '优惠券', icon: '🎟️', accent: '#ff5c8a',
    subtitle: '管理优惠券的发行、投放与核销；支持暂停投放、查看核销进度，到期券自动结束。',
    category: 'master',
    tips: ['暂停后用户不可领取，已领取券仍可使用', '核销量达到发行量时自动结束'],
    actions: [
      act('issue', '发放券码', '🎁', { variant: 'primary', from: ['ACTIVE', '进行中', '1', '启用'], confirm: true, effect: '批量生成券码并投放至渠道' }),
      act('pause', '暂停投放', '⏸️', { from: ['ACTIVE', '进行中', '1', '启用'], confirm: true, effect: '暂停优惠券领取' }),
      act('resume', '恢复投放', '▶️', { from: ['PAUSED', '已暂停', '0', '停用'], effect: '恢复优惠券领取' }),
      act('endCoupon', '结束活动', '🏁', { from: ['ACTIVE', 'PAUSED', '进行中', '已暂停'], danger: true, variant: 'danger', confirm: true, effect: '提前结束优惠券活动' }),
    ],
    stats: [
      stat('优惠券总数', 'count', { tone: 'brand' }),
      stat('进行中', 'status', { values: ['ACTIVE', '进行中', '1', '启用'], tone: 'success' }),
      stat('已暂停', 'status', { values: ['PAUSED', '已暂停'], tone: 'warning' }),
      stat('发行总量', 'sum', { field: 'totalQty', suffix: ' 张' }),
    ],
  },
  {
    key: 'shop-promotions', module: 'shop', title: '促销活动', icon: '🎉', accent: '#e0457b',
    subtitle: '配置满减、秒杀等营销活动；活动按「未开始 → 进行中 → 已结束」流转，可随时预览活动规则。',
    category: 'doc',
    tips: ['活动开始前需先完成商品与库存校验', '活动结束后自动恢复原价'],
    actions: [
      act('previewPromo', '预览活动', '👁️', {}),
      act('startPromo', '启动活动', '🚀', { variant: 'primary', from: ['未开始'], to: '进行中', confirm: true, effect: '校验商品库存后启动活动并同步平台' }),
      act('endPromo', '结束活动', '🏁', { from: ['进行中'], to: '已结束', confirm: true, effect: '结束活动并恢复商品价格' }),
      act('voidPromo', '作废活动', '🗑️', { from: ['未开始'], danger: true, variant: 'danger', confirm: true, effect: '作废未开始的活动' }),
    ],
    stats: [
      stat('活动总数', 'count', { tone: 'brand' }),
      stat('进行中', 'status', { values: ['进行中'], tone: 'success' }),
      stat('未开始', 'status', { values: ['未开始'], tone: 'warning' }),
      stat('已结束', 'status', { values: ['已结束'] }),
    ],
  },
];

/* ========================================================================== */
/*                              打印中心                                       */
/* ========================================================================== */

const printProfiles: PageProfile[] = [
  {
    key: 'print-doc-templates', module: 'print', title: '单据模板', icon: '📐', accent: '#3a7bd5',
    subtitle: '按业务单据管理打印模板（A4 / 热敏 / 标签）；模板版本化，设为默认后新单据自动套用，历史单据不受影响。',
    category: 'setting',
    tips: ['修改模板会自动升版本', '设为默认前请先预览确认排版'],
    actions: [
      act('previewTpl', '预览模板', '👁️', { variant: 'primary', effect: '使用示例数据渲染模板预览' }),
      act('setDefault', '设为默认', '⭐', { from: ['1', '启用'], confirm: true, effect: '将该模板设为对应单据类型的默认模板' }),
      act('upgrade', '升版本', '⬆️', { confirm: true, effect: '基于当前模板创建新版本' }),
      act('toggle', '启用/停用', '🔘', { confirm: true }),
    ],
    stats: [
      stat('模板总数', 'count', { tone: 'brand' }),
      stat('启用中', 'status', { values: ['1', '启用'], tone: 'success' }),
      stat('业务类型', 'nonempty', { field: 'bizType' }),
      stat('纸张规格', 'nonempty', { field: 'paperSize' }),
    ],
  },
  {
    key: 'print-jobs', module: 'print', title: '打印执行', icon: '🖨️', accent: '#2f7de1',
    subtitle: '打印任务三通道执行：服务端 PDF、浏览器打印、本地客户端静默打印；失败任务可重试，支持批量重打。',
    category: 'doc',
    tips: ['静默打印需先启动本地打印客户端', '失败任务点击「重试」重新入队'],
    actions: [
      act('printNow', '立即打印', '🖨️', { variant: 'primary', from: ['0', '1', '排队中', '打印中'], confirm: true, effect: '按模板与通道执行打印任务' }),
      act('serverPdf', '导出 PDF', '📄', { from: ['1', '2', '打印中', '已完成'], effect: '服务端渲染并生成 PDF 文件' }),
      act('retry', '重试任务', '🔄', { from: ['9', '失败'], confirm: true, effect: '将失败任务重新加入打印队列' }),
      act('cancelJob', '取消任务', '🚫', { from: ['0', '1', '排队中', '打印中'], danger: true, variant: 'danger', confirm: true, effect: '取消尚未完成的打印任务' }),
    ],
    stats: [
      stat('任务总数', 'count', { tone: 'brand' }),
      stat('排队/打印中', 'status', { values: ['0', '1', '排队中', '打印中'], tone: 'warning' }),
      stat('已完成', 'status', { values: ['2', '已完成'], tone: 'success' }),
      stat('失败', 'status', { values: ['9', '失败'], tone: 'danger' }),
    ],
  },
  {
    key: 'print-labels', module: 'print', title: '条码标签', icon: '🏷️', accent: '#5a4fcf',
    subtitle: '维护产品 / 外箱 / 库位标签模板与绑定字段；支持批量生成条码并发送至标签打印机。',
    category: 'master',
    tips: ['绑定字段需与模板占位符一致', '批量打印建议使用标签打印机'],
    actions: [
      act('previewLabel', '预览标签', '👁️', { variant: 'primary', effect: '渲染标签模板预览' }),
      act('batchPrint', '批量生成', '🏷️', { variant: 'primary', from: ['1', '启用'], confirm: true, effect: '按绑定字段批量生成条码标签' }),
      act('toggle', '启用/停用', '🔘', { confirm: true }),
      act('copy', '复制模板', '📋', {}),
    ],
    stats: [
      stat('标签模板', 'count', { tone: 'brand' }),
      stat('启用中', 'status', { values: ['1', '启用'], tone: 'success' }),
      stat('尺寸规格', 'nonempty', { field: 'size' }),
      stat('绑定打印机', 'nonempty', { field: 'printer' }),
    ],
  },
];

/* ========================================================================== */
/*                              AI 助手                                        */
/* ========================================================================== */

const aiProfiles: PageProfile[] = [
  {
    key: 'ai-anomaly', module: 'ai', title: '异常检测', icon: '🚨', accent: '#ff6b4a',
    subtitle: 'AI 扫描库存突变、价格异常、账期逾期与重复付款；每条异常可忽略、标记已处理或转为工单，全程留痕。',
    category: 'doc',
    tips: ['高风险异常建议优先转工单跟进', '忽略的异常仍可在审计日志追溯'],
    actions: [
      act('scan', '重新扫描', '🔍', { variant: 'primary', effect: '触发 AI 异常扫描并刷新清单' }),
      act('toTicket', '转工单', '🎫', { from: ['TODO', '待处理'], confirm: true, effect: '将异常转为跟进工单并指派负责人' }),
      act('markDone', '标记已处理', '✅', { from: ['TODO', '待处理'], confirm: true, effect: '标记异常为已处理并记录处理结果' }),
      act('ignore', '忽略', '🙈', { from: ['TODO', '待处理'], danger: true, confirm: true, effect: '忽略该异常并记录原因' }),
    ],
    stats: [
      stat('异常总数', 'count', { tone: 'brand' }),
      stat('待处理', 'status', { values: ['TODO', '待处理'], tone: 'warning' }),
      stat('高风险', 'nonempty', { field: 'riskLevel', tone: 'danger' }),
      stat('已处理', 'status', { values: ['DONE', '已处理'], tone: 'success' }),
    ],
  },
  {
    key: 'ai-cs', module: 'ai', title: '智能客服', icon: '💬', accent: '#4291ff',
    subtitle: '查看 AI 客服会话记录、满意度与转人工情况；支持将会话转接人工并跟进答复质量。',
    category: 'log',
    tips: ['转人工后需在客服工作台及时跟进', '低满意度会话建议复盘话术'],
    actions: [
      act('viewSession', '查看会话', '👁️', { variant: 'primary', effect: '查看完整会话记录' }),
      act('transfer', '转人工', '👤', { from: ['OPEN', '进行中'], confirm: true, effect: '将会话转接人工客服' }),
      act('closeSession', '结束会话', '🔒', { from: ['OPEN', '进行中'], confirm: true, effect: '结束客服会话' }),
      act('export', '导出记录', '⬇️', {}),
    ],
    stats: [
      stat('会话总数', 'count', { tone: 'brand' }),
      stat('进行中', 'status', { values: ['OPEN', '进行中'], tone: 'warning' }),
      stat('已转人工', 'status', { values: ['TRANSFER', '已转人工'], tone: 'danger' }),
      stat('平均满意度', 'avg', { field: 'satisfaction', tone: 'success' }),
    ],
  },
  {
    key: 'ai-report', module: 'ai', title: '报表解读', icon: '📊', accent: '#8b5cf6',
    subtitle: 'AI 自动生成经营报表解读，给出关键指标变化与原因；可刷新解读、查看溯源并导出分析结论。',
    category: 'report',
    tips: ['解读结论仅供参考，请结合原始报表核对', '刷新会重新生成解读并计入审计'],
    actions: [
      act('generate', '生成解读', '✨', { variant: 'primary', effect: '调用 AI 重新生成该报表的解读结论' }),
      act('trace', '查看溯源', '🔎', {}),
      act('export', '导出结论', '⬇️', {}),
      act('refresh', '刷新数据', '🔄', {}),
    ],
    stats: [
      stat('解读总数', 'count', { tone: 'brand' }),
      stat('已启用', 'status', { values: ['1', '启用'], tone: 'success' }),
      stat('指标数', 'nonempty', { field: 'metricName' }),
      stat('平均变化率', 'avg', { field: 'changeRate', suffix: '%' }),
    ],
  },
  {
    key: 'ai-subject-match', module: 'ai', title: '科目匹配', icon: '🧮', accent: '#0e9f8a',
    subtitle: '维护费用摘要关键词与会计科目的匹配规则；支持测试匹配、启用停用与重新训练，置信度低于阈值需人工复核。',
    category: 'setting',
    tips: ['修改规则后建议先「测试匹配」再启用', '置信度低于 90% 的匹配需人工复核'],
    actions: [
      act('testMatch', '测试匹配', '🧪', { variant: 'primary', effect: '用示例摘要测试科目匹配结果' }),
      act('retrain', '重新训练', '🔄', { confirm: true, effect: '基于最新凭证重新训练匹配模型' }),
      act('toggle', '启用/停用', '🔘', { confirm: true }),
      act('copy', '复制规则', '📋', {}),
    ],
    stats: [
      stat('规则总数', 'count', { tone: 'brand' }),
      stat('启用中', 'status', { values: ['1', '启用'], tone: 'success' }),
      stat('平均置信度', 'avg', { field: 'confidence', suffix: '%' }),
      stat('累计命中', 'sum', { field: 'hitCount', suffix: ' 次' }),
    ],
  },
];

/* ========================================================================== */
/*                              系统管理                                       */
/* ========================================================================== */

/** 日志类通用画像生成：审计/登录日志等只读页面 */
function logProfile(key: string, title: string, icon: string, subtitle: string, tips: string[]): PageProfile {
  return {
    key, module: 'system', title, icon, accent: '#64748b', subtitle, category: 'log', tips,
    actions: [
      act('viewLog', '查看详情', '👁️', { variant: 'primary', effect: '查看日志记录详情' }),
      act('export', '导出日志', '⬇️', {}),
      act('refresh', '刷新', '🔄', {}),
    ],
    stats: [
      stat('日志总数', 'count', { tone: 'brand' }),
      stat('今日记录', 'nonempty', { field: 'createdAt', tone: 'success' }),
      stat('涉及模块', 'nonempty', { field: 'module' }),
      stat('操作人', 'nonempty', { field: 'operator' }),
    ],
  };
}

/** 基础数据类通用画像生成：字典/组织/角色等主数据页面 */
function masterProfile(key: string, title: string, icon: string, subtitle: string, accent: string, tips: string[]): PageProfile {
  return {
    key, module: 'system', title, icon, accent, subtitle, category: 'master', tips,
    actions: [
      act('toggle', '启用/停用', '🔘', { variant: 'primary', confirm: true, effect: '切换启用状态并写入审计日志' }),
      act('copy', '复制', '📋', {}),
      act('export', '导出', '⬇️', {}),
    ],
    stats: [
      stat('记录总数', 'count', { tone: 'brand' }),
      stat('正常', 'status', { values: ['1', '启用', '正常'], tone: 'success' }),
      stat('停用', 'status', { values: ['0', '停用'], tone: 'warning' }),
      stat('编码完整', 'nonempty', { field: 'code' }),
    ],
  };
}

const systemProfiles: PageProfile[] = [
  logProfile('system-audit-logs', '审计日志', '📜',
    '记录谁在何时修改了什么数据；支持按业务单号追溯操作轨迹，日志不可删除。',
    ['日志仅可查看与导出，不可修改', '可按单据 ID 筛选关联操作']),
  logProfile('system-login-logs', '登录日志', '🔐',
    '记录登录时间、IP 与设备信息；异常登录可联动 AI 风险预警，支持导出排查。',
    ['关注异地/陌生设备登录', '连续失败登录建议检查账号安全']),
  masterProfile('system-orgs', '组织租户', '🏢',
    '维护公司/组织基础数据与多租户隔离；组织停用后其下用户将无法登录。',
    '#3b82f6', ['停用组织前请确认无在途业务', '组织编码在租户内唯一']),
  masterProfile('system-roles', '角色', '🎭',
    '维护角色与权限范围；可为角色批量配置菜单/按钮/接口权限，角色停用后用户自动失效。',
    '#8b5cf6', ['ADMIN 角色拥有全部权限', '修改角色权限后立即生效']),
  masterProfile('system-permissions', '权限', '🔑',
    '维护菜单、按钮与接口权限码；前端 v-perm 与后端 @RequirePerm 使用同一套权限码。',
    '#0ea5e9', ['权限码需与后端注解保持一致', '新增权限码后需同步角色授权']),
  masterProfile('system-data-scopes', '数据权限', '🛡️',
    '配置行级数据权限（本人/本部门/本组织/全部）；查询时自动拼接数据隔离条件。',
    '#14b8a6', ['数据权限与角色绑定生效', '「全部」范围需谨慎授予']),
  masterProfile('system-dicts', '数据字典', '📖',
    '统一维护状态、单位、支付方式等枚举；字典变更即时影响全站下拉选项。',
    '#f59e0b', ['字典编码在同类内唯一', '停用枚举项不影响历史数据展示']),
  masterProfile('system-sequences', '编码规则', '🔢',
    '配置单据编码规则（前缀 + 日期 + 流水）；支持按组织与日期独立 numbering。',
    '#6366f1', ['规则变更后仅对新单据生效', '流水号按组织+日期独立递增']),
  {
    key: 'system-nos', module: 'system', title: '单据编号', icon: '#️⃣', accent: '#0ea5e9',
    subtitle: '管理各类单据流水号与断号处理；支持跳号、补号与高并发无重复取号。',
    category: 'setting',
    tips: ['补号需确认原号未被占用', '断号处理会写入审计日志'],
    actions: [
      act('nextNo', '测试取号', '🎫', { variant: 'primary', effect: '按规则测试生成下一个单据编号' }),
      act('fillGap', '断号补号', '🔧', { confirm: true, effect: '补录断号并记录操作' }),
      act('toggle', '启用/停用', '🔘', { confirm: true }),
    ],
    stats: [
      stat('规则总数', 'count', { tone: 'brand' }),
      stat('启用中', 'status', { values: ['1', '启用', '正常'], tone: 'success' }),
      stat('前缀种类', 'nonempty', { field: 'prefix' }),
      stat('当前流水', 'sum', { field: 'currentNo' }),
    ],
  },
  {
    key: 'system-settings', module: 'system', title: '系统参数', icon: '⚙️', accent: '#475569',
    subtitle: '维护全局参数（税率、币种、精度、库存负卖开关等）；保存并生效后立即影响业务规则。',
    category: 'setting',
    tips: ['关键参数变更需二次确认', '参数生效后写入审计日志'],
    actions: [
      act('apply', '保存并生效', '💾', { variant: 'primary', confirm: true, effect: '保存参数并即时生效' }),
      act('test', '参数校验', '🧪', { effect: '校验参数取值合法性' }),
      act('reset', '恢复默认', '↩️', { danger: true, variant: 'danger', confirm: true, effect: '恢复参数为系统默认值' }),
    ],
    stats: [
      stat('参数总数', 'count', { tone: 'brand' }),
      stat('已配置', 'nonempty', { field: 'cfgValue', tone: 'success' }),
      stat('参数分组', 'nonempty', { field: 'cfgKey' }),
      stat('启用中', 'status', { values: ['1', '启用'], tone: 'success' }),
    ],
  },
  {
    key: 'system-files', module: 'system', title: '文件存储', icon: '📁', accent: '#0284c7',
    subtitle: '统一管理附件、图片与文档；支持查看存储信息、下载与清理孤儿文件。',
    category: 'master',
    tips: ['清理前请确认文件未被单据引用', '大文件建议使用对象存储'],
    actions: [
      act('viewFile', '查看详情', '👁️', { variant: 'primary', effect: '查看文件存储详情' }),
      act('download', '下载', '⬇️', {}),
      act('cleanOrphan', '清理孤儿文件', '🧹', { danger: true, variant: 'danger', confirm: true, effect: '清理未被任何单据引用的文件' }),
    ],
    stats: [
      stat('文件总数', 'count', { tone: 'brand' }),
      stat('图片', 'nonempty', { field: 'fileUrl', tone: 'success' }),
      stat('存储类型', 'nonempty', { field: 'storage' }),
      stat('孤儿文件', 'nonempty', { field: 'orphan', tone: 'warning' }),
    ],
  },
  {
    key: 'system-jobs', module: 'system', title: '定时任务', icon: '⏰', accent: '#f97316',
    subtitle: '管理 CRON 定时任务（预测、对账、预警、月结）；支持立即执行、启用停用与查看执行日志。',
    category: 'setting',
    tips: ['立即执行不影响原调度计划', '连续失败的任务请检查执行日志'],
    actions: [
      act('runNow', '立即执行', '▶️', { variant: 'primary', from: ['1', '启用', '正常'], confirm: true, effect: '立即触发一次定时任务' }),
      act('viewLog', '执行日志', '📋', {}),
      act('toggle', '启用/停用', '🔘', { confirm: true }),
    ],
    stats: [
      stat('任务总数', 'count', { tone: 'brand' }),
      stat('启用中', 'status', { values: ['1', '启用', '正常'], tone: 'success' }),
      stat('已停用', 'status', { values: ['0', '停用'], tone: 'warning' }),
      stat('执行记录', 'nonempty', { field: 'lastRun' }),
    ],
  },
  {
    key: 'system-notifies', module: 'system', title: '通知中心', icon: '🔔', accent: '#e11d48',
    subtitle: '集中查看审批、预警与对账到期提醒；支持标记已读、发送消息与配置推送渠道。',
    category: 'log',
    tips: ['未读通知建议及时处理', '重要通知可配置多通道推送'],
    actions: [
      act('viewNotify', '查看详情', '👁️', { variant: 'primary', effect: '查看通知详情' }),
      act('markRead', '标记已读', '✅', { effect: '将通知标记为已读' }),
      act('send', '发送消息', '📤', { confirm: true, effect: '向指定对象发送站内信' }),
    ],
    stats: [
      stat('通知总数', 'count', { tone: 'brand' }),
      stat('未读', 'nonempty', { field: 'isRead', tone: 'warning' }),
      stat('已读', 'status', { values: ['1', '已读'], tone: 'success' }),
      stat('通知类型', 'nonempty', { field: 'type' }),
    ],
  },
  {
    key: 'system-events', module: 'system', title: '消息订阅', icon: '📡', accent: '#7c3aed',
    subtitle: '管理领域事件订阅；单据状态变更驱动下游处理，支持订阅、取消订阅与查看事件轨迹。',
    category: 'setting',
    tips: ['取消订阅后不再推送该事件', '订阅关系变更即时生效'],
    actions: [
      act('subscribe', '订阅事件', '➕', { variant: 'primary', effect: '订阅该领域事件' }),
      act('unsubscribe', '取消订阅', '➖', { from: ['1', '启用', '正常'], confirm: true, effect: '取消事件订阅' }),
      act('viewTrace', '事件轨迹', '🔎', {}),
    ],
    stats: [
      stat('事件总数', 'count', { tone: 'brand' }),
      stat('已订阅', 'status', { values: ['1', '启用', '正常'], tone: 'success' }),
      stat('事件源', 'nonempty', { field: 'source' }),
      stat('处理器', 'nonempty', { field: 'handler' }),
    ],
  },
  {
    key: 'system-alert-rules', module: 'system', title: '告警规则', icon: '🚨', accent: '#dc2626',
    subtitle: '配置监控告警规则（阈值、触发条件与动作）；支持试算验证规则并控制规则启停。',
    category: 'setting',
    tips: ['规则试算不会真的触发告警', '阈值变更需二次确认'],
    actions: [
      act('test', '规则试算', '🧪', { variant: 'primary', effect: '用当前数据试算告警规则命中情况' }),
      act('toggle', '启用/停用', '🔘', { confirm: true }),
      act('copy', '复制规则', '📋', {}),
    ],
    stats: [
      stat('规则总数', 'count', { tone: 'brand' }),
      stat('启用中', 'status', { values: ['1', '启用', '正常'], tone: 'success' }),
      stat('已停用', 'status', { values: ['0', '停用'], tone: 'warning' }),
      stat('触发动作', 'nonempty', { field: 'action' }),
    ],
  },
  {
    key: 'system-view-configs', module: 'system', title: '我的视图', icon: '👁️', accent: '#0891b2',
    subtitle: '保存个人列表视图（列显隐、排序、列宽、密度）；按路由与角色自动恢复，支持设为默认视图。',
    category: 'setting',
    tips: ['视图按「路由 + 角色」自动恢复', '设为默认后影响同角色用户'],
    actions: [
      act('applyView', '应用视图', '✅', { variant: 'primary', effect: '将视图配置应用到当前列表' }),
      act('setDefault', '设为默认', '⭐', { confirm: true, effect: '将该视图设为默认视图' }),
      act('copy', '复制视图', '📋', {}),
    ],
    stats: [
      stat('视图总数', 'count', { tone: 'brand' }),
      stat('默认视图', 'nonempty', { field: 'isDefault', tone: 'success' }),
      stat('关联路由', 'nonempty', { field: 'route' }),
      stat('字段配置', 'nonempty', { field: 'columns' }),
    ],
  },
  {
    key: 'system-feedback', module: 'system', title: '反馈与工单', icon: '💬', accent: '#2563eb',
    subtitle: '跟踪用户反馈与问题工单；按「待处理 → 处理中 → 已解决」流转，支持指派处理人与查看处理记录。',
    category: 'doc',
    tips: ['处理完成需填写解决方案', '超时工单会自动升级提醒'],
    actions: [
      act('assign', '指派处理人', '👤', { variant: 'primary', from: ['待处理'], confirm: true, effect: '指派工单处理人' }),
      act('start', '开始处理', '▶️', { from: ['待处理'], to: '处理中', confirm: true, effect: '将工单置为处理中' }),
      act('resolve', '标记解决', '✅', { from: ['处理中'], to: '已解决', confirm: true, effect: '记录解决方案并关闭工单' }),
      act('reopen', '重新打开', '🔄', { from: ['已解决'], confirm: true, effect: '重新打开已解决工单' }),
    ],
    stats: [
      stat('工单总数', 'count', { tone: 'brand' }),
      stat('待处理', 'status', { values: ['待处理'], tone: 'warning' }),
      stat('处理中', 'status', { values: ['处理中'], tone: 'success' }),
      stat('已解决', 'status', { values: ['已解决'] }),
    ],
  },
];

/**
 * 每页专属功能区映射：让 30 个页面呈现完全不同的主体界面。
 * 同一功能类型下再用 config 细化（如看板分组字段、图表轴、预览纸张），
 * 保证「页面不一样、业务功能不一样」。
 */
const FEATURE_MAP: Record<string, PageProfile['feature']> = {
  /* 商城渠道：卡片墙 / 配置器 / 进度 / 看板 / 卡片墙 / 时间线 */
  'shop-stores': { type: 'cards' },
  'shop-channels': { type: 'config' },
  'shop-goods-maps': { type: 'progress' },
  'shop-orders': { type: 'kanban' },
  'shop-coupons': { type: 'cards' },
  'shop-promotions': { type: 'timeline' },
  /* 打印中心：预览 / 队列 / 预览（不同 config） */
  'print-doc-templates': { type: 'preview', config: { paper: 'A4', version: 'v2.3' } },
  'print-jobs': { type: 'queue' },
  'print-labels': { type: 'preview', config: { paper: '60×40mm', channel: 'CLIENT' } },
  /* AI 助手：看板 / 收件箱 / 图表 / 矩阵 */
  'ai-anomaly': { type: 'kanban' },
  'ai-cs': { type: 'inbox' },
  'ai-report': { type: 'chart' },
  'ai-subject-match': { type: 'matrix', config: { head: ['摘要关键词', '匹配科目', '状态'] } },
  /* 系统管理：时间线 / 时间线 / 树 / 卡片 / 树 / 矩阵 / 树 / 配置 / 配置 / 配置 / 卡片 / 队列 / 收件箱 / 开关 / 配置 / 配置 / 看板 */
  'system-audit-logs': { type: 'timeline' },
  'system-login-logs': { type: 'timeline' },
  'system-orgs': { type: 'tree' },
  'system-roles': { type: 'cards' },
  'system-permissions': { type: 'tree' },
  'system-data-scopes': { type: 'matrix', config: { head: ['权限项', '数据范围', '状态'] } },
  'system-dicts': { type: 'tree' },
  'system-sequences': { type: 'config' },
  'system-nos': { type: 'config' },
  'system-settings': { type: 'config' },
  'system-files': { type: 'cards' },
  'system-jobs': { type: 'queue' },
  'system-notifies': { type: 'inbox' },
  'system-events': { type: 'switchboard' },
  'system-alert-rules': { type: 'config' },
  'system-view-configs': { type: 'cards' },
  'system-feedback': { type: 'kanban' },
};

/** 全部页面画像 */
export const PAGE_PROFILES: Record<string, PageProfile> = [
  ...shopProfiles,
  ...printProfiles,
  ...aiProfiles,
  ...systemProfiles,
].reduce((map, p) => { map[p.key] = { ...p, feature: FEATURE_MAP[p.key] }; return map; }, {} as Record<string, PageProfile>);

/**
 * 取页面画像。
 * @param key 画像标识
 * @returns 画像，未注册时返回 undefined（BusinessPage 走通用兜底）
 */
export function getPageProfile(key?: string): PageProfile | undefined {
  return key ? PAGE_PROFILES[key] : undefined;
}
