/**
 * 生产计划与排产（APS）域实体 Schema 覆盖
 * ---------------------------------------------------------------------------
 * 目的：为「生产计划 / 排产任务 / 工作中心日历 / 产能负荷 / 齐套检查 / 异常预警」
 *       提供真实字段与演示种子，让通用页与 APS 工作台在无后端时也能完整演示。
 *
 * 约定：集合名与 /api/v1/aps/** 路径经 collectionOf 推导的结果一致
 *       （aps/plans -> apsPlans，aps/tasks -> apsTasks）。
 */
import { f, sel, opt, EntitySchema } from './types';

/** 计划状态：草稿 → 已确认 → 已排产 → 已下达 → 已完成，作废为终态 */
const PLAN_STATUS = opt(['DRAFT:草稿', 'CONFIRMED:已确认', 'SCHEDULED:已排产', 'ISSUED:已下达', 'COMPLETED:已完成', 'CANCELLED:已作废']);
/** 工序任务状态 */
const TASK_STATUS = opt(['PENDING:待排产', 'SCHEDULED:已排产', 'RUNNING:生产中', 'DONE:已完工']);
/** 预警级别与类型 */
const ALERT_LEVEL = opt(['HIGH:高', 'MED:中', 'LOW:低']);
const ALERT_TYPE = opt(['CAPACITY:产能超载', 'DUE:交期风险', 'MATERIAL:物料短缺']);
/** 工作中心清单（同时供种子引用，保证计划/任务/负荷的中心名称一致） */
const CENTERS = ['数控加工中心', '焊接工作站', '总装线'];

/**
 * 生成未来 14 天的工作日历种子：周末停产、其余按白班 8 小时。
 * 固定基准日保证演示数据在不同日期打开时仍然连贯（与计划种子同区间）。
 */
function calendarSeed(): any[] {
  const rows: any[] = [];
  const base = new Date('2026-11-20T00:00:00');
  for (let i = 0; i < 14; i++) {
    const d = new Date(base.getTime() + i * 86400000);
    const date = d.toISOString().slice(0, 10);
    const weekend = [0, 6].includes(d.getDay());
    for (const center of CENTERS) {
      rows.push({
        id: rows.length + 1, calendarDate: date, workCenter: center,
        shiftType: weekend ? '停产' : '白班', availableHours: weekend ? 0 : 8,
        isWorking: weekend ? 0 : 1, reason: weekend ? '周末休息' : '正常班次',
      });
    }
  }
  return rows;
}

/** APS 域覆盖集合（合并进 entitySchemas.ts 的统一注册表） */
export const apsOverrides: Record<string, EntitySchema> = {
  apsPlans: {
    collection: 'apsPlans', label: '生产计划',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('planNo', '计划单号', 'text', 160),
      f('planName', '计划名称', 'text', 190),
      sel('sourceType', '需求来源', opt(['SALES:销售订单', 'FORECAST:销售预测', 'MANUAL:手工录入']), 130),
      f('sourceNo', '来源单号', 'text', 150),
      f('productName', '生产产品', 'text', 180),
      f('qty', '计划数量', 'number', 120),
      sel('priority', '优先级', opt(['P1:紧急', 'P2:较高', 'P3:普通']), 100),
      f('dueDate', '需求日期', 'date', 130),
      sel('workCenter', '主工作中心', opt(CENTERS.map((c) => `${c}:${c}`)), 160),
      sel('status', '状态', PLAN_STATUS, 110),
      f('planStart', '计划开工', 'date', 130),
      f('planEnd', '计划完工', 'date', 130),
      f('scheduleNo', '排产批次', 'text', 160, { form: false }),
      f('remark', '备注', 'textarea'),
    ],
    statusField: 'status', statusLabels: Object.fromEntries(PLAN_STATUS.map((o) => [o.value, o.label])),
    seed: [
      { id: 1, planNo: 'PP20261120-0001', planName: '智能温控器 11 月补单', sourceType: 'SALES', sourceNo: 'SO202611180001', productName: '智能温控器', qty: 480, priority: 'P1', dueDate: '2026-11-25', workCenter: '总装线', status: 'CONFIRMED', planStart: '2026-11-20', planEnd: '2026-11-25', remark: '客户要求 25 日前发货' },
      { id: 2, planNo: 'PP20261120-0002', planName: '无线网关常规补货', sourceType: 'FORECAST', sourceNo: 'FC20261102', productName: '无线网关', qty: 320, priority: 'P2', dueDate: '2026-11-27', workCenter: '焊接工作站', status: 'CONFIRMED', planStart: '2026-11-21', planEnd: '2026-11-27', remark: '安全库存补货' },
      { id: 3, planNo: 'PP20261121-0003', planName: '工控主板试产批次', sourceType: 'MANUAL', sourceNo: '', productName: '工控主板', qty: 160, priority: 'P3', dueDate: '2026-11-30', workCenter: '数控加工中心', status: 'DRAFT', planStart: '', planEnd: '', remark: '试产，等待工艺确认' },
      { id: 4, planNo: 'PP20261119-0004', planName: '温控器芯片替代验证', sourceType: 'SALES', sourceNo: 'SO202611170003', productName: '智能温控器', qty: 120, priority: 'P2', dueDate: '2026-11-24', workCenter: '总装线', status: 'SCHEDULED', planStart: '2026-11-20', planEnd: '2026-11-24', scheduleNo: 'APS20261119-0001', remark: '替代料验证后量产' },
    ],
  },

  apsRuns: {
    collection: 'apsRuns', label: '排产运算记录',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('runNo', '运算单号', 'text', 160),
      sel('strategy', '排产策略', opt(['FINITE:有限产能', 'INFINITE:无限产能']), 140),
      sel('direction', '排产方向', opt(['FORWARD:正排', 'BACKWARD:倒排']), 120),
      f('planCount', '计划数', 'number', 100),
      f('taskCount', '工序任务数', 'number', 120),
      f('lateCount', '交期风险数', 'number', 120),
      f('overloadCount', '超载中心数', 'number', 120),
      sel('status', '状态', opt(['RUNNING:运算中', 'DONE:完成', 'FAILED:失败']), 110),
      f('createdAt', '运算时间', 'datetime', 170, { form: false }),
    ],
    statusField: 'status', statusLabels: { RUNNING: '运算中', DONE: '完成', FAILED: '失败' },
    seed: [
      { id: 1, runNo: 'APS20261119-0001', strategy: 'FINITE', direction: 'FORWARD', planCount: 2, taskCount: 6, lateCount: 1, overloadCount: 1, status: 'DONE', createdAt: '2026-11-19 08:30:00' },
    ],
  },

  apsTasks: {
    collection: 'apsTasks', label: '工序排产任务',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('taskNo', '任务单号', 'text', 150),
      f('planNo', '生产计划', 'text', 160, { form: false }),
      f('productName', '产品', 'text', 170, { form: false }),
      f('seqNo', '工序号', 'number', 90),
      f('processName', '工序名称', 'text', 140),
      sel('workCenter', '工作中心', opt(CENTERS.map((c) => `${c}:${c}`)), 160),
      f('qty', '数量', 'number', 100),
      f('workHours', '工时(小时)', 'number', 120),
      f('planStart', '计划开始', 'datetime', 165),
      f('planEnd', '计划结束', 'datetime', 165),
      f('predecessor', '前序任务', 'text', 130),
      sel('priority', '优先级', opt(['P1:紧急', 'P2:较高', 'P3:普通']), 100),
      sel('status', '状态', TASK_STATUS, 110),
      sel('lateFlag', '交期风险', opt(['0:正常', '1:延期']), 100),
    ],
    statusField: 'status', statusLabels: Object.fromEntries(TASK_STATUS.map((o) => [o.value, o.label])),
    seed: [
      { id: 1, taskNo: 'APT0001', planNo: 'PP20261119-0004', productName: '智能温控器', seqNo: 10, processName: '下料', workCenter: '数控加工中心', qty: 120, workHours: 3.2, planStart: '2026-11-20 08:00', planEnd: '2026-11-20 11:12', predecessor: '', priority: 'P2', status: 'SCHEDULED', lateFlag: 0 },
      { id: 2, taskNo: 'APT0002', planNo: 'PP20261119-0004', productName: '智能温控器', seqNo: 20, processName: '焊接', workCenter: '焊接工作站', qty: 120, workHours: 4.0, planStart: '2026-11-20 13:00', planEnd: '2026-11-20 17:00', predecessor: 'APT0001', priority: 'P2', status: 'SCHEDULED', lateFlag: 0 },
      { id: 3, taskNo: 'APT0003', planNo: 'PP20261119-0004', productName: '智能温控器', seqNo: 30, processName: '总装调试', workCenter: '总装线', qty: 120, workHours: 6.0, planStart: '2026-11-21 08:00', planEnd: '2026-11-21 14:00', predecessor: 'APT0002', priority: 'P2', status: 'SCHEDULED', lateFlag: 0 },
    ],
  },

  apsResources: {
    collection: 'apsResources', label: '工作中心',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('code', '中心编码', 'text', 130),
      f('name', '工作中心名称', 'text', 180),
      f('workshop', '所属车间', 'text', 150),
      f('shiftHours', '班次工时', 'number', 120),
      f('efficiency', '设备效率(%)', 'number', 130),
      f('dailyCapacity', '日产能(件)', 'number', 130),
      f('manager', '负责人', 'text', 120),
      sel('status', '状态', opt(['ENABLED:可用', 'DISABLED:停用']), 110),
    ],
    statusField: 'status', statusLabels: { ENABLED: '可用', DISABLED: '停用' },
    seed: [
      { id: 1, code: 'WC-CNC', name: '数控加工中心', workshop: '机加工车间', shiftHours: 8, efficiency: 92, dailyCapacity: 120, manager: '王强', status: 'ENABLED' },
      { id: 2, code: 'WC-WELD', name: '焊接工作站', workshop: '焊接车间', shiftHours: 8, efficiency: 85, dailyCapacity: 80, manager: '刘敏', status: 'ENABLED' },
      { id: 3, code: 'WC-ASSY', name: '总装线', workshop: '装配车间', shiftHours: 8, efficiency: 88, dailyCapacity: 60, manager: '赵鹏', status: 'ENABLED' },
    ],
  },

  apsCalendars: {
    collection: 'apsCalendars', label: '工作日历',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('calendarDate', '日期', 'date', 130),
      sel('workCenter', '工作中心', opt(CENTERS.map((c) => `${c}:${c}`)), 160),
      sel('shiftType', '班次', opt(['白班:白班', '夜班:夜班', '停产:停产']), 100),
      f('availableHours', '可用工时', 'number', 120),
      sel('isWorking', '是否工作日', [{ label: '是', value: 1 }, { label: '否', value: 0 }], 120),
      f('reason', '原因', 'text', 170),
    ],
    seed: calendarSeed(),
  },

  apsLoads: {
    collection: 'apsLoads', label: '产能负荷',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('loadDate', '日期', 'date', 130),
      sel('workCenter', '工作中心', opt(CENTERS.map((c) => `${c}:${c}`)), 160),
      f('availableHours', '可用工时', 'number', 120),
      f('plannedHours', '计划工时', 'number', 120),
      f('loadRate', '负荷率(%)', 'number', 120),
      f('taskCount', '任务数', 'number', 100),
      sel('level', '负荷等级', opt(['IDLE:空闲', 'NORMAL:正常', 'WARN:偏高', 'OVER:超载']), 110),
      sel('bottleneck', '瓶颈', [{ label: '是', value: 1 }, { label: '否', value: 0 }], 90),
    ],
    statusField: 'level', statusLabels: { IDLE: '空闲', NORMAL: '正常', WARN: '偏高', OVER: '超载' },
    seed: [
      { id: 1, loadDate: '2026-11-20', workCenter: '总装线', availableHours: 8, plannedHours: 9.6, loadRate: 120, taskCount: 2, level: 'OVER', bottleneck: 1 },
      { id: 2, loadDate: '2026-11-20', workCenter: '数控加工中心', availableHours: 8, plannedHours: 6.4, loadRate: 80, taskCount: 2, level: 'NORMAL', bottleneck: 0 },
      { id: 3, loadDate: '2026-11-21', workCenter: '总装线', availableHours: 8, plannedHours: 6, loadRate: 75, taskCount: 1, level: 'NORMAL', bottleneck: 0 },
    ],
  },

  apsMaterials: {
    collection: 'apsMaterials', label: '齐套检查',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('checkNo', '检查单号', 'text', 160),
      f('planNo', '生产计划', 'text', 160),
      f('materialName', '物料名称', 'text', 180),
      f('requireQty', '需求数量', 'number', 120),
      f('availableQty', '可用库存', 'number', 120),
      f('shortQty', '缺口数量', 'number', 120),
      sel('status', '齐套状态', opt(['OK:齐套', 'SHORT:缺料']), 110),
      f('checkedAt', '检查时间', 'datetime', 170),
    ],
    statusField: 'status', statusLabels: { OK: '齐套', SHORT: '缺料' },
    seed: [
      { id: 1, checkNo: 'QK20261119-0001', planNo: 'PP20261119-0004', materialName: '温控芯片', requireQty: 120, availableQty: 150, shortQty: 0, status: 'OK', checkedAt: '2026-11-19 09:00:00' },
      { id: 2, checkNo: 'QK20261119-0001', planNo: 'PP20261119-0004', materialName: '铝合金外壳', requireQty: 120, availableQty: 86, shortQty: 34, status: 'SHORT', checkedAt: '2026-11-19 09:00:00' },
    ],
  },

  apsAlerts: {
    collection: 'apsAlerts', label: '排产异常预警',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      sel('alertType', '预警类型', ALERT_TYPE, 140),
      sel('level', '级别', ALERT_LEVEL, 90),
      f('title', '预警标题', 'text', 210),
      f('detail', '详细说明', 'textarea'),
      f('bizNo', '关联单号', 'text', 160),
      sel('status', '处理状态', opt(['OPEN:待处理', 'RESOLVED:已处理']), 120),
      f('createdAt', '产生时间', 'datetime', 170, { form: false }),
    ],
    statusField: 'status', statusLabels: { OPEN: '待处理', RESOLVED: '已处理' },
    seed: [
      { id: 1, alertType: 'CAPACITY', level: 'HIGH', title: '总装线 11-20 产能超载 20%', detail: '总装线当日可用 8 小时，已排 9.6 小时，建议分流至加班班次或调整优先级', bizNo: 'APS20261119-0001', status: 'OPEN', createdAt: '2026-11-19 08:31:00' },
      { id: 2, alertType: 'MATERIAL', level: 'MED', title: '温控器计划缺少铝合金外壳 34 件', detail: '齐套检查发现 PP20261119-0004 物料不足，建议加急采购或调整开工日期', bizNo: 'PP20261119-0004', status: 'OPEN', createdAt: '2026-11-19 09:00:00' },
    ],
  },
};
