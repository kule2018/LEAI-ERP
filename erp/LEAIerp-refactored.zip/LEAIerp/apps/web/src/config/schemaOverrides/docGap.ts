/**
 * 文档菜单补齐 Schema 覆盖
 * ---------------------------------------------------------------------------
 * 目的：把《ERP 完整产品与技术文档》第 3 章菜单树中原有实现缺失的三级功能点
 *       补齐为「可访问、有真实字段、有业务种子」的通用实体页，避免千篇一律的
 *       "演示数据 1/2/3"。集合名与 handleMock 的 collectionOf(路径) 结果一致。
 */
import { f, sel, opt, ON_OFF, EntitySchema } from './types';

const DOC = opt(['0:草稿', '1:待审核', '2:已确认', '3:部分完成', '4:已完成', '9:已作废']);
const YESNO = [{ label: '是', value: 1 }, { label: '否', value: 0 }];

/** 文档缺失菜单补齐集合 */
export const docGapOverrides: Record<string, EntitySchema> = {
  /* ------------------------------ 销售客户 ------------------------------ */
  salesReturnReasons: {
    collection: 'salesReturnReasons', label: '退货原因',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('name', '原因名称', 'text', 180), f('code', '原因编码', 'text', 120),
      sel('type', '适用类型', opt(['退货:销售退货', '换货:换货', '质量:质量问题'])), f('remark', '说明', 'textarea'), sel('status', '状态', ON_OFF)],
    statusField: 'status', statusLabels: { '1': '启用', '0': '停用' },
    seed: [
      { id: 1, name: '客户取消订单', code: 'RR01', type: '退货', remark: '客户下单后因故取消', status: 1 },
      { id: 2, name: '商品质量问题', code: 'RR02', type: '质量', remark: '到货破损或功能异常', status: 1 },
      { id: 3, name: '发错型号规格', code: 'RR03', type: '换货', remark: '出库拣货错误导致', status: 1 },
      { id: 4, name: '七天无理由退货', code: 'RR04', type: '退货', remark: '符合消保退换政策', status: 1 },
    ],
  },
  salesCommissions: {
    collection: 'salesCommissions', label: '佣金规则',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('name', '规则名称', 'text', 170), f('salesman', '业务员', 'text', 110),
      f('rate', '佣金比例(%)', 'number', 120), f('minAmount', '起算金额', 'money', 120), f('period', '结算周期', 'text', 110), sel('status', '状态', ON_OFF)],
    statusField: 'status', statusLabels: { '1': '启用', '0': '停用' },
    seed: [
      { id: 1, name: '销售额阶梯提成', salesman: '张销售', rate: 3, minAmount: 10000, period: '月度', status: 1 },
      { id: 2, name: '新客户开发奖励', salesman: '李业务', rate: 5, minAmount: 5000, period: '单次', status: 1 },
      { id: 3, name: '清库存专项提成', salesman: '全体', rate: 2, minAmount: 20000, period: '季度', status: 1 },
    ],
  },
  salesDetails: {
    collection: 'salesDetails', label: '销售明细',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('orderNo', '销售单号', 'text', 150), f('customerName', '客户', 'text', 160),
      f('productName', '产品', 'text', 160), f('qty', '数量', 'number', 90), f('unitPrice', '单价', 'money', 100), f('amount', '金额', 'money', 110), f('saleDate', '销售日期', 'date', 120)],
    seed: [
      { id: 1, orderNo: 'SO20261116-0001', customerName: '蓝天实业有限公司', productName: 'A4 复印纸', qty: 100, unitPrice: 26, amount: 2600, saleDate: '2026-11-16' },
      { id: 2, orderNo: 'SO20261116-0001', customerName: '蓝天实业有限公司', productName: '华为耳机', qty: 34, unitPrice: 300, amount: 10200, saleDate: '2026-11-16' },
      { id: 3, orderNo: 'SO20261117-0002', customerName: '深圳好再来商贸', productName: '无线鼠标', qty: 20, unitPrice: 160, amount: 3200, saleDate: '2026-11-17' },
      { id: 4, orderNo: 'SO20261117-0003', customerName: '广州云科技有限公司', productName: 'USB-C 扩展坞', qty: 6, unitPrice: 130, amount: 780, saleDate: '2026-11-17' },
    ],
  },
  salesSummaries: {
    collection: 'salesSummaries', label: '销售汇总',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('period', '统计期间', 'text', 120), f('customerName', '客户', 'text', 160),
      f('orderCount', '单据数', 'number', 100), f('totalAmount', '销售额', 'money', 130), f('paidAmount', '已收款', 'money', 130), f('profit', '毛利', 'money', 120)],
    seed: [
      { id: 1, period: '2026-11', customerName: '蓝天实业有限公司', orderCount: 5, totalAmount: 42800, paidAmount: 36000, profit: 8600 },
      { id: 2, period: '2026-11', customerName: '深圳好再来商贸', orderCount: 8, totalAmount: 31600, paidAmount: 28000, profit: 5200 },
      { id: 3, period: '2026-10', customerName: '广州云科技有限公司', orderCount: 3, totalAmount: 18900, paidAmount: 18900, profit: 4100 },
    ],
  },
  salesRankings: {
    collection: 'salesRankings', label: '畅销排行',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('rankNo', '排名', 'number', 80), f('productName', '产品名称', 'text', 180),
      f('skuCode', '产品编码', 'text', 120), f('saleQty', '销量', 'number', 100), f('saleAmount', '销售额', 'money', 130), f('trend', '环比趋势', 'text', 110)],
    seed: [
      { id: 1, rankNo: 1, productName: 'A4 复印纸', skuCode: 'P0001', saleQty: 1200, saleAmount: 31200, trend: '↑12%' },
      { id: 2, rankNo: 2, productName: '华为耳机', skuCode: 'P0007', saleQty: 340, saleAmount: 101660, trend: '↑8%' },
      { id: 3, rankNo: 3, productName: '无线鼠标', skuCode: 'P0004', saleQty: 520, saleAmount: 35880, trend: '↓3%' },
      { id: 4, rankNo: 4, productName: 'USB-C 扩展坞', skuCode: 'P0005', saleQty: 180, saleAmount: 23220, trend: '↑5%' },
    ],
  },

  /* ------------------------------ 采购供应 ------------------------------ */
  supplierContacts: {
    collection: 'supplierContacts', label: '供应商联系人',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('supplierName', '供应商', 'text', 170), f('name', '联系人', 'text', 120),
      f('position', '职务', 'text', 110), f('phone', '电话', 'text', 130), f('email', '邮箱', 'text', 160), sel('isPrimary', '主联系人', YESNO)],
    seed: [
      { id: 1, supplierName: '得力集团深圳分公司', name: '孙经理', position: '销售经理', phone: '13900139001', email: 'sun@deli.com', isPrimary: 1 },
      { id: 2, supplierName: '华强北电子批发', name: '吴老板', position: '负责人', phone: '13900139002', email: 'wu@hqb.com', isPrimary: 1 },
      { id: 3, supplierName: '晨光文具', name: '陈主管', position: '渠道主管', phone: '13900139003', email: 'chen@mg.com', isPrimary: 0 },
    ],
  },
  purchaseImports: {
    collection: 'purchaseImports', label: '采购批量导入',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('batchNo', '导入批次', 'text', 150), f('fileName', '文件名', 'text', 180),
      f('totalRows', '总行数', 'number', 100), f('successRows', '成功行数', 'number', 110), f('failRows', '失败行数', 'number', 110),
      sel('status', '状态', opt(['完成:完成', '处理中:处理中', '失败:失败']))],
    statusField: 'status', statusLabels: { 完成: '完成', 处理中: '处理中', 失败: '失败' },
    seed: [
      { id: 1, batchNo: 'IMP20261117-001', fileName: '11月采购计划.xlsx', totalRows: 50, successRows: 48, failRows: 2, status: '完成' },
      { id: 2, batchNo: 'IMP20261116-002', fileName: '办公用品补货.csv', totalRows: 20, successRows: 20, failRows: 0, status: '完成' },
    ],
  },
  purchaseFines: {
    collection: 'purchaseFines', label: '供应商罚款',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('fineNo', '罚款单号', 'text', 150), f('supplierName', '供应商', 'text', 170),
      f('reason', '罚款原因', 'text', 180), f('amount', '罚款金额', 'money', 120), f('fineDate', '罚款日期', 'date', 120), sel('status', '状态', DOC)],
    statusField: 'status', statusLabels: { '0': '草稿', '1': '待审核', '2': '已确认', '4': '已完成' },
    seed: [
      { id: 1, fineNo: 'PF20261110-001', supplierName: '华强北电子批发', reason: '到货延期 3 天', amount: 500, fineDate: '2026-11-10', status: 2 },
      { id: 2, fineNo: 'PF20261105-002', supplierName: '得力集团深圳分公司', reason: '产品质量不合格', amount: 1200, fineDate: '2026-11-05', status: 4 },
    ],
  },
  purchasePriceHistory: {
    collection: 'purchasePriceHistory', label: '历史采购价',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('productName', '产品', 'text', 170), f('supplierName', '供应商', 'text', 170),
      f('price', '采购价', 'money', 110), f('qty', '采购数量', 'number', 110), f('purchaseDate', '采购日期', 'date', 120)],
    seed: [
      { id: 1, productName: 'A4 复印纸', supplierName: '得力集团深圳分公司', price: 18, qty: 200, purchaseDate: '2026-11-15' },
      { id: 2, productName: 'A4 复印纸', supplierName: '晨光文具', price: 19.5, qty: 100, purchaseDate: '2026-10-20' },
      { id: 3, productName: '无线鼠标', supplierName: '华强北电子批发', price: 42, qty: 50, purchaseDate: '2026-11-08' },
    ],
  },
  purchaseDetails: {
    collection: 'purchaseDetails', label: '采购明细',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('orderNo', '采购单号', 'text', 150), f('supplierName', '供应商', 'text', 170),
      f('productName', '产品', 'text', 160), f('qty', '数量', 'number', 90), f('unitPrice', '单价', 'money', 100), f('amount', '金额', 'money', 110), f('receivedQty', '已收数量', 'number', 110)],
    seed: [
      { id: 1, orderNo: 'PO20261115-0001', supplierName: '得力集团深圳分公司', productName: 'A4 复印纸', qty: 200, unitPrice: 28, amount: 5600, receivedQty: 200 },
      { id: 2, orderNo: 'PO20261117-0002', supplierName: '华强北电子批发', productName: '无线鼠标', qty: 100, unitPrice: 45, amount: 4500, receivedQty: 0 },
    ],
  },
  purchaseSummaries: {
    collection: 'purchaseSummaries', label: '采购汇总',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('period', '统计期间', 'text', 120), f('supplierName', '供应商', 'text', 170),
      f('orderCount', '单据数', 'number', 100), f('totalAmount', '采购额', 'money', 130), f('receivedAmount', '已入库', 'money', 130)],
    seed: [
      { id: 1, period: '2026-11', supplierName: '得力集团深圳分公司', orderCount: 12, totalAmount: 86500, receivedAmount: 78200 },
      { id: 2, period: '2026-11', supplierName: '华强北电子批发', orderCount: 8, totalAmount: 52300, receivedAmount: 45000 },
    ],
  },
  supplierRankings: {
    collection: 'supplierRankings', label: '供货排行',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('rankNo', '排名', 'number', 80), f('supplierName', '供应商', 'text', 180),
      f('supplyAmount', '供货金额', 'money', 130), f('orderCount', '订单数', 'number', 100), f('onTimeRate', '及时率(%)', 'number', 120)],
    seed: [
      { id: 1, rankNo: 1, supplierName: '得力集团深圳分公司', supplyAmount: 86500, orderCount: 12, onTimeRate: 96 },
      { id: 2, rankNo: 2, supplierName: '华强北电子批发', supplyAmount: 52300, orderCount: 8, onTimeRate: 88 },
      { id: 3, rankNo: 3, supplierName: '晨光文具', supplyAmount: 21400, orderCount: 5, onTimeRate: 100 },
    ],
  },

  /* ------------------------------ 库存仓储 ------------------------------ */
  productCreates: {
    collection: 'productCreates', label: '创建产品',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('name', '产品名称', 'text', 180), f('code', '产品编码', 'text', 120),
      f('categoryName', '分类', 'text', 120), f('unitName', '单位', 'text', 90), f('cost', '成本', 'money', 100), f('price', '售价', 'money', 100), sel('status', '状态', DOC)],
    statusField: 'status', seed: [
      { id: 1, name: 'A4 复印纸', code: 'P0001', categoryName: '办公用品', unitName: '包', cost: 18, price: 26, status: '已确认' },
      { id: 2, name: '无线鼠标', code: 'P0004', categoryName: '数码电子', unitName: '个', cost: 45, price: 69, status: '已确认' },
    ],
  },
  productImports: {
    collection: 'productImports', label: '导入产品',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('batchNo', '导入批次', 'text', 150), f('fileName', '文件名', 'text', 180),
      f('totalRows', '总行数', 'number', 100), f('successRows', '成功', 'number', 90), f('failRows', '失败', 'number', 90), sel('status', '状态', opt(['完成:完成', '处理中:处理中']))],
    statusField: 'status', seed: [
      { id: 1, batchNo: 'PIM20261117-001', fileName: '产品目录2026.xlsx', totalRows: 120, successRows: 118, failRows: 2, status: '完成' },
      { id: 2, batchNo: 'PIM20261110-002', fileName: '新增SKU.csv', totalRows: 30, successRows: 30, failRows: 0, status: '完成' },
    ],
  },
  productImportUpdates: {
    collection: 'productImportUpdates', label: '导入更新',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('batchNo', '批次', 'text', 150), f('fileName', '文件名', 'text', 180),
      f('updatedRows', '更新行数', 'number', 110), f('skipRows', '跳过行数', 'number', 110), f('updateTime', '更新时间', 'datetime', 150)],
    seed: [
      { id: 1, batchNo: 'PUP20261116-001', fileName: '价格批量更新.xlsx', updatedRows: 85, skipRows: 3, updateTime: '2026-11-16 14:30:00' },
      { id: 2, batchNo: 'PUP20261112-002', fileName: '库存成本调整.csv', updatedRows: 42, skipRows: 0, updateTime: '2026-11-12 10:15:00' },
    ],
  },
  productBarcodes: {
    collection: 'productBarcodes', label: '打印条形码',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('productName', '产品', 'text', 180), f('productCode', '编码', 'text', 120),
      f('barcode', '条码', 'text', 160), f('spec', '规格', 'text', 110), f('copies', '打印份数', 'number', 100)],
    seed: [
      { id: 1, productName: 'A4 复印纸', productCode: 'P0001', barcode: '6901234567000', spec: '500张/包', copies: 2 },
      { id: 2, productName: '无线鼠标', productCode: 'P0004', barcode: '6901234567003', spec: '无线蓝牙', copies: 1 },
      { id: 3, productName: 'USB-C 扩展坞', productCode: 'P0005', barcode: '6901234567004', spec: 'Type-C 七合一', copies: 3 },
    ],
  },
  batchTraces: {
    collection: 'batchTraces', label: '批次追踪',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('batchNo', '批号', 'text', 140), f('productName', '产品', 'text', 170),
      f('produceDate', '生产日期', 'date', 120), f('expireDate', '有效期至', 'date', 120), f('qty', '批次数量', 'number', 110), sel('status', '状态', opt(['在库:在库', '已售:已售', '锁定:锁定']))],
    statusField: 'status', seed: [
      { id: 1, batchNo: 'B20261101', productName: 'A4 复印纸', produceDate: '2026-11-01', expireDate: '2027-11-01', qty: 500, status: '在库' },
      { id: 2, batchNo: 'B20261015', productName: '中性笔 0.5mm', produceDate: '2026-10-15', expireDate: '2028-10-15', qty: 1000, status: '在库' },
    ],
  },
  materialReturns: {
    collection: 'materialReturns', label: '退料入库',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('returnNo', '退料单号', 'text', 150), f('workOrder', '工单', 'text', 130),
      f('productName', '物料', 'text', 160), f('qty', '退料数量', 'number', 110), f('reason', '退料原因', 'text', 160), f('returnDate', '退料日期', 'date', 120), sel('status', '状态', DOC)],
    statusField: 'status', seed: [
      { id: 1, returnNo: 'MR20261116-001', workOrder: 'WO20261110-003', productName: '螺丝 M8', qty: 20, reason: '工单完工剩余', returnDate: '2026-11-16', status: '已确认' },
      { id: 2, returnNo: 'MR20261115-002', workOrder: 'WO20261108-001', productName: '包装纸箱', qty: 15, reason: '质量检验不合格退回', returnDate: '2026-11-15', status: '已完成' },
    ],
  },
  otherInOuts: {
    collection: 'otherInOuts', label: '其他出入库',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('voucherNo', '单据号', 'text', 150), sel('type', '类型', opt(['其他入库:其他入库', '其他出库:其他出库'])),
      f('productName', '产品', 'text', 170), f('warehouseName', '仓库', 'text', 130), f('qty', '数量', 'number', 100), f('reason', '原因', 'text', 160), f('bizDate', '日期', 'date', 120)],
    seed: [
      { id: 1, voucherNo: 'OIN20261115-001', type: '其他入库', productName: '办公文件夹', warehouseName: '主仓库', qty: 80, reason: '盘盈入库', bizDate: '2026-11-15' },
      { id: 2, voucherNo: 'OOUT20261116-002', type: '其他出库', productName: '中性笔 0.5mm', warehouseName: '主仓库', qty: 10, reason: '样品领用', bizDate: '2026-11-16' },
    ],
  },
  negativeStocks: {
    collection: 'negativeStocks', label: '负库存清单',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('productName', '产品', 'text', 180), f('productCode', '编码', 'text', 120),
      f('warehouseName', '仓库', 'text', 130), f('qtyOnHand', '实物量', 'number', 100), f('qtyOccupied', '锁定量', 'number', 100), f('available', '可用量', 'number', 100, { width: 100 })],
    seed: [
      { id: 1, productName: 'USB-C 扩展坞', productCode: 'P0005', warehouseName: '主仓库', qtyOnHand: -2, qtyOccupied: 0, available: -2 },
      { id: 2, productName: '快递纸箱', productCode: 'P0006', warehouseName: '深圳分仓', qtyOnHand: -5, qtyOccupied: 3, available: -8 },
    ],
  },

  /* ------------------------------ 生产制造 ------------------------------ */
  workOrderProgress: {
    collection: 'workOrderProgress', label: '工单进度',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('orderNo', '工单号', 'text', 150), f('productName', '产品', 'text', 170),
      f('planQty', '计划数量', 'number', 110), f('producedQty', '已产数量', 'number', 110), f('progress', '进度(%)', 'number', 110), sel('status', '状态', opt(['计划:计划', '生产中:生产中', '完工:完工']))],
    statusField: 'status', seed: [
      { id: 1, orderNo: 'WO20261110-003', productName: '办公文件夹', planQty: 500, producedQty: 350, progress: 70, status: '生产中' },
      { id: 2, orderNo: 'WO20261108-001', productName: '无线鼠标', planQty: 300, producedQty: 300, progress: 100, status: '完工' },
      { id: 3, orderNo: 'WO20261118-005', productName: 'USB-C 扩展坞', planQty: 200, producedQty: 0, progress: 0, status: '计划' },
    ],
  },
  lossAnalysis: {
    collection: 'lossAnalysis', label: '损耗分析',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('orderNo', '工单号', 'text', 150), f('materialName', '物料', 'text', 160),
      f('inputQty', '投入量', 'number', 100), f('stdQty', '标准用量', 'number', 110), f('actualQty', '实际用量', 'number', 110), f('lossRate', '损耗率(%)', 'number', 110)],
    seed: [
      { id: 1, orderNo: 'WO20261110-003', materialName: '塑料粒子', inputQty: 500, stdQty: 480, actualQty: 495, lossRate: 3.1 },
      { id: 2, orderNo: 'WO20261108-001', materialName: '电子芯片', inputQty: 300, stdQty: 300, actualQty: 306, lossRate: 2.0 },
    ],
  },

  /* ------------------------------ 财务结算 ------------------------------ */
  financeDashboards: {
    collection: 'financeDashboards', label: '财务仪表盘',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('period', '期间', 'text', 110), f('income', '收入', 'money', 130), f('expense', '支出', 'money', 130),
      f('profit', '利润', 'money', 130), f('receivable', '应收', 'money', 130), f('payable', '应付', 'money', 130), f('cash', '资金余额', 'money', 130)],
    seed: [
      { id: 1, period: '2026-11', income: 167800, expense: 98500, profit: 69300, receivable: 21600, payable: 12400, cash: 358600 },
      { id: 2, period: '2026-10', income: 145200, expense: 88300, profit: 56900, receivable: 18200, payable: 15600, cash: 289300 },
    ],
  },
  profitLosses: {
    collection: 'profitLosses', label: '损益表',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('period', '期间', 'text', 110), f('item', '项目', 'text', 180), f('amount', '金额', 'money', 140), f('type', '类别', 'text', 110)],
    seed: [
      { id: 1, period: '2026-11', item: '一、营业收入', amount: 167800, type: '收入' },
      { id: 2, period: '2026-11', item: '减：营业成本', amount: 98500, type: '成本' },
      { id: 3, period: '2026-11', item: '减：销售费用', amount: 12000, type: '费用' },
      { id: 4, period: '2026-11', item: '三、利润总额', amount: 57300, type: '利润' },
    ],
  },
  balanceSheets: {
    collection: 'balanceSheets', label: '资产负债表',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('period', '期间', 'text', 110), f('item', '项目', 'text', 190), f('endBalance', '期末余额', 'money', 140), f('beginBalance', '年初余额', 'money', 140), f('side', '类别', 'text', 100)],
    seed: [
      { id: 1, period: '2026-11', item: '货币资金', endBalance: 358600, beginBalance: 210000, side: '资产' },
      { id: 2, period: '2026-11', item: '应收账款', endBalance: 21600, beginBalance: 18000, side: '资产' },
      { id: 3, period: '2026-11', item: '应付账款', endBalance: 12400, beginBalance: 9000, side: '负债' },
      { id: 4, period: '2026-11', item: '实收资本', endBalance: 300000, beginBalance: 300000, side: '权益' },
    ],
  },
  taxSummaries: {
    collection: 'taxSummaries', label: '税务汇总',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('period', '期间', 'text', 110), f('taxType', '税种', 'text', 130), f('taxable', '计税依据', 'money', 140), f('rate', '税率(%)', 'number', 100), f('taxAmount', '税额', 'money', 130)],
    seed: [
      { id: 1, period: '2026-11', taxType: '增值税', taxable: 167800, rate: 13, taxAmount: 21814 },
      { id: 2, period: '2026-11', taxType: '企业所得税', taxable: 57300, rate: 25, taxAmount: 14325 },
      { id: 3, period: '2026-11', taxType: '附加税', taxable: 21814, rate: 12, taxAmount: 2617.68 },
    ],
  },
  expensesNew: {
    collection: 'expensesNew', label: '新建支出',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('expenseNo', '支出单号', 'text', 150), f('categoryName', '费用类别', 'text', 130),
      f('amount', '金额', 'money', 120), f('accountName', '支出账户', 'text', 130), f('payee', '收款方', 'text', 140), f('bizDate', '日期', 'date', 120), sel('status', '状态', DOC)],
    statusField: 'status', seed: [
      { id: 1, expenseNo: 'EX20261116-001', categoryName: '办公费', amount: 1200, accountName: '银行存款', payee: '得力集团', bizDate: '2026-11-16', status: '已确认' },
      { id: 2, expenseNo: 'EX20261115-002', categoryName: '差旅费', amount: 860, accountName: '现金', payee: '张销售', bizDate: '2026-11-15', status: '已完成' },
    ],
  },
  badDebts: {
    collection: 'badDebts', label: '坏账',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('debtNo', '坏账单号', 'text', 150), f('customerName', '客户', 'text', 170),
      f('amount', '坏账金额', 'money', 130), f('reason', '坏账原因', 'text', 180), f('bizDate', '确认日期', 'date', 120), sel('status', '状态', DOC)],
    statusField: 'status', seed: [
      { id: 1, debtNo: 'BD20261101-001', customerName: '佛山顺德贸易行', amount: 3500, reason: '客户经营异常长期催收无果', bizDate: '2026-11-01', status: '已确认' },
    ],
  },
  collectionPlans: {
    collection: 'collectionPlans', label: '回款计划',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('planNo', '计划单号', 'text', 150), f('customerName', '客户', 'text', 170),
      f('planAmount', '计划回款', 'money', 130), f('receivedAmount', '已回款', 'money', 130), f('dueDate', '计划日期', 'date', 120), sel('status', '状态', opt(['待回款:待回款', '部分回款:部分回款', '已完成:已完成']))],
    statusField: 'status', seed: [
      { id: 1, planNo: 'CP20261120-001', customerName: '蓝天实业有限公司', planAmount: 4800, receivedAmount: 0, dueDate: '2026-11-20', status: '待回款' },
      { id: 2, planNo: 'CP20261125-002', customerName: '深圳好再来商贸', planAmount: 3200, receivedAmount: 1200, dueDate: '2026-11-25', status: '部分回款' },
    ],
  },
  assetDisposals: {
    collection: 'assetDisposals', label: '资产处置',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('disposalNo', '处置单号', 'text', 150), f('assetName', '资产名称', 'text', 170),
      f('originalValue', '原值', 'money', 120), f('disposalValue', '处置收入', 'money', 130), f('method', '处置方式', 'text', 120), f('bizDate', '处置日期', 'date', 120)],
    seed: [
      { id: 1, disposalNo: 'AD20261110-001', assetName: '旧办公电脑', originalValue: 8000, disposalValue: 1200, method: '出售', bizDate: '2026-11-10' },
    ],
  },
  assetChecks: {
    collection: 'assetChecks', label: '资产盘点',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('checkNo', '盘点单号', 'text', 150), f('assetName', '资产名称', 'text', 170),
      f('bookQty', '账面数量', 'number', 110), f('realQty', '实盘数量', 'number', 110), f('diffQty', '差异', 'number', 90), f('checkDate', '盘点日期', 'date', 120)],
    seed: [
      { id: 1, checkNo: 'AC20261115-001', assetName: '办公桌椅', bookQty: 50, realQty: 48, diffQty: -2, checkDate: '2026-11-15' },
      { id: 2, checkNo: 'AC20261115-002', assetName: '打印机', bookQty: 8, realQty: 8, diffQty: 0, checkDate: '2026-11-15' },
    ],
  },
  taxCodes: {
    collection: 'taxCodes', label: '税码',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('code', '税码', 'text', 110), f('name', '名称', 'text', 160), f('rate', '税率(%)', 'number', 110), f('description', '说明', 'textarea'), sel('status', '状态', ON_OFF)],
    statusField: 'status', seed: [
      { id: 1, code: 'VAT13', name: '增值税专用发票 13%', rate: 13, description: '一般纳税人销售货物', status: 1 },
      { id: 2, code: 'VAT9', name: '增值税专用发票 9%', rate: 9, description: '交通运输、建筑服务', status: 1 },
      { id: 3, code: 'VAT6', name: '增值税普通发票 6%', rate: 6, description: '现代服务业', status: 1 },
    ],
  },
  taxRates: {
    collection: 'taxRates', label: '税率',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('name', '税率名称', 'text', 160), f('rate', '税率(%)', 'number', 110), f('type', '税种', 'text', 120), f('effectiveDate', '生效日期', 'date', 120)],
    seed: [
      { id: 1, name: '增值税-销售货物', rate: 13, type: '增值税', effectiveDate: '2019-04-01' },
      { id: 2, name: '企业所得税-小微企业', rate: 5, type: '企业所得税', effectiveDate: '2023-01-01' },
    ],
  },
  taxDeclarations: {
    collection: 'taxDeclarations', label: '纳税申报',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('period', '申报期间', 'text', 110), f('taxType', '税种', 'text', 130),
      f('taxAmount', '应纳税额', 'money', 130), f('declareDate', '申报日期', 'date', 120), sel('status', '状态', opt(['未申报:未申报', '已申报:已申报', '已缴纳:已缴纳']))],
    statusField: 'status', seed: [
      { id: 1, period: '2026-10', taxType: '增值税', taxAmount: 18900, declareDate: '2026-11-15', status: '已缴纳' },
      { id: 2, period: '2026-11', taxType: '增值税', taxAmount: 21814, declareDate: '', status: '未申报' },
    ],
  },

  /* ------------------------------ 协同办公 ------------------------------ */
  approvalTemplates: {
    collection: 'approvalTemplates', label: '审批模板',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('name', '模板名称', 'text', 180), f('bizType', '适用单据', 'text', 140),
      f('nodes', '审批节点', 'text', 200), f('remark', '说明', 'textarea'), sel('status', '状态', ON_OFF)],
    statusField: 'status', seed: [
      { id: 1, name: '销售单审批', bizType: '销售订单', nodes: '销售主管→销售总监(>1万)', remark: '金额大于1万走总监', status: 1 },
      { id: 2, name: '费用报销审批', bizType: '费用单', nodes: '部门经理→财务→总经理', remark: '三级审批', status: 1 },
      { id: 3, name: '请假审批', bizType: '请假单', nodes: '直属上级→人事', remark: '3天以上需人事审批', status: 1 },
    ],
  },
  approvalCc: {
    collection: 'approvalCc', label: '抄送设置',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('bizType', '单据类型', 'text', 140), f('receiver', '抄送人', 'text', 130),
      f('cond', '抄送条件', 'text', 180), sel('status', '状态', ON_OFF)],
    statusField: 'status', seed: [
      { id: 1, bizType: '销售订单', receiver: '财务经理', cond: '金额 > 5万', status: 1 },
      { id: 2, bizType: '采购订单', receiver: '仓库主管', cond: '全部单据', status: 1 },
    ],
  },
  projectDashboards: {
    collection: 'projectDashboards', label: '项目仪表盘',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('projectName', '项目', 'text', 180), f('taskTotal', '任务总数', 'number', 110),
      f('taskDone', '已完成', 'number', 100), f('progress', '进度(%)', 'number', 110), f('manager', '负责人', 'text', 120), sel('status', '状态', opt(['进行中:进行中', '已完成:已完成', '延期:延期']))],
    statusField: 'status', seed: [
      { id: 1, projectName: 'ERP 系统上线', taskTotal: 48, taskDone: 32, progress: 67, manager: '项目经理', status: '进行中' },
      { id: 2, projectName: '仓库搬迁', taskTotal: 20, taskDone: 20, progress: 100, manager: '王仓管', status: '已完成' },
      { id: 3, projectName: '官网改版', taskTotal: 15, taskDone: 6, progress: 40, manager: '李设计', status: '延期' },
    ],
  },
  timesheets: {
    collection: 'timesheets', label: '时间表',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('employee', '员工', 'text', 120), f('projectName', '项目', 'text', 170),
      f('taskName', '任务', 'text', 170), f('workDate', '工作日期', 'date', 120), f('hours', '工时', 'number', 90), f('content', '工作内容', 'textarea')],
    seed: [
      { id: 1, employee: '张开发', projectName: 'ERP 系统上线', taskName: '库存模块开发', workDate: '2026-11-16', hours: 8, content: '完成库存流水与加权成本逻辑' },
      { id: 2, employee: '李测试', projectName: 'ERP 系统上线', taskName: '销售模块测试', workDate: '2026-11-16', hours: 6, content: '回归销售出库与凭证联动' },
    ],
  },

  /* ------------------------------ 人事行政 ------------------------------ */
  hirings: {
    collection: 'hirings', label: '录用',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('name', '候选人', 'text', 130), f('position', '录用岗位', 'text', 150),
      f('deptName', '部门', 'text', 120), f('entryDate', '入职日期', 'date', 120), f('salary', '薪资', 'money', 120), sel('status', '状态', opt(['待入职:待入职', '已入职:已入职']))],
    statusField: 'status', seed: [
      { id: 1, name: '陈明', position: '销售代表', deptName: '销售部', entryDate: '2026-11-20', salary: 8000, status: '待入职' },
      { id: 2, name: '林晓', position: '会计', deptName: '财务部', entryDate: '2026-11-01', salary: 9500, status: '已入职' },
    ],
  },
  assetLedgers: {
    collection: 'assetLedgers', label: '资产台账',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('assetNo', '资产编号', 'text', 140), f('name', '资产名称', 'text', 180),
      f('category', '类别', 'text', 120), f('value', '价值', 'money', 120), f('custodian', '保管人', 'text', 120), f('location', '存放位置', 'text', 140)],
    seed: [
      { id: 1, assetNo: 'FA001', name: '办公电脑', category: '电子设备', value: 6500, custodian: '张销售', location: '销售部' },
      { id: 2, assetNo: 'FA002', name: '打印机', category: '办公设备', value: 3200, custodian: '王仓管', location: '仓库' },
      { id: 3, assetNo: 'FA003', name: '办公桌椅', category: '家具', value: 1800, custodian: '李行政', location: '前台' },
    ],
  },
  assetReturns: {
    collection: 'assetReturns', label: '资产归还',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('returnNo', '归还单号', 'text', 150), f('assetName', '资产', 'text', 170),
      f('custodian', '归还人', 'text', 120), f('returnDate', '归还日期', 'date', 120), f('assetCondition', '资产状况', 'text', 140), sel('status', '状态', DOC)],
    statusField: 'status', seed: [
      { id: 1, returnNo: 'AR20261115-001', assetName: '投影仪', custodian: '李设计', returnDate: '2026-11-15', assetCondition: '完好', status: '已完成' },
    ],
  },
  assetScraps: {
    collection: 'assetScraps', label: '资产报废',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('scrapNo', '报废单号', 'text', 150), f('assetName', '资产', 'text', 170),
      f('originalValue', '原值', 'money', 120), f('reason', '报废原因', 'text', 180), f('scrapDate', '报废日期', 'date', 120), sel('status', '状态', DOC)],
    statusField: 'status', seed: [
      { id: 1, scrapNo: 'AS20261108-001', assetName: '旧打印机', originalValue: 2800, reason: '达到使用年限无法维修', scrapDate: '2026-11-08', status: '已完成' },
    ],
  },
  drivers: {
    collection: 'drivers', label: '司机',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('name', '姓名', 'text', 130), f('phone', '电话', 'text', 130),
      f('licenseNo', '驾驶证号', 'text', 170), f('licenseType', '准驾车型', 'text', 120), f('expireDate', '有效期至', 'date', 120), sel('status', '状态', ON_OFF)],
    statusField: 'status', seed: [
      { id: 1, name: '赵师傅', phone: '13700137001', licenseNo: '4403011990xxxx1234', licenseType: 'B2', expireDate: '2028-05-20', status: 1 },
      { id: 2, name: '孙师傅', phone: '13700137002', licenseNo: '4403011988xxxx5678', licenseType: 'C1', expireDate: '2027-09-10', status: 1 },
    ],
  },
  vehicleUses: {
    collection: 'vehicleUses', label: '用车申请',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('useNo', '申请单号', 'text', 150), f('applicant', '申请人', 'text', 120),
      f('plateNo', '车牌号', 'text', 130), f('destination', '目的地', 'text', 160), f('useDate', '用车日期', 'date', 120), sel('status', '状态', DOC)],
    statusField: 'status', seed: [
      { id: 1, useNo: 'VU20261118-001', applicant: '张销售', plateNo: '粤B·12345', destination: '东莞客户拜访', useDate: '2026-11-18', status: '待审核' },
      { id: 2, useNo: 'VU20261116-002', applicant: '王仓管', plateNo: '粤B·67890', destination: '深圳分仓调货', useDate: '2026-11-16', status: '已完成' },
    ],
  },
  fuelRecords: {
    collection: 'fuelRecords', label: '加油记录',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('plateNo', '车牌号', 'text', 130), f('fuelDate', '加油日期', 'date', 120),
      f('qty', '加油量(升)', 'number', 120), f('amount', '金额', 'money', 120), f('station', '加油站', 'text', 160), f('driver', '司机', 'text', 120)],
    seed: [
      { id: 1, plateNo: '粤B·12345', fuelDate: '2026-11-15', qty: 45, amount: 340, station: '中石化南山站', driver: '赵师傅' },
      { id: 2, plateNo: '粤B·67890', fuelDate: '2026-11-14', qty: 38, amount: 288, station: '中石油福田站', driver: '孙师傅' },
    ],
  },
  vehicleMaintains: {
    collection: 'vehicleMaintains', label: '维保记录',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('plateNo', '车牌号', 'text', 130), f('maintainDate', '维保日期', 'date', 120),
      f('type', '维保类型', 'text', 130), f('amount', '费用', 'money', 110), f('vendor', '服务商', 'text', 160), f('nextDate', '下次维保', 'date', 120)],
    seed: [
      { id: 1, plateNo: '粤B·12345', maintainDate: '2026-11-01', type: '常规保养', amount: 580, vendor: '丰田4S店', nextDate: '2027-05-01' },
    ],
  },

  /* ------------------------------ 商城渠道 ------------------------------ */
  goodsPublications: {
    collection: 'goodsPublications', label: '商品发布',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('productName', '产品', 'text', 180), f('platform', '平台', 'text', 130),
      f('title', '商品标题', 'text', 200), f('price', '售价', 'money', 110), f('stock', '库存', 'number', 100), sel('status', '状态', opt(['已上架:已上架', '待上架:待上架', '已下架:已下架']))],
    statusField: 'status', seed: [
      { id: 1, productName: 'A4 复印纸', platform: '淘宝', title: '得力A4复印纸 500张/包 包邮', price: 29, stock: 120, status: '已上架' },
      { id: 2, productName: '华为耳机', platform: '京东', title: '华为无线蓝牙耳机 正品保障', price: 329, stock: 20, status: '已上架' },
      { id: 3, productName: 'USB-C 扩展坞', platform: '抖音', title: '七合一Type-C扩展坞', price: 139, stock: 3, status: '待上架' },
    ],
  },
  stockSyncs: {
    collection: 'stockSyncs', label: '价格库存同步',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('platform', '平台', 'text', 130), f('productName', '产品', 'text', 170),
      f('syncType', '同步类型', 'text', 130), f('result', '同步结果', 'text', 130), f('syncTime', '同步时间', 'datetime', 160)],
    seed: [
      { id: 1, platform: '淘宝', productName: 'A4 复印纸', syncType: '库存同步', result: '成功', syncTime: '2026-11-18 09:00:00' },
      { id: 2, platform: '京东', productName: '华为耳机', syncType: '价格同步', result: '成功', syncTime: '2026-11-18 09:05:00' },
      { id: 3, platform: '抖音', productName: 'USB-C 扩展坞', syncType: '库存同步', result: '失败-库存不足', syncTime: '2026-11-18 09:10:00' },
    ],
  },
  orderSyncs: {
    collection: 'orderSyncs', label: '订单同步',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('platformOrderNo', '平台订单号', 'text', 170), f('platform', '平台', 'text', 120),
      f('buyer', '买家', 'text', 140), f('amount', '金额', 'money', 110), f('syncTime', '同步时间', 'datetime', 160), sel('status', '状态', opt(['待同步:待同步', '已同步:已同步', '失败:失败']))],
    statusField: 'status', seed: [
      { id: 1, platformOrderNo: 'TB20261118001', platform: '淘宝', buyer: '淘宝买家A', amount: 58, syncTime: '2026-11-18 10:00:00', status: '已同步' },
      { id: 2, platformOrderNo: 'JD20261118002', platform: '京东', buyer: '京东买家B', amount: 329, syncTime: '2026-11-18 10:15:00', status: '待同步' },
    ],
  },
  shipCallbacks: {
    collection: 'shipCallbacks', label: '发货回传',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('platformOrderNo', '平台订单号', 'text', 170), f('platform', '平台', 'text', 120),
      f('trackingNo', '运单号', 'text', 150), f('carrier', '承运商', 'text', 130), f('callbackTime', '回传时间', 'datetime', 160), sel('status', '状态', opt(['待回传:待回传', '已回传:已回传']))],
    statusField: 'status', seed: [
      { id: 1, platformOrderNo: 'TB20261118001', platform: '淘宝', trackingNo: 'SF1234567890', carrier: '顺丰速运', callbackTime: '2026-11-18 15:00:00', status: '已回传' },
      { id: 2, platformOrderNo: 'JD20261117005', platform: '京东', trackingNo: 'YT9876543210', carrier: '圆通速递', callbackTime: '', status: '待回传' },
    ],
  },
  fullReductions: {
    collection: 'fullReductions', label: '满减活动',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('name', '活动名称', 'text', 180), f('threshold', '满额', 'money', 120),
      f('discount', '减额', 'money', 120), f('startDate', '开始日期', 'date', 120), f('endDate', '结束日期', 'date', 120), sel('status', '状态', ON_OFF)],
    statusField: 'status', seed: [
      { id: 1, name: '双十一满300减50', threshold: 300, discount: 50, startDate: '2026-11-01', endDate: '2026-11-11', status: 0 },
      { id: 2, name: '日常满100减10', threshold: 100, discount: 10, startDate: '2026-11-01', endDate: '2026-12-31', status: 1 },
    ],
  },
  flashSales: {
    collection: 'flashSales', label: '秒杀活动',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('name', '活动名称', 'text', 180), f('productName', '秒杀产品', 'text', 170),
      f('flashPrice', '秒杀价', 'money', 120), f('limitQty', '限购数量', 'number', 110), f('startTime', '开始时间', 'datetime', 160), sel('status', '状态', opt(['未开始:未开始', '进行中:进行中', '已结束:已结束']))],
    statusField: 'status', seed: [
      { id: 1, name: '周末秒杀专场', productName: '华为耳机', flashPrice: 199, limitQty: 2, startTime: '2026-11-21 10:00:00', status: '未开始' },
      { id: 2, name: '新品秒杀', productName: 'USB-C 扩展坞', flashPrice: 89, limitQty: 1, startTime: '2026-11-18 10:00:00', status: '已结束' },
    ],
  },

  /* ------------------------------ 系统管理 ------------------------------ */
  systemThemes: {
    collection: 'systemThemes', label: '主题配置',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('name', '主题名称', 'text', 160), f('code', '主题编码', 'text', 120),
      f('primaryColor', '主色调', 'text', 130), f('sidebarColor', '侧栏颜色', 'text', 130), sel('isDefault', '默认主题', YESNO), sel('status', '状态', ON_OFF)],
    statusField: 'status', seed: [
      { id: 1, name: '明亮蓝（默认）', code: 'light-blue', primaryColor: '#4d6bfe', sidebarColor: '#12161f', isDefault: 1, status: 1 },
      { id: 2, name: '深邃黑', code: 'dark', primaryColor: '#5b7cfa', sidebarColor: '#0a0d14', isDefault: 0, status: 1 },
      { id: 3, name: '森林绿', code: 'green', primaryColor: '#16a34a', sidebarColor: '#12211a', isDefault: 0, status: 0 },
    ],
  },
  systemPayConfigs: {
    collection: 'systemPayConfigs', label: '支付配置',
    fields: [f('id', 'ID', 'text', 70, { form: false }), f('channel', '支付渠道', 'text', 140), f('merchantId', '商户号', 'text', 160),
      f('appId', '应用ID', 'text', 160), f('callbackUrl', '回调地址', 'text', 200), sel('status', '状态', ON_OFF)],
    statusField: 'status', seed: [
      { id: 1, channel: '微信支付', merchantId: '1900000001', appId: 'wx888888888888', callbackUrl: '/api/v1/callback/wechat', status: 1 },
      { id: 2, channel: '支付宝', merchantId: '2088000000000001', appId: '2021000000000000', callbackUrl: '/api/v1/callback/alipay', status: 1 },
      { id: 3, channel: '银联商务', merchantId: '9000000001', appId: 'unionpay-app', callbackUrl: '/api/v1/callback/unionpay', status: 0 },
    ],
  },
};

/**
 * 集合别名：菜单 api 路径经 handleMock 的 collectionOf() 推导出的集合名可能与
 * 上面的简短 key 不同（如 purchase/supplier-contacts -> purchaseSupplierContacts）。
 * 这里把推导名指向同一份 Schema，保证通用页首屏能拿到真实字段与业务种子。
 */
const COLLECTION_ALIASES: Record<string, string> = {
  purchaseSupplierContacts: 'supplierContacts',
  purchaseSupplierRankings: 'supplierRankings',
  inventoryProductCreates: 'productCreates',
  inventoryProductImports: 'productImports',
  inventoryProductImportUpdates: 'productImportUpdates',
  inventoryProductBarcodes: 'productBarcodes',
  inventoryBatchTraces: 'batchTraces',
  inventoryMaterialReturns: 'materialReturns',
  inventoryOtherInOuts: 'otherInOuts',
  inventoryNegativeStocks: 'negativeStocks',
  manufacturingWorkOrderProgress: 'workOrderProgress',
  manufacturingLossAnalysis: 'lossAnalysis',
  financeProfitLoss: 'profitLosses',
  financeBalanceSheets: 'balanceSheets',
  financeTaxSummaries: 'taxSummaries',
  financeExpensesNew: 'expensesNew',
  financeBadDebts: 'badDebts',
  financeCollectionPlans: 'collectionPlans',
  financeAssetDisposals: 'assetDisposals',
  financeAssetChecks: 'assetChecks',
  financeTaxCodes: 'taxCodes',
  financeTaxRates: 'taxRates',
  financeTaxDeclarations: 'taxDeclarations',
  collabApprovalTemplates: 'approvalTemplates',
  collabApprovalCc: 'approvalCc',
  collabProjectDashboards: 'projectDashboards',
  collabTimesheets: 'timesheets',
  hrHirings: 'hirings',
  hrAssetLedgers: 'assetLedgers',
  hrAssetReturns: 'assetReturns',
  hrAssetScraps: 'assetScraps',
  hrDrivers: 'drivers',
  hrVehicleUses: 'vehicleUses',
  hrFuelRecords: 'fuelRecords',
  hrVehicleMaintains: 'vehicleMaintains',
  shopGoodsPublications: 'goodsPublications',
  shopStockSyncs: 'stockSyncs',
  shopOrderSyncs: 'orderSyncs',
  shopShipCallbacks: 'shipCallbacks',
  shopFullReductions: 'fullReductions',
  shopFlashSales: 'flashSales',
};
for (const [alias, key] of Object.entries(COLLECTION_ALIASES)) {
  docGapOverrides[alias] = docGapOverrides[key];
}
