/**
 * 财务域实体 Schema 覆盖
 * ---------------------------------------------------------------------------
 * 将 entitySchemas.ts 中财务域的占位集合（名称/编码/说明/状态）替换为
 * 《ERP完整产品与技术文档》4.6 财务与会计要求的真实业务字段：
 * 固定资产与折旧、费用与收入、资金转账、发票、期末结账、试算平衡、报表与税务。
 */
import { f, sel, opt, ON_OFF, DOC_STATUS_OPT, EntitySchema } from './types';

/** 财务域覆盖集合 */
export const financeOverrides: Record<string, EntitySchema> = {
  financeSubjects: {
    collection: 'financeSubjects', label: '会计科目表',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('code', '科目编码', 'text', 110),
      f('name', '科目名称', 'text', 180),
      sel('category', '科目类别', opt(['资产:资产', '负债:负债', '所有者权益:所有者权益', '成本:成本', '损益:损益']), 110),
      sel('direction', '余额方向', opt(['1:借方', '2:贷方']), 90),
      f('parentCode', '上级科目', 'text', 110),
      sel('isDetail', '是否明细', opt(['1:是', '0:否']), 90),
      f('description', '说明', 'textarea'),
      sel('status', '状态', ON_OFF),
    ],
    statusField: 'status', statusLabels: { '1': '启用', '0': '停用' },
    seed: [
      { id: 1, code: '1001', name: '库存现金', category: '资产', direction: 1, parentCode: '', isDetail: 1, description: '企业库存现金', status: 1 },
      { id: 2, code: '1002', name: '银行存款', category: '资产', direction: 1, parentCode: '', isDetail: 1, description: '企业银行存款', status: 1 },
      { id: 3, code: '1122', name: '应收账款', category: '资产', direction: 1, parentCode: '', isDetail: 1, description: '销售未收款', status: 1 },
      { id: 4, code: '1403', name: '原材料', category: '资产', direction: 1, parentCode: '', isDetail: 1, description: '生产用原材料', status: 1 },
      { id: 5, code: '1405', name: '库存商品', category: '资产', direction: 1, parentCode: '', isDetail: 1, description: '已完工待售商品', status: 1 },
    ],
  },

  financeAccounts: {
    collection: 'financeAccounts', label: '账户列表',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('accountName', '账户名称', 'text', 170),
      f('accountNo', '银行账号', 'text', 170),
      f('bankName', '开户行', 'text', 170),
      sel('accountType', '账户类型', opt(['BASIC:基本户', 'GENERAL:一般户', 'CASH:现金户']), 110),
      sel('currency', '币种', opt(['CNY:人民币', 'USD:美元', 'EUR:欧元']), 90),
      f('openingBalance', '期初余额', 'money', 130),
      f('currentBalance', '当前余额', 'money', 130),
      sel('status', '状态', ON_OFF),
    ],
    statusField: 'status', statusLabels: { '1': '启用', '0': '停用' },
    seed: [
      { id: 1, accountName: '现金账户', accountNo: '—', bankName: '—', accountType: 'CASH', currency: 'CNY', openingBalance: 12000, currentBalance: 12000, status: 1 },
      { id: 2, accountName: '招商银行基本户', accountNo: '6225 8888 0011 2233', bankName: '招商银行深圳分行', accountType: 'BASIC', currency: 'CNY', openingBalance: 258000, currentBalance: 258000, status: 1 },
      { id: 3, accountName: '中国银行一般户', accountNo: '4563 1122 0099 8877', bankName: '中国银行南山支行', accountType: 'GENERAL', currency: 'CNY', openingBalance: 86000, currentBalance: 86000, status: 1 },
    ],
  },

  financeAssets: {
    collection: 'financeAssets', label: '固定资产',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('assetNo', '资产编号', 'text', 140),
      f('assetName', '资产名称', 'text', 180),
      sel('assetType', '资产类别', opt(['设备:设备', '房屋:房屋建筑物', '车辆:运输工具', '办公:办公设备', '电子:电子设备']), 120),
      f('deptName', '使用部门', 'text', 120),
      f('purchaseDate', '购入日期', 'date', 120),
      f('originalValue', '原值', 'money', 130),
      f('accumDep', '累计折旧', 'money', 130),
      f('netValue', '净值', 'money', 130),
      f('usefulLife', '使用年限(年)', 'number', 120),
      f('residualRate', '残值率(%)', 'number', 110),
      sel('depMethod', '折旧方法', opt(['STRAIGHT:年限平均法', 'DOUBLE:双倍余额递减法', 'SUM:年数总和法']), 150),
      sel('status', '状态', opt(['USING:在用', 'IDLE:闲置', 'DISPOSED:已处置']), 110),
    ],
    statusField: 'status', statusLabels: { USING: '在用', IDLE: '闲置', DISPOSED: '已处置' },
    seed: [
      { id: 1, assetNo: 'FA2026001', assetName: '数控加工中心', assetType: '设备', deptName: '生产部', purchaseDate: '2024-03-15', originalValue: 480000, accumDep: 128000, netValue: 352000, usefulLife: 10, residualRate: 5, depMethod: 'STRAIGHT', status: 'USING' },
      { id: 2, assetNo: 'FA2026002', assetName: '厂房办公楼', assetType: '房屋', deptName: '行政部', purchaseDate: '2020-06-01', originalValue: 2600000, accumDep: 390000, netValue: 2210000, usefulLife: 20, residualRate: 3, depMethod: 'STRAIGHT', status: 'USING' },
      { id: 3, assetNo: 'FA2026003', assetName: '货运卡车', assetType: '车辆', deptName: '物流部', purchaseDate: '2023-09-20', originalValue: 186000, accumDep: 74400, netValue: 111600, usefulLife: 5, residualRate: 5, depMethod: 'DOUBLE', status: 'USING' },
      { id: 4, assetNo: 'FA2026004', assetName: '旧办公电脑组', assetType: '电子', deptName: '信息部', purchaseDate: '2019-01-10', originalValue: 52000, accumDep: 52000, netValue: 0, usefulLife: 3, residualRate: 0, depMethod: 'STRAIGHT', status: 'DISPOSED' },
    ],
  },

  financeDepreciations: {
    collection: 'financeDepreciations', label: '折旧',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('depNo', '折旧单号', 'text', 150),
      f('assetNo', '资产编号', 'text', 140),
      f('assetName', '资产名称', 'text', 170),
      f('period', '折旧期间', 'text', 110),
      sel('depMethod', '折旧方法', opt(['STRAIGHT:年限平均法', 'DOUBLE:双倍余额递减法', 'SUM:年数总和法']), 150),
      f('openingNet', '期初净值', 'money', 130),
      f('amount', '本期折旧额', 'money', 130),
      f('accumDep', '累计折旧额', 'money', 130),
      f('depDate', '计提日期', 'date', 120),
      sel('status', '状态', opt(['0:待计提', '1:已计提', '9:已作废']), 110),
    ],
    statusField: 'status', statusLabels: { '0': '待计提', '1': '已计提', '9': '已作废' },
    seed: [
      { id: 1, depNo: 'DEP202611-0001', assetNo: 'FA2026001', assetName: '数控加工中心', period: '2026-11', depMethod: 'STRAIGHT', openingNet: 356000, amount: 3800, accumDep: 131800, depDate: '2026-11-30', status: 0 },
      { id: 2, depNo: 'DEP202611-0002', assetNo: 'FA2026002', assetName: '厂房办公楼', period: '2026-11', depMethod: 'STRAIGHT', openingNet: 2216500, amount: 10508.33, accumDep: 400508.33, depDate: '2026-11-30', status: 0 },
      { id: 3, depNo: 'DEP202610-0003', assetNo: 'FA2026003', assetName: '货运卡车', period: '2026-10', depMethod: 'DOUBLE', openingNet: 114480, amount: 2946.67, accumDep: 77346.67, depDate: '2026-10-31', status: 1 },
    ],
  },

  financeCosts: {
    collection: 'financeCosts', label: '成本核算',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('costNo', '成本单号', 'text', 150),
      sel('targetType', '核算对象', opt(['PRODUCT:产品', 'ORDER:订单', 'DEPT:部门']), 120),
      f('targetName', '对象名称', 'text', 170),
      f('costItem', '成本项目', 'text', 140),
      f('period', '期间', 'text', 110),
      f('qty', '数量', 'number', 100),
      f('unitCost', '单位成本', 'money', 120),
      f('totalCost', '总成本', 'money', 130),
      f('settledAmount', '已结转', 'money', 130),
      sel('status', '状态', opt(['0:待结转', '1:已结转', '9:已作废']), 110),
    ],
    statusField: 'status', statusLabels: { '0': '待结转', '1': '已结转', '9': '已作废' },
    seed: [
      { id: 1, costNo: 'COST202611-0001', targetType: 'PRODUCT', targetName: '激光切割机 LG-200', costItem: '直接材料', period: '2026-11', qty: 20, unitCost: 8600, totalCost: 172000, settledAmount: 0, status: 0 },
      { id: 2, costNo: 'COST202611-0002', targetType: 'PRODUCT', targetName: '激光切割机 LG-200', costItem: '直接人工', period: '2026-11', qty: 20, unitCost: 1200, totalCost: 24000, settledAmount: 0, status: 0 },
      { id: 3, costNo: 'COST202610-0003', targetType: 'PRODUCT', targetName: '数控折弯机 NW-100', costItem: '制造费用', period: '2026-10', qty: 15, unitCost: 980, totalCost: 14700, settledAmount: 14700, status: 1 },
    ],
  },

  financeExpenseCategories: {
    collection: 'financeExpenseCategories', label: '费用类别',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('code', '类别编码', 'text', 120),
      f('name', '类别名称', 'text', 170),
      f('parentName', '上级类别', 'text', 150),
      f('subjectCode', '费用科目', 'text', 120),
      f('budgetAmount', '预算金额', 'money', 130),
      f('usedAmount', '已用金额', 'money', 130),
      f('deptName', '适用部门', 'text', 120),
      sel('status', '状态', ON_OFF),
    ],
    statusField: 'status', statusLabels: { '1': '启用', '0': '停用' },
    seed: [
      { id: 1, code: 'EXP-01', name: '办公费', parentName: '管理费用', subjectCode: '6602', budgetAmount: 60000, usedAmount: 38420, deptName: '全公司', status: 1 },
      { id: 2, code: 'EXP-02', name: '差旅费', parentName: '销售费用', subjectCode: '6601', budgetAmount: 120000, usedAmount: 76500, deptName: '销售部', status: 1 },
      { id: 3, code: 'EXP-03', name: '设备维修费', parentName: '制造费用', subjectCode: '5101', budgetAmount: 80000, usedAmount: 51200, deptName: '生产部', status: 1 },
    ],
  },

  financeIncomeCategories: {
    collection: 'financeIncomeCategories', label: '收入类别',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('code', '类别编码', 'text', 120),
      f('name', '类别名称', 'text', 170),
      f('subjectCode', '收入科目', 'text', 120),
      f('taxRate', '税率(%)', 'number', 110),
      f('bizType', '适用业务', 'text', 140),
      sel('status', '状态', ON_OFF),
    ],
    statusField: 'status', statusLabels: { '1': '启用', '0': '停用' },
    seed: [
      { id: 1, code: 'INC-01', name: '商品销售收入', subjectCode: '6001', taxRate: 13, bizType: '销售出库', status: 1 },
      { id: 2, code: 'INC-02', name: '技术服务收入', subjectCode: '6001', taxRate: 6, bizType: '服务合同', status: 1 },
      { id: 3, code: 'INC-03', name: '设备租赁收入', subjectCode: '6001', taxRate: 13, bizType: '租赁业务', status: 1 },
    ],
  },

  financeIncomes: {
    collection: 'financeIncomes', label: '收入列表',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('incomeNo', '收入单号', 'text', 150),
      f('incomeType', '收入类型', 'text', 130),
      f('partnerName', '对方单位', 'text', 170),
      f('incomeDate', '收入日期', 'date', 120),
      f('amount', '金额', 'money', 130),
      f('taxAmount', '税额', 'money', 120),
      f('accountName', '收款账户', 'text', 150),
      f('voucherNo', '凭证号', 'text', 150),
      f('summary', '摘要', 'textarea'),
      sel('status', '状态', opt(['0:草稿', '2:已确认', '4:已收款']), 110),
    ],
    statusField: 'status', statusLabels: { '0': '草稿', '2': '已确认', '4': '已收款' },
    seed: [
      { id: 1, incomeNo: 'INC202611-0001', incomeType: '商品销售', partnerName: '深圳市宏图科技有限公司', incomeDate: '2026-11-12', amount: 128000, taxAmount: 14725.66, accountName: '招商银行基本户', voucherNo: 'V20261112-0007', summary: 'LG-200 激光切割机 2 台', status: 4 },
      { id: 2, incomeNo: 'INC202611-0002', incomeType: '技术服务', partnerName: '东莞市精密制造有限公司', incomeDate: '2026-11-15', amount: 36000, taxAmount: 2037.74, accountName: '中国银行一般户', voucherNo: 'V20261115-0011', summary: '设备调试与培训服务', status: 2 },
      { id: 3, incomeNo: 'INC202611-0003', incomeType: '设备租赁', partnerName: '佛山市机械加工厂', incomeDate: '2026-11-18', amount: 18000, taxAmount: 2070.8, accountName: '招商银行基本户', voucherNo: '', summary: '折弯机月租金', status: 0 },
    ],
  },

  financeTransfers: {
    collection: 'financeTransfers', label: '资金转账',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('transferNo', '转账单号', 'text', 150),
      f('fromAccount', '转出账户', 'text', 160),
      f('toAccount', '转入账户', 'text', 160),
      f('transferDate', '转账日期', 'date', 120),
      f('amount', '金额', 'money', 130),
      f('fee', '手续费', 'money', 110),
      f('summary', '摘要', 'textarea'),
      sel('status', '状态', opt(['0:草稿', '2:已确认', '4:已完成']), 110),
    ],
    statusField: 'status', statusLabels: { '0': '草稿', '2': '已确认', '4': '已完成' },
    seed: [
      { id: 1, transferNo: 'TR202611-0001', fromAccount: '招商银行基本户', toAccount: '中国银行一般户', transferDate: '2026-11-10', amount: 50000, fee: 5, summary: '资金调拨', status: 4 },
      { id: 2, transferNo: 'TR202611-0002', fromAccount: '招商银行基本户', toAccount: '现金账户', transferDate: '2026-11-16', amount: 8000, fee: 0, summary: '备用金提取', status: 2 },
    ],
  },

  financeInvoices: {
    collection: 'financeInvoices', label: '发票登记',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('invoiceNo', '发票号码', 'text', 150),
      f('invoiceCode', '发票代码', 'text', 140),
      sel('invoiceType', '发票类型', opt(['SPECIAL:增值税专票', 'NORMAL:增值税普票', 'ELECTRONIC:电子发票']), 140),
      f('buyerName', '购买方', 'text', 180),
      f('sourceNo', '来源单据', 'text', 150),
      f('invoiceDate', '开票日期', 'date', 120),
      f('amount', '金额', 'money', 130),
      f('taxRate', '税率(%)', 'number', 110),
      f('taxAmount', '税额', 'money', 120),
      sel('status', '状态', opt(['0:待开', '1:已开', '2:已认证', '9:已作废']), 110),
    ],
    statusField: 'status', statusLabels: { '0': '待开', '1': '已开', '2': '已认证', '9': '已作废' },
    seed: [
      { id: 1, invoiceNo: '044120261112', invoiceCode: '0441200000', invoiceType: 'SPECIAL', buyerName: '深圳市宏图科技有限公司', sourceNo: 'SO20261105-0008', invoiceDate: '2026-11-12', amount: 128000, taxRate: 13, taxAmount: 14725.66, status: 2 },
      { id: 2, invoiceNo: '044120261118', invoiceCode: '0441200000', invoiceType: 'ELECTRONIC', buyerName: '东莞市精密制造有限公司', sourceNo: 'SO20261109-0012', invoiceDate: '2026-11-15', amount: 36000, taxRate: 6, taxAmount: 2037.74, status: 1 },
      { id: 3, invoiceNo: '', invoiceCode: '', invoiceType: 'SPECIAL', buyerName: '佛山市机械加工厂', sourceNo: 'SO20261117-0003', invoiceDate: '2026-11-18', amount: 18000, taxRate: 13, taxAmount: 2070.8, status: 0 },
    ],
  },

  financePeriods: {
    collection: 'financePeriods', label: '期末结账',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('period', '会计期间', 'text', 120),
      f('periodName', '期间名称', 'text', 150),
      f('startDate', '开始日期', 'date', 120),
      f('endDate', '结束日期', 'date', 120),
      sel('status', '状态', opt(['0:未开启', '1:已开启', '2:已结账']), 110),
      f('closedBy', '结账人', 'text', 120),
      f('closedAt', '结账日期', 'date', 120),
      f('voucherCount', '凭证数量', 'number', 110),
    ],
    statusField: 'status', statusLabels: { '0': '未开启', '1': '已开启', '2': '已结账' },
    seed: [
      { id: 1, period: '2026-09', periodName: '2026年9月', startDate: '2026-09-01', endDate: '2026-09-30', status: 2, closedBy: '陈会计', closedAt: '2026-10-05', voucherCount: 86 },
      { id: 2, period: '2026-10', periodName: '2026年10月', startDate: '2026-10-01', endDate: '2026-10-31', status: 2, closedBy: '陈会计', closedAt: '2026-11-04', voucherCount: 94 },
      { id: 3, period: '2026-11', periodName: '2026年11月', startDate: '2026-11-01', endDate: '2026-11-30', status: 1, closedBy: '', closedAt: '', voucherCount: 37 },
    ],
  },

  financeTrialBalance: {
    collection: 'financeTrialBalance', label: '试算平衡表',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('period', '期间', 'text', 110),
      f('subjectCode', '科目编码', 'text', 120),
      f('subjectName', '科目名称', 'text', 170),
      f('openingDebit', '期初借方', 'money', 130),
      f('openingCredit', '期初贷方', 'money', 130),
      f('periodDebit', '本期借方', 'money', 130),
      f('periodCredit', '本期贷方', 'money', 130),
      f('closingDebit', '期末借方', 'money', 130),
      f('closingCredit', '期末贷方', 'money', 130),
      sel('balanced', '是否平衡', opt(['1:平衡', '0:不平衡']), 110),
    ],
    statusField: 'balanced', statusLabels: { '1': '平衡', '0': '不平衡' },
    seed: [
      { id: 1, period: '2026-11', subjectCode: '1002', subjectName: '银行存款', openingDebit: 258000, openingCredit: 0, periodDebit: 164000, periodCredit: 58000, closingDebit: 364000, closingCredit: 0, balanced: 1 },
      { id: 2, period: '2026-11', subjectCode: '1122', subjectName: '应收账款', openingDebit: 96000, openingCredit: 0, periodDebit: 128000, periodCredit: 42000, closingDebit: 182000, closingCredit: 0, balanced: 1 },
      { id: 3, period: '2026-11', subjectCode: '6001', subjectName: '主营业务收入', openingDebit: 0, openingCredit: 0, periodDebit: 0, periodCredit: 145000, closingDebit: 0, closingCredit: 145000, balanced: 1 },
    ],
  },

  financereports: {
    collection: 'financereports', label: '财务报表',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('period', '报表期间', 'text', 110),
      sel('reportType', '报表类型', opt(['BS:资产负债表', 'IS:利润表', 'CF:现金流量表']), 140),
      f('itemName', '项目', 'text', 180),
      f('currentAmount', '本期金额', 'money', 130),
      f('priorAmount', '上期金额', 'money', 130),
      f('changeAmount', '同比变动', 'money', 130),
      sel('changeDir', '变动方向', opt(['UP:增', 'DOWN:减', 'FLAT:持平']), 110),
      sel('status', '状态', ON_OFF),
    ],
    statusField: 'status', statusLabels: { '1': '启用', '0': '停用' },
    seed: [
      { id: 1, period: '2026-11', reportType: 'IS', itemName: '营业收入', currentAmount: 1450000, priorAmount: 1280000, changeAmount: 170000, changeDir: 'UP', status: 1 },
      { id: 2, period: '2026-11', reportType: 'IS', itemName: '营业成本', currentAmount: 980000, priorAmount: 872000, changeAmount: 108000, changeDir: 'UP', status: 1 },
      { id: 3, period: '2026-11', reportType: 'BS', itemName: '资产总计', currentAmount: 8640000, priorAmount: 8120000, changeAmount: 520000, changeDir: 'UP', status: 1 },
      { id: 4, period: '2026-11', reportType: 'CF', itemName: '经营活动现金流入', currentAmount: 1320000, priorAmount: 1410000, changeAmount: -90000, changeDir: 'DOWN', status: 1 },
    ],
  },

  financetax: {
    collection: 'financetax', label: '税务申报',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('period', '申报期间', 'text', 110),
      sel('taxType', '税种', opt(['VAT:增值税', 'CIT:企业所得税', 'SURTAX:附加税', 'STAMP:印花税']), 140),
      f('taxableAmount', '计税金额', 'money', 130),
      f('taxRate', '税率(%)', 'number', 110),
      f('taxAmount', '应纳税额', 'money', 130),
      sel('status', '状态', opt(['0:待申报', '1:已申报', '2:已缴款']), 110),
      f('declareDate', '申报日期', 'date', 120),
    ],
    statusField: 'status', statusLabels: { '0': '待申报', '1': '已申报', '2': '已缴款' },
    seed: [
      { id: 1, period: '2026-10', taxType: 'VAT', taxableAmount: 1280000, taxRate: 13, taxAmount: 147256.64, status: 2, declareDate: '2026-11-08' },
      { id: 2, period: '2026-10', taxType: 'CIT', taxableAmount: 320000, taxRate: 25, taxAmount: 80000, status: 1, declareDate: '2026-11-12' },
      { id: 3, period: '2026-11', taxType: 'VAT', taxableAmount: 1450000, taxRate: 13, taxAmount: 166814.16, status: 0, declareDate: '' },
    ],
  },
};
