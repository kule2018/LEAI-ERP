/**
 * 人力与协同域实体 Schema 覆盖
 * ---------------------------------------------------------------------------
 * HR：劳动合同、员工资产、假期、面试、薪资、绩效、岗位、排班、车辆。
 * 协同：项目、里程碑、任务看板、会议、文件、公告、目标、项目报表。
 */
import { f, sel, opt, ON_OFF, EntitySchema } from './types';

/** 人力域覆盖集合 */
export const hrOverrides: Record<string, EntitySchema> = {
  hrContracts: {
    collection: 'hrContracts', label: '劳动合同',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('contractNo', '合同编号', 'text', 160),
      f('employeeName', '员工姓名', 'text', 140),
      f('deptName', '所属部门', 'text', 140),
      sel('contractType', '合同类型', opt(['FIXED:固定期限', 'OPEN:无固定期限', 'INTERN:实习协议', 'DISPATCH:劳务派遣']), 140),
      f('startDate', '开始日期', 'date', 120),
      f('endDate', '结束日期', 'date', 120),
      f('salary', '约定月薪', 'money', 120),
      sel('status', '状态', opt(['ACTIVE:生效中', 'EXPIRING:即将到期', 'EXPIRED:已到期', 'TERMINATED:已终止']), 120),
    ],
    statusField: 'status', statusLabels: { ACTIVE: '生效中', EXPIRING: '即将到期', EXPIRED: '已到期', TERMINATED: '已终止' },
    seed: [
      { id: 1, contractNo: 'HT2024-0018', employeeName: '张伟', deptName: '销售部', contractType: 'FIXED', startDate: '2024-03-01', endDate: '2027-02-28', salary: 12000, status: 'ACTIVE' },
      { id: 2, contractNo: 'HT2023-0042', employeeName: '李娜', deptName: '财务部', contractType: 'FIXED', startDate: '2023-07-01', endDate: '2026-12-31', salary: 9800, status: 'EXPIRING' },
      { id: 3, contractNo: 'HT2022-0009', employeeName: '王强', deptName: '生产部', contractType: 'OPEN', startDate: '2022-01-10', endDate: '', salary: 8600, status: 'ACTIVE' },
    ],
  },

  hrAssets: {
    collection: 'hrAssets', label: '员工资产',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('assetNo', '资产编号', 'text', 150),
      f('assetName', '资产名称', 'text', 180),
      sel('assetType', '资产类型', opt(['PC:电脑', 'PHONE:手机', 'TOOL:工具', 'CAR:车辆', 'OTHER:其他']), 130),
      f('employeeName', '领用人', 'text', 140),
      f('deptName', '所属部门', 'text', 140),
      f('assignDate', '领用日期', 'date', 120),
      f('value', '资产价值', 'money', 130),
      sel('status', '状态', opt(['IN_USE:在用', 'RETURNED:已归还', 'DAMAGED:损坏', 'LOST:遗失']), 120),
    ],
    statusField: 'status', statusLabels: { IN_USE: '在用', RETURNED: '已归还', DAMAGED: '损坏', LOST: '遗失' },
    seed: [
      { id: 1, assetNo: 'HA-2024-0132', assetName: 'ThinkPad X1 笔记本', assetType: 'PC', employeeName: '张伟', deptName: '销售部', assignDate: '2024-03-05', value: 9800, status: 'IN_USE' },
      { id: 2, assetNo: 'HA-2023-0088', assetName: 'iPhone 15 工作机', assetType: 'PHONE', employeeName: '李娜', deptName: '财务部', assignDate: '2023-11-20', value: 6999, status: 'IN_USE' },
      { id: 3, assetNo: 'HA-2022-0045', assetName: '测量工具套装', assetType: 'TOOL', employeeName: '王强', deptName: '生产部', assignDate: '2022-02-18', value: 2400, status: 'DAMAGED' },
    ],
  },

  hrHolidays: {
    collection: 'hrHolidays', label: '假期管理',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('holidayNo', '假期编号', 'text', 150),
      f('employeeName', '员工姓名', 'text', 140),
      f('deptName', '所属部门', 'text', 140),
      sel('holidayType', '假期类型', opt(['ANNUAL:年假', 'SICK:病假', 'PERSONAL:事假', 'MARRIAGE:婚假', 'MATERNITY:产假']), 130),
      f('startDate', '开始日期', 'date', 120),
      f('endDate', '结束日期', 'date', 120),
      f('days', '天数', 'number', 100),
      f('reason', '请假原因', 'textarea'),
      sel('status', '状态', opt(['PENDING:待审批', 'APPROVED:已批准', 'REJECTED:已驳回', 'CANCELED:已撤销']), 120),
    ],
    statusField: 'status', statusLabels: { PENDING: '待审批', APPROVED: '已批准', REJECTED: '已驳回', CANCELED: '已撤销' },
    seed: [
      { id: 1, holidayNo: 'LV202611-0001', employeeName: '张伟', deptName: '销售部', holidayType: 'ANNUAL', startDate: '2026-11-20', endDate: '2026-11-22', days: 3, reason: '家事返乡', status: 'APPROVED' },
      { id: 2, holidayNo: 'LV202611-0002', employeeName: '李娜', deptName: '财务部', holidayType: 'SICK', startDate: '2026-11-18', endDate: '2026-11-18', days: 1, reason: '感冒发烧', status: 'PENDING' },
      { id: 3, holidayNo: 'LV202611-0003', employeeName: '王强', deptName: '生产部', holidayType: 'PERSONAL', startDate: '2026-11-25', endDate: '2026-11-26', days: 2, reason: '办理证件', status: 'PENDING' },
    ],
  },

  hrInterviews: {
    collection: 'hrInterviews', label: '面试管理',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('interviewNo', '面试编号', 'text', 150),
      f('candidateName', '候选人', 'text', 140),
      f('positionName', '应聘岗位', 'text', 160),
      f('interviewDate', '面试时间', 'datetime', 170),
      f('interviewer', '面试官', 'text', 140),
      sel('round', '面试轮次', opt(['1:初试', '2:复试', '3:终试']), 110),
      f('score', '评分', 'number', 100),
      sel('result', '结果', opt(['PENDING:待定', 'PASS:通过', 'FAIL:不通过', 'HIRED:已录用']), 120),
    ],
    statusField: 'result', statusLabels: { PENDING: '待定', PASS: '通过', FAIL: '不通过', HIRED: '已录用' },
    seed: [
      { id: 1, interviewNo: 'IV202611-0001', candidateName: '陈晓东', positionName: '销售经理', interviewDate: '2026-11-18 14:00', interviewer: '张伟', round: '2', score: 86, result: 'PASS' },
      { id: 2, interviewNo: 'IV202611-0002', candidateName: '刘芳', positionName: '会计', interviewDate: '2026-11-19 10:30', interviewer: '李娜', round: '1', score: 0, result: 'PENDING' },
      { id: 3, interviewNo: 'IV202610-0003', candidateName: '赵鹏', positionName: '数控操作工', interviewDate: '2026-10-28 09:00', interviewer: '王强', round: '1', score: 72, result: 'HIRED' },
    ],
  },

  hrPayrolls: {
    collection: 'hrPayrolls', label: '薪资管理',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('payrollNo', '薪资单号', 'text', 160),
      f('period', '薪资期间', 'text', 110),
      f('employeeName', '员工姓名', 'text', 140),
      f('deptName', '所属部门', 'text', 140),
      f('baseSalary', '基本工资', 'money', 130),
      f('bonus', '绩效奖金', 'money', 120),
      f('deduction', '扣款合计', 'money', 120),
      f('socialInsurance', '社保个人', 'money', 130),
      f('tax', '个税', 'money', 120),
      f('netPay', '实发工资', 'money', 130),
      sel('status', '状态', opt(['0:待核算', '1:已核算', '2:已发放']), 120),
    ],
    statusField: 'status', statusLabels: { '0': '待核算', '1': '已核算', '2': '已发放' },
    seed: [
      { id: 1, payrollNo: 'PAY202610-0001', period: '2026-10', employeeName: '张伟', deptName: '销售部', baseSalary: 12000, bonus: 4800, deduction: 200, socialInsurance: 1260, tax: 585, netPay: 14755, status: 2 },
      { id: 2, payrollNo: 'PAY202610-0002', period: '2026-10', employeeName: '李娜', deptName: '财务部', baseSalary: 9800, bonus: 1600, deduction: 0, socialInsurance: 1029, tax: 231, netPay: 10140, status: 2 },
      { id: 3, payrollNo: 'PAY202611-0003', period: '2026-11', employeeName: '王强', deptName: '生产部', baseSalary: 8600, bonus: 1200, deduction: 150, socialInsurance: 903, tax: 104, netPay: 8643, status: 1 },
    ],
  },

  hrPositions: {
    collection: 'hrPositions', label: '岗位管理',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('code', '岗位编码', 'text', 130),
      f('name', '岗位名称', 'text', 170),
      f('deptName', '所属部门', 'text', 140),
      sel('level', '岗位级别', opt(['P1:初级', 'P2:中级', 'P3:高级', 'M1:主管', 'M2:经理']), 120),
      f('headcount', '编制人数', 'number', 120),
      f('currentCount', '在岗人数', 'number', 120),
      f('salaryRange', '薪资范围', 'text', 150),
      sel('status', '状态', ON_OFF),
    ],
    statusField: 'status', statusLabels: { '1': '启用', '0': '停用' },
    seed: [
      { id: 1, code: 'POS-SALES-M', name: '销售经理', deptName: '销售部', level: 'M2', headcount: 2, currentCount: 2, salaryRange: '12000-18000', status: 1 },
      { id: 2, code: 'POS-ACC', name: '会计', deptName: '财务部', level: 'P2', headcount: 3, currentCount: 2, salaryRange: '8000-11000', status: 1 },
      { id: 3, code: 'POS-CNC', name: '数控操作工', deptName: '生产部', level: 'P1', headcount: 12, currentCount: 10, salaryRange: '6000-9000', status: 1 },
    ],
  },

  hrShifts: {
    collection: 'hrShifts', label: '排班管理',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('shiftNo', '排班编号', 'text', 150),
      f('shiftName', '班次名称', 'text', 160),
      f('employeeName', '员工姓名', 'text', 140),
      f('deptName', '所属部门', 'text', 140),
      f('workDate', '排班日期', 'date', 120),
      f('startTime', '上班时间', 'text', 110),
      f('endTime', '下班时间', 'text', 110),
      sel('shiftType', '班次类型', opt(['DAY:白班', 'NIGHT:夜班', 'MID:中班', 'REST:休息']), 120),
      sel('status', '状态', opt(['0:待确认', '1:已确认', '9:已取消']), 110),
    ],
    statusField: 'status', statusLabels: { '0': '待确认', '1': '已确认', '9': '已取消' },
    seed: [
      { id: 1, shiftNo: 'SH202611-0001', shiftName: '白班 A', employeeName: '王强', deptName: '生产部', workDate: '2026-11-19', startTime: '08:00', endTime: '17:00', shiftType: 'DAY', status: 1 },
      { id: 2, shiftNo: 'SH202611-0002', shiftName: '夜班 B', employeeName: '赵鹏', deptName: '生产部', workDate: '2026-11-19', startTime: '20:00', endTime: '05:00', shiftType: 'NIGHT', status: 1 },
      { id: 3, shiftNo: 'SH202611-0003', shiftName: '白班 A', employeeName: '刘敏', deptName: '生产部', workDate: '2026-11-20', startTime: '08:00', endTime: '17:00', shiftType: 'DAY', status: 0 },
    ],
  },

  hrVehicles: {
    collection: 'hrVehicles', label: '车辆管理',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('plateNo', '车牌号', 'text', 140),
      f('vehicleType', '车辆类型', 'text', 140),
      f('brand', '品牌型号', 'text', 160),
      f('driver', '驾驶员', 'text', 130),
      f('deptName', '所属部门', 'text', 140),
      f('mileage', '里程(km)', 'number', 120),
      f('nextServiceDate', '下次保养日期', 'date', 140),
      sel('status', '状态', opt(['IDLE:空闲', 'IN_USE:使用中', 'MAINTAIN:保养中', 'SCRAPPED:已报废']), 120),
    ],
    statusField: 'status', statusLabels: { IDLE: '空闲', IN_USE: '使用中', MAINTAIN: '保养中', SCRAPPED: '已报废' },
    seed: [
      { id: 1, plateNo: '粤B·8H6K23', vehicleType: '厢式货车', brand: '福田欧马可 4.2米', driver: '周司机', deptName: '物流部', mileage: 86420, nextServiceDate: '2026-12-15', status: 'IN_USE' },
      { id: 2, plateNo: '粤B·5D2L88', vehicleType: '商务车', brand: '别克 GL8', driver: '吴师傅', deptName: '行政部', mileage: 46200, nextServiceDate: '2027-01-20', status: 'IDLE' },
      { id: 3, plateNo: '粤B·3F9M11', vehicleType: '小货车', brand: '五菱荣光', driver: '郑司机', deptName: '物流部', mileage: 128600, nextServiceDate: '2026-11-25', status: 'MAINTAIN' },
    ],
  },

  hrmPerformance: {
    collection: 'hrmPerformance', label: '绩效管理',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('perfNo', '考核编号', 'text', 150),
      f('period', '考核期间', 'text', 110),
      f('employeeName', '员工姓名', 'text', 140),
      f('deptName', '所属部门', 'text', 140),
      sel('perfType', '考核类型', opt(['MONTH:月度', 'QUARTER:季度', 'YEAR:年度']), 120),
      f('targetScore', '目标分', 'number', 110),
      f('actualScore', '实得分', 'number', 110),
      sel('grade', '绩效等级', opt(['S:S级', 'A:A级', 'B:B级', 'C:C级', 'D:D级']), 110),
      sel('status', '状态', opt(['0:待自评', '1:待主管评', '2:已完成']), 120),
    ],
    statusField: 'status', statusLabels: { '0': '待自评', '1': '待主管评', '2': '已完成' },
    seed: [
      { id: 1, perfNo: 'PF2026Q3-0001', period: '2026-Q3', employeeName: '张伟', deptName: '销售部', perfType: 'QUARTER', targetScore: 100, actualScore: 118, grade: 'S', status: 2 },
      { id: 2, perfNo: 'PF2026Q3-0002', period: '2026-Q3', employeeName: '李娜', deptName: '财务部', perfType: 'QUARTER', targetScore: 100, actualScore: 92, grade: 'A', status: 2 },
      { id: 3, perfNo: 'PF2026Q4-0003', period: '2026-Q4', employeeName: '王强', deptName: '生产部', perfType: 'QUARTER', targetScore: 100, actualScore: 0, grade: 'B', status: 0 },
    ],
  },

  hrmSalary: {
    collection: 'hrmSalary', label: '薪酬标准',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('code', '标准编码', 'text', 140),
      f('name', '标准名称', 'text', 170),
      f('positionName', '适用岗位', 'text', 160),
      sel('level', '岗位级别', opt(['P1:初级', 'P2:中级', 'P3:高级', 'M1:主管', 'M2:经理']), 120),
      f('baseSalary', '基本工资', 'money', 130),
      f('bonusRate', '绩效系数', 'number', 120),
      f('allowance', '补贴', 'money', 120),
      sel('status', '状态', ON_OFF),
    ],
    statusField: 'status', statusLabels: { '1': '启用', '0': '停用' },
    seed: [
      { id: 1, code: 'SAL-P1', name: '初级岗位标准', positionName: '数控操作工', level: 'P1', baseSalary: 6500, bonusRate: 0.15, allowance: 600, status: 1 },
      { id: 2, code: 'SAL-P2', name: '中级岗位标准', positionName: '会计', level: 'P2', baseSalary: 9000, bonusRate: 0.2, allowance: 800, status: 1 },
      { id: 3, code: 'SAL-M2', name: '经理级标准', positionName: '销售经理', level: 'M2', baseSalary: 14000, bonusRate: 0.35, allowance: 1500, status: 1 },
    ],
  },
};

/** 协同域覆盖集合 */
export const collabOverrides: Record<string, EntitySchema> = {
  collabProjects: {
    collection: 'collabProjects', label: '项目管理',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('projectNo', '项目编号', 'text', 150),
      f('name', '项目名称', 'text', 190),
      f('owner', '项目负责人', 'text', 140),
      f('members', '项目成员', 'text', 190),
      f('startDate', '开始日期', 'date', 120),
      f('endDate', '计划结束', 'date', 120),
      f('budget', '预算', 'money', 130),
      f('progress', '进度(%)', 'number', 110),
      sel('status', '状态', opt(['PLAN:规划中', 'DOING:进行中', 'PAUSED:已暂停', 'DONE:已完成']), 120),
    ],
    statusField: 'status', statusLabels: { PLAN: '规划中', DOING: '进行中', PAUSED: '已暂停', DONE: '已完成' },
    seed: [
      { id: 1, projectNo: 'PRJ2026-001', name: 'ERP 系统二期上线', owner: '张伟', members: '张伟,李娜,王强,陈晓东', startDate: '2026-09-01', endDate: '2026-12-31', budget: 480000, progress: 68, status: 'DOING' },
      { id: 2, projectNo: 'PRJ2026-002', name: '智能仓储改造', owner: '王强', members: '王强,周司机', startDate: '2026-10-15', endDate: '2027-03-31', budget: 1260000, progress: 22, status: 'DOING' },
      { id: 3, projectNo: 'PRJ2026-003', name: '年度审计准备', owner: '李娜', members: '李娜,陈会计', startDate: '2026-11-01', endDate: '2027-01-31', budget: 60000, progress: 0, status: 'PLAN' },
    ],
  },

  collabMilestones: {
    collection: 'collabMilestones', label: '项目里程碑',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('projectName', '所属项目', 'text', 180),
      f('name', '里程碑名称', 'text', 190),
      f('planDate', '计划日期', 'date', 120),
      f('actualDate', '实际日期', 'date', 120),
      f('owner', '负责人', 'text', 140),
      f('deliverable', '交付物', 'textarea'),
      sel('status', '状态', opt(['PENDING:未开始', 'DOING:进行中', 'DONE:已完成', 'DELAY:已延期']), 120),
    ],
    statusField: 'status', statusLabels: { PENDING: '未开始', DOING: '进行中', DONE: '已完成', DELAY: '已延期' },
    seed: [
      { id: 1, projectName: 'ERP 系统二期上线', name: '需求确认签字', planDate: '2026-09-20', actualDate: '2026-09-18', owner: '张伟', deliverable: '需求规格说明书 v1.0', status: 'DONE' },
      { id: 2, projectName: 'ERP 系统二期上线', name: 'UAT 验收通过', planDate: '2026-11-30', actualDate: '', owner: '李娜', deliverable: 'UAT 测试报告', status: 'DOING' },
      { id: 3, projectName: '智能仓储改造', name: '设备到场验收', planDate: '2026-11-15', actualDate: '', owner: '王强', deliverable: '设备验收单', status: 'DELAY' },
    ],
  },

  collabBoard: {
    collection: 'collabBoard', label: '任务看板',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('taskNo', '任务编号', 'text', 150),
      f('title', '任务标题', 'text', 200),
      f('projectName', '所属项目', 'text', 170),
      f('assignee', '负责人', 'text', 130),
      f('dueDate', '截止日期', 'date', 120),
      sel('priority', '优先级', opt(['HIGH:高', 'MID:中', 'LOW:低']), 110),
      f('progress', '进度(%)', 'number', 110),
      sel('stage', '阶段', opt(['TODO:待办', 'DOING:进行中', 'REVIEW:待评审', 'DONE:已完成']), 120),
    ],
    statusField: 'stage', statusLabels: { TODO: '待办', DOING: '进行中', REVIEW: '待评审', DONE: '已完成' },
    seed: [
      { id: 1, taskNo: 'TK-0101', title: '完成财务模块凭证接口对接', projectName: 'ERP 系统二期上线', assignee: '李娜', dueDate: '2026-11-22', priority: 'HIGH', progress: 70, stage: 'DOING' },
      { id: 2, taskNo: 'TK-0102', title: '仓库货架安装验收', projectName: '智能仓储改造', assignee: '王强', dueDate: '2026-11-28', priority: 'MID', progress: 30, stage: 'DOING' },
      { id: 3, taskNo: 'TK-0103', title: '整理年度审计资料清单', projectName: '年度审计准备', assignee: '陈会计', dueDate: '2026-12-05', priority: 'LOW', progress: 0, stage: 'TODO' },
    ],
  },

  collabMeetings: {
    collection: 'collabMeetings', label: '会议管理',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('meetingNo', '会议编号', 'text', 150),
      f('title', '会议主题', 'text', 200),
      f('meetingTime', '会议时间', 'datetime', 170),
      f('location', '会议地点', 'text', 170),
      f('host', '主持人', 'text', 130),
      f('attendees', '参会人', 'text', 200),
      f('minutes', '会议纪要', 'textarea'),
      sel('status', '状态', opt(['PLAN:待召开', 'DOING:进行中', 'DONE:已结束', 'CANCELED:已取消']), 120),
    ],
    statusField: 'status', statusLabels: { PLAN: '待召开', DOING: '进行中', DONE: '已结束', CANCELED: '已取消' },
    seed: [
      { id: 1, meetingNo: 'MT202611-001', title: 'ERP 二期上线周例会', meetingTime: '2026-11-19 10:00', location: 'A 栋 3 楼会议室', host: '张伟', attendees: '张伟,李娜,王强,陈晓东', minutes: '确认 UAT 进度，财务模块需在下周三前完成对接', status: 'PLAN' },
      { id: 2, meetingNo: 'MT202611-002', title: '智能仓储方案评审', meetingTime: '2026-11-15 14:00', location: 'A 栋 2 楼会议室', host: '王强', attendees: '王强,周司机,外部供应商', minutes: '确定货架布局与 AGV 路线，预算追加 8 万', status: 'DONE' },
      { id: 3, meetingNo: 'MT202610-003', title: '季度经营分析会', meetingTime: '2026-10-28 15:00', location: 'A 栋 3 楼会议室', host: '总经理', attendees: '全体部门负责人', minutes: 'Q3 营收同比增长 12.6%，Q4 目标上调 8%', status: 'DONE' },
    ],
  },

  collabFiles: {
    collection: 'collabFiles', label: '协同文件',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('fileNo', '文件编号', 'text', 150),
      f('fileName', '文件名称', 'text', 200),
      f('projectName', '所属项目', 'text', 170),
      f('fileType', '文件类型', 'text', 120),
      f('size', '大小(KB)', 'number', 120),
      f('uploader', '上传人', 'text', 130),
      f('createdAt', '上传时间', 'datetime', 170),
      f('version', '版本', 'text', 100),
      sel('status', '状态', ON_OFF),
    ],
    statusField: 'status', statusLabels: { '1': '启用', '0': '停用' },
    seed: [
      { id: 1, fileNo: 'CF-0001', fileName: 'ERP二期需求规格说明书_v1.2.docx', projectName: 'ERP 系统二期上线', fileType: 'DOCX', size: 1860, uploader: '张伟', createdAt: '2026-11-10 11:20', version: 'v1.2', status: 1 },
      { id: 2, fileNo: 'CF-0002', fileName: '智能仓储布局图.dwg', projectName: '智能仓储改造', fileType: 'DWG', size: 8640, uploader: '王强', createdAt: '2026-11-12 15:38', version: 'v2.0', status: 1 },
      { id: 3, fileNo: 'CF-0003', fileName: '2026年度审计资料清单.xlsx', projectName: '年度审计准备', fileType: 'XLSX', size: 320, uploader: '陈会计', createdAt: '2026-11-16 09:05', version: 'v0.9', status: 1 },
    ],
  },

  collabNotices: {
    collection: 'collabNotices', label: '公告通知',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('noticeNo', '公告编号', 'text', 150),
      f('title', '公告标题', 'text', 200),
      sel('noticeType', '公告类型', opt(['SYSTEM:系统公告', 'POLICY:制度通知', 'BIZ:业务通知']), 130),
      f('content', '公告内容', 'textarea'),
      f('publisher', '发布人', 'text', 130),
      f('publishAt', '发布时间', 'datetime', 170),
      f('expireAt', '失效时间', 'datetime', 170),
      sel('status', '状态', opt(['DRAFT:草稿', 'PUBLISHED:已发布', 'EXPIRED:已失效']), 120),
    ],
    statusField: 'status', statusLabels: { DRAFT: '草稿', PUBLISHED: '已发布', EXPIRED: '已失效' },
    seed: [
      { id: 1, noticeNo: 'NT202611-001', title: '关于 ERP 系统二期上线的通知', noticeType: 'SYSTEM', content: '系统将于 12 月 1 日正式切换至二期版本，请各部门做好数据核对', publisher: '张伟', publishAt: '2026-11-16 09:00', expireAt: '2026-12-31 23:59', status: 'PUBLISHED' },
      { id: 2, noticeNo: 'NT202611-002', title: '差旅报销新标准执行通知', noticeType: 'POLICY', content: '自 11 月 20 日起执行新的差旅报销标准，详见附件', publisher: '李娜', publishAt: '2026-11-14 14:30', expireAt: '2027-06-30 23:59', status: 'PUBLISHED' },
      { id: 3, noticeNo: 'NT202611-003', title: '年终盘点工作安排', noticeType: 'BIZ', content: '定于 12 月 25 日开展全仓盘点，请仓库提前整理', publisher: '王强', publishAt: '', expireAt: '', status: 'DRAFT' },
    ],
  },

  collabProjectReports: {
    collection: 'collabProjectReports', label: '项目报表',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('reportNo', '报表编号', 'text', 150),
      f('projectName', '项目名称', 'text', 190),
      f('period', '报告期间', 'text', 110),
      f('progress', '整体进度(%)', 'number', 130),
      f('budgetUsed', '已用预算', 'money', 130),
      f('budgetTotal', '预算总额', 'money', 130),
      f('riskCount', '风险项数', 'number', 120),
      f('summary', '报告摘要', 'textarea'),
      f('createdAt', '生成时间', 'datetime', 170),
    ],
    seed: [
      { id: 1, reportNo: 'PR202611-001', projectName: 'ERP 系统二期上线', period: '2026-11', progress: 68, budgetUsed: 326000, budgetTotal: 480000, riskCount: 2, summary: '财务模块对接完成 70%，UAT 需在下周启动', createdAt: '2026-11-18 09:00' },
      { id: 2, reportNo: 'PR202611-002', projectName: '智能仓储改造', period: '2026-11', progress: 22, budgetUsed: 278000, budgetTotal: 1260000, riskCount: 3, summary: '设备延期到场，需协调供应商加快', createdAt: '2026-11-18 09:05' },
      { id: 3, reportNo: 'PR202610-003', projectName: 'ERP 系统二期上线', period: '2026-10', progress: 45, budgetUsed: 218000, budgetTotal: 480000, riskCount: 1, summary: '需求确认完成，开发进度正常', createdAt: '2026-10-31 18:00' },
    ],
  },

  collabgoals: {
    collection: 'collabgoals', label: '目标管理',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('goalNo', '目标编号', 'text', 150),
      f('name', '目标名称', 'text', 200),
      f('owner', '负责人', 'text', 130),
      f('period', '目标周期', 'text', 110),
      f('targetValue', '目标值', 'number', 130),
      f('currentValue', '当前值', 'number', 130),
      f('unit', '单位', 'text', 100),
      f('progress', '完成率(%)', 'number', 120),
      sel('status', '状态', opt(['DOING:进行中', 'DONE:已达成', 'FAIL:未达成']), 120),
    ],
    statusField: 'status', statusLabels: { DOING: '进行中', DONE: '已达成', FAIL: '未达成' },
    seed: [
      { id: 1, goalNo: 'G2026Q4-001', name: 'Q4 销售额目标', owner: '张伟', period: '2026-Q4', targetValue: 4800000, currentValue: 1450000, unit: '元', progress: 30, status: 'DOING' },
      { id: 2, goalNo: 'G2026Q4-002', name: '库存周转天数', owner: '王强', period: '2026-Q4', targetValue: 25, currentValue: 22, unit: '天', progress: 100, status: 'DONE' },
      { id: 3, goalNo: 'G2026Q4-003', name: '应收逾期率', owner: '李娜', period: '2026-Q4', targetValue: 5, currentValue: 8.6, unit: '%', progress: 58, status: 'DOING' },
    ],
  },

  collabdocuments: {
    collection: 'collabdocuments', label: '在线文档',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('docNo', '文档编号', 'text', 150),
      f('title', '文档标题', 'text', 200),
      sel('docType', '文档类型', opt(['MD:Markdown', 'DOC:文档', 'SHEET:表格', 'MIND:脑图']), 130),
      f('projectName', '所属项目', 'text', 170),
      f('author', '作者', 'text', 130),
      f('updatedAt', '更新时间', 'datetime', 170),
      f('viewCount', '浏览次数', 'number', 120),
      sel('status', '状态', opt(['DRAFT:草稿', 'PUBLISHED:已发布', 'ARCHIVED:已归档']), 120),
    ],
    statusField: 'status', statusLabels: { DRAFT: '草稿', PUBLISHED: '已发布', ARCHIVED: '已归档' },
    seed: [
      { id: 1, docNo: 'DOC-0001', title: 'ERP 二期操作手册', docType: 'MD', projectName: 'ERP 系统二期上线', author: '张伟', updatedAt: '2026-11-17 16:20', viewCount: 128, status: 'PUBLISHED' },
      { id: 2, docNo: 'DOC-0002', title: '智能仓储验收标准', docType: 'DOC', projectName: '智能仓储改造', author: '王强', updatedAt: '2026-11-15 10:40', viewCount: 46, status: 'DRAFT' },
      { id: 3, docNo: 'DOC-0003', title: '年度审计要点清单', docType: 'SHEET', projectName: '年度审计准备', author: '陈会计', updatedAt: '2026-11-16 09:12', viewCount: 22, status: 'PUBLISHED' },
    ],
  },

  collabChat: {
    collection: 'collabChat', label: '团队沟通',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('channel', '沟通频道', 'text', 160),
      f('sender', '发送人', 'text', 130),
      f('content', '消息内容', 'textarea'),
      f('createdAt', '发送时间', 'datetime', 170),
      sel('msgType', '消息类型', opt(['TEXT:文本', 'FILE:文件', 'IMAGE:图片', 'SYSTEM:系统']), 120),
      sel('status', '状态', ON_OFF),
    ],
    statusField: 'status', statusLabels: { '1': '启用', '0': '停用' },
    seed: [
      { id: 1, channel: 'ERP 二期项目组', sender: '张伟', content: '财务模块对接今天能完成吗？', createdAt: '2026-11-18 09:30', msgType: 'TEXT', status: 1 },
      { id: 2, channel: 'ERP 二期项目组', sender: '李娜', content: '凭证接口已完成，下午做联调', createdAt: '2026-11-18 09:35', msgType: 'TEXT', status: 1 },
      { id: 3, channel: '仓储改造群', sender: '王强', content: '货架到货照片已上传', createdAt: '2026-11-17 16:12', msgType: 'IMAGE', status: 1 },
    ],
  },

  collabmessages: {
    collection: 'collabmessages', label: '内部消息',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('title', '消息标题', 'text', 200),
      f('sender', '发送人', 'text', 130),
      f('receiver', '接收人', 'text', 130),
      f('content', '内容', 'textarea'),
      f('createdAt', '发送时间', 'datetime', 170),
      sel('readStatus', '已读状态', opt(['UNREAD:未读', 'READ:已读']), 120),
      sel('status', '状态', ON_OFF),
    ],
    statusField: 'readStatus', statusLabels: { UNREAD: '未读', READ: '已读' },
    seed: [
      { id: 1, title: '请补充销售单附件', sender: '李娜', receiver: '张伟', content: 'SO202611-0008 缺少合同扫描件，请上传', createdAt: '2026-11-18 10:20', readStatus: 'UNREAD', status: 1 },
      { id: 2, title: '盘点安排确认', sender: '王强', receiver: '张伟', content: '12 月 25 日盘点，请销售部提前清理待发货单据', createdAt: '2026-11-17 15:40', readStatus: 'READ', status: 1 },
      { id: 3, title: '审计资料已提交', sender: '陈会计', receiver: '李娜', content: '10 月凭证已全部装订归档', createdAt: '2026-11-16 17:05', readStatus: 'READ', status: 1 },
    ],
  },

  collabnotifications: {
    collection: 'collabnotifications', label: '协同通知',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('notifyNo', '通知编号', 'text', 150),
      f('title', '通知标题', 'text', 200),
      f('content', '通知内容', 'textarea'),
      f('receiver', '接收人', 'text', 130),
      sel('notifyType', '通知类型', opt(['TASK:任务', 'MEETING:会议', 'APPROVAL:审批', 'ANNOUNCE:公告']), 130),
      f('createdAt', '发送时间', 'datetime', 170),
      sel('readStatus', '已读状态', opt(['UNREAD:未读', 'READ:已读']), 120),
    ],
    statusField: 'readStatus', statusLabels: { UNREAD: '未读', READ: '已读' },
    seed: [
      { id: 1, notifyNo: 'CN20261118-001', title: '任务 TK-0101 即将到期', content: '财务模块凭证接口对接需在 11 月 22 日前完成', receiver: '李娜', notifyType: 'TASK', createdAt: '2026-11-18 08:00', readStatus: 'UNREAD' },
      { id: 2, notifyNo: 'CN20261118-002', title: '会议提醒：ERP 周例会', content: '11 月 19 日 10:00 在 A 栋 3 楼会议室召开', receiver: '张伟', notifyType: 'MEETING', createdAt: '2026-11-18 09:00', readStatus: 'UNREAD' },
      { id: 3, notifyNo: 'CN20261117-003', title: '新公告：差旅报销新标准', content: '自 11 月 20 日起执行新的差旅报销标准', receiver: '全体用户', notifyType: 'ANNOUNCE', createdAt: '2026-11-17 14:30', readStatus: 'READ' },
    ],
  },
};
