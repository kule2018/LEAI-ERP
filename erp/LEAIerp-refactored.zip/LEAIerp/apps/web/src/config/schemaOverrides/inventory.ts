/**
 * 库存域实体 Schema 覆盖
 * ---------------------------------------------------------------------------
 * 将占位集合替换为《ERP完整产品与技术文档》4.2/4.5 要求的多仓、批次、序列号、
 * 安全库存、盘点调整、库存追溯与周转分析的真实业务字段。
 */
import { f, sel, opt, ON_OFF, DOC_STATUS_OPT, EntitySchema } from './types';

/** 库存域覆盖集合 */
export const inventoryOverrides: Record<string, EntitySchema> = {
  inventoryWarehouses: {
    collection: 'inventoryWarehouses', label: '仓库列表',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('code', '仓库编码', 'text', 130),
      f('name', '仓库名称', 'text', 180),
      sel('type', '仓库类型', opt(['RAW:原料库', 'FINISHED:成品库', 'SEMI:半成品库', 'SPARE:备品备件库']), 130),
      f('location', '所在地点', 'text', 180),
      f('manager', '负责人', 'text', 120),
      f('area', '面积(㎡)', 'number', 110),
      sel('status', '状态', ON_OFF),
    ],
    statusField: 'status', statusLabels: { '1': '启用', '0': '停用' },
    seed: [
      { id: 1, code: 'WH-RAW', name: '原料一库', type: 'RAW', location: '深圳市宝安区工业园 A 栋', manager: '王仓管', area: 1200, status: 1 },
      { id: 2, code: 'WH-FIN', name: '成品主仓', type: 'FINISHED', location: '深圳市宝安区工业园 B 栋', manager: '刘成品', area: 2000, status: 1 },
      { id: 3, code: 'WH-SEMI', name: '半成品周转仓', type: 'SEMI', location: '深圳市宝安区工业园 C 栋', manager: '陈周转', area: 600, status: 1 },
    ],
  },

  inventoryLocations: {
    collection: 'inventoryLocations', label: '库位管理',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('code', '库位编码', 'text', 140),
      f('name', '库位名称', 'text', 160),
      f('warehouseName', '所属仓库', 'text', 150),
      f('zone', '库区', 'text', 120),
      f('shelf', '货架', 'text', 110),
      sel('type', '库位类型', opt(['STORE:存储位', 'RECV:收货位', 'SHIP:发货位']), 130),
      f('capacity', '容量', 'number', 110),
      f('occupied', '占用数量', 'number', 110),
      sel('status', '状态', ON_OFF),
    ],
    statusField: 'status', statusLabels: { '1': '启用', '0': '停用' },
    seed: [
      { id: 1, code: 'A-01-01', name: 'A区1排1位', warehouseName: '原料一库', zone: 'A区', shelf: 'A-01', type: 'STORE', capacity: 500, occupied: 320, status: 1 },
      { id: 2, code: 'A-01-02', name: 'A区1排2位', warehouseName: '原料一库', zone: 'A区', shelf: 'A-01', type: 'STORE', capacity: 500, occupied: 180, status: 1 },
      { id: 3, code: 'B-RECV-01', name: 'B区收货位', warehouseName: '成品主仓', zone: 'B区', shelf: 'RECV', type: 'RECV', capacity: 200, occupied: 45, status: 1 },
    ],
  },

  inventoryBatches: {
    collection: 'inventoryBatches', label: '批次管理',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('batchNo', '批次号', 'text', 160),
      f('productCode', '产品编码', 'text', 140),
      f('productName', '产品名称', 'text', 170),
      f('produceDate', '生产日期', 'date', 120),
      f('expireDate', '到期日期', 'date', 120),
      f('inQty', '入库数量', 'number', 110),
      f('availableQty', '可用数量', 'number', 110),
      f('unitCost', '单价', 'money', 110),
      sel('status', '批次状态', opt(['NORMAL:正常', 'FROZEN:冻结', 'EXPIRED:已过期']), 120),
    ],
    statusField: 'status', statusLabels: { NORMAL: '正常', FROZEN: '冻结', EXPIRED: '已过期' },
    seed: [
      { id: 1, batchNo: 'B20261101-001', productCode: 'P-1001', productName: 'A4 复印纸 70g', produceDate: '2026-11-01', expireDate: '2028-11-01', inQty: 500, availableQty: 320, unitCost: 18.5, status: 'NORMAL' },
      { id: 2, batchNo: 'B20261015-002', productCode: 'P-2003', productName: '不锈钢螺栓 M8', produceDate: '2026-10-15', expireDate: '2029-10-15', inQty: 2000, availableQty: 1680, unitCost: 0.85, status: 'NORMAL' },
      { id: 3, batchNo: 'B20250820-003', productCode: 'P-3007', productName: '工业润滑油 20L', produceDate: '2025-08-20', expireDate: '2026-08-20', inQty: 60, availableQty: 12, unitCost: 260, status: 'EXPIRED' },
    ],
  },

  inventorySerials: {
    collection: 'inventorySerials', label: '序列号',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('serialNo', '序列号', 'text', 170),
      f('productCode', '产品编码', 'text', 140),
      f('productName', '产品名称', 'text', 170),
      f('inDate', '入库日期', 'date', 120),
      sel('status', '状态', opt(['STOCK:在库', 'OUT:已出库', 'SOLD:已销售', 'REPAIR:返修']), 120),
      f('warehouseName', '所属仓库', 'text', 150),
      f('customerName', '客户名称', 'text', 170),
    ],
    statusField: 'status', statusLabels: { STOCK: '在库', OUT: '已出库', SOLD: '已销售', REPAIR: '返修' },
    seed: [
      { id: 1, serialNo: 'SN-LG200-202611001', productCode: 'P-9001', productName: '激光切割机 LG-200', inDate: '2026-11-05', status: 'SOLD', warehouseName: '成品主仓', customerName: '深圳市宏图科技有限公司' },
      { id: 2, serialNo: 'SN-LG200-202611002', productCode: 'P-9001', productName: '激光切割机 LG-200', inDate: '2026-11-05', status: 'STOCK', warehouseName: '成品主仓', customerName: '' },
      { id: 3, serialNo: 'SN-NW100-202610008', productCode: 'P-9002', productName: '数控折弯机 NW-100', inDate: '2026-10-18', status: 'REPAIR', warehouseName: '半成品周转仓', customerName: '佛山市机械加工厂' },
    ],
  },

  inventoryUnits: {
    collection: 'inventoryUnits', label: '计量单位',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('code', '单位编码', 'text', 120),
      f('name', '单位名称', 'text', 140),
      f('baseUnit', '基本单位', 'text', 120),
      f('rate', '换算率', 'number', 110),
      sel('category', '所属类别', opt(['LENGTH:长度', 'WEIGHT:重量', 'COUNT:数量', 'VOLUME:体积']), 120),
      sel('status', '状态', ON_OFF),
    ],
    statusField: 'status', statusLabels: { '1': '启用', '0': '停用' },
    seed: [
      { id: 1, code: 'U-PCS', name: '个', baseUnit: '个', rate: 1, category: 'COUNT', status: 1 },
      { id: 2, code: 'U-BOX', name: '箱', baseUnit: '个', rate: 24, category: 'COUNT', status: 1 },
      { id: 3, code: 'U-KG', name: '千克', baseUnit: '千克', rate: 1, category: 'WEIGHT', status: 1 },
      { id: 4, code: 'U-M', name: '米', baseUnit: '米', rate: 1, category: 'LENGTH', status: 1 },
    ],
  },

  inventoryBrands: {
    collection: 'inventoryBrands', label: '品牌管理',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('code', '品牌编码', 'text', 120),
      f('name', '品牌名称', 'text', 170),
      f('company', '所属公司', 'text', 180),
      f('origin', '产地', 'text', 140),
      sel('authLevel', '授权级别', opt(['L1:一级授权', 'L2:二级授权', 'L3:三级授权']), 130),
      sel('status', '合作状态', opt(['AUTHORIZED:已授权', 'PENDING:待审核', 'TERMINATED:已终止']), 130),
    ],
    statusField: 'status', statusLabels: { AUTHORIZED: '已授权', PENDING: '待审核', TERMINATED: '已终止' },
    seed: [
      { id: 1, code: 'BR-DELI', name: '得力', company: '得力集团有限公司', origin: '浙江宁波', authLevel: 'L1', status: 'AUTHORIZED' },
      { id: 2, code: 'BR-SKF', name: 'SKF', company: 'SKF（中国）有限公司', origin: '上海', authLevel: 'L1', status: 'AUTHORIZED' },
      { id: 3, code: 'BR-LOCAL', name: '自有品牌 LE', company: '示例科技有限公司', origin: '广东深圳', authLevel: 'L1', status: 'PENDING' },
    ],
  },

  inventoryCategories: {
    collection: 'inventoryCategories', label: '库存分类',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('code', '分类编码', 'text', 120),
      f('name', '分类名称', 'text', 170),
      f('parentName', '上级分类', 'text', 150),
      sel('categoryType', '分类类型', opt(['RAW:原材料', 'SEMI:半成品', 'FINISHED:成品', 'CONSUMABLE:低值易耗品']), 140),
      sel('status', '状态', ON_OFF),
    ],
    statusField: 'status', statusLabels: { '1': '启用', '0': '停用' },
    seed: [
      { id: 1, code: 'C-RAW-METAL', name: '金属材料', parentName: '原材料', categoryType: 'RAW', status: 1 },
      { id: 2, code: 'C-RAW-ELEC', name: '电子元件', parentName: '原材料', categoryType: 'RAW', status: 1 },
      { id: 3, code: 'C-FIN-EQUIP', name: '机械设备', parentName: '成品', categoryType: 'FINISHED', status: 1 },
    ],
  },

  inventorySafeStock: {
    collection: 'inventorySafeStock', label: '安全库存',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('productCode', '产品编码', 'text', 140),
      f('productName', '产品名称', 'text', 170),
      f('warehouseName', '仓库', 'text', 150),
      f('minQty', '安全库存下限', 'number', 130),
      f('maxQty', '安全库存上限', 'number', 130),
      f('currentQty', '当前库存', 'number', 120),
      f('alertQty', '预警值', 'number', 110),
      sel('alertMode', '预警方式', opt(['BELOW_MIN:低于下限', 'BELOW_ALERT:低于预警值']), 150),
      sel('status', '状态', ON_OFF),
    ],
    statusField: 'status', statusLabels: { '1': '启用', '0': '停用' },
    seed: [
      { id: 1, productCode: 'P-1001', productName: 'A4 复印纸 70g', warehouseName: '原料一库', minQty: 100, maxQty: 800, currentQty: 320, alertQty: 120, alertMode: 'BELOW_MIN', status: 1 },
      { id: 2, productCode: 'P-2003', productName: '不锈钢螺栓 M8', warehouseName: '原料一库', minQty: 500, maxQty: 3000, currentQty: 1680, alertQty: 600, alertMode: 'BELOW_MIN', status: 1 },
      { id: 3, productCode: 'P-9001', productName: '激光切割机 LG-200', warehouseName: '成品主仓', minQty: 2, maxQty: 15, currentQty: 1, alertQty: 3, alertMode: 'BELOW_ALERT', status: 1 },
    ],
  },

  inventoryAdjusts: {
    collection: 'inventoryAdjusts', label: '库存调整',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('adjustNo', '调整单号', 'text', 150),
      f('adjustDate', '调整日期', 'date', 120),
      f('productCode', '产品编码', 'text', 140),
      f('productName', '产品名称', 'text', 170),
      f('warehouseName', '仓库', 'text', 150),
      sel('adjustType', '调整类型', opt(['GAIN:盘盈', 'LOSS:盘亏', 'SCRAP:报损', 'OTHER:其他']), 120),
      f('beforeQty', '调整前数量', 'number', 120),
      f('changeQty', '调整数量', 'number', 110),
      f('afterQty', '调整后数量', 'number', 120),
      f('unitCost', '单位成本', 'money', 120),
      f('reason', '调整原因', 'textarea'),
      sel('status', '状态', DOC_STATUS_OPT, 110),
    ],
    statusField: 'status', statusLabels: { '0': '草稿', '1': '待审核', '2': '已确认', '3': '部分完成', '4': '已完成', '9': '已作废' },
    seed: [
      { id: 1, adjustNo: 'ADJ202611-0001', adjustDate: '2026-11-10', productCode: 'P-1001', productName: 'A4 复印纸 70g', warehouseName: '原料一库', adjustType: 'LOSS', beforeQty: 325, changeQty: -5, afterQty: 320, unitCost: 18.5, reason: '库房受潮报损', status: '4' },
      { id: 2, adjustNo: 'ADJ202611-0002', adjustDate: '2026-11-14', productCode: 'P-2003', productName: '不锈钢螺栓 M8', warehouseName: '原料一库', adjustType: 'GAIN', beforeQty: 1675, changeQty: 5, afterQty: 1680, unitCost: 0.85, reason: '盘点差异', status: '2' },
      { id: 3, adjustNo: 'ADJ202611-0003', adjustDate: '2026-11-18', productCode: 'P-3007', productName: '工业润滑油 20L', warehouseName: '原料一库', adjustType: 'SCRAP', beforeQty: 12, changeQty: 0, afterQty: 12, unitCost: 260, reason: '过期待报废，待审批', status: '0' },
    ],
  },

  inventoryAlerts: {
    collection: 'inventoryAlerts', label: '库存预警',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('alertNo', '预警编号', 'text', 150),
      f('productCode', '产品编码', 'text', 140),
      f('productName', '产品名称', 'text', 170),
      f('warehouseName', '仓库', 'text', 150),
      sel('alertType', '预警类型', opt(['BELOW_SAFE:低于安全库存', 'OVER_MAX:超上限', 'SLOW:呆滞', 'BATCH_EXPIRE:批次过期']), 150),
      f('currentQty', '当前库存', 'number', 120),
      f('safeQty', '安全库存', 'number', 120),
      f('diffQty', '差额', 'number', 110),
      sel('level', '预警级别', opt(['HIGH:高', 'MID:中', 'LOW:低']), 110),
      sel('status', '处理状态', opt(['TODO:待处理', 'DOING:处理中', 'DONE:已处理']), 120),
      f('createdAt', '触发日期', 'date', 120),
    ],
    statusField: 'status', statusLabels: { TODO: '待处理', DOING: '处理中', DONE: '已处理' },
    seed: [
      { id: 1, alertNo: 'ALT20261118-001', productCode: 'P-9001', productName: '激光切割机 LG-200', warehouseName: '成品主仓', alertType: 'BELOW_SAFE', currentQty: 1, safeQty: 3, diffQty: -2, level: 'HIGH', status: 'TODO', createdAt: '2026-11-18' },
      { id: 2, alertNo: 'ALT20261117-002', productCode: 'P-3007', productName: '工业润滑油 20L', warehouseName: '原料一库', alertType: 'BATCH_EXPIRE', currentQty: 12, safeQty: 0, diffQty: 0, level: 'MID', status: 'DOING', createdAt: '2026-11-17' },
      { id: 3, alertNo: 'ALT20261115-003', productCode: 'P-5004', productName: '包装纸箱 大号', warehouseName: '原料一库', alertType: 'SLOW', currentQty: 860, safeQty: 200, diffQty: 660, level: 'LOW', status: 'DONE', createdAt: '2026-11-15' },
    ],
  },

  inventoryTrace: {
    collection: 'inventoryTrace', label: '库存追溯',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('traceNo', '追溯单号', 'text', 150),
      f('productCode', '产品编码', 'text', 140),
      f('productName', '产品名称', 'text', 170),
      f('batchNo', '批次号', 'text', 150),
      f('sourceNo', '来源单据', 'text', 150),
      sel('sourceType', '来源类型', opt(['PURCHASE_IN:采购入库', 'SALE_OUT:销售出库', 'PRODUCTION:生产完工', 'ADJUST:库存调整']), 140),
      f('qty', '数量', 'number', 110),
      f('cost', '成本', 'money', 120),
      f('occurredAt', '发生时间', 'datetime', 160),
      f('warehouseName', '仓库', 'text', 150),
    ],
    seed: [
      { id: 1, traceNo: 'TRC-20261105-001', productCode: 'P-9001', productName: '激光切割机 LG-200', batchNo: 'B20261105-001', sourceNo: 'PR202611-0003', sourceType: 'PURCHASE_IN', qty: 2, cost: 172000, occurredAt: '2026-11-05 09:20', warehouseName: '成品主仓' },
      { id: 2, traceNo: 'TRC-20261112-002', productCode: 'P-9001', productName: '激光切割机 LG-200', batchNo: 'B20261105-001', sourceNo: 'SO202611-0007', sourceType: 'SALE_OUT', qty: -1, cost: 86000, occurredAt: '2026-11-12 14:05', warehouseName: '成品主仓' },
      { id: 3, traceNo: 'TRC-20261110-003', productCode: 'P-1001', productName: 'A4 复印纸 70g', batchNo: 'B20261101-001', sourceNo: 'ADJ202611-0001', sourceType: 'ADJUST', qty: -5, cost: 92.5, occurredAt: '2026-11-10 16:40', warehouseName: '原料一库' },
    ],
  },

  inventoryTurnover: {
    collection: 'inventoryTurnover', label: '库存周转',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('period', '统计期间', 'text', 110),
      f('warehouseName', '仓库', 'text', 150),
      f('openingQty', '期初库存数量', 'number', 140),
      f('inQty', '期间入库', 'number', 120),
      f('outQty', '期间出库', 'number', 120),
      f('closingQty', '期末库存数量', 'number', 140),
      f('turnoverTimes', '周转次数', 'number', 120),
      f('turnoverDays', '周转天数', 'number', 120),
      f('slowAmount', '呆滞金额', 'money', 130),
    ],
    seed: [
      { id: 1, period: '2026-10', warehouseName: '原料一库', openingQty: 4200, inQty: 3800, outQty: 4150, closingQty: 3850, turnoverTimes: 1.03, turnoverDays: 29, slowAmount: 18600 },
      { id: 2, period: '2026-10', warehouseName: '成品主仓', openingQty: 86, inQty: 42, outQty: 51, closingQty: 77, turnoverTimes: 0.63, turnoverDays: 48, slowAmount: 172000 },
      { id: 3, period: '2026-11', warehouseName: '原料一库', openingQty: 3850, inQty: 2100, outQty: 2480, closingQty: 3470, turnoverTimes: 0.69, turnoverDays: 22, slowAmount: 15800 },
    ],
  },

  inventoryReports: {
    collection: 'inventoryReports', label: '库存报表',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('period', '报表期间', 'text', 110),
      sel('reportType', '报表类型', opt(['BALANCE:库存余额', 'INOUT:收发存', 'AGING:库龄分析', 'SLOW:呆滞分析']), 140),
      f('warehouseName', '仓库', 'text', 150),
      f('openingAmount', '期初金额', 'money', 130),
      f('inAmount', '入库金额', 'money', 130),
      f('outAmount', '出库金额', 'money', 130),
      f('closingAmount', '期末金额', 'money', 130),
      f('createdAt', '生成时间', 'datetime', 160),
      sel('status', '状态', ON_OFF),
    ],
    statusField: 'status', statusLabels: { '1': '启用', '0': '停用' },
    seed: [
      { id: 1, period: '2026-10', reportType: 'INOUT', warehouseName: '原料一库', openingAmount: 386000, inAmount: 342000, outAmount: 373500, closingAmount: 354500, createdAt: '2026-11-01 08:30', status: 1 },
      { id: 2, period: '2026-10', reportType: 'BALANCE', warehouseName: '成品主仓', openingAmount: 1840000, inAmount: 960000, outAmount: 1120000, closingAmount: 1680000, createdAt: '2026-11-01 08:31', status: 1 },
      { id: 3, period: '2026-10', reportType: 'AGING', warehouseName: '原料一库', openingAmount: 386000, inAmount: 342000, outAmount: 373500, closingAmount: 354500, createdAt: '2026-11-01 08:32', status: 1 },
    ],
  },
};
