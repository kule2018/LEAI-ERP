/**
 * 制造、仓储执行、AI、打印、商城与 CRM 域实体 Schema 覆盖
 * ---------------------------------------------------------------------------
 * 覆盖文档 4.5 生产制造（产能/设备/工艺/工作中心）、WMS 执行（波次/上架/越库）、
 * AI 能力（规则/任务/知识库/异常扫描/科目匹配）、打印模板与设备、
 * 商城渠道与优惠券、CRM 线索。
 */
import { f, sel, opt, ON_OFF, EntitySchema } from './types';

/** 制造与仓储执行域覆盖集合 */
export const mesWmsOverrides: Record<string, EntitySchema> = {
  mesWorkCenters: {
    collection: 'mesWorkCenters', label: '工作中心',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('code', '中心编码', 'text', 130),
      f('name', '工作中心名称', 'text', 180),
      f('deptName', '所属车间', 'text', 150),
      f('capacityPerDay', '日产能', 'number', 130),
      f('efficiency', '效率(%)', 'number', 120),
      f('manager', '负责人', 'text', 130),
      sel('status', '状态', ON_OFF),
    ],
    statusField: 'status', statusLabels: { '1': '启用', '0': '停用' },
    seed: [
      { id: 1, code: 'WC-CNC', name: '数控加工中心', deptName: '机加工车间', capacityPerDay: 120, efficiency: 92, manager: '王强', status: 1 },
      { id: 2, code: 'WC-WELD', name: '焊接工作站', deptName: '焊接车间', capacityPerDay: 80, efficiency: 85, manager: '刘敏', status: 1 },
      { id: 3, code: 'WC-ASSY', name: '总装线', deptName: '装配车间', capacityPerDay: 60, efficiency: 88, manager: '赵鹏', status: 1 },
    ],
  },

  mesCapacity: {
    collection: 'mesCapacity', label: '产能管理',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('period', '计划期间', 'text', 110),
      f('workCenterName', '工作中心', 'text', 170),
      f('availableHours', '可用工时', 'number', 130),
      f('plannedHours', '计划工时', 'number', 130),
      f('loadRate', '负荷率(%)', 'number', 120),
      f('bottleneck', '是否瓶颈', 'text', 110),
      sel('status', '负荷状态', opt(['IDLE:空闲', 'NORMAL:正常', 'FULL:饱和', 'OVER:超负荷']), 120),
    ],
    statusField: 'status', statusLabels: { IDLE: '空闲', NORMAL: '正常', FULL: '饱和', OVER: '超负荷' },
    seed: [
      { id: 1, period: '2026-11', workCenterName: '数控加工中心', availableHours: 2080, plannedHours: 1920, loadRate: 92.3, bottleneck: '是', status: 'FULL' },
      { id: 2, period: '2026-11', workCenterName: '焊接工作站', availableHours: 1760, plannedHours: 1280, loadRate: 72.7, bottleneck: '否', status: 'NORMAL' },
      { id: 3, period: '2026-11', workCenterName: '总装线', availableHours: 1760, plannedHours: 1840, loadRate: 104.5, bottleneck: '是', status: 'OVER' },
    ],
  },

  mesEquipments: {
    collection: 'mesEquipments', label: '设备管理',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('equipmentNo', '设备编号', 'text', 150),
      f('name', '设备名称', 'text', 180),
      f('model', '规格型号', 'text', 170),
      f('workCenterName', '所属工作中心', 'text', 170),
      f('purchaseDate', '购入日期', 'date', 120),
      f('runHours', '累计运行(小时)', 'number', 140),
      f('nextMaintainDate', '下次保养日期', 'date', 140),
      sel('status', '状态', opt(['RUNNING:运行中', 'IDLE:待机', 'MAINTAIN:保养中', 'FAULT:故障', 'SCRAPPED:已报废']), 120),
    ],
    statusField: 'status', statusLabels: { RUNNING: '运行中', IDLE: '待机', MAINTAIN: '保养中', FAULT: '故障', SCRAPPED: '已报废' },
    seed: [
      { id: 1, equipmentNo: 'EQ-CNC-001', name: '五轴加工中心', model: 'DMU 50', workCenterName: '数控加工中心', purchaseDate: '2022-05-18', runHours: 12680, nextMaintainDate: '2026-12-01', status: 'RUNNING' },
      { id: 2, equipmentNo: 'EQ-WELD-002', name: '激光焊接机', model: 'LW-3000', workCenterName: '焊接工作站', purchaseDate: '2023-08-10', runHours: 4820, nextMaintainDate: '2026-11-25', status: 'FAULT' },
      { id: 3, equipmentNo: 'EQ-ASSY-003', name: '自动装配线', model: 'AL-200', workCenterName: '总装线', purchaseDate: '2021-11-30', runHours: 18420, nextMaintainDate: '2026-11-20', status: 'MAINTAIN' },
    ],
  },

  mesRoutings: {
    collection: 'mesRoutings', label: '工艺路线',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('routingNo', '工艺编号', 'text', 150),
      f('productName', '产品名称', 'text', 180),
      f('processName', '工序名称', 'text', 170),
      f('seqNo', '工序号', 'number', 100),
      f('workCenterName', '工作中心', 'text', 170),
      f('standardHours', '标准工时(分)', 'number', 140),
      f('setupHours', '准备工时(分)', 'number', 140),
      sel('status', '状态', ON_OFF),
    ],
    statusField: 'status', statusLabels: { '1': '启用', '0': '停用' },
    seed: [
      { id: 1, routingNo: 'RT-LG200-01', productName: '激光切割机 LG-200', processName: '下料', seqNo: 10, workCenterName: '数控加工中心', standardHours: 45, setupHours: 20, status: 1 },
      { id: 2, routingNo: 'RT-LG200-02', productName: '激光切割机 LG-200', processName: '焊接', seqNo: 20, workCenterName: '焊接工作站', standardHours: 60, setupHours: 15, status: 1 },
      { id: 3, routingNo: 'RT-LG200-03', productName: '激光切割机 LG-200', processName: '总装调试', seqNo: 30, workCenterName: '总装线', standardHours: 90, setupHours: 10, status: 1 },
    ],
  },

  mesReports: {
    collection: 'mesReports', label: '生产报表',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('period', '统计期间', 'text', 110),
      sel('reportType', '报表类型', opt(['OUTPUT:产量统计', 'EFFICIENCY:效率分析', 'QUALITY:质量分析', 'COST:成本分析']), 140),
      f('workCenterName', '工作中心', 'text', 170),
      f('planQty', '计划数量', 'number', 120),
      f('actualQty', '实际数量', 'number', 120),
      f('achieveRate', '达成率(%)', 'number', 130),
      f('defectQty', '不良数量', 'number', 120),
      f('defectRate', '不良率(%)', 'number', 120),
      f('createdAt', '生成时间', 'datetime', 170),
    ],
    seed: [
      { id: 1, period: '2026-10', reportType: 'OUTPUT', workCenterName: '数控加工中心', planQty: 2400, actualQty: 2280, achieveRate: 95, defectQty: 46, defectRate: 2.02, createdAt: '2026-11-01 07:00' },
      { id: 2, period: '2026-10', reportType: 'OUTPUT', workCenterName: '总装线', planQty: 1200, actualQty: 1140, achieveRate: 95, defectQty: 34, defectRate: 2.98, createdAt: '2026-11-01 07:05' },
      { id: 3, period: '2026-10', reportType: 'EFFICIENCY', workCenterName: '焊接工作站', planQty: 900, actualQty: 828, achieveRate: 92, defectQty: 18, defectRate: 2.17, createdAt: '2026-11-01 07:10' },
    ],
  },

  wmsWaves: {
    collection: 'wmsWaves', label: '波次管理',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('waveNo', '波次号', 'text', 150),
      f('warehouseName', '仓库', 'text', 150),
      f('orderCount', '订单数', 'number', 120),
      f('lineCount', '明细行数', 'number', 120),
      f('totalQty', '总数量', 'number', 120),
      f('createdAt', '创建时间', 'datetime', 170),
      sel('status', '状态', opt(['0:待拣货', '1:拣货中', '2:待复核', '3:已出库', '9:已取消']), 120),
    ],
    statusField: 'status', statusLabels: { '0': '待拣货', '1': '拣货中', '2': '待复核', '3': '已出库', '9': '已取消' },
    seed: [
      { id: 1, waveNo: 'WV20261118-001', warehouseName: '成品主仓', orderCount: 3, lineCount: 8, totalQty: 26, createdAt: '2026-11-18 08:30', status: 1 },
      { id: 2, waveNo: 'WV20261117-002', warehouseName: '成品主仓', orderCount: 5, lineCount: 12, totalQty: 48, createdAt: '2026-11-17 09:10', status: 3 },
      { id: 3, waveNo: 'WV20261118-003', warehouseName: '原料一库', orderCount: 2, lineCount: 4, totalQty: 320, createdAt: '2026-11-18 10:05', status: 0 },
    ],
  },

  wmsPutaways: {
    collection: 'wmsPutaways', label: '上架任务',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('putawayNo', '上架单号', 'text', 150),
      f('productCode', '产品编码', 'text', 140),
      f('productName', '产品名称', 'text', 170),
      f('warehouseName', '仓库', 'text', 150),
      f('fromLocation', '收货位', 'text', 140),
      f('toLocation', '目标库位', 'text', 140),
      f('qty', '数量', 'number', 110),
      f('operator', '作业人员', 'text', 130),
      f('createdAt', '创建时间', 'datetime', 170),
      sel('status', '状态', opt(['0:待上架', '1:上架中', '2:已完成']), 110),
    ],
    statusField: 'status', statusLabels: { '0': '待上架', '1': '上架中', '2': '已完成' },
    seed: [
      { id: 1, putawayNo: 'PA20261118-001', productCode: 'P-1001', productName: 'A4 复印纸 70g', warehouseName: '原料一库', fromLocation: 'A-RECV-01', toLocation: 'A-01-01', qty: 200, operator: '王仓管', createdAt: '2026-11-18 08:15', status: 2 },
      { id: 2, putawayNo: 'PA20261118-002', productCode: 'P-2003', productName: '不锈钢螺栓 M8', warehouseName: '原料一库', fromLocation: 'A-RECV-01', toLocation: 'A-01-02', qty: 800, operator: '王仓管', createdAt: '2026-11-18 08:40', status: 1 },
      { id: 3, putawayNo: 'PA20261118-003', productCode: 'P-9001', productName: '激光切割机 LG-200', warehouseName: '成品主仓', fromLocation: 'B-RECV-01', toLocation: 'B-02-01', qty: 1, operator: '刘成品', createdAt: '2026-11-18 09:20', status: 0 },
    ],
  },

  wmsCrossdocks: {
    collection: 'wmsCrossdocks', label: '越库作业',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('crossNo', '越库单号', 'text', 150),
      f('productCode', '产品编码', 'text', 140),
      f('productName', '产品名称', 'text', 170),
      f('inboundNo', '入库单号', 'text', 150),
      f('outboundNo', '出库单号', 'text', 150),
      f('qty', '数量', 'number', 110),
      f('dockNo', '月台号', 'text', 110),
      f('createdAt', '创建时间', 'datetime', 170),
      sel('status', '状态', opt(['0:待收货', '1:已收货', '2:已发运']), 110),
    ],
    statusField: 'status', statusLabels: { '0': '待收货', '1': '已收货', '2': '已发运' },
    seed: [
      { id: 1, crossNo: 'CD20261118-001', productCode: 'P-9001', productName: '激光切割机 LG-200', inboundNo: 'PR202611-0008', outboundNo: 'SO202611-0012', qty: 1, dockNo: 'D-01', createdAt: '2026-11-18 07:50', status: 1 },
      { id: 2, crossNo: 'CD20261118-002', productCode: 'P-2003', productName: '不锈钢螺栓 M8', inboundNo: 'PR202611-0009', outboundNo: 'SO202611-0013', qty: 500, dockNo: 'D-02', createdAt: '2026-11-18 08:10', status: 0 },
      { id: 3, crossNo: 'CD20261117-003', productCode: 'P-1001', productName: 'A4 复印纸 70g', inboundNo: 'PR202611-0007', outboundNo: 'SO202611-0011', qty: 120, dockNo: 'D-01', createdAt: '2026-11-17 15:30', status: 2 },
    ],
  },
};

/** AI 能力域覆盖集合 */
export const aiOverrides: Record<string, EntitySchema> = {
  aiRules: {
    collection: 'aiRules', label: 'AI 规则',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('code', '规则编码', 'text', 140),
      f('name', '规则名称', 'text', 180),
      sel('scene', '适用场景', opt(['PREDICT:需求预测', 'ALERT:异常预警', 'REORDER:补货建议', 'SUBJECT:科目匹配', 'RISK:风险识别']), 140),
      f('condition', '触发条件', 'text', 220),
      f('action', '执行动作', 'text', 200),
      f('priority', '优先级', 'number', 110),
      sel('status', '状态', ON_OFF),
    ],
    statusField: 'status', statusLabels: { '1': '启用', '0': '停用' },
    seed: [
      { id: 1, code: 'AIR-001', name: '库存低于安全值时建议补货', scene: 'REORDER', condition: '可用库存 < 安全库存', action: '生成采购建议单', priority: 1, status: 1 },
      { id: 2, code: 'AIR-002', name: '应收逾期超 60 天风险预警', scene: 'RISK', condition: '账龄 > 60 天', action: '推送风险提醒给销售总监', priority: 1, status: 1 },
      { id: 3, code: 'AIR-003', name: '费用类凭证自动匹配科目', scene: 'SUBJECT', condition: '摘要含「差旅/招待/办公」', action: '匹配管理费用/销售费用科目', priority: 2, status: 1 },
    ],
  },

  aiTasks: {
    collection: 'aiTasks', label: 'AI 任务',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('taskNo', '任务编号', 'text', 150),
      f('name', '任务名称', 'text', 190),
      sel('taskType', '任务类型', opt(['FORECAST:需求预测', 'SCAN:异常扫描', 'INSIGHT:报表洞察', 'MATCH:科目匹配', 'RAG:知识检索']), 140),
      f('target', '执行对象', 'text', 180),
      f('createdAt', '创建时间', 'datetime', 170),
      f('finishedAt', '完成时间', 'datetime', 170),
      sel('status', '状态', opt(['PENDING:待执行', 'RUNNING:执行中', 'DONE:已完成', 'FAIL:失败']), 120),
    ],
    statusField: 'status', statusLabels: { PENDING: '待执行', RUNNING: '执行中', DONE: '已完成', FAIL: '失败' },
    seed: [
      { id: 1, taskNo: 'AIT20261118-001', name: '下月成品需求预测', taskType: 'FORECAST', target: '激光切割机 LG-200', createdAt: '2026-11-18 06:00', finishedAt: '2026-11-18 06:02', status: 'DONE' },
      { id: 2, taskNo: 'AIT20261118-002', name: '全量凭证异常扫描', taskType: 'SCAN', target: '2026-11 会计期间', createdAt: '2026-11-18 07:00', finishedAt: '', status: 'RUNNING' },
      { id: 3, taskNo: 'AIT20261117-003', name: '10 月经营报表洞察', taskType: 'INSIGHT', target: '2026-10 利润表', createdAt: '2026-11-17 18:00', finishedAt: '2026-11-17 18:01', status: 'DONE' },
    ],
  },

  aiAnomalyScan: {
    collection: 'aiAnomalyScan', label: '异常扫描',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('scanNo', '扫描编号', 'text', 150),
      f('bizType', '业务类型', 'text', 140),
      f('bizNo', '业务单号', 'text', 150),
      sel('anomalyType', '异常类型', opt(['AMOUNT:金额异常', 'QTY:数量异常', 'PRICE:单价异常', 'FREQ:频次异常', 'RELATION:关联异常']), 140),
      f('description', '异常描述', 'textarea'),
      f('riskLevel', '风险等级', 'text', 110),
      f('suggestion', '处理建议', 'textarea'),
      sel('status', '状态', opt(['TODO:待处理', 'IGNORED:已忽略', 'DONE:已处理']), 120),
    ],
    statusField: 'status', statusLabels: { TODO: '待处理', IGNORED: '已忽略', DONE: '已处理' },
    seed: [
      { id: 1, scanNo: 'SC20261118-001', bizType: '销售单', bizNo: 'SO202611-0012', anomalyType: 'PRICE', description: '单价 86000，低于近 3 月均价 92000 约 6.5%', riskLevel: '中', suggestion: '确认是否审批特价，建议补充特价审批单', status: 'TODO' },
      { id: 2, scanNo: 'SC20261118-002', bizType: '采购单', bizNo: 'PO202611-0009', anomalyType: 'AMOUNT', description: '单笔采购 68 万，超过历史 95 分位（42 万）', riskLevel: '高', suggestion: '建议核对供应商资质与比价记录', status: 'TODO' },
      { id: 3, scanNo: 'SC20261117-003', bizType: '凭证', bizNo: 'V20261117-0022', anomalyType: 'RELATION', description: '同一供应商当月付款 3 次，金额接近拆分阈值', riskLevel: '中', suggestion: '核查是否存在规避审批的拆分付款', status: 'DONE' },
    ],
  },

  aiReportInsight: {
    collection: 'aiReportInsight', label: '报表洞察',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('insightNo', '洞察编号', 'text', 150),
      f('reportName', '报表名称', 'text', 180),
      f('period', '期间', 'text', 110),
      f('insightText', '洞察结论', 'textarea'),
      f('metricName', '关键指标', 'text', 150),
      f('metricValue', '指标值', 'text', 120),
      f('changeRate', '变化率(%)', 'number', 130),
      f('createdAt', '生成时间', 'datetime', 170),
      sel('status', '状态', ON_OFF),
    ],
    statusField: 'status', statusLabels: { '1': '启用', '0': '停用' },
    seed: [
      { id: 1, insightNo: 'INS202610-001', reportName: '利润表', period: '2026-10', insightText: '营业收入环比增长 8.2%，但毛利率下降 1.6 个百分点，主因原材料成本上涨', metricName: '毛利率', metricValue: '32.4%', changeRate: -1.6, createdAt: '2026-11-01 08:00', status: 1 },
      { id: 2, insightNo: 'INS202610-002', reportName: '库存报表', period: '2026-10', insightText: '成品仓周转天数由 42 天升至 48 天，呆滞金额增加 12 万', metricName: '周转天数', metricValue: '48天', changeRate: 14.3, createdAt: '2026-11-01 08:05', status: 1 },
      { id: 3, insightNo: 'INS202610-003', reportName: '应收账龄', period: '2026-10', insightText: '30-60 天账龄占比上升至 18%，建议加强催收', metricName: '逾期率', metricValue: '8.6%', changeRate: 2.1, createdAt: '2026-11-01 08:10', status: 1 },
    ],
  },

  aiRagDocs: {
    collection: 'aiRagDocs', label: '知识库文档',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('docNo', '文档编号', 'text', 150),
      f('title', '文档标题', 'text', 200),
      sel('docType', '文档类型', opt(['POLICY:制度', 'MANUAL:操作手册', 'CONTRACT:合同范本', 'FAQ:常见问题']), 130),
      f('chunkCount', '切片数量', 'number', 130),
      f('embeddingModel', '向量模型', 'text', 160),
      f('uploader', '上传人', 'text', 130),
      f('createdAt', '入库时间', 'datetime', 170),
      sel('status', '状态', opt(['PENDING:待索引', 'INDEXED:已索引', 'FAIL:失败']), 120),
    ],
    statusField: 'status', statusLabels: { PENDING: '待索引', INDEXED: '已索引', FAIL: '失败' },
    seed: [
      { id: 1, docNo: 'RAG-0001', title: '差旅费报销管理制度', docType: 'POLICY', chunkCount: 24, embeddingModel: 'text-embedding-3-small', uploader: '李娜', createdAt: '2026-11-10 10:00', status: 'INDEXED' },
      { id: 2, docNo: 'RAG-0002', title: '销售出库操作手册', docType: 'MANUAL', chunkCount: 38, embeddingModel: 'text-embedding-3-small', uploader: '张伟', createdAt: '2026-11-12 14:20', status: 'INDEXED' },
      { id: 3, docNo: 'RAG-0003', title: '采购合同标准范本 2026', docType: 'CONTRACT', chunkCount: 0, embeddingModel: 'text-embedding-3-small', uploader: '李采购', createdAt: '2026-11-17 16:40', status: 'PENDING' },
    ],
  },

  aiSubjectMatch: {
    collection: 'aiSubjectMatch', label: '科目匹配',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('keyword', '摘要关键词', 'text', 180),
      f('matchedSubject', '匹配科目', 'text', 170),
      f('subjectCode', '科目编码', 'text', 120),
      f('confidence', '置信度(%)', 'number', 120),
      f('hitCount', '命中次数', 'number', 120),
      sel('status', '状态', ON_OFF),
    ],
    statusField: 'status', statusLabels: { '1': '启用', '0': '停用' },
    seed: [
      { id: 1, keyword: '差旅费/住宿/机票', matchedSubject: '销售费用', subjectCode: '6601', confidence: 96, hitCount: 128, status: 1 },
      { id: 2, keyword: '办公用品/打印纸', matchedSubject: '管理费用', subjectCode: '6602', confidence: 94, hitCount: 86, status: 1 },
      { id: 3, keyword: '设备维修/保养', matchedSubject: '制造费用', subjectCode: '5101', confidence: 91, hitCount: 42, status: 1 },
    ],
  },

  aiCs: {
    collection: 'aiCs', label: '智能客服',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('sessionNo', '会话编号', 'text', 150),
      f('customerName', '客户名称', 'text', 170),
      f('question', '咨询问题', 'textarea'),
      f('answer', 'AI 回复', 'textarea'),
      f('satisfaction', '满意度', 'number', 110),
      f('createdAt', '会话时间', 'datetime', 170),
      sel('status', '状态', opt(['OPEN:进行中', 'CLOSED:已结束', 'TRANSFER:已转人工']), 120),
    ],
    statusField: 'status', statusLabels: { OPEN: '进行中', CLOSED: '已结束', TRANSFER: '已转人工' },
    seed: [
      { id: 1, sessionNo: 'CS20261118-001', customerName: '深圳市宏图科技有限公司', question: 'LG-200 的交期是多久？', answer: '标准交期为下单后 25 个工作日，当前库存 1 台可即时发货。', satisfaction: 5, createdAt: '2026-11-18 09:20', status: 'CLOSED' },
      { id: 2, sessionNo: 'CS20261118-002', customerName: '东莞市精密制造有限公司', question: '能否开具增值税专用发票？', answer: '可以，请提供开票资料，我们将在收款后 3 个工作日内开具。', satisfaction: 4, createdAt: '2026-11-18 10:05', status: 'CLOSED' },
      { id: 3, sessionNo: 'CS20261118-003', customerName: '佛山市机械加工厂', question: '设备出现报警代码 E021 怎么处理？', answer: '该代码表示液压压力异常，建议检查液压油位。是否需要转接技术工程师？', satisfaction: 0, createdAt: '2026-11-18 11:12', status: 'TRANSFER' },
    ],
  },
};

/** 打印、商城与 CRM 域覆盖集合 */
export const printShopCrmOverrides: Record<string, EntitySchema> = {
  printJobs: {
    collection: 'printJobs', label: '打印任务',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('jobNo', '任务编号', 'text', 150),
      f('templateName', '打印模板', 'text', 180),
      f('bizType', '单据类型', 'text', 140),
      f('bizNo', '单据号', 'text', 150),
      f('copies', '份数', 'number', 100),
      sel('channel', '打印通道', opt(['SERVER_PDF:服务端PDF', 'CLIENT:客户端打印', 'SILENT:静默打印']), 140),
      f('submittedBy', '提交人', 'text', 130),
      f('createdAt', '提交时间', 'datetime', 170),
      sel('status', '状态', opt(['0:排队中', '1:打印中', '2:已完成', '9:失败']), 110),
    ],
    statusField: 'status', statusLabels: { '0': '排队中', '1': '打印中', '2': '已完成', '9': '失败' },
    seed: [
      { id: 1, jobNo: 'PJ20261118-001', templateName: '销售出库单 A4', bizType: '销售单', bizNo: 'SO202611-0012', copies: 2, channel: 'SERVER_PDF', submittedBy: '张销售', createdAt: '2026-11-18 09:30', status: 2 },
      { id: 2, jobNo: 'PJ20261118-002', templateName: '采购入库单', bizType: '采购单', bizNo: 'PO202611-0009', copies: 1, channel: 'SILENT', submittedBy: '李采购', createdAt: '2026-11-18 10:15', status: 1 },
      { id: 3, jobNo: 'PJ20261118-003', templateName: '库存调整单', bizType: '调整单', bizNo: 'ADJ202611-0001', copies: 1, channel: 'CLIENT', submittedBy: '王仓管', createdAt: '2026-11-18 11:00', status: 9 },
    ],
  },

  printLabels: {
    collection: 'printLabels', label: '标签模板',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('code', '标签编码', 'text', 140),
      f('name', '标签名称', 'text', 180),
      f('size', '标签尺寸', 'text', 150),
      f('fields', '绑定字段', 'textarea'),
      f('printer', '默认打印机', 'text', 170),
      sel('status', '状态', ON_OFF),
    ],
    statusField: 'status', statusLabels: { '1': '启用', '0': '停用' },
    seed: [
      { id: 1, code: 'LBL-PROD', name: '产品条码标签', size: '60×40mm', fields: 'productName,productCode,barcode,price', printer: 'Zebra ZD421', status: 1 },
      { id: 2, code: 'LBL-BOX', name: '外箱标签', size: '100×80mm', fields: 'orderNo,customerName,qty,boxNo', printer: 'Zebra ZT411', status: 1 },
      { id: 3, code: 'LBL-SHELF', name: '库位标签', size: '50×30mm', fields: 'locationCode,warehouseName,barcode', printer: 'Zebra ZD421', status: 1 },
    ],
  },

  printBarcodes: {
    collection: 'printBarcodes', label: '条码规则',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('code', '规则编码', 'text', 140),
      f('name', '规则名称', 'text', 180),
      sel('barcodeType', '条码类型', opt(['CODE128:Code128', 'EAN13:EAN-13', 'QR:二维码', 'CODE39:Code39']), 140),
      f('prefix', '前缀', 'text', 110),
      f('content', '编码内容', 'textarea'),
      f('length', '长度', 'number', 100),
      sel('status', '状态', ON_OFF),
    ],
    statusField: 'status', statusLabels: { '1': '启用', '0': '停用' },
    seed: [
      { id: 1, code: 'BC-PROD', name: '产品条码', barcodeType: 'CODE128', prefix: 'P-', content: '产品编码', length: 12, status: 1 },
      { id: 2, code: 'BC-BATCH', name: '批次二维码', barcodeType: 'QR', prefix: 'B', content: '批次号+产品编码+生产日期', length: 0, status: 1 },
      { id: 3, code: 'BC-SHELF', name: '库位条码', barcodeType: 'CODE39', prefix: 'L-', content: '库位编码', length: 8, status: 1 },
    ],
  },

  printFonts: {
    collection: 'printFonts', label: '打印字体',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('code', '字体编码', 'text', 140),
      f('name', '字体名称', 'text', 170),
      f('fontFamily', '字体族', 'text', 170),
      f('fontSize', '默认字号', 'number', 120),
      f('filePath', '字体文件', 'text', 200),
      sel('status', '状态', ON_OFF),
    ],
    statusField: 'status', statusLabels: { '1': '启用', '0': '停用' },
    seed: [
      { id: 1, code: 'FT-SONG', name: '宋体（标题）', fontFamily: 'SimSun', fontSize: 16, filePath: '/fonts/simsun.ttf', status: 1 },
      { id: 2, code: 'FT-HEI', name: '黑体（表头）', fontFamily: 'SimHei', fontSize: 12, filePath: '/fonts/simhei.ttf', status: 1 },
      { id: 3, code: 'FT-MONO', name: '等宽（数值）', fontFamily: 'Consolas', fontSize: 11, filePath: '/fonts/consola.ttf', status: 1 },
    ],
  },

  shopStores: {
    collection: 'shopStores', label: '店铺管理',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('name', '店铺名称', 'text', 180),
      sel('platform', '所属平台', opt(['SELF:自营商城', 'TAOBAO:淘宝', 'JD:京东', 'DOUYIN:抖音', 'PDD:拼多多']), 140),
      f('sellerId', '店铺ID', 'text', 170),
      f('owner', '负责人', 'text', 130),
      f('orderCount', '累计订单', 'number', 130),
      f('createdAt', '开通时间', 'datetime', 170),
      sel('status', '状态', opt(['AUTHORIZED:已授权', 'EXPIRED:授权过期', 'CLOSED:已关闭']), 130),
    ],
    statusField: 'status', statusLabels: { AUTHORIZED: '已授权', EXPIRED: '授权过期', CLOSED: '已关闭' },
    seed: [
      { id: 1, name: 'LE 自营旗舰店', platform: 'SELF', sellerId: 'SELF-0001', owner: '张伟', orderCount: 1286, createdAt: '2025-03-01 10:00', status: 'AUTHORIZED' },
      { id: 2, name: 'LE 工业品淘宝店', platform: 'TAOBAO', sellerId: 'TB-88213344', owner: '刘敏', orderCount: 486, createdAt: '2025-08-15 14:20', status: 'AUTHORIZED' },
      { id: 3, name: 'LE 京东自营店', platform: 'JD', sellerId: 'JD-55667788', owner: '赵鹏', orderCount: 220, createdAt: '2026-01-10 09:30', status: 'EXPIRED' },
    ],
  },

  shopChannels: {
    collection: 'shopChannels', label: '销售渠道',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('code', '渠道编码', 'text', 140),
      f('name', '渠道名称', 'text', 170),
      f('storeName', '关联店铺', 'text', 170),
      f('commissionRate', '佣金比例(%)', 'number', 130),
      f('settleCycle', '结算周期', 'text', 130),
      sel('status', '状态', ON_OFF),
    ],
    statusField: 'status', statusLabels: { '1': '启用', '0': '停用' },
    seed: [
      { id: 1, code: 'CH-SELF', name: '自营商城', storeName: 'LE 自营旗舰店', commissionRate: 0, settleCycle: 'T+1', status: 1 },
      { id: 2, code: 'CH-TB', name: '淘宝渠道', storeName: 'LE 工业品淘宝店', commissionRate: 5, settleCycle: 'T+7', status: 1 },
      { id: 3, code: 'CH-JD', name: '京东渠道', storeName: 'LE 京东自营店', commissionRate: 8, settleCycle: 'T+15', status: 1 },
    ],
  },

  shopCoupons: {
    collection: 'shopCoupons', label: '优惠券',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('code', '券码', 'text', 150),
      f('name', '优惠券名称', 'text', 180),
      sel('couponType', '券类型', opt(['DISCOUNT:折扣券', 'CASH:满减券', 'GIFT:赠品券']), 130),
      f('threshold', '使用门槛', 'money', 130),
      f('faceValue', '面值/折扣', 'money', 130),
      f('totalQty', '发行数量', 'number', 120),
      f('usedQty', '已使用', 'number', 110),
      f('startDate', '开始日期', 'date', 120),
      f('endDate', '结束日期', 'date', 120),
      sel('status', '状态', opt(['ACTIVE:进行中', 'PAUSED:已暂停', 'ENDED:已结束']), 120),
    ],
    statusField: 'status', statusLabels: { ACTIVE: '进行中', PAUSED: '已暂停', ENDED: '已结束' },
    seed: [
      { id: 1, code: 'CP2026NOV01', name: '双十一满减券', couponType: 'CASH', threshold: 1000, faceValue: 100, totalQty: 500, usedQty: 286, startDate: '2026-11-01', endDate: '2026-11-15', status: 'ENDED' },
      { id: 2, code: 'CP2026NOV02', name: '新客首单 95 折', couponType: 'DISCOUNT', threshold: 0, faceValue: 95, totalQty: 1000, usedQty: 412, startDate: '2026-11-01', endDate: '2026-12-31', status: 'ACTIVE' },
      { id: 3, code: 'CP2026DEC01', name: '年终大促满 5000 减 800', couponType: 'CASH', threshold: 5000, faceValue: 800, totalQty: 200, usedQty: 0, startDate: '2026-12-01', endDate: '2026-12-31', status: 'PAUSED' },
    ],
  },

  shopGoodsMaps: {
    collection: 'shopGoodsMaps', label: '商品映射',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('platformSku', '平台SKU', 'text', 170),
      f('platformGoodsName', '平台商品名', 'text', 200),
      f('productCode', '内部产品编码', 'text', 150),
      f('productName', '内部产品名', 'text', 180),
      f('storeName', '所属店铺', 'text', 170),
      f('priceDiff', '价格差', 'money', 120),
      sel('status', '状态', ON_OFF),
    ],
    statusField: 'status', statusLabels: { '1': '启用', '0': '停用' },
    seed: [
      { id: 1, platformSku: 'SKU-LG200-TB', platformGoodsName: 'LE 激光切割机 LG-200 工业级', productCode: 'P-9001', productName: '激光切割机 LG-200', storeName: 'LE 工业品淘宝店', priceDiff: 2000, status: 1 },
      { id: 2, platformSku: 'SKU-NW100-TB', platformGoodsName: 'LE 数控折弯机 NW-100', productCode: 'P-9002', productName: '数控折弯机 NW-100', storeName: 'LE 工业品淘宝店', priceDiff: 0, status: 1 },
      { id: 3, platformSku: 'SKU-A4-JD', platformGoodsName: 'A4 复印纸 70g 整箱', productCode: 'P-1001', productName: 'A4 复印纸 70g', storeName: 'LE 京东自营店', priceDiff: -8, status: 1 },
    ],
  },

  crmLeads: {
    collection: 'crmLeads', label: '销售线索',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('name', '线索名称', 'text', 180),
      f('company', '公司名称', 'text', 190),
      f('contact', '联系人', 'text', 130),
      f('phone', '联系电话', 'text', 140),
      sel('source', '线索来源', opt(['WEB:官网', 'EXPO:展会', 'REFERRAL:转介绍', 'CALL:电话营销', 'AD:广告']), 130),
      f('owner', '负责人', 'text', 130),
      f('expectAmount', '预计金额', 'money', 130),
      sel('status', '状态', opt(['NEW:新线索', 'FOLLOW:跟进中', 'CONVERTED:已转化', 'LOST:已流失']), 120),
    ],
    statusField: 'status', statusLabels: { NEW: '新线索', FOLLOW: '跟进中', CONVERTED: '已转化', LOST: '已流失' },
    seed: [
      { id: 1, name: '宏图科技激光设备采购', company: '深圳市宏图科技有限公司', contact: '黄经理', phone: '13900001111', source: 'EXPO', owner: '张伟', expectAmount: 380000, status: 'CONVERTED' },
      { id: 2, name: '精密制造折弯机需求', company: '东莞市精密制造有限公司', contact: '周厂长', phone: '13900002222', source: 'WEB', owner: '张伟', expectAmount: 168000, status: 'FOLLOW' },
      { id: 3, name: '机械加工厂设备升级', company: '佛山市机械加工厂', contact: '梁总', phone: '13900003333', source: 'REFERRAL', owner: '刘敏', expectAmount: 520000, status: 'NEW' },
    ],
  },
};
