/**
 * 系统管理域实体 Schema 覆盖
 * ---------------------------------------------------------------------------
 * 将占位集合替换为真实的用户/角色/权限/组织/字典/参数、日志审计、事件通知、
 * 定时任务、备份、编号规则等平台底座字段（文档第 5 章平台能力）。
 */
import { f, sel, opt, ON_OFF, EntitySchema } from './types';

/** 系统域覆盖集合 */
export const systemOverrides: Record<string, EntitySchema> = {
  sysusers: {
    collection: 'sysusers', label: '用户管理',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('username', '用户名', 'text', 140),
      f('realName', '姓名', 'text', 130),
      f('deptName', '部门', 'text', 150),
      f('roleName', '角色', 'text', 150),
      f('phone', '手机号', 'text', 140),
      f('email', '邮箱', 'text', 190),
      f('lastLoginAt', '最后登录时间', 'datetime', 170),
      sel('status', '状态', ON_OFF),
    ],
    statusField: 'status', statusLabels: { '1': '启用', '0': '停用' },
    seed: [
      { id: 1, username: 'admin', realName: '系统管理员', deptName: '信息部', roleName: '超级管理员', phone: '13800001111', email: 'admin@example.com', lastLoginAt: '2026-11-18 09:12', status: 1 },
      { id: 2, username: 'zhangsales', realName: '张销售', deptName: '销售部', roleName: '销售主管', phone: '13800002222', email: 'zhang@example.com', lastLoginAt: '2026-11-18 08:40', status: 1 },
      { id: 3, username: 'licaiwu', realName: '陈会计', deptName: '财务部', roleName: '财务会计', phone: '13800003333', email: 'chen@example.com', lastLoginAt: '2026-11-17 17:26', status: 1 },
    ],
  },

  sysroles: {
    collection: 'sysroles', label: '角色管理',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('code', '角色编码', 'text', 130),
      f('name', '角色名称', 'text', 160),
      sel('dataScope', '数据范围', opt(['ALL:全部', 'DEPT:本部门', 'DEPT_SUB:本部门及以下', 'SELF:仅本人']), 150),
      f('description', '描述', 'textarea'),
      f('memberCount', '成员数', 'number', 110),
      sel('status', '状态', ON_OFF),
    ],
    statusField: 'status', statusLabels: { '1': '启用', '0': '停用' },
    seed: [
      { id: 1, code: 'ROLE_ADMIN', name: '超级管理员', dataScope: 'ALL', description: '拥有全部权限', memberCount: 1, status: 1 },
      { id: 2, code: 'ROLE_SALES', name: '销售主管', dataScope: 'DEPT_SUB', description: '销售业务与报表', memberCount: 6, status: 1 },
      { id: 3, code: 'ROLE_FIN', name: '财务会计', dataScope: 'DEPT', description: '凭证、应收应付、报表', memberCount: 3, status: 1 },
      { id: 4, code: 'ROLE_WH', name: '仓管员', dataScope: 'SELF', description: '出入库与盘点', memberCount: 4, status: 1 },
    ],
  },

  syspermissions: {
    collection: 'syspermissions', label: '权限管理',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('code', '权限编码', 'text', 180),
      f('name', '权限名称', 'text', 170),
      f('module', '所属模块', 'text', 140),
      sel('permType', '权限类型', opt(['MENU:菜单', 'BUTTON:按钮', 'API:接口', 'DATA:数据']), 130),
      f('parentCode', '上级权限', 'text', 160),
      sel('status', '状态', ON_OFF),
    ],
    statusField: 'status', statusLabels: { '1': '启用', '0': '停用' },
    seed: [
      { id: 1, code: 'sales:*', name: '销售全部权限', module: '销售管理', permType: 'MENU', parentCode: '', status: 1 },
      { id: 2, code: 'sales:order:create', name: '新建销售单', module: '销售管理', permType: 'BUTTON', parentCode: 'sales:*', status: 1 },
      { id: 3, code: 'finance:voucher:post', name: '凭证过账', module: '财务管理', permType: 'BUTTON', parentCode: 'finance:*', status: 1 },
      { id: 4, code: 'inventory:balance:view', name: '查看库存余额', module: '库存管理', permType: 'DATA', parentCode: 'inventory:*', status: 1 },
    ],
  },

  systemRoles: {
    collection: 'systemRoles', label: '角色管理',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('code', '角色编码', 'text', 130),
      f('name', '角色名称', 'text', 160),
      sel('dataScope', '数据范围', opt(['ALL:全部', 'DEPT:本部门', 'DEPT_SUB:本部门及以下', 'SELF:仅本人']), 150),
      f('userCount', '用户数', 'number', 110),
      f('description', '描述', 'textarea'),
      sel('status', '状态', ON_OFF),
    ],
    statusField: 'status', statusLabels: { '1': '启用', '0': '停用' },
    seed: [
      { id: 1, code: 'ROLE_PURCHASE', name: '采购主管', dataScope: 'DEPT_SUB', userCount: 4, description: '采购订单与供应商管理', status: 1 },
      { id: 2, code: 'ROLE_HR', name: '人事专员', dataScope: 'ALL', userCount: 2, description: '员工、考勤、薪资', status: 1 },
      { id: 3, code: 'ROLE_VIEWER', name: '只读查看', dataScope: 'ALL', userCount: 5, description: '仅查看无编辑权限', status: 1 },
    ],
  },

  systemPermissions: {
    collection: 'systemPermissions', label: '权限管理',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('code', '权限编码', 'text', 180),
      f('name', '权限名称', 'text', 170),
      sel('permType', '权限类型', opt(['MENU:菜单', 'ACTION:操作', 'DATA:数据']), 130),
      f('resource', '资源路径', 'text', 180),
      f('module', '所属模块', 'text', 140),
      sel('status', '状态', ON_OFF),
    ],
    statusField: 'status', statusLabels: { '1': '启用', '0': '停用' },
    seed: [
      { id: 1, code: 'purchase:*', name: '采购全部权限', permType: 'MENU', resource: '/purchase/**', module: '采购管理', status: 1 },
      { id: 2, code: 'purchase:order:approve', name: '采购单审批', permType: 'ACTION', resource: '/api/v1/purchase/orders/:id/approve', module: '采购管理', status: 1 },
      { id: 3, code: 'report:sales:all', name: '全公司销售报表', permType: 'DATA', resource: '/api/v1/reports/sales', module: '报表中心', status: 1 },
    ],
  },

  systemDataScopes: {
    collection: 'systemDataScopes', label: '数据权限',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('code', '范围编码', 'text', 140),
      f('name', '范围名称', 'text', 170),
      f('roleName', '适用角色', 'text', 150),
      sel('scopeType', '数据范围', opt(['ALL:全部', 'DEPT:本部门', 'DEPT_SUB:本部门及以下', 'SELF:仅本人', 'CUSTOM:自定义']), 150),
      f('visibleOrgs', '可见组织', 'textarea'),
      sel('status', '状态', ON_OFF),
    ],
    statusField: 'status', statusLabels: { '1': '启用', '0': '停用' },
    seed: [
      { id: 1, code: 'DS-SALES-SUB', name: '销售部及下属可见', roleName: '销售主管', scopeType: 'DEPT_SUB', visibleOrgs: '销售部、华南大区、华北大区', status: 1 },
      { id: 2, code: 'DS-FIN-DEPT', name: '财务部可见', roleName: '财务会计', scopeType: 'DEPT', visibleOrgs: '财务部', status: 1 },
      { id: 3, code: 'DS-ALL', name: '全公司可见', roleName: '超级管理员', scopeType: 'ALL', visibleOrgs: '全部组织', status: 1 },
    ],
  },

  sysdepartments: {
    collection: 'sysdepartments', label: '部门管理',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('code', '部门编码', 'text', 130),
      f('name', '部门名称', 'text', 170),
      f('parentName', '上级部门', 'text', 150),
      f('manager', '负责人', 'text', 130),
      sel('deptType', '部门类型', opt(['COMPANY:公司', 'BU:事业部', 'DEPT:部门', 'TEAM:班组']), 130),
      f('sortNo', '排序', 'number', 100),
      sel('status', '状态', ON_OFF),
    ],
    statusField: 'status', statusLabels: { '1': '启用', '0': '停用' },
    seed: [
      { id: 1, code: 'D001', name: '总经办', parentName: '', manager: '总经理', deptType: 'COMPANY', sortNo: 1, status: 1 },
      { id: 2, code: 'D010', name: '销售部', parentName: '总经办', manager: '张销售', deptType: 'DEPT', sortNo: 10, status: 1 },
      { id: 3, code: 'D020', name: '财务部', parentName: '总经办', manager: '陈会计', deptType: 'DEPT', sortNo: 20, status: 1 },
      { id: 4, code: 'D030', name: '生产部', parentName: '总经办', manager: '李生产', deptType: 'DEPT', sortNo: 30, status: 1 },
    ],
  },

  systemOrgs: {
    collection: 'systemOrgs', label: '组织架构',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('code', '组织编码', 'text', 130),
      f('name', '组织名称', 'text', 180),
      sel('orgType', '组织类型', opt(['GROUP:集团', 'COMPANY:公司', 'DEPT:部门', 'FACTORY:工厂', 'STORE:门店']), 130),
      f('parentName', '上级组织', 'text', 160),
      f('manager', '负责人', 'text', 130),
      f('foundDate', '成立日期', 'date', 120),
      sel('status', '状态', ON_OFF),
    ],
    statusField: 'status', statusLabels: { '1': '启用', '0': '停用' },
    seed: [
      { id: 1, code: 'ORG-GROUP', name: '示例科技集团', orgType: 'GROUP', parentName: '', manager: '董事长', foundDate: '2015-05-08', status: 1 },
      { id: 2, code: 'ORG-SZ', name: '深圳市示例科技有限公司', orgType: 'COMPANY', parentName: '示例科技集团', manager: '总经理', foundDate: '2016-03-12', status: 1 },
      { id: 3, code: 'ORG-FAC', name: '宝安制造工厂', orgType: 'FACTORY', parentName: '深圳市示例科技有限公司', manager: '李生产', foundDate: '2018-09-01', status: 1 },
      { id: 4, code: 'DEPT-HR', name: '人力资源部', orgType: 'DEPT', parentName: '深圳市示例科技有限公司', manager: '陈人事', foundDate: '2017-04-10', status: 1 },
      { id: 5, code: 'DEPT-FIN', name: '财务部', orgType: 'DEPT', parentName: '深圳市示例科技有限公司', manager: '李娜', foundDate: '2017-04-12', status: 1 },
      { id: 6, code: 'DEPT-SALES', name: '销售部', orgType: 'DEPT', parentName: '深圳市示例科技有限公司', manager: '张伟', foundDate: '2017-05-01', status: 1 },
    ],
  },

  systemDicts: {
    collection: 'systemDicts', label: '数据字典',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('code', '字典编码', 'text', 150),
      f('name', '字典名称', 'text', 170),
      f('itemCount', '字典项数量', 'number', 130),
      f('module', '所属模块', 'text', 140),
      f('description', '描述', 'textarea'),
      sel('status', '状态', ON_OFF),
    ],
    statusField: 'status', statusLabels: { '1': '启用', '0': '停用' },
    seed: [
      { id: 1, code: 'DICT_PAY_METHOD', name: '付款方式', itemCount: 4, module: '财务', description: '现金/转账/承兑/信用', status: 1 },
      { id: 2, code: 'DICT_SHIP_METHOD', name: '发运方式', itemCount: 3, module: '销售', description: '自提/快递/物流', status: 1 },
      { id: 3, code: 'DICT_CUSTOMER_LEVEL', name: '客户分级', itemCount: 4, module: 'CRM', description: 'A/B/C/D 四级', status: 1 },
    ],
  },

  sysdicts: {
    collection: 'sysdicts', label: '数据字典',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('code', '字典编码', 'text', 150),
      f('name', '字典名称', 'text', 170),
      sel('dictType', '字典类型', opt(['SYSTEM:系统', 'BUSINESS:业务']), 130),
      f('items', '字典项', 'textarea'),
      f('description', '描述', 'textarea'),
      sel('status', '状态', ON_OFF),
    ],
    statusField: 'status', statusLabels: { '1': '启用', '0': '停用' },
    seed: [
      { id: 1, code: 'DICT_UNIT', name: '计量单位', dictType: 'BUSINESS', items: '个,箱,千克,米,升', description: '物料计量单位', status: 1 },
      { id: 2, code: 'DICT_TAX', name: '税率', dictType: 'BUSINESS', items: '0%,6%,9%,13%', description: '增值税税率', status: 1 },
      { id: 3, code: 'DICT_GENDER', name: '性别', dictType: 'SYSTEM', items: '男,女', description: '员工性别', status: 1 },
    ],
  },

  systemConfigs: {
    collection: 'systemConfigs', label: '系统参数',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('configKey', '参数键', 'text', 190),
      f('configName', '参数名称', 'text', 170),
      f('configValue', '参数值', 'text', 180),
      f('groupName', '参数分组', 'text', 130),
      sel('valueType', '值类型', opt(['STRING:字符串', 'NUMBER:数字', 'BOOLEAN:布尔', 'JSON:JSON']), 120),
      f('description', '描述', 'textarea'),
      sel('isBuiltin', '是否内置', opt(['1:是', '0:否']), 110),
      sel('status', '状态', ON_OFF),
    ],
    statusField: 'status', statusLabels: { '1': '启用', '0': '停用' },
    seed: [
      { id: 1, configKey: 'COMPANY_NAME', configName: '公司名称', configValue: '示例科技有限公司', groupName: '基础信息', valueType: 'STRING', description: '显示在单据页眉', isBuiltin: 1, status: 1 },
      { id: 2, configKey: 'DEFAULT_TAX_RATE', configName: '默认税率', configValue: '13%', groupName: '财务', valueType: 'STRING', description: '销项税计算默认税率', isBuiltin: 1, status: 1 },
      { id: 3, configKey: 'APPROVAL_ENABLED', configName: '启用审批流', configValue: 'true', groupName: '流程', valueType: 'BOOLEAN', description: '销售/采购单提交后走审批', isBuiltin: 1, status: 1 },
      { id: 4, configKey: 'SAFE_STOCK_ALERT', configName: '安全库存预警', configValue: 'true', groupName: '库存', valueType: 'BOOLEAN', description: '低于安全库存触发预警', isBuiltin: 0, status: 1 },
    ],
  },

  sysconfigs: {
    collection: 'sysconfigs', label: '系统参数',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('configKey', '参数键', 'text', 190),
      f('configName', '参数名称', 'text', 170),
      f('configValue', '参数值', 'text', 180),
      f('groupName', '分组', 'text', 130),
      f('description', '描述', 'textarea'),
      sel('status', '状态', ON_OFF),
    ],
    statusField: 'status', statusLabels: { '1': '启用', '0': '停用' },
    seed: [
      { id: 1, configKey: 'DEFAULT_WAREHOUSE', configName: '默认仓库', configValue: '原料一库', groupName: '库存', description: '新建单据默认仓库', status: 1 },
      { id: 2, configKey: 'PAGE_SIZE', configName: '默认分页条数', configValue: '20', groupName: '界面', description: '列表默认每页条数', status: 1 },
      { id: 3, configKey: 'PRINT_WATERMARK', configName: '打印水印', configValue: '示例科技', groupName: '打印', description: '打印单据水印文字', status: 1 },
    ],
  },

  systemViewConfigs: {
    collection: 'systemViewConfigs', label: '视图配置',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('code', '配置编码', 'text', 140),
      f('name', '配置名称', 'text', 170),
      f('pagePath', '所属页面', 'text', 180),
      sel('viewType', '视图类型', opt(['LIST:列表', 'BOARD:看板', 'CHART:图表']), 130),
      f('columns', '列配置', 'textarea'),
      f('sortNo', '排序', 'number', 100),
      sel('isDefault', '是否默认', opt(['1:是', '0:否']), 110),
      sel('status', '状态', ON_OFF),
    ],
    statusField: 'status', statusLabels: { '1': '启用', '0': '停用' },
    seed: [
      { id: 1, code: 'VIEW-SO-LIST', name: '销售单列表视图', pagePath: '/sales/orders', viewType: 'LIST', columns: 'orderNo,customerName,orderDate,totalAmount,status', sortNo: 1, isDefault: 1, status: 1 },
      { id: 2, code: 'VIEW-INV-BOARD', name: '库存看板视图', pagePath: '/inventory/balance', viewType: 'BOARD', columns: 'productName,qtyOnHand,qtyAvailable', sortNo: 2, isDefault: 0, status: 1 },
      { id: 3, code: 'VIEW-FIN-CHART', name: '收入趋势图', pagePath: '/finance/incomes', viewType: 'CHART', columns: 'period,amount', sortNo: 3, isDefault: 0, status: 1 },
    ],
  },

  syslogs: {
    collection: 'syslogs', label: '系统日志',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('logNo', '日志编号', 'text', 160),
      sel('opType', '操作类型', opt(['LOGIN:登录', 'CREATE:新增', 'UPDATE:修改', 'DELETE:删除', 'EXPORT:导出']), 130),
      f('module', '操作模块', 'text', 140),
      f('description', '操作描述', 'textarea'),
      f('operator', '操作人', 'text', 130),
      f('ip', 'IP地址', 'text', 140),
      f('createdAt', '操作时间', 'datetime', 170),
      f('costMs', '耗时(ms)', 'number', 110),
      sel('result', '状态', opt(['SUCCESS:成功', 'FAIL:失败']), 110),
    ],
    statusField: 'result', statusLabels: { SUCCESS: '成功', FAIL: '失败' },
    seed: [
      { id: 1, logNo: 'LOG20261118-0001', opType: 'LOGIN', module: '系统', description: '用户 admin 登录系统', operator: 'admin', ip: '192.168.1.20', createdAt: '2026-11-18 09:12:03', costMs: 128, result: 'SUCCESS' },
      { id: 2, logNo: 'LOG20261118-0002', opType: 'CREATE', module: '销售管理', description: '新建销售单 SO202611-0008', operator: '张销售', ip: '192.168.1.35', createdAt: '2026-11-18 10:05:41', costMs: 246, result: 'SUCCESS' },
      { id: 3, logNo: 'LOG20261118-0003', opType: 'UPDATE', module: '财务管理', description: '凭证 V20261118-0012 过账失败：借贷不平衡', operator: '陈会计', ip: '192.168.1.42', createdAt: '2026-11-18 11:22:18', costMs: 92, result: 'FAIL' },
    ],
  },

  systemAuditLogs: {
    collection: 'systemAuditLogs', label: '审计日志',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('auditNo', '审计编号', 'text', 160),
      f('module', '业务模块', 'text', 140),
      f('bizNo', '业务单号', 'text', 150),
      sel('opType', '操作类型', opt(['CREATE:新增', 'UPDATE:修改', 'DELETE:删除', 'APPROVE:审批', 'POST:过账']), 130),
      f('operator', '操作人', 'text', 130),
      f('beforeContent', '变更前内容', 'textarea'),
      f('afterContent', '变更后内容', 'textarea'),
      f('createdAt', '操作时间', 'datetime', 170),
      f('ip', '来源IP', 'text', 140),
    ],
    seed: [
      { id: 1, auditNo: 'AUD20261112-001', module: '销售管理', bizNo: 'SO202611-0007', opType: 'POST', operator: '张销售', beforeContent: '状态=待审核', afterContent: '状态=已完成；已生成应收 128000；已生成凭证 2 张', createdAt: '2026-11-12 14:05:22', ip: '192.168.1.35' },
      { id: 2, auditNo: 'AUD20261114-002', module: '库存管理', bizNo: 'ADJ202611-0002', opType: 'APPROVE', operator: '王仓管', beforeContent: '状态=待审核', afterContent: '状态=已确认；盘盈 5', createdAt: '2026-11-14 09:18:40', ip: '192.168.1.51' },
      { id: 3, auditNo: 'AUD20261115-003', module: '财务管理', bizNo: 'V20261115-0011', opType: 'UPDATE', operator: '陈会计', beforeContent: '科目=6001 金额=36000', afterContent: '科目=6001 金额=33962.26；新增应交税费 2037.74', createdAt: '2026-11-15 16:42:11', ip: '192.168.1.42' },
    ],
  },

  systemLoginLogs: {
    collection: 'systemLoginLogs', label: '登录日志',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('loginNo', '登录编号', 'text', 160),
      f('username', '用户名', 'text', 140),
      f('ip', '登录IP', 'text', 140),
      f('location', '登录地点', 'text', 160),
      f('browser', '浏览器', 'text', 140),
      f('os', '操作系统', 'text', 140),
      f('createdAt', '登录时间', 'datetime', 170),
      sel('result', '结果', opt(['SUCCESS:成功', 'FAIL:失败']), 110),
      f('failReason', '失败原因', 'text', 170),
    ],
    statusField: 'result', statusLabels: { SUCCESS: '成功', FAIL: '失败' },
    seed: [
      { id: 1, loginNo: 'LG20261118-0001', username: 'admin', ip: '192.168.1.20', location: '广东深圳', browser: 'Chrome 131', os: 'Windows 11', createdAt: '2026-11-18 09:12:01', result: 'SUCCESS', failReason: '' },
      { id: 2, loginNo: 'LG20261118-0002', username: 'zhangsales', ip: '192.168.1.35', location: '广东深圳', browser: 'Chrome 131', os: 'Windows 10', createdAt: '2026-11-18 08:40:12', result: 'SUCCESS', failReason: '' },
      { id: 3, loginNo: 'LG20261118-0003', username: 'licaiwu', ip: '192.168.1.42', location: '广东深圳', browser: 'Edge 130', os: 'Windows 11', createdAt: '2026-11-18 08:02:55', result: 'FAIL', failReason: '密码错误' },
    ],
  },

  sysloginLogs: {
    collection: 'sysloginLogs', label: '登录日志',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('username', '用户名', 'text', 140),
      f('ip', '登录IP', 'text', 140),
      f('createdAt', '登录时间', 'datetime', 170),
      sel('result', '结果', opt(['SUCCESS:成功', 'FAIL:失败']), 110),
      f('remark', '备注', 'text', 180),
    ],
    statusField: 'result', statusLabels: { SUCCESS: '成功', FAIL: '失败' },
    seed: [
      { id: 1, username: 'admin', ip: '192.168.1.20', createdAt: '2026-11-18 09:12:01', result: 'SUCCESS', remark: '正常登录' },
      { id: 2, username: 'wangcang', ip: '192.168.1.51', createdAt: '2026-11-18 08:15:33', result: 'SUCCESS', remark: '正常登录' },
      { id: 3, username: 'unknown', ip: '10.0.0.88', createdAt: '2026-11-18 03:22:07', result: 'FAIL', remark: '账号不存在，疑似暴力破解' },
    ],
  },

  systemEvents: {
    collection: 'systemEvents', label: '事件中心',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('eventNo', '事件编号', 'text', 160),
      sel('eventType', '事件类型', opt(['BIZ:业务事件', 'SYS:系统事件', 'ALERT:预警']), 130),
      f('title', '事件标题', 'text', 200),
      f('module', '来源模块', 'text', 140),
      sel('severity', '严重级别', opt(['INFO:提示', 'NORMAL:一般', 'SERIOUS:严重']), 120),
      f('createdAt', '发生时间', 'datetime', 170),
      sel('status', '处理状态', opt(['UNREAD:未处理', 'READ:已读', 'DONE:已处理']), 120),
      f('handler', '处理人', 'text', 130),
    ],
    statusField: 'status', statusLabels: { UNREAD: '未处理', READ: '已读', DONE: '已处理' },
    seed: [
      { id: 1, eventNo: 'EVT20261118-001', eventType: 'ALERT', title: '激光切割机 LG-200 库存低于安全库存', module: '库存管理', severity: 'SERIOUS', createdAt: '2026-11-18 07:00:00', status: 'UNREAD', handler: '' },
      { id: 2, eventNo: 'EVT20261117-002', eventType: 'BIZ', title: '销售单 SO202611-0007 已完成发货', module: '销售管理', severity: 'INFO', createdAt: '2026-11-17 15:22:10', status: 'READ', handler: '' },
      { id: 3, eventNo: 'EVT20261116-003', eventType: 'SYS', title: '定时任务「日报表生成」执行失败', module: '系统管理', severity: 'NORMAL', createdAt: '2026-11-16 02:00:05', status: 'DONE', handler: 'admin' },
    ],
  },

  systemNotifies: {
    collection: 'systemNotifies', label: '消息通知',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('notifyNo', '通知编号', 'text', 160),
      sel('notifyType', '通知类型', opt(['APPROVAL:审批', 'ALERT:预警', 'TASK:任务', 'SYSTEM:系统']), 130),
      f('title', '标题', 'text', 200),
      f('content', '内容', 'textarea'),
      f('receiver', '接收人', 'text', 130),
      f('createdAt', '发送时间', 'datetime', 170),
      sel('readStatus', '已读状态', opt(['UNREAD:未读', 'READ:已读']), 120),
      sel('priority', '优先级', opt(['HIGH:高', 'MID:中', 'LOW:低']), 110),
    ],
    statusField: 'readStatus', statusLabels: { UNREAD: '未读', READ: '已读' },
    seed: [
      { id: 1, notifyNo: 'NTF20261118-001', notifyType: 'APPROVAL', title: '销售单 SO202611-0008 待您审批', content: '金额 168000 元，超过 10000 元阈值，需总监审批', receiver: '销售总监', createdAt: '2026-11-18 10:05:45', readStatus: 'UNREAD', priority: 'HIGH' },
      { id: 2, notifyNo: 'NTF20261118-002', notifyType: 'ALERT', title: '库存预警：LG-200 低于安全库存', content: '当前库存 1，安全库存 3，请及时补货', receiver: '王仓管', createdAt: '2026-11-18 07:00:01', readStatus: 'UNREAD', priority: 'HIGH' },
      { id: 3, notifyNo: 'NTF20261117-003', notifyType: 'SYSTEM', title: '系统升级通知', content: '系统将于 11 月 20 日 22:00 进行版本升级', receiver: '全体用户', createdAt: '2026-11-17 18:00:00', readStatus: 'READ', priority: 'MID' },
    ],
  },

  systemJobs: {
    collection: 'systemJobs', label: '定时任务',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('jobNo', '任务编号', 'text', 150),
      f('name', '任务名称', 'text', 170),
      sel('jobType', '任务类型', opt(['BACKUP:备份', 'SYNC:同步', 'REPORT:报表', 'CLEAN:清理']), 130),
      f('cron', '执行计划', 'text', 160),
      f('lastRunAt', '上次执行时间', 'datetime', 170),
      f('nextRunAt', '下次执行时间', 'datetime', 170),
      sel('runStatus', '执行状态', opt(['SUCCESS:成功', 'FAIL:失败', 'NEVER:未执行']), 120),
      sel('status', '状态', ON_OFF),
    ],
    statusField: 'runStatus', statusLabels: { SUCCESS: '成功', FAIL: '失败', NEVER: '未执行' },
    seed: [
      { id: 1, jobNo: 'JOB-001', name: '每日全量备份', jobType: 'BACKUP', cron: '0 2 * * *', lastRunAt: '2026-11-18 02:00:00', nextRunAt: '2026-11-19 02:00:00', runStatus: 'SUCCESS', status: 1 },
      { id: 2, jobNo: 'JOB-002', name: '日报表生成', jobType: 'REPORT', cron: '0 6 * * *', lastRunAt: '2026-11-18 06:00:00', nextRunAt: '2026-11-19 06:00:00', runStatus: 'FAIL', status: 1 },
      { id: 3, jobNo: 'JOB-003', name: '过期日志清理', jobType: 'CLEAN', cron: '0 3 1 * *', lastRunAt: '2026-11-01 03:00:00', nextRunAt: '2026-12-01 03:00:00', runStatus: 'SUCCESS', status: 0 },
    ],
  },

  sysbackups: {
    collection: 'sysbackups', label: '备份管理',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('backupNo', '备份编号', 'text', 160),
      sel('backupType', '备份类型', opt(['FULL:全量', 'INCREMENT:增量']), 130),
      f('fileName', '文件名称', 'text', 200),
      f('fileSize', '文件大小(KB)', 'number', 140),
      f('storagePath', '存储位置', 'text', 200),
      f('backupAt', '备份时间', 'datetime', 170),
      f('costSec', '耗时(秒)', 'number', 120),
      f('operator', '操作人', 'text', 130),
      sel('status', '状态', opt(['SUCCESS:成功', 'FAIL:失败']), 110),
    ],
    statusField: 'status', statusLabels: { SUCCESS: '成功', FAIL: '失败' },
    seed: [
      { id: 1, backupNo: 'BK20261118-001', backupType: 'FULL', fileName: 'leai_erp_20261118_020000.sql', fileSize: 48620, storagePath: '/backup/full/20261118/', backupAt: '2026-11-18 02:00:00', costSec: 46, operator: '系统任务', status: 'SUCCESS' },
      { id: 2, backupNo: 'BK20261117-002', backupType: 'INCREMENT', fileName: 'leai_erp_incr_20261117.sql', fileSize: 3260, storagePath: '/backup/incr/20261117/', backupAt: '2026-11-17 02:00:00', costSec: 9, operator: '系统任务', status: 'SUCCESS' },
      { id: 3, backupNo: 'BK20261116-003', backupType: 'FULL', fileName: 'leai_erp_20261116_020000.sql', fileSize: 47980, storagePath: '/backup/full/20261116/', backupAt: '2026-11-16 02:00:00', costSec: 0, operator: '系统任务', status: 'FAIL' },
    ],
  },

  systemFiles: {
    collection: 'systemFiles', label: '文件管理',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('fileNo', '文件编号', 'text', 160),
      f('fileName', '文件名称', 'text', 200),
      f('fileType', '文件类型', 'text', 120),
      f('fileSize', '文件大小(KB)', 'number', 140),
      f('storagePath', '存储路径', 'text', 200),
      f('uploader', '上传人', 'text', 130),
      f('createdAt', '上传时间', 'datetime', 170),
      f('module', '所属模块', 'text', 140),
      sel('status', '状态', ON_OFF),
    ],
    statusField: 'status', statusLabels: { '1': '启用', '0': '停用' },
    seed: [
      { id: 1, fileNo: 'FILE-0001', fileName: '销售合同_宏图科技_2026.pdf', fileType: 'PDF', fileSize: 2860, storagePath: '/files/contract/2026/', uploader: '张销售', createdAt: '2026-11-12 10:30:00', module: '销售管理', status: 1 },
      { id: 2, fileNo: 'FILE-0002', fileName: '供应商资质_不锈钢材料.jpg', fileType: 'JPG', fileSize: 1240, storagePath: '/files/supplier/2026/', uploader: '李采购', createdAt: '2026-11-08 15:12:00', module: '采购管理', status: 1 },
      { id: 3, fileNo: 'FILE-0003', fileName: '2026年10月财务报表.xlsx', fileType: 'XLSX', fileSize: 486, storagePath: '/files/finance/202610/', uploader: '陈会计', createdAt: '2026-11-04 09:05:00', module: '财务管理', status: 1 },
    ],
  },

  systemNos: {
    collection: 'systemNos', label: '编号规则',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('code', '规则编码', 'text', 140),
      f('name', '规则名称', 'text', 170),
      f('bizType', '适用单据', 'text', 150),
      f('prefix', '前缀', 'text', 110),
      f('dateFormat', '日期格式', 'text', 130),
      f('seqLength', '流水位数', 'number', 120),
      f('currentSeq', '当前序号', 'number', 120),
      sel('resetCycle', '重置周期', opt(['DAY:每日', 'MONTH:每月', 'YEAR:每年', 'NEVER:不重置']), 130),
      sel('status', '状态', ON_OFF),
    ],
    statusField: 'status', statusLabels: { '1': '启用', '0': '停用' },
    seed: [
      { id: 1, code: 'NO-SO', name: '销售订单号', bizType: '销售订单', prefix: 'SO', dateFormat: 'yyyyMM', seqLength: 4, currentSeq: 8, resetCycle: 'MONTH', status: 1 },
      { id: 2, code: 'NO-PO', name: '采购订单号', bizType: '采购订单', prefix: 'PO', dateFormat: 'yyyyMM', seqLength: 4, currentSeq: 5, resetCycle: 'MONTH', status: 1 },
      { id: 3, code: 'NO-VCH', name: '凭证号', bizType: '会计凭证', prefix: 'V', dateFormat: 'yyyyMMdd', seqLength: 4, currentSeq: 37, resetCycle: 'DAY', status: 1 },
      { id: 4, code: 'NO-ADJ', name: '库存调整单号', bizType: '库存调整', prefix: 'ADJ', dateFormat: 'yyyyMM', seqLength: 4, currentSeq: 3, resetCycle: 'MONTH', status: 1 },
    ],
  },

  sysprintLogs: {
    collection: 'sysprintLogs', label: '打印日志',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('printNo', '打印编号', 'text', 160),
      f('templateName', '模板名称', 'text', 180),
      f('bizType', '单据类型', 'text', 140),
      f('bizNo', '单据号', 'text', 150),
      f('copies', '份数', 'number', 100),
      sel('printMode', '打印方式', opt(['FRONT:前台', 'BACK:后台']), 120),
      f('printedBy', '打印人', 'text', 130),
      f('printedAt', '打印时间', 'datetime', 170),
      sel('status', '状态', opt(['SUCCESS:成功', 'FAIL:失败']), 110),
    ],
    statusField: 'status', statusLabels: { SUCCESS: '成功', FAIL: '失败' },
    seed: [
      { id: 1, printNo: 'PRT20261112-001', templateName: '销售出库单 A4', bizType: '销售单', bizNo: 'SO202611-0007', copies: 2, printMode: 'FRONT', printedBy: '张销售', printedAt: '2026-11-12 14:10:00', status: 'SUCCESS' },
      { id: 2, printNo: 'PRT20261114-002', templateName: '库存调整单', bizType: '调整单', bizNo: 'ADJ202611-0002', copies: 1, printMode: 'FRONT', printedBy: '王仓管', printedAt: '2026-11-14 09:22:00', status: 'SUCCESS' },
      { id: 3, printNo: 'PRT20261116-003', templateName: '采购入库单', bizType: '采购单', bizNo: 'PO202611-0003', copies: 3, printMode: 'BACK', printedBy: '李采购', printedAt: '2026-11-16 16:40:00', status: 'FAIL' },
    ],
  },

  systemAlertRules: {
    collection: 'systemAlertRules', label: '告警规则',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('name', '规则名称', 'text', 180),
      sel('ruleType', '规则类型', opt(['INVENTORY:库存', 'FINANCE:财务', 'SALES:销售', 'SYSTEM:系统']), 130),
      f('condition', '触发条件', 'text', 220),
      f('threshold', '阈值', 'text', 130),
      sel('level', '告警级别', opt(['HIGH:高', 'MID:中', 'LOW:低']), 110),
      sel('notifyWay', '通知方式', opt(['SITE:站内', 'EMAIL:邮件', 'SMS:短信']), 120),
      f('receiver', '接收人', 'text', 150),
      sel('status', '状态', ON_OFF),
    ],
    statusField: 'status', statusLabels: { '1': '启用', '0': '停用' },
    seed: [
      { id: 1, name: '低库存告警', ruleType: 'INVENTORY', condition: '可用库存 < 安全库存', threshold: '安全库存', level: 'HIGH', notifyWay: 'SITE', receiver: '王仓管', status: 1 },
      { id: 2, name: '应收逾期告警', ruleType: 'FINANCE', condition: '账龄 > 30 天', threshold: '30天', level: 'HIGH', notifyWay: 'EMAIL', receiver: '陈会计', status: 1 },
      { id: 3, name: '超信用额度告警', ruleType: 'SALES', condition: '应收余额 > 信用额度', threshold: '信用额度', level: 'MID', notifyWay: 'SITE', receiver: '张销售', status: 1 },
    ],
  },

  syslogConfigs: {
    collection: 'syslogConfigs', label: '日志配置',
    fields: [
      f('id', 'ID', 'text', 70, { form: false }),
      f('code', '配置编号', 'text', 150),
      f('name', '配置名称', 'text', 180),
      sel('logLevel', '记录级别', opt(['DEBUG:调试', 'INFO:信息', 'WARN:警告', 'ERROR:错误']), 130),
      f('retainDays', '保留天数', 'number', 120),
      sel('logBody', '是否记录请求体', opt(['1:是', '0:否']), 130),
      sel('status', '状态', ON_OFF),
    ],
    statusField: 'status', statusLabels: { '1': '启用', '0': '停用' },
    seed: [
      { id: 1, code: 'LOGC-001', name: '业务操作日志', logLevel: 'INFO', retainDays: 180, logBody: 1, status: 1 },
      { id: 2, code: 'LOGC-002', name: '接口访问日志', logLevel: 'WARN', retainDays: 90, logBody: 0, status: 1 },
      { id: 3, code: 'LOGC-003', name: '错误异常日志', logLevel: 'ERROR', retainDays: 365, logBody: 1, status: 1 },
    ],
  },
};
