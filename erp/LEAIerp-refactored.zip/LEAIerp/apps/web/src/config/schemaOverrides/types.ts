/**
 * 业务实体 Schema 覆盖层
 * ---------------------------------------------------------------------------
 * 目的：entitySchemas.ts 中 159 个集合里，有 101 个早期用「名称/编码/说明/状态」
 *       占位字段生成，导致页面虽然是增删改查的功能页，但用户根本无法录入
 *       真实业务数据（例如「固定资产」没有原值/使用年限/折旧方法）。
 *       本目录按业务域提供这些集合的**真实字段与真实种子数据**，
 *       由 entitySchemas.ts 统一合并覆盖。
 *
 * 约定：
 *   - 每个域文件导出 `Record<string, EntitySchema>`，键为集合名；
 *   - 字段与 entitySchemas.ts 完全同构（prop/label/type/options/width/form）；
 *   - 种子数据必须符合业务语义（真实单号、金额、日期、状态）；
 *   - 不改动业务逻辑与文案，仅补齐数据模型。
 */

export type FieldType = 'text' | 'number' | 'money' | 'date' | 'datetime' | 'select' | 'textarea' | 'switch';

export interface EntityField {
  prop: string;
  label: string;
  type?: FieldType;
  options?: Array<{ label: string; value: string | number }>;
  width?: number;
  /** 是否出现在新增/编辑表单（默认 true；id/时间戳默认排除） */
  form?: boolean;
}

export interface EntitySchema {
  collection: string;
  label: string;
  fields: EntityField[];
  seed: any[];
  statusField?: string;
  statusLabels?: Record<string, string>;
}

/** 字段定义简写 */
export const f = (prop: string, label: string, type: FieldType = 'text', width?: number, extra?: Partial<EntityField>): EntityField => ({ prop, label, type, width, ...extra });
/** 下拉字段简写 */
export const sel = (prop: string, label: string, options: Array<{ label: string; value: string | number }>, width = 100): EntityField => f(prop, label, 'select', width, { options });
/** 下拉简写：从 "值:文案" 数组构造 */
export const opt = (pairs: string[]): Array<{ label: string; value: string }> =>
  pairs.map((p) => { const i = p.indexOf(':'); const value = i >= 0 ? p.slice(0, i) : p; const label = i >= 0 ? p.slice(i + 1) : p; return { label, value }; });

/** 通用启停选项 */
export const ON_OFF = opt(['1:启用', '0:停用']);
/** 通用单据状态选项 */
export const DOC_STATUS_OPT = opt(['0:草稿', '1:待审核', '2:已确认', '3:部分完成', '4:已完成', '9:已作废']);
