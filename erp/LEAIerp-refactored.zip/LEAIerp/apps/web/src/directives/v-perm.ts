import { useUserStore } from '../store';

/** 按钮权限指令：无权限直接移除节点，v-perm="'sales:order:create'" */
export const vPerm = {
  mounted(el: HTMLElement, binding: any) {
    const store = useUserStore();
    const code = binding.value as string;
    if (code && !store.hasPerm(code)) {
      el.parentNode?.removeChild(el);
    }
  },
};
