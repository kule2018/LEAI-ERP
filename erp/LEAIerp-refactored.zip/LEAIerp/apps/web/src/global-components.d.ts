/**
 * 全局组件类型声明。
 * ---------------------------------------------------------------------------
 * main.ts 调用 installDsUi(app) 后，Ds 与 Base 系列组件可在任意 SFC 模板直接使用。
 * 这里把组件加入 Vue 的 GlobalComponents 接口，让 vue-tsc 正确识别标签，
 * 避免类型检查把全局组件误判为未知元素。
 */
declare module 'vue' {
  export interface GlobalComponents {
    DsAppShell: typeof import('./components/ds/DsAppShell.vue').default;
    DsAlert: typeof import('./components/ds/DsAlert.vue').default;
    DsAvatar: typeof import('./components/ds/DsAvatar.vue').default;
    DsBadge: typeof import('./components/ds/DsBadge.vue').default;
    DsBreadcrumb: typeof import('./components/ds/DsBreadcrumb.vue').default;
    DsButton: typeof import('./components/ds/DsButton.vue').default;
    DsCard: typeof import('./components/ds/DsCard.vue').default;
    DsCascader: typeof import('./components/ds/DsCascader.vue').default;
    DsChatView: typeof import('./components/ds/DsChatView.vue').default;
    DsCheckbox: typeof import('./components/ds/DsCheckbox.vue').default;
    DsCollapse: typeof import('./components/ds/DsCollapse.vue').default;
    DsCollapseItem: typeof import('./components/ds/DsCollapseItem.vue').default;
    DsComposer: typeof import('./components/ds/DsComposer.vue').default;
    DsConfirm: typeof import('./components/ds/DsConfirm.vue').default;
    DsDatePicker: typeof import('./components/ds/DsDatePicker.vue').default;
    DsDescriptions: typeof import('./components/ds/DsDescriptions.vue').default;
    DsDivider: typeof import('./components/ds/DsDivider.vue').default;
    DsDrawer: typeof import('./components/ds/DsDrawer.vue').default;
    DsDropdown: typeof import('./components/ds/DsDropdown.vue').default;
    DsEmpty: typeof import('./components/ds/DsEmpty.vue').default;
    DsField: typeof import('./components/ds/DsField.vue').default;
    DsForm: typeof import('./components/ds/DsForm.vue').default;
    DsFormItem: typeof import('./components/ds/DsFormItem.vue').default;
    DsImage: typeof import('./components/ds/DsImage.vue').default;
    DsInput: typeof import('./components/ds/DsInput.vue').default;
    DsInputNumber: typeof import('./components/ds/DsInputNumber.vue').default;
    DsLoading: typeof import('./components/ds/DsLoading.vue').default;
    DsMarkdown: typeof import('./components/ds/DsMarkdown.vue').default;
    DsMenu: typeof import('./components/ds/DsMenu.vue').default;
    DsModal: typeof import('./components/ds/DsModal.vue').default;
    DsPagination: typeof import('./components/ds/DsPagination.vue').default;
    DsPopover: typeof import('./components/ds/DsPopover.vue').default;
    DsProgress: typeof import('./components/ds/DsProgress.vue').default;
    DsRadio: typeof import('./components/ds/DsRadio.vue').default;
    DsRate: typeof import('./components/ds/DsRate.vue').default;
    DsResult: typeof import('./components/ds/DsResult.vue').default;
    DsSegmented: typeof import('./components/ds/DsSegmented.vue').default;
    DsSelect: typeof import('./components/ds/DsSelect.vue').default;
    DsSkeleton: typeof import('./components/ds/DsSkeleton.vue').default;
    DsSlider: typeof import('./components/ds/DsSlider.vue').default;
    DsSpinner: typeof import('./components/ds/DsSpinner.vue').default;
    DsStatCard: typeof import('./components/ds/DsStatCard.vue').default;
    DsSteps: typeof import('./components/ds/DsSteps.vue').default;
    DsSwitch: typeof import('./components/ds/DsSwitch.vue').default;
    DsTable: typeof import('./components/ds/DsTable.vue').default;
    DsTabs: typeof import('./components/ds/DsTabs.vue').default;
    DsTag: typeof import('./components/ds/DsTag.vue').default;
    DsToast: typeof import('./components/ds/DsToast.vue').default;
    DsTooltip: typeof import('./components/ds/DsTooltip.vue').default;
    DsTree: typeof import('./components/ds/DsTree.vue').default;
    DsTreeSelect: typeof import('./components/ds/DsTreeSelect.vue').default;
    DsUploader: typeof import('./components/ds/DsUploader.vue').default;

    AsyncState: typeof import('./components/AsyncState.vue').default;
    ErrorBoundary: typeof import('./components/ErrorBoundary.vue').default;
    ChunkedUpload: typeof import('./components/ChunkedUpload.vue').default;
    BaseDialog: typeof import('./components/BaseDialog.vue').default;
    BaseDrawer: typeof import('./components/BaseDrawer.vue').default;
    BaseForm: typeof import('./components/BaseForm.vue').default;
    BaseGrid: typeof import('./components/BaseGrid.vue').default;
    BaseSelect: typeof import('./components/BaseSelect.vue').default;
    BaseTable: typeof import('./components/BaseTable.vue').default;
    BaseTree: typeof import('./components/BaseTree.vue').default;
    BaseUpload: typeof import('./components/BaseUpload.vue').default;
    DetailDrawer: typeof import('./components/DetailDrawer.vue').default;
    EmptyState: typeof import('./components/EmptyState.vue').default;
    IconButton: typeof import('./components/IconButton.vue').default;
    IconFont: typeof import('./components/IconFont.vue').default;
    Panel: typeof import('./components/Panel.vue').default;
    ParentView: typeof import('./components/ParentView.vue').default;
    PhotoToVideo: typeof import('./components/PhotoToVideo.vue').default;
    QueryDrawer: typeof import('./components/QueryDrawer.vue').default;
    StatCard: typeof import('./components/StatCard.vue').default;
    Tbar: typeof import('./components/Tbar.vue').default;
    TopSearch: typeof import('./components/TopSearch.vue').default;
    FirstGuide: typeof import('./components/FirstGuide.vue').default;
    SignaturePad: typeof import('./components/SignaturePad.vue').default;
    DocumentComments: typeof import('./components/DocumentComments.vue').default;
    VirtualTable: typeof import('./components/VirtualTable.vue').default;
    ViewConfigDrawer: typeof import('./components/ViewConfigDrawer.vue').default;
    BatchResultDialog: typeof import('./components/BatchResultDialog.vue').default;
  }
}
export {};
