/**
 * 轻量国际化（文档第 13 章：多语言）。
 * ---------------------------------------------------------------------------
 * 项目菜单与业务术语以中文为主，这里提供不引入额外依赖的响应式语言包：
 *   - 全局 $t(key) / useI18n() 组成的可翻译文案层；
 *   - 语言包存本地，可在「系统管理 → 多语言多币种」维护；
 *   - 缺失文案自动回退中文，保证切换语言后不会出现空白。
 */
import { reactive } from 'vue';

export type Locale = 'zh-CN' | 'en-US' | 'ja-JP';

/** 内置语言包：只覆盖全局高频文案，业务数据仍由后端 i18n 字段提供 */
const builtin: Record<Locale, Record<string, string>> = {
  'zh-CN': {
    'common.save': '保存', 'common.cancel': '取消', 'common.delete': '删除', 'common.confirm': '确认',
    'common.search': '查询', 'common.reset': '重置', 'common.export': '导出', 'common.import': '导入',
    'common.new': '新建', 'common.edit': '编辑', 'common.close': '关闭', 'common.loading': '加载中',
    'nav.dashboard': '工作台', 'nav.sales': '销售客户', 'nav.purchase': '采购供应商', 'nav.inventory': '库存管理',
    'nav.finance': '财务管理', 'nav.system': '系统管理', 'nav.ai': 'AI 助手',
  },
  'en-US': {
    'common.save': 'Save', 'common.cancel': 'Cancel', 'common.delete': 'Delete', 'common.confirm': 'Confirm',
    'common.search': 'Search', 'common.reset': 'Reset', 'common.export': 'Export', 'common.import': 'Import',
    'common.new': 'New', 'common.edit': 'Edit', 'common.close': 'Close', 'common.loading': 'Loading',
    'nav.dashboard': 'Dashboard', 'nav.sales': 'Sales', 'nav.purchase': 'Purchase', 'nav.inventory': 'Inventory',
    'nav.finance': 'Finance', 'nav.system': 'System', 'nav.ai': 'AI Assistant',
  },
  'ja-JP': {
    'common.save': '保存', 'common.cancel': 'キャンセル', 'common.delete': '削除', 'common.confirm': '確認',
    'common.search': '検索', 'common.reset': 'リセット', 'common.export': 'エクスポート', 'common.import': 'インポート',
    'common.new': '新規', 'common.edit': '編集', 'common.close': '閉じる', 'common.loading': '読み込み中',
    'nav.dashboard': 'ダッシュボード', 'nav.sales': '販売', 'nav.purchase': '仕入', 'nav.inventory': '在庫',
    'nav.finance': '財務', 'nav.system': 'システム', 'nav.ai': 'AI アシスタント',
  },
};

/** 当前语言（持久化） */
function loadLocale(): Locale {
  try { return (localStorage.getItem('erp_locale') as Locale) || 'zh-CN'; } catch { return 'zh-CN'; }
}
export const i18nState = reactive<{ locale: Locale; overrides: Record<string, Record<string, string>> }>({
  locale: loadLocale(),
  overrides: {},
});

/** 设置语言并持久化 */
export function setLocale(locale: Locale): void {
  i18nState.locale = locale;
  localStorage.setItem('erp_locale', locale);
  document.documentElement.lang = locale;
}

/** 翻译入口：优先自定义语言包 → 内置语言包 → key 本身 */
export function t(key: string): string {
  return i18nState.overrides[i18nState.locale]?.[key]
    || builtin[i18nState.locale]?.[key]
    || builtin['zh-CN'][key]
    || key;
}

/** 加载/合并后台维护的语言包 */
export function loadLanguagePacks(packs: Array<{ locale: string; key: string; text: string }>): void {
  for (const pack of packs) {
    if (!i18nState.overrides[pack.locale]) i18nState.overrides[pack.locale] = {};
    i18nState.overrides[pack.locale][pack.key] = pack.text;
  }
}

/** 组合式 API 入口 */
export function useI18n() {
  return { t, setLocale, state: i18nState };
}
