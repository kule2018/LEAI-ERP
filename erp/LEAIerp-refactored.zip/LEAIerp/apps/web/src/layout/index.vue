<!--
 * ERP 主框架（顶栏 + 深色侧边栏 + 标签页 + 内容区 + AI/通知抽屉）
 * ---------------------------------------------------------------------------
 * 侧边栏按《注释.txt》的侧栏提示词实现：
 *   - 保留全部菜单内容、沿用现有交互，统一字号/圆角/间距；
 *   - 组间比组内更松，两侧留白一致，图标略小于文字，图文间距一致；
 *   - 每行最小高度 38px，文字放得下且上下留白充足，点击区域足够大；
 *   - 恒定深色 #12161f（样式在 styles/index.css 的 .erp-side）。
 * 全局交互：Cmd/Ctrl+K 或 / 打开快捷搜索，N 新建，S 保存，P 打印，
 *           Ctrl+Enter 提交，? 查看快捷键面板。
 -->
<template>
  <div class="erp-shell">
    <!-- 顶栏 -->
    <header class="erp-header">
      <div class="erp-header__left">
        <span class="erp-logo">LEO ERP</span>
        <button class="ds-btn ds-btn-default ds-btn-sm" type="button" @click="searchVisible = true">
          <IconFont name="Search" :size="15" /> 搜索菜单 / 单号 <kbd class="erp-kbd">Ctrl K</kbd>
        </button>
      </div>
      <div class="erp-header__right">
        <select v-model="uiLocale" class="ds-select" style="width: 96px" @change="changeLocale">
          <option value="zh-CN">中文</option><option value="en-US">English</option><option value="ja-JP">日本語</option>
        </select>
        <DsButton variant="text" size="sm" @click="toggleTheme"><IconFont :name="isDark ? 'Sun' : 'Moon'" :size="15" /> {{ isDark ? '浅色' : '深色' }}</DsButton>
        <DsButton variant="text" size="sm" @click="shortcutVisible = true"><IconFont name="Setting" :size="15" /> 快捷键</DsButton>
        <DsButton variant="text" size="sm" @click="feedback"><IconFont name="Chat" :size="15" /> 反馈</DsButton>
        <DsButton variant="text" size="sm" @click="openNotify"><IconFont name="Bell" :size="15" /> 通知 <span v-if="unread" class="erp-dot">{{ unread }}</span></DsButton>
        <span class="erp-user">{{ userStore.realName }}</span>
        <DsButton size="sm" @click="logout">退出</DsButton>
      </div>
    </header>

    <div class="erp-body">
      <!-- 侧边栏：一级分组可折叠，当前路由所在分组自动展开 -->
      <aside class="erp-side">
        <div v-for="group in groups" :key="group.group" class="side-group">
          <div class="group-title" :class="{ 'is-collapsed': !expanded[group.group] }" @click="toggleGroup(group.group)">
            <span class="group-arrow"><IconFont :name="expanded[group.group] ? 'ChevronDown' : 'ChevronRight'" :size="12" /></span>
            <span>{{ group.group }}</span>
          </div>
          <template v-if="expanded[group.group]">
            <div
              v-for="item in group.items"
              :key="item.path"
              class="menu-item"
              :class="{ 'is-active': isActive(item.path) }"
              :title="item.title"
              @click="go(item.path)"
            >
              <span class="icon"><IconFont :name="toDsIcon(item.icon)" :size="15" /></span>
              <span class="text">{{ item.title }}</span>
            </div>
          </template>
        </div>
        <div class="side-group">
          <div class="group-title">快捷入口</div>
          <div class="menu-item" @click="aiVisible = true"><span class="icon"><IconFont name="Sparkles" :size="15" /></span><span class="text">AI 助理</span></div>
          <div class="menu-item" @click="go('system/import-export')"><span class="icon"><IconFont name="Download" :size="15" /></span><span class="text">导入导出中心</span></div>
        </div>
      </aside>

      <!-- 主内容区：标签页 + 路由视图 -->
      <main class="erp-main">
        <div class="erp-tabs">
          <span v-for="tab in tabs" :key="tab.path" class="erp-tab" :class="{ 'is-active': route.path === '/' + tab.path }" @click="go(tab.path)">
            {{ tab.title }} <small v-if="tabs.length > 1" @click.stop="closeTab(tab.path)">✕</small>
          </span>
        </div>
        <router-view v-slot="{ Component }">
          <component :is="Component" :key="route.fullPath" />
        </router-view>
      </main>
    </div>

    <!-- 全局快捷搜索（Cmd/Ctrl+K） -->
    <DsModal v-model="searchVisible" title="快捷搜索（支持菜单、单号、产品、客户）" :width="640" :resizable="false">
      <input ref="searchInput" v-model="searchKeyword" class="ds-input" placeholder="输入关键词，如：销售、库存、SO2026…" @keyup.down.prevent="moveSearch(1)" @keyup.up.prevent="moveSearch(-1)" @keyup.enter="pickSearch" />
      <div class="erp-search-results">
        <div v-for="(item, i) in searchResults" :key="item.path" class="erp-search-item" :class="{ active: i === searchIndex }" @click="pickSearch(item)">
          <span><IconFont :name="toDsIcon(item.icon)" :size="15" /></span>
          <b>{{ item.title }}</b>
          <small>{{ item.group }}</small>
        </div>
        <div v-if="!searchResults.length" class="erp-empty">没有匹配的菜单或数据，试试「客户」或「打印」</div>
      </div>
      <template #footer><div class="erp-modal-foot"><DsButton @click="searchVisible = false">关闭</DsButton></div></template>
    </DsModal>

    <!-- 快捷键面板 -->
    <DsModal v-model="shortcutVisible" title="键盘快捷键" :width="460" :resizable="false">
      <div class="erp-shortcuts">
        <div v-for="s in shortcuts" :key="s.key" class="erp-shortcut"><kbd>{{ s.key }}</kbd><span>{{ s.desc }}</span></div>
      </div>
      <template #footer><div class="erp-modal-foot"><DsButton variant="primary" @click="shortcutVisible = false">知道了</DsButton></div></template>
    </DsModal>

    <!-- AI 助理常驻抽屉 -->
    <DsDrawer v-model="aiVisible" title="AI 助理 Copilot" :size="420">
      <AiCopilot embedded />
    </DsDrawer>

    <!-- 通知中心 -->
    <DsDrawer v-model="notifyVisible" title="通知中心" :size="360">
      <div v-if="!notifies.length" class="erp-empty">暂无通知</div>
      <div v-for="n in notifies" :key="n.id" class="erp-notify" @click="readNotify(n)">
        <b>{{ n.title || '系统通知' }}</b>
        <p>{{ n.content }}</p>
        <small>{{ n.createdAt }}</small>
      </div>
    </DsDrawer>

    <!-- 首次进入分步引导（只显示一次） -->
    <FirstGuide />

    <!-- 新特性提示：版本更新后首次进入弹出，可在版本日志页再次查看 -->
    <DsModal v-model="featureVisible" title="本次更新了什么" :width="520">
      <div class="erp-feature">
        <p>当前版本 <b>v{{ latestVersion }}</b>，本次补齐文档要求的全业务功能：</p>
        <ul><li>销售/采购/库存/财务全链路状态机与审批联动</li><li>打印模板设计器、批量打印与 AI 建单</li><li>数据权限、多语言多币种、订阅与开放平台</li></ul>
      </div>
      <template #footer><div class="erp-modal-foot"><DsButton @click="closeFeature('later')">稍后再说</DsButton><DsButton variant="primary" @click="closeFeature('done')">查看版本日志</DsButton></div></template>
    </DsModal>

    <!-- 全局轻提示容器（Ds UI 单例） -->
    <DsToast />
  </div>
</template>

<script setup lang="ts">
import { computed, onBeforeUnmount, onMounted, reactive, ref, watch } from 'vue';
import { useRoute, useRouter } from 'vue-router';
import { buildMenus } from '../router';
import { MENUS } from '../config/erp';
import { useUserStore } from '../store';
import { sysApi } from '../api';
import { useTheme } from '../components/ds/theme';
import { i18nState, setLocale, type Locale } from '../i18n';
import { useToast } from '../components/ds/toast';
import { IconFont } from '../components';
import { toDsIcon } from '../utils/menuIcon';
import AiCopilot from '../views/ai/copilot.vue';

/** 基础状态 */
const route = useRoute();
const router = useRouter();
const userStore = useUserStore();
const toast = useToast();
const { isDark, toggleTheme } = useTheme();
const uiLocale = ref<Locale>(i18nState.locale);
function changeLocale(): void { setLocale(uiLocale.value); toast.info('界面语言已切换，业务数据语言由各模块 i18n 字段决定'); }
// 依赖 token：切换账号后重新按新权限生成菜单，避免沿用上一个用户的侧栏
const groups = computed(() => { void userStore.token; return buildMenus(); });

/** 侧边栏展开状态：按分组记忆，默认全部展开（可通过点击标题收起） */
const expanded = reactive<Record<string, boolean>>({});
function toggleGroup(name: string) { expanded[name] = !expanded[name]; localStorage.setItem('erp_side_expanded', JSON.stringify(expanded)); }
watch(groups, (gs) => {
  let saved: Record<string, boolean> = {};
  try { saved = JSON.parse(localStorage.getItem('erp_side_expanded') || '{}'); } catch { /* 忽略损坏数据 */ }
  for (const g of gs) {
    if (saved[g.group] !== undefined) expanded[g.group] = saved[g.group];
    else expanded[g.group] = true;
    // 当前路由所在分组始终展开，避免找不到当前菜单位置
    if (g.group === route.meta.group) expanded[g.group] = true;
  }
}, { immediate: true });

/** 菜单跳转 */
function go(path: string) {
  if (path.includes(':')) return;
  void router.push('/' + path);
}
function isActive(path: string) { return route.path === '/' + path; }

/** 标签页：记录最近访问，点击可切换，可单独关闭 */
const tabs = ref<Array<{ path: string; title: string }>>([]);
function addTab(path: string, title: string) {
  if (!path || tabs.value.some((t) => t.path === path)) return;
  tabs.value.push({ path, title });
  if (tabs.value.length > 12) tabs.value.shift();
  localStorage.setItem('erp_tabs', JSON.stringify(tabs.value));
}
function closeTab(path: string) {
  tabs.value = tabs.value.filter((t) => t.path !== path);
  localStorage.setItem('erp_tabs', JSON.stringify(tabs.value));
}
watch(() => route.path, (path) => {
  if (typeof route.meta.group === 'string') expanded[route.meta.group] = true;
  if (typeof route.meta.title === 'string') addTab(path.slice(1), route.meta.title);
}, { immediate: true });

/** 快捷搜索：菜单 + 数据（Mock 模式下搜产品/客户/销售单） */
const searchVisible = ref(false);
const searchKeyword = ref('');
const searchIndex = ref(0);
const searchInput = ref<HTMLInputElement | null>(null);
const dataHits = ref<any[]>([]);
const searchResults = computed(() => {
  const kw = searchKeyword.value.trim().toLowerCase();
  const menuHits = kw
    ? MENUS.filter((m) => !m.hidden && (m.title.toLowerCase().includes(kw) || m.path.includes(kw))).map((m) => ({ path: m.path, title: m.title, group: m.group, icon: m.icon }))
    : MENUS.filter((m) => ['dashboard', 'sales/orders', 'inventory/products', 'ai/copilot'].includes(m.path)).map((m) => ({ path: m.path, title: m.title, group: m.group, icon: m.icon }));
  return [...menuHits, ...dataHits.value.map((d) => ({ path: d.path, title: d.title, group: d.group, icon: 'Search' }))].slice(0, 20);
});
function moveSearch(step: number) {
  searchIndex.value = (searchIndex.value + step + searchResults.value.length) % Math.max(1, searchResults.value.length);
}
function pickSearch(item?: any) {
  const target = item || searchResults.value[searchIndex.value];
  if (target) go(target.path);
  searchVisible.value = false;
}
watch(searchVisible, (v) => { if (v) setTimeout(() => searchInput.value?.focus(), 60); });
watch(searchKeyword, async (kw) => {
  dataHits.value = [];
  if (!kw || kw.length < 2) return;
  // 本地数据搜索，避免每次按键都请求后端
  try {
    const raw = localStorage.getItem('erp_mock_db_v3');
    if (!raw) return;
    const db = JSON.parse(raw);
    for (const [key, collection] of Object.entries<any>(db)) {
      for (const row of collection || []) {
        const text = String(row.name || row.title || row.orderNo || row.code || '').toLowerCase();
        if (text.includes(kw.toLowerCase())) {
          dataHits.value.push({ path: key === 'products' ? 'inventory/products' : key === 'customers' ? 'sales/customers' : key === 'saleOrders' ? 'sales/orders' : 'dashboard', title: row.name || row.title || row.orderNo || row.code, group: '数据结果' });
          if (dataHits.value.length >= 5) return;
        }
      }
    }
  } catch { /* 搜索失败只显示菜单结果 */ }
});

/** 通知中心 */
const aiVisible = ref(false);
const notifyVisible = ref(false);
const notifies = ref<any[]>([]);
const unread = computed(() => notifies.value.filter((n) => !n.is_read && !n.isRead).length);
async function openNotify() {
  notifyVisible.value = true;
  try { notifies.value = (await sysApi.notifies() as any[]); } catch { notifies.value = []; }
}
async function readNotify(n: any) {
  await sysApi.readNotify(n.id);
  n.isRead = 1; n.is_read = 1;
}

/** 退出登录 */
function logout() { userStore.logout(); router.push('/login'); }
/** 反馈入口：直接跳转到系统工单/反馈页 */
function feedback() { go('system/feedback'); toast.info('已打开反馈入口，可提交问题与建议'); }

/** 新特性提示：版本变更时弹出一次 */
const featureVisible = ref(false);
const latestVersion = '3.2.0';
function closeFeature(action: 'later' | 'done'): void {
  featureVisible.value = false;
  if (action === 'done') go('system/changelog');
  else localStorage.setItem('erp_changelog_seen', latestVersion);
}

/** 快捷键：全局键盘流，业务页面可通过 erp-shortcut 自定义事件响应 */
const shortcuts = [
  { key: 'Ctrl + K', desc: '打开全局快捷搜索' }, { key: '/', desc: '聚焦搜索框' },
  { key: 'N', desc: '新建（当前页面）' }, { key: 'S', desc: '保存（当前页面）' },
  { key: 'Ctrl + Enter', desc: '提交单据' }, { key: 'P', desc: '打印当前单据' },
  { key: 'Ctrl + Z', desc: '撤销上一步表单编辑' }, { key: 'Ctrl + Y', desc: '重做表单编辑' },
  { key: '?', desc: '打开快捷键面板' }, { key: 'Esc', desc: '关闭弹窗/抽屉' },
];
function onKeydown(e: KeyboardEvent) {
  const tag = (e.target as HTMLElement)?.tagName;
  const typing = ['INPUT', 'TEXTAREA', 'SELECT'].includes(tag);
  if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') { e.preventDefault(); searchVisible.value = true; return; }
  // 撤销/重做：输入框内交给浏览器原生处理，非输入态统一派发给当前页面
  if ((e.ctrlKey || e.metaKey) && !typing && e.key.toLowerCase() === 'z') { e.preventDefault(); window.dispatchEvent(new CustomEvent('erp-shortcut', { detail: 'undo' })); return; }
  if ((e.ctrlKey || e.metaKey) && !typing && (e.key.toLowerCase() === 'y' || (e.shiftKey && e.key.toLowerCase() === 'z'))) { e.preventDefault(); window.dispatchEvent(new CustomEvent('erp-shortcut', { detail: 'redo' })); return; }
  if (!typing && e.key === '/') { e.preventDefault(); searchVisible.value = true; return; }
  if (e.key === 'Escape') { searchVisible.value = false; shortcutVisible.value = false; aiVisible.value = false; notifyVisible.value = false; return; }
  if (typing) return;
  if (e.key === '?') { shortcutVisible.value = true; return; }
  const map: Record<string, string> = { n: 'new', s: 'save', p: 'print' };
  const action = map[e.key.toLowerCase()];
  if (action || (e.ctrlKey && e.key === 'Enter')) {
    window.dispatchEvent(new CustomEvent('erp-shortcut', { detail: e.ctrlKey && e.key === 'Enter' ? 'submit' : action }));
  }
}
const shortcutVisible = ref(false);

onMounted(() => {
  // 恢复上次标签页
  try {
    const saved = JSON.parse(localStorage.getItem('erp_tabs') || '[]');
    if (Array.isArray(saved)) tabs.value = saved;
  } catch { /* 忽略损坏数据 */ }
  document.title = 'LEO ERP · 一体化经营管理';
  if (localStorage.getItem('erp_changelog_seen') !== latestVersion) featureVisible.value = true;
  window.addEventListener('keydown', onKeydown);
});
onBeforeUnmount(() => window.removeEventListener('keydown', onKeydown));
</script>

<style scoped>
.erp-shell { height: 100%; display: flex; flex-direction: column; }
.erp-body { flex: 1; min-height: 0; display: flex; }
.erp-kbd { margin-left: 6px; padding: 1px 5px; border: 1px solid var(--ds-border); border-radius: 4px; font-size: 11px; color: var(--ds-text-3); }
.erp-dot { display: inline-block; min-width: 16px; height: 16px; line-height: 16px; border-radius: 8px; background: var(--ds-danger); color: #fff; font-size: 11px; text-align: center; }
.erp-user { font-size: var(--ds-font-sm); color: var(--ds-text-2); }
.erp-search-results { margin-top: 10px; max-height: 360px; overflow: auto; border: 1px solid var(--ds-border); border-radius: var(--ds-radius); }
.erp-search-item { display: flex; align-items: center; gap: 10px; padding: 9px 12px; border-bottom: 1px solid var(--ds-divider); cursor: pointer; font-size: var(--ds-font-sm); }
.erp-search-item:last-child { border-bottom: none; }
.erp-search-item.active, .erp-search-item:hover { background: var(--ds-brand-soft); }
.erp-search-item small { margin-left: auto; color: var(--ds-text-3); }
.erp-empty { padding: 30px; text-align: center; color: var(--ds-text-3); font-size: var(--ds-font-sm); }
.erp-modal-foot { display: flex; justify-content: flex-end; }
.erp-shortcuts { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }
.erp-shortcut { display: flex; align-items: center; gap: 10px; font-size: var(--ds-font-sm); }
.erp-shortcut kbd { min-width: 68px; text-align: center; padding: 4px 8px; border: 1px solid var(--ds-border); border-radius: 6px; background: var(--ds-bg-soft); }
.erp-notify { padding: 10px 12px; border-bottom: 1px solid var(--ds-divider); cursor: pointer; }
.erp-notify b { font-size: var(--ds-font-sm); }
.erp-notify p { margin: 4px 0; font-size: var(--ds-font-xs); color: var(--ds-text-2); }
.erp-notify small { color: var(--ds-text-3); font-size: 11px; }
.erp-feature { font-size: 13px; line-height: 1.8; color: var(--ds-text-2); }
.erp-feature ul { padding-left: 18px; margin: 8px 0 0; }
</style>
