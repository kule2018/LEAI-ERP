/**
 * 应用入口。
 * ---------------------------------------------------------------------------
 * 说明：
 *   1. 安装 Ds 设计系统（apps/web/src/components）：全站统一品牌蓝、圆角、字号、间距；
 *   2. 全站统一使用 Ds 自有设计系统，不依赖任何第三方 UI 框架；
 *   3. 权限指令 v-perm 全局注册，与后端 @RequirePerm 权限码保持一致。
 */
import { createApp } from 'vue';
import { createPinia } from 'pinia';
import App from './App.vue';
import { router } from './router';
import { vPerm } from './directives/v-perm';
import { installDsUi, useTheme } from './components';
import 'uno.css';
import './styles/index.css';
import { t, loadLanguagePacks } from './i18n';
import { installTelemetry } from './utils/telemetry';
import { installEventSubscribers } from './utils/eventSubscribers';

const app = createApp(App);

app.use(createPinia());
app.use(router);

/** 安装 65 个 Ds/Base 组件 + 主题样式，组件可在任意 SFC 直接以标签使用 */
installDsUi(app);

/** 权限指令：v-perm="'sales:order:create'" */
app.directive('perm', vPerm);

/**
 * 加载遮罩指令：兼容历史 v-loading="boolean" 写法，用纯 CSS/Ds 令牌实现，
 * 不依赖 Element Plus。绑定值 true 时在元素上叠加半透明遮罩与旋转指示器。
 */
app.directive('loading', {
  mounted(el: HTMLElement, binding) {
    el.classList.add('ds-loading-host');
    if (binding.value) el.classList.add('is-loading');
  },
  updated(el: HTMLElement, binding) {
    if (binding.value !== binding.oldValue) el.classList.toggle('is-loading', !!binding.value);
  },
});

/** 国际化：$t('common.save') 可在任意模板使用；语言包从本地恢复 */
app.config.globalProperties.$t = t;
try {
  const packs = JSON.parse(localStorage.getItem('erp_language_packs') || '[]');
  if (Array.isArray(packs)) loadLanguagePacks(packs);
} catch { /* 语言包损坏时忽略，使用内置文案 */ }

/** 初始化明暗主题（用户上次选择优先，否则跟随系统） */
useTheme();

/** 操作埋点：路由切换、点击、停留时长，20 条批量上报 */
installTelemetry((handler) => router.afterEach((to) => handler(to.fullPath)));

/** 全局领域事件订阅：库存变动/订单确认/审批完成等转为通知，接通跨页面联动 */
installEventSubscribers();

app.mount('#app');
