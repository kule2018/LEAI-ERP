/** 每个菜单绑定一个独立的路由组件。 */
import { createRouter, createWebHashHistory } from 'vue-router';
import type { RouteRecordRaw } from 'vue-router';
import { MENUS, type MenuEntry } from '../config/erp';

const pageModules = import.meta.glob('../views/**/*.vue');
const definedPaths = new Set<string>();
const definedViews = new Set<string>();

function resolvePage(item: MenuEntry) {
  const loader = pageModules[`../views/${item.view}.vue`];
  if (!loader) throw new Error(`页面组件不存在：${item.path}（${item.view}）`);
  if (definedPaths.has(item.path)) throw new Error(`路由重复：${item.path}`);
  if (definedViews.has(item.view)) throw new Error(`路由组件重复：${item.view}`);
  definedPaths.add(item.path);
  definedViews.add(item.view);
  return loader;
}

/**
 * 把一个菜单项转换成路由记录。
 * @param item 菜单项
 * @returns Vue Router 路由记录
 */
function toRoute(item: MenuEntry): RouteRecordRaw {
  return {
    path: item.path,
    name: item.path.replace(/[/:]/g, '-'),
    component: resolvePage(item) as any,
    meta: {
      title: item.title,
      group: item.group,
      icon: item.icon,
      perm: item.perm,
      hidden: item.hidden,
      view: item.view,
      api: item.api,
      entity: item.entity,
      statusField: item.statusField,
      statusLabels: item.statusLabels,
      actions: item.actions,
    },
  };
}

const children = MENUS.map(toRoute);

/** 全量路由定义 */
const routes: RouteRecordRaw[] = [
  { path: '/login', name: 'login', component: () => import('../views/login/index.vue'), meta: { public: true, title: '登录' } },
  {
    path: '/',
    component: () => import('../layout/index.vue'),
    redirect: '/dashboard',
    children,
  },
  { path: '/:pathMatch(.*)*', redirect: '/dashboard' },
];

export const router = createRouter({ history: createWebHashHistory(), routes });

/**
 * 权限校验：未登录跳登录页；权限码支持 * 与 sales:* 两种通配。
 */
router.beforeEach((to) => {
  if (to.meta.public) return true;
  const token = localStorage.getItem('erp_token');
  if (!token) return { path: '/login' };
  const user = JSON.parse(localStorage.getItem('erp_user') || 'null');
  const perm = to.meta.perm as string | undefined;
  if (perm && user) {
    const perms: string[] = user.permissions || [];
    const ok = perms.includes('*') || perms.includes(perm) || perms.some((p) => p.endsWith(':*') && perm.startsWith(p.slice(0, -1)));
    if (!ok) return { path: '/dashboard' };
  }
  return true;
});

/**
 * 侧栏菜单：由全量配置生成（保留权限过滤）。
 * @returns 分组后的菜单数组
 */
export function buildMenus() {
  const user = JSON.parse(localStorage.getItem('erp_user') || 'null');
  const perms: string[] = user?.permissions || [];
  const groups: Array<{ group: string; items: MenuEntry[] }> = [];
  for (const item of MENUS) {
    if (item.hidden) continue;
    if (item.perm) {
      const ok = perms.includes('*') || perms.includes(item.perm) || perms.some((p) => p.endsWith(':*') && item.perm!.startsWith(p.slice(0, -1)));
      if (!ok) continue;
    }
    let g = groups.find((x) => x.group === item.group);
    if (!g) { g = { group: item.group, items: [] }; groups.push(g); }
    g.items.push(item);
  }
  return groups;
}

export { routes };
