import { defineStore } from 'pinia';
import { authApi, sysApi, inventoryApi } from '../api';

/** 用户状态：Token、权限、用户信息 */
export const useUserStore = defineStore('user', {
  state: () => ({
    token: localStorage.getItem('erp_token') || '',
    userInfo: JSON.parse(localStorage.getItem('erp_user') || 'null') as any,
  }),
  getters: {
    permissions: (s) => s.userInfo?.permissions || [],
    realName: (s) => s.userInfo?.realName || '未登录',
  },
  actions: {
    async login(dto: any) {
      const data: any = await authApi.login(dto);
      this.token = data.token;
      this.userInfo = data.userInfo;
      localStorage.setItem('erp_token', data.token);
      localStorage.setItem('erp_user', JSON.stringify(data.userInfo));
    },
    logout() {
      this.token = ''; this.userInfo = null;
      localStorage.removeItem('erp_token'); localStorage.removeItem('erp_user');
    },
    hasPerm(code: string) {
      if (!code) return true;
      const perms = this.permissions;
      return perms.includes(code) || perms.includes('*') || perms.some((p: string) => p.endsWith(':*') && code.startsWith(p.slice(0, -1)));
    },
  },
});

/** 应用状态：侧栏折叠、标签页 */
export const useAppStore = defineStore('app', {
  state: () => ({ collapsed: false, tabs: [] as any[] }),
  actions: {
    toggle() { this.collapsed = !this.collapsed; },
  },
});

/** 字典缓存 */
export const useDictStore = defineStore('dict', {
  state: () => ({ map: {} as Record<string, any[]> }),
  actions: {
    async load(code: string) {
      if (!this.map[code]) this.map[code] = await sysApi.dict(code);
      return this.map[code];
    },
  },
});

/** 基础数据缓存：仓库/分类，表单下拉复用 */
export const useBaseStore = defineStore('base', {
  state: () => ({ warehouses: [] as any[], categories: [] as any[] }),
  actions: {
    async ensure() {
      if (!this.warehouses.length) this.warehouses = await inventoryApi.warehouses();
      if (!this.categories.length) this.categories = await inventoryApi.categories();
    },
  },
});
