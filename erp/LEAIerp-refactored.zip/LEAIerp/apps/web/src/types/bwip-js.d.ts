/**
 * bwip-js 类型补丁。
 * ---------------------------------------------------------------------------
 * 包自带的 exports 条件类型在部分 TypeScript/bundler 组合下无法被解析，
 * 这里补充打印标签设计器实际用到的 toSVG 接口，保证 vue-tsc 能通过。
 */
declare module 'bwip-js' {
  export interface BwipOptions {
    /** 条码类型：code128 / ean13 / qrcode 等 */
    bcid?: string;
    /** 编码内容 */
    text?: string;
    /** 缩放比例 */
    scale?: number;
    /** 条码高度（毫米，二维码忽略） */
    height?: number;
    [key: string]: unknown;
  }
  const bwipjs: {
    /** 生成条码 SVG 字符串 */
    toSVG(options: BwipOptions): string;
  };
  export default bwipjs;
}
