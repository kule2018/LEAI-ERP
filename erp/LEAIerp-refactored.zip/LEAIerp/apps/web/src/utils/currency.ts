/**
 * 多币种与汇率换算（文档第 13 章）。
 * ---------------------------------------------------------------------------
 * 本币固定为 CNY；汇率保存在本地业务数据（sys_currency / sys_exchange_rate），
 * 无配置时使用内置演示汇率。换算遵循「原币金额 ÷ 原币对 CNY 汇率 = 本币金额」。
 */
export interface Currency {
  code: string;
  name: string;
  symbol: string;
  rate: number;
}

/** 演示汇率（1 单位外币 = X 人民币） */
const demoRates: Record<string, number> = { CNY: 1, USD: 7.24, EUR: 7.86, JPY: 0.048, HKD: 0.93 };

/** 读取币种列表：本地数据优先，失败回退演示数据 */
export function currencies(): Currency[] {
  const list: Currency[] = [
    { code: 'CNY', name: '人民币', symbol: '¥', rate: 1 },
    { code: 'USD', name: '美元', symbol: '$', rate: demoRates.USD },
    { code: 'EUR', name: '欧元', symbol: '€', rate: demoRates.EUR },
    { code: 'JPY', name: '日元', symbol: '¥', rate: demoRates.JPY },
    { code: 'HKD', name: '港币', symbol: 'HK$', rate: demoRates.HKD },
  ];
  try {
    const raw = localStorage.getItem('erp_mock_db_v3');
    if (!raw) return list;
    const db = JSON.parse(raw);
    for (const row of db.sysExchangeRates || db.exchangeRates || []) {
      const target = list.find((c) => c.code === row.code || c.code === row.currency);
      if (target) target.rate = Number(row.rate || row.rateToCny || target.rate);
    }
  } catch { /* 配置损坏时使用演示汇率 */ }
  return list;
}

/** 取指定币种汇率（对 CNY） */
export function rateOf(code: string): number {
  return currencies().find((c) => c.code === code)?.rate || 1;
}

/**
 * 金额换算为人民币。
 * @param amount 原币金额
 * @param code 原币币种
 * @returns 保留 2 位小数的本币金额
 */
export function toCny(amount: number, code: string): number {
  return Math.round(amount * rateOf(code) * 100) / 100;
}

/** 金额格式化：带币种符号 */
export function formatMoney(amount: number, code = 'CNY'): string {
  const currency = currencies().find((c) => c.code === code);
  return `${currency?.symbol || ''}${Number(amount || 0).toFixed(2)} ${code}`;
}
