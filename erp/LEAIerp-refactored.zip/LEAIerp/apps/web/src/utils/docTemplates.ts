/**
 * 单据常用方案（文档第 27 章）。
 * ---------------------------------------------------------------------------
 * 把「常用商品组合 / 常用费用项」保存为本地方案，开单时一键套用，
 * 避免每次重复录入相同明细；方案随浏览器账号维度保存在 localStorage。
 */
export interface DocTemplate {
  id: number;
  name: string;
  bizType: string;
  lines: Array<{ productId: any; qty: string; unitPrice: string; discount: string; amount: string }>;
  createdAt: string;
}

const KEY = 'erp_doc_templates';

/** 读取全部方案 */
export function listTemplates(bizType = 'SALE'): DocTemplate[] {
  try {
    const all: DocTemplate[] = JSON.parse(localStorage.getItem(KEY) || '[]');
    return all.filter((t) => t.bizType === bizType);
  } catch { return []; }
}

/** 保存当前明细为方案；同名覆盖 */
export function saveTemplate(name: string, bizType: string, lines: DocTemplate['lines']): DocTemplate[] {
  const all: DocTemplate[] = listTemplates(bizType);
  const index = all.findIndex((t) => t.name === name);
  const record: DocTemplate = { id: index >= 0 ? all[index].id : Date.now(), name, bizType, lines: JSON.parse(JSON.stringify(lines)), createdAt: new Date().toLocaleString('zh-CN') };
  if (index >= 0) all[index] = record; else all.push(record);
  localStorage.setItem(KEY, JSON.stringify(all));
  return all;
}

/** 删除方案 */
export function removeTemplate(id: number): void {
  try {
    const all: DocTemplate[] = JSON.parse(localStorage.getItem(KEY) || '[]');
    localStorage.setItem(KEY, JSON.stringify(all.filter((t) => t.id !== id)));
  } catch { /* 忽略损坏数据 */ }
}
