/**
 * 错误码友好化（文档第 24 章：错误友好化）。
 * ---------------------------------------------------------------------------
 * 目标：把"500"、"STATUS_ILLEGAL"这类裸错误码转成人话 + 解决建议，
 * 让用户看到报错后能自己判断下一步怎么做，而不是只看到一串代码。
 */
export interface FriendlyError {
  /** 给用户看的中文说明 */
  message: string;
  /** 可操作的解决建议，没有则为空串 */
  suggestion: string;
}

/** 已知错误码 -> 友好文案 */
const ERROR_MAP: Record<string, FriendlyError> = {
  STATUS_ILLEGAL: { message: '单据当前状态不允许这个操作', suggestion: '请刷新页面查看最新状态，或联系管理员确认流程节点' },
  CREDIT_LIMIT_EXCEEDED: { message: '客户信用额度不足', suggestion: '请减少本次开单金额，或先在客户档案中调整信用额度' },
  STOCK_NOT_ENOUGH: { message: '可用库存不足', suggestion: '请核对仓库与数量，或通过「库存预警」查看补货建议' },
  PERIOD_LOCKED: { message: '该会计期间已结账', suggestion: '需要修改请先由财务在有权限时执行反结账' },
  PARAM_INVALID: { message: '提交的数据格式有误', suggestion: '请检查必填项与数字格式后重试' },
  VOUCHER_UNBALANCED: { message: '凭证借贷不平衡', suggestion: '请检查分录金额，借方合计必须等于贷方合计' },
  DUPLICATE_CODE: { message: '编码已存在', suggestion: '请更换编码；若启用编码规则，可点击「重新生成」' },
  NETWORK_ERROR: { message: '无法连接服务器', suggestion: '请检查网络或后端服务' },
  TIMEOUT: { message: '请求超时', suggestion: '请稍后重试；大文件导入可到导入导出中心查看后台进度' },
  FORBIDDEN: { message: '没有执行此操作的权限', suggestion: '请联系管理员为你的角色分配对应权限码' },
  UNAUTHORIZED: { message: '登录状态已失效', suggestion: '请重新登录后再试' },
};

/** HTTP 状态码 -> 友好文案 */
const HTTP_MAP: Record<number, FriendlyError> = {
  400: { message: '提交的内容有误', suggestion: '请检查表单填写是否完整、正确' },
  401: { message: '登录状态已失效', suggestion: '请重新登录' },
  403: { message: '没有访问权限', suggestion: '请联系管理员分配权限' },
  404: { message: '找不到请求的数据', suggestion: '数据可能已被删除，请刷新列表' },
  409: { message: '数据发生冲突', suggestion: '其他人可能已修改该数据，请刷新后重试' },
  422: { message: '业务规则校验未通过', suggestion: '请按提示调整单据内容' },
  429: { message: '操作太频繁', suggestion: '请稍等几秒再试' },
  500: { message: '系统开小差了', suggestion: '请稍后重试；若反复出现请通过右下角「反馈」提交问题' },
  503: { message: '服务暂时不可用', suggestion: '请等待服务恢复后重试' },
};

/**
 * 把任意错误转换成可展示的友好文案。
 * @param error 原始错误（Axios 错误、{code,message} 对象或字符串）
 * @returns 包含说明与建议的对象
 */
export function friendlyError(error: any): FriendlyError {
  // 已经是标准响应体时，优先按业务码匹配
  const code = error?.response?.data?.code ?? error?.code;
  const rawMessage = error?.response?.data?.message ?? error?.message;
  if (typeof code === 'string' && ERROR_MAP[code]) return ERROR_MAP[code];
  if (typeof code === 'number' && HTTP_MAP[code]) return HTTP_MAP[code];

  const status = Number(error?.response?.status);
  if (HTTP_MAP[status]) return HTTP_MAP[status];
  if (String(rawMessage || '').includes('timeout')) return ERROR_MAP.TIMEOUT;

  // 后端返回了可读消息时保留它，但补一句兜底建议
  if (rawMessage && !['Network Error', 'Request failed with status code'].includes(rawMessage)) {
    return { message: rawMessage, suggestion: '若问题持续，请通过「反馈」入口提交截图' };
  }
  return ERROR_MAP.NETWORK_ERROR;
}
