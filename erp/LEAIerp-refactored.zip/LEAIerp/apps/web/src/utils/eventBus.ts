/**
 * 全局轻量事件总线（文档第 16 章：消息订阅 / 事件总线）。
 * ---------------------------------------------------------------------------
 * 设计原因：项目已不引入额外依赖，用 Map + Set 实现一个最小可用总线即可。
 * 用途：单据状态变更、库存变动、审批待办、打印任务、AI 流式结果等跨页面通知。
 * 不引入 once/wildcard 等复杂语义，保持"发什么、收什么"直观可控。
 */
type EventHandler = (payload?: any) => void;

/** 事件名 -> 处理器集合 */
const channels = new Map<string, Set<EventHandler>>();

/**
 * 订阅事件。
 * @param event 事件名，如 'order:confirmed'、'stock:changed'
 * @param handler 处理函数
 * @returns 取消订阅函数（调用后不再收到该事件）
 */
export function on(event: string, handler: EventHandler): () => void {
  if (!channels.has(event)) channels.set(event, new Set());
  channels.get(event)!.add(handler);
  return () => off(event, handler);
}

/**
 * 取消订阅。
 * @param event 事件名
 * @param handler 之前传入 on 的同一个函数引用
 * @returns 无
 */
export function off(event: string, handler: EventHandler): void {
  channels.get(event)?.delete(handler);
}

/**
 * 发布事件，同步通知所有订阅者；单个订阅者报错不影响其他订阅者。
 * @param event 事件名
 * @param payload 事件载荷
 * @returns 无
 */
export function emit(event: string, payload?: any): void {
  // 事件落盘：即使当前无页面订阅也留痕，供「变更订阅」页与 Mock 事件流读取
  try {
    const events = JSON.parse(localStorage.getItem('erp_domain_events') || '[]');
    events.push({ id: Date.now() + Math.floor(Math.random() * 1000), level: event.includes('stock') ? 'high' : 'normal', title: event, detail: JSON.stringify(payload || {}).slice(0, 120), createdAt: new Date().toLocaleString('zh-CN') });
    localStorage.setItem('erp_domain_events', JSON.stringify(events.slice(-100)));
  } catch { /* 本地存储不可用时不影响事件派发 */ }
  const handlers = channels.get(event);
  if (!handlers) return;
  for (const handler of [...handlers]) {
    try { handler(payload); }
    catch (error) { console.error(`[事件总线] 处理 ${event} 失败：`, error); }
  }
}

/** 供需要对象风格调用的页面使用 */
export const eventBus = { on, off, emit };

/** 常用事件名常量，避免各页面拼写不一致 */
export const Events = {
  ORDER_CONFIRMED: 'order:confirmed',
  ORDER_SHIPPED: 'order:shipped',
  STOCK_CHANGED: 'stock:changed',
  APPROVAL_DONE: 'approval:done',
  PRINT_DONE: 'print:done',
  AI_ADOPTED: 'ai:adopted',
  NOTIFY_RECEIVED: 'notify:received',
  DATA_RELOADED: 'data:reloaded',
} as const;
