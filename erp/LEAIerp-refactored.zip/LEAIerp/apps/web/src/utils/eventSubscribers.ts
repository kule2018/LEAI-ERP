/**
 * 全局领域事件订阅：把事件总线上的业务事件落地为通知中心消息。
 * ------------------------------------------------------------------
 * 背景：eventBus 此前只有 emit（仅落 localStorage），全库无 on 订阅，
 *       导致库存变动/订单确认/审批完成/打印完成等跨页面联动"发了没人收"。
 * 方案：应用启动时统一注册一次订阅，事件触发后通过 sysApi.addNotify 写入
 *       通知中心，用户在顶栏铃铛即可看到，实现真正的跨页面联动闭环。
 */
import { on, Events } from './eventBus';
import { sysApi } from '../api';

interface EventRule {
  event: string;
  title: string;
  detail: (p: any) => string;
}

const RULES: EventRule[] = [
  { event: Events.STOCK_CHANGED, title: '库存变动', detail: (p) => `${p?.type || '库存操作'}：产品 #${p?.productId ?? '-'} 数量 ${p?.qty ?? '-'}` },
  { event: Events.ORDER_CONFIRMED, title: '订单已确认', detail: (p) => `业务单据 #${p?.bizId ?? p?.id ?? '-'} 已确认` },
  { event: Events.ORDER_SHIPPED, title: '订单已发货', detail: (p) => `业务单据 #${p?.bizId ?? p?.id ?? '-'} 已发货${p?.invoiceNo ? `，发票 ${p.invoiceNo}` : ''}` },
  { event: Events.APPROVAL_DONE, title: '审批完成', detail: (p) => `${p?.title || '审批任务'} ${p?.approved === false ? '被驳回' : '已通过'}` },
  { event: Events.PRINT_DONE, title: '打印完成', detail: (p) => `打印任务 ${p?.taskId ?? p?.id ?? '-'} 已完成` },
  { event: Events.AI_ADOPTED, title: 'AI 建议已采纳', detail: (p) => `${p?.title || 'AI 建议'}已采纳` },
  { event: Events.NOTIFY_RECEIVED, title: '新消息', detail: (p) => p?.content || p?.title || '收到一条新消息' },
  { event: Events.DATA_RELOADED, title: '数据已刷新', detail: (p) => p?.message || '基础数据已更新' },
];

let installed = false;

/** 注册全局事件订阅（幂等，重复调用只生效一次） */
export function installEventSubscribers(): void {
  if (installed) return;
  installed = true;
  for (const rule of RULES) {
    on(rule.event, (payload) => {
      try {
        void sysApi.addNotify({
          title: rule.title,
          content: rule.detail(payload || {}),
          createdAt: new Date().toLocaleString('zh-CN'),
        });
      } catch { /* 通知写入失败不影响业务事件本身 */ }
    });
  }
}
