/**
 * 字段级脱敏（文档第 32 章：字段级脱敏与列级权限）。
 * ---------------------------------------------------------------------------
 * 规则按字段名识别：手机号、身份证、银行卡、成本价。
 * 是否脱敏由系统参数 `security.mask.enabled` 决定，且拥有 `*:sensitive:view`
 * 权限的用户可查看原文（列级权限）。这样既不改数据结构，也能满足合规要求。
 */
function param(name: string): string {
  try {
    const raw = localStorage.getItem('erp_mock_db_v3');
    if (!raw) return '';
    const db = JSON.parse(raw);
    return String(db.configs?.find((c: any) => (c.cfgKey || c.key) === name)?.cfgValue ?? '');
  } catch { return ''; }
}

/** 当前用户是否可查看敏感原文 */
function canViewRaw(): boolean {
  try {
    const user = JSON.parse(localStorage.getItem('erp_user') || '{}');
    return (user.permissions || []).includes('*') || (user.permissions || []).includes('*:sensitive:view');
  } catch { return false; }
}

/** 是否开启脱敏：默认开启，管理员可在系统参数中关闭 */
export function maskEnabled(): boolean {
  return param('security.mask.enabled') !== '0' && !canViewRaw();
}

/** 保留头尾、中间打星 */
function keepEnds(value: string, head: number, tail: number): string {
  if (value.length <= head + tail) return value;
  return value.slice(0, head) + '*'.repeat(Math.min(6, value.length - head - tail)) + value.slice(-tail);
}

/**
 * 按字段名对值脱敏。
 * @param field 字段名（如 phone / idCard / cost）
 * @param value 原始值
 * @returns 脱敏后的字符串
 */
export function maskField(field: string, value: any): any {
  if (value === null || value === undefined || value === '' || !maskEnabled()) return value;
  const key = field.toLowerCase();
  const text = String(value);
  if (/phone|mobile|tel|电话|手机/.test(key)) return keepEnds(text, 3, 4);
  if (/idcard|identity|身份证/.test(key)) return keepEnds(text, 4, 4);
  if (/bankcard|cardno|银行卡/.test(key)) return keepEnds(text, 4, 4);
  if (/cost|成本/.test(key)) return '****';
  return value;
}

/**
 * 对整行数据脱敏，返回新对象（不修改原数据）。
 * @param row 数据行
 * @returns 脱敏后的新对象
 */
export function maskRow<T extends Record<string, any>>(row: T): T {
  const result: any = { ...row };
  for (const key of Object.keys(result)) result[key] = maskField(key, result[key]);
  return result as T;
}
