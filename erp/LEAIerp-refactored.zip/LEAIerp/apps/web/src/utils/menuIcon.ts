/**
 * 菜单图标统一映射：把历史配置里的 emoji 映射为 Ds 内置线性图标名，
 * 侧边栏用 IconFont 以灰色渲染，形成"全站灰度、立体一致"的图标风格。
 * 未命中的 emoji 统一回退到 Dot，保证任何菜单都有图标且风格统一。
 */
const EMOJI_TO_DS: Record<string, string> = {
  '📊': 'ChartBar', '📈': 'ChartLine', '📉': 'ChartLine', '✅': 'CheckCircle', '☑️': 'CheckCircle',
  '🔔': 'Bell', '📅': 'Calendar', '🤖': 'Sparkles', '🛒': 'Inbox', '👥': 'Users', '👤': 'User',
  '🚚': 'ExternalLink', '🏭': 'Box', '📦': 'Box', '🧩': 'Grid', '🔧': 'Setting', '⚙️': 'Setting',
  '💰': 'File', '📑': 'File', '📒': 'BookOpen', '🏆': 'Star', '📝': 'Edit', '🔀': 'Connection',
  '🏢': 'Home', '🧑‍💼': 'User', '🛍️': 'Inbox', '🖨️': 'File', '📄': 'File', '🔍': 'Search',
  '🧮': 'Grid', '📚': 'BookOpen', '🧠': 'DeepThink', '✍️': 'Edit', '🛠': 'Setting', '🔌': 'Connection',
  '🌐': 'Globe', '📋': 'List', '💬': 'Chat', '🏪': 'Home', '🍽': 'Inbox', '💊': 'Box',
  '👕': 'Tag', '⚖️': 'Aim', '📥': 'Download', '📤': 'Upload', '↩️': 'Regenerate',
  '🧾': 'File', '🎁': 'Star', '🖥': 'Grid', '🏦': 'Home', '💵': 'File', '🗓': 'Calendar',
  '📌': 'Aim', '🔐': 'Setting', '🔎': 'Search', '🚨': 'Warning', '▫️': 'Grid',
};

/** 把配置里的图标（emoji 或已是 Ds 名）解析成 Ds 图标名 */
export function toDsIcon(icon?: string): string {
  if (!icon) return 'Grid';
  // 已是 Ds 图标名（首字母大写且字典中有）直接返回
  if (/^[A-Z]/.test(icon) && !EMOJI_TO_DS[icon]) return icon;
  return EMOJI_TO_DS[icon] || 'Grid';
}
