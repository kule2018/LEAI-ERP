/**
 * 价格策略解析（文档第 28 章：价格体系与优先级）。
 * ---------------------------------------------------------------------------
 * 优先级：客户专属价 > 客户等级价 > 数量阶梯价 > 产品通用售价。
 * 返回价格来源，方便开单界面显示「为什么是这个价」，做到取价可解释。
 */
export interface PriceResult {
  /** 最终单价 */
  price: number;
  /** 价格来源说明 */
  source: string;
}

/** 从本地业务数据读取配置集合 */
function collection(name: string): any[] {
  try {
    const raw = localStorage.getItem('erp_mock_db_v3');
    if (!raw) return [];
    return JSON.parse(raw)[name] || [];
  } catch { return []; }
}

/**
 * 按规则解析产品单价。
 * @param product 产品对象（至少含 id / price）
 * @param customerId 客户 ID
 * @param quantity 本次数量
 * @returns 单价与来源
 */
export function resolvePrice(product: any, customerId: any, quantity: number): PriceResult {
  const basePrice = Number(product?.price || 0);
  if (!customerId) return { price: basePrice, source: '通用售价' };

  // 1. 客户专属价
  const customerPrice = collection('customerPrices').find((p) => Number(p.customerId) === Number(customerId) && Number(p.productId) === Number(product?.id));
  if (customerPrice) return { price: Number(customerPrice.price), source: '客户专属价' };

  // 2. 客户等级价（先取客户等级，再取等级价目表）
  const customer = collection('customers').find((c) => Number(c.id) === Number(customerId));
  const levelPrice = collection('customerLevelPrices').find((p) => p.level === customer?.level && Number(p.productId) === Number(product?.id));
  if (levelPrice) return { price: Number(levelPrice.price), source: `客户等级价（${customer?.level || '等级'}）` };

  // 3. 数量阶梯价
  const tiers = collection('priceTiers').filter((t) => Number(t.productId) === Number(product?.id) && Number(quantity) >= Number(t.minQty));
  if (tiers.length) {
    const best = tiers.sort((a, b) => Number(b.minQty) - Number(a.minQty))[0];
    return { price: Number(best.price), source: `数量阶梯价（≥${best.minQty}）` };
  }

  return { price: basePrice, source: '通用售价' };
}
