/**
 * 促销与优惠结算（文档第 28 章）。
 * ---------------------------------------------------------------------------
 * 优先级：优惠券 > 会员专享活动 > 普通促销活动 > 积分抵现。
 * 返回可追溯的优惠明细，开单界面据此展示「为什么是这个价」。
 */
export interface PromotionResult {
  discount: number;
  payable: number;
  source: string;
  pointsEarned: number;
  detail: string;
}

/** 读取本地业务集合 */
function collection(name: string): any[] {
  try {
    const raw = localStorage.getItem('erp_mock_db_v3');
    if (!raw) return [];
    return JSON.parse(raw)[name] || [];
  } catch { return []; }
}

/**
 * 计算订单优惠。
 * @param amount 优惠前金额
 * @param customerId 客户 ID
 * @param couponCode 优惠券码（可选）
 * @returns 优惠结果与应付金额
 */
export function calcPromotion(amount: number, customerId: any, couponCode = ''): PromotionResult {
  const base = Number(amount || 0);
  const now = Date.now();
  const active = collection('promotions').filter((p) => {
    if (Number(p.isActive ?? p.status) === 0) return false;
    const start = p.startAt ? new Date(p.startAt).getTime() : 0;
    const end = p.endAt ? new Date(p.endAt).getTime() : Number.MAX_SAFE_INTEGER;
    return now >= start && now <= end;
  });
  const coupon = couponCode ? collection('coupons').find((c) => (c.code || c.name) === couponCode) : null;
  const memberOnly = active.find((p) => p.memberOnly && customerId);
  const normal = active.find((p) => !p.memberOnly);

  let discount = 0;
  let source = '无优惠';
  if (coupon) {
    discount = coupon.type === 'FIXED' ? Number(coupon.value || 0) : base * Number(coupon.value || 0) / 100;
    source = `优惠券 ${coupon.code || coupon.name}`;
  } else if (memberOnly) {
    discount = base * Number(memberOnly.discount || 10) / 100;
    source = `会员专享 ${memberOnly.name}`;
  } else if (normal) {
    discount = base * Number(normal.discount || 10) / 100;
    source = `促销活动 ${normal.name}`;
  }
  discount = Math.min(base, Math.round(discount * 100) / 100);
  return {
    discount,
    payable: Math.round((base - discount) * 100) / 100,
    source,
    pointsEarned: Math.floor(base / 100),
    detail: `${source}，优惠 ${discount.toFixed(2)}，应付 ${(base - discount).toFixed(2)}，预计获得 ${Math.floor(base / 100)} 积分`,
  };
}
