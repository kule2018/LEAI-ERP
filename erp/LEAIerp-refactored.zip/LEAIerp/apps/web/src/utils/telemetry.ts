/**
 * 轻量操作埋点（文档第 20 章：页面停留、点击、放弃步骤）。
 * ---------------------------------------------------------------------------
 * 不引入第三方 SDK：本地队列 + 批量上报，后端未提供接口时静默降级，
 * 不影响业务操作。真实环境把 flush 里的 mockPost 换成上报 API 即可。
 */
export interface TrackEvent {
  type: 'pageview' | 'click' | 'stay' | 'abandon' | 'error';
  page: string;
  target?: string;
  durationMs?: number;
  at: string;
}

const KEY = 'erp_telemetry_queue';
let queue: TrackEvent[] = [];

/** 从本地恢复未上报事件 */
function restore(): void {
  try { queue = JSON.parse(localStorage.getItem(KEY) || '[]'); } catch { queue = []; }
}
restore();

/** 记录一条事件（满 20 条自动上报） */
export function track(type: TrackEvent['type'], page: string, extra: Partial<TrackEvent> = {}): void {
  queue.push({ type, page, at: new Date().toISOString(), ...extra });
  if (queue.length >= 20) void flush();
  else persist();
}
function persist(): void { try { localStorage.setItem(KEY, JSON.stringify(queue.slice(-200))); } catch { /* 忽略存储异常 */ } }

/** 批量上报；演示环境直接清空队列并写入统计快照 */
export async function flush(): Promise<void> {
  if (!queue.length) return;
  const batch = queue.slice();
  queue = [];
  persist();
  try {
    const { mockPost } = await import('../api/mockAdapter');
    await mockPost('/api/v1/ux/telemetry/batch', { events: batch });
  } catch { /* 上报失败不影响业务 */ }
}

/**
 * 安装全局埋点：页面切换记 pageview，点击记 click，页面卸载记停留时长。
 * @param onRouteChange 路由变化订阅函数（由 main.ts 传入 router.afterEach 注册）
 */
export function installTelemetry(onRouteChange: (handler: (to: string) => void) => void): void {
  let current = location.hash || '/';
  let entered = Date.now();
  onRouteChange((to) => {
    track('stay', current, { durationMs: Date.now() - entered });
    current = to; entered = Date.now();
    track('pageview', current);
  });
  document.addEventListener('click', (event) => {
    const element = event.target as HTMLElement;
    const label = element?.getAttribute('aria-label') || element?.textContent?.trim().slice(0, 30) || element?.tagName;
    if (label) track('click', current, { target: label });
  }, true);
  window.addEventListener('beforeunload', () => { track('stay', current, { durationMs: Date.now() - entered }); void flush(); });
}

/** 读取埋点统计快照（供系统诊断页展示） */
export function stats(): { total: number; byType: Record<string, number> } {
  const all = queue.slice();
  const byType: Record<string, number> = {};
  for (const e of all) byType[e.type] = (byType[e.type] || 0) + 1;
  return { total: all.length, byType };
}
