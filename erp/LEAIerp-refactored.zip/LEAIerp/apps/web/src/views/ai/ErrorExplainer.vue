<!-- 可复用异常解释组件：传入错误码 / 消息 / 上下文，按钮触发 AI 解释并展示处置步骤 -->
<template>
  <div class="err-explain">
    <div class="err-head">
      <DsTag color="danger" size="sm">{{ code }}</DsTag>
      <span class="err-msg">{{ message }}</span>
    </div>
    <div v-if="context" class="err-context">上下文：{{ context }}</div>
    <div class="err-actions">
      <DsButton variant="ghost" size="sm" :loading="loading" @click="explain">AI 解释异常</DsButton>
    </div>
    <div v-if="answer" class="err-answer">
      <div class="err-answer-title">
        AI 诊断建议
        <DsTag v-if="fallback" color="warning" size="sm">规则兜底</DsTag>
      </div>
      <pre>{{ answer }}</pre>
    </div>
  </div>
</template>

<script setup lang="ts">
/** ErrorExplainer —— 通用 AI 异常解释卡片，可被任意业务页复用 */
import { ref } from 'vue';
import { aiApi } from '../../api';
import { useToast } from '../../components/ds/toast';

const props = defineProps<{
  /** 错误码 */
  code: string | number;
  /** 错误消息 */
  message: string;
  /** 附加上下文（接口名 / 单据号 / 操作人等） */
  context?: string;
}>();

const toast = useToast();
const loading = ref(false);
const answer = ref('');
const fallback = ref(false);

/** 调用 copilot 解释异常，说明原因并给出处置步骤 */
async function explain(): Promise<void> {
  if (loading.value) return;
  loading.value = true;
  answer.value = '';
  try {
    const prompt = `错误 ${props.code}: ${props.message}，上下文 ${props.context || '无'}，请给出原因和处置步骤`;
    const r: any = await aiApi.copilot(prompt);
    answer.value = r.text || r.message || '（AI 未返回内容）';
    fallback.value = !!r.fallback;
  } catch (e: any) {
    answer.value = '解释失败：' + (e?.message || '网络错误');
    toast.error(answer.value);
  } finally {
    loading.value = false;
  }
}
</script>

<style scoped>
.err-explain { background: var(--ds-bg-elevated); border: 1px solid var(--ds-border); border-radius: var(--ds-radius-lg); padding: 14px 16px; }
.err-head { display: flex; align-items: center; gap: 8px; }
.err-msg { font-size: 13px; color: var(--ds-text); }
.err-context { margin-top: 8px; font-size: 12px; color: var(--ds-text-3); }
.err-actions { margin-top: 10px; }
.err-answer { margin-top: 12px; background: var(--ds-bg-soft); border-radius: var(--ds-radius); padding: 10px 12px; }
.err-answer-title { display: flex; align-items: center; gap: 8px; font-size: 13px; font-weight: 600; color: var(--ds-text-2); margin-bottom: 6px; }
.err-answer pre { margin: 0; white-space: pre-wrap; word-break: break-word; font-size: 12px; line-height: 1.6; color: var(--ds-text-2); font-family: inherit; }
</style>
