<!-- AI 能力配置台：Function 工具管理（JSON Schema 校验 / 启停 / 模拟调用测试） -->
<template>
  <div class="erp-page">
    <DsCard title="Function 工具管理" subtitle="维护可供模型调用的工具；参数使用 JSON Schema 描述，可模拟调用并查看返回" :pad="false">
      <template #extra><DsButton variant="primary" size="sm" @click="openForm()">新增工具</DsButton></template>
      <table class="ft-table">
        <thead>
          <tr><th>工具名</th><th>描述</th><th>调用端点</th><th>权限码</th><th>参数 Schema</th><th>状态</th><th>操作</th></tr>
        </thead>
        <tbody>
          <tr v-for="row in rows" :key="row.id">
            <td class="ft-mono"><b>{{ row.name }}</b></td>
            <td class="ft-desc">{{ row.description }}</td>
            <td class="ft-mono">{{ row.endpoint }}</td>
            <td class="ft-mono">{{ row.permission || '-' }}</td>
            <td class="ft-mono ft-ellipsis" :title="row.schema">{{ schemaSummary(row.schema) }}</td>
            <td><DsTag :color="row.isActive ? 'success' : 'neutral'" size="sm">{{ row.isActive ? '启用' : '停用' }}</DsTag></td>
            <td class="ft-ops">
              <DsButton variant="text" size="sm" @click="openForm(row)">编辑</DsButton>
              <DsButton variant="text" size="sm" @click="toggle(row)">{{ row.isActive ? '停用' : '启用' }}</DsButton>
              <DsButton variant="primary" size="sm" @click="openTest(row)">调用测试</DsButton>
            </td>
          </tr>
          <tr v-if="!rows.length"><td colspan="7" class="ft-empty">暂无工具配置</td></tr>
        </tbody>
      </table>
    </DsCard>

    <!-- 新增 / 编辑工具 -->
    <DsModal v-model="formVisible" :title="form.id ? '编辑工具' : '新增工具'" :width="680">
      <div class="ft-form">
        <label><span>工具名（英文标识）</span><input v-model="form.name" class="ds-input" placeholder="如 query_stock" /></label>
        <label><span>权限码</span><input v-model="form.permission" class="ds-input" placeholder="如 inventory:balance:view" /></label>
        <label class="full"><span>描述</span><input v-model="form.description" class="ds-input" placeholder="工具用途说明" /></label>
        <label class="full"><span>调用端点</span><input v-model="form.endpoint" class="ds-input" placeholder="如 /api/v1/inventory/balance" /></label>
        <label>
          <span>状态</span>
          <select v-model.number="form.isActive" class="ds-select"><option :value="1">启用</option><option :value="0">停用</option></select>
        </label>
        <label class="full">
          <span>参数 JSON Schema（编辑时实时校验）</span>
          <textarea v-model="form.schema" class="ds-input" rows="8" spellcheck="false" placeholder='{"type":"object","properties":{...}}' />
        </label>
        <div v-if="schemaError" class="ft-error">Schema 校验失败：{{ schemaError }}</div>
        <div v-else-if="form.schema" class="ft-ok">JSON 格式校验通过</div>
      </div>
      <template #footer><div class="ft-foot"><DsButton @click="formVisible = false">取消</DsButton><DsButton variant="primary" @click="save">保存</DsButton></div></template>
    </DsModal>

    <!-- 模拟调用测试 -->
    <DsModal v-model="testVisible" :title="`调用测试 · ${testRow?.name || ''}`" :width="640">
      <div class="ft-test">
        <div class="ft-test-info">
          <div><span>端点</span><b class="ft-mono">{{ testRow?.endpoint }}</b></div>
          <div><span>权限码</span><b class="ft-mono">{{ testRow?.permission || '无' }}</b></div>
        </div>
        <label class="ft-test-label">
          <span>调用参数（JSON，需符合 Schema）</span>
          <textarea v-model="testArgs" class="ds-input" rows="5" spellcheck="false" placeholder='{"productCode":"P0001"}' />
        </label>
        <div v-if="argError" class="ft-error">参数校验失败：{{ argError }}</div>
        <div class="ft-test-actions"><DsButton variant="primary" :loading="testing" @click="runTest">执行测试</DsButton></div>
        <div v-if="testResult !== null" class="ft-result">
          <div class="ft-result-title">返回结果</div>
          <pre>{{ testResult }}</pre>
        </div>
      </div>
      <template #footer><div class="ft-foot"><DsButton @click="testVisible = false">关闭</DsButton></div></template>
    </DsModal>
  </div>
</template>

<script setup lang="ts">
/** Function 工具管理：mock 集合 aiFunctions；Schema 与调用参数均做 JSON 格式校验 */
import { onMounted, reactive, ref } from 'vue';
import { mockGet, mockPost } from '../../api/mockAdapter';
import { useToast } from '../../components/ds/toast';

const toast = useToast();
const rows = ref<any[]>([]);
const formVisible = ref(false);
const testVisible = ref(false);
const testRow = ref<any>(null);
const testArgs = ref('{}');
const argError = ref('');
const testResult = ref<string | null>(null);
const testing = ref(false);
const schemaError = ref('');
const form = reactive<any>({ id: undefined, name: '', description: '', schema: '{"type":"object","properties":{}}', endpoint: '', permission: '', isActive: 1 });

const DEMO: any[] = [
  {
    id: 1, name: 'query_stock', description: '按产品编码查询可用库存', endpoint: '/api/v1/inventory/balance', permission: 'inventory:balance:view', isActive: 1,
    schema: '{"type":"object","properties":{"productCode":{"type":"string","description":"产品编码"}},"required":["productCode"]}',
  },
  {
    id: 2, name: 'create_sale_order', description: '创建销售草稿单（需人工确认）', endpoint: '/api/v1/sales/orders', permission: 'sales:order:create', isActive: 1,
    schema: '{"type":"object","properties":{"customerName":{"type":"string"},"qty":{"type":"number"}},"required":["customerName"]}',
  },
  {
    id: 3, name: 'query_receivable', description: '查询客户应收未收金额', endpoint: '/api/v1/finance/receivable-aging', permission: 'finance:voucher:view', isActive: 0,
    schema: '{"type":"object","properties":{"customerId":{"type":"number"}}}',
  },
];

/** 兜底演示数据识别 */
function normalize(data: any): any[] {
  const arr = Array.isArray(data) ? data : data?.list || [];
  if (!arr.length || arr.every((r: any) => /^演示数据\s*\d+$/.test(String(r?.name || '')))) return DEMO.map((d) => ({ ...d }));
  return arr;
}
/** Schema 摘要：仅展示首个属性名，避免表格过宽 */
function schemaSummary(schema?: string): string {
  try {
    const obj = JSON.parse(schema || '{}');
    const props = Object.keys(obj?.properties || {});
    return props.length ? `{ ${props.slice(0, 3).join(', ')}${props.length > 3 ? ' …' : ''} }` : schema || '-';
  } catch { return String(schema || '-').slice(0, 40); }
}
/** JSON 格式校验：返回错误信息，合法返回空串 */
function jsonError(text: string): string {
  try { JSON.parse(text || '{}'); return ''; }
  catch (e: any) { return e?.message || 'JSON 格式错误'; }
}

/** 加载工具列表 */
async function load(): Promise<void> {
  try { rows.value = normalize(await mockGet('/api/v1/ai/functions')); }
  catch { rows.value = DEMO.map((d) => ({ ...d })); }
}

/** 打开表单 */
function openForm(row?: any): void {
  Object.assign(form, row ? { ...row } : {
    id: undefined, name: '', description: '', schema: '{"type":"object","properties":{}}',
    endpoint: '', permission: '', isActive: 1,
  });
  schemaError.value = jsonError(form.schema);
  formVisible.value = true;
}

/** 保存工具：Schema 必须为合法 JSON */
async function save(): Promise<void> {
  if (!form.name || !form.endpoint) { toast.warning('请填写工具名与调用端点'); return; }
  schemaError.value = jsonError(form.schema);
  if (schemaError.value) return;
  await mockPost('/api/v1/ai/functions', { ...form });
  formVisible.value = false;
  toast.success('已保存工具配置');
  await load();
}

/** 启用 / 停用 */
async function toggle(row: any): Promise<void> {
  const next = Number(row.isActive) === 1 ? 0 : 1;
  await mockPost('/api/v1/ai/functions', { ...row, isActive: next });
  row.isActive = next;
  toast.success(next ? '已启用' : '已停用');
}

/** 打开调用测试弹窗 */
function openTest(row: any): void {
  testRow.value = row;
  testArgs.value = '{}';
  argError.value = '';
  testResult.value = null;
  testVisible.value = true;
}

/** 模拟调用：参数需为合法 JSON，经 mockPost 记录调用并返回结果 */
async function runTest(): Promise<void> {
  argError.value = jsonError(testArgs.value);
  if (argError.value || !testRow.value) return;
  testing.value = true;
  try {
    const args = JSON.parse(testArgs.value || '{}');
    const res: any = await mockPost(`/api/v1/ai/functions/${testRow.value.id}/test`, {
      tool: testRow.value.name, endpoint: testRow.value.endpoint, args,
    });
    testResult.value = JSON.stringify({
      ok: true,
      tool: testRow.value.name,
      message: `模拟调用成功，端点 ${testRow.value.endpoint}`,
      args,
      response: res?.result ?? { code: 0, data: res },
    }, null, 2);
    toast.success('调用测试完成');
  } catch (e: any) {
    testResult.value = JSON.stringify({ ok: false, error: e?.message || '调用失败' }, null, 2);
    toast.error('调用测试失败');
  } finally {
    testing.value = false;
  }
}
onMounted(load);
</script>

<style scoped>
.ft-table { width: 100%; border-collapse: collapse; font-size: 13px; }
.ft-table th, .ft-table td { padding: 9px 12px; border-bottom: 1px solid var(--ds-divider); text-align: left; }
.ft-table th { background: var(--ds-bg-soft); color: var(--ds-text-3); font-weight: 500; white-space: nowrap; }
.ft-mono { font-family: Consolas, Monaco, monospace; font-size: 12px; }
.ft-desc { max-width: 180px; }
.ft-ellipsis { max-width: 180px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.ft-ops { white-space: nowrap; }
.ft-empty { text-align: center; color: var(--ds-text-3); padding: 24px; }
.ft-form { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
.ft-form label { display: flex; flex-direction: column; gap: 4px; font-size: 13px; color: var(--ds-text-2); }
.ft-form .full { grid-column: 1 / -1; }
textarea.ds-input, input.ds-input { width: 100%; box-sizing: border-box; }
textarea.ds-input { font-family: Consolas, Monaco, monospace; font-size: 12px; }
.ft-error { grid-column: 1 / -1; color: var(--ds-danger); font-size: 12px; }
.ft-ok { grid-column: 1 / -1; color: var(--ds-success); font-size: 12px; }
.ft-foot { display: flex; justify-content: flex-end; gap: 8px; }
.ft-test-info { display: flex; gap: 24px; font-size: 12px; color: var(--ds-text-3); margin-bottom: 12px; }
.ft-test-info b { color: var(--ds-text-2); margin-left: 6px; }
.ft-test-label { display: flex; flex-direction: column; gap: 4px; font-size: 13px; color: var(--ds-text-2); }
.ft-test-actions { margin-top: 12px; }
.ft-result { margin-top: 12px; border: 1px solid var(--ds-border); border-radius: var(--ds-radius); overflow: hidden; }
.ft-result-title { padding: 6px 10px; background: var(--ds-bg-soft); font-size: 12px; color: var(--ds-text-3); }
.ft-result pre { margin: 0; padding: 10px; max-height: 260px; overflow: auto; white-space: pre-wrap; word-break: break-word; font-size: 12px; color: var(--ds-text-2); background: var(--ds-bg-elevated); }
</style>
