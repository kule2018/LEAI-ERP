<!-- AI 能力配置台：MCP 服务管理（连接测试 / 能力勾选 / 模拟调用工具） -->
<template>
  <div class="erp-page">
    <DsCard title="MCP 服务管理" subtitle="维护 Model Context Protocol 服务；支持连接测试、能力配置与工具模拟调用" :pad="false">
      <template #extra><DsButton variant="primary" size="sm" @click="openForm()">新增 Server</DsButton></template>
      <table class="mp-table">
        <thead>
          <tr><th>Server 名</th><th>传输方式</th><th>Endpoint</th><th>能力列表</th><th>状态</th><th>操作</th></tr>
        </thead>
        <tbody>
          <tr v-for="row in rows" :key="row.id">
            <td><b>{{ row.name }}</b></td>
            <td><DsTag color="brand" size="sm">{{ row.transport }}</DsTag></td>
            <td class="mp-mono mp-ellipsis" :title="row.endpoint">{{ row.endpoint }}</td>
            <td class="mp-caps">
              <DsTag v-for="c in capList(row)" :key="c" color="neutral" size="sm">{{ c }}</DsTag>
              <span v-if="!capList(row).length">-</span>
            </td>
            <td><DsTag :color="row.status === 'connected' ? 'success' : row.status === 'error' ? 'danger' : 'warning'" size="sm">{{ statusText(row.status) }}</DsTag></td>
            <td class="mp-ops">
              <DsButton variant="text" size="sm" @click="openForm(row)">编辑</DsButton>
              <DsButton variant="text" size="sm" :loading="testingId === row.id" @click="testConnection(row)">连接测试</DsButton>
              <DsButton variant="text" size="sm" @click="openCall(row)">模拟调用</DsButton>
              <DsButton variant="text" size="sm" @click="remove(row)">删除</DsButton>
            </td>
          </tr>
          <tr v-if="!rows.length"><td colspan="6" class="mp-empty">暂无 MCP 服务，点击右上角新增</td></tr>
        </tbody>
      </table>
    </DsCard>

    <!-- 新增 / 编辑 Server -->
    <DsModal v-model="formVisible" :title="form.id ? '编辑 Server' : '新增 Server'" :width="620">
      <div class="mp-form">
        <label><span>Server 名</span><input v-model="form.name" class="ds-input" placeholder="如 erp-local" /></label>
        <label>
          <span>传输方式</span>
          <select v-model="form.transport" class="ds-select">
            <option value="stdio">stdio</option><option value="sse">sse</option><option value="streamable-http">streamable-http</option>
          </select>
        </label>
        <label class="full"><span>Endpoint / 启动命令</span><input v-model="form.endpoint" class="ds-input" placeholder="如 npx -y @modelcontextprotocol/server-filesystem" /></label>
        <label class="full">
          <span>能力（可多选）</span>
          <span class="mp-checks">
            <label v-for="c in ALL_CAPS" :key="c"><input v-model="form.capabilities" type="checkbox" :value="c" /> {{ c }}</label>
          </span>
        </label>
        <label class="full"><span>工具清单（英文逗号分隔，供模拟调用选择）</span><input v-model="form.toolsText" class="ds-input" placeholder="query_stock,create_sale_order" /></label>
      </div>
      <template #footer><div class="mp-foot"><DsButton @click="formVisible = false">取消</DsButton><DsButton variant="primary" @click="save">保存</DsButton></div></template>
    </DsModal>

    <!-- 模拟调用工具 -->
    <DsModal v-model="callVisible" title="MCP 工具模拟调用" :width="660">
      <div class="mp-call">
        <div class="mp-call-row">
          <label><span>Server</span>
            <select v-model="callServerId" class="ds-select" @change="onServerChange">
              <option v-for="s in rows" :key="s.id" :value="s.id">{{ s.name }}</option>
            </select>
          </label>
          <label><span>能力 / 工具</span>
            <select v-model="callCapability" class="ds-select">
              <option v-for="c in callCapabilities" :key="c" :value="c">{{ c }}</option>
            </select>
          </label>
        </div>
        <label class="mp-call-label"><span>调用参数（JSON）</span><textarea v-model="callArgs" class="ds-input" rows="5" spellcheck="false" placeholder='{"productCode":"P0001"}' /></label>
        <div v-if="callError" class="mp-error">参数校验失败：{{ callError }}</div>
        <div class="mp-call-actions"><DsButton variant="primary" :loading="calling" @click="runCall">发起调用</DsButton></div>
        <div v-if="callResult !== null" class="mp-result">
          <div class="mp-result-title">返回结果</div>
          <pre>{{ callResult }}</pre>
        </div>
      </div>
      <template #footer><div class="mp-foot"><DsButton @click="callVisible = false">关闭</DsButton></div></template>
    </DsModal>
  </div>
</template>

<script setup lang="ts">
/** MCP 服务管理：mock 集合 aiMcpServers；连接测试经 mock 记录，模拟调用走 mockPost('/ai/mcp/call') */
import { computed, onMounted, reactive, ref } from 'vue';
import { mockGet, mockPost } from '../../api/mockAdapter';
import { useToast } from '../../components/ds/toast';

const toast = useToast();
const rows = ref<any[]>([]);
const formVisible = ref(false);
const callVisible = ref(false);
const testingId = ref<number | null>(null);
const calling = ref(false);
const ALL_CAPS = ['tools', 'resources', 'prompts'];
const form = reactive<any>({ id: undefined, name: '', transport: 'stdio', endpoint: '', capabilities: [], toolsText: '' });
const callServerId = ref<number | null>(null);
const callCapability = ref('');
const callArgs = ref('{}');
const callError = ref('');
const callResult = ref<string | null>(null);

const DEMO: any[] = [
  { id: 1, name: 'erp-local', transport: 'stdio', endpoint: 'local://erp-mcp', capabilities: ['tools', 'resources'], tools: ['query_stock', 'create_sale_order'], status: 'connected' },
  { id: 2, name: 'filesystem', transport: 'stdio', endpoint: 'npx -y @modelcontextprotocol/server-filesystem', capabilities: ['resources', 'prompts'], tools: [], status: 'connected' },
  { id: 3, name: 'remote-api', transport: 'sse', endpoint: 'https://mcp.example.com/sse', capabilities: ['tools'], tools: ['query_receivable'], status: 'disconnected' },
];

/** 兜底演示数据识别 */
function normalize(data: any): any[] {
  const arr = Array.isArray(data) ? data : data?.list || [];
  if (!arr.length || arr.every((r: any) => /^演示数据\s*\d+$/.test(String(r?.name || '')))) return DEMO.map((d) => ({ ...d }));
  return arr.filter((r: any) => !r.isDeleted);
}
/** 能力列表：兼容数组与逗号分隔字符串 */
function capList(row: any): string[] { return Array.isArray(row?.capabilities) ? row.capabilities : String(row?.capabilities || '').split(',').filter(Boolean); }
function statusText(s?: string): string { return s === 'connected' ? '已连接' : s === 'error' ? '异常' : '未连接'; }

/** 加载 Server 列表 */
async function load(): Promise<void> {
  try { rows.value = normalize(await mockGet('/api/v1/ai/mcp/servers')); }
  catch { rows.value = DEMO.map((d) => ({ ...d })); }
}

/** 打开表单 */
function openForm(row?: any): void {
  Object.assign(form, row ? {
    id: row.id, name: row.name, transport: row.transport || 'stdio', endpoint: row.endpoint,
    capabilities: capList(row), toolsText: (row.tools || []).join(','),
  } : { id: undefined, name: '', transport: 'stdio', endpoint: '', capabilities: [], toolsText: '' });
  formVisible.value = true;
}

/** 保存 Server */
async function save(): Promise<void> {
  if (!form.name || !form.endpoint) { toast.warning('请填写 Server 名与 Endpoint'); return; }
  await mockPost('/api/v1/ai/mcp/servers', {
    ...form,
    tools: String(form.toolsText || '').split(',').map((s: string) => s.trim()).filter(Boolean),
  });
  formVisible.value = false;
  toast.success('已保存 Server 配置');
  await load();
}

/** 删除 Server：以 isDeleted 标记并经 mock 持久化，列表读取时过滤 */
async function remove(row: any): Promise<void> {
  await mockPost('/api/v1/ai/mcp/servers', { ...row, isDeleted: 1 });
  toast.success('已删除');
  await load();
}

/** 连接测试：模拟延迟后更新状态 */
async function testConnection(row: any): Promise<void> {
  testingId.value = row.id;
  try {
    await new Promise((resolve) => window.setTimeout(resolve, 600));
    const ok = !String(row.endpoint || '').includes('example.com');
    const status = ok ? 'connected' : 'error';
    await mockPost('/api/v1/ai/mcp/servers', { ...row, status });
    row.status = status;
    if (ok) toast.success(`「${row.name}」连接成功`);
    else toast.error(`「${row.name}」连接失败`);
  } finally {
    testingId.value = null;
  }
}

/** 打开模拟调用弹窗 */
function openCall(row?: any): void {
  callResult.value = null;
  callError.value = '';
  callArgs.value = '{}';
  callServerId.value = row?.id ?? rows.value[0]?.id ?? null;
  onServerChange();
  callVisible.value = true;
}
/** 切换 Server 时刷新可选能力（tools/resources/prompts + 工具名） */
const callCapabilities = computed(() => {
  const s = rows.value.find((r) => Number(r.id) === Number(callServerId.value));
  if (!s) return [];
  return [...capList(s), ...(Array.isArray(s.tools) ? s.tools : [])];
});
function onServerChange(): void { callCapability.value = callCapabilities.value[0] || ''; }

/** 发起模拟调用 */
async function runCall(): Promise<void> {
  try { JSON.parse(callArgs.value || '{}'); }
  catch (e: any) { callError.value = e?.message || 'JSON 格式错误'; return; }
  if (!callCapability.value) { callError.value = '请选择能力或工具'; return; }
  calling.value = true;
  try {
    const res: any = await mockPost('/api/v1/ai/mcp/call', {
      serverId: callServerId.value, capability: callCapability.value, args: JSON.parse(callArgs.value || '{}'),
    });
    callResult.value = JSON.stringify({
      ok: true,
      server: rows.value.find((r) => Number(r.id) === Number(callServerId.value))?.name || '',
      capability: callCapability.value,
      response: res?.result ?? res,
    }, null, 2);
    toast.success('MCP 调用完成');
  } catch (e: any) {
    callResult.value = JSON.stringify({ ok: false, error: e?.message || '调用失败' }, null, 2);
    toast.error('MCP 调用失败');
  } finally {
    calling.value = false;
  }
}
onMounted(load);
</script>

<style scoped>
.mp-table { width: 100%; border-collapse: collapse; font-size: 13px; }
.mp-table th, .mp-table td { padding: 9px 12px; border-bottom: 1px solid var(--ds-divider); text-align: left; }
.mp-table th { background: var(--ds-bg-soft); color: var(--ds-text-3); font-weight: 500; white-space: nowrap; }
.mp-mono { font-family: Consolas, Monaco, monospace; font-size: 12px; max-width: 260px; }
.mp-ellipsis { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.mp-caps { display: flex; gap: 4px; flex-wrap: wrap; }
.mp-ops { white-space: nowrap; }
.mp-empty { text-align: center; color: var(--ds-text-3); padding: 24px; }
.mp-form { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
.mp-form label, .mp-call label { display: flex; flex-direction: column; gap: 4px; font-size: 13px; color: var(--ds-text-2); }
.mp-form .full { grid-column: 1 / -1; }
input.ds-input, textarea.ds-input { width: 100%; box-sizing: border-box; }
textarea.ds-input { font-family: Consolas, Monaco, monospace; font-size: 12px; }
.mp-checks { display: flex; gap: 16px; padding: 6px 0; }
.mp-checks label { flex-direction: row; align-items: center; gap: 4px; }
.mp-foot { display: flex; justify-content: flex-end; gap: 8px; }
.mp-call-row { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
.mp-call-label { margin-top: 12px; }
.mp-call-actions { margin-top: 12px; }
.mp-error { color: var(--ds-danger); font-size: 12px; margin-top: 6px; }
.mp-result { margin-top: 12px; border: 1px solid var(--ds-border); border-radius: var(--ds-radius); overflow: hidden; }
.mp-result-title { padding: 6px 10px; background: var(--ds-bg-soft); font-size: 12px; color: var(--ds-text-3); }
.mp-result pre { margin: 0; padding: 10px; max-height: 260px; overflow: auto; white-space: pre-wrap; word-break: break-word; font-size: 12px; color: var(--ds-text-2); background: var(--ds-bg-elevated); }
</style>
