<!-- AI 能力配置台：模型配置（供应商 / endpoint / 上下文 / 默认参数 / 健康检查 / 默认模型） -->
<template>
  <div class="erp-page">
    <DsCard title="模型配置" subtitle="维护 AI 大模型接入参数；支持健康检查、启用停用与设为默认" :pad="false">
      <template #extra><DsButton variant="primary" size="sm" @click="openForm()">新增模型</DsButton></template>
      <div class="mc-scroll">
        <table class="mc-table">
          <thead>
            <tr>
              <th>模型名</th><th>供应商</th><th>Endpoint</th><th>上下文长度</th><th>默认参数</th><th>健康状态</th><th>启用</th><th>默认</th><th>操作</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="row in rows" :key="row.id">
              <td><b>{{ row.name }}</b></td>
              <td>{{ row.provider }}</td>
              <td class="mc-mono">{{ row.endpoint }}</td>
              <td>{{ row.contextLength }}</td>
              <td class="mc-mono mc-ellipsis" :title="row.defaultParams">{{ row.defaultParams }}</td>
              <td><DsTag :color="healthColor(row.health)" size="sm">{{ healthText(row.health) }}</DsTag></td>
              <td><DsTag :color="row.isActive ? 'success' : 'neutral'" size="sm">{{ row.isActive ? '启用' : '停用' }}</DsTag></td>
              <td><DsTag v-if="row.isDefault" color="brand" size="sm">默认</DsTag><span v-else>-</span></td>
              <td class="mc-ops">
                <DsButton variant="text" size="sm" @click="openForm(row)">编辑</DsButton>
                <DsButton variant="text" size="sm" :loading="checkingId === row.id" @click="healthCheck(row)">健康检查</DsButton>
                <DsButton variant="text" size="sm" @click="toggle(row)">{{ row.isActive ? '停用' : '启用' }}</DsButton>
                <DsButton variant="text" size="sm" :disabled="!!row.isDefault" @click="setDefault(row)">设为默认</DsButton>
              </td>
            </tr>
            <tr v-if="!rows.length"><td colspan="9" class="mc-empty">暂无模型配置</td></tr>
          </tbody>
        </table>
      </div>
    </DsCard>

    <!-- 新增 / 编辑模型 -->
    <DsModal v-model="formVisible" :title="form.id ? '编辑模型' : '新增模型'" :width="640">
      <div class="mc-form">
        <label><span>模型名</span><input v-model="form.name" class="ds-input" placeholder="如 gpt-4o" /></label>
        <label><span>供应商</span><input v-model="form.provider" class="ds-input" placeholder="如 OpenAI / 阿里云" /></label>
        <label class="full"><span>Endpoint</span><input v-model="form.endpoint" class="ds-input" placeholder="如 https://api.openai.com/v1" /></label>
        <label><span>上下文长度</span><input v-model.number="form.contextLength" class="ds-input" type="number" min="1024" /></label>
        <label><span>是否启用</span><select v-model.number="form.isActive" class="ds-select"><option :value="1">启用</option><option :value="0">停用</option></select></label>
        <label class="full"><span>默认参数（JSON）</span><textarea v-model="form.defaultParams" class="ds-input" rows="4" placeholder='{&quot;temperature&quot;:0.2,&quot;max_tokens&quot;:2048}' /></label>
        <div v-if="paramError" class="mc-error">{{ paramError }}</div>
      </div>
      <template #footer><div class="mc-foot"><DsButton @click="formVisible = false">取消</DsButton><DsButton variant="primary" @click="save">保存</DsButton></div></template>
    </DsModal>
  </div>
</template>

<script setup lang="ts">
/** 模型配置：数据来自 mock 集合 aiModels（真实种子），无内置演示兜底 */
import { onMounted, reactive, ref } from 'vue';
import { mockGet, mockPost } from '../../api/mockAdapter';
import { useToast } from '../../components/ds/toast';

const toast = useToast();
const rows = ref<any[]>([]);
const formVisible = ref(false);
const form = reactive<any>({ id: undefined, name: '', provider: '', endpoint: '', contextLength: 8192, defaultParams: '{}', isActive: 1 });
const paramError = ref('');
const checkingId = ref<number | null>(null);

/** 加载模型列表（过滤 mock 通用兜底行，只认真实配置） */
async function load(): Promise<void> {
  try {
    const data: any = await mockGet('/api/v1/ai/models');
    const arr = Array.isArray(data) ? data : data?.list || [];
    rows.value = arr.filter((r: any) => !/^演示数据\s*\d+$/.test(String(r?.name || '')));
  } catch { rows.value = []; }
}

/** 健康状态文案与配色 */
function healthText(h?: string): string {
  return h === 'healthy' ? '健康' : h === 'slow' ? '延迟高' : h === 'error' ? '异常' : h === 'checking' ? '检测中' : '未检测';
}
type HealthColor = 'success' | 'warning' | 'danger' | 'neutral';
function healthColor(h?: string): HealthColor {
  return h === 'healthy' ? 'success' : h === 'slow' ? 'warning' : h === 'error' ? 'danger' : 'neutral';
}

/** 打开表单：传 row 为编辑，否则新增 */
function openForm(row?: any): void {
  Object.assign(form, row ? { ...row } : {
    id: undefined, name: '', provider: '', endpoint: '', contextLength: 8192,
    defaultParams: '{"temperature":0.2,"max_tokens":2048}', isActive: 1,
  });
  paramError.value = '';
  formVisible.value = true;
}

/** 保存模型（默认参数需为合法 JSON） */
async function save(): Promise<void> {
  if (!form.name || !form.endpoint) { toast.warning('请填写模型名与 Endpoint'); return; }
  try { JSON.parse(form.defaultParams || '{}'); }
  catch (e: any) { paramError.value = '默认参数不是合法 JSON：' + (e?.message || ''); return; }
  await mockPost('/api/v1/ai/models', { ...form });
  formVisible.value = false;
  toast.success('已保存模型配置');
  await load();
}

/** 健康检查：模拟请求延迟后更新状态并持久化 */
async function healthCheck(row: any): Promise<void> {
  checkingId.value = row.id;
  try {
    row.health = 'checking';
    await mockPost('/api/v1/ai/models', { ...row });
    await new Promise((resolve) => window.setTimeout(resolve, 700));
    row.health = Math.random() > 0.25 ? 'healthy' : 'slow';
    await mockPost('/api/v1/ai/models', { ...row });
    toast.success(`「${row.name}」检测完成：${healthText(row.health)}`);
  } finally {
    checkingId.value = null;
  }
}

/** 启用 / 停用 */
async function toggle(row: any): Promise<void> {
  const next = Number(row.isActive) === 1 ? 0 : 1;
  await mockPost('/api/v1/ai/models', { ...row, isActive: next });
  row.isActive = next;
  toast.success(next ? '已启用' : '已停用');
}

/** 设为默认：同一时刻仅一个默认模型 */
async function setDefault(row: any): Promise<void> {
  for (const m of rows.value) {
    m.isDefault = Number(m.id) === Number(row.id) ? 1 : 0;
    await mockPost('/api/v1/ai/models', { ...m });
  }
  toast.success(`已将「${row.name}」设为默认模型`);
}
onMounted(load);
</script>

<style scoped>
.mc-scroll { max-height: 480px; overflow: auto; }
.mc-table { width: 100%; border-collapse: collapse; font-size: 13px; }
.mc-table th, .mc-table td { padding: 9px 12px; border-bottom: 1px solid var(--ds-divider); text-align: left; }
.mc-table th { position: sticky; top: 0; background: var(--ds-bg-soft); color: var(--ds-text-3); font-weight: 500; white-space: nowrap; }
.mc-mono { font-family: Consolas, Monaco, monospace; font-size: 12px; max-width: 220px; }
.mc-ellipsis { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.mc-ops { white-space: nowrap; }
.mc-empty { text-align: center; color: var(--ds-text-3); padding: 24px; }
.mc-form { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
.mc-form label { display: flex; flex-direction: column; gap: 4px; font-size: 13px; color: var(--ds-text-2); }
.mc-form .full { grid-column: 1 / -1; }
textarea.ds-input, input.ds-input { width: 100%; box-sizing: border-box; }
.mc-error { grid-column: 1 / -1; color: var(--ds-danger); font-size: 12px; }
.mc-foot { display: flex; justify-content: flex-end; gap: 8px; }
</style>
