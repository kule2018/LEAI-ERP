<template>
  <div class="erp-page">
    <DsCard title="OCR 识别" subtitle="提取单据图片中的文字和字段">
      <div class="ocr-grid">
        <section>
          <label class="ocr-picker">选择 JPG、PNG 或 WebP（最多 1 MB）
            <input type="file" accept="image/jpeg,image/png,image/webp" :disabled="busy" @change="selectImage" />
          </label>
          <img v-if="image" :src="image" class="ocr-image" alt="待识别图片" />
          <DsButton variant="primary" :loading="busy" :disabled="!image" @click="recognize">识别图片</DsButton>
          <p v-if="error" class="record-error" role="alert">{{ error }}</p>
        </section>
        <section>
          <h3>识别结果</h3>
          <p v-if="fallback" role="status">当前显示规则或演示结果，请与图片原件核对。</p>
          <textarea v-model="result" class="ds-input ocr-result" rows="12" aria-label="可编辑识别结果" :readonly="busy" />
          <DsButton size="sm" :disabled="!result" @click="copyResult">复制结果</DsButton>
        </section>
      </div>
    </DsCard>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import { DsButton, DsCard } from '../../components';
import { useToast } from '../../components/ds/toast';
import { pageData } from '../../api/pageData';

const toast = useToast();
const image = ref('');
const result = ref('');
const error = ref('');
const busy = ref(false);
const fallback = ref(false);

async function selectImage(event: Event) {
  const file = (event.target as HTMLInputElement).files?.[0];
  image.value = '';
  result.value = '';
  error.value = '';
  fallback.value = false;
  if (!file) return;
  if (!['image/jpeg', 'image/png', 'image/webp'].includes(file.type) || file.size > 1_000_000) {
    error.value = '请选择 1 MB 以内的 JPG、PNG 或 WebP 图片';
    return;
  }
  busy.value = true;
  try {
    image.value = await new Promise<string>((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(String(reader.result));
      reader.onerror = () => reject(new Error('图片读取失败'));
      reader.readAsDataURL(file);
    });
  } catch (cause) {
    error.value = cause instanceof Error ? cause.message : '图片读取失败';
  } finally {
    busy.value = false;
  }
}

async function recognize() {
  if (!image.value || busy.value) return;
  busy.value = true;
  result.value = '';
  fallback.value = false;
  error.value = '';
  try {
    const reply = await pageData<{ fields?: object; text?: string; fallback?: boolean }>('POST', '/api/v1/ai/ocr', { imageBase64: image.value });
    fallback.value = Boolean(reply.fallback);
    result.value = reply.fields ? JSON.stringify(reply.fields, null, 2) : reply.text ?? '';
    if (!result.value) error.value = '未返回识别内容';
  } catch (cause) {
    error.value = cause instanceof Error ? cause.message : '识别失败';
  } finally {
    busy.value = false;
  }
}

async function copyResult() {
  try {
    await navigator.clipboard.writeText(result.value);
    toast.success('识别结果已复制');
  } catch {
    error.value = '复制失败，可选中文字手动复制';
  }
}
</script>

<style src="../records/recordPage.css"></style>
<style scoped>
.ocr-grid { display: grid; gap: 24px; grid-template-columns: repeat(auto-fit, minmax(min(100%, 300px), 1fr)); }
.ocr-grid h3 { margin-top: 0; }
.ocr-picker { display: grid; gap: 8px; margin-bottom: 12px; }
.ocr-image { display: block; max-width: 100%; max-height: 320px; margin-bottom: 12px; }
.ocr-result { width: 100%; box-sizing: border-box; margin-bottom: 8px; }
</style>
