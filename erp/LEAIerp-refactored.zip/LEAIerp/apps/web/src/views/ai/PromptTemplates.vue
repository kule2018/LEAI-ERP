<!-- AI 能力配置台：Prompt 模板管理（版本化 / 历史 / diff / 启用历史版本 / 复制） -->
<template>
  <div class="erp-page">
    <DsCard title="Prompt 模板管理" subtitle="按编码管理多版本提示词；支持新建版本、版本对比与启用历史版本" :pad="false">
      <template #extra><DsButton variant="primary" size="sm" @click="openForm()">新建模板</DsButton></template>
      <table class="pt-table">
        <thead>
          <tr><th>编码</th><th>名称</th><th>模型</th><th>Temperature</th><th>变量列表</th><th>版本</th><th>状态</th><th>操作</th></tr>
        </thead>
        <tbody>
          <tr v-for="p in rows" :key="p.id">
            <td class="pt-mono">{{ p.code }}</td>
            <td>{{ p.name }}</td>
            <td>{{ p.model || '-' }}</td>
            <td>{{ p.temperature ?? '-' }}</td>
            <td class="pt-mono">{{ variablesOf(p) || '-' }}</td>
            <td>v{{ p.version || 1 }}</td>
            <td><DsTag :color="activeOf(p) ? 'success' : 'neutral'" size="sm">{{ activeOf(p) ? '启用' : '停用' }}</DsTag></td>
            <td class="pt-ops">
              <DsButton variant="text" size="sm" @click="openForm(p)">新建版本</DsButton>
              <DsButton variant="text" size="sm" @click="openHistory(p)">历史</DsButton>
              <DsButton variant="text" size="sm" @click="openDiff(p)">版本对比</DsButton>
              <DsButton variant="text" size="sm" @click="copyTemplate(p)">复制</DsButton>
              <DsButton variant="text" size="sm" @click="toggle(p)">{{ activeOf(p) ? '停用' : '启用' }}</DsButton>
            </td>
          </tr>
          <tr v-if="!rows.length"><td colspan="8" class="pt-empty">暂无模板，点击右上角新建</td></tr>
        </tbody>
      </table>
    </DsCard>

    <!-- 新建模板 / 新建版本 -->
    <DsModal v-model="formVisible" :title="form.id ? `为「${form.name}」新建版本` : '新建模板'" :width="640">
      <div class="pt-form">
        <label><span>模板编码</span><input v-model="form.code" class="ds-input" placeholder="如 copilot / forecast" /></label>
        <label><span>模板名称</span><input v-model="form.name" class="ds-input" /></label>
        <label><span>模型</span><input v-model="form.model" class="ds-input" placeholder="如 local-rule / gpt-4o" /></label>
        <label><span>Temperature（0~1）</span><input v-model.number="form.temperature" class="ds-input" type="number" min="0" max="1" step="0.1" /></label>
        <label class="full"><span>变量列表（英文逗号分隔，如 data,horizon）</span><input v-model="form.variables" class="ds-input" placeholder="data,horizon" /></label>
        <label class="full"><span>模板内容（用双花括号变量占位，如 &#123;&#123;data&#125;&#125;）</span><textarea v-model="form.content" class="ds-input" rows="7" /></label>
      </div>
      <template #footer><div class="pt-foot"><DsButton @click="formVisible = false">取消</DsButton><DsButton variant="primary" @click="save">保存新版本</DsButton></div></template>
    </DsModal>

    <!-- 版本历史 -->
    <DsModal v-model="historyVisible" :title="`版本历史 · ${historyRow?.code || ''}`" :width="640">
      <div class="pt-history">
        <div v-for="v in historyList" :key="v.version" class="pt-hist-row">
          <div class="pt-hist-meta"><DsTag color="brand" size="sm">v{{ v.version }}</DsTag><span>{{ v.savedAt }}</span><span>{{ v.model || '-' }}</span></div>
          <pre class="pt-hist-content">{{ v.content }}</pre>
          <div class="pt-hist-ops">
            <DsButton variant="text" size="sm" @click="enableVersion(v)">启用此版本</DsButton>
            <DsButton variant="text" size="sm" @click="showDiff(historyRow, v)">与当前对比</DsButton>
          </div>
        </div>
        <div v-if="!historyList.length" class="pt-empty">暂无历史版本，保存新版本后可在此查看</div>
      </div>
    </DsModal>

    <!-- 版本 diff（逐行对比） -->
    <DsModal v-model="diffVisible" title="版本 diff 对比" :width="760">
      <div v-if="diffCurrent" class="pt-diff">
        <div class="pt-diff-head">
          <DsTag color="warning" size="sm">v{{ diffOld?.version || '历史' }}</DsTag>
          <span class="pt-diff-arrow">→</span>
          <DsTag color="success" size="sm">v{{ diffCurrent.version || '当前' }}</DsTag>
        </div>
        <div class="pt-diff-lines">
          <div v-for="(line, i) in diffLines" :key="i" class="pt-diff-line" :class="'is-' + line.kind">
            <span class="pt-diff-sign">{{ line.sign }}</span><span>{{ line.text }}</span>
          </div>
        </div>
        <p class="pt-diff-tip">说明：+ 新版本新增 · - 旧版本移除 · ~ 内容变更 · 空白为一致</p>
      </div>
    </DsModal>
  </div>
</template>

<script setup lang="ts">
/** Prompt 模板管理：aiApi.prompts 拉取、aiApi.savePrompt 保存新版本；前端维护历史快照用于 diff */
import { computed, onMounted, reactive, ref } from 'vue';
import { aiApi } from '../../api';
import { useToast } from '../../components/ds/toast';

const toast = useToast();
const rows = ref<any[]>([]);
const formVisible = ref(false);
const historyVisible = ref(false);
const diffVisible = ref(false);
const historyRow = ref<any>(null);
const diffCurrent = ref<any>(null);
const diffOld = ref<any>(null);
const form = reactive<any>({ id: undefined, code: '', name: '', model: 'local-rule', temperature: 0.2, variables: '', content: '' });
/** 每个编码对应的历史版本栈 */
const history: Record<string, any[]> = {};
/** Mock 保存接口强制 isActive=1，本地覆盖保证停用状态展示正确 */
const activeOverrides: Record<number, number> = {};

const DEMO: any[] = [
  { id: 1, code: 'copilot', name: 'AI 助理', content: '你是企业 ERP 助手，请用简洁中文回答。数据：{{data}}', variables: 'data', model: 'local-rule', temperature: 0.2, version: 1, isActive: 1 },
  { id: 2, code: 'forecast', name: '补货预测', content: '基于销量与库存预测未来 {{horizon}} 期需求，低于安全库存才建议采购。数据：{{data}}', variables: 'horizon,data', model: 'local-rule', temperature: 0.2, version: 1, isActive: 1 },
  { id: 3, code: 'reconcile', name: '智能对账', content: '比对双方账单并解释差异原因。己方：{{ours}}；对方：{{theirs}}', variables: 'ours,theirs', model: 'gpt-4o', temperature: 0.1, version: 1, isActive: 0 },
];

/** 变量列表：兼容数组与逗号分隔字符串 */
function variablesOf(p: any): string { return Array.isArray(p?.variables) ? p.variables.join(',') : String(p?.variables || ''); }
/** 启用状态（含本地覆盖） */
function activeOf(p: any): boolean { return (activeOverrides[p.id] !== undefined ? activeOverrides[p.id] : p.isActive) == 1; }

/** 加载模板；空数据时回退演示模板 */
async function load(): Promise<void> {
  try {
    const r: any = await aiApi.prompts();
    const arr = Array.isArray(r) ? r : r?.list || [];
    rows.value = arr.length ? arr : DEMO.map((d) => ({ ...d }));
  } catch { rows.value = DEMO.map((d) => ({ ...d })); }
  rows.value.forEach((p) => { if (activeOverrides[p.id] !== undefined) p.isActive = activeOverrides[p.id]; });
}

/** 把一条记录压入对应编码的历史栈 */
function pushHistory(p: any): void {
  if (!p || !p.code) return;
  if (!history[p.code]) history[p.code] = [];
  history[p.code].push({
    version: p.version || 1,
    content: p.content || '',
    model: p.model || '',
    variables: variablesOf(p),
    temperature: p.temperature ?? 0.2,
    savedAt: new Date().toLocaleString('zh-CN'),
  });
}

/** 新建模板 / 新建版本 */
function openForm(p?: any): void {
  Object.assign(form, p ? {
    id: p.id, code: p.code, name: p.name, model: p.model || 'local-rule',
    temperature: p.temperature ?? 0.2, variables: variablesOf(p), content: p.content || '', version: p.version || 1,
  } : {
    id: undefined, code: '', name: '', model: 'local-rule', temperature: 0.2, variables: '', content: '', version: 0,
  });
  formVisible.value = true;
}

/** 保存：编辑已有模板时先记录旧版本，再提交新版本 */
async function save(): Promise<void> {
  if (!form.code || !form.content) { toast.warning('请填写模板编码与内容'); return; }
  const old = rows.value.find((p) => p.code === form.code && Number(p.id) === Number(form.id));
  if (old) pushHistory(old);
  const payload = { ...form, variables: String(form.variables || '').split(',').map((s: string) => s.trim()).filter(Boolean) };
  await aiApi.savePrompt(payload);
  activeOverrides[form.id] = 1;
  formVisible.value = false;
  toast.success('已保存新版本');
  await load();
}

/** 查看版本历史 */
function openHistory(p: any): void { historyRow.value = p; historyVisible.value = true; }
/** 历史版本列表（含当前版本） */
const historyList = computed(() => {
  const row = historyRow.value;
  if (!row) return [];
  return [...(history[row.code] || [])].reverse();
});

/** 启用历史版本内容：作为新版本保存 */
async function enableVersion(v: any): Promise<void> {
  const p = historyRow.value;
  if (!p) return;
  await aiApi.savePrompt({ ...p, content: v.content, model: v.model, temperature: v.temperature, variables: v.variables, isActive: 1 });
  toast.success(`已启用 v${v.version} 的内容（生成新版本）`);
  historyVisible.value = false;
  await load();
}

/** 复制模板为新编码 */
async function copyTemplate(p: any): Promise<void> {
  try {
    await aiApi.savePrompt({
      ...p, id: undefined, code: `${p.code}_copy`, name: `${p.name}（副本）`,
      version: 0, variables: variablesOf(p), isActive: 0,
    });
    toast.success('已复制为新模板');
    await load();
  } catch (e: any) { toast.error('复制失败：' + (e?.message || '')); }
}

/** 启用 / 停用 */
async function toggle(p: any): Promise<void> {
  const next = activeOf(p) ? 0 : 1;
  activeOverrides[p.id] = next;
  try {
    await aiApi.savePrompt({ ...p, isActive: next });
    p.isActive = next;
    toast.success(next ? '已启用' : '已停用');
  } catch (e: any) {
    delete activeOverrides[p.id];
    toast.error('状态更新失败：' + (e?.message || ''));
  }
}

/** 打开 diff：旧版本取历史栈顶，当前取传入记录 */
function openDiff(p: any): void {
  const list = history[p.code] || [];
  showDiff(p, list.length ? list[list.length - 1] : { version: (p.version || 1) - 1, content: '（暂无历史快照）' });
}
function showDiff(p: any, old: any): void { diffCurrent.value = p; diffOld.value = old; diffVisible.value = true; }

/** 逐行文本 diff */
const diffLines = computed(() => {
  if (!diffCurrent.value) return [];
  const a = String(diffOld.value?.content || '').split('\n');
  const b = String(diffCurrent.value?.content || '').split('\n');
  const len = Math.max(a.length, b.length);
  const lines: any[] = [];
  for (let i = 0; i < len; i++) {
    const o = a[i]; const n = b[i];
    if (o === n) lines.push({ kind: 'same', sign: ' ', text: n ?? '' });
    else if (o === undefined) lines.push({ kind: 'add', sign: '+', text: n });
    else if (n === undefined) lines.push({ kind: 'del', sign: '-', text: o });
    else lines.push({ kind: 'chg', sign: '~', text: `${o}  →  ${n}` });
  }
  return lines;
});
onMounted(load);
</script>

<style scoped>
.pt-table { width: 100%; border-collapse: collapse; font-size: 13px; }
.pt-table th, .pt-table td { padding: 9px 12px; border-bottom: 1px solid var(--ds-divider); text-align: left; }
.pt-table th { background: var(--ds-bg-soft); color: var(--ds-text-3); font-weight: 500; white-space: nowrap; }
.pt-mono { font-family: Consolas, Monaco, monospace; font-size: 12px; }
.pt-ops { white-space: nowrap; }
.pt-empty { text-align: center; color: var(--ds-text-3); padding: 24px; }
.pt-form { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
.pt-form label { display: flex; flex-direction: column; gap: 4px; font-size: 13px; color: var(--ds-text-2); }
.pt-form .full { grid-column: 1 / -1; }
textarea.ds-input, input.ds-input { width: 100%; box-sizing: border-box; }
.pt-foot { display: flex; justify-content: flex-end; gap: 8px; }
.pt-history { display: flex; flex-direction: column; gap: 12px; max-height: 480px; overflow: auto; }
.pt-hist-row { border: 1px solid var(--ds-border); border-radius: var(--ds-radius); padding: 10px 12px; }
.pt-hist-meta { display: flex; align-items: center; gap: 10px; font-size: 12px; color: var(--ds-text-3); }
.pt-hist-content { white-space: pre-wrap; word-break: break-word; font-size: 12px; color: var(--ds-text-2); background: var(--ds-bg-soft); border-radius: var(--ds-radius); padding: 8px; margin: 8px 0; }
.pt-hist-ops { display: flex; gap: 8px; }
.pt-diff-head { display: flex; align-items: center; gap: 10px; margin-bottom: 10px; }
.pt-diff-arrow { color: var(--ds-text-3); }
.pt-diff-lines { max-height: 380px; overflow: auto; border: 1px solid var(--ds-border); border-radius: var(--ds-radius); font-family: Consolas, Monaco, monospace; font-size: 12px; }
.pt-diff-line { display: flex; gap: 10px; padding: 4px 10px; white-space: pre-wrap; word-break: break-all; border-bottom: 1px solid var(--ds-divider); }
.pt-diff-line:last-child { border-bottom: 0; }
.pt-diff-sign { flex: 0 0 12px; color: var(--ds-text-3); }
.pt-diff-line.is-add { background: rgba(22, 163, 74, 0.1); }
.pt-diff-line.is-add .pt-diff-sign { color: var(--ds-success); }
.pt-diff-line.is-del { background: rgba(220, 38, 38, 0.1); }
.pt-diff-line.is-del .pt-diff-sign { color: var(--ds-danger); }
.pt-diff-line.is-chg { background: rgba(217, 119, 6, 0.1); }
.pt-diff-line.is-chg .pt-diff-sign { color: var(--ds-warning); }
.pt-diff-tip { font-size: 12px; color: var(--ds-text-3); margin: 10px 0 0; }
</style>
