<!-- AI 审计日志：能力调用留痕、提示词版本管理、模型配置入口 -->
<template>
  <div class="erp-page">
    <div class="ai-stats">
      <div v-for="card in cards" :key="card.label" class="ai-stat"><span>{{ card.label }}</span><b>{{ card.value }}</b></div>
    </div>

    <DsCard title="AI 调用审计日志" :pad="false">
      <div class="ai-toolbar">
        <select v-model="capability" class="ds-select" @change="load"><option value="">全部能力</option><option v-for="c in capabilities" :key="c" :value="c">{{ c }}</option></select>
        <DsButton size="sm" @click="load">刷新</DsButton>
      </div>
      <div class="ai-scroll">
        <table class="ai-table">
          <thead><tr><th>能力码</th><th>模型</th><th>耗时(ms)</th><th>Token</th><th>降级</th><th>采纳</th><th>时间</th></tr></thead>
          <tbody>
            <tr v-for="log in logs" :key="log.id">
              <td>{{ log.capability }}</td><td>{{ log.model }}</td><td>{{ log.latencyMs }}</td>
              <td>{{ (log.promptTokens || 0) + (log.completionTokens || 0) }}</td>
              <td><DsTag :color="log.fallback ? 'warning' : 'success'" size="sm">{{ log.fallback ? '规则兜底' : '模型' }}</DsTag></td>
              <td>{{ log.accepted ? '是' : '否' }}</td><td>{{ log.createdAt }}</td>
            </tr>
            <tr v-if="!logs.length"><td colspan="7" class="ai-empty">暂无调用记录，可先在 AI 助理中提问</td></tr>
          </tbody>
        </table>
      </div>
    </DsCard>

    <DsCard title="提示词版本管理" :pad="false" class="ai-gap">
      <template #extra><DsButton variant="primary" size="sm" @click="openPrompt()">新增版本</DsButton></template>
      <table class="ai-table">
        <thead><tr><th>编码</th><th>名称</th><th>模型</th><th>Temperature</th><th>版本</th><th>状态</th><th>操作</th></tr></thead>
        <tbody>
          <tr v-for="p in prompts" :key="p.id">
            <td>{{ p.code }}</td><td>{{ p.name }}</td><td>{{ p.model }}</td><td>{{ p.temperature }}</td><td>v{{ p.version }}</td>
            <td><DsTag :color="p.isActive ? 'success' : 'neutral'" size="sm">{{ p.isActive ? '启用' : '停用' }}</DsTag></td>
            <td class="ai-ops">
              <DsButton variant="text" size="sm" @click="openPrompt(p)">编辑</DsButton>
              <DsButton variant="text" size="sm" @click="toggleActive(p)">{{ p.isActive ? '停用' : '启用' }}</DsButton>
              <DsButton variant="text" size="sm" @click="openDiff(p)">版本对比</DsButton>
            </td>
          </tr>
          <tr v-if="!prompts.length"><td colspan="7" class="ai-empty">暂无提示词配置</td></tr>
        </tbody>
      </table>
    </DsCard>

    <!-- 新增 / 编辑提示词：含 model / temperature / isActive 字段 -->
    <DsModal v-model="promptVisible" :title="prompt.id ? '编辑提示词' : '新增提示词版本'" :width="600">
      <div class="ai-form">
        <label><span>编码</span><input v-model="prompt.code" class="ds-input" placeholder="如 copilot / forecast" /></label>
        <label><span>名称</span><input v-model="prompt.name" class="ds-input" /></label>
        <label><span>模型</span><input v-model="prompt.model" class="ds-input" placeholder="如 local-rule / gpt-4o" /></label>
        <label><span>Temperature（0~1）</span><input v-model.number="prompt.temperature" class="ds-input" type="number" min="0" max="1" step="0.1" /></label>
        <label>
          <span>是否启用</span>
          <select v-model.number="prompt.isActive" class="ds-select"><option :value="1">启用</option><option :value="0">停用</option></select>
        </label>
        <label class="full"><span>内容（支持双花括号变量占位）</span><textarea v-model="prompt.content" class="ds-input" rows="6" /></label>
      </div>
      <template #footer><div class="ai-foot"><DsButton @click="promptVisible = false">取消</DsButton><DsButton variant="primary" @click="savePrompt">保存新版本</DsButton></div></template>
    </DsModal>

    <!-- 版本对比：简单的逐行文本 diff 展示 -->
    <DsModal v-model="diffVisible" title="提示词版本对比" :width="720">
      <div v-if="diffRow" class="ai-diff">
        <div class="ai-diff-head">
          <span>编码：{{ diffRow.code }} · {{ diffRow.name }}</span>
          <DsTag color="brand" size="sm">当前 v{{ diffRow.version }}</DsTag>
        </div>
        <div class="ai-diff-lines">
          <div v-for="(line, i) in diffLines" :key="i" class="ai-diff-line" :class="'is-' + line.kind">
            <span class="ai-diff-sign">{{ line.sign }}</span><span>{{ line.text }}</span>
          </div>
          <div v-if="!diffLines.length" class="ai-empty">暂无可对比内容</div>
        </div>
        <p class="ai-diff-tip">说明：+ 当前版本新增 · - 上一版本移除 · ~ 内容变更 · 空白为两版本一致</p>
      </div>
    </DsModal>
  </div>
</template>

<script setup lang="ts">
/** AI 审计与提示词管理页面：调用可追溯、提示词可版本化 */
import { computed, onMounted, reactive, ref } from 'vue';
import { aiApi } from '../../api';
import { useToast } from '../../components/ds/toast';

const toast = useToast();
const logs = ref<any[]>([]);
const prompts = ref<any[]>([]);
const capability = ref('');
const promptVisible = ref(false);
const diffVisible = ref(false);
const diffRow = ref<any>(null);
const prompt = reactive<any>({ code: '', name: '', model: 'local-rule', temperature: 0.2, isActive: 1, content: '' });
const capabilities = ['ai.copilot', 'ai.doc.parse', 'ai.ocr', 'ai.recommend', 'ai.forecast', 'ai.anomaly', 'ai.report', 'ai.rag'];
/** 编辑前的内容快照：键为编码，用于版本对比 */
const snapshots: Record<string, string> = {};
/** 用户对启用状态的期望值：Mock 保存接口会强制 isActive=1，用本地覆盖保证界面一致 */
const activeOverrides: Record<number, number> = {};

const cards = computed(() => [
  { label: '调用总次数', value: logs.value.length },
  { label: '规则兜底次数', value: logs.value.filter((l) => l.fallback).length },
  { label: '平均耗时', value: logs.value.length ? Math.round(logs.value.reduce((s, l) => s + Number(l.latencyMs || 0), 0) / logs.value.length) + ' ms' : '-' },
  { label: '提示词版本', value: prompts.value.length },
]);

/** 简单逐行 diff：上一版本 → 当前版本 */
const diffLines = computed(() => {
  if (!diffRow.value) return [];
  const oldLines = String(snapshots[diffRow.value.code] ?? '（暂无历史快照）').split('\n');
  const newLines = String(diffRow.value.content || '').split('\n');
  const len = Math.max(oldLines.length, newLines.length);
  const lines: any[] = [];
  for (let i = 0; i < len; i++) {
    const o = oldLines[i];
    const n = newLines[i];
    if (o === n) lines.push({ kind: 'same', sign: ' ', text: n ?? '' });
    else if (o === undefined) lines.push({ kind: 'add', sign: '+', text: n });
    else if (n === undefined) lines.push({ kind: 'del', sign: '-', text: o });
    else lines.push({ kind: 'chg', sign: '~', text: `${o}  →  ${n}` });
  }
  return lines;
});

/** 应用本地启用状态覆盖 */
function applyOverrides(): void {
  prompts.value.forEach((p) => { if (activeOverrides[p.id] !== undefined) p.isActive = activeOverrides[p.id]; });
}

/** 加载审计与提示词 */
async function load(): Promise<void> {
  const [l, p]: any[] = await Promise.all([aiApi.audits(), aiApi.prompts()]);
  logs.value = Array.isArray(l) ? l : l?.list || [];
  prompts.value = Array.isArray(p) ? p : p?.list || [];
  applyOverrides();
}
/** 新增 / 编辑提示词 */
function openPrompt(p?: any): void {
  const source = p || { code: '', name: '', model: 'local-rule', temperature: 0.2, isActive: 1, content: '' };
  Object.assign(prompt, {
    id: source.id,
    code: source.code,
    name: source.name,
    model: source.model || 'local-rule',
    temperature: source.temperature ?? 0.2,
    isActive: source.isActive ?? 1,
    content: source.content || '',
    version: source.version || 1,
  });
  if (p) snapshots[p.code] = String(p.content || '');
  promptVisible.value = true;
}
/** 保存提示词版本 */
async function savePrompt(): Promise<void> {
  if (!prompt.code || !prompt.content) { toast.warning('请填写编码和内容'); return; }
  const desiredActive = Number(prompt.isActive) === 1 ? 1 : 0;
  await aiApi.savePrompt({ ...prompt, isActive: desiredActive });
  activeOverrides[prompt.id] = desiredActive;
  snapshots[prompt.code] = String(prompt.content || '');
  promptVisible.value = false;
  toast.success('已保存新版本');
  await load();
}
/** 启用 / 停用提示词 */
async function toggleActive(p: any): Promise<void> {
  const next = Number(p.isActive) === 1 ? 0 : 1;
  activeOverrides[p.id] = next;
  try {
    await aiApi.savePrompt({ ...p, isActive: next });
    p.isActive = next;
    toast.success(next ? '已启用' : '已停用');
  } catch (e: any) {
    delete activeOverrides[p.id];
    toast.error('状态更新失败：' + (e?.message || ''));
  }
}
/** 打开版本对比 */
function openDiff(p: any): void { diffRow.value = p; diffVisible.value = true; }
onMounted(load);
</script>

<style scoped>
.ai-stats { display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px; margin-bottom: 12px; }
.ai-stat { background: var(--ds-bg-elevated); border: 1px solid var(--ds-border); border-radius: var(--ds-radius); padding: 12px 16px; display: flex; flex-direction: column; gap: 4px; }
.ai-stat span { font-size: 12px; color: var(--ds-text-3); }
.ai-stat b { font-size: 18px; }
.ai-toolbar { display: flex; gap: 8px; padding: 12px; }
.ai-scroll { max-height: 420px; overflow: auto; }
.ai-table { width: 100%; border-collapse: collapse; font-size: 13px; }
.ai-table th, .ai-table td { padding: 9px 12px; border-bottom: 1px solid var(--ds-divider); text-align: left; }
.ai-table th { position: sticky; top: 0; background: var(--ds-bg-soft); color: var(--ds-text-3); font-weight: 500; }
.ai-empty { text-align: center; color: var(--ds-text-3); padding: 24px; }
.ai-gap { margin-top: 12px; }
.ai-form { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
.ai-form label { display: flex; flex-direction: column; gap: 4px; font-size: 13px; color: var(--ds-text-2); }
.ai-form .full { grid-column: 1 / -1; }
.ai-foot { display: flex; justify-content: flex-end; gap: 8px; }
.ai-ops { white-space: nowrap; }
.ai-diff-head { display: flex; align-items: center; justify-content: space-between; font-size: 13px; margin-bottom: 10px; }
.ai-diff-lines { max-height: 360px; overflow: auto; border: 1px solid var(--ds-border); border-radius: var(--ds-radius); font-family: Consolas, Monaco, monospace; font-size: 12px; }
.ai-diff-line { display: flex; gap: 10px; padding: 4px 10px; white-space: pre-wrap; word-break: break-all; border-bottom: 1px solid var(--ds-divider); }
.ai-diff-line:last-child { border-bottom: 0; }
.ai-diff-sign { flex: 0 0 12px; color: var(--ds-text-3); }
.ai-diff-line.is-add { background: rgba(22, 163, 74, 0.1); }
.ai-diff-line.is-add .ai-diff-sign { color: var(--ds-success); }
.ai-diff-line.is-del { background: rgba(220, 38, 38, 0.1); }
.ai-diff-line.is-del .ai-diff-sign { color: var(--ds-danger); }
.ai-diff-line.is-chg { background: rgba(217, 119, 6, 0.1); }
.ai-diff-line.is-chg .ai-diff-sign { color: var(--ds-warning); }
.ai-diff-tip { font-size: 12px; color: var(--ds-text-3); margin: 10px 0 0; }
</style>
