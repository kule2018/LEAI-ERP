<template>
  <div :class="embedded ? 'ai-drawer' : 'erp-page'">
    <div v-if="!embedded"><h3>🤖 AI 助理 Copilot</h3></div>
    <div class="chat" ref="chatRef">
      <div v-for="(m, i) in messages" :key="i" :class="['msg', m.role]">
        <div class="bubble">{{ m.content }}</div>
        <!-- AI 建议卡片：可采纳/可驳回，写库必须用户确认（文档 0 章约定） -->
        <div v-if="m.card" class="card">
          <pre>{{ m.card }}</pre>
          <DsButton size="sm" variant="primary" @click="accept(m)">采纳并生成草稿</DsButton>
          <DsButton size="sm" :disabled="m.rejected" @click="m.rejected = true">驳回</DsButton>
          <span v-if="m.fallback" class="fallback">规则引擎兜底</span>
        </div>
      </div>
    </div>
    <!-- 文档 12.2 专属能力快捷入口：标签识别 / 智能客服 / 简历解析 -->
    <div class="quick-actions">
      <DsButton size="sm" @click="quickAction('label')">🏷 标签识别</DsButton>
      <DsButton size="sm" @click="quickAction('cs')">💬 智能客服</DsButton>
      <DsButton size="sm" @click="quickAction('resume')">📄 简历解析</DsButton>
    </div>
    <div class="input">
      <textarea v-model="input" class="ds-input" rows="2" placeholder="自然语言查库存/查单据/问流程，如：库存预警有哪些？" @keyup.enter.ctrl="send"></textarea>
      <DsButton variant="primary" :loading="loading" @click="send">发送</DsButton>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, nextTick } from 'vue';
import { DsButton } from '../../components';
import { useToast } from '../../components/ds/toast';
import { aiApi, salesApi } from '../../api';
import { MOCK_ENABLED } from '../../api/mockAdapter';

defineProps<{ embedded?: boolean }>();
const toast = useToast();
const messages = ref<any[]>([{ role: 'assistant', content: '你好，我是LEO ERP AI 助理。可以问我库存、客户应收、单据流程，我会给出可采纳的建议。' }]);
const input = ref('');
const loading = ref(false);
const chatRef = ref<HTMLElement | null>(null);

async function scroll() { await nextTick(); chatRef.value?.scrollIntoView?.({ behavior: 'smooth' }); }

/** 专属 AI 能力：按能力码调用对应接口，结果以可解释文本展示 */
async function quickAction(kind: 'label' | 'cs' | 'resume'): Promise<void> {
  const prompts: Record<string, string> = { label: '请识别产品：品牌无线鼠标，用于办公', cs: '这款产品报价多少？', resume: '姓名：张三，电话：13800138000，熟悉 Java 和 Vue，5 年工作经验' };
  const question = prompts[kind];
  messages.value.push({ role: 'user', content: question });
  loading.value = true;
  try {
    const result: any = kind === 'label' ? await aiApi.labelRec(question) : kind === 'cs' ? await aiApi.customerService(question) : await aiApi.resumeParse(question);
    messages.value.push({ role: 'assistant', content: result.text || `识别结果：${JSON.stringify(result, null, 2)}`, fallback: !!result.fallback });
  } catch {
    messages.value.push({ role: 'assistant', content: '该能力暂不可用，请稍后重试。' });
  } finally { loading.value = false; await scroll(); }
}

/** 发送：优先 SSE 流式；浏览器 fetch 读取 ReadableStream 分块渲染 */
async function send() {
  const text = input.value.trim();
  if (!text || loading.value) return;
  input.value = '';
  messages.value.push({ role: 'user', content: text });
  const aiMsg: any = { role: 'assistant', content: '', fallback: false };
  messages.value.push(aiMsg);
  loading.value = true;
  try {
    // 本地演示模式：走 Mock 规则引擎，不需要后端 SSE
    if (MOCK_ENABLED) {
      const reply: any = await aiApi.copilot(text, false);
      aiMsg.content = reply.text || '（无响应）';
      aiMsg.fallback = !!reply.fallback;
      if (reply.items) aiMsg.card = JSON.stringify(reply.items, null, 2);
      loading.value = false;
      await scroll();
      return;
    }
    const token = localStorage.getItem('erp_token');
    const resp = await fetch('/api/v1/ai/copilot', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
      body: JSON.stringify({ message: text, stream: true }),
    });
    if (resp.ok && resp.headers.get('content-type')?.includes('text/event-stream')) {
      const reader = resp.body!.getReader(); const decoder = new TextDecoder(); let buf = '';
      for (;;) {
        const { done, value } = await reader.read();
        if (done) break;
        buf += decoder.decode(value, { stream: true });
        // SSE 帧以空行分隔，每帧 data: 后为 JSON 或文本块
        const frames = buf.split('\n\n'); buf = frames.pop() || '';
        for (const f of frames) {
          const line = f.split('\n').find((l) => l.startsWith('data:'))?.slice(5).trim();
          if (!line) continue;
          try {
            const d = JSON.parse(line);
            if (d.done) { aiMsg.fallback = d.fallback; break; }
            aiMsg.content += d.chunk || d.text || '';
          } catch { aiMsg.content += line; }
        }
        await scroll();
      }
    } else {
      const d: any = await resp.json().catch(() => ({}));
      aiMsg.content = d.text || d.message || '（无响应）';
      aiMsg.fallback = d.fallback;
      if (d.items || d.suggest) aiMsg.card = JSON.stringify(d.items || d.suggest, null, 2);
    }
  } catch (e: any) {
    aiMsg.content = '请求失败：' + (e?.message || '网络错误');
  } finally { loading.value = false; await scroll(); }
}

/** 采纳：AI 只给建议，真正落库走业务接口，由用户确认 */
async function accept(m: any) {
  try {
    const payload = JSON.parse(m.card);
    if (Array.isArray(payload.items)) {
      await salesApi.create({ customerId: payload.customerId, lines: payload.items, remark: 'AI 助理生成草稿' });
      toast.success('已生成销售草稿单');
    } else { toast.info('该建议暂不支持一键建单，请手工录入'); }
  } catch { toast.warning('建议内容不是可建单结构'); }
}
</script>

<style scoped>
.ai-drawer { display: flex; flex-direction: column; height: 100%; }
.chat { flex: 1; overflow-y: auto; padding: 8px; }
.msg { margin-bottom: 12px; }
.msg.user { text-align: right; }
.bubble { display: inline-block; padding: 8px 12px; border-radius: 8px; background: #f0f2f5; max-width: 90%; text-align: left; white-space: pre-wrap; }
.msg.user .bubble { background: #409eff; color: #fff; }
.card { margin-top: 6px; background: #fff; border: 1px solid #ebeef5; border-radius: 6px; padding: 8px; }
.card pre { font-size: 12px; max-height: 200px; overflow: auto; }
.fallback { color: #e6a23c; font-size: 12px; margin-left: 8px; }
.quick-actions { display: flex; gap: 6px; padding: 6px 8px 0; flex-wrap: wrap; }
.input { display: flex; gap: 8px; padding: 8px; border-top: 1px solid #ebeef5; }
.input .ds-input { flex: 1; resize: vertical; }
</style>