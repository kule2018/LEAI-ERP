<!--
 * AI 每日简报：按当日经营指标生成可读简报，并给出可点击的处置入口。
 * 数据来自销售/采购/应收/库存/审批真实聚合，AI 不可用时保留指标与建议清单。
-->
<template>
  <div class="brief-page">
    <div class="brief-head">
      <div>
        <h2>AI 每日简报</h2>
        <p>汇总今日销售、采购、应收、库存预警与待办，一键生成经营诊断。</p>
      </div>
      <DsButton variant="primary" size="sm" :loading="loading" @click="generate">🤖 生成今日简报</DsButton>
    </div>

    <div class="brief-cards">
      <div v-for="c in cards" :key="c.label" class="brief-card" @click="router.push(c.path)">
        <span>{{ c.label }}</span>
        <b>{{ c.value }}</b>
        <small>{{ c.hint }}</small>
      </div>
    </div>

    <DsCard title="经营诊断" class="brief-gap">
      <div v-if="loading" class="brief-empty">正在生成简报…</div>
      <div v-else-if="brief" class="brief-text">{{ brief }}</div>
      <div v-else class="brief-empty">点击右上角「生成今日简报」获取诊断与行动建议。</div>
    </DsCard>

    <DsCard title="今日待办与风险" :pad="false" class="brief-gap">
      <div class="brief-list">
        <div v-for="t in todos" :key="t.id" class="brief-item" @click="router.push('/collab/approval')">
          <span class="brief-item__tag">{{ t.bizType || '审批' }}</span>
          <b>{{ t.bizNo || t.title || `#${t.id}` }}</b>
          <span>{{ t.nodeName || t.type || '待处理' }}</span>
          <small>去处理 →</small>
        </div>
        <div v-for="a in alerts" :key="'a' + a.id" class="brief-item" @click="router.push('/inventory/alerts')">
          <span class="brief-item__tag danger">库存预警</span>
          <b>{{ a.productName || `产品 ${a.productId}` }}</b>
          <span>{{ a.message || a.type }}</span>
          <small>查看 →</small>
        </div>
        <div v-if="!todos.length && !alerts.length" class="brief-empty">今日无待办与库存预警。</div>
      </div>
    </DsCard>
  </div>
</template>

<script setup lang="ts">
import { onMounted, ref } from 'vue';
import { useRouter } from 'vue-router';
import { DsButton, DsCard } from '../../components';
import { useToast } from '../../components/ds/toast';
import { aiApi, salesApi, purchaseApi, financeApi, inventoryApi } from '../../api';
import { bpmApi } from '../../api/ext';

const router = useRouter();
const toast = useToast();
const loading = ref(false);
const brief = ref('');
const todos = ref<any[]>([]);
const alerts = ref<any[]>([]);
const cards = ref([
  { label: '今日销售', value: '0.00', hint: '查看销售单 →', path: '/sales/orders' },
  { label: '今日采购', value: '0.00', hint: '查看采购单 →', path: '/purchase/orders' },
  { label: '应收未收', value: '0.00', hint: '查看应收 →', path: '/finance/receivables' },
  { label: '库存预警', value: '0', hint: '查看预警 →', path: '/inventory/alerts' },
]);

/** 并行加载经营指标；每个接口独立容错，单个失败不影响简报可用 */
async function loadMetrics(): Promise<void> {
  const [sale, purchase, aging, warn, todo] = await Promise.allSettled([
    salesApi.list({ pageSize: 1 }), purchaseApi.list({ pageSize: 1 }),
    financeApi.receivableAging(), inventoryApi.alerts(), bpmApi.todo(),
  ]);
  const settled = (r: PromiseSettledResult<any>) => r.status === 'fulfilled' ? r.value : null;
  const s: any = settled(sale);
  const p: any = settled(purchase);
  const a: any = settled(aging) || [];
  const w: any = settled(warn) || [];
  const t: any = settled(todo) || [];
  cards.value[0].value = String(s?.summary?.todayAmount ?? '0.00');
  cards.value[1].value = String(p?.summary?.todayAmount ?? '0.00');
  cards.value[2].value = (Array.isArray(a) ? a : []).reduce((sum: number, r: any) => sum + Number(r.unpaid || 0), 0).toFixed(2);
  cards.value[3].value = String((Array.isArray(w) ? w : []).length);
  todos.value = (Array.isArray(t) ? t : []).slice(0, 6);
  alerts.value = (Array.isArray(w) ? w : []).slice(0, 5);
}

/** 生成简报：指标使用中文键，与 AI 规则引擎提示词保持一致 */
async function generate(): Promise<void> {
  loading.value = true;
  try {
    const res: any = await aiApi.reportInsight({
      今日销售: cards.value[0].value,
      今日采购: cards.value[1].value,
      应收未收: cards.value[2].value,
      库存预警: cards.value[3].value,
      待办数: todos.value.length,
    });
    brief.value = res.text || JSON.stringify(res);
    toast.success('简报已生成');
  } catch (e: any) {
    brief.value = '简报生成失败，请稍后重试';
    toast.error(e?.message || '简报生成失败');
  } finally {
    loading.value = false;
  }
}

onMounted(loadMetrics);
</script>

<style scoped>
.brief-page { padding: 16px; }
.brief-head { display: flex; justify-content: space-between; align-items: center; margin-bottom: 14px; }
.brief-head h2 { margin: 0 0 4px; font-size: 18px; }
.brief-head p { margin: 0; color: var(--ds-text-3); font-size: 12px; }
.brief-cards { display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); gap: 12px; }
.brief-card { display: flex; flex-direction: column; gap: 4px; padding: 14px; border: 1px solid var(--ds-border); border-radius: 10px; background: var(--ds-bg-elevated); cursor: pointer; }
.brief-card:hover { border-color: var(--ds-brand); }
.brief-card span { font-size: 12px; color: var(--ds-text-3); }
.brief-card b { font-size: 22px; }
.brief-card small { font-size: 11px; color: var(--ds-brand); }
.brief-gap { margin-top: 12px; }
.brief-text { white-space: pre-wrap; line-height: 1.8; font-size: 13px; }
.brief-empty { padding: 16px; color: var(--ds-text-3); font-size: 13px; }
.brief-list { padding: 8px 12px; }
.brief-item { display: flex; align-items: center; gap: 12px; padding: 9px 0; border-bottom: 1px solid var(--ds-divider); font-size: 13px; cursor: pointer; }
.brief-item:last-child { border-bottom: 0; }
.brief-item__tag { padding: 2px 8px; border-radius: 999px; background: var(--ds-brand-soft, rgba(77,107,254,.1)); color: var(--ds-brand); font-size: 11px; }
.brief-item__tag.danger { color: var(--ds-danger); }
.brief-item small { margin-left: auto; color: var(--ds-brand); }
@media (max-width: 900px) { .brief-cards { grid-template-columns: repeat(2, minmax(0, 1fr)); } }
</style>
