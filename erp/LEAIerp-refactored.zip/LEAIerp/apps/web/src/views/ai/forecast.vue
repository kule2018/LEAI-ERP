<template>
  <div class="entity-page">
    <div class="entity-search">
      <DsButton variant="primary" size="sm" :loading="loading" @click="run">🤖 运行销量预测与补货建议</DsButton>
      <DsButton size="sm" @click="scan">🛡 异常检测扫描</DsButton>
    </div>
    <div class="forecast-grid">
      <DsCard :pad="false">
        <div class="entity-table"><b>预测 / 补货建议</b>
          <table class="ds-table" style="margin-top: 8px">
            <thead><tr><th style="width:110px">产品编码</th><th style="width:90px">预测需求</th><th style="width:90px">建议采购</th><th>原因</th></tr></thead>
            <tbody>
              <tr v-for="(r, i) in items" :key="r.productCode || i"><td>{{ r.productCode }}</td><td>{{ r.predictQty }}</td><td>{{ r.suggestPurchaseQty }}</td><td>{{ r.reason }}</td></tr>
              <tr v-if="!items.length"><td colspan="4" class="entity-empty">点击上方按钮生成</td></tr>
            </tbody>
          </table>
        </div>
        <div v-if="items.length" style="margin-top: 8px; padding: 0 12px 12px"><DsButton size="sm" variant="primary" @click="toPurchase">生成采购建议单（待确认）</DsButton></div>
      </DsCard>
      <DsCard :pad="false">
        <div class="entity-table"><b>风险清单</b>
          <table class="ds-table" style="margin-top: 8px">
            <thead><tr><th style="width:120px">类型</th><th style="width:80px">等级</th><th>说明</th></tr></thead>
            <tbody>
              <tr v-for="(r, i) in risks" :key="i"><td>{{ r.type }}</td><td>{{ r.level }}</td><td>{{ r.message }}</td></tr>
              <tr v-if="!risks.length"><td colspan="3" class="entity-empty">暂无扫描结果</td></tr>
            </tbody>
          </table>
        </div>
      </DsCard>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import { useRouter } from 'vue-router';
import { DsButton, DsCard } from '../../components';
import { useToast } from '../../components/ds/toast';
import { aiApi } from '../../api';

const router = useRouter();
const toast = useToast();
const loading = ref(false);
const items = ref<any[]>([]);
const risks = ref<any[]>([]);

async function run() {
  loading.value = true;
  try {
    await aiApi.forecastRun();
    const r: any = await aiApi.forecastResult();
    items.value = r.items || r.list || (Array.isArray(r) ? r : []);
    toast.success('预测完成');
  } catch { /* 已提示 */ } finally { loading.value = false; }
}
async function scan() {
  const r: any = await aiApi.anomalyScan();
  risks.value = r.items || r.risks || (Array.isArray(r) ? r : []);
}
/** AI 建议不直接落单，跳转采购新建页由用户确认 */
function toPurchase() { toast.info('建议已列出，请确认后在采购单中录入'); router.push('/purchase/orders/new'); }
</script>

<style scoped>
.forecast-grid { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 12px; margin-top: 12px; }
@media (max-width: 900px) { .forecast-grid { grid-template-columns: 1fr; } }
</style>