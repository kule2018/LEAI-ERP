<!-- 企业知识库 RAG：文档上传向量化 + 知识问答（答案附引用来源与置信度） -->
<template>
  <div class="erp-page">
    <div class="ai-rag-grid">
      <!-- 左：文档库 -->
      <DsCard title="知识库文档" subtitle="上传文档后自动切片向量化，供问答检索">
        <label class="ai-upload">
          <input type="file" accept=".pdf,.doc,.docx,.txt,.md" @change="onFileChange" />
          <span class="ai-upload-box">
            <b>点击上传知识文档</b>
            <small>支持 PDF / Word / TXT / Markdown</small>
          </span>
        </label>
        <div v-if="uploading" class="ai-upload-progress">
          <div class="ai-upload-label">{{ vectorStatus }}</div>
          <DsProgress :value="uploadPercent" show-text :status="uploadDone ? 'success' : 'running'" />
        </div>
        <table class="ai-table">
          <thead><tr><th>文档</th><th>切片数</th><th>状态</th></tr></thead>
          <tbody>
            <tr v-for="doc in docs" :key="doc.id">
              <td>{{ doc.title || doc.name }}</td>
              <td>{{ doc.chunkCount ?? doc.chunks ?? '-' }}</td>
              <td>
                <DsTag :color="Number(doc.status ?? 1) === 1 ? 'success' : 'warning'" size="sm">
                  {{ Number(doc.status ?? 1) === 1 ? '已就绪' : '处理中' }}
                </DsTag>
              </td>
            </tr>
            <tr v-if="!docs.length"><td colspan="3" class="ai-empty">暂无文档，请先上传</td></tr>
          </tbody>
        </table>
      </DsCard>

      <!-- 右：问答区 -->
      <DsCard title="知识库问答" subtitle="基于已入库文档回答，答案下方展示引用来源与置信度">
        <div ref="chatRef" class="ai-chat">
          <div v-for="(m, i) in messages" :key="i" class="ai-msg" :class="m.role">
            <div class="ai-bubble">{{ m.content }}</div>
            <div v-if="m.role === 'assistant' && m.citations?.length" class="ai-citations">
              <div class="ai-cite-head">
                引用来源 · 总体置信度 {{ (Number(m.confidence || 0.9) * 100).toFixed(0) }}%
                <DsTag v-if="m.fallback" color="warning" size="sm">规则兜底</DsTag>
              </div>
              <div v-for="(c, j) in m.citations" :key="j" class="ai-cite">
                <span class="ai-cite-doc">{{ c.doc }}</span>
                <span class="ai-cite-loc">{{ c.location }}</span>
                <DsTag color="brand" size="sm">置信 {{ (Number(c.confidence) * 100).toFixed(0) }}%</DsTag>
              </div>
            </div>
          </div>
        </div>
        <div class="ai-ask">
          <input v-model="question" class="ds-input" placeholder="输入问题，如：销售流程是怎样的？" @keyup.enter="ask" />
          <DsButton variant="primary" :loading="asking" @click="ask">提问</DsButton>
        </div>
      </DsCard>
    </div>
  </div>
</template>

<script setup lang="ts">
/** 企业知识库 RAG：模拟向量化进度，问答结果解析引用来源与置信度 */
import { nextTick, onMounted, ref } from 'vue';
import { aiApi } from '../../api';
import { mockGet, mockPost } from '../../api/mockAdapter';
import { useToast } from '../../components/ds/toast';

const toast = useToast();
const docs = ref<any[]>([]);
const question = ref('');
const asking = ref(false);
const chatRef = ref<HTMLElement | null>(null);
const messages = ref<any[]>([
  { role: 'assistant', content: '你好，我是企业知识库助手。基于已入库文档回答你的问题，答案下方会列出引用来源。', citations: [] },
]);
const uploading = ref(false);
const uploadPercent = ref(0);
const uploadDone = ref(false);
const vectorStatus = ref('');

/** 加载已入库文档 */
async function loadDocs(): Promise<void> {
  try {
    const r: any = await mockGet('/api/v1/ai/rag/docs');
    docs.value = Array.isArray(r) ? r : r?.list || [];
  } catch { docs.value = []; }
}
onMounted(loadDocs);

/** 滚动到底部 */
async function scroll(): Promise<void> {
  await nextTick();
  chatRef.value?.scrollTo?.({ top: chatRef.value.scrollHeight, behavior: 'smooth' });
}

/** 文件选择：模拟切片向量化进度，完成后调用 ragUpload 并刷新文档列表 */
function onFileChange(e: Event): void {
  const file = (e.target as HTMLInputElement).files?.[0];
  if (!file) return;
  uploading.value = true;
  uploadDone.value = false;
  uploadPercent.value = 0;
  vectorStatus.value = `正在解析「${file.name}」并生成向量…`;
  const chunkCount = Math.max(1, Math.ceil(file.size / 1024));
  const timer = window.setInterval(() => {
    uploadPercent.value = Math.min(100, uploadPercent.value + 18);
    if (uploadPercent.value >= 100) {
      window.clearInterval(timer);
      vectorStatus.value = `「${file.name}」向量化完成，共 ${chunkCount} 个切片`;
      uploadDone.value = true;
      void finishUpload(file.name, chunkCount);
    }
  }, 220);
}

/** 文档入库：ragUpload 生成向量记录，并写入文档列表供检索展示 */
async function finishUpload(fileName: string, chunkCount: number): Promise<void> {
  try {
    await aiApi.ragUpload({ fileName, chunkCount, status: 1 });
    await mockPost('/api/v1/ai/rag/docs', { title: fileName, chunkCount, status: 1 });
    await loadDocs();
    toast.success('文档已入库，可开始提问');
  } catch (e: any) {
    toast.error('入库失败：' + (e?.message || ''));
  }
}

/** 问答：调用 ragQuery，解析 sources 为引用来源（文档名 + 页码 / 段落） */
async function ask(): Promise<void> {
  const q = question.value.trim();
  if (!q || asking.value) return;
  question.value = '';
  messages.value.push({ role: 'user', content: q, citations: [] });
  asking.value = true;
  try {
    const r: any = await aiApi.ragQuery(q);
    const raw = r?.sources;
    const sources = Array.isArray(raw) ? raw : (raw ? String(raw).split(/[,，、]/).filter(Boolean) : []);
    const citations = sources.map((s: any) => ({
      doc: typeof s === 'string' ? s : (s.doc || s.title || '未知文档'),
      location: typeof s === 'string' ? '第 1 页 / 段落 1' : (s.location || `第 ${s.page || 1} 页 / 段落 1`),
      confidence: typeof s === 'object' ? (s.confidence ?? 0.9) : 0.9,
    }));
    messages.value.push({
      role: 'assistant',
      content: r.text || '（无回答）',
      citations,
      confidence: r.confidence ?? 0.9,
      fallback: !!r.fallback,
    });
  } catch (e: any) {
    messages.value.push({ role: 'assistant', content: '查询失败：' + (e?.message || ''), citations: [] });
  } finally {
    asking.value = false;
    await scroll();
  }
}
</script>

<style scoped>
.ai-rag-grid { display: grid; grid-template-columns: 380px 1fr; gap: 12px; align-items: start; }
.ai-upload { display: block; cursor: pointer; }
.ai-upload input { display: none; }
.ai-upload-box { display: flex; flex-direction: column; gap: 4px; padding: 14px; border: 1px dashed var(--ds-border-strong); border-radius: var(--ds-radius); text-align: center; }
.ai-upload-box b { color: var(--ds-brand); }
.ai-upload-box small { color: var(--ds-text-3); }
.ai-upload-progress { margin: 12px 0; }
.ai-upload-label { font-size: 12px; color: var(--ds-text-2); margin-bottom: 6px; }
.ai-table { width: 100%; border-collapse: collapse; font-size: 13px; margin-top: 12px; }
.ai-table th, .ai-table td { padding: 8px; border-bottom: 1px solid var(--ds-divider); text-align: left; }
.ai-table th { color: var(--ds-text-3); font-weight: 500; }
.ai-empty { text-align: center; color: var(--ds-text-3); padding: 16px; }
.ai-chat { height: 380px; overflow-y: auto; display: flex; flex-direction: column; gap: 12px; padding-right: 4px; }
.ai-msg { display: flex; flex-direction: column; align-items: flex-start; }
.ai-msg.user { align-items: flex-end; }
.ai-bubble { max-width: 88%; padding: 8px 12px; border-radius: 8px; background: var(--ds-bg-soft); white-space: pre-wrap; font-size: 13px; line-height: 1.6; }
.ai-msg.user .ai-bubble { background: var(--ds-brand); color: #fff; }
.ai-citations { margin-top: 6px; max-width: 92%; background: var(--ds-bg-elevated); border: 1px solid var(--ds-border); border-radius: 8px; padding: 8px 10px; }
.ai-cite-head { font-size: 12px; color: var(--ds-text-3); margin-bottom: 6px; display: flex; align-items: center; gap: 8px; }
.ai-cite { display: flex; align-items: center; gap: 8px; font-size: 12px; padding: 3px 0; }
.ai-cite-doc { color: var(--ds-brand); font-weight: 500; }
.ai-cite-loc { color: var(--ds-text-2); flex: 1; }
.ai-ask { display: flex; gap: 8px; margin-top: 12px; }
.ai-ask .ds-input { flex: 1; width: auto; }
@media (max-width: 900px) { .ai-rag-grid { grid-template-columns: 1fr; } }
</style>
