<!-- AI 智能对账：双方账单比对 → 差异表 → 采纳建议留痕 -->
<template>
  <div class="erp-page">
    <DsCard title="AI 智能对账" subtitle="粘贴己方与对方账单 CSV，AI 按金额 / 数量 / 日期模糊匹配并给出差异处置建议">
      <div class="ai-grid">
        <label class="ai-col">
          <span class="ai-subtitle">己方账单（CSV）</span>
          <textarea v-model="ours" class="ds-input" rows="10" placeholder="日期,摘要,金额,数量&#10;2026-11-17,销售收款,12800,10" />
        </label>
        <label class="ai-col">
          <span class="ai-subtitle">对方账单（CSV）</span>
          <textarea v-model="theirs" class="ds-input" rows="10" placeholder="日期,摘要,金额,数量&#10;2026-11-17,销售收款,12800,9" />
        </label>
      </div>
      <div class="ai-actions">
        <DsButton variant="primary" :loading="loading" @click="run">开始对账</DsButton>
        <DsButton @click="loadDemo">填入示例</DsButton>
      </div>
    </DsCard>

    <DsCard v-if="summary" title="对账结果" class="ai-gap" :pad="false">
      <div class="ai-summary">{{ summary }}</div>
      <table class="ai-table">
        <thead>
          <tr>
            <th>差异字段</th><th>己方</th><th>对方</th><th>差额</th><th>可能原因</th><th>置信度</th><th>建议动作</th><th>操作</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="(d, i) in differences" :key="i">
            <td>{{ d.field }}</td>
            <td>{{ d.ours }}</td>
            <td>{{ d.theirs }}</td>
            <td :class="Number(d.diff) !== 0 ? 'ai-diff' : ''">{{ d.diff }}</td>
            <td>{{ d.reason }}</td>
            <td><DsTag :color="Number(d.confidence) >= 0.8 ? 'success' : 'warning'" size="sm">{{ (Number(d.confidence) * 100).toFixed(0) }}%</DsTag></td>
            <td>{{ d.suggestion }}</td>
            <td><DsButton size="sm" :disabled="d.accepted" @click="accept(d)">{{ d.accepted ? '已采纳' : '采纳建议' }}</DsButton></td>
          </tr>
          <tr v-if="!differences.length"><td colspan="8" class="ai-empty">未发现差异或尚未对账</td></tr>
        </tbody>
      </table>
    </DsCard>
  </div>
</template>

<script setup lang="ts">
/** 智能对账：aiApi.reconcile 返回差异，用户确认后经 mockPost 记录采纳情况 */
import { ref } from 'vue';
import { aiApi } from '../../api';
import { mockPost } from '../../api/mockAdapter';
import { useToast } from '../../components/ds/toast';

const toast = useToast();
const ours = ref('');
const theirs = ref('');
const loading = ref(false);
const summary = ref('');
const differences = ref<any[]>([]);

const DEMO_OURS = '日期,摘要,金额,数量\n2026-11-17,销售收款,12800,10\n2026-11-16,采购付款,5600,200';
const DEMO_THEIRS = '日期,摘要,金额,数量\n2026-11-17,销售收款,12800,9\n2026-11-16,采购付款,5500,200';

/** 填入演示账单，便于快速体验 */
function loadDemo(): void { ours.value = DEMO_OURS; theirs.value = DEMO_THEIRS; }

/** 开始对账：调用 AI 接口并补全可能原因 / 置信度 / 建议动作 */
async function run(): Promise<void> {
  if (!ours.value.trim() || !theirs.value.trim()) { toast.warning('请填写双方账单 CSV'); return; }
  loading.value = true;
  try {
    const r: any = await aiApi.reconcile({ ours: ours.value, theirs: theirs.value });
    summary.value = r.text || '对账完成';
    const rows = Array.isArray(r.differences) ? r.differences : [];
    differences.value = rows.map((d: any) => {
      const diff = Number(d.diff ?? (Number(d.theirs || 0) - Number(d.ours || 0)));
      const isZero = diff === 0;
      const field = String(d.field || '未分类');
      return {
        field,
        ours: d.ours ?? '',
        theirs: d.theirs ?? '',
        diff: String(diff),
        reason: d.reason || (isZero
          ? '金额 / 数量一致，无差异'
          : field.includes('数量') ? '对方数量少计，可能漏记或单位换算不一致' : '金额不一致，可能含税 / 运费或汇率差异'),
        confidence: d.confidence ?? (isZero ? 0.99 : 0.86),
        suggestion: d.suggestion || (isZero ? '无需处理' : '建议与对方核实原始单据后调整'),
        accepted: false,
      };
    });
    toast.success('对账完成');
  } catch (e: any) {
    toast.error('对账失败：' + (e?.message || ''));
  } finally {
    loading.value = false;
  }
}

/** 采纳建议：AI 仅给建议，采纳动作通过业务接口留痕 */
async function accept(d: any): Promise<void> {
  try {
    await mockPost('/api/v1/ai/reconcile/accept', { ...d, acceptedAt: new Date().toISOString() });
    d.accepted = true;
    toast.success('已采纳建议并记录');
  } catch (e: any) {
    toast.error('记录失败：' + (e?.message || ''));
  }
}
</script>

<style scoped>
.ai-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
.ai-col { min-width: 0; display: flex; flex-direction: column; }
.ai-subtitle { font-size: 14px; margin-bottom: 10px; }
textarea.ds-input { width: 100%; box-sizing: border-box; resize: vertical; }
.ai-actions { display: flex; gap: 8px; margin-top: 12px; }
.ai-gap { margin-top: 12px; }
.ai-summary { padding: 12px 18px; background: var(--ds-brand-soft); color: var(--ds-brand); font-size: 13px; }
.ai-table { width: 100%; border-collapse: collapse; font-size: 13px; }
.ai-table th, .ai-table td { padding: 9px 12px; border-bottom: 1px solid var(--ds-divider); text-align: left; }
.ai-table th { background: var(--ds-bg-soft); color: var(--ds-text-3); font-weight: 500; }
.ai-diff { color: var(--ds-danger); font-weight: 600; }
.ai-empty { text-align: center; color: var(--ds-text-3); padding: 24px; }
@media (max-width: 900px) { .ai-grid { grid-template-columns: 1fr; } }
</style>
