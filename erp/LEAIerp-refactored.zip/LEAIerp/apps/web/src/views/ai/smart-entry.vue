<template>
  <div class="erp-page">
    <DsCard title="AI 智能建单">
      <template #extra><RouterLink to="/ai/ocr" class="ds-btn ds-btn-default ds-btn-sm">图片 OCR</RouterLink></template>
      <label class="entry-label">单据文字
        <textarea v-model.trim="text" class="ds-input entry-text" rows="5" placeholder="粘贴客户、商品、数量和单价" :disabled="saving" />
      </label>
      <div class="record-buttons">
        <DsButton size="sm" variant="primary" :disabled="!text || saving || loading" :loading="parsing" @click="parse">提取字段</DsButton>
      </div>
      <p v-if="result" class="entry-result">{{ result }}</p>
      <p v-if="error" role="alert" class="record-error">{{ error }}</p>
      <p v-if="loading" role="status">加载销售主数据…</p>
      <form v-else class="entry-form" @submit.prevent="save">
        <div class="record-form">
          <label>客户 <select v-model.number="customerId" class="ds-select" required>
            <option value="">请选择客户</option>
            <option v-for="customer in customers" :key="customer.id" :value="Number(customer.id)">{{ customer.name }}</option>
          </select></label>
          <label>出货仓库 <select v-model.number="warehouseId" class="ds-select" required>
            <option value="">请选择仓库</option>
            <option v-for="warehouse in warehouses" :key="warehouse.id" :value="Number(warehouse.id)">{{ warehouse.name }}</option>
          </select></label>
          <label>日期 <input v-model="date" class="ds-input" type="date" required /></label>
        </div>
        <div class="record-table">
          <table class="ds-table">
            <thead><tr><th>商品</th><th>数量</th><th>单价</th><th></th></tr></thead>
            <tbody>
              <tr v-for="(line, index) in lines" :key="index">
                <td><select v-model.number="line.productId" class="ds-select" :aria-label="'明细 ' + (index + 1) + ' 商品'" required>
                  <option value="">{{ line.suggested || '请选择商品' }}</option>
                  <option v-for="product in products" :key="product.id" :value="Number(product.id)">{{ product.name }}</option>
                </select></td>
                <td><input v-model="line.qty" class="ds-input" type="number" min="0.001" step="0.001" required aria-label="数量" /></td>
                <td><input v-model="line.unitPrice" class="ds-input" type="number" min="0" step="0.01" required aria-label="单价" /></td>
                <td><DsButton size="sm" variant="text" :disabled="lines.length === 1" @click="lines.splice(index, 1)">移除</DsButton></td>
              </tr>
            </tbody>
          </table>
        </div>
        <DsButton size="sm" @click="lines.push(blankLine())">添加明细</DsButton>
        <div class="record-buttons">
          <label><input v-model="confirmed" type="checkbox" /> 已核对客户、仓库和商品明细</label>
          <DsButton v-perm="'sales:order:create'" type="submit" variant="primary" :loading="saving" :disabled="!confirmed || parsing">
            保存销售草稿
          </DsButton>
        </div>
      </form>
    </DsCard>
  </div>
</template>

<script setup lang="ts">
import { onMounted, ref, watch } from 'vue';
import { useRouter } from 'vue-router';
import { DsButton, DsCard } from '../../components';
import { useToast } from '../../components/ds/toast';
import { pageData, pageRows, type BusinessRow } from '../../api/pageData';

const router = useRouter();
const toast = useToast();
const text = ref('');
const result = ref('');
const error = ref('');
const loading = ref(true);
const parsing = ref(false);
const saving = ref(false);
const confirmed = ref(false);
const customers = ref<BusinessRow[]>([]);
const warehouses = ref<BusinessRow[]>([]);
const products = ref<BusinessRow[]>([]);
const customerId = ref<number | ''>('');
const warehouseId = ref<number | ''>('');
const date = ref(new Date().toLocaleDateString('sv-SE'));
const blankLine = () => ({ productId: '' as number | '', qty: '1', unitPrice: '0.00', suggested: '' });
const lines = ref([blankLine()]);

watch([text, customerId, warehouseId, date, lines], () => { confirmed.value = false; }, { deep: true });

onMounted(async () => {
  try {
    const [customerData, warehouseData, productData] = await Promise.all([
      pageData('GET', '/api/v1/crm/customers', { pageSize: 200 }),
      pageData('GET', '/api/v1/inventory/warehouses'),
      pageData('GET', '/api/v1/inventory/products', { pageSize: 200 }),
    ]);
    customers.value = pageRows(customerData);
    warehouses.value = pageRows(warehouseData);
    products.value = pageRows(productData).filter((product) => ![2, 3].includes(Number(product.type)));
  } catch (cause) {
    error.value = cause instanceof Error ? cause.message : '销售主数据加载失败';
  } finally {
    loading.value = false;
  }
});

async function parse() {
  if (!text.value || parsing.value) return;
  parsing.value = true;
  confirmed.value = false;
  error.value = '';
  result.value = '';
  try {
    const reply = await pageData<{ text?: string; fields?: BusinessRow; fallback?: boolean }>('POST', '/api/v1/ai/doc-parse', { content: text.value });
    result.value = reply.text ?? '';
    let fields = reply.fields;
    if (!fields && reply.text) {
      try {
        const parsed = JSON.parse(reply.text.replace(/^\s*```(?:json)?\s*|\s*```\s*$/gi, ''));
        fields = parsed.fields ?? parsed;
      } catch { /* 保留可供核对的原始模型结果 */ }
    }
    if (fields?.customerName) customerId.value = Number(customers.value.find((row) => row.name === fields.customerName)?.id) || '';
    const items = fields?.items ?? fields?.lines;
    if (Array.isArray(items) && items.length) {
      lines.value = items.slice(0, 100).map((item) => {
        const suggested = String(item.productName ?? item.name ?? item.productCode ?? '');
        const product = products.value.find((row) => row.code === item.productCode || row.name === suggested);
        return { productId: Number(product?.id) || '', qty: String(item.qty ?? 1), unitPrice: String(item.unitPrice ?? item.price ?? 0), suggested };
      });
    }
  } catch (cause) {
    error.value = cause instanceof Error ? cause.message : '字段提取失败';
  } finally {
    parsing.value = false;
  }
}

async function save() {
  if (!confirmed.value || saving.value || !customerId.value || !warehouseId.value || lines.value.some((line) => !line.productId)) return;
  saving.value = true;
  error.value = '';
  try {
    await pageData('POST', '/api/v1/sales/orders', {
      customerId: customerId.value, warehouseId: warehouseId.value, orderDate: date.value,
      lines: lines.value.map((line) => ({ productId: line.productId, qty: String(line.qty), unitPrice: String(line.unitPrice), warehouseId: warehouseId.value })),
      remark: 'AI 建单草稿，已人工核对',
    });
    toast.success('销售草稿已保存');
    await router.push('/sales/orders');
  } catch (cause) {
    error.value = cause instanceof Error ? cause.message : '销售草稿保存失败';
  } finally {
    saving.value = false;
  }
}
</script>

<style src="../records/recordPage.css"></style>
<style scoped>
.entry-label, .entry-form { display: grid; gap: 12px; }
.entry-form { margin-top: 18px; }
.entry-form > button { justify-self: start; }
.entry-label { margin-bottom: 10px; }
.entry-text { width: 100%; box-sizing: border-box; }
.entry-result { white-space: pre-wrap; overflow-wrap: anywhere; padding: 12px; background: var(--ds-bg-soft); }
</style>
