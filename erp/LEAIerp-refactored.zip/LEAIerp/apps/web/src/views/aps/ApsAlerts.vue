<template>
  <div class="erp-page aps-page">
    <div class="aps-head">
      <h2>排产预警</h2>
      <DsButton size="sm" :loading="loading" @click="load">刷新</DsButton>
    </div>
    <p v-if="error" class="aps-load-error" role="alert">{{ error }}</p>
    <p v-else-if="loading" role="status">正在加载…</p>
    <template v-else>
      <DsCard title="排产异常预警" :pad="false">
        <table class="aps-table">
          <thead><tr><th>类型</th><th>级别</th><th>标题</th><th>详细说明</th><th>关联单号</th><th>状态</th><th>操作</th></tr></thead>
          <tbody>
            <tr v-for="a in alerts" :key="a.id">
              <td>{{ alertTypeText(a.alertType) }}</td>
              <td><DsTag size="sm" :color="a.level === 'HIGH' ? 'danger' : a.level === 'MED' ? 'warning' : 'neutral'">{{ a.level }}</DsTag></td>
              <td>{{ a.title }}</td><td class="aps-detail">{{ a.detail }}</td><td>{{ a.bizNo }}</td>
              <td><DsTag size="sm" :color="a.status === 'OPEN' ? 'warning' : 'success'">{{ a.status === 'OPEN' ? '待处理' : '已处理' }}</DsTag></td>
              <td><DsButton v-if="a.status === 'OPEN'" size="sm" @click="perform(() => resolve(a))" :disabled="acting">标记处理</DsButton></td>
            </tr>
            <tr v-if="!alerts.length"><td colspan="7" class="aps-empty">暂无异常预警</td></tr>
          </tbody>
        </table>
      </DsCard>
    </template>

  </div>
</template>

<script setup lang="ts">
import { onMounted, ref } from 'vue';
import { DsButton, DsCard, DsTag } from '../../components';
import { apsApi } from '../../api';
import { useToast } from '../../components/ds/toast';
import { pageRows as asList } from '../../api/pageData';

const toast = useToast();
const error = ref('');
const loading = ref(false);
const acting = ref(false);
const alerts = ref<any[]>([]);

async function load() {
  if (loading.value) return;
  loading.value = true;
  error.value = '';
  try {
    alerts.value = asList(await apsApi.alerts());
  } catch (cause) {
    error.value = cause instanceof Error ? cause.message : '加载失败，请重试';
  } finally {
    loading.value = false;
  }
}

async function perform(action: () => Promise<void>) {
  if (acting.value) return;
  acting.value = true;
  try {
    await action();
  } catch (cause) {
    toast.error(cause instanceof Error ? cause.message : '操作失败');
  } finally {
    acting.value = false;
  }
}

function alertTypeText(s: string): string { return ({ CAPACITY: '产能超载', DUE: '交期风险', MATERIAL: '物料短缺' } as any)[s] || s; }

async function resolve(a: any): Promise<void> {
  await apsApi.resolveAlert(a.id);
  toast.success('预警已标记为处理完成');
  await load();
}

onMounted(load);
</script>

<style src="./apsPage.css" scoped></style>
