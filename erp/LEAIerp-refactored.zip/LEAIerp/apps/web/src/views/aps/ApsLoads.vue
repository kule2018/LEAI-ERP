<template>
  <div class="erp-page aps-page">
    <div class="aps-head">
      <h2>产能负荷</h2>
      <DsButton size="sm" :loading="loading" @click="load">刷新</DsButton>
    </div>
    <p v-if="error" class="aps-load-error" role="alert">{{ error }}</p>
    <p v-else-if="loading" role="status">正在加载…</p>
    <template v-else>
      <DsCard title="产能负荷分析" :pad="false">
        <template #extra><DsButton size="sm" @click="perform(rebuild)" :loading="acting">重算负荷</DsButton></template>
        <table class="aps-table">
          <thead><tr><th>日期</th><th>工作中心</th><th>可用工时</th><th>计划工时</th><th>负荷率</th><th>任务数</th><th>等级</th><th>瓶颈</th></tr></thead>
          <tbody>
            <tr v-for="l in loads" :key="l.id" :class="{ 'aps-over': l.level === 'OVER' }">
              <td>{{ l.loadDate }}</td><td>{{ l.workCenter }}</td><td>{{ l.availableHours }}h</td>
              <td>{{ l.plannedHours }}h</td><td>{{ l.loadRate }}%</td><td>{{ l.taskCount }}</td>
              <td><DsTag size="sm" :color="loadColor(l.level)">{{ loadText(l.level) }}</DsTag></td>
              <td>{{ l.bottleneck ? '是' : '否' }}</td>
            </tr>
            <tr v-if="!loads.length"><td colspan="8" class="aps-empty">暂无负荷数据，请先执行排产运算</td></tr>
          </tbody>
        </table>
      </DsCard>
    </template>

  </div>
</template>

<script setup lang="ts">
import { onMounted, ref } from 'vue';
import { DsButton, DsCard, DsTag } from '../../components';
import { apsApi } from '../../api';
import { useToast } from '../../components/ds/toast';
import { pageRows as asList } from '../../api/pageData';

const toast = useToast();
const error = ref('');
const loading = ref(false);
const acting = ref(false);
const loads = ref<any[]>([]);

async function load() {
  if (loading.value) return;
  loading.value = true;
  error.value = '';
  try {
    loads.value = asList(await apsApi.loads({ pageSize: 200 }));
  } catch (cause) {
    error.value = cause instanceof Error ? cause.message : '加载失败，请重试';
  } finally {
    loading.value = false;
  }
}

async function perform(action: () => Promise<void>) {
  if (acting.value) return;
  acting.value = true;
  try {
    await action();
  } catch (cause) {
    toast.error(cause instanceof Error ? cause.message : '操作失败');
  } finally {
    acting.value = false;
  }
}

function loadText(s: string): string { return ({ IDLE: '空闲', NORMAL: '正常', WARN: '偏高', OVER: '超载' } as any)[s] || s; }

function loadColor(s: string): any { return s === 'OVER' ? 'danger' : s === 'WARN' ? 'warning' : s === 'IDLE' ? 'neutral' : 'success'; }

async function rebuild(): Promise<void> {
  await apsApi.rebuildLoads();
  await load();
  toast.success('负荷已按当前工序任务重算');
}

onMounted(load);
</script>

<style src="./apsPage.css" scoped></style>
