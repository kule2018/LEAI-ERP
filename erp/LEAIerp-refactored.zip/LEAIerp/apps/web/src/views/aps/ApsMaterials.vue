<template>
  <div class="erp-page aps-page">
    <div class="aps-head">
      <h2>齐套检查</h2>
      <DsButton size="sm" :loading="loading" @click="load">刷新</DsButton>
    </div>
    <p v-if="error" class="aps-load-error" role="alert">{{ error }}</p>
    <p v-else-if="loading" role="status">正在加载…</p>
    <template v-else>
      <DsCard title="物料齐套检查" :pad="false">
        <template #extra>
          <div class="aps-tools">
            <select v-model="checkPlanNo" class="ds-input aps-select">
              <option value="">全部计划</option>
              <option v-for="p in plans" :key="p.id" :value="p.planNo">{{ p.planNo }} {{ p.planName }}</option>
            </select>
            <DsButton size="sm" variant="primary" @click="perform(doMaterialCheck)" :loading="acting">执行检查</DsButton>
          </div>
        </template>
        <table class="aps-table">
          <thead><tr><th>检查单号</th><th>生产计划</th><th>物料</th><th>需求</th><th>可用</th><th>缺口</th><th>状态</th><th>检查时间</th></tr></thead>
          <tbody>
            <tr v-for="x in materials" :key="x.id">
              <td>{{ x.checkNo }}</td><td>{{ x.planNo }}</td><td>{{ x.materialName }}</td>
              <td>{{ x.requireQty }}</td><td>{{ x.availableQty }}</td>
              <td :class="{ 'aps-danger-text': x.shortQty > 0 }">{{ x.shortQty }}</td>
              <td><DsTag size="sm" :color="x.status === 'SHORT' ? 'danger' : 'success'">{{ x.status === 'SHORT' ? '缺料' : '齐套' }}</DsTag></td>
              <td>{{ x.checkedAt }}</td>
            </tr>
            <tr v-if="!materials.length"><td colspan="8" class="aps-empty">暂无检查记录，点击「执行检查」核对物料齐套情况</td></tr>
          </tbody>
        </table>
      </DsCard>
    </template>

  </div>
</template>

<script setup lang="ts">
import { onMounted, ref } from 'vue';
import { DsButton, DsCard, DsTag } from '../../components';
import { apsApi } from '../../api';
import { useToast } from '../../components/ds/toast';
import { pageRows as asList } from '../../api/pageData';

const toast = useToast();
const error = ref('');
const loading = ref(false);
const acting = ref(false);
const plans = ref<any[]>([]);
const materials = ref<any[]>([]);
const checkPlanNo = ref('');

async function load() {
  if (loading.value) return;
  loading.value = true;
  error.value = '';
  try {
    const [planData, materialData] = await Promise.all([apsApi.plans({ pageSize: 200 }), apsApi.materials()]);
    plans.value = asList(planData);
    materials.value = asList(materialData);
    if (checkPlanNo.value) materials.value = materials.value.filter((row) => row.planNo === checkPlanNo.value);
  } catch (cause) {
    error.value = cause instanceof Error ? cause.message : '加载失败，请重试';
  } finally {
    loading.value = false;
  }
}

async function perform(action: () => Promise<void>) {
  if (acting.value) return;
  acting.value = true;
  try {
    await action();
  } catch (cause) {
    toast.error(cause instanceof Error ? cause.message : '操作失败');
  } finally {
    acting.value = false;
  }
}

async function doMaterialCheck(): Promise<void> {
  try {
    const p = plans.value.find((x) => x.planNo === checkPlanNo.value);
    const res: any = await apsApi.materialCheck(p?.id);
    toast.success(`齐套检查完成：缺料 ${res.shortCount} 项`);
    await load();
  } catch (e: any) { toast.error(e?.message || '检查失败'); }
}

onMounted(load);
</script>

<style src="./apsPage.css" scoped></style>
