<template>
  <div class="erp-page aps-page">
    <div class="aps-head">
      <h2>生产计划</h2>
      <DsButton size="sm" :loading="loading" @click="load">刷新</DsButton>
    </div>
    <p v-if="error" class="aps-load-error" role="alert">{{ error }}</p>
    <p v-else-if="loading" role="status">正在加载…</p>
    <template v-else>
      <DsCard title="生产计划清单" :pad="false">
        <template #extra>
          <div class="aps-tools">
            <DsButton size="sm" variant="primary" @click="openPlan">新增计划</DsButton>
            <RouterLink to="/aps/schedule" class="ds-btn ds-btn-default ds-btn-sm">排产工作台</RouterLink>
            <RouterLink to="/aps/materials" class="ds-btn ds-btn-default ds-btn-sm">齐套检查</RouterLink>
          </div>
        </template>
        <table class="aps-table">
          <thead><tr><th>计划单号</th><th>计划名称</th><th>产品</th><th>数量</th><th>优先级</th><th>需求日期</th><th>工作中心</th><th>状态</th><th>操作</th></tr></thead>
          <tbody>
            <tr v-for="p in plans" :key="p.id">
              <td>{{ p.planNo }}</td><td>{{ p.planName }}</td><td>{{ p.productName }}</td>
              <td>{{ p.qty }}</td>
              <td><DsTag size="sm" :color="p.priority === 'P1' ? 'danger' : p.priority === 'P2' ? 'warning' : 'neutral'">{{ p.priority }}</DsTag></td>
              <td>{{ p.dueDate }}</td><td>{{ p.workCenter }}</td>
              <td><DsTag size="sm" :color="planColor(p.status)">{{ planText(p.status) }}</DsTag></td>
              <td class="aps-ops">
                <DsButton v-if="p.status === 'DRAFT'" size="sm" variant="primary" @click="perform(() => planAction(p, 'confirm'))">确认</DsButton>
                <RouterLink v-if="p.status === 'CONFIRMED'" :to="{ path: '/aps/schedule', query: { planId: p.id } }" class="ds-btn ds-btn-default ds-btn-sm">排产</RouterLink>
                <DsButton v-if="p.status === 'SCHEDULED'" size="sm" variant="primary" @click="perform(() => planAction(p, 'issue'))">下达工单</DsButton>
                <DsButton v-if="p.status === 'ISSUED'" size="sm" @click="perform(() => planAction(p, 'complete'))">完工</DsButton>
                <DsButton v-if="!['COMPLETED', 'CANCELLED'].includes(p.status)" size="sm" variant="text" @click="perform(() => planAction(p, 'cancel'))">作废</DsButton>
              </td>
            </tr>
            <tr v-if="!plans.length"><td colspan="9" class="aps-empty">暂无生产计划，点击「新增计划」开始</td></tr>
          </tbody>
        </table>
      </DsCard>
    </template>
    <DsModal v-model="planVisible" title="新增生产计划" :width="560">
      <div class="aps-form">
        <label><span>计划名称 *</span><input v-model="form.planName" class="ds-input" placeholder="如：智能温控器 12 月补单" /></label>
        <label><span>生产产品 *</span><select v-model.number="form.productId" class="ds-input">
          <option v-for="product in products" :key="product.id" :value="product.id">{{ product.name }}（{{ product.code }}）</option>
        </select></label>
        <label><span>计划数量 *</span><input v-model.number="form.qty" class="ds-input" type="number" min="1" /></label>
        <label><span>需求日期 *</span><input v-model="form.dueDate" class="ds-input" type="date" /></label>
        <label><span>优先级</span><select v-model="form.priority" class="ds-input">
          <option value="P1">P1 紧急</option><option value="P2">P2 较高</option><option value="P3">P3 普通</option>
        </select></label>
        <label><span>主工作中心</span><select v-model="form.workCenter" class="ds-input">
          <option v-for="c in centers" :key="c" :value="c">{{ c }}</option>
        </select></label>
        <label><span>需求来源</span><select v-model="form.sourceType" class="ds-input">
          <option value="SALES">销售订单</option><option value="FORECAST">销售预测</option><option value="MANUAL">手工录入</option>
        </select></label>
        <label><span>来源单号</span><input v-model="form.sourceNo" class="ds-input" placeholder="选填" /></label>
        <label class="full"><span>备注</span><input v-model="form.remark" class="ds-input" placeholder="选填" /></label>
      </div>
      <template #footer><div class="aps-foot">
        <DsButton @click="planVisible = false">取消</DsButton>
        <DsButton variant="primary" @click="perform(savePlan)" :loading="acting">创建计划</DsButton>
      </div></template>
    </DsModal>
  </div>
</template>

<script setup lang="ts">
import { onMounted, ref, reactive } from 'vue';
import { DsButton, DsCard, DsModal, DsTag } from '../../components';
import { apsApi } from '../../api';
import { useToast } from '../../components/ds/toast';
import { pageData, pageRows as asList, type BusinessRow } from '../../api/pageData';
const toast = useToast();
const error = ref('');
const loading = ref(false);
const acting = ref(false);
const plans = ref<any[]>([]);
const centers = ref<string[]>([]);
const products = ref<BusinessRow[]>([]);
const planVisible = ref(false);
const form = reactive<any>({ planName: '', productId: 0, qty: 100, dueDate: '', priority: 'P2', workCenter: '', sourceType: 'MANUAL', sourceNo: '', remark: '' });

async function load() {
  if (loading.value) return;
  loading.value = true;
  error.value = '';
  try {
    const [planData, resourceData, productData] = await Promise.all([
      apsApi.plans({ pageSize: 200 }),
      apsApi.resources(),
      pageData<BusinessRow[] | { list: BusinessRow[] }>('GET', '/api/v1/inventory/products', { pageSize: 200 }),
    ]);
    plans.value = asList(planData);
    centers.value = [...new Set(asList(resourceData).map((row) => String(row.workCenter || row.work_center || row.name || '')).filter(Boolean))];
    products.value = asList(productData);
  } catch (cause) {
    error.value = cause instanceof Error ? cause.message : '加载失败，请重试';
  } finally {
    loading.value = false;
  }
}

async function perform(action: () => Promise<void>) {
  if (acting.value) return;
  acting.value = true;
  try {
    await action();
  } catch (cause) {
    toast.error(cause instanceof Error ? cause.message : '操作失败');
  } finally {
    acting.value = false;
  }
}

function planText(s: string): string {
  return ({ DRAFT: '草稿', CONFIRMED: '已确认', SCHEDULED: '已排产', ISSUED: '已下达', COMPLETED: '已完成', CANCELLED: '已作废' } as any)[s] || s;
}

function planColor(s: string): any { return s === 'COMPLETED' ? 'success' : s === 'CANCELLED' ? 'neutral' : s === 'DRAFT' ? 'warning' : 'brand'; }

function openPlan(): void {
  const d = new Date(Date.now() + 7 * 86400000);
  form.planName = '';
  form.qty = 100;
  form.productId = products.value[0]?.id || 0;
  form.workCenter = centers.value[0] || '';
  form.dueDate = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  form.sourceNo = '';
  form.remark = '';
  planVisible.value = true;
}

async function savePlan(): Promise<void> {
  const product = products.value.find((row) => row.id === form.productId);
  if (!form.planName.trim() || !product || !(form.qty > 0) || !form.dueDate) { toast.warning('请填写计划名称、数量与需求日期'); return; }
  const planNo = 'PP-' + crypto.randomUUID().slice(0, 18).toUpperCase();
  await apsApi.savePlan({ ...form, productName: product.name, planNo, planStart: form.dueDate, status: 'DRAFT' });
  planVisible.value = false;
  toast.success('生产计划已创建，请确认后排产');
  await load();
}

async function planAction(p: any, action: 'confirm' | 'issue' | 'complete' | 'cancel'): Promise<void> {
  try {
    await apsApi.planAction(p.id, action);
    toast.success(`${p.planNo} 已${action === 'confirm' ? '确认' : action === 'issue' ? '下达工单' : action === 'complete' ? '完工' : '作废'}`);
    await load();
  } catch (e: any) { toast.error(e?.message || '操作失败'); }
}

onMounted(load);
</script>

<style src="./apsPage.css" scoped></style>
