<!-- 工作中心与工作日历：维护排产所需资源产能、班次与停产日 -->
<template>
  <div class="erp-page rc-page">
    <div class="rc-head">
      <div><h2>工作中心与工作日历</h2><p>维护产能基线与可工作日期，排产引擎按日历逐日分配工序工时</p></div>
    </div>

    <DsCard title="工作中心 / 产线" :pad="false">
      <template #extra><DsButton size="sm" variant="primary" @click="openResource">新增工作中心</DsButton></template>
      <table class="rc-table">
        <thead><tr><th>编码</th><th>名称</th><th>车间</th><th>班次工时</th><th>效率(%)</th><th>日产能</th><th>负责人</th><th>状态</th><th>操作</th></tr></thead>
        <tbody>
          <tr v-for="r in resources" :key="r.id">
            <td>{{ r.code }}</td><td>{{ r.name }}</td><td>{{ r.workshop }}</td><td>{{ r.shiftHours }}h</td>
            <td>{{ r.efficiency }}</td><td>{{ r.dailyCapacity }}</td><td>{{ r.manager }}</td>
            <td><DsTag size="sm" :color="r.status === 'ENABLED' ? 'success' : 'neutral'">{{ r.status === 'ENABLED' ? '可用' : '停用' }}</DsTag></td>
            <td><DsButton size="sm" variant="text" @click="openResource(r)">编辑</DsButton></td>
          </tr>
        </tbody>
      </table>
    </DsCard>

    <DsCard title="工作日历" :pad="false" class="rc-calendar">
      <template #extra>
        <div class="rc-tools">
          <select v-model="filterCenter" class="ds-input rc-select">
            <option value="">全部工作中心</option>
            <option v-for="r in resources" :key="r.name" :value="r.name">{{ r.name }}</option>
          </select>
          <DsButton size="sm" @click="openBatch">批量生成</DsButton>
        </div>
      </template>
      <table class="rc-table">
        <thead><tr><th>日期</th><th>工作中心</th><th>班次</th><th>可用工时</th><th>是否工作日</th><th>原因</th><th>操作</th></tr></thead>
        <tbody>
          <tr v-for="c in filteredCalendars" :key="c.id">
            <td>{{ c.calendarDate }}</td><td>{{ c.workCenter }}</td><td>{{ c.shiftType }}</td>
            <td>{{ c.availableHours }}h</td>
            <td><DsTag size="sm" :color="c.isWorking ? 'success' : 'neutral'">{{ c.isWorking ? '是' : '否' }}</DsTag></td>
            <td>{{ c.reason }}</td>
            <td><DsButton size="sm" variant="text" @click="toggleWorking(c)">{{ c.isWorking ? '设为停产' : '设为工作' }}</DsButton></td>
          </tr>
          <tr v-if="!filteredCalendars.length"><td colspan="7" class="rc-empty">暂无日历，点击「批量生成」创建未来工作日</td></tr>
        </tbody>
      </table>
    </DsCard>

    <DsModal v-model="resourceVisible" title="工作中心" :width="480">
      <div class="rc-form">
        <label><span>编码</span><input v-model="rForm.code" class="ds-input" /></label>
        <label><span>名称</span><input v-model="rForm.name" class="ds-input" /></label>
        <label><span>所属车间</span><input v-model="rForm.workshop" class="ds-input" /></label>
        <label><span>负责人</span><input v-model="rForm.manager" class="ds-input" /></label>
        <label><span>班次工时</span><input v-model.number="rForm.shiftHours" class="ds-input" type="number" /></label>
        <label><span>设备效率(%)</span><input v-model.number="rForm.efficiency" class="ds-input" type="number" /></label>
        <label><span>日产能(件)</span><input v-model.number="rForm.dailyCapacity" class="ds-input" type="number" /></label>
        <label><span>状态</span><select v-model="rForm.status" class="ds-input">
          <option value="ENABLED">可用</option><option value="DISABLED">停用</option>
        </select></label>
      </div>
      <template #footer><div class="rc-foot">
        <DsButton @click="resourceVisible = false">取消</DsButton>
        <DsButton variant="primary" @click="saveResource">保存</DsButton>
      </div></template>
    </DsModal>

    <DsModal v-model="batchVisible" title="批量生成工作日历" :width="460">
      <div class="rc-form">
        <label><span>起始日期</span><input v-model="bForm.startDate" class="ds-input" type="date" /></label>
        <label><span>生成天数</span><input v-model.number="bForm.days" class="ds-input" type="number" min="1" max="90" /></label>
        <label><span>每日工时</span><input v-model.number="bForm.defaultHours" class="ds-input" type="number" min="0" max="24" /></label>
        <div class="rc-note"> weekends 自动置为停产；已存在的日期不会重复生成。</div>
      </div>
      <template #footer><div class="rc-foot">
        <DsButton @click="batchVisible = false">取消</DsButton>
        <DsButton variant="primary" @click="doBatch">生成</DsButton>
      </div></template>
    </DsModal>
  </div>
</template>

<script setup lang="ts">
/** 工作中心与日历：通用 REST 集合由 Mock 兜底 CRUD 接管，切换工作日后立即重排负荷 */
import { computed, onMounted, reactive, ref } from 'vue';
import { DsButton, DsCard, DsModal, DsTag } from '../../components';
import { apsApi } from '../../api';
import { useToast } from '../../components/ds/toast';

const toast = useToast();
const resources = ref<any[]>([]);
const calendars = ref<any[]>([]);
const filterCenter = ref('');
const resourceVisible = ref(false);
const batchVisible = ref(false);
const rForm = reactive<any>({ id: 0, code: '', name: '', workshop: '', manager: '', shiftHours: 8, efficiency: 90, dailyCapacity: 60, status: 'ENABLED' });
const bForm = reactive<any>({ startDate: '', days: 14, defaultHours: 8 });

function asList(x: any): any[] { return Array.isArray(x) ? x : x?.list || []; }
const filteredCalendars = computed(() => calendars.value
  .filter((c) => !filterCenter.value || c.workCenter === filterCenter.value)
  .sort((a, b) => String(a.calendarDate).localeCompare(String(b.calendarDate)) || String(a.workCenter).localeCompare(String(b.workCenter))));

async function load(): Promise<void> {
  const [r, c] = await Promise.all([apsApi.resources(), apsApi.calendars({ pageSize: 500 })]);
  resources.value = asList(r);
  calendars.value = asList(c);
}

function openResource(row?: any): void {
  Object.assign(rForm, row || { id: 0, code: '', name: '', workshop: '', manager: '', shiftHours: 8, efficiency: 90, dailyCapacity: 60, status: 'ENABLED' });
  resourceVisible.value = true;
}

async function saveResource(): Promise<void> {
  if (!rForm.name) { toast.warning('请填写工作中心名称'); return; }
  await apsApi.saveResource({ ...rForm });
  resourceVisible.value = false;
  toast.success('工作中心已保存');
  await load();
}

function openBatch(): void {
  bForm.startDate = new Date().toISOString().slice(0, 10);
  batchVisible.value = true;
}

async function doBatch(): Promise<void> {
  const res: any = await apsApi.batchCalendar({ ...bForm });
  batchVisible.value = false;
  toast.success(`已生成 ${res.created} 条日历记录`);
  await load();
}

/** 切换工作日/停产日：直接走通用 REST 更新，负荷随后可在工作台重算 */
async function toggleWorking(c: any): Promise<void> {
  const working = c.isWorking ? 0 : 1;
  await apsApi.saveCalendar({ ...c, isWorking: working, shiftType: working ? '白班' : '停产', availableHours: working ? (c.availableHours || 8) : 0, reason: working ? '正常班次' : '手动设为停产' });
  toast.success(working ? '已设为工作日' : '已设为停产日');
  await load();
}

onMounted(load);
</script>

<style scoped>
.rc-page { padding: 16px; }
.rc-head h2 { font-size: 18px; margin: 0 0 4px; }
.rc-head p { font-size: 12px; color: var(--ds-text-3); margin: 0 0 14px; }
.rc-calendar { margin-top: 14px; }
.rc-tools { display: flex; gap: 8px; align-items: center; }
.rc-select { width: 200px; }
.rc-table { width: 100%; border-collapse: collapse; font-size: 12px; }
.rc-table th, .rc-table td { padding: 8px 10px; text-align: left; border-bottom: 1px solid var(--ds-divider); }
.rc-table th { background: var(--ds-bg-soft); color: var(--ds-text-2); }
.rc-empty { text-align: center; color: var(--ds-text-3); padding: 20px; }
.rc-form { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
.rc-form label { display: flex; flex-direction: column; gap: 5px; font-size: 12px; }
.rc-form label span { color: var(--ds-text-2); }
.rc-note { grid-column: 1 / -1; font-size: 12px; color: var(--ds-text-3); }
.rc-foot { display: flex; justify-content: flex-end; gap: 8px; }
</style>
