<!-- 排产运算记录与工序任务明细：追溯每次运算策略、结果与生成的排产任务 -->
<template>
  <div class="erp-page rh-page">
    <div class="rh-head"><h2>排产记录与工序任务</h2><p>按运算批次追溯排产策略、交期风险与工序执行状态</p></div>
    <DsCard title="运算批次" :pad="false">
      <table class="rh-table">
        <thead><tr><th>运算单号</th><th>策略</th><th>方向</th><th>计划数</th><th>工序数</th><th>交期风险</th><th>超载中心</th><th>状态</th><th>时间</th></tr></thead>
        <tbody>
          <tr v-for="r in runs" :key="r.id" :class="{ active: r.id === selectedRun }" @click="selectedRun = r.id">
            <td>{{ r.runNo }}</td>
            <td>{{ r.strategy === 'FINITE' ? '有限产能' : '无限产能' }}</td>
            <td>{{ r.direction === 'BACKWARD' ? '倒排' : '正排' }}</td>
            <td>{{ r.planCount }}</td><td>{{ r.taskCount }}</td><td>{{ r.lateCount }}</td><td>{{ r.overloadCount }}</td>
            <td><DsTag size="sm" :color="r.status === 'DONE' ? 'success' : r.status === 'FAILED' ? 'danger' : 'warning'">{{ r.status === 'DONE' ? '完成' : r.status === 'FAILED' ? '失败' : '运算中' }}</DsTag></td>
            <td>{{ r.createdAt }}</td>
          </tr>
          <tr v-if="!runs.length"><td colspan="9" class="rh-empty">暂无运算记录</td></tr>
        </tbody>
      </table>
    </DsCard>

    <DsCard title="工序任务明细" :pad="false" class="rh-detail">
      <template #extra><span class="rh-count">{{ filteredTasks.length }} 道工序</span></template>
      <table class="rh-table">
        <thead><tr><th>任务单号</th><th>生产计划</th><th>工序</th><th>工作中心</th><th>工时</th><th>计划开始</th><th>计划结束</th><th>前序</th><th>状态</th><th>交期</th></tr></thead>
        <tbody>
          <tr v-for="t in filteredTasks" :key="t.id">
            <td>{{ t.taskNo }}</td><td>{{ t.planNo }}</td><td>{{ t.seqNo }} {{ t.processName }}</td><td>{{ t.workCenter }}</td>
            <td>{{ t.workHours }}h</td><td>{{ t.planStart }}</td><td>{{ t.planEnd }}</td><td>{{ t.predecessor || '-' }}</td>
            <td><DsTag size="sm" :color="t.status === 'DONE' ? 'success' : t.status === 'RUNNING' ? 'warning' : 'brand'">{{ statusText(t.status) }}</DsTag></td>
            <td>{{ t.lateFlag ? '延期' : '正常' }}</td>
          </tr>
          <tr v-if="!filteredTasks.length"><td colspan="10" class="rh-empty">暂无工序任务</td></tr>
        </tbody>
      </table>
    </DsCard>
  </div>
</template>

<script setup lang="ts">
/** 排产记录：运算批次与工序任务只读追溯，数据在 APS 工作台执行运算时生成 */
import { computed, onMounted, ref } from 'vue';
import { DsCard, DsTag } from '../../components';
import { apsApi } from '../../api';

const runs = ref<any[]>([]);
const tasks = ref<any[]>([]);
const selectedRun = ref<number | string>('');

function asList(x: any): any[] { return Array.isArray(x) ? x : x?.list || []; }
const filteredTasks = computed(() => selectedRun.value
  ? tasks.value.filter((t) => Number(t.runId) === Number(selectedRun.value))
  : tasks.value);
function statusText(s: string): string { return ({ PENDING: '待排产', SCHEDULED: '已排产', RUNNING: '生产中', DONE: '已完工' } as any)[s] || s; }

onMounted(async () => {
  const [r, t] = await Promise.all([apsApi.runs(), apsApi.tasks({ pageSize: 500 })]);
  runs.value = asList(r);
  tasks.value = asList(t);
  if (runs.value.length) selectedRun.value = runs.value[0].id;
});
</script>

<style scoped>
.rh-page { padding: 16px; }
.rh-head h2 { font-size: 18px; margin: 0 0 4px; }
.rh-head p { font-size: 12px; color: var(--ds-text-3); margin: 0 0 14px; }
.rh-detail { margin-top: 14px; }
.rh-count { font-size: 12px; color: var(--ds-text-3); }
.rh-table { width: 100%; border-collapse: collapse; font-size: 12px; }
.rh-table th, .rh-table td { padding: 8px 10px; text-align: left; border-bottom: 1px solid var(--ds-divider); white-space: nowrap; }
.rh-table th { background: var(--ds-bg-soft); color: var(--ds-text-2); }
.rh-table tbody tr { cursor: pointer; }
.rh-table tbody tr.active { background: var(--ds-brand-soft, var(--ds-bg-soft)); }
.rh-empty { text-align: center; color: var(--ds-text-3); padding: 20px; }
</style>
