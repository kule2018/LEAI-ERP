<template>
  <div class="erp-page aps-page">
    <div class="aps-head">
      <h2>排产工作台</h2>
      <DsButton size="sm" :loading="loading" @click="load">刷新</DsButton>
    </div>
    <p v-if="error" class="aps-load-error" role="alert">{{ error }}</p>
    <p v-else-if="loading" role="status">正在加载…</p>
    <template v-else>
      <DsCard title="工序排产甘特" :pad="false">
        <template #extra>
          <div class="aps-tools">
            <DsButton size="sm" :disabled="offset === 0" @click="offset -= 14">前 14 天</DsButton>
            <DsButton size="sm" @click="offset += 14">后 14 天</DsButton>
            <DsButton size="sm" @click="openSchedule()">重新排产</DsButton>
          </div>
        </template>
        <div class="aps-gantt-scroll">
          <table class="aps-gantt">
            <thead>
              <tr>
                <th class="aps-gantt-name">工作中心 / 工序任务</th>
                <th v-for="d in days" :key="d.date" class="aps-gantt-day" :class="{ weekend: d.weekend }">
                  <small>{{ d.weekday }}</small><b>{{ d.day }}</b>
                </th>
              </tr>
            </thead>
            <tbody>
              <tr v-if="!tasks.length"><td :colspan="days.length + 1" class="aps-empty">暂无工序排产</td></tr>
              <template v-for="center in centers" :key="center">
                <tr class="aps-group"><td :colspan="days.length + 1">{{ center }}（{{ tasksByCenter(center).length }} 道工序）</td></tr>
                <tr v-for="t in tasksByCenter(center)" :key="t.id">
                  <td class="aps-gantt-name">
                    <b>{{ t.processName }}</b>
                    <small>{{ t.planNo }} · {{ t.productName }} · {{ t.workHours }}h</small>
                  </td>
                  <template v-for="(c, idx) in taskCells(t)" :key="idx">
                    <td v-if="c.type === 'empty'" :class="{ weekend: c.weekend }"></td>
                    <td v-else :colspan="c.span" class="aps-gantt-td">
                      <button class="aps-bar" :class="barClass(t)" :title="barTitle(t)" @click="openTask(t)">
                        {{ t.processName }} {{ t.lateFlag ? '⚠' : '' }}
                      </button>
                    </td>
                  </template>
                </tr>
                <tr v-if="!tasksByCenter(center).length"><td :colspan="days.length + 1" class="aps-empty">该工作中心暂无排产任务</td></tr>
              </template>
            </tbody>
          </table>
        </div>
      </DsCard>
    </template>
    <DsModal v-model="scheduleVisible" title="排产运算" :width="480">
      <div class="aps-form">
        <label><span>排产策略</span><select v-model="scheduleCfg.strategy" class="ds-input">
          <option value="FINITE">有限产能（占用工作日历空档）</option>
          <option value="INFINITE">无限产能（忽略产能占用）</option>
        </select></label>
        <label><span>排产方向</span><select v-model="scheduleCfg.direction" class="ds-input">
          <option value="FORWARD">正排（从计划开工日向前推）</option>
          <option value="BACKWARD">倒排（从需求日期向前推）</option>
        </select></label>
        <label><span>计划范围</span><select v-model="scheduleCfg.planId" class="ds-input">
          <option value="">全部已确认计划</option>
          <option v-for="p in plans.filter((x) => x.status === 'CONFIRMED')" :key="p.id" :value="p.id">{{ p.planNo }} {{ p.planName }}</option>
        </select></label>
        <div class="aps-note">运算将按优先级与交期排序展开工序，自动生成工序任务、刷新产能负荷并识别交期风险。</div>
      </div>
      <template #footer><div class="aps-foot">
        <DsButton @click="scheduleVisible = false">取消</DsButton>
        <DsButton variant="primary" @click="perform(doSchedule)" :loading="acting">开始运算</DsButton>
      </div></template>
    </DsModal>
    <DsModal v-model="taskVisible" title="调整工序排产" :width="520">
      <div v-if="currentTask" class="aps-form">
        <label><span>工序</span><input class="ds-input" :value="currentTask.processName" disabled /></label>
        <label><span>工作中心</span><select v-model="taskForm.workCenter" class="ds-input">
          <option v-for="c in centers" :key="c" :value="c">{{ c }}</option>
        </select></label>
        <label><span>计划开始</span><input v-model="taskForm.planStart" class="ds-input" type="datetime-local" /></label>
        <label><span>计划结束</span><input v-model="taskForm.planEnd" class="ds-input" type="datetime-local" /></label>
        <label><span>优先级</span><select v-model="taskForm.priority" class="ds-input">
          <option value="P1">P1 紧急</option><option value="P2">P2 较高</option><option value="P3">P3 普通</option>
        </select></label>
        <div class="aps-note">工序工时 {{ currentTask.workHours }} 小时，前序任务 {{ currentTask.predecessor || '无' }}。</div>
      </div>
      <template #footer><div class="aps-foot">
        <DsButton v-if="currentTask && currentTask.status !== 'DONE'" @click="perform(completeTask)" :disabled="acting">完工</DsButton>
        <DsButton @click="taskVisible = false">取消</DsButton>
        <DsButton variant="primary" @click="perform(saveTask)" :loading="acting">保存调整</DsButton>
      </div></template>
    </DsModal>
  </div>
</template>

<script setup lang="ts">
import { onMounted, ref, reactive, computed } from 'vue';
import { DsButton, DsCard, DsModal, DsTag } from '../../components';
import { apsApi } from '../../api';
import { useToast } from '../../components/ds/toast';
import { pageRows as asList } from '../../api/pageData';
import { useRoute } from 'vue-router';
const toast = useToast();
const error = ref('');
const loading = ref(false);
const acting = ref(false);
const route = useRoute();
const plans = ref<any[]>([]);
const tasks = ref<any[]>([]);
const offset = ref(0);
const centers = ref<string[]>([]);
const scheduleVisible = ref(false);
const taskVisible = ref(false);
const currentTask = ref<any>(null);
const scheduleCfg = reactive<any>({ strategy: 'FINITE', direction: 'FORWARD', planId: '' });
const taskForm = reactive<any>({ workCenter: '', planStart: '', planEnd: '', priority: 'P3' });

async function load() {
  if (loading.value) return;
  loading.value = true;
  error.value = '';
  try {
    const [planData, taskData, resourceData] = await Promise.all([
      apsApi.plans({ pageSize: 200 }),
      apsApi.tasks({ pageSize: 200 }),
      apsApi.resources(),
    ]);
    plans.value = asList(planData);
    tasks.value = asList(taskData);
    centers.value = [...new Set([...asList(resourceData), ...tasks.value]
      .map((row) => String(row.workCenter || row.work_center || row.name || '')).filter(Boolean))];
  } catch (cause) {
    error.value = cause instanceof Error ? cause.message : '加载失败，请重试';
  } finally {
    loading.value = false;
  }
}

async function perform(action: () => Promise<void>) {
  if (acting.value) return;
  acting.value = true;
  try {
    await action();
  } catch (cause) {
    toast.error(cause instanceof Error ? cause.message : '操作失败');
  } finally {
    acting.value = false;
  }
}

const days = computed(() => {
  const earliest = tasks.value.map((t) => String(t.planStart || '').slice(0, 10)).filter(Boolean).sort()[0] || new Date().toISOString().slice(0, 10);
  const base = new Date(`${earliest}T00:00:00`);
  base.setDate(base.getDate() + offset.value);
  return Array.from({ length: 14 }, (_, i) => {
    const d = new Date(base);
    d.setDate(d.getDate() + i);
    const iso = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
    return { date: iso, day: d.getDate(), weekday: ['周日', '周一', '周二', '周三', '周四', '周五', '周六'][d.getDay()], weekend: [0, 6].includes(d.getDay()) };
  });
});

function barClass(t: any): string { return t.lateFlag ? 'late' : t.status === 'DONE' ? 'done' : t.status === 'RUNNING' ? 'running' : 'normal'; }

function barTitle(t: any): string { return `${t.planNo} ${t.processName} ${t.planStart} ~ ${t.planEnd}（${t.workHours}h）`; }

function tasksByCenter(center: string): any[] { return tasks.value.filter((t) => t.workCenter === center); }

function taskCells(t: any) {
  const start = String(t.planStart || '').slice(0, 10);
  const end = String(t.planEnd || '').slice(0, 10);
  const cells: Array<{ type: 'empty' | 'bar'; span: number; weekend: boolean }> = [];
  for (const day of days.value) {
    if (day.date >= start && day.date <= end) {
      const previous = cells[cells.length - 1];
      if (previous?.type === 'bar') previous.span++;
      else cells.push({ type: 'bar', span: 1, weekend: day.weekend });
    } else cells.push({ type: 'empty', span: 1, weekend: day.weekend });
  }
  return cells;
}

function openSchedule(p?: any): void {
  scheduleCfg.planId = p?.id || Number(route.query.planId) || '';
  scheduleVisible.value = true;
}

async function doSchedule(): Promise<void> {
  try {
    const res: any = await apsApi.runSchedule({
      strategy: scheduleCfg.strategy, direction: scheduleCfg.direction,
      planIds: scheduleCfg.planId ? [Number(scheduleCfg.planId)] : [],
    });
    scheduleVisible.value = false;
    toast.success(`排产完成：${res.taskCount} 道工序，交期风险 ${res.lateCount} 项，超载中心 ${res.overloadCount} 个`);
    await load();
  } catch (e: any) { toast.error(e?.message || '排产失败'); }
}

function openTask(t: any): void {
  currentTask.value = t;
  taskForm.workCenter = t.workCenter;
  taskForm.planStart = String(t.planStart || '').replace(' ', 'T');
  taskForm.planEnd = String(t.planEnd || '').replace(' ', 'T');
  taskForm.priority = t.priority;
  taskVisible.value = true;
}

async function saveTask(): Promise<void> {
  if (!currentTask.value) return;
  if (!taskForm.planStart || !taskForm.planEnd || taskForm.planEnd <= taskForm.planStart) throw new Error('结束时间必须晚于开始时间');
  await apsApi.patchTask(currentTask.value.id, {
    workCenter: taskForm.workCenter, planStart: String(taskForm.planStart).replace('T', ' '),
    planEnd: String(taskForm.planEnd).replace('T', ' '), priority: taskForm.priority,
  });
  taskVisible.value = false;
  toast.success('工序排产已调整，负荷与交期风险同步刷新');
  await load();
}

async function completeTask(): Promise<void> {
  if (!currentTask.value) return;
  await apsApi.completeTask(currentTask.value.id);
  taskVisible.value = false;
  toast.success('工序已完工，后续工序已推进');
  await load();
}

onMounted(load);
</script>

<style src="./apsPage.css" scoped></style>
