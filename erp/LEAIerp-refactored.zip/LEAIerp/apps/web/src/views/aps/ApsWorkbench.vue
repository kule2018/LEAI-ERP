<!--
  生产计划与排产工作台
  ---------------------------------------------------------------------------
  功能：在同一页面完成计划维护 → 确认 → 排产运算 → 工序调整 → 工单下达 →
        齐套检查 → 产能负荷分析 → 异常预警处理的完整闭环。
  路由：aps/plans、aps/schedule、aps/loads、aps/materials、aps/alerts
        共用本组件，依据当前路径选择默认标签页。
-->
<template>
  <div class="erp-page aps-page">
    <div class="aps-head">
      <div>
        <h2>生产计划与排产</h2>
        <p>覆盖需求计划、有限/无限产能排程、工序甘特、齐套检查与交期预警</p>
      </div>
      <DsButton size="sm" @click="load">刷新数据</DsButton>
    </div>

    <div class="aps-cards">
      <div v-for="c in cards" :key="c.label" class="aps-card">
        <span>{{ c.label }}</span><b :class="{ danger: c.danger }">{{ c.value }}</b>
      </div>
    </div>

    <div class="aps-tabs">
      <button v-for="(t, i) in tabs" :key="t.key" :class="{ active: tab === i }" @click="tab = i">{{ t.label }}</button>
    </div>

    <!-- 生产计划 -->
    <div v-show="tab === 0">
      <DsCard title="生产计划清单" :pad="false">
        <template #extra>
          <div class="aps-tools">
            <DsButton size="sm" variant="primary" @click="openPlan">新增计划</DsButton>
            <DsButton size="sm" @click="scheduleVisible = true">排产运算</DsButton>
            <DsButton size="sm" @click="doMaterialCheck()">齐套检查</DsButton>
          </div>
        </template>
        <table class="aps-table">
          <thead><tr><th>计划单号</th><th>计划名称</th><th>产品</th><th>数量</th><th>优先级</th><th>需求日期</th><th>工作中心</th><th>状态</th><th>操作</th></tr></thead>
          <tbody>
            <tr v-for="p in plans" :key="p.id">
              <td>{{ p.planNo }}</td><td>{{ p.planName }}</td><td>{{ p.productName }}</td>
              <td>{{ p.qty }}</td>
              <td><DsTag size="sm" :color="p.priority === 'P1' ? 'danger' : p.priority === 'P2' ? 'warning' : 'neutral'">{{ p.priority }}</DsTag></td>
              <td>{{ p.dueDate }}</td><td>{{ p.workCenter }}</td>
              <td><DsTag size="sm" :color="planColor(p.status)">{{ planText(p.status) }}</DsTag></td>
              <td class="aps-ops">
                <DsButton v-if="p.status === 'DRAFT'" size="sm" variant="primary" @click="planAction(p, 'confirm')">确认</DsButton>
                <DsButton v-if="p.status === 'CONFIRMED'" size="sm" variant="primary" @click="openSchedule(p)">排产</DsButton>
                <DsButton v-if="p.status === 'SCHEDULED'" size="sm" variant="primary" @click="planAction(p, 'issue')">下达工单</DsButton>
                <DsButton v-if="p.status === 'ISSUED'" size="sm" @click="planAction(p, 'complete')">完工</DsButton>
                <DsButton v-if="!['COMPLETED', 'CANCELLED'].includes(p.status)" size="sm" variant="text" @click="planAction(p, 'cancel')">作废</DsButton>
              </td>
            </tr>
            <tr v-if="!plans.length"><td colspan="9" class="aps-empty">暂无生产计划，点击「新增计划」开始</td></tr>
          </tbody>
        </table>
      </DsCard>
    </div>

    <!-- 排产工作台：按工作中心分组的工序甘特 -->
    <div v-show="tab === 1">
      <DsCard title="工序排产甘特" :pad="false">
        <template #extra>
          <div class="aps-tools">
            <span class="aps-hint">点击任务条可手动调整时间/工作中心</span>
            <DsButton size="sm" @click="scheduleVisible = true">重新排产</DsButton>
          </div>
        </template>
        <div class="aps-gantt-scroll">
          <table class="aps-gantt">
            <thead>
              <tr>
                <th class="aps-gantt-name">工作中心 / 工序任务</th>
                <th v-for="d in days" :key="d.date" class="aps-gantt-day" :class="{ weekend: d.weekend }">
                  <small>{{ d.weekday }}</small><b>{{ d.day }}</b>
                </th>
              </tr>
            </thead>
            <tbody>
              <template v-for="center in centers" :key="center">
                <tr class="aps-group"><td :colspan="days.length + 1">{{ center }}（{{ tasksByCenter(center).length }} 道工序）</td></tr>
                <tr v-for="t in tasksByCenter(center)" :key="t.id">
                  <td class="aps-gantt-name">
                    <b>{{ t.processName }}</b>
                    <small>{{ t.planNo }} · {{ t.productName }} · {{ t.workHours }}h</small>
                  </td>
                  <template v-for="(c, idx) in taskCells(t)" :key="idx">
                    <td v-if="c.type === 'empty'" :class="{ weekend: days[idx].weekend }"></td>
                    <td v-else :colspan="c.span" class="aps-gantt-td">
                      <button class="aps-bar" :class="barClass(t)" :title="barTitle(t)" @click="openTask(t)">
                        {{ t.processName }} {{ t.lateFlag ? '⚠' : '' }}
                      </button>
                    </td>
                  </template>
                </tr>
                <tr v-if="!tasksByCenter(center).length"><td :colspan="days.length + 1" class="aps-empty">该工作中心暂无排产任务</td></tr>
              </template>
            </tbody>
          </table>
        </div>
      </DsCard>
    </div>

    <!-- 产能负荷 -->
    <div v-show="tab === 2">
      <DsCard title="产能负荷分析" :pad="false">
        <template #extra><DsButton size="sm" @click="rebuild">重算负荷</DsButton></template>
        <table class="aps-table">
          <thead><tr><th>日期</th><th>工作中心</th><th>可用工时</th><th>计划工时</th><th>负荷率</th><th>任务数</th><th>等级</th><th>瓶颈</th></tr></thead>
          <tbody>
            <tr v-for="l in loads" :key="l.id" :class="{ 'aps-over': l.level === 'OVER' }">
              <td>{{ l.loadDate }}</td><td>{{ l.workCenter }}</td><td>{{ l.availableHours }}h</td>
              <td>{{ l.plannedHours }}h</td><td>{{ l.loadRate }}%</td><td>{{ l.taskCount }}</td>
              <td><DsTag size="sm" :color="loadColor(l.level)">{{ loadText(l.level) }}</DsTag></td>
              <td>{{ l.bottleneck ? '是' : '否' }}</td>
            </tr>
            <tr v-if="!loads.length"><td colspan="8" class="aps-empty">暂无负荷数据，请先执行排产运算</td></tr>
          </tbody>
        </table>
      </DsCard>
    </div>

    <!-- 齐套检查 -->
    <div v-show="tab === 3">
      <DsCard title="物料齐套检查" :pad="false">
        <template #extra>
          <div class="aps-tools">
            <select v-model="checkPlanNo" class="ds-input aps-select">
              <option value="">全部计划</option>
              <option v-for="p in plans" :key="p.id" :value="p.planNo">{{ p.planNo }} {{ p.planName }}</option>
            </select>
            <DsButton size="sm" variant="primary" @click="doMaterialCheck()">执行检查</DsButton>
          </div>
        </template>
        <table class="aps-table">
          <thead><tr><th>检查单号</th><th>生产计划</th><th>物料</th><th>需求</th><th>可用</th><th>缺口</th><th>状态</th><th>检查时间</th></tr></thead>
          <tbody>
            <tr v-for="x in materials" :key="x.id">
              <td>{{ x.checkNo }}</td><td>{{ x.planNo }}</td><td>{{ x.materialName }}</td>
              <td>{{ x.requireQty }}</td><td>{{ x.availableQty }}</td>
              <td :class="{ 'aps-danger-text': x.shortQty > 0 }">{{ x.shortQty }}</td>
              <td><DsTag size="sm" :color="x.status === 'SHORT' ? 'danger' : 'success'">{{ x.status === 'SHORT' ? '缺料' : '齐套' }}</DsTag></td>
              <td>{{ x.checkedAt }}</td>
            </tr>
            <tr v-if="!materials.length"><td colspan="8" class="aps-empty">暂无检查记录，点击「执行检查」核对物料齐套情况</td></tr>
          </tbody>
        </table>
      </DsCard>
    </div>

    <!-- 异常预警 -->
    <div v-show="tab === 4">
      <DsCard title="排产异常预警" :pad="false">
        <table class="aps-table">
          <thead><tr><th>类型</th><th>级别</th><th>标题</th><th>详细说明</th><th>关联单号</th><th>状态</th><th>操作</th></tr></thead>
          <tbody>
            <tr v-for="a in alerts" :key="a.id">
              <td>{{ alertTypeText(a.alertType) }}</td>
              <td><DsTag size="sm" :color="a.level === 'HIGH' ? 'danger' : a.level === 'MED' ? 'warning' : 'neutral'">{{ a.level }}</DsTag></td>
              <td>{{ a.title }}</td><td class="aps-detail">{{ a.detail }}</td><td>{{ a.bizNo }}</td>
              <td><DsTag size="sm" :color="a.status === 'OPEN' ? 'warning' : 'success'">{{ a.status === 'OPEN' ? '待处理' : '已处理' }}</DsTag></td>
              <td><DsButton v-if="a.status === 'OPEN'" size="sm" @click="resolve(a)">标记处理</DsButton></td>
            </tr>
            <tr v-if="!alerts.length"><td colspan="7" class="aps-empty">暂无异常预警</td></tr>
          </tbody>
        </table>
      </DsCard>
    </div>

    <!-- 新增生产计划 -->
    <DsModal v-model="planVisible" title="新增生产计划" :width="560">
      <div class="aps-form">
        <label><span>计划名称 *</span><input v-model="form.planName" class="ds-input" placeholder="如：智能温控器 12 月补单" /></label>
        <label><span>生产产品 *</span><select v-model="form.productName" class="ds-input">
          <option v-for="p in productNames" :key="p" :value="p">{{ p }}</option>
        </select></label>
        <label><span>计划数量 *</span><input v-model.number="form.qty" class="ds-input" type="number" min="1" /></label>
        <label><span>需求日期 *</span><input v-model="form.dueDate" class="ds-input" type="date" /></label>
        <label><span>优先级</span><select v-model="form.priority" class="ds-input">
          <option value="P1">P1 紧急</option><option value="P2">P2 较高</option><option value="P3">P3 普通</option>
        </select></label>
        <label><span>主工作中心</span><select v-model="form.workCenter" class="ds-input">
          <option v-for="c in centers" :key="c" :value="c">{{ c }}</option>
        </select></label>
        <label><span>需求来源</span><select v-model="form.sourceType" class="ds-input">
          <option value="SALES">销售订单</option><option value="FORECAST">销售预测</option><option value="MANUAL">手工录入</option>
        </select></label>
        <label><span>来源单号</span><input v-model="form.sourceNo" class="ds-input" placeholder="选填" /></label>
        <label class="full"><span>备注</span><input v-model="form.remark" class="ds-input" placeholder="选填" /></label>
      </div>
      <template #footer><div class="aps-foot">
        <DsButton @click="planVisible = false">取消</DsButton>
        <DsButton variant="primary" @click="savePlan">创建计划</DsButton>
      </div></template>
    </DsModal>

    <!-- 排产参数 -->
    <DsModal v-model="scheduleVisible" title="排产运算" :width="480">
      <div class="aps-form">
        <label><span>排产策略</span><select v-model="scheduleCfg.strategy" class="ds-input">
          <option value="FINITE">有限产能（占用工作日历空档）</option>
          <option value="INFINITE">无限产能（忽略产能占用）</option>
        </select></label>
        <label><span>排产方向</span><select v-model="scheduleCfg.direction" class="ds-input">
          <option value="FORWARD">正排（从计划开工日向前推）</option>
          <option value="BACKWARD">倒排（从需求日期向前推）</option>
        </select></label>
        <label><span>计划范围</span><select v-model="scheduleCfg.planId" class="ds-input">
          <option value="">全部已确认计划</option>
          <option v-for="p in plans.filter((x) => x.status === 'CONFIRMED')" :key="p.id" :value="p.id">{{ p.planNo }} {{ p.planName }}</option>
        </select></label>
        <div class="aps-note">运算将按优先级与交期排序展开工序，自动生成工序任务、刷新产能负荷并识别交期风险。</div>
      </div>
      <template #footer><div class="aps-foot">
        <DsButton @click="scheduleVisible = false">取消</DsButton>
        <DsButton variant="primary" @click="doSchedule">开始运算</DsButton>
      </div></template>
    </DsModal>

    <!-- 工序任务手动调整 -->
    <DsModal v-model="taskVisible" title="调整工序排产" :width="520">
      <div v-if="currentTask" class="aps-form">
        <label><span>工序</span><input class="ds-input" :value="currentTask.processName" disabled /></label>
        <label><span>工作中心</span><select v-model="taskForm.workCenter" class="ds-input">
          <option v-for="c in centers" :key="c" :value="c">{{ c }}</option>
        </select></label>
        <label><span>计划开始</span><input v-model="taskForm.planStart" class="ds-input" type="datetime-local" /></label>
        <label><span>计划结束</span><input v-model="taskForm.planEnd" class="ds-input" type="datetime-local" /></label>
        <label><span>优先级</span><select v-model="taskForm.priority" class="ds-input">
          <option value="P1">P1 紧急</option><option value="P2">P2 较高</option><option value="P3">P3 普通</option>
        </select></label>
        <div class="aps-note">工序工时 {{ currentTask.workHours }} 小时，前序任务 {{ currentTask.predecessor || '无' }}。</div>
      </div>
      <template #footer><div class="aps-foot">
        <DsButton v-if="currentTask && currentTask.status !== 'DONE'" @click="completeTask">完工</DsButton>
        <DsButton @click="taskVisible = false">取消</DsButton>
        <DsButton variant="primary" @click="saveTask">保存调整</DsButton>
      </div></template>
    </DsModal>
  </div>
</template>

<script setup lang="ts">
/** APS 工作台：页面数据与交互全部走 apsApi（Mock 模式下由本地排产引擎处理） */
import { computed, onMounted, reactive, ref } from 'vue';
import { useRoute } from 'vue-router';
import { DsButton, DsCard, DsModal, DsTag } from '../../components';
import { apsApi } from '../../api';
import { useToast } from '../../components/ds/toast';

const toast = useToast();
const route = useRoute();
const tabs = [
  { key: 'plans', label: '生产计划' }, { key: 'schedule', label: '排产工作台' },
  { key: 'loads', label: '产能负荷' }, { key: 'materials', label: '齐套检查' }, { key: 'alerts', label: '异常预警' },
];
const tab = ref(0);
const overview = ref<any>({});
const plans = ref<any[]>([]);
const tasks = ref<any[]>([]);
const loads = ref<any[]>([]);
const materials = ref<any[]>([]);
const alerts = ref<any[]>([]);
const centers = ['数控加工中心', '焊接工作站', '总装线'];
const productNames = ['智能温控器', '无线网关', '工控主板'];
const checkPlanNo = ref('');

const planVisible = ref(false);
const scheduleVisible = ref(false);
const taskVisible = ref(false);
const currentTask = ref<any>(null);
const form = reactive<any>({ planName: '', productName: '智能温控器', qty: 100, dueDate: '', priority: 'P2', workCenter: '总装线', sourceType: 'MANUAL', sourceNo: '', remark: '' });
const scheduleCfg = reactive<any>({ strategy: 'FINITE', direction: 'FORWARD', planId: '' });
const taskForm = reactive<any>({ workCenter: '', planStart: '', planEnd: '', priority: 'P3' });

/** 统一拆包：接口可能返回数组或 { list } 分页结构 */
function asList(x: any): any[] { return Array.isArray(x) ? x : x?.list || []; }

/** 统计卡：把排产引擎返回的汇总指标展示在页面顶部 */
const cards = computed(() => [
  { label: '生产计划', value: overview.value.plans ?? 0, danger: false },
  { label: '待确认', value: overview.value.confirmed ?? 0, danger: false },
  { label: '已排产', value: overview.value.scheduled ?? 0, danger: false },
  { label: '待执行工序', value: overview.value.pendingTasks ?? 0, danger: false },
  { label: '交期风险', value: overview.value.lateTasks ?? 0, danger: true },
  { label: '超载/预警', value: `${overview.value.overloads ?? 0}/${overview.value.openAlerts ?? 0}`, danger: true },
]);

/** 日期轴：以最早工序日期为准展示 14 天，周末高亮 */
const days = computed(() => {
  const earliest = tasks.value.map((t) => String(t.planStart || '').slice(0, 10)).filter(Boolean).sort()[0] || new Date().toISOString().slice(0, 10);
  const base = new Date(`${earliest}T00:00:00`);
  return Array.from({ length: 14 }, (_, i) => {
    const d = new Date(base.getTime() + i * 86400000);
    const iso = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
    return { date: iso, day: d.getDate(), weekday: ['周日', '周一', '周二', '周三', '周四', '周五', '周六'][d.getDay()], weekend: [0, 6].includes(d.getDay()) };
  });
});

/** 状态文案与颜色 */
function planText(s: string): string {
  return ({ DRAFT: '草稿', CONFIRMED: '已确认', SCHEDULED: '已排产', ISSUED: '已下达', COMPLETED: '已完成', CANCELLED: '已作废' } as any)[s] || s;
}
function planColor(s: string): any { return s === 'COMPLETED' ? 'success' : s === 'CANCELLED' ? 'neutral' : s === 'DRAFT' ? 'warning' : 'brand'; }
function loadText(s: string): string { return ({ IDLE: '空闲', NORMAL: '正常', WARN: '偏高', OVER: '超载' } as any)[s] || s; }
function loadColor(s: string): any { return s === 'OVER' ? 'danger' : s === 'WARN' ? 'warning' : s === 'IDLE' ? 'neutral' : 'success'; }
function alertTypeText(s: string): string { return ({ CAPACITY: '产能超载', DUE: '交期风险', MATERIAL: '物料短缺' } as any)[s] || s; }
function barClass(t: any): string { return t.lateFlag ? 'late' : t.status === 'DONE' ? 'done' : t.status === 'RUNNING' ? 'running' : 'normal'; }
function barTitle(t: any): string { return `${t.planNo} ${t.processName} ${t.planStart} ~ ${t.planEnd}（${t.workHours}h）`; }

/** 按工作中心筛选工序任务 */
function tasksByCenter(center: string): any[] { return tasks.value.filter((t) => t.workCenter === center); }

/**
 * 生成甘特行的格子序列：任务时间窗所在日期合并为一个跨列任务条。
 * 超出当前日期轴的任务不显示，避免表格列数错位。
 */
function taskCells(t: any): any[] {
  const start = String(t.planStart || '').slice(0, 10);
  const end = String(t.planEnd || '').slice(0, 10);
  const from = days.value.findIndex((d) => d.date === start);
  const to = days.value.findIndex((d) => d.date === end);
  const cells = days.value.map(() => ({ type: 'empty', span: 1 }));
  if (from < 0) return cells;
  const last = to < from ? from : to;
  cells[from] = { type: 'bar', span: Math.max(1, last - from + 1) };
  return cells;
}

/** 加载工作台全部数据 */
async function load(): Promise<void> {
  const [ov, p, t, l, m, a] = await Promise.all([
    apsApi.overview(), apsApi.plans({ pageSize: 200 }), apsApi.tasks({ pageSize: 300 }),
    apsApi.loads({ pageSize: 300 }), apsApi.materials(), apsApi.alerts(),
  ]);
  overview.value = ov || {};
  plans.value = asList(p);
  tasks.value = asList(t);
  loads.value = asList(l);
  materials.value = asList(m);
  alerts.value = asList(a);
}

/** 打开新增计划弹窗，默认需求日期为今天 +7 天 */
function openPlan(): void {
  const d = new Date(Date.now() + 7 * 86400000);
  form.planName = '';
  form.qty = 100;
  form.dueDate = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  form.sourceNo = '';
  form.remark = '';
  planVisible.value = true;
}

/** 创建生产计划：单号由前端按日期生成，状态默认为草稿 */
async function savePlan(): Promise<void> {
  if (!form.planName || !form.qty || !form.dueDate) { toast.warning('请填写计划名称、数量与需求日期'); return; }
  const d = new Date();
  const prefix = `PP${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, '0')}${String(d.getDate()).padStart(2, '0')}`;
  const no = `${prefix}-${String(plans.value.filter((p) => String(p.planNo).startsWith(prefix)).length + 1).padStart(4, '0')}`;
  await apsApi.savePlan({ ...form, planNo: no, status: 'DRAFT', planStart: form.dueDate, createdAt: new Date().toISOString().slice(0, 19).replace('T', ' ') });
  planVisible.value = false;
  toast.success('生产计划已创建，请确认后排产');
  await load();
}

/** 执行计划状态动作（确认/下达/完工/作废） */
async function planAction(p: any, action: string): Promise<void> {
  try {
    await apsApi.planAction(p.id, action as any);
    toast.success(`${p.planNo} 已${action === 'confirm' ? '确认' : action === 'issue' ? '下达工单' : action === 'complete' ? '完工' : '作废'}`);
    await load();
  } catch (e: any) { toast.error(e?.message || '操作失败'); }
}

/** 对指定计划直接排产 */
function openSchedule(p?: any): void {
  scheduleCfg.planId = p ? p.id : '';
  scheduleVisible.value = true;
}

/** 执行排产运算并显示关键结果 */
async function doSchedule(): Promise<void> {
  try {
    const res: any = await apsApi.runSchedule({
      strategy: scheduleCfg.strategy, direction: scheduleCfg.direction,
      planIds: scheduleCfg.planId ? [Number(scheduleCfg.planId)] : [],
    });
    scheduleVisible.value = false;
    toast.success(`排产完成：${res.taskCount} 道工序，交期风险 ${res.lateCount} 项，超载中心 ${res.overloadCount} 个`);
    await load();
  } catch (e: any) { toast.error(e?.message || '排产失败'); }
}

/** 执行齐套检查 */
async function doMaterialCheck(): Promise<void> {
  try {
    const p = plans.value.find((x) => x.planNo === checkPlanNo.value);
    const res: any = await apsApi.materialCheck(p?.id);
    const list: any = await apsApi.materials();
    materials.value = asList(list);
    toast.success(`齐套检查完成：缺料 ${res.shortCount} 项`);
    await load();
  } catch (e: any) { toast.error(e?.message || '检查失败'); }
}

/** 重算产能负荷 */
async function rebuild(): Promise<void> {
  await apsApi.rebuildLoads();
  const list: any = await apsApi.loads({ pageSize: 300 });
  loads.value = asList(list);
  toast.success('负荷已按当前工序任务重算');
}

/** 打开工序调整弹窗：datetime-local 输入需要把空格替换为 T */
function openTask(t: any): void {
  currentTask.value = t;
  taskForm.workCenter = t.workCenter;
  taskForm.planStart = String(t.planStart || '').replace(' ', 'T');
  taskForm.planEnd = String(t.planEnd || '').replace(' ', 'T');
  taskForm.priority = t.priority;
  taskVisible.value = true;
}

/** 保存手动调整：时间格式还原为空格分隔 */
async function saveTask(): Promise<void> {
  if (!currentTask.value) return;
  await apsApi.patchTask(currentTask.value.id, {
    workCenter: taskForm.workCenter, planStart: String(taskForm.planStart).replace('T', ' '),
    planEnd: String(taskForm.planEnd).replace('T', ' '), priority: taskForm.priority,
  });
  taskVisible.value = false;
  toast.success('工序排产已调整，负荷与交期风险同步刷新');
  await load();
}

/** 工序完工并自动推进后续工序 */
async function completeTask(): Promise<void> {
  if (!currentTask.value) return;
  await apsApi.completeTask(currentTask.value.id);
  taskVisible.value = false;
  toast.success('工序已完工，后续工序已推进');
  await load();
}

/** 处理预警 */
async function resolve(a: any): Promise<void> {
  await apsApi.resolveAlert(a.id);
  toast.success('预警已标记为处理完成');
  await load();
}

onMounted(async () => {
  const key = String(route.path).split('/').filter(Boolean)[1] || 'plans';
  const idx = tabs.findIndex((t) => t.key === key);
  tab.value = idx >= 0 ? idx : 0;
  await load();
});
</script>

<style scoped>
.aps-page { padding: 16px; }
.aps-head { display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px; }
.aps-head h2 { margin: 0 0 4px; font-size: 18px; }
.aps-head p { margin: 0; font-size: 12px; color: var(--ds-text-3); }
.aps-cards { display: grid; grid-template-columns: repeat(6, 1fr); gap: 10px; margin-bottom: 12px; }
.aps-card { background: var(--ds-bg-card); border: 1px solid var(--ds-divider); border-radius: 10px; padding: 12px 14px; }
.aps-card span { display: block; font-size: 12px; color: var(--ds-text-3); }
.aps-card b { display: block; font-size: 22px; margin-top: 6px; }
.aps-card b.danger { color: var(--ds-danger); }
.aps-tabs { display: flex; gap: 4px; margin-bottom: 12px; border-bottom: 1px solid var(--ds-divider); }
.aps-tabs button { border: 0; background: transparent; padding: 9px 16px; cursor: pointer; font-size: 13px; color: var(--ds-text-2); border-bottom: 2px solid transparent; }
.aps-tabs button.active { color: var(--ds-brand); border-bottom-color: var(--ds-brand); font-weight: 600; }
.aps-tools { display: flex; align-items: center; gap: 8px; }
.aps-hint { font-size: 12px; color: var(--ds-text-3); }
.aps-table { width: 100%; border-collapse: collapse; font-size: 12px; }
.aps-table th, .aps-table td { padding: 9px 10px; text-align: left; border-bottom: 1px solid var(--ds-divider); white-space: nowrap; }
.aps-table th { background: var(--ds-bg-soft); color: var(--ds-text-2); font-weight: 600; }
.aps-table tbody tr:hover { background: var(--ds-bg-soft); }
.aps-ops { display: flex; gap: 4px; }
.aps-empty { text-align: center; color: var(--ds-text-3); padding: 24px; }
.aps-over { background: var(--ds-danger-soft); }
.aps-danger-text { color: var(--ds-danger); font-weight: 600; }
.aps-detail { white-space: normal; max-width: 380px; color: var(--ds-text-2); }
.aps-gantt-scroll { overflow-x: auto; padding: 12px; }
.aps-gantt { border-collapse: collapse; width: 100%; min-width: 1180px; font-size: 12px; }
.aps-gantt th, .aps-gantt td { border: 1px solid var(--ds-divider); height: 42px; padding: 3px; text-align: center; }
.aps-gantt-name { min-width: 220px; text-align: left !important; padding: 6px 10px !important; }
.aps-gantt-name b { display: block; }
.aps-gantt-name small { color: var(--ds-text-3); }
.aps-gantt-day { min-width: 62px; background: var(--ds-bg-soft); }
.aps-gantt-day small { display: block; color: var(--ds-text-3); }
.aps-gantt td.weekend, .aps-gantt th.weekend { background: var(--ds-bg-soft); }
.aps-group td { text-align: left; background: var(--ds-bg-soft); font-weight: 600; padding-left: 10px !important; height: 30px !important; }
.aps-bar { border: 0; border-radius: 5px; color: #fff; padding: 5px 9px; font-size: 11px; width: 100%; cursor: pointer; background: var(--ds-brand); }
.aps-bar.late { background: var(--ds-danger); }
.aps-bar.running { background: var(--ds-warning); }
.aps-bar.done { background: var(--ds-success); }
.aps-form { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; padding: 4px 0; }
.aps-form label { display: flex; flex-direction: column; gap: 5px; font-size: 12px; }
.aps-form label.full { grid-column: 1 / -1; }
.aps-form label span { color: var(--ds-text-2); }
.aps-select { max-width: 220px; }
.aps-note { grid-column: 1 / -1; font-size: 12px; color: var(--ds-text-3); background: var(--ds-bg-soft); border-radius: 6px; padding: 8px 10px; }
.aps-foot { display: flex; justify-content: flex-end; gap: 8px; }
</style>
