<template><RecordPage :config="page" /></template>

<script setup lang="ts">
import RecordPage from '../records/RecordPage.vue';
import type { RecordPageConfig } from '../records/records';

const page: RecordPageConfig = {
  title: '抄送设置',
  resource: 'collab/approval-cc',
  schema: 'collabApprovalCc',
  filters: ['bizType', 'receiver', 'status'],
  required: ['bizType', 'receiver'],
};
</script>
