<template><RecordPage :config="page" /></template>

<script setup lang="ts">
import RecordPage from '../records/RecordPage.vue';
import type { RecordPageConfig } from '../records/records';

const page: RecordPageConfig = {
  title: '审批模板',
  resource: 'collab/approval-templates',
  schema: 'collabApprovalTemplates',
  filters: ['bizType', 'status'],
  required: ['name', 'bizType', 'nodes'],
};
</script>
