<template><SalesEntityPage :key="key" :config="config" /></template>
<script setup lang="ts">
import { computed } from 'vue';
import { useRoute } from 'vue-router';
import SalesEntityPage from '../sales/SalesEntityPage.vue';
import { collabConfigFor } from './collabConfigs';

const route = useRoute();
const key = computed(() => route.path.split('/').filter(Boolean)[1] || 'approval');
const config = computed(() => collabConfigFor(key.value));
</script>
