
<template><div class="ag-page">
<div class="ag-head"><div><div class="ag-kicker">AGENDA · 会议日程</div><h2>会议</h2></div><div class="ag-actions"><DsButton size="sm" @click="load">刷新</DsButton><DsButton size="sm" @click="exportCsv">导出</DsButton><DsButton variant="primary" size="sm" @click="openForm()">＋ 新建会议</DsButton></div></div>
<div class="ag-stats"><div v-for="s in statVals" :key="s.label" class="ag-stat"><span>{{s.label}}</span><b>{{s.value}}</b></div></div>
<div class="ag-search"><input v-model="q.keyword" class="ds-input" placeholder="搜索主题 / 编号…" @keyup.enter="reload"/><select v-model="q.status" class="ds-input"><option value="">全部状态</option><option v-for="(l,v) in statusLabels" :key="v" :value="v">{{l}}</option></select><DsButton variant="primary" size="sm" @click="reload">查询</DsButton><DsButton size="sm" @click="resetQuery">重置</DsButton></div>
<div class="ag-rooms"><span class="ag-rooms-label"><IconFont name="Home" :size="13"/> 会议室</span><button class="ag-chip" :class="{active:!roomFilter}" @click="roomFilter=''">全部</button><button v-for="room in roomChips" :key="room" class="ag-chip" :class="{active:roomFilter===room}" @click="roomFilter=room">{{room}}</button></div>
<div class="ag-body">
<div class="ag-timeline">
<div v-for="g in grouped" :key="g.date" class="ag-day"><div class="ag-day-hd"><span class="ag-day-dot"></span><b>{{g.date}}</b><small>{{g.items.length}} 场会议</small></div>
<div class="ag-day-body"><div v-for="r in g.items" :key="r.id" class="ag-meet">
<div class="ag-time">{{timeOf(r)}}</div><div class="ag-rail"><span class="ag-node" :style="{background:colorFor(r),boxShadow:'0 0 0 4px '+colorFor(r)+'20'}"></span></div>
<div class="ag-card">
<div class="ag-card-top"><div class="ag-title"><b>{{r.name||'未命名会议'}}</b><span class="ag-code">{{r.code}}</span></div><span class="ag-badge" :style="badgeStyle(r)">{{statusText(r.status)}}</span></div>
<div class="ag-meta"><span><IconFont name="Home" :size="13"/> {{r.bizText||'未设会议室'}}</span><span><IconFont name="Users" :size="13"/> 主持 {{r.partner||'—'}}</span><span><IconFont name="Calendar" :size="13"/> {{r.qty||0}} 人参会</span></div>
<div class="ag-card-foot"><div class="ag-ops"><DsButton v-for="a in actionsOf(r)" :key="a.key" variant="text" size="sm" :style="{color:colorOf(a)}" @click="runAction(r,a)">{{a.label}}</DsButton></div><div class="ag-ops"><DsButton variant="text" size="sm" @click="openForm(r)">编辑</DsButton><DsButton variant="text" size="sm" style="color:var(--ds-danger)" @click="removeRow(r)">删除</DsButton></div></div>
</div>
</div></div></div>
<div v-if="!grouped.length" class="ag-empty"><IconFont name="Calendar" :size="28"/><p>暂无会议安排</p></div>
</div>
</div>
<div class="ag-pager"><DsPagination v-model:current-page="page" :page-size="pageSize" :total="total" layout="total, prev, pager, next" @change="load"/></div>
<DsModal v-model="formVisible" :title="(editing?'编辑':'新建')+'会议'" :width="640"><div class="ag-form"><label v-for="f in formFields" :key="f.prop" class="ag-field"><span>{{f.label}}<i v-if="f.required">*</i></span><select v-if="f.type==='select'" v-model="form[f.prop]" class="ds-input"><option :value="''">请选择</option><option v-for="o in optionsOf(f)" :key="String(o.value)" :value="o.value">{{o.label}}</option></select><textarea v-else-if="f.type==='textarea'" v-model="form[f.prop]" class="ds-input" rows="3"></textarea><input v-else :type="f.type==='number'?'number':f.type==='date'?'date':'text'" v-model="form[f.prop]" class="ds-input"/></label></div><template #footer><div class="ag-foot"><DsButton @click="formVisible=false">取消</DsButton><DsButton variant="primary" :loading="saving" @click="save">保存</DsButton></div></template></DsModal>
</div></template>

<script setup lang="ts">
import IconFont from '../../components/IconFont.vue';
import { ref, reactive, computed, onMounted } from 'vue';
import { mockGet, mockPost, mockPatch, mockDel } from '../../api/mockAdapter';
import { useToast } from '../../components/ds/toast';
import { confirm as uiConfirm } from '../../components/ds/useConfirm';
const toast=useToast();
const API="/api/v1/collab/meetings";
const COLLECTION="collabMeetings";
const columns:any[]=[{"prop":"code","label":"会议编号","type":"text","options":null,"source":""},{"prop":"name","label":"会议主题","type":"text","options":null,"source":""},{"prop":"partner","label":"主持人","type":"text","options":null,"source":""},{"prop":"bizText","label":"会议室","type":"text","options":null,"source":""},{"prop":"bizDate","label":"会议时间","type":"date","options":null,"source":""},{"prop":"qty","label":"参会人数","type":"number","options":null,"source":""},{"prop":"docDate","label":"创建日期","type":"date","options":null,"source":""},{"prop":"status","label":"状态","type":"select","options":[{"label":"待处理","value":0},{"label":"进行中","value":1},{"label":"已完成","value":2},{"label":"已归档","value":3},{"label":"已驳回","value":4},{"label":"已作废","value":9}],"source":""}];
const formFields:any[]=[{"prop":"code","label":"会议编号","type":"text","options":null,"source":"","required":true,"placeholder":""},{"prop":"name","label":"会议主题","type":"text","options":null,"source":"","required":true,"placeholder":""},{"prop":"partner","label":"主持人","type":"text","options":null,"source":"","required":false,"placeholder":""},{"prop":"bizText","label":"会议室","type":"text","options":null,"source":"","required":false,"placeholder":""},{"prop":"bizDate","label":"会议时间","type":"date","options":null,"source":"","required":false,"placeholder":""},{"prop":"qty","label":"参会人数","type":"number","options":null,"source":"","required":false,"placeholder":""},{"prop":"docDate","label":"创建日期","type":"date","options":null,"source":"","required":false,"placeholder":""},{"prop":"remark","label":"备注","type":"textarea","options":null,"source":"","required":false,"placeholder":""},{"prop":"status","label":"状态","type":"select","options":[{"label":"待处理","value":0},{"label":"进行中","value":1},{"label":"已完成","value":2},{"label":"已归档","value":3},{"label":"已驳回","value":4},{"label":"已作废","value":9}],"source":"","required":false,"placeholder":""}];
const statusLabels:Record<string,string>={"0":"待处理","1":"进行中","2":"已完成","3":"已归档","4":"已驳回","9":"已作废"};
const actions:any[]=[{"key":"submit","label":"发送邀请","variant":"primary","from":[0]},{"key":"start","label":"开始会议","variant":"primary","from":[1]},{"key":"finish","label":"结束并纪要","variant":"primary","from":[2]}];
const DEFAULTS:any={"status":0,"qty":0,"amount":0,"bizAmount":0};
const STATS:any[]=[{"label":"记录总数","expr":"rows.length","unit":""},{"label":"参会人数合计","expr":"sum('qty')","unit":""},{"label":"待处理","expr":"rows.filter(r=>Number(r.status)<=1).length","unit":""}];
const hasStatus=Object.keys(statusLabels).length>0;
const isReport=false;
const q=reactive<{keyword:string;status:any}>({keyword:'',status:''});
const rows=ref<any[]>([]);const total=ref(0);const page=ref(1);const pageSize=ref(12);
const loading=ref(false);const saving=ref(false);const formVisible=ref(false);const editing=ref<any>(null);
const form=reactive<Record<string,any>>({});
const remoteOptions=reactive<Record<string,any[]>>({});
const roomFilter=ref('');
const roomChips=computed(()=>{const set=new Set<string>();rows.value.forEach(r=>{if(r.bizText)set.add(String(r.bizText));});return Array.from(set);});
const filteredRows=computed(()=>roomFilter.value?rows.value.filter(r=>String(r.bizText)===roomFilter.value):rows.value);
const grouped=computed(()=>{const map=new Map<string,any[]>();filteredRows.value.forEach(r=>{const d=String(r.bizDate||r.docDate||'未排期').slice(0,10);if(!map.has(d))map.set(d,[]);map.get(d)!.push(r);});return Array.from(map.entries()).map(([date,items])=>({date,items}));});
function timeOf(r:any){const s=String(r.bizDate||'');if(s.length>10)return s.slice(11,16);const id=Number(r.id)||0;const h=8+id%10;const m=(id*7)%6*10;return String(h).padStart(2,'0')+':'+String(m).padStart(2,'0');}
function colorFor(r:any){const s=Number(r.status);return s===0?'#f59e0b':s===1?'#3b82f6':s===2?'#10b981':s===3?'#6366f1':'#94a3b8';}
function badgeStyle(r:any){const c=colorFor(r);return {color:c,background:c+'18',border:'1px solid '+c+'40'};}
const statVals=computed(()=>STATS.map(s=>({label:s.label,unit:s.unit,value:evalStat(s.expr)})));
function sum(prop:string){return rows.value.reduce((a,r)=>a+(Number(r[prop])||0),0);}
function evalStat(expr:string){try{return new Function('rows','page','sum','rows_',expr)(rows.value,page.value,sum,rows.value);}catch{return 0;}}
function statusText(v:any){return statusLabels[String(v)]||String(v??'');}
function display(row:any,col:any){const v=row[col.prop];if(col.prop==='status'&&hasStatus)return statusText(v);if(col.options){const h=col.options.find((o:any)=>String(o.value)===String(v));if(h)return h.label;}const src=(remoteOptions as any)[col.source];if(src){const h=src.find((o:any)=>String(o.value)===String(v));if(h)return h.label;}if(v==null||v==='')return '—';const s=String(v);return /^\d{4}-\d{2}-\d{2}/.test(s)?s.slice(0,10):s;}
function optionsOf(f:any){return f.options||(remoteOptions as any)[f.source]||[];}
async function loadRemote(){const srcs:Record<string,string>={customers:'/api/v1/crm/customers',products:'/api/v1/inventory/products',orders:'/api/v1/sales/orders',groups:'/api/v1/crm/customer-groups',suppliers:'/api/v1/purchase/suppliers',warehouses:'/api/v1/inventory/warehouses'};const used=formFields.filter(f=>f.source).map(f=>f.source);await Promise.all(used.map(async s=>{if(remoteOptions[s])return;try{const d:any=await mockGet(srcs[s]||API,{pageSize:200});const list=Array.isArray(d)?d:d?.list||[];remoteOptions[s]=list.map((x:any)=>({label:x.name||x.code||x.title||('#'+x.id),value:x.id}));}catch{remoteOptions[s]=[];}}));}
async function load(){loading.value=true;try{const d:any=await mockGet(API,{page:page.value,pageSize:pageSize.value,keyword:q.keyword,status:q.status});rows.value=Array.isArray(d)?d:d?.list||[];total.value=Number(d?.total??rows.value.length);}catch(e:any){toast.error(e?.message||'加载失败');rows.value=[];}finally{loading.value=false;}}
function reload(){page.value=1;load();}
function resetQuery(){q.keyword='';q.status='';roomFilter.value='';reload();}
function resetForm(){for(const k of Object.keys(form))delete form[k];for(const f of formFields)form[f.prop]=DEFAULTS[f.prop]??(f.type==='number'?0:'');}
function openForm(row?:any){editing.value=row||null;resetForm();if(row)for(const f of formFields)if(row[f.prop]!==undefined)form[f.prop]=row[f.prop];formVisible.value=true;}
async function save(){for(const f of formFields){if(f.required&&(form[f.prop]===''||form[f.prop]==null)){toast.warning('请填写「'+f.label+'」');return;}}saving.value=true;try{const payload:any={};for(const f of formFields)payload[f.prop]=form[f.prop];if(editing.value?.id)await mockPatch(API+'/'+editing.value.id,payload);else await mockPost(API,payload);toast.success(editing.value?'已保存':'已创建');formVisible.value=false;await load();}catch(e:any){toast.error(e?.message||'保存失败');}finally{saving.value=false;}}
function actionsOf(row:any){return actions.filter(a=>!a.from||a.from.some(s=>Number(s)===Number(row.status)));}
function colorOf(a:any){return a.variant==='danger'?'var(--ds-danger)':a.variant==='warning'?'var(--ds-warning)':'var(--ds-brand)';}
async function runAction(row:any,a:any){if(!await uiConfirm('确定执行「'+a.label+'」吗？','业务确认'))return;try{const res:any=await mockPost('/_biz/action/'+COLLECTION+'/'+row.id+'/'+a.key,{label:a.label});toast.success(res?.message||(a.label+'成功'));await load();}catch(e:any){toast.error(e?.message||'操作失败');}}
async function removeRow(row:any){if(!await uiConfirm('确定删除 #'+row.id+' 吗？','删除确认'))return;try{await mockDel(API+'/'+row.id);toast.success('已删除');await load();}catch(e:any){toast.error(e?.message||'删除失败');}}
function exportCsv(){const head=columns.map(c=>c.label);const lines=[head.join(',')].concat(rows.value.map(r=>columns.map(c=>String(display(r,c)).replace(/,/g,' ')).join(',')));const blob=new Blob(['\ufeff'+lines.join('\n')],{type:'text/csv;charset=utf-8'});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='会议.csv';a.click();}
onMounted(()=>{load();if(!isReport)loadRemote();});
</script>

<style scoped>
.ag-page{padding:16px}.ag-head{display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:14px}.ag-kicker{font-size:11px;letter-spacing:1px;color:#6366f1;font-weight:700;margin-bottom:4px}.ag-head h2{margin:0;font-size:20px}.ag-actions{display:flex;gap:8px}.ag-stats{display:flex;gap:12px;margin-bottom:14px}.ag-stat{flex:1;background:var(--ds-bg-soft);border-left:3px solid #6366f1;border-radius:8px;padding:10px 14px;display:flex;flex-direction:column;gap:4px}.ag-stat span{font-size:12px;color:var(--ds-text-3)}.ag-stat b{font-size:20px}.ag-search{display:flex;gap:8px;margin-bottom:12px;flex-wrap:wrap}.ag-search input{min-width:200px}.ag-pager{display:flex;justify-content:flex-end;padding:12px}.ag-form{display:grid;grid-template-columns:1fr 1fr;gap:14px}.ag-field{display:flex;flex-direction:column;gap:5px;font-size:13px}.ag-field i{color:var(--ds-danger);font-style:normal}.ag-foot{display:flex;justify-content:flex-end;gap:8px}
.ag-rooms{display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-bottom:14px;padding:10px 12px;background:var(--ds-bg-soft);border-radius:8px}.ag-rooms-label{display:flex;align-items:center;gap:5px;font-size:12px;color:var(--ds-text-3);margin-right:4px}.ag-chip{font-size:12px;padding:4px 12px;border-radius:14px;border:1px solid var(--ds-divider);background:var(--ds-card);color:var(--ds-text-2);cursor:pointer;transition:.15s}.ag-chip:hover{border-color:#6366f1;color:#6366f1}.ag-chip.active{background:#6366f1;color:#fff;border-color:#6366f1}
.ag-body{background:var(--ds-card);border:1px solid var(--ds-divider);border-radius:10px;padding:6px 16px 16px}.ag-timeline{display:flex;flex-direction:column}.ag-day{padding-top:14px}.ag-day-hd{display:flex;align-items:center;gap:8px;padding:8px 0 12px;font-size:13px}.ag-day-hd b{color:var(--ds-text-1)}.ag-day-hd small{color:var(--ds-text-3);font-size:11px}.ag-day-dot{width:8px;height:8px;border-radius:50%;background:#6366f1;box-shadow:0 0 0 4px #6366f120}.ag-day-body{display:flex;flex-direction:column}.ag-meet{display:grid;grid-template-columns:52px 24px 1fr;gap:6px;min-height:96px}.ag-time{font-size:12px;color:var(--ds-text-3);padding-top:16px;font-variant-numeric:tabular-nums}.ag-rail{position:relative;display:flex;justify-content:center;padding-top:18px}.ag-rail:before{content:"";position:absolute;top:0;bottom:0;left:50%;width:1px;background:var(--ds-divider);transform:translateX(-50%)}.ag-node{position:relative;width:10px;height:10px;border-radius:50%;z-index:1}
.ag-card{background:var(--ds-bg-soft);border:1px solid var(--ds-divider);border-radius:8px;padding:12px 14px;margin:6px 0}.ag-card-top{display:flex;justify-content:space-between;align-items:flex-start;gap:10px}.ag-title b{font-size:14px}.ag-code{display:block;color:var(--ds-text-3);font-size:11px;margin-top:2px}.ag-badge{font-size:11px;padding:3px 10px;border-radius:12px;white-space:nowrap}.ag-meta{display:flex;gap:16px;flex-wrap:wrap;margin:10px 0;font-size:12px;color:var(--ds-text-2)}.ag-meta span{display:flex;align-items:center;gap:4px}.ag-card-foot{display:flex;justify-content:space-between;align-items:center;border-top:1px dashed var(--ds-divider);padding-top:8px;gap:8px}.ag-ops{display:flex;gap:4px;flex-wrap:wrap}
.ag-empty{display:flex;flex-direction:column;align-items:center;justify-content:center;color:var(--ds-text-3);padding:48px}.ag-empty p{margin:8px 0 0;font-size:13px}
</style>
