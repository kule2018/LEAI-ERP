<template><RecordPage :config="page" /></template>

<script setup lang="ts">
import RecordPage from '../records/RecordPage.vue';
import type { RecordPageConfig } from '../records/records';

const page: RecordPageConfig = {
  title: '项目仪表盘',
  resource: 'collab/project-dashboards',
  schema: 'collabProjectDashboards',
  filters: ['projectName', 'manager', 'status'],
  reportSource: '查询项目进度和完成任务数',
  metrics: ['taskTotal', 'taskDone'],
};
</script>
