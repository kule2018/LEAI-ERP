<template><RecordPage :config="page" /></template>

<script setup lang="ts">
import RecordPage from '../records/RecordPage.vue';
import type { RecordPageConfig } from '../records/records';

const page: RecordPageConfig = {
  title: '时间表',
  resource: 'collab/timesheets',
  schema: 'collabTimesheets',
  filters: ['employee', 'projectName', 'workDate'],
  required: ['employee', 'projectName', 'workDate', 'hours'],
  metrics: ['hours'],
};
</script>
