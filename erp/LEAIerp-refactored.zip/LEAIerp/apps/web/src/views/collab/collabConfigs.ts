/** 协同办公 12 个页面的独立字段、表单、状态与业务动作配置。 */
import type { SalesAction, SalesConfig, SalesField } from '../sales/salesConfigs';

const FLOW = { '0': '待处理', '1': '进行中', '2': '已完成', '3': '已归档', '4': '已驳回', '9': '已作废' };
const MASTER = { '0': '草稿', '1': '启用' };

const approvalActions: SalesAction[] = [
  { key: 'submit', label: '提交审批', variant: 'primary', from: [0] },
  { key: 'approve', label: '审批通过', variant: 'primary', from: [1] },
  { key: 'reject', label: '驳回', variant: 'danger', from: [1] },
  { key: 'archive', label: '归档', variant: 'default', from: [2] },
];
const publishActions: SalesAction[] = [
  { key: 'submit', label: '提交审核', variant: 'primary', from: [0] },
  { key: 'publish', label: '发布', variant: 'primary', from: [1] },
  { key: 'archive', label: '下线归档', variant: 'warning', from: [2] },
];
const meetingActions: SalesAction[] = [
  { key: 'submit', label: '发送邀请', variant: 'primary', from: [0] },
  { key: 'start', label: '开始会议', variant: 'primary', from: [1] },
  { key: 'finish', label: '结束并纪要', variant: 'primary', from: [2] },
];
const taskActions: SalesAction[] = [
  { key: 'submit', label: '派发任务', variant: 'primary', from: [0] },
  { key: 'start', label: '开始处理', variant: 'primary', from: [1] },
  { key: 'finish', label: '完成任务', variant: 'primary', from: [2] },
  { key: 'reject', label: '退回', variant: 'danger', from: [1] },
];
const masterActions: SalesAction[] = [
  { key: 'toggle', label: '停用', variant: 'warning', from: [1] },
  { key: 'enable', label: '启用', variant: 'primary', from: [0] },
  { key: 'copy', label: '复制' },
];

const f = (prop: string, label: string, type?: SalesField['type'], required?: boolean): SalesField => ({ prop, label, type, required });
const sel = (prop: string, label: string, values: string[]): SalesField => ({
  prop, label, type: 'select', options: values.map((v) => ({ label: v, value: v })),
});

type Kind = 'flow' | 'master' | 'report';
interface Def {
  key: string; title: string; collection: string; layout: NonNullable<SalesConfig['layout']>;
  kind: Kind; codeLabel: string; nameLabel: string; extra: SalesField[];
  actions?: SalesAction[]; labels?: Record<string, string>;
}

const DEFS: Def[] = [
  { key: 'approval', title: '申请与审批', collection: 'collabApproval', layout: 'approval', kind: 'flow', codeLabel: '申请单号', nameLabel: '申请标题', extra: [f('partner', '申请人'), f('bizText', '审批类型'), f('bizSelect', '审批人'), f('amount', '申请金额', 'number'), f('docDate', '申请日期', 'date'), f('bizDate', '期望完成日', 'date')], actions: approvalActions },
  { key: 'chat', title: '企业聊天', collection: 'collabChat', layout: 'chat', kind: 'master', codeLabel: '会话编号', nameLabel: '会话主题', extra: [f('partner', '发起人'), f('bizText', '参与人'), f('qty', '消息数', 'number'), f('docDate', '最近活跃', 'date')], actions: masterActions },
  { key: 'notices', title: '公告', collection: 'collabNotices', layout: 'approval', kind: 'flow', codeLabel: '公告编号', nameLabel: '公告标题', extra: [f('partner', '发布部门'), sel('bizText', '公告级别', ['全员通知', '部门通知', '紧急通知']), f('docDate', '发布日期', 'date')], actions: publishActions },
  { key: 'meetings', title: '会议', collection: 'collabMeetings', layout: 'calendar', kind: 'flow', codeLabel: '会议编号', nameLabel: '会议主题', extra: [f('partner', '主持人'), f('bizText', '会议室'), f('bizDate', '会议时间', 'date'), f('qty', '参会人数', 'number'), f('docDate', '创建日期', 'date')], actions: meetingActions },
  { key: 'flow-defs', title: '审批流程设计器', collection: 'collabFlowDefs', layout: 'workflow', kind: 'master', codeLabel: '流程编码', nameLabel: '流程名称', extra: [f('partner', '所属部门'), f('bizText', '节点说明'), f('qty', '节点数量', 'number'), f('bizSelect', '流程类型')], actions: masterActions },
  { key: 'projects', title: '项目', collection: 'collabProjects', layout: 'gantt', kind: 'flow', codeLabel: '项目编码', nameLabel: '项目名称', extra: [f('partner', '项目经理'), f('amount', '项目预算', 'number'), f('bizDate', '计划完成日', 'date'), sel('bizText', '项目类型', ['实施类', '设计类', '研发类']), f('docDate', '立项日期', 'date')], actions: approvalActions },
  { key: 'tasks', title: '任务', collection: 'collabTasks', layout: 'kanban', kind: 'flow', codeLabel: '任务编号', nameLabel: '任务名称', extra: [f('partner', '负责人'), sel('bizText', '优先级', ['高', '中', '低']), f('bizDate', '截止日期', 'date'), f('docDate', '派发日期', 'date')], actions: taskActions },
  { key: 'board', title: '任务板', collection: 'collabBoard', layout: 'kanban', kind: 'flow', codeLabel: '看板编号', nameLabel: '看板名称', extra: [f('partner', '看板负责人'), f('qty', '任务数量', 'number'), f('bizText', '当前阶段'), f('bizDate', '迭代截止日', 'date')], actions: taskActions },
  { key: 'milestones', title: '里程碑', collection: 'collabMilestones', layout: 'calendar', kind: 'flow', codeLabel: '里程碑编号', nameLabel: '里程碑名称', extra: [f('partner', '所属项目'), f('bizDate', '计划日期', 'date'), f('bizText', '交付物'), f('docDate', '登记日期', 'date')], actions: meetingActions },
  { key: 'project-reports', title: '项目报告', collection: 'collabProjectReports', layout: 'analytics', kind: 'report', codeLabel: '报告编号', nameLabel: '报告标题', extra: [f('partner', '所属项目'), f('bizText', '进度说明'), f('bizAmount', '完成率', 'number'), f('amount', '已用预算', 'number'), f('docDate', '报告日期', 'date')] },
  { key: 'files', title: '文件档案', collection: 'collabFiles', layout: 'files', kind: 'master', codeLabel: '档案编号', nameLabel: '文件名称', extra: [f('partner', '上传人'), f('qty', '文件大小(MB)', 'number'), sel('bizText', '文件类型', ['方案文档', '数据报表', '合同附件', '会议纪要']), f('docDate', '更新日期', 'date')], actions: masterActions },
  { key: 'knowledge', title: '知识库', collection: 'collabKnowledge', layout: 'workflow', kind: 'flow', codeLabel: '条目编号', nameLabel: '知识标题', extra: [f('partner', '维护人'), sel('bizText', '知识分类', ['制度规范', '操作手册', '人事制度', '项目经验']), f('docDate', '更新日期', 'date')], actions: publishActions },
];

function build(d: Def): SalesConfig {
  const base: SalesField[] = [f('code', d.codeLabel, undefined, true), f('name', d.nameLabel, undefined, true)];
  const labels = d.labels || (d.kind === 'flow' ? FLOW : MASTER);
  const status: SalesField = {
    prop: 'status', label: '状态', type: 'select',
    options: Object.entries(labels).map(([k, v]) => ({ label: v, value: Number(k) })),
  };
  const isReport = d.kind === 'report';
  return {
    title: d.title,
    api: `/api/v1/collab/${d.key}`,
    collection: d.collection,
    columns: [...base, ...d.extra, ...(isReport ? [] : [status])],
    fields: [...base, ...d.extra, f('remark', '备注', 'textarea'), ...(isReport ? [] : [status])],
    statusField: 'status',
    statusLabels: labels,
    actions: isReport ? [] : (d.actions || masterActions),
    readOnly: isReport,
    layout: d.layout,
    defaults: () => ({ status: d.kind === 'flow' ? 0 : 1, qty: 0, amount: 0, bizAmount: 0 }),
  };
}

export const COLLAB_CONFIGS: Record<string, SalesConfig> = Object.fromEntries(DEFS.map((d) => [d.key, build(d)]));
export function collabConfigFor(key: string): SalesConfig {
  const c = COLLAB_CONFIGS[key];
  if (!c) throw new Error(`未知协同页面配置：${key}`);
  return c;
}
