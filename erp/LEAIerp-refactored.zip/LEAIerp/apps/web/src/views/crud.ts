import { useToast } from '../components/ds/toast';
import { confirm as uiConfirm } from '../components/ds/useConfirm';

const toast = useToast();

/** 单据状态：0草稿 1待审 2已确认 3部分 4完成 9作废 */
export const DOC_STATUS: Record<number, string> = { 0: '草稿', 1: '待审', 2: '已确认', 3: '部分', 4: '完成', 9: '作废' };
export const PAY_STATUS: Record<number, string> = { 0: '未付', 1: '部分', 2: '已付' };
export const SHIP_STATUS: Record<number, string> = { 0: '未发货', 1: '部分', 2: '已完成' };

export const statusTag = (v: number) => ({ 0: 'info', 1: 'warning', 2: 'primary', 3: 'primary', 4: 'success', 9: 'danger' })[v] || 'info';
export const payTag = (v: number) => ({ 0: 'danger', 1: 'warning', 2: 'success' })[v] || 'info';
export const shipTag = (v: number) => ({ 0: 'info', 1: 'warning', 2: 'success' })[v] || 'info';

/**
 * 列表页通用的加载 + 动作执行器：统一“统计卡片 + 筛选 + 表格 + 分页”三态
 */
export function useListPage<T = any>(loader: (q: any) => Promise<any>) {
  return {
    loading: false as boolean,
    list: [] as T[],
    summary: null as any,
    page: 1,
    pageSize: 10,
    total: 0,
    async load(this: any, extra?: any) {
      this.loading = true;
      try {
        const data: any = await loader({ page: this.page, pageSize: this.pageSize, ...(extra || {}) });
        if (data && Array.isArray(data.list)) { this.list = data.list; this.total = Number(data.total || 0); this.summary = data.summary || null; }
        else { this.list = Array.isArray(data) ? data : []; this.total = this.list.length; }
      } catch { this.list = []; } finally { this.loading = false; }
    },
  };
}

/** 执行单据动作（提交/确认/发货/作废），成功后提示并刷新 */
export async function runAction(fn: () => Promise<any>, msg = '操作成功', after?: () => void) {
  try {
    await fn();
    toast.success(msg);
    after?.();
  } catch { /* 已提示 */ }
}

/** 作废前二次确认 */
export async function confirmVoid(fn: () => Promise<any>, after: () => void) {
  if (!await uiConfirm('作废后不可恢复，确定继续？', '作废确认')) return;
  try { await fn(); toast.success('已作废'); after(); } catch { /* 已提示 */ }
}
