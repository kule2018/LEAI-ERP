<!--
 * 个人工作台（每天第一屏）
 * ---------------------------------------------------------------------------
 * 内容：KPI 聚合卡片（点击下钻）、待办中心、常用功能（按点击频次排序）、
 *       最近访问、经营趋势（ECharts）、AI 每日简报、经营日历提醒。
 * 全部接口失败时自动展示本地演示数据，保证页面永不空白。
 -->
<template>
  <div class="dash-page">
    <div class="dash-head">
      <div><h2>早上好，{{ userStore.realName }}</h2><p>今天是 {{ today }}，以下是你最需要关注的事项。</p></div>
      <DsButton variant="primary" size="sm" @click="refresh">刷新数据</DsButton>
    </div>

    <!-- KPI 卡片：点击下钻到对应明细页 -->
    <div class="dash-cards">
      <div v-for="card in cards" :key="card.label" class="dash-card" @click="router.push(card.path)">
        <span class="dash-card__label">{{ card.label }}</span>
        <b class="dash-card__value">{{ card.value }}</b>
        <small :class="card.trend > 0 ? 'up' : card.trend < 0 ? 'down' : ''">{{ card.hint }}</small>
      </div>
    </div>

    <div class="dash-grid">
      <!-- 待办中心 -->
      <DsCard title="我的待办" subtitle="审批 / 发货 / 逾期应收" :pad="false">
        <template #extra><DsButton variant="text" size="sm" @click="router.push('/collab/approval')">全部待办 →</DsButton></template>
        <div v-for="t in todos" :key="t.id" class="dash-todo" @click="handleTodo(t)">
          <span class="dash-todo__icon"><IconFont :name="t.bizType === 'SALE_ORDER' ? 'Inbox' : t.bizType === 'PURCHASE_ORDER' ? 'ExternalLink' : 'Edit'" :size="18" /></span>
          <div><b>{{ t.bizNo || t.title }}</b><small>{{ t.nodeName || t.type }} · 金额 {{ t.amount || '-' }}</small></div>
          <DsButton size="sm" variant="primary" @click.stop="handleTodo(t)">处理</DsButton>
        </div>
        <div v-if="!todos.length" class="dash-empty">待办已清空，状态良好 ✓</div>
      </DsCard>

      <!-- 经营趋势 -->
      <DsCard title="近 7 日经营趋势" subtitle="销售额 / 采购额">
        <div ref="chartRef" class="dash-chart" />
      </DsCard>

      <!-- 常用功能：点击次数本地自学习排序 -->
      <DsCard title="常用功能" :pad="false">
        <div class="dash-quick">
          <div v-for="q in quicks" :key="q.path" class="dash-quick__item" @click="openQuick(q)">
            <span><IconFont :name="q.icon" :size="18" /></span><b>{{ q.title }}</b>
          </div>
        </div>
      </DsCard>

      <!-- AI 每日简报 -->
      <DsCard title="AI 每日简报" subtitle="规则引擎兜底，无需密钥">
        <template #extra><DsButton size="sm" :loading="aiLoading" @click="runBrief">生成简报</DsButton></template>
        <pre class="dash-ai">{{ brief || '点击「生成简报」，AI 将基于库存、应收、待办生成今日经营提示（无密钥时走本地规则引擎）。' }}</pre>
      </DsCard>

      <!-- 最近访问 -->
      <DsCard title="最近访问" :pad="false">
        <div v-for="t in recentTabs" :key="t.path" class="dash-recent" @click="router.push('/' + t.path)">📄 {{ t.title }} <span>→</span></div>
        <div v-if="!recentTabs.length" class="dash-empty">暂无访问记录</div>
      </DsCard>

      <!-- 经营日历提醒 -->
      <DsCard title="经营日历" :pad="false">
        <div class="dash-calendar">
          <div class="dash-cal-item"><b>每月 1 日</b><span>上月销售/采购对账</span></div>
          <div class="dash-cal-item"><b>每月 25 日</b><span>应收账龄跟进、催收</span></div>
          <div class="dash-cal-item"><b>每月末</b><span>库存盘点、财务月结</span></div>
          <div class="dash-cal-item"><b>季度末</b><span>固定资产盘点、税务申报</span></div>
        </div>
      </DsCard>
    </div>
  </div>
</template>

<script setup lang="ts">
/** 工作台：聚合待办、KPI、趋势、常用功能、AI 简报与日历提醒 */
import { onMounted, ref } from 'vue';
import { useRouter } from 'vue-router';
import * as echarts from 'echarts';
import { MENUS } from '../../config/erp';
import { salesApi, purchaseApi, inventoryApi, financeApi, aiApi } from '../../api';
import { bpmApi, biApi } from '../../api/ext';
import { useUserStore } from '../../store';
import { useToast } from '../../components/ds/toast';

const router = useRouter();
const userStore = useUserStore();
const toast = useToast();
const today = new Date().toLocaleDateString('zh-CN', { year: 'numeric', month: 'long', day: 'numeric', weekday: 'long' });

/** KPI 卡片：value/hint 由接口结果填充，path 支持下钻 */
const cards = ref([
  { label: '今日销售额', value: '0.00', hint: '点击查看销售单', trend: 0, path: '/sales/orders' },
  { label: '今日采购额', value: '0.00', hint: '点击查看采购单', trend: 0, path: '/purchase/orders' },
  { label: '应收未收', value: '0.00', hint: '点击查看应收账单', trend: 0, path: '/finance/receivables' },
  { label: '库存预警', value: '0', hint: '点击查看预警明细', trend: 0, path: '/inventory/alerts' },
]);
const todos = ref<any[]>([]);
const brief = ref('');
const aiLoading = ref(false);
const chartRef = ref<HTMLElement | null>(null);
const recentTabs = ref<any[]>([]);
/** 真实经营趋势（来自销售单/采购单按日聚合） */
const trend = ref<{ days: string[]; sale: number[]; purchase: number[] }>({ days: [], sale: [], purchase: [] });

/** 常用功能：点击后写入本地计数，按热度排序 */
const QUICK_PATHS = ['sales/orders', 'inventory/products', 'inventory/balance', 'purchase/orders', 'finance/vouchers', 'print/templates', 'ai/copilot', 'workbench/todo', 'system/import-export'];
const quicks = ref<any[]>([]);
function loadQuicks(): void {
  let counts: Record<string, number> = {};
  try { counts = JSON.parse(localStorage.getItem('erp_quick_counts') || '{}'); } catch { /* 忽略 */ }
  quicks.value = QUICK_PATHS.map((path) => {
    const menu = MENUS.find((m) => m.path === path);
    return { path, title: menu?.title || path, icon: menu?.icon || 'Grid', count: counts[path] || 0 };
  }).sort((a, b) => b.count - a.count);
}
function openQuick(q: any): void {
  let counts: Record<string, number> = {};
  try { counts = JSON.parse(localStorage.getItem('erp_quick_counts') || '{}'); } catch { /* 忽略 */ }
  counts[q.path] = (counts[q.path] || 0) + 1;
  localStorage.setItem('erp_quick_counts', JSON.stringify(counts));
  router.push('/' + q.path);
}

/** 加载工作台数据：各接口独立容错，一个失败不影响其他卡片 */
async function load(): Promise<void> {
  const results = await Promise.allSettled([
    salesApi.list({ pageSize: 1 }), purchaseApi.list({ pageSize: 1 }), financeApi.receivableAging(),
    inventoryApi.alerts(), bpmApi.todo(), biApi.trend(),
  ]);
  const sale: any = results[0].status === 'fulfilled' ? results[0].value : null;
  const pur: any = results[1].status === 'fulfilled' ? results[1].value : null;
  const aging: any = results[2].status === 'fulfilled' ? results[2].value : [];
  const alerts: any = results[3].status === 'fulfilled' ? results[3].value : [];
  const todo: any = results[4].status === 'fulfilled' ? results[4].value : [];
  const trendData: any = results[5].status === 'fulfilled' ? results[5].value : null;
  if (trendData?.days?.length) trend.value = trendData;
  cards.value[0].value = String(sale?.summary?.todayAmount ?? '0.00');
  cards.value[1].value = String(pur?.summary?.todayAmount ?? '0.00');
  cards.value[2].value = (Array.isArray(aging) ? aging : []).reduce((s: number, r: any) => s + Number(r.unpaid ?? 0), 0).toFixed(2);
  cards.value[3].value = String((Array.isArray(alerts) ? alerts : []).length);
  todos.value = (Array.isArray(todo) ? todo : []).slice(0, 6);
  try { recentTabs.value = JSON.parse(localStorage.getItem('erp_tabs') || '[]').slice(-5).reverse(); } catch { /* 忽略 */ }
  loadQuicks();
  renderChart();
}
/** 刷新数据 */
function refresh(): void { load(); toast.success('数据已刷新'); }

/** 处理待办：跳转到审批中心并提示 */
function handleTodo(t: any): void {
  router.push({ path: '/collab/approval', query: { taskId: t.id } });
}
/** 绘制近 7 日趋势图：数据来自真实销售单/采购单按日聚合 */
function renderChart(): void {
  if (!chartRef.value) return;
  const chart = echarts.getInstanceByDom(chartRef.value) || echarts.init(chartRef.value);
  const days = trend.value.days.length ? trend.value.days : ['无数据'];
  chart.setOption({
    tooltip: { trigger: 'axis' }, legend: { data: ['销售额', '采购额'], right: 0 },
    grid: { left: 40, right: 20, top: 36, bottom: 24 },
    xAxis: { type: 'category', data: days },
    yAxis: { type: 'value' },
    series: [
      { name: '销售额', type: 'line', smooth: true, areaStyle: { opacity: .12 }, data: trend.value.sale },
      { name: '采购额', type: 'line', smooth: true, areaStyle: { opacity: .08 }, data: trend.value.purchase },
    ],
  });
}
/** 生成 AI 每日简报 */
async function runBrief(): Promise<void> {
  aiLoading.value = true;
  try {
    const res: any = await aiApi.reportInsight({
      今日销售: cards.value[0].value, 今日采购: cards.value[1].value,
      应收未收: cards.value[2].value, 库存预警: cards.value[3].value, 待办数: todos.value.length,
    });
    brief.value = res.text || JSON.stringify(res);
  } catch { brief.value = '简报生成失败，请稍后重试'; }
  finally { aiLoading.value = false; }
}

onMounted(load);
</script>

<style scoped>
.dash-page { padding: 16px; }
.dash-head { display: flex; align-items: center; justify-content: space-between; margin-bottom: 14px; }
.dash-head h2 { font-size: 18px; margin: 0 0 4px; }
.dash-head p { font-size: 13px; color: var(--ds-text-3); margin: 0; }
.dash-cards { display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px; margin-bottom: 12px; }
.dash-card { background: var(--ds-bg-elevated); border: 1px solid var(--ds-border); border-radius: var(--ds-radius); padding: 14px 16px; cursor: pointer; display: flex; flex-direction: column; gap: 4px; }
.dash-card:hover { border-color: var(--ds-brand); box-shadow: var(--ds-shadow-sm); }
.dash-card__label { color: var(--ds-text-3); font-size: 12px; }
.dash-card__value { font-size: 22px; }
.dash-card small { color: var(--ds-text-3); font-size: 11px; }
.dash-card .up { color: var(--ds-up); } .dash-card .down { color: var(--ds-down); }
.dash-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 12px; }
.dash-todo { display: flex; align-items: center; gap: 10px; padding: 10px 12px; border-bottom: 1px solid var(--ds-divider); cursor: pointer; }
.dash-todo:hover { background: var(--ds-bg-hover); }
.dash-todo__icon { font-size: 16px; }
.dash-todo div { flex: 1; display: flex; flex-direction: column; gap: 2px; }
.dash-todo b { font-size: 13px; } .dash-todo small { font-size: 11px; color: var(--ds-text-3); }
.dash-chart { height: 260px; }
.dash-empty { padding: 30px; text-align: center; color: var(--ds-text-3); font-size: 13px; }
.dash-quick { display: grid; grid-template-columns: repeat(3, 1fr); gap: 8px; padding: 12px; }
.dash-quick__item { display: flex; flex-direction: column; align-items: center; gap: 6px; padding: 12px 6px; border: 1px solid var(--ds-border); border-radius: var(--ds-radius); cursor: pointer; font-size: 12px; }
.dash-quick__item:hover { background: var(--ds-brand-soft); border-color: var(--ds-brand); }
.dash-quick__item span { font-size: 18px; }
.dash-ai { white-space: pre-wrap; font-size: 13px; line-height: 1.7; min-height: 180px; margin: 0; color: var(--ds-text-2); }
.dash-recent { display: flex; justify-content: space-between; padding: 10px 12px; border-bottom: 1px solid var(--ds-divider); font-size: 13px; cursor: pointer; }
.dash-recent span { color: var(--ds-text-3); }
.dash-calendar { padding: 8px 12px; }
.dash-cal-item { display: flex; gap: 14px; padding: 9px 0; border-bottom: 1px solid var(--ds-divider); font-size: 13px; }
.dash-cal-item b { min-width: 78px; color: var(--ds-brand); }
.dash-cal-item span { color: var(--ds-text-2); }
@media (max-width: 1000px) { .dash-grid, .dash-cards { grid-template-columns: 1fr 1fr; } }
</style>
