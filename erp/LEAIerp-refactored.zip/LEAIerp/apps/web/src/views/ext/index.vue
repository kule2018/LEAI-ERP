<template>
  <div class="page-card">
    <div class="balance-tabs">
      <button v-for="t in tabItems" :key="t.value" class="balance-tab" :class="{ on: tab === t.value }" @click="switchTab(t.value)">{{ t.label }}</button>
    </div>

    <!-- BPM 审批流 -->
    <div v-if="tab === 'bpm'">
      <div class="ext-cols">
        <div>
          <div class="panel-title">待办任务 <DsButton size="sm" @click="signVisible = true">电子签名</DsButton></div>
          <div class="entity-table">
            <table class="ds-table">
              <thead><tr><th>单号</th><th>类型</th><th>当前节点</th><th>节点类型</th><th>审批人</th><th>金额</th><th>操作</th></tr></thead>
              <tbody>
                <tr v-for="(row, i) in todo" :key="row.id || i" style="cursor:pointer" @click="openInst(row)">
                  <td>{{ row.bizNo }}</td><td>{{ row.bizType }}</td><td>{{ row.nodeName }}</td>
                  <td><span class="ext-node-type">{{ nodeTypeText(row.nodeType) }}</span></td>
                  <td>{{ row.assignee || '—' }}</td>
                  <td>{{ row.amount ?? '—' }}</td>
                  <td>
                    <DsButton size="sm" variant="text" @click.stop="aiSuggestion(row)">AI 意见</DsButton>
                    <DsButton size="sm" variant="primary" @click.stop="handle(row, 'APPROVE')">通过</DsButton>
                    <DsButton size="sm" variant="danger" @click.stop="handle(row, 'REJECT')">驳回</DsButton>
                    <DsButton size="sm" variant="text" @click.stop="openTransfer(row)">转办</DsButton>
                    <DsButton size="sm" variant="text" @click.stop="doCancel(row)">撤回</DsButton>
                  </td>
                </tr>
                <tr v-if="!todo.length"><td colspan="7"><div class="ext-empty">暂无待办任务</div></td></tr>
              </tbody>
            </table>
          </div>
        </div>
        <div>
          <div class="panel-title">流程定义（金额阈值路由）</div>
          <div class="entity-table">
            <table class="ds-table">
              <thead><tr><th>编码</th><th>名称</th><th>状态</th></tr></thead>
              <tbody><tr v-for="(r, i) in defs" :key="i"><td>{{ r.code }}</td><td>{{ r.name }}</td><td>{{ r.status }}</td></tr></tbody>
            </table>
          </div>
          <div class="panel-title">审批日志</div>
          <div class="entity-table">
            <table class="ds-table">
              <thead><tr><th>节点</th><th>动作</th><th>时间</th></tr></thead>
              <tbody><tr v-for="(r, i) in logs" :key="i"><td>{{ r.nodeName }}</td><td>{{ r.action }}</td><td>{{ r.createdAt }}</td></tr></tbody>
            </table>
          </div>
        </div>
      </div>
    </div>

    <!-- BI 自定义报表 -->
    <div v-if="tab === 'bi'">
      <div class="entity-search">
        <span class="ext-label">报表</span>
        <DsSelect v-model="reportId" :options="reportOptions" style="width:200px" />
        <DsButton variant="primary" @click="runReport">运行</DsButton>
        <DsButton @click="loadDashboard">经营看板</DsButton>
      </div>
      <div class="entity-table" style="margin-top:8px">
        <table class="ds-table">
          <thead><tr><th v-for="(v, k) in (biRows[0] || {})" :key="k">{{ k }}</th></tr></thead>
          <tbody><tr v-for="(r, i) in biRows" :key="i"><td v-for="(v, k) in r" :key="k">{{ v }}</td></tr></tbody>
        </table>
      </div>
      <div class="panel-title">报表定义（表与字段走白名单，防 SQL 注入）</div>
      <div class="entity-table">
        <table class="ds-table">
          <thead><tr><th>编码</th><th>名称</th><th>维度</th><th>指标</th></tr></thead>
          <tbody>
            <tr v-for="(r, i) in reports" :key="r.code || i"><td>{{ r.code }}</td><td>{{ r.name }}</td><td>{{ r.dimensions }}</td><td>{{ r.metrics }}</td></tr>
          </tbody>
        </table>
      </div>
    </div>

    <!-- CRM -->
    <div v-if="tab === 'crm'">
      <div class="entity-search">
        <span class="ext-label">线索名称</span><input v-model="lead.name" class="ds-input" />
        <span class="ext-label">公司</span><input v-model="lead.company" class="ds-input" />
        <span class="ext-label">电话</span><input v-model="lead.phone" class="ds-input" />
        <DsButton variant="primary" @click="saveLead">新增线索</DsButton>
      </div>
      <div class="entity-table" style="margin-top:8px">
        <table class="ds-table">
          <thead><tr><th>名称</th><th>公司</th><th>AI 评分</th><th>状态</th><th>操作</th></tr></thead>
          <tbody>
            <tr v-for="(row, i) in leads" :key="row.id || i"><td>{{ row.name }}</td><td>{{ row.company }}</td><td>{{ row.score }}</td><td>{{ row.status }}</td><td><DsButton size="sm" variant="text" @click="convert(row)">转化</DsButton></td></tr>
          </tbody>
        </table>
      </div>
      <div class="panel-title">商机</div>
      <div class="entity-table">
        <table class="ds-table">
          <thead><tr><th>名称</th><th>预计金额</th><th>阶段</th><th>赢率%</th></tr></thead>
          <tbody><tr v-for="(row, i) in opps" :key="i"><td>{{ row.name }}</td><td>{{ row.amount }}</td><td>{{ row.stage }}</td><td>{{ row.probability }}</td></tr></tbody>
        </table>
      </div>
      <div class="panel-title">报价单</div>
      <div class="entity-table">
        <table class="ds-table">
          <thead><tr><th>报价单号</th><th>金额</th><th>状态</th><th>操作</th></tr></thead>
          <tbody><tr v-for="(row, i) in quotes" :key="row.id || i"><td>{{ row.quoteNo }}</td><td>{{ row.totalAmount }}</td><td>{{ row.status }}</td><td><DsButton size="sm" variant="text" @click="acceptQuote(row)">接受</DsButton></td></tr></tbody>
        </table>
      </div>
    </div>

    <!-- WMS -->
    <div v-if="tab === 'wms'">
      <div class="ext-space">
        <DsButton @click="genWave">生成波次</DsButton>
        <DsButton @click="createTake">新建盘点单</DsButton>
        <DsButton @click="createPutaway">新建上架单</DsButton>
        <DsButton @click="createTransfer">新建调拨单</DsButton>
      </div>
      <div class="ext-cols" style="margin-top:8px">
        <div>
          <div class="panel-title">盘点单（盲盘）</div>
          <div class="entity-table">
            <table class="ds-table">
              <thead><tr><th>单号</th><th>状态</th><th>操作</th></tr></thead>
              <tbody><tr v-for="(row, i) in takes" :key="row.id || i"><td>{{ row.takeNo }}</td><td>{{ row.status }}</td><td><DsButton size="sm" variant="text" @click="finishTake(row)">完成</DsButton></td></tr></tbody>
            </table>
          </div>
        </div>
        <div>
          <div class="panel-title">波次</div>
          <div class="entity-table">
            <table class="ds-table">
              <thead><tr><th>单号</th><th>状态</th><th>操作</th></tr></thead>
              <tbody><tr v-for="(row, i) in waves" :key="row.id || i"><td>{{ row.waveNo }}</td><td>{{ row.status }}</td><td><DsButton size="sm" variant="text" @click="waveLines(row)">查看明细</DsButton></td></tr></tbody>
            </table>
          </div>
        </div>
      </div>
      <div class="entity-table" style="margin-top:8px">
        <table class="ds-table">
          <thead><tr><th>产品</th><th>账面数</th><th>实盘数</th><th>差异</th></tr></thead>
          <tbody>
            <tr v-for="(row, i) in takeLines" :key="row.id || i"><td>{{ row.productName }}</td><td>{{ row.bookQty }}</td><td><DsInputNumber v-model="row.realQty" size="sm" @change="inputReal(row)" /></td><td>{{ row.diffQty }}</td></tr>
          </tbody>
        </table>
      </div>
    </div>

    <!-- MES -->
    <div v-if="tab === 'mes'">
      <div class="ext-space">
        <DsButton variant="primary" @click="runMrp">执行 MRP 运算</DsButton>
        <DsButton @click="loadSuggests">查看最新建议</DsButton>
      </div>
      <div class="entity-table" style="margin-top:8px">
        <table class="ds-table">
          <thead><tr><th>物料/产品</th><th>需求</th><th>可用</th><th>在途</th><th>净需求</th><th>建议</th></tr></thead>
          <tbody>
            <tr v-for="(row, i) in suggests" :key="i"><td>{{ row.productName }}</td><td>{{ row.demandQty }}</td><td>{{ row.availableQty }}</td><td>{{ row.onWayQty }}</td><td>{{ row.netQty }}</td><td>{{ row.suggestType === 'PURCHASE' ? '建议采购' : '建议生产' }}</td></tr>
          </tbody>
        </table>
      </div>
      <div class="panel-title">质检（AI 建议）</div>
      <div class="entity-table">
        <table class="ds-table">
          <thead><tr><th>单号</th><th>检验数</th><th>不合格</th><th>建议</th></tr></thead>
          <tbody><tr v-for="(r, i) in qc" :key="r.qcNo || i"><td>{{ r.qcNo }}</td><td>{{ r.checkQty }}</td><td>{{ r.ngQty }}</td><td>{{ r.aiAdvice }}</td></tr></tbody>
        </table>
      </div>
    </div>

    <!-- 商城 -->
    <div v-if="tab === 'shop'">
      <div class="entity-search">
        <span class="ext-label">店铺名称</span><input v-model="store.name" class="ds-input" />
        <span class="ext-label">平台</span><input v-model="store.platform" class="ds-input" placeholder="SELF/淘宝/京东/抖音" />
        <DsButton variant="primary" @click="saveStore">保存店铺</DsButton>
      </div>
      <div class="entity-table" style="margin-top:8px">
        <table class="ds-table">
          <thead><tr><th>店铺</th><th>平台</th><th>状态</th><th>操作</th></tr></thead>
          <tbody><tr v-for="(r, i) in stores" :key="r.id || i"><td>{{ r.name }}</td><td>{{ r.platform }}</td><td>{{ r.status }}</td><td><DsButton size="sm" variant="text" @click="syncOrder(r)">拉取订单</DsButton></td></tr></tbody>
        </table>
      </div>
      <div class="panel-title">平台订单</div>
      <div class="entity-table">
        <table class="ds-table">
          <thead><tr><th>平台单号</th><th>金额</th><th>状态</th><th>操作</th></tr></thead>
          <tbody><tr v-for="(r, i) in shopOrders" :key="r.id || i"><td>{{ r.platformOrderNo }}</td><td>{{ r.amount }}</td><td>{{ r.status }}</td><td>
            <DsButton size="sm" variant="text" @click="convertOrder(r)">转销售单</DsButton>
            <DsButton size="sm" variant="text" @click="shipOrder(r)">发货回传</DsButton></td></tr></tbody>
        </table>
      </div>
    </div>

    <!-- 移动端 -->
    <div v-if="tab === 'mobile'">
      <div class="entity-search">
        <span class="ext-label">扫码</span><input v-model="scanCode" class="ds-input" placeholder="条码/产品编码" @keyup.enter="doScan" />
        <DsButton variant="primary" @click="doScan">查询</DsButton>
        <DsButton @click="submitOffline">模拟离线批量提交</DsButton>
      </div>
      <DsDescriptions v-if="scanResult" :items="scanDescItems" :data="scanResult?.product || {}" :column="4" bordered style="margin-top:8px" />
      <div class="panel-title">移动端待办</div>
      <div class="entity-table">
        <table class="ds-table">
          <thead><tr><th>标题</th><th>节点</th></tr></thead>
          <tbody><tr v-for="(r, i) in mTodo" :key="i"><td>{{ r.title }}</td><td>{{ r.nodeName }}</td></tr></tbody>
        </table>
      </div>
    </div>

    <!-- 电子签名：审批/签收场景手写签章，确认后保存到本地业务数据 -->
    <DsModal v-model="signVisible" title="电子签名" :width="520">
      <SignaturePad v-model="signData" @confirm="onSigned" />
    </DsModal>

    <!-- 转办：把当前待办指派给其他审批人 -->
    <DsModal v-model="transferVisible" title="转办审批任务" :width="440">
      <div class="ext-form">
        <label class="ext-label">接收人</label>
        <input v-model="transferTo" class="ds-input" placeholder="请输入审批人姓名" />
        <label class="ext-label">转办说明</label>
        <input v-model="transferRemark" class="ds-input" placeholder="选填" />
      </div>
      <template #footer>
        <DsButton @click="transferVisible = false">取消</DsButton>
        <DsButton variant="primary" :disabled="!transferTo.trim()" @click="doTransfer">确认转办</DsButton>
      </template>
    </DsModal>
  </div>
</template>
<script setup lang="ts">
import { ref, reactive, computed, onMounted, watch } from 'vue'
import { useRoute } from 'vue-router'
import { DsButton, DsCard, DsModal, DsSelect, DsDescriptions, DsInputNumber } from '../../components'
import { useToast } from '../../components/ds/toast'
import { bpmApi, biApi, crmApi, wmsApi, mesApi, shopApi, mobileApi } from '../../api/ext'
import { aiApi } from '../../api'
import { mockPost } from '../../api/mockAdapter'
import { emit, Events } from '../../utils/eventBus'

const toast = useToast()
const route = useRoute()
/** 同一组件承接多个菜单：按路由定位业务页签，避免「MRP / 商城中心」误落到审批流 */
const PATH_TAB: Record<string, string> = {
  'workbench/todo': 'bpm', 'collab/approval': 'bpm',
  'manufacturing/mrp': 'mes', 'shop/center': 'shop',
}
function inferTab(): string {
  const q = String(route.query.tab || '')
  if (['bpm', 'bi', 'crm', 'wms', 'mes', 'shop', 'mobile'].includes(q)) return q
  return PATH_TAB[route.path.replace(/^\//, '')] || 'bpm'
}
const tab = ref(inferTab())
watch(() => route.path, () => {
  const next = inferTab()
  if (next !== tab.value) { tab.value = next; load() }
})
const tabItems = [
  { label: '审批流', value: 'bpm' },
  { label: 'BI 报表', value: 'bi' },
  { label: 'CRM', value: 'crm' },
  { label: '仓储 WMS', value: 'wms' },
  { label: '生产 MES', value: 'mes' },
  { label: '商城渠道', value: 'shop' },
  { label: '移动端', value: 'mobile' },
]
/** 承接原 el-tabs 的 @tab-change="load"：切换时按当前 tab 懒加载 */
function switchTab(v: string) { if (tab.value === v) return; tab.value = v; load() }
/** DsSelect 选项（替代模板内 el-option） */
const reportOptions = computed(() => reports.value.map((r: any) => ({ label: r.name, value: r.id })))
/** DsDescriptions 描述项（替代 el-descriptions-item） */
const scanDescItems = [
  { key: 'name', label: '产品' },
  { key: 'code', label: '编码' },
  { key: 'price', label: '售价' },
  { key: 'available', label: '可用库存' },
]
const todo = ref<any[]>([]); const defs = ref<any[]>([]); const logs = ref<any[]>([])
const reports = ref<any[]>([]); const reportId = ref<number | null>(null); const biRows = ref<any[]>([])
const leads = ref<any[]>([]); const opps = ref<any[]>([]); const quotes = ref<any[]>([])
const lead = reactive<any>({ name: '', company: '', phone: '' })
const takes = ref<any[]>([]); const takeLines = ref<any[]>([]); const waves = ref<any[]>([])
const suggests = ref<any[]>([]); const qc = ref<any[]>([])
const stores = ref<any[]>([]); const shopOrders = ref<any[]>([])
const store = reactive<any>({ name: '', platform: 'SELF' })
const scanCode = ref(''); const scanResult = ref<any>(null); const mTodo = ref<any[]>([])
/** 电子签名状态 */
const signVisible = ref(false); const signData = ref('')
/** 转办弹窗状态：目标待办 + 接收人 + 说明 */
const transferVisible = ref(false); const transferRow = ref<any>(null)
const transferTo = ref(''); const transferRemark = ref('')

/** AI 审批意见助手：把单据信息交给 Copilot 生成意见，并作为驳回/通过建议 */
async function aiSuggestion(row: any): Promise<void> {
  try {
    const res: any = await aiApi.copilot(`请为审批任务 ${row.bizNo || row.id}（类型 ${row.bizType}，金额 ${row.amount || '未知'}）生成简短审批意见并提示风险点。`, false)
    toast.info(res.text || res.message || '已生成审批意见')
  } catch { toast.info('AI 暂不可用，请手动填写审批意见') }
}
/** 签名确认后写入 revision 快照并发布事件 */
async function onSigned(value: string): Promise<void> {
  await mockPost('/api/v1/ux/revisions', { entity: 'SIGNATURE', snapshot: value.slice(0, 120) + '…', reason: '电子签名' })
  emit(Events.DATA_RELOADED, { type: 'signature' })
  toast.success('签名已保存')
  signVisible.value = false
}

async function load() {
  const t = tab.value
  if (t === 'bpm') { todo.value = await bpmApi.todo() as any; defs.value = await bpmApi.definitions() as any }
  if (t === 'bi') { reports.value = await biApi.reports() as any }
  if (t === 'crm') { leads.value = ((await crmApi.leads()) as any).list || []; opps.value = await crmApi.opportunities() as any; quotes.value = await crmApi.quotations() as any }
  if (t === 'wms') { takes.value = await wmsApi.stocktakes() as any; waves.value = await wmsApi.waves() as any }
  if (t === 'mes') { qc.value = await mesApi.qc() as any }
  if (t === 'shop') { stores.value = await shopApi.stores() as any; shopOrders.value = ((await shopApi.orders()) as any).list || [] }
  if (t === 'mobile') { mTodo.value = await mobileApi.todo() as any }
}
async function handle(row: any, action: string) {
  try {
    const r: any = await bpmApi.handle(row.id, { action, comment: action === 'APPROVE' ? '同意' : '不同意' })
    toast.success(r?.message || '已处理')
    load()
  } catch (e: any) { toast.error(e?.message || '审批处理失败') }
}
async function openInst(row: any) {
  const iid = row.instanceId || row.instance_id
  logs.value = (await bpmApi.logs(iid) as any) || []
}
/** 节点类型中文说明：让会签/或签/抄送在列表上可辨识 */
function nodeTypeText(t: string) {
  return ({ approval: '审批', countersign: '会签', orsign: '或签', cc: '抄送', auto: '自动' } as Record<string, string>)[String(t || '')] || '审批'
}
/** 撤回：终止流程，单据恢复可编辑 */
async function doCancel(row: any) {
  try {
    const r: any = await bpmApi.cancel(row.id, '申请人撤回')
    toast.success(r?.message || '已撤回')
    load()
  } catch (e: any) { toast.error(e?.message || '撤回失败') }
}
/** 打开转办弹窗 */
function openTransfer(row: any) {
  transferRow.value = row
  transferTo.value = ''
  transferRemark.value = ''
  transferVisible.value = true
}
/** 提交转办 */
async function doTransfer() {
  if (!transferTo.value.trim()) { toast.warning('请填写接收人'); return }
  try {
    const r: any = await bpmApi.transfer(transferRow.value.id, transferTo.value.trim())
    toast.success(r?.message || '已转办')
    transferVisible.value = false
    load()
  } catch (e: any) { toast.error(e?.message || '转办失败') }
}
async function runReport() { if (reportId.value) biRows.value = await biApi.run(reportId.value) as any }
async function loadDashboard() { biRows.value = await biApi.dashboard() as any }
async function saveLead() { await crmApi.saveLead(lead); toast.success('已新增'); load() }
async function convert(row: any) { await crmApi.convertLead(row.id, { customerName: row.company || row.name }); toast.success('已转化'); load() }
async function acceptQuote(row: any) { await crmApi.acceptQuotation(row.id); toast.success('已接受') }
async function genWave() { const r: any = await wmsApi.generateWave({ warehouseId: 1 }); toast.success(`生成 ${r.lineCount} 行`); load() }
async function createPutaway() { await wmsApi.createPutaway({ warehouseId: 1, productId: 1, qty: 1 }); toast.success('已创建'); load() }
async function createTake() { const r: any = await wmsApi.createStocktake({ warehouseId: 1 }); toast.success('已创建'); takeLines.value = await wmsApi.stocktakeLines(r.id) as any; load() }
async function inputReal(row: any) { await wmsApi.inputReal(row.id, row.realQty || 0); load() }
async function finishTake(row: any) { const r: any = await wmsApi.finishStocktake(row.id); toast.success(`差异 ${r.diffLines} 行已过账`); load() }
async function waveLines(row: any) { takeLines.value = await wmsApi.waveLines(row.id) as any }
async function createTransfer() { await wmsApi.createTransfer({ fromWarehouseId: 1, toWarehouseId: 2, productId: 1, qty: 1 }); toast.success('已创建') }
async function runMrp() { const r: any = await mesApi.runMrp({ source: 'MANUAL' }); toast.success(`运算完成，成品 ${r.productCount} 个`); loadSuggests() }
async function loadSuggests() { const runs: any[] = await mesApi.runs() as any; if (runs[0]) suggests.value = await mesApi.suggests(runs[0].id) as any }
async function saveStore() { await shopApi.saveStore(store); toast.success('已保存'); load() }
async function syncOrder(row: any) { const r: any = await shopApi.sync(row.id, [{ platformOrderNo: `PL${Date.now()}`, buyer: '测试买家', amount: 100, items: [{ platformSku: 'SKU1' }] }]); toast.success(`新增 ${r.created}`); shopOrders.value = ((await shopApi.orders()) as any).list || [] }
async function convertOrder(row: any) { const r: any = await shopApi.convert(row.id); toast.success('已转 ' + r.orderNo); load() }
async function shipOrder(row: any) { await shopApi.ship(row.id, { trackingNo: `SF${Date.now()}` }); toast.success('已回传'); load() }
async function doScan() { scanResult.value = await mobileApi.scan(scanCode.value) as any }
async function submitOffline() { const r: any = await mobileApi.offlineSubmit(`B${Date.now()}`, [{ type: 'scan', code: '6901234567890' }]); toast.success(r.status) }
onMounted(load)
</script>
<style scoped>
.panel-title { font-size: 13px; color: #666; margin: 10px 0 4px; }
.balance-tabs { display: flex; gap: 4px; flex-wrap: wrap; padding: 8px 12px 0; border-bottom: 1px solid var(--ds-divider); }
.balance-tab { padding: 8px 16px; border: 0; background: transparent; color: var(--ds-text-2); font-size: var(--ds-font-sm); cursor: pointer; border-bottom: 2px solid transparent; }
.balance-tab:hover { color: var(--ds-brand); }
.balance-tab.on { color: var(--ds-brand); border-bottom-color: var(--ds-brand); font-weight: 600; }
.ext-cols { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 12px; }
.ext-space { display: flex; flex-wrap: wrap; gap: 8px; }
.ext-label { color: var(--ds-text-2); font-size: var(--ds-font-sm); }
/* 节点类型标签：会签/或签/抄送一眼可辨 */
.ext-node-type {
  display: inline-block; padding: 1px 8px; border-radius: var(--ds-radius-sm);
  background: var(--ds-brand-soft, #eef4ff); color: var(--ds-brand, #2563eb);
  font-size: var(--ds-font-xs); white-space: nowrap;
}
/* 表格空态：与统一空状态规范一致 */
.ext-empty { padding: 32px 0; text-align: center; color: var(--ds-text-3); font-size: var(--ds-font-sm); }
/* 转办表单：纵向分组，组间间距大于组内 */
.ext-form { display: grid; grid-template-columns: 96px minmax(0, 1fr); gap: 12px 16px; align-items: center; }
.ext-form .ds-input { width: 100%; }
.entity-search .ds-input { width: 180px; }
@media (max-width: 900px) { .ext-cols { grid-template-columns: 1fr; } .ext-form { grid-template-columns: minmax(0, 1fr); } }
</style>