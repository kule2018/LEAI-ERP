<template><RecordPage :config="page" /></template>

<script setup lang="ts">
import RecordPage from '../records/RecordPage.vue';
import type { RecordPageConfig } from '../records/records';

const page: RecordPageConfig = {
  title: '资产盘点',
  resource: 'finance/asset-checks',
  schema: 'financeAssetChecks',
  filters: ['assetName', 'checkDate'],
  reportSource: '查询固定资产账面数量和实盘差异',
  metrics: ['bookQty', 'realQty', 'diffQty'],
  link: { to: '/finance/assets', label: '固定资产台账' },
};
</script>
