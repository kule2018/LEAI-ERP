<template><RecordPage :config="page" /></template>

<script setup lang="ts">
import RecordPage from '../records/RecordPage.vue';
import type { RecordPageConfig } from '../records/records';

const page: RecordPageConfig = {
  title: '资产处置',
  resource: 'finance/asset-disposals',
  schema: 'financeAssetDisposals',
  filters: ['assetName', 'method', 'bizDate'],
  reportSource: '固定资产处置记录',
  metrics: ['originalValue', 'disposalValue'],
  link: { to: '/finance/assets', label: '固定资产台账' },
};
</script>
