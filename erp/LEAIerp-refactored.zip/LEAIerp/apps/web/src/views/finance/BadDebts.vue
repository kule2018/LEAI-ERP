<template><RecordPage :config="page" /></template>

<script setup lang="ts">
import RecordPage from '../records/RecordPage.vue';
import type { RecordPageConfig } from '../records/records';

const page: RecordPageConfig = {
  title: '坏账',
  resource: 'finance/bad-debts',
  schema: 'financeBadDebts',
  filters: ['customerName', 'status'],
  reportSource: '坏账记录查询',
  metrics: ['amount'],
};
</script>
