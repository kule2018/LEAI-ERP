<template><RecordPage :config="page" /></template>

<script setup lang="ts">
import RecordPage from '../records/RecordPage.vue';
import type { RecordPageConfig } from '../records/records';

const page: RecordPageConfig = {
  title: '资产负债表',
  resource: 'finance/balance-sheets',
  schema: 'financeBalanceSheets',
  filters: ['period', 'side'],
  reportSource: '按期间查询资产负债表快照',
};
</script>
