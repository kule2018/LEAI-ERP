<template>
  <div class="erp-page">
    <DsCard :title="title">
      <form class="record-form" @submit.prevent="save">
        <label>单号 <input v-model.trim="form.code" class="ds-input" maxlength="64" required /></label>
        <label>事项 <input v-model.trim="form.name" class="ds-input" maxlength="128" required /></label>
        <label>{{ partnerLabel }} <input v-model.trim="form.partner" class="ds-input" /></label>
        <label>类别
          <select v-model="form.bizText" class="ds-select">
            <option value="">选择类别</option>
            <option v-for="category in categories" :key="category.id" :value="category.name">{{ category.name }}</option>
          </select>
        </label>
        <label>金额 <input :value="form.amount" class="ds-input" type="number" min="0.01" step="0.01" required @input="form.amount = ($event.target as HTMLInputElement).value" /></label>
        <label>发生日期 <input v-model="form.docDate" class="ds-input" type="date" required /></label>
        <label v-if="kind === 'expense'">单据张数 <input v-model.number="form.qty" class="ds-input" type="number" min="0" step="1" /></label>
        <label>备注 <textarea v-model.trim="form.remark" class="ds-input" rows="2" /></label>
        <div class="record-buttons cash-entry-footer">
          <RouterLink :to="listPath" class="ds-btn ds-btn-default ds-btn-md">返回列表</RouterLink>
          <DsButton type="submit" variant="primary" :loading="saving">保存草稿</DsButton>
        </div>
      </form>
      <p v-if="error" class="record-error" role="alert">{{ error }}</p>
    </DsCard>
  </div>
</template>

<script setup lang="ts">
import { DsButton, DsCard } from '../../components';
import { useCashEntry } from './cashEntry';

const { kind } = defineProps<{ kind: 'expense' | 'income' }>();
const { title, listPath, categories, form, partnerLabel, saving, error, save } = useCashEntry(kind);
</script>

<style src="../records/recordPage.css"></style>
<style scoped>
.cash-entry-footer { grid-column: 1 / -1; justify-content: flex-end; }
</style>
