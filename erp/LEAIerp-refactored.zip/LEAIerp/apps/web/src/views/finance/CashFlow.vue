
<template><div class="u-page">
<div class="u-head"><div><div class="u-kicker">DONUT · 现金流量表</div><h2>现金流量表</h2></div><div class="u-actions"><DsButton size="sm" @click="load">刷新</DsButton><DsButton size="sm" @click="exportCsv">导出</DsButton></div></div>
<div class="u-stats"><div v-for="s in statVals" :key="s.label" class="u-stat"><span>{{s.label}}</span><b>{{s.unit=== '¥'?'¥':'' }}{{s.value}}{{s.unit&&s.unit!=='¥'?s.unit:''}}</b></div></div>
<div class="u-search"><input v-model="q.keyword" class="ds-input" placeholder="搜索…" @keyup.enter="reload"/><select v-if="hasStatus" v-model="q.status" class="ds-input"><option value="">全部状态</option><option v-for="(l,v) in statusLabels" :key="v" :value="v">{{l}}</option></select><DsButton variant="primary" size="sm" @click="reload">查询</DsButton><DsButton size="sm" @click="resetQuery">重置</DsButton></div>
<div class="u-donut-page"><div class="u-donut-box"><div class="u-donut" :style="donutStyle()"><div class="u-donut-hole"><b>{{rows.length}}</b><span>项</span></div></div><ul class="u-legend"><li v-for="(r,i) in rows.slice(0,8)" :key="r.id"><i :style="{background:legendColor(i)}"></i>{{r.name}}<b>{{display(r,amountCol())}}</b></li></ul></div><div class="u-chart-card"><div class="u-table-wrap"><table class="u-table u-table-dense"><thead><tr><th v-for="c in columns" :key="c.prop">{{c.label}}</th></tr></thead><tbody><tr v-for="r in rows.slice(0,8)" :key="r.id"><td v-for="c in columns" :key="c.prop">{{display(r,c)}}</td></tr></tbody></table></div></div></div>
<div class="u-pager"><DsPagination v-model:current-page="page" :page-size="pageSize" :total="total" layout="total, prev, pager, next" @change="load"/></div>

</div></template>

<script setup lang="ts">
import { ref, reactive, computed, onMounted } from 'vue';
import { mockGet, mockPost, mockPatch, mockDel } from '../../api/mockAdapter';
import { useToast } from '../../components/ds/toast';
import { confirm as uiConfirm } from '../../components/ds/useConfirm';
const toast=useToast();
const API="/api/v1/fin/cash-flow";
const COLLECTION="finCashFlow";
const columns:any[]=[{"prop":"code","label":"项目编码","type":"text","options":null,"source":""},{"prop":"name","label":"现金流项目","type":"text","options":null,"source":""},{"prop":"partner","label":"归口部门","type":"text","options":null,"source":""},{"prop":"amount","label":"本期金额","type":"number","options":null,"source":""},{"prop":"bizText","label":"现金流分类","type":"text","options":null,"source":""},{"prop":"bizDate","label":"报表期间","type":"date","options":null,"source":""}];
const formFields:any[]=[{"prop":"code","label":"项目编码","type":"text","options":null,"source":"","required":true,"placeholder":""},{"prop":"name","label":"现金流项目","type":"text","options":null,"source":"","required":true,"placeholder":""},{"prop":"partner","label":"归口部门","type":"text","options":null,"source":"","required":false,"placeholder":""},{"prop":"amount","label":"本期金额","type":"number","options":null,"source":"","required":false,"placeholder":""},{"prop":"bizText","label":"现金流分类","type":"text","options":null,"source":"","required":false,"placeholder":""},{"prop":"bizDate","label":"报表期间","type":"date","options":null,"source":"","required":false,"placeholder":""},{"prop":"remark","label":"备注","type":"textarea","options":null,"source":"","required":false,"placeholder":""}];
const statusLabels:Record<string,string>={"0":"停用","1":"启用"};
const actions:any[]=[];
const DEFAULTS:any={"status":1,"qty":0,"amount":0,"bizAmount":0};
const STATS:any[]=[{"label":"记录总数","expr":"rows.length","unit":""},{"label":"本期金额合计","expr":"sum('amount')","unit":"¥"},{"label":"待处理","expr":"rows.filter(r=>Number(r.status)<=1).length","unit":""}];
const hasStatus=Object.keys(statusLabels).length>0;
const isReport=true;
const arch="donut";
const q=reactive<{keyword:string;status:any}>({keyword:'',status:''});
const rows=ref<any[]>([]);const total=ref(0);const page=ref(1);const pageSize=ref(12);
const loading=ref(false);const saving=ref(false);const formVisible=ref(false);const editing=ref<any>(null);
const form=reactive<Record<string,any>>({});
const remoteOptions=reactive<Record<string,any[]>>({});
const statVals=computed(()=>STATS.map(s=>({label:s.label,unit:s.unit,value:evalStat(s.expr)})));
function sum(prop:string){return rows.value.reduce((a,r)=>a+(Number(r[prop])||0),0);}
function evalStat(expr:string){try{return new Function('rows','page','sum','rows_',expr)(rows.value,page.value,sum,rows.value);}catch{return 0;}}
function statusText(v:any){return statusLabels[String(v)]||String(v??'');}
function display(row:any,col:any){const v=row[col.prop];if(col.prop==='status'&&hasStatus)return statusText(v);if(col.options){const h=col.options.find((o:any)=>String(o.value)===String(v));if(h)return h.label;}const src=(remoteOptions as any)[col.source];if(src){const h=src.find((o:any)=>String(o.value)===String(v));if(h)return h.label;}if(v==null||v==='')return '—';const s=String(v);return /^\d{4}-\d{2}-\d{2}/.test(s)?s.slice(0,10):s;}
function optionsOf(f:any){return f.options||(remoteOptions as any)[f.source]||[];}
async function loadRemote(){const srcs:Record<string,string>={customers:'/api/v1/crm/customers',products:'/api/v1/inventory/products',orders:'/api/v1/sales/orders',groups:'/api/v1/crm/customer-groups',suppliers:'/api/v1/purchase/suppliers',warehouses:'/api/v1/inventory/warehouses'};const used=formFields.filter(f=>f.source).map(f=>f.source);await Promise.all(used.map(async s=>{if(remoteOptions[s])return;try{const d:any=await mockGet(srcs[s]||API,{pageSize:200});const list=Array.isArray(d)?d:d?.list||[];remoteOptions[s]=list.map((x:any)=>({label:x.name||x.code||x.title||('#'+x.id),value:x.id}));}catch{remoteOptions[s]=[];}}));}
async function load(){loading.value=true;try{const d:any=await mockGet(API,{page:page.value,pageSize:pageSize.value,keyword:q.keyword,status:q.status});rows.value=Array.isArray(d)?d:d?.list||[];total.value=Number(d?.total??rows.value.length);}catch(e:any){toast.error(e?.message||'加载失败');rows.value=[];}finally{loading.value=false;}}
function reload(){page.value=1;load();}
function resetQuery(){q.keyword='';q.status='';reload();}
function resetForm(){for(const k of Object.keys(form))delete form[k];for(const f of formFields)form[f.prop]=DEFAULTS[f.prop]??(f.type==='number'?0:'');}
function openForm(row?:any){editing.value=row||null;resetForm();if(row)for(const f of formFields)if(row[f.prop]!==undefined)form[f.prop]=row[f.prop];formVisible.value=true;}
async function save(){for(const f of formFields){if(f.required&&(form[f.prop]===''||form[f.prop]==null)){toast.warning('请填写「'+f.label+'」');return;}}saving.value=true;try{const payload:any={};for(const f of formFields)payload[f.prop]=form[f.prop];if(editing.value?.id)await mockPatch(API+'/'+editing.value.id,payload);else await mockPost(API,payload);toast.success(editing.value?'已保存':'已创建');formVisible.value=false;await load();}catch(e:any){toast.error(e?.message||'保存失败');}finally{saving.value=false;}}
function actionsOf(row:any){return actions.filter(a=>!a.from||a.from.some(s=>Number(s)===Number(row.status)));}
function colorOf(a:any){return a.variant==='danger'?'var(--ds-danger)':a.variant==='warning'?'var(--ds-warning)':'var(--ds-brand)';}
async function runAction(row:any,a:any){if(!await uiConfirm('确定执行「'+a.label+'」吗？','业务确认'))return;try{const res:any=await mockPost('/_biz/action/'+COLLECTION+'/'+row.id+'/'+a.key,{label:a.label});toast.success(res?.message||(a.label+'成功'));await load();}catch(e:any){toast.error(e?.message||'操作失败');}}
async function removeRow(row:any){if(!await uiConfirm('确定删除 #'+row.id+' 吗？','删除确认'))return;try{await mockDel(API+'/'+row.id);toast.success('已删除');await load();}catch(e:any){toast.error(e?.message||'删除失败');}}
function exportCsv(){const head=columns.map(c=>c.label);const lines=[head.join(',')].concat(rows.value.map(r=>columns.map(c=>String(display(r,c)).replace(/,/g,' ')).join(',')));const blob=new Blob(['\ufeff'+lines.join('\n')],{type:'text/csv;charset=utf-8'});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='现金流量表.csv';a.click();}
onMounted(()=>{load();if(!isReport)loadRemote();});

function amountCol(){const c=columns.find((c:any)=>c.type==='number'&&/金额|额|amount|cost|余额|利润/i.test(c.label+c.prop))||columns.find((c:any)=>c.type==='number');return c||{prop:'id'};}
const PALETTE=['#5b8cff','#7c5cff','#0e9f8a','#ff8a3d','#e11d48','#2563eb','#0891b2','#db2777'];function legendColor(i:number){return PALETTE[i%PALETTE.length];}function hash(s:string){let h=0;for(let i=0;i<s.length;i++)h=(h*31+s.charCodeAt(i))|0;return Math.abs(h);}
function donutStyle(){const n=rows.value.length||1;let a=0;const stops:string[]=[];for(let i=0;i<Math.min(n,8);i++){const pct=100/Math.min(n,8);stops.push(legendColor(i)+' '+a+'% '+(a+pct)+'%');a+=pct;}return {background:'conic-gradient('+stops.join(',')+')'};}
</script>

<style scoped>
.u-page{padding:16px}.u-head{display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:14px}.u-kicker{font-size:11px;letter-spacing:1px;color:#5b8cff;font-weight:700;margin-bottom:4px}.u-head h2{margin:0;font-size:20px}.u-actions{display:flex;gap:8px}.u-stats{display:flex;gap:12px;margin-bottom:14px}.u-stat{flex:1;background:var(--ds-bg-soft);border-left:3px solid #5b8cff;border-radius:8px;padding:10px 14px;display:flex;flex-direction:column;gap:4px}.u-stat span{font-size:12px;color:var(--ds-text-3)}.u-stat b{font-size:20px}.u-search{display:flex;gap:8px;margin-bottom:12px;flex-wrap:wrap}.u-search input{min-width:200px}.u-pager{display:flex;justify-content:flex-end;padding:12px}.u-empty{text-align:center;color:var(--ds-text-3);padding:36px}.u-table-wrap{overflow:auto}.u-table{width:100%;border-collapse:collapse;font-size:13px}.u-table th,.u-table td{border:1px solid var(--ds-divider);padding:8px 10px;text-align:left}.u-table th{background:var(--ds-bg-soft)}.u-table-dense th,.u-table-dense td{padding:5px 8px;font-size:12px}.u-ops{white-space:nowrap}.u-form{display:grid;grid-template-columns:1fr 1fr;gap:14px}.u-field{display:flex;flex-direction:column;gap:5px;font-size:13px}.u-field i{color:var(--ds-danger);font-style:normal}.u-foot{display:flex;justify-content:flex-end;gap:8px}.u-donut-page{display:grid;grid-template-columns:320px 1fr;gap:12px}.u-donut-box{background:var(--ds-card);border-radius:10px;padding:16px;display:flex;flex-direction:column;align-items:center}.u-donut{width:180px;height:180px;border-radius:50%;position:relative;background:var(--ds-bg-soft)}.u-donut-hole{position:absolute;inset:38px;background:var(--ds-card);border-radius:50%;display:flex;flex-direction:column;align-items:center;justify-content:center}.u-donut-hole b{font-size:26px}.u-donut-hole span{font-size:12px;color:var(--ds-text-3)}.u-legend{list-style:none;padding:0;margin-top:14px;width:100%}.u-legend li{display:flex;align-items:center;gap:6px;font-size:12px;padding:3px 0}.u-legend i{width:10px;height:10px;border-radius:2px}.u-legend b{margin-left:auto}
</style>
