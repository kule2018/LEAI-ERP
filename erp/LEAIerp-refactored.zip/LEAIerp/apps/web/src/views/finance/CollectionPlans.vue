<template><RecordPage :config="page" /></template>

<script setup lang="ts">
import RecordPage from '../records/RecordPage.vue';
import type { RecordPageConfig } from '../records/records';

const page: RecordPageConfig = {
  title: '回款计划',
  resource: 'finance/collection-plans',
  schema: 'financeCollectionPlans',
  filters: ['customerName', 'dueDate', 'status'],
  required: ['planNo', 'customerName', 'dueDate', 'planAmount'],
  metrics: ['planAmount', 'receivedAmount'],
};
</script>
