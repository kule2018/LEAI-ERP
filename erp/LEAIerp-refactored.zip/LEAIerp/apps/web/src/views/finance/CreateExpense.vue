<template><CashEntryForm kind="expense" /></template>

<script setup lang="ts">
import CashEntryForm from './CashEntryForm.vue';
</script>
