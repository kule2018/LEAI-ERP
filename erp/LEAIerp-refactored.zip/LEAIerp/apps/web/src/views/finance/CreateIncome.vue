<template><CashEntryForm kind="income" /></template>

<script setup lang="ts">
import CashEntryForm from './CashEntryForm.vue';
</script>
