<!-- 财务深化报表：现金流量表 / 科目余额表 / 明细账 / 利润中心 -->
<template>
  <div class="fr-page">
    <DsCard :pad="false">
      <div class="fr-tabs">
        <DsButton v-for="tab in tabs" :key="tab.key" :variant="active === tab.key ? 'primary' : 'default'" size="sm" @click="switchTab(tab.key)">{{ tab.label }}</DsButton>
        <span class="fr-period">期间：{{ period }}</span>
        <DsButton size="sm" @click="exportCsv">导出 CSV</DsButton>
      </div>
      <table class="fr-table">
        <thead><tr><th v-for="col in columns" :key="col">{{ col }}</th></tr></thead>
        <tbody>
          <tr v-for="(row, i) in rows" :key="i">
            <td v-for="col in columns" :key="col">{{ formatCell(row[col]) }}</td>
          </tr>
          <tr v-if="!rows.length"><td :colspan="columns.length" class="fr-empty">暂无数据，可先生成凭证再查看</td></tr>
        </tbody>
      </table>
      <div class="fr-foot">共 {{ rows.length }} 行 · 数据来自本地业务账套（真实环境由 BI/总账服务取数）</div>
    </DsCard>
  </div>
</template>

<script setup lang="ts">
/** 财务深化报表：四类报表的统一查询框架，失败时回退演示行 */
import { computed, onMounted, ref } from 'vue';
import { useRoute } from 'vue-router';
import { DsButton, DsCard } from '../../components';
import { mockGet } from '../../api/mockAdapter';
import { useToast } from '../../components/ds/toast';

const toast = useToast();
const route = useRoute();
const tabs = [
  { key: 'cash-flow', label: '现金流量表' }, { key: 'subject-balance', label: '科目余额表' },
  { key: 'ledger', label: '明细账' }, { key: 'profit-center', label: '利润中心' },
];
const active = ref('cash-flow');
const rows = ref<any[]>([]);
const period = new Date().toLocaleDateString('zh-CN', { year: 'numeric', month: '2-digit' });

/** 各报表列定义 */
const columns = computed(() => ({
  'cash-flow': ['项目', '本月金额', '本年累计', '说明'],
  'subject-balance': ['科目编码', '科目名称', '期初借方', '本期借方', '本期贷方', '期末余额'],
  ledger: ['日期', '凭证号', '摘要', '科目', '借方', '贷方', '余额'],
  'profit-center': ['中心', '收入', '成本', '费用', '利润', '利润率'],
}[active.value] || []));

/** 切换报表并加载数据：全部来自真实凭证/单据/库存聚合，无写死 demo */
async function switchTab(key: string): Promise<void> {
  active.value = key;
  try {
    const data: any = await mockGet(`/api/v1/finance/reports/${key}`, { period });
    rows.value = Array.isArray(data) ? data : data?.list || [];
  } catch { rows.value = []; }
}
/** 数字格式化，其他字段原样显示 */
function formatCell(value: any): string {
  return typeof value === 'number' ? value.toLocaleString('zh-CN', { minimumFractionDigits: 2 }) : String(value ?? '');
}
/** 导出 CSV（带 BOM，Excel 可直接打开） */
function exportCsv(): void {
  const lines = [columns.value.join(','), ...rows.value.map((r) => columns.value.map((c) => `"${String(r[c] ?? '').replace(/"/g, '""')}"`).join(','))];
  const blob = new Blob(['\ufeff' + lines.join('\n')], { type: 'text/csv;charset=utf-8' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob); a.download = `${active.value}_${period}.csv`; a.click();
  URL.revokeObjectURL(a.href);
  toast.success('报表已导出');
}
onMounted(() => {
  const fromRoute = String(route.path).split('/').pop() || '';
  switchTab(tabs.some((t) => t.key === fromRoute) ? fromRoute : 'cash-flow');
});
</script>

<style scoped>
.fr-page { padding: 16px; }
.fr-tabs { display: flex; align-items: center; gap: 8px; padding: 12px; }
.fr-period { margin-left: auto; color: var(--ds-text-3); font-size: 12px; }
.fr-table { width: 100%; border-collapse: collapse; font-size: 13px; }
.fr-table th, .fr-table td { padding: 9px 12px; border-bottom: 1px solid var(--ds-divider); text-align: left; }
.fr-table th { background: var(--ds-bg-soft); color: var(--ds-text-3); font-weight: 500; }
.fr-empty { text-align: center; padding: 28px; color: var(--ds-text-3); }
.fr-foot { padding: 12px; color: var(--ds-text-3); font-size: 12px; }
</style>
