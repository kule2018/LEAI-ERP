<template><RecordPage :config="page" /></template>

<script setup lang="ts">
import RecordPage from '../records/RecordPage.vue';
import type { RecordPageConfig } from '../records/records';

const page: RecordPageConfig = {
  title: '财务仪表盘',
  resource: 'finance/dashboards',
  schema: 'financeDashboards',
  filters: ['period'],
  reportSource: '按期间查看经营与资金快照',
};
</script>
