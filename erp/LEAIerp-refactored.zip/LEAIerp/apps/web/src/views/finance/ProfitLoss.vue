<template><RecordPage :config="page" /></template>

<script setup lang="ts">
import RecordPage from '../records/RecordPage.vue';
import type { RecordPageConfig } from '../records/records';
import { f } from '../../config/schemaOverrides/types';

const page: RecordPageConfig = {
  title: '损益表',
  resource: 'finance/profit-loss',
  schema: 'financeProfitLoss',
  filters: [],
  reportSource: '根据已过账会计凭证计算',
  columns: [f('name', '损益项目'), f('amount', '金额', 'money')],
};
</script>
