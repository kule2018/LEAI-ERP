<template><RecordPage :config="page" /></template>

<script setup lang="ts">
import RecordPage from '../records/RecordPage.vue';
import type { RecordPageConfig } from '../records/records';

const page: RecordPageConfig = {
  title: '税码',
  resource: 'finance/tax-codes',
  schema: 'financeTaxCodes',
  filters: ['code', 'status'],
  required: ['code', 'name', 'rate'],
};
</script>
