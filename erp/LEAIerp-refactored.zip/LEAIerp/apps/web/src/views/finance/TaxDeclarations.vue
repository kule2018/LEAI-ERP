<template><RecordPage :config="page" /></template>

<script setup lang="ts">
import RecordPage from '../records/RecordPage.vue';
import type { RecordPageConfig } from '../records/records';

const page: RecordPageConfig = {
  title: '纳税申报',
  resource: 'finance/tax-declarations',
  schema: 'financeTaxDeclarations',
  filters: ['period', 'taxType', 'status'],
  reportSource: '查询各期间的纳税申报记录',
  metrics: ['taxAmount'],
};
</script>
