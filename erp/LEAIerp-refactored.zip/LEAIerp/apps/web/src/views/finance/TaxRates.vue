<template><RecordPage :config="page" /></template>

<script setup lang="ts">
import RecordPage from '../records/RecordPage.vue';
import type { RecordPageConfig } from '../records/records';

const page: RecordPageConfig = {
  title: '税率',
  resource: 'finance/tax-rates',
  schema: 'financeTaxRates',
  filters: ['type', 'effectiveDate'],
  required: ['name', 'rate', 'type', 'effectiveDate'],
};
</script>
