<template><RecordPage :config="page" /></template>

<script setup lang="ts">
import RecordPage from '../records/RecordPage.vue';
import type { RecordPageConfig } from '../records/records';

const page: RecordPageConfig = {
  title: '税务汇总报告',
  resource: 'finance/tax-summaries',
  schema: 'financeTaxSummaries',
  filters: ['period', 'taxType'],
  reportSource: '按期间和税种查询税务汇总',
  metrics: ['taxable', 'taxAmount'],
};
</script>
