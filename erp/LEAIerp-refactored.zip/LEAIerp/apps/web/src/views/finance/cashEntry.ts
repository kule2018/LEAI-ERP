import { computed, onMounted, reactive, ref } from 'vue';
import { useRouter } from 'vue-router';
import { pageData, pageRows, type BusinessRow } from '../../api/pageData';
import { useToast } from '../../components/ds/toast';

export function useCashEntry(kind: 'expense' | 'income') {
  const expense = kind === 'expense';
  const title = expense ? '新建支出' : '新建收入';
  const listPath = expense ? '/finance/expenses' : '/finance/incomes';
  const resource = expense ? 'expenses' : 'incomes';
  const categoryResource = expense ? 'expense-categories' : 'income-categories';
  const router = useRouter();
  const toast = useToast();
  const saving = ref(false);
  const error = ref('');
  const categories = ref<BusinessRow[]>([]);
  const form = reactive({ code: '', name: '', partner: '', bizText: '', amount: '', docDate: '', remark: '', qty: 1 });
  const partnerLabel = computed(() => expense ? '报销人' : '收入来源');

  onMounted(async () => {
    try {
      categories.value = pageRows(await pageData('GET', `/api/v1/fin/${categoryResource}`, { pageSize: 100 }));
    } catch (cause) {
      error.value = cause instanceof Error ? cause.message : '分类加载失败';
    }
  });

  async function save() {
    if (saving.value || !form.code || !form.name || !(Number(form.amount) > 0)) return;
    saving.value = true;
    error.value = '';
    try {
      await pageData('POST', `/api/v1/fin/${resource}`, { ...form, amount: String(form.amount), status: 0 });
      toast.success(expense ? '支出草稿已保存' : '收入草稿已保存');
      await router.push(listPath);
    } catch (cause) {
      error.value = cause instanceof Error ? cause.message : '草稿保存失败';
    } finally {
      saving.value = false;
    }
  }
  return { title, listPath, categories, form, partnerLabel, saving, error, save };
}
