/** 财务结算 24 个页面的独立字段、表单、状态与业务动作配置。 */
import type { SalesAction, SalesConfig, SalesField } from '../sales/salesConfigs';

const DOC = { '0': '草稿', '1': '待审批', '2': '已通过', '3': '已完成', '4': '已驳回', '9': '已作废' };
const MASTER = { '0': '停用', '1': '启用' };
const PERIOD = { '0': '未结账', '1': '已结账' };

const docActions: SalesAction[] = [
  { key: 'submit', label: '提交审批', variant: 'primary', from: [0] },
  { key: 'approve', label: '审批通过', variant: 'primary', from: [1] },
  { key: 'reject', label: '驳回', variant: 'danger', from: [1] },
  { key: 'void', label: '作废', variant: 'danger', from: [0, 1, 2] },
];
const voucherActions: SalesAction[] = [
  { key: 'submit', label: '提交复核', variant: 'primary', from: [0] },
  { key: 'post', label: '审核过账', variant: 'primary', from: [1] },
  { key: 'void', label: '红冲作废', variant: 'danger', from: [0, 1, 2] },
];
const paymentActions: SalesAction[] = [
  { key: 'submit', label: '提交', variant: 'primary', from: [0] },
  { key: 'pay', label: '确认收付', variant: 'primary', from: [1] },
  { key: 'reject', label: '驳回', variant: 'danger', from: [1] },
];
const periodActions: SalesAction[] = [
  { key: 'close', label: '期末结账', variant: 'primary', from: [0] },
  { key: 'open', label: '反结账', variant: 'warning', from: [1] },
];
const masterActions: SalesAction[] = [
  { key: 'toggle', label: '停用', variant: 'warning', from: [1] },
  { key: 'enable', label: '启用', variant: 'primary', from: [0] },
  { key: 'copy', label: '复制' },
];

const f = (prop: string, label: string, type?: SalesField['type'], required?: boolean): SalesField => ({ prop, label, type, required });
const s = (prop: string, label: string, value: any): SalesField => ({ prop, label, type: 'select', options: [{ label: value, value }] });

type Kind = 'doc' | 'master' | 'report';
interface Def {
  key: string; title: string; collection: string; layout: NonNullable<SalesConfig['layout']>;
  kind: Kind; codeLabel: string; nameLabel: string; extra: SalesField[];
  actions?: SalesAction[]; labels?: Record<string, string>;
}

const DEFS: Def[] = [
  { key: 'vouchers', title: '会计分录', collection: 'finVouchers', layout: 'ledger', kind: 'doc', codeLabel: '凭证号', nameLabel: '摘要', extra: [f('partner', '制单人'), f('productName', '会计科目'), f('amount', '借方金额', 'number', true), f('bizText', '贷方科目'), f('bizAmount', '贷方金额', 'number'), f('docDate', '凭证日期', 'date'), s('bizSelect', '凭证类型', '记账凭证')], actions: voucherActions },
  { key: 'reports', title: '财务报表', collection: 'finReports', layout: 'analytics', kind: 'report', codeLabel: '报表编号', nameLabel: '报表名称', extra: [f('partner', '编制部门'), f('amount', '本期金额', 'number'), f('bizText', '报表类型'), f('bizDate', '报告期', 'date')] },
  { key: 'subjects', title: '会计科目表', collection: 'finSubjects', layout: 'list', kind: 'master', codeLabel: '科目编码', nameLabel: '科目名称', extra: [f('partner', '科目类别'), f('productName', '上级科目'), f('bizText', '余额方向'), f('bizAmount', '期初余额', 'number')], actions: masterActions },
  { key: 'accounts', title: '账户列表', collection: 'finAccounts', layout: 'list', kind: 'master', codeLabel: '账户编号', nameLabel: '账户名称', extra: [f('partner', '开户行'), f('bizText', '银行账号'), f('bizAmount', '账户余额', 'number'), f('bizSelect', '账户类型')], actions: masterActions },
  { key: 'transfers', title: '资金转账', collection: 'finTransfers', layout: 'workflow', kind: 'doc', codeLabel: '转账单号', nameLabel: '转账用途', extra: [f('partner', '收款账户'), f('bizText', '付款账户'), f('amount', '转账金额', 'number', true), f('docDate', '转账日期', 'date'), s('bizSelect', '转账类型', '内部转账')], actions: paymentActions },
  { key: 'expenses', title: '清单费用', collection: 'finExpenses', layout: 'workflow', kind: 'doc', codeLabel: '费用单号', nameLabel: '费用事项', extra: [f('partner', '报销人'), f('bizText', '费用类别'), f('qty', '单据张数', 'number'), f('amount', '报销金额', 'number', true), f('docDate', '发生日期', 'date')], actions: docActions },
  { key: 'incomes', title: '收入列表', collection: 'finIncomes', layout: 'workflow', kind: 'doc', codeLabel: '收入单号', nameLabel: '收入项目', extra: [f('partner', '付款客户'), f('bizText', '收入类别'), f('amount', '收入金额', 'number', true), f('docDate', '确认日期', 'date')], actions: docActions },
  { key: 'expense-categories', title: '费用类别', collection: 'finExpenseCategories', layout: 'list', kind: 'master', codeLabel: '类别编码', nameLabel: '费用类别', extra: [f('partner', '归口部门'), f('bizText', '对应科目'), f('bizAmount', '年度预算', 'number')], actions: masterActions },
  { key: 'income-categories', title: '收入类别', collection: 'finIncomeCategories', layout: 'list', kind: 'master', codeLabel: '类别编码', nameLabel: '收入类别', extra: [f('partner', '归口部门'), f('bizText', '对应科目'), f('bizAmount', '年度目标', 'number')], actions: masterActions },
  { key: 'receivables', title: '应收账单', collection: 'finReceivables', layout: 'workflow', kind: 'doc', codeLabel: '账单号', nameLabel: '应收说明', extra: [f('partner', '客户'), f('amount', '应收金额', 'number', true), f('bizAmount', '未收金额', 'number'), f('bizDate', '到期日', 'date'), f('bizText', '币种'), f('docDate', '账单日期', 'date')], actions: docActions },
  { key: 'payments-in', title: '收款单', collection: 'finPaymentsIn', layout: 'ledger', kind: 'doc', codeLabel: '收款单号', nameLabel: '收款说明', extra: [f('partner', '付款客户'), f('amount', '收款金额', 'number', true), f('bizText', '结算方式'), f('docDate', '收款日期', 'date')], actions: paymentActions },
  { key: 'payables', title: '应付账单', collection: 'finPayables', layout: 'workflow', kind: 'doc', codeLabel: '应付单号', nameLabel: '应付说明', extra: [f('partner', '供应商'), f('amount', '应付金额', 'number', true), f('bizAmount', '未付金额', 'number'), f('bizDate', '到期日', 'date'), f('bizText', '币种'), f('docDate', '账单日期', 'date')], actions: docActions },
  { key: 'payments-out', title: '付款单', collection: 'finPaymentsOut', layout: 'ledger', kind: 'doc', codeLabel: '付款单号', nameLabel: '付款说明', extra: [f('partner', '收款供应商'), f('amount', '付款金额', 'number', true), f('bizText', '结算方式'), f('docDate', '付款日期', 'date')], actions: paymentActions },
  { key: 'aging', title: '账龄分析', collection: 'finAging', layout: 'analytics', kind: 'report', codeLabel: '分析编号', nameLabel: '账龄区间', extra: [f('partner', '客户'), f('amount', '应收金额', 'number'), f('bizText', '逾期天数'), f('bizDate', '分析基准日', 'date')] },
  { key: 'assets', title: '固定资产', collection: 'finAssets', layout: 'equipment', kind: 'master', codeLabel: '资产编号', nameLabel: '资产名称', extra: [f('partner', '使用部门'), f('qty', '资产数量', 'number'), f('amount', '资产原值', 'number'), f('bizText', '资产类别'), f('bizDate', '购置日期', 'date')], actions: masterActions },
  { key: 'depreciations', title: '折旧', collection: 'finDepreciations', layout: 'workflow', kind: 'doc', codeLabel: '折旧单号', nameLabel: '资产名称', extra: [f('partner', '使用部门'), f('amount', '折旧金额', 'number', true), f('bizText', '折旧方法'), f('bizDate', '折旧月份', 'date')], actions: docActions },
  { key: 'invoices', title: '发票登记', collection: 'finInvoices', layout: 'workflow', kind: 'doc', codeLabel: '发票号码', nameLabel: '开票项目', extra: [f('partner', '购方名称'), f('amount', '价税合计', 'number', true), f('bizAmount', '税额', 'number'), f('bizText', '发票类型'), f('docDate', '开票日期', 'date')], actions: docActions },
  { key: 'cash-flow', title: '现金流量表', collection: 'finCashFlow', layout: 'analytics', kind: 'report', codeLabel: '项目编码', nameLabel: '现金流项目', extra: [f('partner', '归口部门'), f('amount', '本期金额', 'number'), f('bizText', '现金流分类'), f('bizDate', '报表期间', 'date')] },
  { key: 'subject-balances', title: '科目余额表', collection: 'finSubjectBalances', layout: 'analytics', kind: 'report', codeLabel: '科目编码', nameLabel: '科目名称', extra: [f('partner', '科目类别'), f('amount', '借方余额', 'number'), f('bizAmount', '贷方余额', 'number'), f('bizText', '余额方向'), f('bizDate', '余额日期', 'date')] },
  { key: 'ledger', title: '明细账', collection: 'finLedger', layout: 'ledger', kind: 'report', codeLabel: '流水号', nameLabel: '摘要', extra: [f('productName', '会计科目'), f('amount', '发生额', 'number'), f('bizAmount', '余额', 'number'), f('bizText', '分录方向'), f('docDate', '记账日期', 'date')] },
  { key: 'profit-centers', title: '利润中心', collection: 'finProfitCenters', layout: 'analytics', kind: 'master', codeLabel: '中心编码', nameLabel: '利润中心', extra: [f('partner', '负责人'), f('amount', '本期利润', 'number'), f('bizText', '核算范围'), f('bizDate', '核算期间', 'date')], actions: masterActions },
  { key: 'trial-balance', title: '试算平衡表', collection: 'finTrialBalance', layout: 'analytics', kind: 'report', codeLabel: '科目编码', nameLabel: '科目名称', extra: [f('partner', '编制部门'), f('amount', '借方发生额', 'number'), f('bizAmount', '贷方发生额', 'number'), f('bizText', '余额方向'), f('bizDate', '平衡日期', 'date')] },
  { key: 'periods', title: '期末结账', collection: 'finPeriods', layout: 'calendar', kind: 'master', codeLabel: '期间编码', nameLabel: '会计期间', extra: [f('partner', '结账部门'), f('bizText', '期间名称'), f('bizDate', '结账日期', 'date')], actions: periodActions, labels: PERIOD },
  { key: 'costs', title: '成本核算', collection: 'finCosts', layout: 'analytics', kind: 'doc', codeLabel: '成本单号', nameLabel: '核算对象', extra: [f('productName', '核算产品'), f('qty', '完工数量', 'number'), f('amount', '成本金额', 'number', true), f('bizText', '成本构成'), f('bizDate', '核算期间', 'date')], actions: docActions },
];

function build(d: Def): SalesConfig {
  const base: SalesField[] = [f('code', d.codeLabel, undefined, true), f('name', d.nameLabel, undefined, true)];
  const labels = d.labels || (d.kind === 'doc' ? DOC : MASTER);
  const status: SalesField = {
    prop: 'status', label: '状态', type: 'select',
    options: Object.entries(labels).map(([k, v]) => ({ label: v, value: Number(k) })),
  };
  const isReport = d.kind === 'report';
  return {
    title: d.title,
    api: `/api/v1/fin/${d.key}`,
    collection: d.collection,
    columns: [...base, ...d.extra, ...(isReport ? [] : [status])],
    fields: [...base, ...d.extra, f('remark', '备注', 'textarea'), ...(isReport ? [] : [status])],
    statusField: 'status',
    statusLabels: labels,
    actions: isReport ? [] : (d.actions || masterActions),
    readOnly: isReport,
    layout: d.layout,
    defaults: () => ({ status: d.kind === 'doc' ? 0 : 1, qty: 0, amount: 0, bizAmount: 0 }),
  };
}

export const FINANCE_CONFIGS: Record<string, SalesConfig> = Object.fromEntries(DEFS.map((d) => [d.key, build(d)]));
export function financeConfigFor(key: string): SalesConfig {
  const c = FINANCE_CONFIGS[key];
  if (!c) throw new Error(`未知财务页面配置：${key}`);
  return c;
}
