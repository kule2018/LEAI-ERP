<template>
  <div class="entity-page">
    <div class="entity-search">
      <DsButton size="sm" variant="primary" @click="loadAll">刷新报表</DsButton>
      <DsButton size="sm" @click="runAi">🤖 AI 报表解读</DsButton>
      <DsButton size="sm" @click="onClose">期末结账({{ curPeriod }})</DsButton>
    </div>
    <div class="report-grid">
      <div class="entity-table"><b>试算平衡表</b>
        <table class="ds-table" style="margin-top: 8px">
          <thead><tr><th>科目</th><th>借方发生</th><th>贷方发生</th></tr></thead>
          <tbody><tr v-for="(r, i) in trial" :key="i"><td>{{ r.subjectName }}</td><td>{{ r.debit }}</td><td>{{ r.credit }}</td></tr></tbody>
          <tfoot><tr><td>合计</td><td>{{ trialTotals.debit }}</td><td>{{ trialTotals.credit }}</td></tr></tfoot>
        </table>
      </div>
      <div class="entity-table"><b>应收账龄</b>
        <table class="ds-table" style="margin-top: 8px">
          <thead><tr><th>客户</th><th>未结金额</th><th>未逾期</th><th>1-30天</th><th>31-90天</th><th>90天以上</th></tr></thead>
          <tbody><tr v-for="(r, i) in aging" :key="i"><td>{{ r.customerName }}</td><td>{{ r.unpaid }}</td><td>{{ r.notDue }}</td><td>{{ r.d1_30 }}</td><td>{{ r.d31_90 }}</td><td>{{ r.d90 }}</td></tr></tbody>
        </table>
      </div>
    </div>
    <div class="report-grid" style="margin-top: 12px">
      <div class="entity-table"><b>损益表</b>
        <table class="ds-table" style="margin-top: 8px">
          <thead><tr><th>科目</th><th>金额（贷-借）</th></tr></thead>
          <tbody><tr v-for="(r, i) in pl" :key="i"><td>{{ r.item }}</td><td>{{ r.amount }}</td></tr></tbody>
        </table>
      </div>
      <div class="entity-table"><b>应付账单</b>
        <table class="ds-table" style="margin-top: 8px">
          <thead><tr><th>供应商</th><th>金额</th><th>已付</th><th>到期日</th></tr></thead>
          <tbody><tr v-for="(r, i) in payables" :key="i"><td>{{ r.supplierName }}</td><td>{{ r.amount }}</td><td>{{ r.paidAmount }}</td><td>{{ r.dueDate }}</td></tr></tbody>
        </table>
      </div>
    </div>
    <div v-if="aiText" class="entity-table" style="margin-top: 12px"><b>🤖 AI 解读</b><pre class="ai-text">{{ aiText }}</pre></div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue';
import { DsButton } from '../../components';
import { useToast } from '../../components/ds/toast';
import { confirm as uiConfirm } from '../../components/ds/useConfirm';
import { financeApi, aiApi } from '../../api';

const toast = useToast();
const trial = ref<any[]>([]); const aging = ref<any[]>([]); const pl = ref<any[]>([]); const payables = ref<any[]>([]);
const aiText = ref('');
const curPeriod = new Date().toISOString().slice(0, 7);
const trialTotals = computed(() => trial.value.reduce((acc, r) => {
  acc.debit += Number(r.debit || 0);
  acc.credit += Number(r.credit || 0);
  return acc;
}, { debit: 0, credit: 0 }));

async function loadAll() {
  const [t, a, p, y] = await Promise.allSettled([financeApi.trialBalance(), financeApi.receivableAging(), financeApi.profitLoss(), financeApi.payables()]);
  if (t.status === 'fulfilled') trial.value = (t.value as any) || [];
  if (a.status === 'fulfilled') aging.value = (a.value as any) || [];
  if (p.status === 'fulfilled') pl.value = (p.value as any) || [];
  if (y.status === 'fulfilled') payables.value = (y.value as any) || [];
}
async function runAi() {
  // 指标 key 与 AI 网关约定对齐，并带入真实汇总数据而非条数
  const receivable = aging.value.reduce((s, r) => s + Number(r.unpaid || 0), 0);
  const profit = pl.value.find((x) => x.item === '净利润')?.amount || 0;
  const res: any = await aiApi.reportInsight({ 今日销售: profit, 应收未收: receivable, 库存预警: trial.value.length });
  aiText.value = res.text || JSON.stringify(res);
}
async function onClose() {
  if (!await uiConfirm(`结账期间 ${curPeriod}？结账后不可录凭证`, '期末结账确认')) return;
  await financeApi.closePeriod(curPeriod);
  toast.success('已结账（反结账需 system:config:edit 权限）');
}
onMounted(loadAll);
</script>

<style scoped>
.report-grid { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 12px; }
</style>