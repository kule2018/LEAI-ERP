<template>
  <div class="entity-page">
    <div class="entity-search">
      <input v-model="q.keyword" class="ds-input entity-search__input" placeholder="凭证号/摘要" />
      <DsButton size="sm" variant="primary" @click="load">查询</DsButton>
      <span class="entity-search__spacer" />
      <DsButton v-perm="'finance:voucher:edit'" size="sm" @click="openForm">新建凭证</DsButton>
    </div>
    <div class="entity-table">
      <div v-if="loading" class="entity-empty-inline">加载中…</div>
      <table class="ds-table">
        <thead><tr><th></th><th>凭证号</th><th>日期</th><th>来源</th><th>借方合计</th><th>状态</th><th>操作</th></tr></thead>
        <tbody>
          <template v-for="(s, i) in list" :key="s.id ?? i">
            <tr>
              <td><DsButton variant="text" size="sm" @click="toggleExpand(s.id)">{{ expandedIds.includes(s.id) ? '−' : '+' }}</DsButton></td>
              <td>{{ s.voucherNo }}</td>
              <td>{{ s.voucherDate }}</td>
              <td>{{ s.sourceType }}</td>
              <td>{{ s.totalDebit }}</td>
              <td><DsTag :color="s.status === 1 ? 'success' : (s.status === 2 ? 'danger' : 'neutral')" size="sm">{{ ['草稿', '已过账', '作废'][s.status] }}</DsTag></td>
              <td>
                <DsButton v-if="s.status === 0" v-perm="'finance:voucher:edit'" variant="text" size="sm" @click="onPost(s)">过账</DsButton>
                <DsButton v-if="s.status !== 2" v-perm="'finance:voucher:edit'" variant="danger" size="sm" @click="onVoid(s)">作废</DsButton>
                <DsButton v-perm="'finance:voucher:ai'" variant="text" size="sm" @click="onAi(s)">🤖 科目建议</DsButton>
              </td>
            </tr>
            <tr v-if="expandedIds.includes(s.id)">
              <td colspan="7">
                <table class="ds-table" style="margin: 8px">
                  <thead><tr><th>摘要</th><th>科目</th><th>借方</th><th>贷方</th></tr></thead>
                  <tbody>
                    <tr v-for="(e, ei) in (s.entries || [])" :key="ei">
                      <td>{{ e.summary }}</td><td>{{ e.subjectName }}</td><td>{{ e.debit }}</td><td>{{ e.credit }}</td>
                    </tr>
                  </tbody>
                </table>
              </td>
            </tr>
          </template>
        </tbody>
      </table>
      <div class="entity-pager">
        <DsPagination v-model:current-page="page" :page-size="pageSize" :total="total" layout="total, prev, pager, next" @change="load" />
      </div>
    </div>

    <DsModal v-model="formVisible" title="新建凭证（借贷必须平衡）" :width="700">
      <div class="entity-search">
        <label>日期<DsDatePicker v-model="form.voucherDate" /></label>
        <label>摘要<input v-model="form.summary" class="ds-input" style="width: 240px" /></label>
      </div>
      <table class="ds-table">
        <thead><tr><th>科目</th><th>借方</th><th>贷方</th><th></th></tr></thead>
        <tbody>
          <tr v-for="(row, i) in form.entries" :key="i">
            <td><DsSelect v-model="row.subjectId" :options="subjectOptions" filterable size="sm" /></td>
            <td><input v-model="row.debit" class="ds-input" type="number" /></td>
            <td><input v-model="row.credit" class="ds-input" type="number" /></td>
            <td><DsButton variant="text" size="sm" style="color: var(--ds-danger)" @click="form.entries.splice(i, 1)">删</DsButton></td>
          </tr>
        </tbody>
      </table>
      <DsButton size="sm" style="margin-top: 8px" @click="form.entries.push({ subjectId: null, debit: '0', credit: '0' })">添加分录</DsButton>
      <div style="margin-top: 8px">借方合计：{{ sum('debit') }} / 贷方合计：{{ sum('credit') }}</div>
      <template #footer><div class="entity-modal-foot"><DsButton @click="formVisible = false">取消</DsButton><DsButton variant="primary" @click="onSave">保存</DsButton></div></template>
    </DsModal>
  </div>
</template>

<script setup lang="ts">
import { reactive, ref, computed, onMounted } from 'vue';
import { DsButton, DsModal, DsPagination, DsSelect, DsTag } from '../../components';
import { useToast } from '../../components/ds/toast';
import { confirm as uiConfirm } from '../../components/ds/useConfirm';
import Decimal from 'decimal.js';
import { financeApi, aiApi } from '../../api';

const toast = useToast();
const loading = ref(false);
const list = ref<any[]>([]);
const total = ref(0);
const page = ref(1);
const pageSize = ref(10);
const subjects = ref<any[]>([]);
const q = reactive<{ keyword?: string }>({});
const formVisible = ref(false);
const form = reactive<any>({ voucherDate: new Date().toISOString().slice(0, 10), summary: '', entries: [{ subjectId: null, debit: '0', credit: '0' }, { subjectId: null, debit: '0', credit: '0' }] });
const sum = (k: string) => form.entries.reduce((a: Decimal.Value, r: any) => new Decimal(a).plus(r[k] || 0).toString(), '0');
const subjectOptions = computed(() => subjects.value.map((a: any) => ({ label: `${a.code} ${a.name}`, value: a.id })));
const expandedIds = ref<any[]>([]);
function toggleExpand(id: any): void {
  const i = expandedIds.value.indexOf(id);
  if (i >= 0) expandedIds.value.splice(i, 1); else expandedIds.value.push(id);
}

async function load() {
  loading.value = true;
  try { const d: any = await financeApi.vouchers({ ...q, page: page.value, pageSize: pageSize.value }); list.value = d.list || d || []; total.value = d.total || 0; }
  catch { list.value = []; } finally { loading.value = false; }
}
/** 打开新建凭证：每次重置为空表单，避免沿用上一次的分录造成误记账 */
function openForm() {
  form.voucherDate = new Date().toISOString().slice(0, 10);
  form.summary = '';
  form.entries = [{ subjectId: null, debit: '0', credit: '0' }, { subjectId: null, debit: '0', credit: '0' }];
  formVisible.value = true;
}
async function onSave() {
  const entries = form.entries.filter((e: any) => e.subjectId);
  const debit = Number(sum('debit')), credit = Number(sum('credit'));
  if (Math.abs(debit - credit) > 0.005) { toast.error(`借贷不平衡：借 ${debit.toFixed(2)} / 贷 ${credit.toFixed(2)}`); return; }
  try {
    await financeApi.saveVoucher({ ...form, entries });
    toast.success('凭证已保存（草稿）'); formVisible.value = false; load();
  } catch (e: any) { toast.error(e?.message || '保存失败'); }
}
async function onPost(row: any) {
  try { await financeApi.postVoucher(row.id); toast.success('已过账'); load(); }
  catch (e: any) { toast.error(e?.message || '过账失败'); }
}
/** 作废凭证（软删除）：仅草稿可作废，已过账凭证后端会拒绝并要求先红冲 */
async function onVoid(row: any) {
  if (!await uiConfirm(`确定作废凭证 ${row.voucherNo || '#' + row.id}？记录将保留可追溯，但不可再过账。`, '凭证作废确认')) return;
  try { await financeApi.voidVoucher(row.id); toast.success('已作废（记录保留可追溯）'); load(); }
  catch (e: any) { toast.error(e?.message || '作废失败'); }
}
async function onAi(row: any) {
  try {
    const res: any = await aiApi.subjectMatch(row.summary || '');
    toast.info(`AI 建议科目：${res.code || res.subjectCode || res.name || JSON.stringify(res)}`);
  } catch (e: any) { toast.error(e?.message || '科目建议暂不可用'); }
}
onMounted(async () => { subjects.value = (await financeApi.subjects().catch(() => [])) as any; load(); });
</script>