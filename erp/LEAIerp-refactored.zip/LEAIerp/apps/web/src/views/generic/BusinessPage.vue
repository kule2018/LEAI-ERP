<!--
 * 通用业务功能页（BusinessPage）
 * ---------------------------------------------------------------------------
 * 用途：承载「增删改查 + 状态机 + 动作联动 + 审计留痕 + 方案设置 + 统计卡片」
 *       的统一业务骨架，并通过 pageProfiles 画像让每个页面拥有**专属**的
 *       页面说明、统计口径、动作流程与业务提示，避免四个模块页面千篇一律。
 *
 * 渲染规则：
 *   1. 传入 profile-key 时：优先使用画像的动作/统计/说明/主题色；
 *   2. 未传画像时：退回 businessFlows 按集合名推导的通用流程；
 *   3. 所有动作经 /_biz/action 交给 Mock 后端执行真实副作用与审计。
-->
<template>
  <div class="biz-page" :style="headerVars">
    <!-- 页面头部：明确本页业务定位，解决「页面内容乱、不知道干嘛」的问题 -->
    <div v-if="profile" class="biz-header">
      <div class="biz-header__main">
        <span class="biz-header__icon">{{ profile.icon }}</span>
        <div class="biz-header__text">
          <h2>{{ profile.title }}</h2>
          <p>{{ profile.subtitle }}</p>
        </div>
      </div>
      <div v-if="profile.tips.length" class="biz-header__tips">
        <span v-for="(tip, i) in profile.tips" :key="i" class="biz-tip">{{ tip }}</span>
      </div>
    </div>

    <!-- 统计卡片：由画像口径或真实数据计算，而非写死的「当前页/每页条数/本地演示」 -->
    <div class="biz-stats">
      <div class="biz-stat" v-for="s in displayStats" :key="s.label">
        <span>{{ s.label }}</span>
        <b :class="s.tone">{{ s.value }}</b>
      </div>
    </div>

    <!-- 筛选区：关键字 + 状态 + 业务方案入口 -->
    <DsCard :pad="false">
      <div class="biz-search">
        <input v-model="keyword" class="ds-input biz-search__input" :placeholder="`搜索${title}关键字 / 编码 / 单号`" @keyup.enter="reload" />
        <select v-if="statusMeta" v-model="statusFilter" class="ds-select biz-search__select">
          <option value="">全部状态</option>
          <option v-for="(label, value) in statusMeta.labels" :key="value" :value="value">{{ label }}</option>
        </select>
        <DsButton variant="primary" size="sm" @click="reload">查询</DsButton>
        <DsButton size="sm" @click="resetQuery">重置</DsButton>
        <span class="biz-search__spacer" />
        <DsButton v-if="hasBatchable" size="sm" :disabled="!selected.length" @click="batchExecute">批量执行（{{ selected.length }}）</DsButton>
        <DsButton size="sm" @click="openImport">导入</DsButton>
        <DsButton size="sm" @click="exportCsv">导出</DsButton>
        <DsButton size="sm" @click="printPage">打印</DsButton>
        <DsButton variant="primary" size="sm" @click="openForm()">新建{{ title }}</DsButton>
      </div>
    </DsCard>

    <!-- 专属功能区：按页面画像渲染不同的主体界面（看板/时间线/树/配置器等） -->
    <DsCard v-if="profile?.feature" :pad="false" class="biz-gap">
      <div class="biz-feature-head">
        <span class="biz-feature-head__icon">{{ profile.icon }}</span>
        <div>
          <b>{{ profile.title }} · 业务视图</b>
          <small>以下为真实业务数据的专属视图，可直接查看与操作</small>
        </div>
      </div>
      <PageFeature :type="profile.feature.type" :title="profile.title" :rows="rows" :config="profile.feature.config" />
    </DsCard>

    <!-- 列表：选择 + 状态标签 + 状态机动作 + 内联编辑（可通过业务视图收起） -->
    <DsCard :pad="false" class="biz-gap">
      <div class="biz-table" v-loading="loading">
        <table class="ds-table">
          <thead>
            <tr>
              <th style="width:40px"><input type="checkbox" :checked="allChecked" @change="toggleAll(($event.target as HTMLInputElement).checked)" /></th>
              <th v-for="c in fields" :key="c.prop" :style="c.width ? { width: c.width + 'px' } : {}">{{ c.label }}</th>
              <th style="width:300px">操作</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="r in pagedRows" :key="r.id">
              <td><input type="checkbox" :checked="selected.includes(r)" @change="toggleRow(r, ($event.target as HTMLInputElement).checked)" /></td>
              <td v-for="c in fields" :key="c.prop" @dblclick="startInline(r, c)" :title="c.type === 'textarea' ? '双击可编辑' : ''">
                <input v-if="inline?.id === r.id && inline?.prop === c.prop" v-model="inline.value" class="ds-input biz-inline" autofocus @keyup.enter="commitInline(r, c)" @blur="commitInline(r, c)" />
                <DsTag v-else-if="c.prop === statusField" :color="statusColor(r[c.prop])" size="sm">{{ statusLabel(r[c.prop]) }}</DsTag>
                <span v-else>{{ formatCell(r, c) }}</span>
              </td>
              <td>
                <div class="biz-row-actions">
                  <DsButton variant="text" size="sm" @click="openDetail(r)">查看</DsButton>
                  <DsButton v-for="a in availableActions(r)" :key="a.key" variant="text" size="sm" :class="actionClass(a)" @click="runAction(r, a)">{{ actionLabel(a) }}</DsButton>
                  <DsButton variant="text" size="sm" @click="openForm(r)">编辑</DsButton>
                  <DsButton variant="text" size="sm" class="biz-act-danger" @click="removeRow(r)">删除</DsButton>
                </div>
              </td>
            </tr>
            <tr v-if="!loading && !pagedRows.length"><td :colspan="fields.length + 2" class="biz-empty">暂无{{ title }}数据，点击「新建{{ title }}」开始</td></tr>
            <tr v-if="loading"><td :colspan="fields.length + 2" class="biz-empty">正在加载{{ title }}…</td></tr>
          </tbody>
        </table>
      </div>
      <div class="biz-pager">
        <span>共 {{ filteredRows.length }} 条</span>
        <DsPagination v-model:current-page="page" :page-size="pageSize" :total="filteredRows.length" />
      </div>
    </DsCard>

    <!-- 新增/编辑表单：按字段类型渲染，必填校验 -->
    <DsModal v-model="formVisible" :title="editing?.id ? `编辑${title}` : `新建${title}`" :width="640">
      <div class="biz-form">
        <label v-for="c in formFields" :key="c.prop" class="biz-field">
          <span>{{ c.label }}<em v-if="requiredFields.includes(c.prop)">*</em></span>
          <textarea v-if="c.type === 'textarea'" v-model="form[c.prop]" class="ds-input" rows="3" />
          <select v-else-if="c.options?.length" v-model="form[c.prop]" class="ds-select">
            <option value="">请选择</option>
            <option v-for="o in c.options" :key="o.value" :value="o.value">{{ o.label }}</option>
          </select>
          <input v-else-if="c.type === 'switch'" type="checkbox" v-model="form[c.prop]" />
          <input v-else v-model="form[c.prop]" class="ds-input" :type="['number','money'].includes(c.type) ? 'number' : c.type === 'date' ? 'date' : 'text'" />
        </label>
      </div>
      <template #footer>
        <div class="biz-modal-foot">
          <DsButton @click="formVisible = false">取消</DsButton>
          <DsButton variant="primary" :loading="saving" @click="save">保存</DsButton>
        </div>
      </template>
    </DsModal>

    <!-- 详情抽屉：基本信息 + 状态流转轨迹（审计） + 关联单据 -->
    <DsDrawer v-model="detailVisible" :title="`${title}详情`" :size="520">
      <div v-if="detail" class="biz-detail">
        <div class="biz-detail__section">
          <h4>基本信息</h4>
          <div v-for="c in fields" :key="c.prop" class="biz-detail__row">
            <span>{{ c.label }}</span>
            <b>{{ formatCell(detail, c) }}</b>
          </div>
        </div>
        <div class="biz-detail__section">
          <h4>状态流转与操作留痕</h4>
          <div v-if="auditTrail.length" class="biz-timeline">
            <div v-for="log in auditTrail" :key="log.id" class="biz-timeline__item">
              <b>{{ log.action }}</b><span>{{ log.detail }}</span><small>{{ log.createdAt }} · {{ log.operator }}</small>
            </div>
          </div>
          <div v-else class="biz-muted">暂无操作记录（执行任一动作后自动生成）</div>
        </div>
        <div class="biz-detail__section">
          <h4>关联单据溯源</h4>
          <div class="biz-lineage">
            <span v-for="(node, i) in lineage" :key="node.label" :class="{ active: i <= lineageIndex }" @click="goto(node.path)">{{ node.label }}</span>
          </div>
        </div>
      </div>
    </DsDrawer>

    <!-- 导入弹窗：粘贴 Excel/CSV 文本批量导入 -->
    <DsModal v-model="importVisible" :title="`导入${title}`" :width="560">
      <p class="biz-muted">每行一条，列顺序与表格一致，用 Tab 或逗号分隔。首行为表头时会自动跳过。</p>
      <textarea v-model="importText" class="ds-input" rows="10" :placeholder="importPlaceholder"></textarea>
      <template #footer>
        <div class="biz-modal-foot">
          <DsButton @click="importVisible = false">取消</DsButton>
          <DsButton variant="primary" @click="doImport">确认导入</DsButton>
        </div>
      </template>
    </DsModal>
  </div>
</template>

<script setup lang="ts">
import { computed, onMounted, reactive, ref } from 'vue';
import { useRoute, useRouter } from 'vue-router';
import { DsButton, DsCard, DsDrawer, DsModal, DsPagination, DsTag } from '../../components';
import { useToast } from '../../components/ds/toast';
import { confirm as uiConfirm } from '../../components/ds/useConfirm';
import { mockGet, mockPost, mockPatch, mockDel } from '../../api/mockAdapter';
import { buildFlow, canonicalState, type BizAction, type BizFlow } from '../../config/businessFlows';
import { getPageProfile, type PageProfile, type ProfileAction } from '../../config/pageProfiles';
import PageFeature from '../../components/ds/PageFeature.vue';
import { MODULE_FLOWS } from '../../config/moduleFlows';

/** 组件入参 */
const props = withDefaults(defineProps<{
  /** 接口路径，如 /api/v1/hr/leaves */
  api: string;
  /** 页面标题 */
  title: string;
  /** 页面画像标识（决定专属业务功能） */
  profileKey?: string;
  /** 业务流标识：同一集合下不同页面（公司/部门）用不同流配置 */
  flowKey?: string;
  /** 数据范围过滤：共用集合时按字段隔离页面数据 */
  scope?: { field: string; value: string | number } | null;
  /** 表格/表单字段（可选；不传则从实体 Schema 注册表加载） */
  fields?: any[];
  /** 首次进入的种子数据（可选；不传则从实体 Schema 注册表加载） */
  seed?: any[];
}>(), { fields: () => [], seed: () => [], profileKey: '', flowKey: '', scope: null });

const route = useRoute();
const router = useRouter();
const toast = useToast();

/** 从接口路径推导集合名，与 mockAdapter.collectionOf 保持一致 */
const collection = computed(() => {
  const seg = props.api.replace(/^\/api\/v1\//, '').split('/').filter(Boolean);
  return seg.map((s, i) => i === 0 ? s : s.replace(/(^|-)([a-z])/g, (_, __, c) => c.toUpperCase())).join('');
});

/**
 * 财务结算 / 协同办公 / 人事行政的页面画像。
 * 这三个模块使用 moduleFlows 注册表生成「专属说明 + 专属动作 + 专属统计」，
 * 与商城/打印/AI/系统中手写的 pageProfiles 共用同一套渲染骨架。
 */
const moduleProfile = computed<PageProfile | undefined>(() => {
  const key = props.flowKey || props.profileKey || collection.value;
  const cfg = MODULE_FLOWS[key];
  if (!cfg) return undefined;
  const prefix = collection.value.replace(/[A-Z].*$/, '').toLowerCase();
  const meta = prefix === 'finance'
    ? { module: 'finance' as const, icon: '💰', accent: '#2f7de1', tips: ['终态动作会写入业务台账与审计日志'] }
    : prefix === 'collab' || key.startsWith('aiRag')
      ? { module: 'collab' as const, icon: '📌', accent: '#7c5cff', tips: ['状态流转后会向相关成员推送通知'] }
      : { module: 'hr' as const, icon: '👤', accent: '#20a0a0', tips: ['人事变动会同步考勤与薪资基准'] };
  return {
    key,
    ...meta,
    title: props.title,
    subtitle: cfg.purpose,
    category: cfg.category,
    stats: [],
    actions: cfg.actions.map((act) => ({
      key: act.key,
      label: act.label,
      icon: act.variant === 'danger' ? '🚫' : act.variant === 'primary' ? '▶️' : '•',
      variant: act.variant === 'danger' ? 'danger' : act.variant === 'primary' ? 'primary' : 'default',
      from: act.from,
      to: act.to,
      confirm: act.confirm,
      batchable: act.from.length === 0,
      effect: cfg.effects?.length ? `将写入：${cfg.effects.join('、')}` : undefined,
    })),
    tips: meta.tips,
  };
});

/** 页面画像：手写真画像优先，其次模块业务流画像 */
const profile = computed<PageProfile | undefined>(() => getPageProfile(props.profileKey) || moduleProfile.value);
const headerVars = computed(() => ({ '--biz-accent': profile.value?.accent || 'var(--ds-brand)' } as Record<string, string>));

/** 表格字段与种子：优先用入参，否则从实体 Schema 注册表加载 */
const activeFields = ref<any[]>(props.fields.slice());
const activeSeed = ref<any[]>(props.seed.slice());
const fields = computed(() => activeFields.value);

/** 业务流配置：模块专属流优先，未配置时按集合名通用推断 */
const flow = ref<BizFlow>(buildFlow(collection.value, props.title, props.api, activeFields.value, props.flowKey));
const statusMeta = computed(() => flow.value.status);
const statusField = computed(() => statusMeta.value?.field
  || activeFields.value.find((c: any) => c.options?.length && /status|state|状态|阶段|stage/i.test(`${c.prop}${c.label}`))?.prop
  || '');
const formFields = computed(() => activeFields.value.filter((c: any) => c.form !== false && c.prop !== 'id'));
const requiredFields = computed(() => formFields.value.filter((c: any) => /no$|name$|code$|title$|name|标题|名称|单号/.test(c.prop)).slice(0, 2).map((c: any) => c.prop));

const rows = ref<any[]>([]);
const keyword = ref('');
const statusFilter = ref('');
const page = ref(1);
const pageSize = 10;
const loading = ref(false);
const saving = ref(false);
const selected = ref<any[]>([]);
const auditTrail = ref<any[]>([]);

const formVisible = ref(false);
const editing = ref<any>(null);
const form = reactive<Record<string, any>>({});
const detailVisible = ref(false);
const detail = ref<any>(null);
const importVisible = ref(false);
const importText = ref('');
const inline = ref<{ id: any; prop: string; value: any } | null>(null);

/** 状态标签颜色 */
type DsTagColor = 'brand' | 'success' | 'warning' | 'danger' | 'neutral';
function statusColor(v: any): DsTagColor {
  const c = canonicalState(statusMeta.value?.labels[String(v)] || String(v));
  return (({ done: 'success', approved: 'success', pending: 'warning', draft: 'neutral', rejected: 'danger', void: 'danger' }) as Record<string, DsTagColor>)[c] || 'brand';
}
function statusLabel(v: any): string { return statusMeta.value?.labels[String(v)] || String(v ?? ''); }
function statusKey(v: any): string { return canonicalState(statusLabel(v)); }
/** 打开导入弹窗：清空上一次的文本 */
function openImport(): void { importText.value = ''; importVisible.value = true; }
function statusValueOf(r: any): string { return String(r?.[statusField.value] ?? ''); }
function statusLabelOf(r: any): string { return statusLabel(statusValueOf(r)); }
/** 画像动作的 from 守卫：值、文案、规范状态任一命中即允许 */
function matchesFrom(r: any, a: ProfileAction): boolean {
  if (!a.from?.length) return true;
  const raw = statusValueOf(r);
  const label = statusLabelOf(r);
  return a.from.some((v) => {
    const code = String(v);
    //  Schema 里状态值是 0/1/2 这类 code，种子数据可能是「草稿/已确认」文案，
    //  必须先翻译成文案再比较，否则动作会全部被隐藏（看起来像流程失效）。
    const text = statusMeta.value?.labels[code] || code;
    return code === raw || text === label || canonicalState(text) === canonicalState(label);
  });
}

function formatCell(row: any, c: any): string {
  const v = row?.[c.prop];
  if (v === undefined || v === null || v === '') return '';
  if (c.options?.length) { const hit = c.options.find((o: any) => String(o.value) === String(v)); return hit ? hit.label : String(v); }
  if (c.type === 'money') return '¥' + Number(v).toLocaleString('zh-CN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  if (typeof v === 'object') return JSON.stringify(v);
  return String(v);
}

/** 通用统计（无画像时使用） */
const genericStats = computed(() => {
  const list = rows.value;
  const nowMonth = new Date().toISOString().slice(0, 7);
  const doneKey = Object.keys(statusMeta.value?.labels || {}).find((k) => canonicalState(statusMeta.value!.labels[k]) === 'done');
  const pendingKey = Object.keys(statusMeta.value?.labels || {}).find((k) => canonicalState(statusMeta.value!.labels[k]) === 'pending');
  const amountKey = list.find((r) => r.amount !== undefined) ? 'amount' : (list.find((r) => r.totalAmount !== undefined) ? 'totalAmount' : '');
  const amount = amountKey ? list.reduce((s, r) => s + Number(r[amountKey] || 0), 0) : 0;
  return [
    { label: '记录总数', value: String(list.length), tone: '' },
    { label: '本月新增', value: String(list.filter((r) => String(r.createdAt || '').startsWith(nowMonth)).length), tone: 'biz-blue' },
    { label: doneKey ? '已完成' : '有效记录', value: String(doneKey ? list.filter((r) => statusKey(r[statusField.value]) === statusKey(doneKey)).length : list.filter((r) => !r.isDeleted).length), tone: 'biz-green' },
    { label: pendingKey ? '待处理' : (amountKey ? '金额合计' : '选择行数'), value: pendingKey ? String(list.filter((r) => statusKey(r[statusField.value]) === statusKey(pendingKey)).length) : (amountKey ? '¥' + amount.toFixed(2) : String(selected.value.length)), tone: 'biz-orange' },
  ];
});

/** 展示用统计卡：画像优先，按画像口径真实计算 */
const displayStats = computed(() => {
  const p = profile.value;
  if (!p || !p.stats.length) return genericStats.value;
  const list = rows.value;
  return p.stats.map((s) => {
    let value: string | number = '';
    switch (s.compute) {
      case 'count': value = list.length; break;
      case 'sum': value = list.reduce((n, r) => n + (Number(r[s.field || '']) || 0), 0).toLocaleString('zh-CN'); break;
      case 'avg': {
        const nums = list.map((r) => Number(r[s.field || ''])).filter((n) => Number.isFinite(n));
        value = nums.length ? (nums.reduce((a, b) => a + b, 0) / nums.length).toFixed(1) : '0';
        break;
      }
      case 'status':
        value = list.filter((r) => s.values?.some((v) => String(v) === statusValueOf(r) || String(v) === statusLabelOf(r) || canonicalState(String(v)) === canonicalState(statusLabelOf(r)))).length;
        break;
      case 'nonempty':
        value = s.values
          ? list.filter((r) => s.values!.some((v) => String(v) === String(r[s.field || '']))).length
          : list.filter((r) => r[s.field || ''] !== undefined && r[s.field || ''] !== null && r[s.field || ''] !== '').length;
        break;
    }
    return { label: s.label, value: `${s.prefix || ''}${value}${s.suffix || ''}`, tone: s.tone || '' };
  });
});

const hasBatchable = computed(() => profile.value
  ? profile.value.actions.some((a) => a.batchable)
  : flow.value.actions.some((a) => ['execute', 'approve', 'toggle'].includes(a.key)));

const filteredRows = computed(() => {
  let list = rows.value.slice();
  const k = keyword.value.trim().toLowerCase();
  if (k) list = list.filter((r) => Object.values(r).some((v) => v != null && typeof v !== 'object' && String(v).toLowerCase().includes(k)));
  if (statusFilter.value) list = list.filter((r) => statusKey(r[statusField.value]) === statusKey(statusFilter.value));
  if (props.scope) list = list.filter((r) => String(r[props.scope!.field]) === String(props.scope!.value));
  return list;
});
const pagedRows = computed(() => filteredRows.value.slice((page.value - 1) * pageSize, page.value * pageSize));
const allChecked = computed(() => pagedRows.value.length > 0 && pagedRows.value.every((r) => selected.value.includes(r)));
function toggleAll(checked: boolean) { selected.value = checked ? [...new Set([...selected.value, ...pagedRows.value])] : selected.value.filter((r) => !pagedRows.value.includes(r)); }
function toggleRow(r: any, checked: boolean) { selected.value = checked ? [...selected.value, r] : selected.value.filter((x) => x !== r); }

const lineage = computed(() => {
  const c = collection.value.toLowerCase();
  if (/sale|order|receivable|paymentin/.test(c)) return [{ label: '销售订单', path: '/sales/orders' }, { label: '出货单', path: '/sales/shipments' }, { label: '应收账单', path: '/finance/receivables' }, { label: '收款单', path: '/finance/payments-in' }, { label: '会计凭证', path: '/finance/vouchers' }];
  if (/purch|payable|paymentout/.test(c)) return [{ label: '采购订单', path: '/purchase/orders' }, { label: '采购收货', path: '/purchase/receipts' }, { label: '应付账单', path: '/finance/payables' }, { label: '付款单', path: '/finance/payments-out' }, { label: '会计凭证', path: '/finance/vouchers' }];
  if (/invent|stock|adjust|transfer|check/.test(c)) return [{ label: '产品', path: '/inventory/products' }, { label: '库存查询', path: '/inventory/balance' }, { label: '库存流水', path: '/inventory/ledger' }, { label: '库存预警', path: '/inventory/alerts' }];
  return [{ label: props.title, path: route.path }];
});
const lineageIndex = computed(() => {
  const c = collection.value.toLowerCase();
  if (/receivable|paymentin/.test(c)) return 4;
  if (/payable|paymentout/.test(c)) return 4;
  if (/ledger|alert/.test(c)) return 3;
  if (/adjust|transfer|check/.test(c)) return 2;
  return 0;
});
function goto(path: string) { router.push(path); }

async function load() {
  loading.value = true;
  try {
    if (!activeFields.value.length) {
      const meta: any = await mockGet(`/_biz/schema/${collection.value}`);
      if (meta?.fields?.length) {
        activeFields.value = meta.fields;
        activeSeed.value = meta.seed || [];
        flow.value = buildFlow(collection.value, props.title, props.api, meta.fields, props.flowKey);
      }
    }
    const res: any = await mockGet(props.api, { pageSize: 500 });
    let list = Array.isArray(res) ? res : (res?.list || res?.rows || []);
    if (!list.length && activeSeed.value.length) {
      for (const s of activeSeed.value) { try { await mockPost(props.api, s); } catch (_) { /* 忽略单条失败 */ } }
      const again: any = await mockGet(props.api, { pageSize: 500 });
      list = Array.isArray(again) ? again : (again?.list || again?.rows || []);
    }
    rows.value = list;
    flow.value = buildFlow(collection.value, props.title, props.api, activeFields.value, props.flowKey);
  } catch (e: any) {
    toast.error(e?.message || `加载${props.title}失败`);
    rows.value = [];
  } finally { loading.value = false; }
}
function reload() { page.value = 1; selected.value = []; load(); }
function resetQuery() { keyword.value = ''; statusFilter.value = ''; reload(); }

/** 可用动作：画像优先按 from 守卫过滤，否则按通用状态机 */
function availableActions(r: any): Array<BizAction | ProfileAction> {
  if (profile.value) return profile.value.actions.filter((a) => matchesFrom(r, a));
  const current = statusKey(r[statusField.value]);
  return flow.value.actions.filter((a) => a.from.length === 0 || a.from.some((f) => statusKey(f) === current));
}
function actionLabel(a: BizAction | ProfileAction): string { return a.label; }
function actionClass(a: BizAction | ProfileAction): string {
  const danger = 'danger' in a ? a.danger : false;
  const variant = (a as any).variant;
  return danger || variant === 'danger' ? 'biz-act-danger' : '';
}

/** 本地动作：不写库，仅展示/跳转/导出 */
const LOCAL_ACTIONS = new Set(['print', 'export', 'download', 'detail', 'viewLog', 'viewSession', 'viewFile', 'viewNotify', 'refresh', 'trace', 'viewTrace', 'previewTpl', 'previewLabel', 'previewPromo', 'test', 'testMatch', 'nextNo']);

async function runAction(r: any, a: BizAction | ProfileAction) {
  const label = a.label;
  const key = a.key;
  if (LOCAL_ACTIONS.has(key)) {
    if (key === 'print') { printPage(); return; }
    if (['export', 'download'].includes(key)) { exportCsv(); return; }
    if (key === 'refresh') { reload(); return; }
    if (['viewLog', 'viewSession', 'viewFile', 'viewNotify', 'detail', 'trace', 'viewTrace'].includes(key)) { openDetail(r); return; }
    toast.info(`${label}：已提交，结果将写入业务日志`);
    return;
  }
  if ('confirm' in a && a.confirm && !await uiConfirm(
    `确定对「${props.title} #${r.id}」执行「${label}」吗？${(a as ProfileAction).effect ? '\n' + (a as ProfileAction).effect : ''}`, '业务确认')) return;
  try {
    const res: any = await mockPost(`/_biz/action/${collection.value}/${r.id}/${key}`, {
      statusField: statusField.value,
      amount: r.amount ?? r.totalAmount,
      to: 'to' in a ? a.to : undefined,
      label,
      flowKey: props.flowKey,
    });
    toast.success(res?.message || `${label}成功`);
    await load();
    if (detailVisible.value && detail.value?.id === r.id) openDetail(r);
  } catch (e: any) { toast.error(e?.message || '操作失败'); }
}

async function batchExecute() {
  const act = profile.value
    ? profile.value.actions.find((a) => a.batchable)
    : (flow.value.actions.find((a) => a.key === 'execute' || a.key === 'approve') || flow.value.actions.find((a) => a.key === 'toggle'));
  if (!act) { toast.warning('本模块暂无批量动作'); return; }
  if (!await uiConfirm(`确定批量「${act.label}」选中的 ${selected.value.length} 条记录吗？`, '批量操作确认')) return;
  let ok = 0; let fail = 0;
  for (const r of selected.value) {
    try {
      await mockPost(`/_biz/action/${collection.value}/${r.id}/${act.key}`, { statusField: statusField.value, label: act.label, to: 'to' in act ? act.to : undefined, flowKey: props.flowKey });
      ok++;
    } catch (_) { fail++; }
  }
  toast.success(`批量完成：成功 ${ok} 条${fail ? `，失败 ${fail} 条` : ''}`);
  selected.value = []; await load();
}

function openForm(row?: any) {
  editing.value = row ? { ...row } : null;
  for (const c of formFields.value) form[c.prop] = row ? row[c.prop] : (c.type === 'switch' ? false : '');
  formVisible.value = true;
}
async function save() {
  for (const key of requiredFields.value) {
    if (form[key] === '' || form[key] === undefined || form[key] === null) { toast.warning(`请填写「${activeFields.value.find((c: any) => c.prop === key)?.label || key}」`); return; }
  }
  saving.value = true;
  try {
    if (editing.value?.id) { await mockPatch(`${props.api}/${editing.value.id}`, { ...form }); toast.success('已保存'); }
    else { await mockPost(props.api, { ...form }); toast.success('已创建'); }
    formVisible.value = false; await load();
  } catch (e: any) { toast.error(e?.message || '保存失败'); }
  finally { saving.value = false; }
}

async function removeRow(r: any) {
  if (!await uiConfirm(`确定删除「${props.title} #${r.id}」吗？删除后不可恢复。`, '删除确认')) return;
  try { await mockDel(`${props.api}/${r.id}`); rows.value = rows.value.filter((x) => x.id !== r.id); toast.success('已删除'); }
  catch (e: any) { toast.error(e?.message || '删除失败'); }
}

function startInline(r: any, c: any) { if (c.form === false || c.prop === statusField.value) return; inline.value = { id: r.id, prop: c.prop, value: r[c.prop] }; }
async function commitInline(r: any, c: any) {
  if (!inline.value) return;
  const val = inline.value.value; inline.value = null;
  if (String(r[c.prop]) === String(val)) return;
  try { await mockPatch(`${props.api}/${r.id}`, { [c.prop]: val }); r[c.prop] = val; toast.success('已更新'); }
  catch (e: any) { toast.error(e?.message || '更新失败'); }
}

async function openDetail(r: any) {
  detail.value = r; detailVisible.value = true;
  try {
    const logs: any = await mockGet('/system/audit-logs', { keyword: String(r.id) });
    const list = Array.isArray(logs) ? logs : (logs?.list || []);
    auditTrail.value = list.filter((l: any) => Number(l.bizId) === Number(r.id) && String(l.module).toLowerCase() === collection.value.toLowerCase().replace(/s$/, ''));
  } catch { auditTrail.value = []; }
}

const importPlaceholder = computed(() => activeFields.value.filter((c: any) => c.form !== false && c.prop !== 'id').map((c: any) => c.label).join('\t'));
async function doImport() {
  const lines = importText.value.split('\n').map((l) => l.trim()).filter(Boolean);
  if (!lines.length) { toast.warning('请先粘贴要导入的数据'); return; }
  if (/标签|名称|编码|单号/.test(lines[0]) && !/^\d/.test(lines[0])) lines.shift();
  let ok = 0;
  for (const line of lines) {
    const cells = line.split(/\t|,|，/).map((s) => s.trim());
    const payload: Record<string, any> = {};
    formFields.value.forEach((c: any, i: number) => { payload[c.prop] = cells[i] ?? ''; });
    try { await mockPost(props.api, payload); ok++; } catch (_) { /* 单行失败不计入 */ }
  }
  importVisible.value = false; importText.value = ''; toast.success(`成功导入 ${ok} 条`); await load();
}

function exportCsv() {
  const cols = activeFields.value.filter((c: any) => c.prop !== 'id');
  const head = cols.map((c: any) => c.label).join(',');
  const body = filteredRows.value.map((r) => cols.map((c: any) => `"${String(formatCell(r, c)).replace(/"/g, '""')}"`).join(',')).join('\n');
  const blob = new Blob(['\ufeff' + head + '\n' + body], { type: 'text/csv;charset=utf-8' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob); a.download = `${props.title}_${new Date().toISOString().slice(0, 10)}.csv`; a.click();
  URL.revokeObjectURL(a.href); toast.success(`已导出 ${filteredRows.value.length} 条`);
}
function printPage() { window.print(); }

onMounted(load);
</script>

<style scoped>
/* 内容页节奏：页面留白 16px；组间 12px > 卡片组内；卡片/表格/筛选同圆角。 */
.biz-page { padding: var(--ds-space-4); display: flex; flex-direction: column; gap: var(--ds-space-4); min-height: 100%; box-sizing: border-box; }

/* 页面头部：主题色强调条 + 说明 + 业务提示，明确每页定位 */
.biz-header {
  display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: var(--ds-space-3);
  background: var(--ds-bg-elevated, #fff); border: 1px solid var(--ds-border, #e8eaed);
  border-left: 4px solid var(--biz-accent, var(--ds-brand));
  border-radius: var(--ds-radius-panel); padding: var(--ds-space-3) var(--ds-space-4);
}
.biz-header__main { display: flex; align-items: center; gap: var(--ds-space-3); min-width: 0; }
.biz-header__icon { font-size: 24px; line-height: 1; flex: none; }
.biz-header__text h2 { font-size: var(--ds-font-lg, 16px); font-weight: 600; margin: 0 0 4px; color: var(--ds-text, #1f2430); }
.biz-header__text p { font-size: var(--ds-font-sm); color: var(--ds-text-3, #8a9099); margin: 0; line-height: 1.6; }
.biz-header__tips { display: flex; flex-wrap: wrap; gap: var(--ds-space-2); max-width: 420px; }
.biz-tip { font-size: var(--ds-font-xs); color: var(--ds-text-2, #4e5561); background: var(--ds-bg-soft, #f7f8fa); border: 1px solid var(--ds-border, #e8eaed); border-radius: var(--ds-radius-pill, 999px); padding: 4px 10px; line-height: 1.5; }

.biz-feature-head { display: flex; align-items: center; gap: var(--ds-space-3); padding: var(--ds-space-3) var(--ds-space-4); border-bottom: 1px solid var(--ds-border); }
.biz-feature-head__icon { font-size: 20px; }
.biz-feature-head b { display: block; font-size: var(--ds-font-md); color: var(--ds-text); }
.biz-feature-head small { display: block; font-size: var(--ds-font-xs); color: var(--ds-text-3); margin-top: 2px; }
.biz-stats { display: grid; grid-template-columns: repeat(4, 1fr); gap: var(--ds-gap-field); }
.biz-stat { background: var(--ds-bg-elevated); border: 1px solid var(--ds-border); border-radius: var(--ds-radius-panel); padding: var(--ds-space-3) var(--ds-space-4); display: flex; flex-direction: column; gap: var(--ds-space-1); }
.biz-stat span { font-size: var(--ds-font-xs); color: var(--ds-text-3); }
.biz-stat b { font-size: var(--ds-font-xl); font-weight: 600; color: var(--ds-text); line-height: 1.3; }
.biz-stat b.biz-blue, .biz-stat b.brand { color: var(--ds-brand); }
.biz-stat b.biz-green, .biz-stat b.success { color: var(--ds-success); }
.biz-stat b.biz-orange, .biz-stat b.warning { color: var(--ds-warning); }
.biz-stat b.danger { color: var(--ds-danger); }
.biz-search { display: flex; align-items: center; gap: var(--ds-gap-inner); padding: var(--ds-space-3); flex-wrap: wrap; }
.biz-search__input { width: 240px; }
.biz-search__select { width: 140px; }
.biz-search__spacer { flex: 1; }
.biz-table { overflow-x: auto; min-height: 80px; }
.biz-table .ds-input { padding: var(--ds-space-1) var(--ds-space-2); }
.biz-inline { width: 100%; }
.biz-empty { text-align: center; padding: var(--ds-space-8) var(--ds-space-4); color: var(--ds-text-3); font-size: var(--ds-font-sm); }
.biz-pager { display: flex; align-items: center; justify-content: flex-end; flex-wrap: wrap; gap: var(--ds-gap-field); padding: var(--ds-space-3); font-size: var(--ds-font-xs); color: var(--ds-text-3); }
.biz-table .ds-btn-text { min-height: var(--ds-hit); }
.biz-row-actions { display: flex; flex-wrap: wrap; align-items: center; gap: var(--ds-space-1); }
.biz-row-actions .ds-btn-text { padding-left: 0; padding-right: 0; }
.biz-act-danger { color: var(--ds-danger); }
.biz-form, .biz-scheme { display: grid; grid-template-columns: 1fr 1fr; gap: var(--ds-space-4); padding: var(--ds-space-2) var(--ds-space-1); }
.biz-field { display: flex; flex-direction: column; gap: var(--ds-space-2); font-size: var(--ds-font-sm); }
.biz-field > span { color: var(--ds-text-2); }
.biz-field em { color: var(--ds-danger); font-style: normal; margin-left: var(--ds-space-1); }
.biz-field small { font-size: var(--ds-font-xs); }
.biz-modal-foot { display: flex; justify-content: flex-end; gap: var(--ds-gap-inner); }
.biz-detail__section { margin-bottom: var(--ds-space-6); }
.biz-detail__section:last-child { margin-bottom: 0; }
.biz-detail__section h4 { font-size: var(--ds-font-md); margin: 0 0 var(--ds-space-3); padding-bottom: var(--ds-space-2); border-bottom: 1px solid var(--ds-border); }
.biz-detail__row { display: flex; justify-content: space-between; gap: var(--ds-space-4); padding: var(--ds-space-2) 0; font-size: var(--ds-font-sm); }
.biz-detail__row span { color: var(--ds-text-3); }
.biz-timeline { border-left: 2px solid var(--ds-brand); padding-left: var(--ds-space-4); }
.biz-timeline__item { display: flex; flex-direction: column; gap: var(--ds-space-1); padding-bottom: var(--ds-space-3); font-size: var(--ds-font-xs); }
.biz-timeline__item small { color: var(--ds-text-3); }
.biz-lineage { display: flex; flex-wrap: wrap; gap: var(--ds-gap-inner); }
.biz-lineage span { padding: var(--ds-space-2) var(--ds-space-3); border-radius: var(--ds-radius-pill); border: 1px solid var(--ds-border); font-size: var(--ds-font-xs); cursor: pointer; color: var(--ds-text-3); min-height: var(--ds-hit); display: inline-flex; align-items: center; }
.biz-lineage span.active { border-color: var(--ds-brand); color: var(--ds-brand); background: var(--ds-brand-soft); }
.biz-muted { color: var(--ds-text-3); font-size: var(--ds-font-xs); }
.biz-scheme__hint { grid-column: 1 / -1; margin: 0; }
@media (max-width: 900px) {
  .biz-stats { grid-template-columns: repeat(2, 1fr); }
  .biz-form, .biz-scheme { grid-template-columns: 1fr; }
}
@media (max-width: 720px) {
  .biz-page { padding: var(--ds-space-3); }
  .biz-header { flex-direction: column; align-items: flex-start; }
  .biz-header__tips { max-width: 100%; }
  .biz-search { gap: var(--ds-gap-inner); }
  .biz-search__input, .biz-search__select { width: 100%; }
  .biz-pager { gap: var(--ds-gap-inner); }
}
</style>
