<template>
  <div class="data-table-wrap">
    <div v-if="layout !== 'list'" class="data-table-bar">
      <DsInput v-model="q.keyword" placeholder="搜索名称 / 编码 / 单号" @keyup.enter="$emit('reload')" />
      <DsSelect v-model="q.status" :options="statusOptions" style="width:140px" placeholder="全部状态" />
      <DsButton variant="primary" size="sm" @click="$emit('reload')">查询</DsButton>
      <DsButton size="sm" @click="$emit('reset')">重置</DsButton>
      <span class="bar-spacer" />
      <slot name="extra" />
    </div>
    <div class="data-table" v-loading="loading">
      <table class="ds-table">
        <thead>
          <tr>
            <th v-for="f in config.columns" :key="f.prop">{{ f.label }}</th>
            <th style="width:230px">操作</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="r in rows" :key="r.id">
            <td v-for="f in config.columns" :key="f.prop">
              <span class="cell" :class="f.prop === 'status' ? 'is-status status-' + Number(r[f.prop] ?? 0) : ''">{{ display(r, f) }}</span>
            </td>
            <td class="row-ops">
              <DsButton variant="text" size="sm" @click="$emit('edit', r)">编辑</DsButton>
              <DsButton v-for="a in rowActions(r)" :key="a.key" variant="text" size="sm" @click="$emit('action', r, a)">{{ a.label }}</DsButton>
              <DsButton variant="danger" size="sm" @click="$emit('remove', r)">删除</DsButton>
            </td>
          </tr>
          <tr v-if="!rows.length"><td :colspan="config.columns.length + 1" class="empty">暂无数据，点击右上角新建</td></tr>
        </tbody>
      </table>
    </div>
    <div class="data-pager">
      <span>共 {{ total }} 条</span>
      <DsButton size="sm" :disabled="page <= 1" @click="$emit('update:page', page - 1)">‹</DsButton>
      <b>{{ page }}</b>
      <DsButton size="sm" :disabled="page * pageSize >= total" @click="$emit('update:page', page + 1)">›</DsButton>
    </div>
  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue';
import { DsButton, DsInput, DsSelect } from '../../components';
import type { SalesAction, SalesConfig, SalesField } from '../sales/salesConfigs';

const props = defineProps<{
  config: SalesConfig; rows: any[]; loading: boolean; total: number; page: number; pageSize: number;
  q: { keyword: string; status: any }; layout: string;
  display: (row: any, field: SalesField) => string;
  actionsOf: (row: any) => SalesAction[];
}>();
defineEmits<{
  (e: 'reload'): void; (e: 'reset'): void; (e: 'edit', row: any): void;
  (e: 'action', row: any, action: SalesAction): void; (e: 'remove', row: any): void; (e: 'update:page', value: number): void;
}>();

const statusOptions = computed(() => Object.entries(props.config.statusLabels || {}).map(([value, label]) => ({ label, value: Number(value) })));
function rowActions(row: any): SalesAction[] { return props.actionsOf(row); }
</script>

<style scoped>
.data-table-wrap { border: 1px solid var(--ds-border); border-radius: 10px; background: var(--ds-bg-elevated); margin: 12px; overflow: hidden; }
.data-table-bar { display: flex; align-items: center; gap: 8px; padding: 10px 12px; border-bottom: 1px solid var(--ds-border); }
.data-table-bar .ds-input-wrap { flex: 0 0 230px; width: 230px; }
.bar-spacer { flex: 1; }
.data-table { overflow: auto; min-height: 180px; }
.data-table th, .data-table td { white-space: nowrap; }
.data-table th { background: var(--ds-bg-hover); }
.row-ops { display: flex; gap: 2px; align-items: center; }
.cell { color: var(--ds-text-1); }
.is-status { padding: 2px 8px; border-radius: 999px; background: var(--ds-bg-hover); font-size: 11px; }
.status-1, .status-2, .status-3 { color: var(--ds-success); background: rgba(34,197,94,.1); }
.status-4, .status-9 { color: var(--ds-danger); background: rgba(239,68,68,.1); }
.empty { text-align: center; padding: 30px; color: var(--ds-text-3); }
.data-pager { display: flex; align-items: center; justify-content: flex-end; gap: 8px; padding: 10px 12px; border-top: 1px solid var(--ds-border); font-size: 12px; color: var(--ds-text-3); }
</style>
