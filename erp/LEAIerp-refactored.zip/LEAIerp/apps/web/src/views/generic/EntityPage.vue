<!--
 * 通用业务页：一份组件驱动文档中所有「三级菜单」的列表、表单、状态流转与工具操作。
 * ---------------------------------------------------------------------------
 * 设计思路（遵循《注释.txt》扁平易读原则）：
 *   1. 页面路由 meta 携带 api / entity / statusField / statusLabels / actions；
 *   2. 首屏先用 pageSize=1 取一条样本数据，自动推导列与表单字段（中文名来自 FIELD_LABELS）；
 *   3. 列表用 BaseGrid（Ds 设计系统），表单用 DsModal + 原生 input（ds-input 样式类）；
 *   4. 状态动作、导入、导出、打印、批量操作都走统一 API，Mock 模式下可真实改变数据。
 -->
<template>
  <div class="entity-page">
    <!-- 统计卡片：让每个列表页都有信息密度，而不是空白表格 -->
    <div class="entity-stats">
      <div class="entity-stat"><span>记录总数</span><b>{{ summary.total || rows.length }}</b></div>
      <div class="entity-stat"><span>当前页</span><b>{{ page }}</b></div>
      <div class="entity-stat"><span>每页条数</span><b>{{ pageSize }}</b></div>
      <div class="entity-stat"><span>数据来源</span><b>{{ mockMode ? '本地演示' : '服务端' }}</b></div>
    </div>

    <!-- 海量数据模式：只渲染可视区行，万行列表不卡顿 -->
    <VirtualTable
      v-if="ready && virtualMode"
      :rows="displayRows"
      :columns="virtualColumns"
      :height="460"
      :density="viewDensity"
    />

    <BaseGrid
      v-if="ready && !virtualMode"
      ref="gridRef"
      :columns="columns"
      :fetch="fetchData"
      :selection="true"
      :column-setting="true"
      :exportable="true"
      :export-name="title"
      :add-text="`新建${title}`"
      :action-width="260"
      @add="openForm()"
    >
      <!-- 查询区：支持收起/展开，与文档「查询区可收起」约定一致 -->
      <template #search="{ model }">
        <div class="entity-search">
          <input v-model="keyword" class="ds-input entity-search__input" placeholder="搜索单号 / 名称 / 编码" @keyup.enter="reload(model)" />
          <select v-if="effectiveStatusField" v-model="statusFilter" class="ds-select entity-search__select">
            <option value="">全部状态</option>
            <option v-for="(label, value) in statusLabels" :key="value" :value="value">{{ label }}</option>
          </select>
          <DsButton variant="primary" size="sm" @click="reload(model)">查询</DsButton>
          <DsButton size="sm" @click="resetQuery(model)">重置</DsButton>
          <span class="entity-search__spacer" />
          <DsButton size="sm" @click="advanced = !advanced">{{ advanced ? '收起高级查询' : '高级查询' }}</DsButton>
          <DsButton v-if="advanced" size="sm" @click="exitAdvanced(model)">退出高级查询</DsButton>
        </div>
        <div v-if="advanced" class="entity-search entity-search--advanced">
          <input v-model="advancedCond.field" class="ds-input" placeholder="字段名，如 name / status" />
          <input v-model="advancedCond.value" class="ds-input" placeholder="字段值" />
          <DsButton size="sm" @click="reload(model)">应用筛选</DsButton>
        </div>
      </template>

      <!-- 工具栏：批量操作与导入导出 -->
      <template #toolbar>
        <DsButton size="sm" :disabled="!selection.length" @click="batchApprove">批量通过</DsButton>
        <DsButton size="sm" :disabled="!selection.length" variant="danger" @click="batchVoid">批量作废</DsButton>
        <DsButton size="sm" @click="openImport">导入</DsButton>
        <DsButton size="sm" @click="openPrint">打印</DsButton>
        <DsButton size="sm" :disabled="!selection.length" @click="batchPrint">批量打印</DsButton>
        <DsButton size="sm" @click="openViewConfig">视图配置</DsButton>
        <DsButton size="sm" @click="virtualMode = !virtualMode">{{ virtualMode ? '返回表格' : '海量模式' }}</DsButton>
      </template>

      <!-- 行操作：查看 / 编辑 / 状态动作 / 删除 -->
      <template #action="{ row }">
        <DsButton variant="text" size="sm" @click="openDetail(row)">查看</DsButton>
        <DsButton variant="text" size="sm" @click="openForm(row)">编辑</DsButton>
        <DsButton v-for="act in availableActions(row)" :key="act" variant="text" size="sm" @click="doAction(row, act)">{{ actionLabel(act) }}</DsButton>
        <DsButton variant="text" size="sm" @click="openPrint(row)">打印</DsButton>
        <DsButton variant="text" size="sm" @click="removeRow(row)">删除</DsButton>
      </template>
    </BaseGrid>

    <div v-else class="entity-loading">正在加载「{{ title }}」配置…</div>

    <!-- 新增/编辑弹窗：按样本字段自动生成表单 -->
    <DsModal v-model="formVisible" :title="editing?.id ? `编辑${title}` : `新建${title}`" :width="600">
      <div class="entity-form">
        <label v-for="field in formFields" :key="field" class="entity-field">
          <span>{{ fieldLabel(field) }}</span>
          <textarea v-if="fieldDef(field)?.type === 'textarea' || field === 'remark' || field === 'content'" v-model="formData[field]" class="ds-input" rows="3" :placeholder="`请输入${fieldLabel(field)}`" />
          <select v-else-if="fieldDef(field)?.options?.length" v-model="formData[field]" class="ds-select">
            <option value="">请选择</option>
            <option v-for="opt in fieldDef(field)?.options" :key="opt.value" :value="opt.value">{{ opt.label }}</option>
          </select>
          <select v-else-if="field === effectiveStatusField && Object.keys(statusLabels).length" v-model="formData[field]" class="ds-select">
            <option v-for="(label, value) in statusLabels" :key="value" :value="value">{{ label }}</option>
          </select>
          <input v-else v-model="formData[field]" class="ds-input" :type="['number','money'].includes(fieldDef(field)?.type || '') ? 'number' : 'text'" :placeholder="`请输入${fieldLabel(field)}`" />
        </label>
      </div>
      <template #footer>
        <div class="entity-modal-foot">
          <DsButton @click="formVisible = false">取消</DsButton>
          <DsButton variant="primary" :loading="saving" @click="saveForm">保存</DsButton>
        </div>
      </template>
    </DsModal>

    <!-- 详情弹窗 -->
    <DsModal v-model="detailVisible" :title="`${title}详情`" :width="560">
      <div v-if="detail" class="entity-detail">
        <div v-for="(value, key) in detail" :key="key" class="entity-detail__row">
          <span>{{ fieldLabel(String(key)) }}</span>
          <b>{{ formatValue(value, String(key)) }}</b>
        </div>
        <!-- 单据关联溯源：报价→合同→订单→出货→收款→凭证 全链路上钻（文档第 27 章） -->
        <div class="entity-lineage">
          <b>关联溯源</b>
          <div class="entity-lineage__chain">
            <span v-for="(node, i) in lineage" :key="node.label" :class="{ active: i <= lineageIndex }" @click="router.push('/' + node.path)">
              {{ node.label }} <small>{{ i <= lineageIndex ? '已关联' : '未生成' }}</small>
            </span>
          </div>
        </div>
        <DocumentComments v-if="detail?.id" :biz-type="entity" :biz-id="detail.id" />
      </div>
      <template #footer><div class="entity-modal-foot"><DsButton variant="primary" @click="detailVisible = false">关闭</DsButton></div></template>
    </DsModal>

    <!-- 我的视图配置 -->
    <ViewConfigDrawer v-model="viewConfigVisible" :columns="columns" @apply="applyViewConfig" />

    <!-- 批量操作结果报告 -->
    <BatchResultDialog v-model="batchResultVisible" :results="batchResult" />

    <!-- 导入弹窗：支持粘贴 Excel 表格内容（制表符/逗号分隔） -->
    <DsModal v-model="importVisible" :title="`导入${title}`" :width="620">
      <p class="entity-hint">第一行写字段名，其后每行一条记录；可直接从 Excel 复制粘贴。</p>
      <textarea v-model="importText" class="ds-input" rows="10" :placeholder="`name\tcode\tremark\n示例产品\tDEMO001\t演示数据`" />
      <template #footer>
        <div class="entity-modal-foot">
          <DsButton @click="importVisible = false">取消</DsButton>
          <DsButton variant="primary" :loading="importing" @click="doImport">导入</DsButton>
        </div>
      </template>
    </DsModal>
  </div>
</template>

<script setup lang="ts">
import { computed, onBeforeUnmount, onMounted, reactive, ref, watch } from 'vue';
import { useRoute, useRouter } from 'vue-router';
import { mockGet, mockPost, mockPatch, MOCK_ENABLED } from '../../api/mockAdapter';
import { printApi } from '../../api';
import { FIELD_LABELS } from '../../config/erp';
import { getEntitySchema, type EntityField } from '../../config/entitySchemas';
import { useToast } from '../../components/ds/toast';
import { useUndoRedo } from '../../composables/useUndoRedo';
import { useUnsavedGuard } from '../../composables/useUnsavedGuard';
import { maskField, maskRow } from '../../utils/mask';
import { emit, Events } from '../../utils/eventBus';

/** 路由元信息 */
const route = useRoute();
const router = useRouter();
const title = computed(() => String(route.meta.title || '业务数据'));
const api = computed(() => String(route.meta.api || ''));
const entity = computed(() => String(route.meta.entity || ''));
const statusField = computed(() => String(route.meta.statusField || ''));
/** Schema 覆盖的状态配置（优先于 route.meta），由 deriveFields 填充 */
const schemaStatusLabels = ref<Record<string, string>>({});
const schemaStatusField = ref('');
const statusLabels = computed<Record<string, string>>(() =>
  Object.keys(schemaStatusLabels.value).length ? schemaStatusLabels.value : ((route.meta.statusLabels as Record<string, string>) || {}));
const effectiveStatusField = computed(() => schemaStatusField.value || statusField.value);
const configuredActions = computed<string[]>(() => (route.meta.actions as string[]) || []);
const mockMode = MOCK_ENABLED;

/** 表格列、样本数据、分页统计 */
const columns = ref<any[]>([{ prop: 'id', label: 'ID', width: 80 }]);
const formFields = ref<string[]>([]);
/** 当前实体的 Schema 字段定义（含类型/选项），优先于样本推导 */
const schemaFields = ref<EntityField[]>([]);
const rows = ref<any[]>([]);
const summary = ref<any>({ total: 0 });
const page = ref(1);
const pageSize = ref(10);
const ready = ref(false);
const keyword = ref('');
const statusFilter = ref('');
const advanced = ref(false);
const advancedCond = reactive({ field: '', value: '' });
const selection = ref<any[]>([]);
const gridRef = ref<any>(null);
const toast = useToast();

/** 弹窗与表单状态 */
const formVisible = ref(false);
const detailVisible = ref(false);
const detail = ref<any>(null);
const editing = ref<any>(null);
const formData = reactive<Record<string, any>>({});
const saving = ref(false);
const importVisible = ref(false);
const importText = ref('');
const importing = ref(false);

/** 体验增强状态：虚拟模式、视图配置、批量结果与表单脏标记 */
const virtualMode = ref(false);
const viewConfigVisible = ref(false);
const viewDensity = ref<'default' | 'compact'>('default');
const batchResultVisible = ref(false);
const batchResult = ref<any>({ success: [], failed: [] });
const dirty = ref(false);
const undoStack = useUndoRedo<Record<string, any>>(30);
/** 未保存保护：30 秒自动存草稿，离开页面前提醒 */
const guard = useUnsavedGuard(() => ({ ...formData }), String(route.path), dirty, (draft) => {
  if (formVisible.value) Object.assign(formData, draft);
});
// 表单任何字段变化都标记为脏，供未保存提醒与草稿保存使用
watch(formData, () => { if (formVisible.value) dirty.value = true; }, { deep: true });

/** 展示给表格的行：按字段脱敏，原始数据仍保留在 rows 中用于编辑 */
const displayRows = computed(() => rows.value.map((r) => maskRow(r)));
/** 虚拟表格所需列配置 */
const virtualColumns = computed(() => columns.value.map((c) => ({ label: c.label, prop: c.prop, width: c.width || c.minWidth })));

/** 单据血缘：根据当前实体高亮链路阶段，点击节点跳转到对应单据列表 */
const lineage = [
  { label: '报价单', path: 'sales/quotations' }, { label: '销售合同', path: 'sales/contracts' },
  { label: '销售订单', path: 'sales/orders' }, { label: '出货单', path: 'sales/shipments' },
  { label: '收款单', path: 'finance/payments-in' }, { label: '会计凭证', path: 'finance/vouchers' },
];
const lineageIndex = computed(() => {
  const path = route.path;
  if (path.includes('quotation') || path.includes('contract')) return 1;
  if (path.includes('sale')) return 3;
  if (path.includes('finance') || path.includes('payment')) return 5;
  return detail.value?.id ? 2 : 0;
});

/** 不展示在列/表单中的技术字段 */
const SKIP_FIELDS = ['createdBy', 'updatedBy', 'isDeleted', 'tenantId', 'lines', 'items', 'variants'];

/** api 路径转集合名，与 mockAdapter.collectionOf 规则一致 */
function collectionOfPath(pathValue: string): string {
  return pathValue.split('/').filter(Boolean)
    .map((s, i) => i === 0 ? s : s.replace(/(^|-)([a-z])/g, (_, __, c) => c.toUpperCase())).join('');
}

/**
 * 推导列表列与表单字段：优先用业务 Schema（符合文档的字段定义），
 * 无 Schema 时退回从样本数据猜测。
 * @param sample 样本记录
 * @returns 无
 */
function deriveFields(sample: any): void {
  const schema = getEntitySchema(collectionOfPath(api.value));
  if (schema?.fields?.length) {
    schemaFields.value = schema.fields;
    schemaStatusLabels.value = schema.statusLabels || {};
    schemaStatusField.value = schema.statusField || '';
    columns.value = schema.fields.map((f) => ({
      prop: f.prop,
      label: f.label,
      width: f.width,
      minWidth: f.type === 'textarea' ? 180 : 120,
      sortable: true,
      fieldType: f.type,
      options: f.options,
      // 枚举字段显示为中文标签；金额字段加千分位与两位小数
      formatter: (row: any) => {
        const v = row?.[f.prop];
        if (v === undefined || v === null || v === '') return '';
        if (f.options?.length) {
          const hit = f.options.find((o) => String(o.value) === String(v));
          return hit ? hit.label : String(v);
        }
        if (f.type === 'money') return '¥' + Number(v).toLocaleString('zh-CN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
        return String(v);
      },
    }));
    formFields.value = schema.fields.filter((f) => f.form !== false).map((f) => f.prop);
    return;
  }
  schemaFields.value = [];
  schemaStatusLabels.value = {};
  schemaStatusField.value = '';
  if (!sample) return;
  const keys = Object.keys(sample).filter((k) => !SKIP_FIELDS.includes(k) && typeof sample[k] !== 'object');
  columns.value = keys.slice(0, 10).map((prop) => ({
    prop,
    label: FIELD_LABELS[prop] || prop,
    width: ['id', 'status', 'statusField'].includes(prop) ? 90 : undefined,
    minWidth: ['name', 'title', 'remark', 'content'].includes(prop) ? 180 : 120,
    sortable: true,
  }));
  formFields.value = keys.filter((k) => k !== 'id' && k !== 'createdAt' && k !== 'updatedAt').slice(0, 14);
}

/** 取字段定义（用于表单按类型渲染） */
function fieldDef(prop: string): EntityField | undefined {
  return schemaFields.value.find((f) => f.prop === prop);
}

/**
 * BaseGrid 的取数函数：把本页状态组合成查询条件。
 * @param query BaseGrid 传入的 { page, pageSize, keyword }
 * @returns { list, total }
 */
async function fetchData(query: any) {
  page.value = query.page || 1;
  pageSize.value = query.pageSize || 10;
  const params: any = { page: page.value, pageSize: pageSize.value, keyword: query.keyword || keyword.value };
  if (effectiveStatusField.value && statusFilter.value !== '') params.status = statusFilter.value;
  if (advanced.value && advancedCond.field && advancedCond.value) params[advancedCond.field] = advancedCond.value;
  const data: any = await mockGet(api.value, params);
  rows.value = Array.isArray(data) ? data : (data?.list || []);
  summary.value = data?.summary || { total: data?.total ?? rows.value.length };
  // 保存当前选择（BaseGrid 跨页保留勾选，这里同步一份用于批量操作）
  queueMicrotask(() => { try { selection.value = gridRef.value?.getSelection?.() || []; } catch { /* 组件未就绪 */ } });
  return { list: displayRows.value, total: Number(summary.value.total || rows.value.length) };
}

/** 刷新表格 */
function reload(model?: any) { gridRef.value?.reload?.(); }
/** 重置查询条件 */
function resetQuery(model?: any) {
  keyword.value = ''; statusFilter.value = ''; advancedCond.field = ''; advancedCond.value = '';
  if (model) model.keyword = '';
  reload();
}
/** 退出高级查询并清空条件 */
function exitAdvanced(model?: any) {
  advanced.value = false; advancedCond.field = ''; advancedCond.value = '';
  if (model) model.keyword = keyword.value;
  reload();
}

/** 字段名中文显示：优先 Schema，其次通用映射 */
function fieldLabel(prop: string) {
  return fieldDef(prop)?.label || FIELD_LABELS[prop] || prop;
}
/** 单元格/详情格式化：敏感字段按权限脱敏 */
function formatValue(value: any, field = '') {
  const masked = maskField(field, value);
  return masked === null || masked === undefined ? '-' : typeof masked === 'object' ? JSON.stringify(masked) : String(masked);
}

/** 打开视图配置抽屉 */
function openViewConfig(): void { viewConfigVisible.value = true; }
/** 应用视图配置：列显隐、密度与每页条数 */
function applyViewConfig(config: any): void {
  const visibleProps: string[] = config.columns?.filter((c: any) => c.visible).map((c: any) => c.prop) || [];
  if (visibleProps.length) columns.value = columns.value.filter((c) => visibleProps.includes(c.prop));
  viewDensity.value = config.density === 'compact' ? 'compact' : 'default';
  pageSize.value = Number(config.pageSize || 20);
}
/** 响应主框架的撤销/重做快捷键 */
function onShortcut(event: Event): void {
  const action = (event as CustomEvent).detail;
  if (action === 'undo') {
    const snapshot = undoStack.undo({ ...formData });
    if (snapshot) { Object.assign(formData, snapshot); toast.info('已撤销上一步'); }
  } else if (action === 'redo') {
    const snapshot = undoStack.redo({ ...formData });
    if (snapshot) { Object.assign(formData, snapshot); toast.info('已重做'); }
  }
}

/**
 * 根据状态推导当前行可用的动作。
 * @param row 行数据
 * @returns 动作码数组
 */
function availableActions(row: any): string[] {
  if (configuredActions.value.length) return configuredActions.value;
  // 有业务 Schema 的实体多为主数据（客户/分组/等级等），不套用单据审批动作
  if (schemaFields.value.length) return [];
  const status = Number(row[statusField.value || 'status']);
  if (status === 0) return ['submit'];
  if (status === 1) return ['confirm', 'reject'];
  if (status === 2) return ['ship', 'void'];
  return [];
}
/** 动作码转中文 */
function actionLabel(action: string): string {
  return ({ submit: '提交', confirm: '确认', reject: '驳回', ship: '完成', receive: '收货', void: '作废', approve: '通过', finish: '完成' } as Record<string, string>)[action] || action;
}

/**
 * 执行单据状态动作：POST {api}/{id}/{action}，成功后刷新。
 * @param row 行数据
 * @param action 动作码
 * @returns 无
 */
async function doAction(row: any, action: string): Promise<void> {
  try {
    const res: any = await mockPost(`${api.value}/${row.id}/${action}`, {});
    toast.success(res?.message || `${actionLabel(action)}成功`);
    // 领域事件：单据状态变更驱动下游刷新（工作台待办、库存、打印、AI 可订阅）
    emit(Events.DATA_RELOADED, { api: api.value, id: row.id, action });
    if (['ship', 'receive', 'finish'].includes(action)) emit(Events.STOCK_CHANGED, { bizType: entity.value, bizId: row.id });
    if (action === 'confirm' || action === 'approve') emit(Events.APPROVAL_DONE, { bizType: entity.value, bizId: row.id });
    reload();
  } catch (err: any) { toast.error(err?.message || '操作失败'); }
}

/** 打开新增/编辑表单 */
function openForm(row?: any): void {
  editing.value = row ? { ...row } : null;
  for (const key of Object.keys(formData)) delete formData[key];
  for (const field of formFields.value) formData[field] = row?.[field] ?? '';
  undoStack.clear();
  undoStack.record({ ...formData });
  dirty.value = false;
  formVisible.value = true;
}
/** 保存表单 */
async function saveForm(): Promise<void> {
  saving.value = true;
  try {
    if (editing.value?.id) await mockPatch(`${api.value}/${editing.value.id}`, { ...formData });
    else await mockPost(api.value, { ...formData, status: formData.status ?? 0 });
    formVisible.value = false;
    dirty.value = false;
    guard.clearDraft();
    toast.success('保存成功');
    reload();
  } catch (err: any) { toast.error(err?.message || '保存失败'); }
  finally { saving.value = false; }
}
/** 打开详情 */
function openDetail(row: any): void { detail.value = row; detailVisible.value = true; }
/** 删除（业务单据软删除） */
async function removeRow(row: any): Promise<void> {
  await mockPost(`${api.value}/${row.id}/void`, {});
  toast.success('已作废/删除');
  reload();
}
/** 批量通过 */
async function batchApprove(): Promise<void> {
  const result: any = { success: [], failed: [] };
  for (const row of selection.value) {
    try { await mockPost(`${api.value}/${row.id}/confirm`, {}); result.success.push(row); }
    catch (e: any) { result.failed.push({ label: row.orderNo || row.name || row.id, reason: e?.message || '状态冲突' }); }
  }
  batchResult.value = result;
  batchResultVisible.value = true;
  reload();
}
/** 批量作废 */
async function batchVoid(): Promise<void> {
  const result: any = { success: [], failed: [] };
  for (const row of selection.value) {
    try { await mockPost(`${api.value}/${row.id}/void`, {}); result.success.push(row); }
    catch (e: any) { result.failed.push({ label: row.orderNo || row.name || row.id, reason: e?.message || '状态冲突' }); }
  }
  batchResult.value = result;
  batchResultVisible.value = true;
  reload();
}
/** 批量打印：为每个选中行创建打印任务，并汇总结果 */
async function batchPrint(): Promise<void> {
  const result: any = { success: [], failed: [] };
  for (const row of selection.value) {
    try {
      await printApi.createJob({ bizType: entity.value.toUpperCase(), bizId: row.id, bizNo: row.orderNo || '', copies: 1, channel: 'SERVER_PDF' });
      result.success.push(row);
      emit(Events.PRINT_DONE, { bizId: row.id });
    } catch (e: any) { result.failed.push({ label: row.orderNo || row.name || row.id, reason: e?.message || '打印任务创建失败' }); }
  }
  batchResult.value = result;
  batchResultVisible.value = true;
}
/** 打开导入弹窗 */
function openImport(): void { importVisible.value = true; }
/**
 * 解析粘贴内容并逐行导入。
 * @returns 无
 */
async function doImport(): Promise<void> {
  const lines = importText.value.split('\n').map((l) => l.trim()).filter(Boolean);
  if (lines.length < 2) { toast.warning('请提供表头和至少一行数据'); return; }
  const sep = lines[0].includes('\t') ? '\t' : ',';
  const heads = lines[0].split(sep).map((h) => h.trim());
  importing.value = true;
  const result: any = { success: [], failed: [] };
  lines.slice(1).forEach((line, index) => {
    const values = line.split(sep).map((v) => v.trim());
    const record: any = {};
    heads.forEach((h, i) => { record[h] = values[i] ?? ''; });
    if (!values[0]) result.failed.push({ label: `第 ${index + 2} 行`, reason: '首列必填' });
    else result.success.push(record);
  });
  for (const record of result.success) {
    try { await mockPost(api.value, record); } catch { /* 单条失败不影响其他行 */ }
  }
  importing.value = false;
  importVisible.value = false;
  importText.value = '';
  batchResult.value = result;
  batchResultVisible.value = true;
  reload();
}
/**
 * 创建打印任务（服务端 PDF 通道）。
 * @param row 指定行；不传时打印当前筛选结果
 * @returns 无
 */
async function openPrint(row?: any): Promise<void> {
  await printApi.createJob({ bizType: entity.value.toUpperCase(), bizId: row?.id || 0, bizNo: row?.orderNo || title.value, copies: 1, channel: 'SERVER_PDF' });
  toast.success('打印任务已创建，可在「打印中心-打印记录」查看');
}

/** 首屏：取样本推导字段后渲染表格 */
onMounted(async () => {
  window.addEventListener('erp-shortcut', onShortcut);
  try {
    const sample: any = await mockGet(api.value, { page: 1, pageSize: 1 });
    const first = Array.isArray(sample) ? sample[0] : sample?.list?.[0];
    deriveFields(first);
    // 自定义字段：追加到列与表单，无需改代码即可生效
    const custom: any = await mockGet('/api/v1/ux/custom-fields/resolve', { entity: title.value, pageSize: 100 });
    for (const field of (Array.isArray(custom) ? custom : custom?.list || [])) {
      if (field.isActive === 0 || field.enabled === false) continue;
      const prop = field.code || field.field;
      if (!prop || columns.value.some((c) => c.prop === prop)) continue;
      columns.value.push({ prop, label: field.name || field.label || prop, minWidth: 120, sortable: true });
      formFields.value.push(prop);
    }
    // 恢复已保存的视图配置
    try {
      const saved = JSON.parse(localStorage.getItem('erp_view_' + route.path.replace(/\//g, '_')) || 'null');
      if (saved) applyViewConfig(saved);
    } catch { /* 配置损坏时使用默认视图 */ }
  } catch { /* 接口异常时仍渲染空表格 */ }
  ready.value = true;
});

onBeforeUnmount(() => window.removeEventListener('erp-shortcut', onShortcut));

/** 切换菜单时重新推导字段 */
watch(() => api.value, async () => {
  ready.value = false;
  try {
    const sample: any = await mockGet(api.value, { page: 1, pageSize: 1 });
    deriveFields(Array.isArray(sample) ? sample[0] : sample?.list?.[0]);
  } catch { /* 忽略 */ }
  ready.value = true;
});
</script>

<style scoped>
.entity-page { padding: 16px; display: flex; flex-direction: column; gap: 12px; min-height: 100%; box-sizing: border-box; }
.entity-stats { display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px; }
.entity-stat { background: var(--ds-bg-elevated); border: 1px solid var(--ds-border); border-radius: var(--ds-radius); padding: 12px 16px; display: flex; flex-direction: column; gap: 4px; }
.entity-stat span { color: var(--ds-text-3); font-size: var(--ds-font-xs); }
.entity-stat b { font-size: var(--ds-font-xl); font-weight: 600; color: var(--ds-text); line-height: 1.3; }
.entity-search { display: flex; align-items: center; gap: 8px; flex-wrap: wrap; }
.entity-search__input { width: 220px; }
.entity-search__select { width: 130px; }
.entity-search__spacer { flex: 1; }
.entity-search--advanced { margin-top: 8px; padding-top: 8px; border-top: 1px dashed var(--ds-border); }
.entity-loading { padding: 40px; text-align: center; color: var(--ds-text-3); }
.entity-form { display: grid; grid-template-columns: repeat(2, 1fr); gap: 12px; }
.entity-field { display: flex; flex-direction: column; gap: 4px; font-size: var(--ds-font-sm); color: var(--ds-text-2); }
.entity-field .ds-input, .entity-field .ds-select { width: 100%; box-sizing: border-box; }
.entity-modal-foot { display: flex; justify-content: flex-end; gap: 8px; }
.entity-detail__row { display: grid; grid-template-columns: 140px 1fr; gap: 12px; padding: 8px 0; border-bottom: 1px solid var(--ds-divider); font-size: var(--ds-font-sm); }
.entity-detail__row span { color: var(--ds-text-3); }
.entity-detail__row b { font-weight: 500; word-break: break-all; }
.entity-hint { margin: 0 0 8px; font-size: var(--ds-font-sm); color: var(--ds-text-3); }
.entity-lineage { margin-top: 16px; padding-top: 12px; border-top: 1px solid var(--ds-divider); }
.entity-lineage > b { font-size: 13px; }
.entity-lineage__chain { display: flex; flex-wrap: wrap; gap: var(--ds-gap-inner); margin-top: var(--ds-space-2); }
.entity-lineage__chain span { display: flex; flex-direction: column; padding: var(--ds-space-2) var(--ds-space-3); border: 1px solid var(--ds-border); border-radius: var(--ds-radius-ctl); font-size: var(--ds-font-xs); cursor: pointer; opacity: .55; min-height: var(--ds-ctl-h-sm); justify-content: center; }
.entity-lineage__chain span.active { opacity: 1; border-color: var(--ds-brand); color: var(--ds-brand); }
.entity-lineage__chain small { font-size: 10px; color: var(--ds-text-3); }
</style>
