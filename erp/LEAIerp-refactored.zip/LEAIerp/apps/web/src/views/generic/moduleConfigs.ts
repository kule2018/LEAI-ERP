/** 商城 / 打印 / AI / 系统 / 工作台剩余页面的独立业务配置：每页字段、流程、动作、布局均不同。 */
import type { SalesAction, SalesConfig, SalesField } from '../sales/salesConfigs';

export type ModuleKey = 'workbench' | 'shop' | 'print' | 'ai' | 'system';

const DOC = { '0': '草稿', '1': '处理中', '2': '已完成', '3': '已归档', '4': '已驳回', '9': '已作废' };
const MASTER = { '0': '停用', '1': '启用' };
const docActions: SalesAction[] = [
  { key: 'submit', label: '提交', variant: 'primary', from: [0] },
  { key: 'approve', label: '审核通过', variant: 'primary', from: [1] },
  { key: 'reject', label: '驳回', variant: 'danger', from: [1] },
  { key: 'archive', label: '归档', variant: 'default', from: [2] },
];
const masterActions: SalesAction[] = [
  { key: 'toggle', label: '停用', variant: 'warning', from: [1] },
  { key: 'enable', label: '启用', variant: 'primary', from: [0] },
  { key: 'copy', label: '复制' },
];
const f = (prop: string, label: string, type?: SalesField['type'], required?: boolean): SalesField => ({ prop, label, type, required });

type Kind = 'doc' | 'master' | 'report';
interface Def {
  module: ModuleKey; key: string; title: string; collection: string;
  layout: NonNullable<SalesConfig['layout']>; kind: Kind;
  codeLabel: string; nameLabel: string; extra: SalesField[];
  actions?: SalesAction[];
}

const DEFS: Def[] = [
  // 工作台
  { module: 'workbench', key: 'todo', title: '待办中心', collection: 'wbTodo', layout: 'approval', kind: 'doc', codeLabel: '待办编号', nameLabel: '待办事项', extra: [f('partner', '来源人'), f('bizText', '待办类型'), f('bizDate', '截止日期', 'date'), f('amount', '关联金额', 'number')], actions: docActions },

  // 商城渠道
  { module: 'shop', key: 'center', title: '渠道运营中心', collection: 'shopCenter', layout: 'analytics', kind: 'report', codeLabel: '运营编号', nameLabel: '运营主题', extra: [f('amount', '成交金额', 'number'), f('qty', '订单数量', 'number'), f('bizText', '渠道'), f('docDate', '统计日期', 'date')] },
  { module: 'shop', key: 'stores', title: '线上店铺', collection: 'shopStores', layout: 'list', kind: 'master', codeLabel: '店铺编码', nameLabel: '店铺名称', extra: [f('partner', '平台'), f('bizText', '店铺联系人'), f('bizAmount', '本月销售额', 'number')] },
  { module: 'shop', key: 'channels', title: '渠道配置', collection: 'shopChannels', layout: 'list', kind: 'master', codeLabel: '渠道编码', nameLabel: '渠道名称', extra: [f('partner', '渠道负责人'), f('bizText', '结算方式'), f('bizAmount', '佣金比例', 'number')] },
  { module: 'shop', key: 'goods-maps', title: '商品映射', collection: 'shopGoodsMaps', layout: 'warehouse', kind: 'master', codeLabel: '映射编码', nameLabel: '映射名称', extra: [f('productName', '平台商品'), f('bizText', '平台SKU'), f('partner', '内部商品'), f('qty', '库存数量', 'number')] },
  { module: 'shop', key: 'orders', title: '平台订单', collection: 'shopOrders', layout: 'workflow', kind: 'doc', codeLabel: '平台订单号', nameLabel: '订单摘要', extra: [f('partner', '买家'), f('productName', '商品'), f('qty', '数量', 'number'), f('amount', '订单金额', 'number'), f('docDate', '下单时间', 'date')], actions: docActions },
  { module: 'shop', key: 'coupons', title: '优惠券', collection: 'shopCoupons', layout: 'workflow', kind: 'doc', codeLabel: '券编号', nameLabel: '券名称', extra: [f('bizText', '券类型'), f('amount', '面额', 'number'), f('qty', '发放数量', 'number'), f('bizDate', '有效期至', 'date')], actions: docActions },
  { module: 'shop', key: 'promotions', title: '促销活动', collection: 'shopPromotions', layout: 'workflow', kind: 'doc', codeLabel: '活动编号', nameLabel: '活动名称', extra: [f('bizText', '活动类型'), f('amount', '活动预算', 'number'), f('bizDate', '开始日期', 'date'), f('partner', '负责店铺')], actions: docActions },

  // 打印中心
  { module: 'print', key: 'templates', title: '模板管理', collection: 'printTemplates', layout: 'files', kind: 'master', codeLabel: '模板编码', nameLabel: '模板名称', extra: [f('bizText', '模板类型'), f('qty', '模板大小(MB)', 'number'), f('docDate', '更新日期', 'date')] },
  { module: 'print', key: 'doc-templates', title: '单据模板', collection: 'printDocTemplates', layout: 'workflow', kind: 'doc', codeLabel: '单据模板号', nameLabel: '模板标题', extra: [f('bizText', '关联单据'), f('partner', '适用部门'), f('docDate', '生效日期', 'date')], actions: docActions },
  { module: 'print', key: 'jobs', title: '打印执行', collection: 'printJobs', layout: 'kanban', kind: 'doc', codeLabel: '打印任务号', nameLabel: '打印任务', extra: [f('partner', '打印人'), f('bizText', '打印机'), f('qty', '份数', 'number'), f('docDate', '提交时间', 'date')], actions: docActions },
  { module: 'print', key: 'records', title: '打印记录', collection: 'printRecords', layout: 'analytics', kind: 'report', codeLabel: '记录编号', nameLabel: '记录说明', extra: [f('partner', '打印人'), f('qty', '打印页数', 'number'), f('docDate', '打印日期', 'date')] },
  { module: 'print', key: 'labels', title: '条码标签', collection: 'printLabels', layout: 'files', kind: 'master', codeLabel: '标签编码', nameLabel: '标签名称', extra: [f('productName', '关联产品'), f('bizText', '条码规则'), f('qty', '打印数量', 'number')] },

  // AI 助手
  { module: 'ai', key: 'copilot', title: 'AI 助理', collection: 'aiCopilot', layout: 'chat', kind: 'master', codeLabel: '会话编号', nameLabel: '会话主题', extra: [f('partner', '提问人'), f('bizText', '模型'), f('qty', '消息数', 'number')] },
  { module: 'ai', key: 'doc-parse', title: '智能建单', collection: 'aiDocParse', layout: 'workflow', kind: 'doc', codeLabel: '识别单号', nameLabel: '单据标题', extra: [f('bizText', '识别类型'), f('amount', '识别金额', 'number'), f('docDate', '识别日期', 'date')], actions: docActions },
  { module: 'ai', key: 'ocr', title: 'OCR 识别', collection: 'aiOcr', layout: 'qc', kind: 'doc', codeLabel: '识别编号', nameLabel: '文件名称', extra: [f('bizText', '识别类型'), f('qty', '识别字段数', 'number'), f('docDate', '识别时间', 'date')], actions: docActions },
  { module: 'ai', key: 'forecast-risk', title: '预测与风控', collection: 'aiForecastRisk', layout: 'analytics', kind: 'report', codeLabel: '预测编号', nameLabel: '预测主题', extra: [f('bizText', '风险类型'), f('amount', '预测金额', 'number'), f('docDate', '预测日期', 'date')] },
  { module: 'ai', key: 'anomaly', title: '异常检测', collection: 'aiAnomaly', layout: 'qc', kind: 'doc', codeLabel: '异常编号', nameLabel: '异常事项', extra: [f('partner', '检测对象'), f('bizText', '异常类型'), f('amount', '影响金额', 'number')], actions: docActions },
  { module: 'ai', key: 'reconcile', title: '智能对账', collection: 'aiReconcile', layout: 'ledger', kind: 'doc', codeLabel: '对账单号', nameLabel: '对账主题', extra: [f('partner', '对账对象'), f('amount', '对账金额', 'number'), f('bizAmount', '差异金额', 'number')], actions: docActions },
  { module: 'ai', key: 'subject-match', title: '科目匹配', collection: 'aiSubjectMatch', layout: 'list', kind: 'master', codeLabel: '规则编号', nameLabel: '规则名称', extra: [f('bizText', '原始科目'), f('productName', '目标科目'), f('partner', '匹配部门')] },
  { module: 'ai', key: 'report', title: '报表解读', collection: 'aiReport', layout: 'analytics', kind: 'report', codeLabel: '解读编号', nameLabel: '报表名称', extra: [f('bizText', '解读结论'), f('amount', '关键金额', 'number'), f('docDate', '解读日期', 'date')] },
  { module: 'ai', key: 'cs', title: '智能客服', collection: 'aiCs', layout: 'chat', kind: 'master', codeLabel: '会话编号', nameLabel: '会话主题', extra: [f('partner', '客户'), f('bizText', '问题类型'), f('qty', '消息数', 'number')] },
  { module: 'ai', key: 'knowledge', title: '知识库与 RAG', collection: 'aiKnowledge', layout: 'files', kind: 'master', codeLabel: '知识编号', nameLabel: '知识标题', extra: [f('bizText', '知识分类'), f('partner', '维护人'), f('qty', '文档大小(MB)', 'number')] },
  { module: 'ai', key: 'config', title: '模型配置', collection: 'aiConfig', layout: 'list', kind: 'master', codeLabel: '配置编码', nameLabel: '配置名称', extra: [f('bizText', '模型名称'), f('partner', '服务商'), f('amount', '单次成本', 'number')] },
  { module: 'ai', key: 'prompts', title: 'Prompt 模板管理', collection: 'aiPrompts', layout: 'files', kind: 'master', codeLabel: '模板编号', nameLabel: '模板名称', extra: [f('bizText', '适用场景'), f('partner', '创建人'), f('qty', '调用次数', 'number')] },
  { module: 'ai', key: 'functions', title: 'Function 工具管理', collection: 'aiFunctions', layout: 'list', kind: 'master', codeLabel: '工具编码', nameLabel: '工具名称', extra: [f('bizText', '调用地址'), f('partner', '负责人'), f('qty', '调用次数', 'number')] },
  { module: 'ai', key: 'mcp', title: 'MCP 服务管理', collection: 'aiMcp', layout: 'equipment', kind: 'master', codeLabel: '服务编码', nameLabel: '服务名称', extra: [f('bizText', '服务地址'), f('partner', '供应商'), f('amount', '月费用', 'number')] },
  { module: 'ai', key: 'audits', title: 'AI 审计日志', collection: 'aiAudits', layout: 'analytics', kind: 'report', codeLabel: '审计编号', nameLabel: '审计主题', extra: [f('partner', '操作人'), f('bizText', 'AI 动作'), f('docDate', '操作时间', 'date')] },

  // 系统管理
  { module: 'system', key: 'users', title: '用户与角色', collection: 'sysUsers', layout: 'people', kind: 'master', codeLabel: '用户账号', nameLabel: '用户姓名', extra: [f('partner', '所属部门'), f('bizText', '角色'), f('bizDate', '入职日期', 'date')] },
  { module: 'system', key: 'configs', title: '参数与审计', collection: 'sysConfigs', layout: 'list', kind: 'master', codeLabel: '参数编码', nameLabel: '参数名称', extra: [f('bizText', '参数值'), f('partner', '所属模块'), f('remark', '参数说明', 'textarea')] },
  { module: 'system', key: 'orgs', title: '组织租户', collection: 'sysOrgs', layout: 'people', kind: 'master', codeLabel: '组织编码', nameLabel: '组织名称', extra: [f('partner', '组织类型'), f('bizText', '负责人'), f('bizDate', '创建日期', 'date')] },
  { module: 'system', key: 'roles', title: '角色', collection: 'sysRoles', layout: 'list', kind: 'master', codeLabel: '角色编码', nameLabel: '角色名称', extra: [f('partner', '数据范围'), f('bizText', '角色说明'), f('qty', '成员数量', 'number')] },
  { module: 'system', key: 'permissions', title: '权限', collection: 'sysPermissions', layout: 'list', kind: 'master', codeLabel: '权限编码', nameLabel: '权限名称', extra: [f('bizText', '权限类型'), f('partner', '所属模块'), f('bizSelect', '请求方法')] },
  { module: 'system', key: 'data-scopes', title: '数据权限', collection: 'sysDataScopes', layout: 'list', kind: 'master', codeLabel: '规则编码', nameLabel: '规则名称', extra: [f('partner', '适用角色'), f('bizText', '范围级别'), f('bizText2', '部门范围')] },
  { module: 'system', key: 'sequences', title: '编码规则', collection: 'sysSequences', layout: 'list', kind: 'master', codeLabel: '规则编码', nameLabel: '规则名称', extra: [f('bizText', '前缀'), f('qty', '步长', 'number'), f('partner', '适用单据')] },
  { module: 'system', key: 'nos', title: '单据编号', collection: 'sysNos', layout: 'list', kind: 'master', codeLabel: '编号编码', nameLabel: '编号名称', extra: [f('bizText', '当前号码'), f('partner', '适用单据'), f('qty', '重置周期', 'number')] },
  { module: 'system', key: 'dicts', title: '数据字典', collection: 'sysDicts', layout: 'list', kind: 'master', codeLabel: '字典编码', nameLabel: '字典名称', extra: [f('bizText', '字典值'), f('partner', '字典分组'), f('bizText2', '显示名称')] },
  { module: 'system', key: 'settings', title: '系统参数', collection: 'sysSettings', layout: 'list', kind: 'master', codeLabel: '参数键', nameLabel: '参数名称', extra: [f('bizText', '参数值'), f('partner', '参数分组'), f('bizText2', '默认值')] },
  { module: 'system', key: 'i18n', title: '多语言多币种', collection: 'sysI18n', layout: 'list', kind: 'master', codeLabel: '语言/币种编码', nameLabel: '语言/币种名称', extra: [f('bizText', '符号'), f('partner', '区域'), f('bizAmount', '汇率', 'number')] },
  { module: 'system', key: 'audit-logs', title: '审计日志', collection: 'sysAuditLogs', layout: 'analytics', kind: 'report', codeLabel: '日志编号', nameLabel: '操作摘要', extra: [f('partner', '操作人'), f('bizText', '操作类型'), f('docDate', '操作时间', 'date')] },
  { module: 'system', key: 'login-logs', title: '登录日志', collection: 'sysLoginLogs', layout: 'analytics', kind: 'report', codeLabel: '日志编号', nameLabel: '登录账号', extra: [f('partner', '登录IP'), f('bizText', '登录方式'), f('docDate', '登录时间', 'date')] },
  { module: 'system', key: 'notifies', title: '通知中心', collection: 'sysNotifies', layout: 'approval', kind: 'doc', codeLabel: '通知编号', nameLabel: '通知标题', extra: [f('partner', '接收人'), f('bizText', '通知类型'), f('docDate', '发送时间', 'date')], actions: docActions },
  { module: 'system', key: 'files', title: '文件存储', collection: 'sysFiles', layout: 'files', kind: 'master', codeLabel: '文件编号', nameLabel: '文件名称', extra: [f('bizText', '存储路径'), f('qty', '文件大小(MB)', 'number'), f('partner', '上传人')] },
  { module: 'system', key: 'jobs', title: '定时任务', collection: 'sysJobs', layout: 'kanban', kind: 'doc', codeLabel: '任务编码', nameLabel: '任务名称', extra: [f('bizText', '执行表达式'), f('partner', '负责人'), f('bizDate', '下次执行', 'date')], actions: docActions },
  { module: 'system', key: 'openapi', title: '开放平台', collection: 'sysOpenapi', layout: 'equipment', kind: 'master', codeLabel: '应用编码', nameLabel: '应用名称', extra: [f('bizText', 'AppKey'), f('partner', '负责人'), f('amount', '调用额度', 'number')] },
  { module: 'system', key: 'webhooks', title: 'Webhook 日志', collection: 'sysWebhooks', layout: 'analytics', kind: 'report', codeLabel: '日志编号', nameLabel: '事件名称', extra: [f('bizText', '回调地址'), f('partner', '订阅应用'), f('docDate', '回调时间', 'date')] },
  { module: 'system', key: 'events', title: '消息订阅', collection: 'sysEvents', layout: 'approval', kind: 'doc', codeLabel: '订阅编号', nameLabel: '订阅主题', extra: [f('partner', '订阅人'), f('bizText', '事件类型'), f('docDate', '订阅日期', 'date')], actions: docActions },
  { module: 'system', key: 'backups', title: '数据备份', collection: 'sysBackups', layout: 'equipment', kind: 'doc', codeLabel: '备份编号', nameLabel: '备份名称', extra: [f('bizText', '备份类型'), f('qty', '备份大小(MB)', 'number'), f('docDate', '备份时间', 'date')], actions: docActions },
  { module: 'system', key: 'view-configs', title: '我的视图', collection: 'sysViewConfigs', layout: 'list', kind: 'master', codeLabel: '视图编码', nameLabel: '视图名称', extra: [f('partner', '所属页面'), f('bizText', '视图类型'), f('qty', '字段数量', 'number')] },
  { module: 'system', key: 'import-export', title: '导入导出中心', collection: 'sysImportExport', layout: 'workflow', kind: 'doc', codeLabel: '任务编号', nameLabel: '任务名称', extra: [f('bizText', '任务类型'), f('partner', '操作人'), f('qty', '记录数量', 'number')], actions: docActions },
  { module: 'system', key: 'custom-fields', title: '自定义字段', collection: 'sysCustomFields', layout: 'list', kind: 'master', codeLabel: '字段编码', nameLabel: '字段名称', extra: [f('partner', '所属实体'), f('bizText', '字段类型'), f('bizText2', '默认值')] },
  { module: 'system', key: 'rules', title: '业务规则中心', collection: 'sysRules', layout: 'workflow', kind: 'doc', codeLabel: '规则编号', nameLabel: '规则名称', extra: [f('bizText', '触发条件'), f('partner', '所属模块'), f('bizText2', '执行动作')], actions: docActions },
  { module: 'system', key: 'alert-rules', title: '告警规则', collection: 'sysAlertRules', layout: 'approval', kind: 'doc', codeLabel: '规则编号', nameLabel: '规则名称', extra: [f('partner', '监控对象'), f('bizText', '告警级别'), f('amount', '阈值', 'number')], actions: docActions },
  { module: 'system', key: 'report-designer', title: '报表设计器', collection: 'sysReportDesigner', layout: 'analytics', kind: 'master', codeLabel: '报表编码', nameLabel: '报表名称', extra: [f('bizText', '数据来源'), f('partner', '设计人'), f('qty', '字段数量', 'number')] },
  { module: 'system', key: 'plugins', title: '插件市场', collection: 'sysPlugins', layout: 'list', kind: 'master', codeLabel: '插件编码', nameLabel: '插件名称', extra: [f('partner', '供应商'), f('bizText', '版本号'), f('amount', '授权费用', 'number')] },
  { module: 'system', key: 'changelog', title: '版本更新日志', collection: 'sysChangelog', layout: 'calendar', kind: 'master', codeLabel: '版本编号', nameLabel: '版本名称', extra: [f('bizText', '更新类型'), f('docDate', '发布日期', 'date'), f('partner', '发布人')] },
  { module: 'system', key: 'integrations', title: '外部集成中心', collection: 'sysIntegrations', layout: 'equipment', kind: 'master', codeLabel: '集成编码', nameLabel: '集成名称', extra: [f('partner', '外部系统'), f('bizText', '认证方式'), f('amount', '调用费用', 'number')] },
  { module: 'system', key: 'subscriptions', title: '变更订阅', collection: 'sysSubscriptions', layout: 'approval', kind: 'doc', codeLabel: '订阅编号', nameLabel: '订阅主题', extra: [f('partner', '订阅人'), f('bizText', '订阅对象'), f('docDate', '订阅日期', 'date')], actions: docActions },
  { module: 'system', key: 'feedback', title: '反馈与工单', collection: 'sysFeedback', layout: 'workflow', kind: 'doc', codeLabel: '工单编号', nameLabel: '反馈标题', extra: [f('partner', '反馈人'), f('bizText', '问题类型'), f('docDate', '反馈日期', 'date')], actions: docActions },
];

const API_GROUP: Record<ModuleKey, string> = { workbench: 'xwb', shop: 'xshop', print: 'xprint', ai: 'xai', system: 'xsys' };

function build(d: Def): SalesConfig {
  const base: SalesField[] = [f('code', d.codeLabel, undefined, true), f('name', d.nameLabel, undefined, true)];
  const labels = d.kind === 'doc' ? DOC : MASTER;
  const status: SalesField = {
    prop: 'status', label: '状态', type: 'select',
    options: Object.entries(labels).map(([k, v]) => ({ label: v, value: Number(k) })),
  };
  const isReport = d.kind === 'report';
  return {
    title: d.title,
    api: `/api/v1/${API_GROUP[d.module]}/${d.key}`,
    collection: d.collection,
    columns: [...base, ...d.extra, ...(isReport ? [] : [status])],
    fields: [...base, ...d.extra, f('remark', '备注', 'textarea'), ...(isReport ? [] : [status])],
    statusField: 'status',
    statusLabels: labels,
    actions: isReport ? [] : (d.actions || (d.kind === 'doc' ? docActions : masterActions)),
    readOnly: isReport,
    layout: d.layout,
    defaults: () => ({ status: d.kind === 'doc' ? 0 : 1, qty: 0, amount: 0, bizAmount: 0 }),
  };
}

export const MODULE_CONFIGS: Record<string, SalesConfig> = Object.fromEntries(DEFS.map((d) => [`${d.module}/${d.key}`, build(d)]));

export function moduleConfigFor(module: ModuleKey, key: string): SalesConfig {
  const c = MODULE_CONFIGS[`${module}/${key}`];
  if (!c) throw new Error(`未知页面配置：${module}/${key}`);
  return c;
}
