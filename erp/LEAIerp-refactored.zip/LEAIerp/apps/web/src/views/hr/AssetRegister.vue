<template><RecordPage :config="page" /></template>

<script setup lang="ts">
import RecordPage from '../records/RecordPage.vue';
import type { RecordPageConfig } from '../records/records';

const page: RecordPageConfig = {
  title: '资产台账',
  resource: 'hr/asset-ledgers',
  schema: 'hrAssetLedgers',
  filters: ['category', 'custodian', 'location'],
  required: ['assetNo', 'name', 'category'],
  metrics: ['value'],
};
</script>
