<template><RecordPage :config="page" /></template>

<script setup lang="ts">
import RecordPage from '../records/RecordPage.vue';
import type { RecordPageConfig } from '../records/records';

const page: RecordPageConfig = {
  title: '资产归还',
  resource: 'hr/asset-returns',
  schema: 'hrAssetReturns',
  filters: ['custodian', 'returnDate', 'status'],
  required: ['returnNo', 'assetName', 'custodian', 'returnDate'],
};
</script>
