<template><RecordPage :config="page" /></template>

<script setup lang="ts">
import RecordPage from '../records/RecordPage.vue';
import type { RecordPageConfig } from '../records/records';

const page: RecordPageConfig = {
  title: '资产报废',
  resource: 'hr/asset-scraps',
  schema: 'hrAssetScraps',
  filters: ['assetName', 'scrapDate', 'status'],
  required: ['scrapNo', 'assetName', 'reason', 'scrapDate'],
  metrics: ['originalValue'],
};
</script>
