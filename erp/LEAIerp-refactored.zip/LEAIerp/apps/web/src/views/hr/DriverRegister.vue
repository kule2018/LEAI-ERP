<template><RecordPage :config="page" /></template>

<script setup lang="ts">
import RecordPage from '../records/RecordPage.vue';
import type { RecordPageConfig } from '../records/records';

const page: RecordPageConfig = {
  title: '司机',
  resource: 'hr/drivers',
  schema: 'hrDrivers',
  filters: ['licenseType', 'expireDate', 'status'],
  required: ['name', 'licenseNo', 'licenseType', 'expireDate'],
};
</script>
