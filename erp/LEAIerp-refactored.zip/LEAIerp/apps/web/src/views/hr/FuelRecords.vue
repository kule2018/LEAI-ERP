<template><RecordPage :config="page" /></template>

<script setup lang="ts">
import RecordPage from '../records/RecordPage.vue';
import type { RecordPageConfig } from '../records/records';

const page: RecordPageConfig = {
  title: '加油记录',
  resource: 'hr/fuel-records',
  schema: 'hrFuelRecords',
  filters: ['plateNo', 'fuelDate', 'driver'],
  required: ['plateNo', 'fuelDate', 'qty', 'amount'],
  metrics: ['qty', 'amount'],
};
</script>
