<template><RecordPage :config="page" /></template>

<script setup lang="ts">
import RecordPage from '../records/RecordPage.vue';
import type { RecordPageConfig } from '../records/records';

const page: RecordPageConfig = {
  title: '录用',
  resource: 'hr/hirings',
  schema: 'hrHirings',
  filters: ['position', 'deptName', 'entryDate', 'status'],
  required: ['name', 'position', 'deptName', 'entryDate'],
};
</script>
