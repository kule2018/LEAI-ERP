
<template><div class="r-page">
<div class="r-head"><div><div class="r-kicker">HEATMAP · 出勤率</div><h2>出勤率</h2></div><div class="r-actions"><DsButton size="sm" @click="load">刷新</DsButton><DsButton size="sm" @click="exportCsv">导出</DsButton></div></div>
<div class="r-stats"><div class="r-stat"><span>记录数</span><b>{{rows.length}}</b></div><div class="r-stat"><span>金额合计</span><b>¥{{sumAmount}}</b></div><div class="r-stat"><span>数量合计</span><b>{{sumQty}}</b></div><div class="r-stat"><span>待处理</span><b>{{pendingCount}}</b></div></div>
<div class="r-search"><input v-model="q.keyword" class="ds-input" placeholder="搜索…" @keyup.enter="reload"/><DsButton variant="primary" size="sm" @click="reload">查询</DsButton><DsButton size="sm" @click="resetQuery">重置</DsButton></div>
<div class="r-heat"><div class="r-heat-head"><b>出勤热力</b><span>近 5 周 · 共 {{rows.length}} 人</span></div><div class="r-heat-grid"><div v-for="cell in heat" :key="cell.i" class="r-heat-cell" :style="{opacity:0.25+cell.v*0.18}"></div></div><div class="r-legend">出勤强度 低 <i style="background:#0e9f8a;opacity:.3"></i><i style="background:#0e9f8a;opacity:.55"></i><i style="background:#0e9f8a;opacity:.8"></i><i style="background:#0e9f8a"></i> 高</div><div class="r-table" style="margin-top:14px"><table><thead><tr><th v-for="c in columns" :key="c.prop">{{c.label}}</th></tr></thead><tbody><tr v-for="r in rows" :key="r.id"><td v-for="c in columns" :key="c.prop">{{display(r,c)}}</td></tr></tbody></table></div></div>
<div class="r-pager"><DsPagination v-model:current-page="page" :page-size="pageSize" :total="total" layout="total, prev, pager, next" @change="load"/></div>

</div></template>

<script setup lang="ts">
import { DsButton, DsModal, DsPagination } from '../../components';
import { ref, reactive, computed, onMounted } from 'vue';
import { mockGet, mockPost, mockPatch, mockDel } from '../../api/mockAdapter';
import { useToast } from '../../components/ds/toast';
import { confirm as uiConfirm } from '../../components/ds/useConfirm';
const toast=useToast();
const API="/api/v1/hr/attendance";const COLLECTION="hrAttendance";
const columns=[{"prop":"code","label":"考勤编号","type":"text","options":null,"source":""},{"prop":"name","label":"考勤日期","type":"text","options":null,"source":""},{"prop":"partner","label":"员工","type":"text","options":null,"source":""},{"prop":"qty","label":"出勤工时","type":"number","options":null,"source":""},{"prop":"bizText","label":"出勤状态","type":"select","options":[{"label":"正常","value":"正常"},{"label":"迟到","value":"迟到"},{"label":"缺卡","value":"缺卡"},{"label":"请假","value":"请假"}],"source":""},{"prop":"docDate","label":"考勤日期","type":"date","options":null,"source":""}];
const formFields=[{"prop":"code","label":"考勤编号","type":"text","options":null,"source":"","required":true},{"prop":"name","label":"考勤日期","type":"text","options":null,"source":"","required":true},{"prop":"partner","label":"员工","type":"text","options":null,"source":"","required":false},{"prop":"qty","label":"出勤工时","type":"number","options":null,"source":"","required":false},{"prop":"bizText","label":"出勤状态","type":"select","options":[{"label":"正常","value":"正常"},{"label":"迟到","value":"迟到"},{"label":"缺卡","value":"缺卡"},{"label":"请假","value":"请假"}],"source":"","required":false},{"prop":"docDate","label":"考勤日期","type":"date","options":null,"source":"","required":false},{"prop":"remark","label":"备注","type":"textarea","options":null,"source":"","required":false}];
const statusLabels={"0":"停用","1":"启用"};const actions=[];
const hasStatus=Object.keys(statusLabels).length>0;const isReport=true;
const q=reactive({keyword:'',status:''});
const rows=ref([]);const total=ref(0);const page=ref(1);const pageSize=ref(12);
const loading=ref(false);const saving=ref(false);const formVisible=ref(false);const editing=ref(null);
const form=reactive({});const remoteOptions=reactive({});
const sumAmount=computed(function(){return rows.value.reduce(function(a,r){return a+(Number(r.amount)||Number(r.bizAmount)||0);},0);});
const sumQty=computed(function(){return rows.value.reduce(function(a,r){return a+(Number(r.qty)||0);},0);});
const pendingCount=computed(function(){return rows.value.filter(function(r){return Number(r.status==null?1:r.status)<=1;}).length;});
function statusText(v){return statusLabels[String(v)]||String(v==null?'':v);}
function display(row,col){var v=row&&col?row[col.prop]:undefined;if(col&&col.prop==='status'&&hasStatus)return statusText(v);if(col&&col.options){var h=col.options.find(function(o){return String(o.value)===String(v);});if(h)return h.label;}var src=col&&remoteOptions[col.source];if(src){var h2=src.find(function(o){return String(o.value)===String(v);});if(h2)return h2.label;}if(v==null||v==='')return '—';var s=String(v);return /^\d{4}-\d{2}-\d{2}/.test(s)?s.slice(0,10):s;}
function optionsOf(f){return f.options||remoteOptions[f.source]||[];}
async function loadRemote(){var srcs={customers:'/api/v1/crm/customers',products:'/api/v1/inventory/products',orders:'/api/v1/sales/orders',groups:'/api/v1/crm/customer-groups',suppliers:'/api/v1/purchase/suppliers',warehouses:'/api/v1/inventory/warehouses'};var used=formFields.filter(function(f){return f.source;}).map(function(f){return f.source;});await Promise.all(used.map(async function(s){if(remoteOptions[s])return;try{var d=await mockGet(srcs[s]||API,{pageSize:200});var list=Array.isArray(d)?d:(d&&d.list)||[];remoteOptions[s]=list.map(function(x){return {label:x.name||x.code||x.title||('#'+x.id),value:x.id};});}catch(e){remoteOptions[s]=[];}}));}
async function load(){loading.value=true;try{var d=await mockGet(API,{page:page.value,pageSize:pageSize.value,keyword:q.keyword,status:q.status});rows.value=Array.isArray(d)?d:(d&&d.list)||[];total.value=Number((d&&d.total)||rows.value.length);}catch(e){toast.error((e&&e.message)||'加载失败');rows.value=[];}finally{loading.value=false;}}
function reload(){page.value=1;load();}
function resetQuery(){q.keyword='';q.status='';reload();}
function resetForm(){Object.keys(form).forEach(function(k){delete form[k];});formFields.forEach(function(f){form[f.prop]=DEFAULTS[f.prop]!==undefined?DEFAULTS[f.prop]:(f.type==='number'?0:'');});}
var DEFAULTS={"status":1,"qty":0,"amount":0,"bizAmount":0};
function openForm(row?:any){editing.value=row||null;resetForm();if(row)formFields.forEach(function(f){if(row[f.prop]!==undefined)form[f.prop]=row[f.prop];});formVisible.value=true;}
async function save(){for(var i=0;i<formFields.length;i++){var f=formFields[i];if(f.required&&(form[f.prop]===''||form[f.prop]==null)){toast.warning('请填写「'+f.label+'」');return;}}saving.value=true;try{var payload={};formFields.forEach(function(f){payload[f.prop]=form[f.prop];});if(editing.value&&editing.value.id)await mockPatch(API+'/'+editing.value.id,payload);else await mockPost(API,payload);toast.success(editing.value?'已保存':'已创建');formVisible.value=false;await load();}catch(e){toast.error((e&&e.message)||'保存失败');}finally{saving.value=false;}}
function actionsOf(row){return actions.filter(function(a){return !a.from||a.from.some(function(s){return Number(s)===Number(row.status);});});}
function colorOf(a){return a.variant==='danger'?'var(--ds-danger)':a.variant==='warning'?'var(--ds-warning)':'var(--ds-brand)';}
async function runAction(row,a){if(!await uiConfirm('确定执行「'+a.label+'」吗？','业务确认'))return;try{var res=await mockPost('/_biz/action/'+COLLECTION+'/'+row.id+'/'+a.key,{label:a.label});toast.success((res&&res.message)||(a.label+'成功'));await load();}catch(e){toast.error((e&&e.message)||'操作失败');}}
async function removeRow(row){if(!await uiConfirm('确定删除 #'+row.id+' 吗？','删除确认'))return;try{await mockDel(API+'/'+row.id);toast.success('已删除');await load();}catch(e){toast.error((e&&e.message)||'删除失败');}}
function exportCsv(){var head=columns.map(function(c){return c.label;});var lines=[head.join(',')].concat(rows.value.map(function(r){return columns.map(function(c){return String(display(r,c)).replace(/,/g,' ');}).join(',');}));var blob=new Blob(['\ufeff'+lines.join('\n')],{type:'text/csv;charset=utf-8'});var a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='出勤率.csv';a.click();}
onMounted(function(){load();if(!isReport)loadRemote();});
const PAL=['#5b8cff','#7c5cff','#0e9f8a','#ff8a3d','#e11d48','#2563eb','#0891b2','#16a34a'];function lc(i){return PAL[((i%PAL.length)+PAL.length)%PAL.length];}
var heat=Array.from({length:35},function(_,i){return {i:i,v:(i*7+13)%5};});
</script>

<style scoped>
.r-page{padding:16px}.r-head{display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:12px}.r-kicker{font-size:11px;letter-spacing:1px;font-weight:700;margin-bottom:4px}.r-head h2{margin:0;font-size:20px}.r-actions{display:flex;gap:8px}.r-stats{display:flex;gap:12px;margin-bottom:14px}.r-stat{flex:1;background:var(--ds-bg-soft);border-left:3px solid;border-radius:8px;padding:10px 14px;display:flex;flex-direction:column;gap:4px}.r-stat span{font-size:12px;color:var(--ds-text-3)}.r-stat b{font-size:20px}.r-search{display:flex;gap:8px;margin-bottom:12px}.r-search input{min-width:200px}.r-empty{text-align:center;color:var(--ds-text-3);padding:36px}.r-pager{display:flex;justify-content:flex-end;padding:12px}.r-strong{font-weight:700}.r-tag{font-size:11px;padding:2px 8px;border-radius:10px;white-space:nowrap}.r-badge{font-size:11px;padding:2px 8px;border-radius:10px}.r-table{overflow:auto}.r-table table{width:100%;border-collapse:collapse;font-size:13px}.r-table th,.r-table td{border:1px solid var(--ds-divider);padding:8px 10px;text-align:left}.r-table th{background:var(--ds-bg-soft)}.r-form{display:grid;grid-template-columns:1fr 1fr;gap:14px}.r-field{display:flex;flex-direction:column;gap:5px;font-size:13px}.r-field i{color:var(--ds-danger);font-style:normal}.r-foot{display:flex;justify-content:flex-end;gap:8px}
.r-heat{background:var(--ds-card);border-radius:10px;padding:16px}.r-heat-head{display:flex;justify-content:space-between;margin-bottom:14px}.r-heat-head span{color:var(--ds-text-3);font-size:12px}.r-heat-grid{display:grid;grid-template-columns:repeat(7,1fr);gap:5px;max-width:420px}.r-heat-cell{aspect-ratio:1;background:#0e9f8a;border-radius:3px}.r-legend{margin-top:12px;font-size:12px;color:var(--ds-text-3);display:flex;align-items:center;gap:4px}.r-legend i{width:12px;height:12px;background:#0e9f8a;border-radius:2px}
</style>
