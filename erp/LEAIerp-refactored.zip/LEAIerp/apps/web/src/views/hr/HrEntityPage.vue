<template><SalesEntityPage :key="key" :config="config" /></template>
<script setup lang="ts">
import { computed } from 'vue';
import { useRoute } from 'vue-router';
import SalesEntityPage from '../sales/SalesEntityPage.vue';
import { hrConfigFor } from './hrConfigs';

const route = useRoute();
const key = computed(() => route.path.split('/').filter(Boolean)[1] || 'employees');
const config = computed(() => hrConfigFor(key.value));
</script>
