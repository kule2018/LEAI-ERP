<!-- 招聘闭环：招聘需求 → 候选人 → 面试 → 录用 → 入职，支持 AI 简历解析 -->
<template>
  <div class="rec-page">
    <DsCard title="招聘需求" :pad="false">
      <template #extra><DsButton variant="primary" size="sm" @click="addDemand">新增需求</DsButton></template>
      <div class="rec-demands">
        <div v-for="d in demands" :key="d.id" class="rec-demand" :class="{ active: current === d.id }" @click="current = d.id">
          <b>{{ d.title }}</b><span>{{ d.dept }} · 需求 {{ d.count }} 人</span>
          <DsTag :color="d.status === 'OPEN' ? 'success' : 'neutral'" size="sm">{{ d.status === 'OPEN' ? '招聘中' : '已关闭' }}</DsTag>
        </div>
      </div>
    </DsCard>

    <DsCard title="候选人与面试流程" :pad="false" class="rec-gap">
      <template #extra><DsButton size="sm" @click="parseOpen = true">🤖 AI 简历解析</DsButton></template>
      <table class="rec-table">
        <thead><tr><th>候选人</th><th>应聘岗位</th><th>阶段</th><th>面试评价</th><th>操作</th></tr></thead>
        <tbody>
          <tr v-for="c in filteredCandidates" :key="c.id">
            <td>{{ c.name }}<small>{{ c.phone }}</small></td><td>{{ c.position }}</td>
            <td><DsTag color="brand" size="sm">{{ stageText(c.stage) }}</DsTag></td>
            <td>{{ c.feedback || '-' }}</td>
            <td><DsButton size="sm" variant="text" @click="advance(c)">推进到 {{ nextStage(c) }}</DsButton></td>
          </tr>
          <tr v-if="!filteredCandidates.length"><td colspan="5" class="rec-empty">该需求暂无候选人</td></tr>
        </tbody>
      </table>
    </DsCard>

    <DsModal v-model="parseOpen" title="AI 简历解析（结果需人工确认）" :width="560">
      <textarea v-model="resumeText" class="ds-input" rows="8" placeholder="粘贴简历文本，包含姓名、电话、技能、工作年限…" />
      <div v-if="parsed" class="rec-parsed"><pre>{{ parsed }}</pre></div>
      <template #footer><div class="rec-foot"><DsButton @click="parseOpen = false">关闭</DsButton><DsButton variant="primary" @click="parse">解析并加入候选人</DsButton></div></template>
    </DsModal>
  </div>
</template>

<script setup lang="ts">
/** 招聘闭环：需求驱动的候选人阶段流转，AI 简历解析只做预填需人工确认 */
import { computed, onMounted, reactive, ref } from 'vue';
import { DsButton, DsCard, DsModal, DsTag } from '../../components';
import { aiApi } from '../../api';
import { mockGet, mockPost } from '../../api/mockAdapter';
import { useToast } from '../../components/ds/toast';
import { prompt as uiPrompt } from '../../components/ds/usePrompt';

const toast = useToast();
const demands = ref<any[]>([]);
const candidates = ref<any[]>([]);
const current = ref(0);
const parseOpen = ref(false);
const resumeText = ref('');
const parsed = reactive<any>({});
const STAGES = ['NEW', 'INTERVIEW', 'OFFER', 'HIRED'];
const stageLabels: Record<string, string> = { NEW: '待筛选', INTERVIEW: '面试中', OFFER: '已发 Offer', HIRED: '已入职' };

const filteredCandidates = computed(() => candidates.value.filter((c) => c.demandId === current.value));
function stageText(stage: string): string { return stageLabels[stage] || stage; }
function nextStage(c: any): string { return stageLabels[STAGES[Math.min(STAGES.length - 1, STAGES.indexOf(c.stage) + 1)]]; }
async function advance(c: any): Promise<void> {
  const index = Math.min(STAGES.length - 1, STAGES.indexOf(c.stage) + 1);
  c.stage = STAGES[index];
  await mockPost('/api/v1/hr/candidates/' + c.id + '/advance', { stage: c.stage });
  toast.success(`已推进到「${stageText(c.stage)}」`);
}
async function addDemand(): Promise<void> {
  const title = await uiPrompt('请输入岗位名称', '销售经理', '新增招聘需求');
  if (!title) return;
  const demand = { id: Date.now(), title, dept: '销售部', count: 1, status: 'OPEN' };
  demands.value.push(demand);
  current.value = demand.id;
  mockPost('/api/v1/hr/recruitments', demand);
  toast.success('招聘需求已创建');
}
/** AI 解析简历：结果填入候选人列表，并可人工修改 */
async function parse(): Promise<void> {
  if (!resumeText.value) { toast.warning('请粘贴简历文本'); return; }
  try {
    const result: any = await aiApi.resumeParse(resumeText.value);
    Object.keys(parsed).forEach((k) => delete parsed[k]);
    Object.assign(parsed, result);
    candidates.value.push({ id: Date.now(), demandId: current.value, name: result.name || '待确认', phone: result.phone || '', position: demands.value.find((d) => d.id === current.value)?.title || '', stage: 'NEW', feedback: `技能：${result.skills || '-'}；经验：${result.experience || '-'}` });
    toast.success('解析完成，已加入候选人列表');
  } catch { toast.error('解析失败，请稍后重试'); }
}
onMounted(async () => {
  const [d, c]: any[] = await Promise.all([
    mockGet('/api/v1/hr/recruitments', { pageSize: 100 }),
    mockGet('/api/v1/hr/candidates', { pageSize: 100 }),
  ]);
  demands.value = Array.isArray(d) ? d : d?.list || [];
  candidates.value = Array.isArray(c) ? c : c?.list || [];
  if (!demands.value.length) {
    demands.value = [{ id: 1, title: '销售经理', dept: '销售部', count: 2, status: 'OPEN' }, { id: 2, title: '仓管员', dept: '仓储部', count: 1, status: 'OPEN' }];
    candidates.value = [{ id: 1, demandId: 1, name: '张三', phone: '13800138000', position: '销售经理', stage: 'INTERVIEW', feedback: '沟通良好，有行业经验' }];
  }
  current.value = demands.value[0].id;
});
</script>

<style scoped>
.rec-page { padding: 16px; }
.rec-demands { display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; padding: 12px; }
.rec-demand { border: 1px solid var(--ds-border); border-radius: 8px; padding: 10px 12px; cursor: pointer; display: flex; flex-direction: column; gap: 4px; font-size: 13px; }
.rec-demand.active { border-color: var(--ds-brand); background: var(--ds-brand-soft); }
.rec-demand span { color: var(--ds-text-3); font-size: 12px; }
.rec-gap { margin-top: 12px; }
.rec-table { width: 100%; border-collapse: collapse; font-size: 13px; }
.rec-table th, .rec-table td { padding: 9px 12px; border-bottom: 1px solid var(--ds-divider); text-align: left; }
.rec-table th { background: var(--ds-bg-soft); color: var(--ds-text-3); font-weight: 500; }
.rec-table small { display: block; color: var(--ds-text-3); }
.rec-empty { text-align: center; padding: 24px; color: var(--ds-text-3); }
.rec-parsed pre { margin: 12px 0 0; padding: 10px; background: var(--ds-bg-soft); border-radius: 6px; font-size: 12px; }
.rec-foot { display: flex; justify-content: flex-end; gap: 8px; }
</style>
