<template><RecordPage :config="page" /></template>

<script setup lang="ts">
import RecordPage from '../records/RecordPage.vue';
import type { RecordPageConfig } from '../records/records';

const page: RecordPageConfig = {
  title: '维保记录',
  resource: 'hr/vehicle-maintains',
  schema: 'hrVehicleMaintains',
  filters: ['plateNo', 'type', 'nextDate'],
  required: ['plateNo', 'maintainDate', 'type'],
  metrics: ['amount'],
};
</script>
