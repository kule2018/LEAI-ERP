<template><RecordPage :config="page" /></template>

<script setup lang="ts">
import RecordPage from '../records/RecordPage.vue';
import type { RecordPageConfig } from '../records/records';

const page: RecordPageConfig = {
  title: '用车申请',
  resource: 'hr/vehicle-uses',
  schema: 'hrVehicleUses',
  filters: ['plateNo', 'useDate', 'status'],
  required: ['useNo', 'applicant', 'plateNo', 'destination', 'useDate'],
};
</script>
