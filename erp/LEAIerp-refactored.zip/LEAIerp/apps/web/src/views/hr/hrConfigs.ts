/** 人事行政 15 个页面的独立字段、表单、状态与业务动作配置。 */
import type { SalesAction, SalesConfig, SalesField } from '../sales/salesConfigs';

const MASTER = { '0': '停用', '1': '启用' };
const DOC = { '0': '待提交', '1': '处理中', '2': '已通过', '3': '已完成', '4': '不通过', '9': '已作废' };
const LEAVE = { '0': '待提交', '1': '待审批', '2': '已批准', '4': '已驳回' };
const PAYROLL = { '0': '待核算', '1': '待发放', '2': '已发放' };
const CANDIDATE = { '0': '待筛选', '1': '待面试', '2': '复试中', '3': '已录用', '4': '不合适' };

const docActions: SalesAction[] = [
  { key: 'submit', label: '提交', variant: 'primary', from: [0] },
  { key: 'approve', label: '审核通过', variant: 'primary', from: [1] },
  { key: 'reject', label: '驳回', variant: 'danger', from: [1] },
];
const payrollActions: SalesAction[] = [
  { key: 'submit', label: '提交核算', variant: 'primary', from: [0] },
  { key: 'approve', label: '确认发放', variant: 'primary', from: [1] },
  { key: 'reject', label: '退回重算', variant: 'danger', from: [1] },
];
const candidateActions: SalesAction[] = [
  { key: 'submit', label: '进入面试', variant: 'primary', from: [0] },
  { key: 'review', label: '安排复试', variant: 'primary', from: [1] },
  { key: 'approve', label: '录用', variant: 'primary', from: [2] },
  { key: 'reject', label: '淘汰', variant: 'danger', from: [0, 1, 2] },
];
const assetActions: SalesAction[] = [
  { key: 'submit', label: '提交领用', variant: 'primary', from: [0] },
  { key: 'approve', label: '同意领用', variant: 'primary', from: [1] },
  { key: 'archive', label: '归还归档', variant: 'warning', from: [2] },
];
const masterActions: SalesAction[] = [
  { key: 'toggle', label: '停用', variant: 'warning', from: [1] },
  { key: 'enable', label: '启用', variant: 'primary', from: [0] },
  { key: 'copy', label: '复制' },
];

const f = (prop: string, label: string, type?: SalesField['type'], required?: boolean): SalesField => ({ prop, label, type, required });
const sel = (prop: string, label: string, values: string[]): SalesField => ({
  prop, label, type: 'select', options: values.map((v) => ({ label: v, value: v })),
});

type Kind = 'master' | 'flow' | 'report';
interface Def {
  key: string; title: string; collection: string; layout: NonNullable<SalesConfig['layout']>;
  kind: Kind; codeLabel: string; nameLabel: string; extra: SalesField[];
  actions?: SalesAction[]; labels?: Record<string, string>;
}

const DEFS: Def[] = [
  { key: 'companies', title: '公司', collection: 'hrCompanies', layout: 'people', kind: 'master', codeLabel: '公司编码', nameLabel: '公司名称', extra: [f('partner', '所在城市'), f('bizText', '统一社会信用代码'), f('bizDate', '成立日期', 'date')], actions: masterActions },
  { key: 'departments', title: '部门', collection: 'hrDepartments', layout: 'people', kind: 'master', codeLabel: '部门编码', nameLabel: '部门名称', extra: [f('partner', '所属公司'), f('bizText', '部门负责人'), f('bizDate', '成立日期', 'date')], actions: masterActions },
  { key: 'positions', title: '岗位', collection: 'hrPositions', layout: 'people', kind: 'master', codeLabel: '岗位编码', nameLabel: '岗位名称', extra: [f('partner', '所属部门'), f('bizText', '职级'), f('qty', '编制人数', 'number')], actions: masterActions },
  { key: 'shifts', title: '班次', collection: 'hrShifts', layout: 'calendar', kind: 'master', codeLabel: '班次编码', nameLabel: '班次名称', extra: [f('partner', '适用部门'), f('bizText', '上班时间'), f('bizText2', '下班时间'), f('bizDate', '生效日期', 'date')], actions: masterActions },
  { key: 'employees', title: '雇员', collection: 'hrEmployees', layout: 'people', kind: 'master', codeLabel: '工号', nameLabel: '员工姓名', extra: [f('partner', '所属部门'), f('bizText', '岗位'), f('bizDate', '入职日期', 'date'), f('bizAmount', '月薪', 'number')], actions: masterActions },
  { key: 'attendance', title: '出勤率', collection: 'hrAttendance', layout: 'analytics', kind: 'report', codeLabel: '考勤编号', nameLabel: '考勤日期', extra: [f('partner', '员工'), f('qty', '出勤工时', 'number'), sel('bizText', '出勤状态', ['正常', '迟到', '缺卡', '请假']), f('docDate', '考勤日期', 'date')] },
  { key: 'leaves', title: '请假', collection: 'hrLeaves', layout: 'calendar', kind: 'flow', codeLabel: '请假单号', nameLabel: '请假事由', extra: [f('partner', '员工'), sel('bizText', '请假类型', ['年假', '事假', '病假', '婚假']), f('bizDate', '开始日期', 'date'), f('bizAmount', '请假天数', 'number'), f('docDate', '申请日期', 'date')], actions: docActions, labels: LEAVE },
  { key: 'holidays', title: '节假日', collection: 'hrHolidays', layout: 'calendar', kind: 'master', codeLabel: '节日编码', nameLabel: '节日名称', extra: [f('partner', '适用范围'), f('bizText', '节假日类型'), f('bizDate', '放假日期', 'date')], actions: masterActions },
  { key: 'payrolls', title: '工资单', collection: 'hrPayrolls', layout: 'workflow', kind: 'flow', codeLabel: '工资单号', nameLabel: '薪资期间', extra: [f('partner', '员工'), f('amount', '实发工资', 'number', true), f('bizText', '薪资说明'), f('bizAmount', '社保扣款', 'number'), f('docDate', '核算日期', 'date')], actions: payrollActions, labels: PAYROLL },
  { key: 'contracts', title: '合约', collection: 'hrContracts', layout: 'workflow', kind: 'flow', codeLabel: '合同编号', nameLabel: '合同名称', extra: [f('partner', '员工'), sel('bizText', '合同类型', ['劳动合同', '保密协议', '实习协议']), f('bizDate', '到期日期', 'date'), f('docDate', '签订日期', 'date')], actions: docActions },
  { key: 'recruitments', title: '招聘管理', collection: 'hrRecruitments', layout: 'workflow', kind: 'flow', codeLabel: '招聘编号', nameLabel: '招聘岗位', extra: [f('partner', '用人部门'), f('qty', '需求人数', 'number'), f('bizDate', '期望到岗日', 'date'), sel('bizText', '招聘渠道', ['社会招聘', '校园招聘', '内部推荐']), f('docDate', '发起日期', 'date')], actions: docActions },
  { key: 'candidates', title: '候选人', collection: 'hrCandidates', layout: 'kanban', kind: 'flow', codeLabel: '候选人编号', nameLabel: '候选人姓名', extra: [f('partner', '应聘岗位'), sel('bizText', '最高学历', ['大专', '本科', '硕士', '博士']), f('bizDate', '投递日期', 'date'), f('docDate', '登记日期', 'date')], actions: candidateActions, labels: CANDIDATE },
  { key: 'interviews', title: '面试', collection: 'hrInterviews', layout: 'calendar', kind: 'flow', codeLabel: '面试编号', nameLabel: '候选人', extra: [f('partner', '面试官'), f('bizDate', '面试时间', 'date'), sel('bizText', '面试结果', ['通过', '待定', '不通过']), f('docDate', '安排日期', 'date')], actions: docActions },
  { key: 'assets', title: '资产领用', collection: 'hrAssets', layout: 'equipment', kind: 'flow', codeLabel: '资产编号', nameLabel: '资产名称', extra: [f('partner', '领用人'), f('qty', '领用数量', 'number'), f('amount', '资产价值', 'number'), sel('bizText', '资产类别', ['办公设备', '办公用品', '电子设备']), f('bizDate', '领用日期', 'date')], actions: assetActions },
  { key: 'vehicles', title: '车辆管理', collection: 'hrVehicles', layout: 'equipment', kind: 'master', codeLabel: '车牌号', nameLabel: '车辆名称', extra: [f('partner', '使用部门'), f('amount', '购置金额', 'number'), sel('bizText', '车辆类型', ['商务车', '轿车', '货车']), f('bizDate', '购置日期', 'date')], actions: masterActions },
];

function build(d: Def): SalesConfig {
  const base: SalesField[] = [f('code', d.codeLabel, undefined, true), f('name', d.nameLabel, undefined, true)];
  const labels = d.labels || (d.kind === 'flow' ? DOC : MASTER);
  const status: SalesField = {
    prop: 'status', label: '状态', type: 'select',
    options: Object.entries(labels).map(([k, v]) => ({ label: v, value: Number(k) })),
  };
  const isReport = d.kind === 'report';
  return {
    title: d.title,
    api: `/api/v1/hr/${d.key}`,
    collection: d.collection,
    columns: [...base, ...d.extra, ...(isReport ? [] : [status])],
    fields: [...base, ...d.extra, f('remark', '备注', 'textarea'), ...(isReport ? [] : [status])],
    statusField: 'status',
    statusLabels: labels,
    actions: isReport ? [] : (d.actions || masterActions),
    readOnly: isReport,
    layout: d.layout,
    defaults: () => ({ status: d.kind === 'flow' ? 0 : 1, qty: 0, amount: 0, bizAmount: 0 }),
  };
}

export const HR_CONFIGS: Record<string, SalesConfig> = Object.fromEntries(DEFS.map((d) => [d.key, build(d)]));
export function hrConfigFor(key: string): SalesConfig {
  const c = HR_CONFIGS[key];
  if (!c) throw new Error(`未知人事页面配置：${key}`);
  return c;
}
