<!-- 服装多规格 SKU 运营中心：属性集→笛卡尔积生成 SKU→矩阵维护→批量改价/调库存→条码打印 -->
<template>
  <div class="skux-page">
    <div class="skux-stats">
      <div v-for="c in stats" :key="c.label" class="skux-stat"><span>{{ c.label }}</span><b :class="c.tone">{{ c.value }}</b></div>
    </div>

    <DsCard title="款式与属性集" :pad="false">
      <div class="skux-body">
        <div class="skux-setup">
          <label class="skux-field"><span>商品款式</span>
            <select v-model="styleId" class="ds-input" @change="loadSkus">
              <option v-for="s in styles" :key="s.id" :value="s.id">{{ s.name }}（{{ s.code }}）</option>
            </select>
          </label>
          <label class="skux-field skux-field--grow"><span>颜色集合（逗号分隔）</span><input v-model="colorsText" class="ds-input" placeholder="黑,白,红" /></label>
          <label class="skux-field skux-field--grow"><span>尺码集合（逗号分隔）</span><input v-model="sizesText" class="ds-input" placeholder="S,M,L,XL" /></label>
          <DsButton variant="primary" @click="generateSkus">生成 SKU</DsButton>
        </div>
        <div class="skux-hint">按「颜色 × 尺码」笛卡尔积生成 SKU，每个 SKU 独立条码、价格、库存；已存在的 SKU 不会重复生成。</div>
      </div>
    </DsCard>

    <DsCard title="SKU 运营矩阵" :pad="false">
      <template #extra>
        <div class="skux-tools">
          <input v-model="keyword" class="ds-input" placeholder="SKU编码/条码搜索" />
          <DsButton size="sm" @click="batchVisible = true" :disabled="!selected.length">批量改价/调库存（{{ selected.length }}）</DsButton>
          <DsButton size="sm" @click="printLabels" :disabled="!selected.length">打印条码标签</DsButton>
          <DsButton size="sm" @click="syncProduct">同步到商品档案</DsButton>
          <DsButton size="sm" @click="$router.push('/inventory/variants')">打开 SKU 中心</DsButton>
        </div>
      </template>
      <div class="skux-body">
        <table class="skux-table">
          <thead><tr><th><input type="checkbox" :checked="allSelected" @change="toggleAll" /></th><th>SKU 编码</th><th>条码</th><th>颜色</th><th>尺码</th><th>售价</th><th>成本</th><th>库存</th><th>状态</th><th>操作</th></tr></thead>
          <tbody>
            <tr v-for="s in filteredSkus" :key="s.skuCode">
              <td><input type="checkbox" :checked="selected.includes(s.skuCode)" @change="toggleOne(s.skuCode)" /></td>
              <td>{{ s.skuCode }}</td><td>{{ s.barcode }}</td><td>{{ s.color }}</td><td>{{ s.size }}</td>
              <td>¥{{ Number(s.price).toFixed(2) }}</td><td>¥{{ Number(s.cost).toFixed(2) }}</td>
              <td :class="{ 'skux-low': Number(s.stock) <= 10 }">{{ s.stock }}</td>
              <td><DsTag :color="s.status === '在售' ? 'success' : 'neutral'" size="sm">{{ s.status }}</DsTag></td>
              <td><DsButton size="sm" @click="editSku(s)">编辑</DsButton></td>
            </tr>
            <tr v-if="!filteredSkus.length"><td colspan="10" class="skux-empty">暂无 SKU，请先在上方生成</td></tr>
          </tbody>
        </table>
      </div>
    </DsCard>

    <!-- 编辑 SKU -->
    <DsModal v-model="editVisible" title="编辑 SKU" :width="440">
      <div v-if="editing" class="skux-form">
        <label><span>SKU 编码</span><input v-model="editing.skuCode" class="ds-input" disabled /></label>
        <label><span>条码</span><input v-model="editing.barcode" class="ds-input" /></label>
        <label><span>售价</span><input v-model.number="editing.price" class="ds-input" type="number" /></label>
        <label><span>成本</span><input v-model.number="editing.cost" class="ds-input" type="number" /></label>
        <label><span>库存</span><input v-model.number="editing.stock" class="ds-input" type="number" /></label>
        <label><span>状态</span><select v-model="editing.status" class="ds-input"><option>在售</option><option>下架</option></select></label>
      </div>
      <template #footer><div class="skux-foot"><DsButton @click="editVisible = false">取消</DsButton><DsButton variant="primary" @click="saveSku">保存</DsButton></div></template>
    </DsModal>

    <!-- 批量操作 -->
    <DsModal v-model="batchVisible" title="批量改价 / 调库存" :width="440">
      <div class="skux-form">
        <label><span>操作类型</span><select v-model="batch.action" class="ds-input"><option>按比例调价</option><option>固定加价</option><option>调整库存</option></select></label>
        <label><span>数值</span><input v-model.number="batch.value" class="ds-input" type="number" /></label>
        <div class="skux-hint">按比例调价：0.9 表示打 9 折，1.1 表示提价 10%；固定加价直接增加金额；调整库存为增量（可为负）。</div>
      </div>
      <template #footer><div class="skux-foot"><DsButton @click="batchVisible = false">取消</DsButton><DsButton variant="primary" @click="applyBatch">应用</DsButton></div></template>
    </DsModal>
  </div>
</template>

<script setup lang="ts">
/** 服装多规格：属性集笛卡尔积生成 SKU，矩阵化维护条码/价格/库存，支持批量运营。 */
import { computed, onMounted, reactive, ref } from 'vue';
import { useRouter } from 'vue-router';
import { DsButton, DsCard, DsModal, DsTag } from '../../components';
import { mockGet, mockPost } from '../../api/mockAdapter';
import { emit, Events } from '../../utils/eventBus';
import { useToast } from '../../components/ds/toast';

interface Sku { id?: number; styleId: number; skuCode: string; barcode: string; color: string; size: string; price: number; cost: number; stock: number; status: string; }
interface Style { id: number; name: string; code: string; }

const toast = useToast();
const router = useRouter();
const styles = ref<Style[]>([
  { id: 1, name: '纯棉圆领T恤', code: 'TSHIRT' },
  { id: 2, name: '修身牛仔裤', code: 'JEANS' },
  { id: 3, name: '连帽卫衣', code: 'HOODIE' },
]);
const styleId = ref<number>(1);
const colorsText = ref('黑,白,红');
const sizesText = ref('S,M,L,XL');
const skus = ref<Sku[]>([]);
const keyword = ref('');
const selected = ref<string[]>([]);
const editVisible = ref(false);
const editing = ref<Sku | null>(null);
const batchVisible = ref(false);
const batch = reactive<any>({ action: '按比例调价', value: 1 });

const currentStyle = computed(() => styles.value.find((s) => s.id === styleId.value));
const styleSkus = computed(() => skus.value.filter((s) => s.styleId === styleId.value));
const filteredSkus = computed(() => {
  const kw = keyword.value.trim().toLowerCase();
  return styleSkus.value.filter((s) => !kw || s.skuCode.toLowerCase().includes(kw) || s.barcode.includes(kw));
});
const allSelected = computed(() => filteredSkus.value.length > 0 && filteredSkus.value.every((s) => selected.value.includes(s.skuCode)));
const stats = computed(() => [
  { label: 'SKU 总数', value: String(styleSkus.value.length), tone: '' },
  { label: '在售 SKU', value: String(styleSkus.value.filter((s) => s.status === '在售').length), tone: 'skux-brand' },
  { label: '库存预警(≤10)', value: String(styleSkus.value.filter((s) => Number(s.stock) <= 10).length), tone: 'skux-danger' },
  { label: '总库存', value: String(styleSkus.value.reduce((s, x) => s + Number(x.stock || 0), 0)), tone: '' },
]);

async function loadSkus(): Promise<void> {
  const r: any = await mockGet('/api/v1/industry/apparelSkus', { pageSize: 500 });
  skus.value = Array.isArray(r) ? r : r?.list || [];
  selected.value = [];
}
/** 笛卡尔积：颜色×尺码生成 SKU；按 skuCode 去重，避免重复生成覆盖人工维护的价格/库存 */
async function generateSkus(): Promise<void> {
  const colors = colorsText.value.split(/[,，]/).map((s) => s.trim()).filter(Boolean);
  const sizes = sizesText.value.split(/[,，]/).map((s) => s.trim()).filter(Boolean);
  if (!colors.length || !sizes.length) { toast.warning('请填写颜色与尺码集合'); return; }
  const prefix = currentStyle.value?.code || 'SKU';
  const existing = new Set(skus.value.map((s) => s.skuCode));
  let created = 0;
  for (const color of colors) {
    for (const size of sizes) {
      const skuCode = `${prefix}-${color}-${size}`;
      if (existing.has(skuCode)) continue;
      const sku: Sku = {
        id: Date.now() + Math.floor(Math.random() * 100000), styleId: styleId.value, skuCode,
        barcode: String(6900000000000 + Math.floor(Math.random() * 99999999)).slice(0, 13),
        color, size, price: 199, cost: 80, stock: 0, status: '在售',
      };
      const saved: any = await mockPost('/api/v1/industry/apparelSkus', sku);
      skus.value.push({ ...sku, id: saved?.id || sku.id }); created++;
    }
  }
  toast[created ? 'success' : 'warning'](created ? `已生成 ${created} 个 SKU` : 'SKU 已存在，未重复生成');
}
function toggleAll(e: Event): void {
  const on = (e.target as HTMLInputElement).checked;
  selected.value = on ? filteredSkus.value.map((s) => s.skuCode) : [];
}
function toggleOne(code: string): void {
  selected.value = selected.value.includes(code) ? selected.value.filter((c) => c !== code) : [...selected.value, code];
}
function editSku(s: Sku): void { editing.value = { ...s }; editVisible.value = true; }
async function saveSku(): Promise<void> {
  if (!editing.value) return;
  const idx = skus.value.findIndex((s) => s.skuCode === editing.value!.skuCode);
  if (idx >= 0) skus.value[idx] = { ...editing.value };
  await mockPost('/api/v1/industry/apparelSkus', { ...editing.value });
  editVisible.value = false; toast.success('SKU 已保存');
}
/** 批量运营：按比例/固定改价、库存增减，写回每张 SKU */
async function applyBatch(): Promise<void> {
  const val = Number(batch.value || 0);
  if (!val) { toast.warning('请输入有效数值'); return; }
  for (const s of skus.value.filter((x) => selected.value.includes(x.skuCode))) {
    if (batch.action === '按比例调价') s.price = Number((s.price * val).toFixed(2));
    else if (batch.action === '固定加价') s.price = Number((s.price + val).toFixed(2));
    else s.stock = Math.max(0, Number(s.stock) + val);
    await mockPost('/api/v1/industry/apparelSkus', { ...s });
  }
  batchVisible.value = false; toast.success(`已对 ${selected.value.length} 个 SKU 应用批量操作`);
}
function printLabels(): void {
  const list = skus.value.filter((s) => selected.value.includes(s.skuCode));
  emit(Events.PRINT_DONE, { type: 'SKU_LABEL', skus: list });
  toast.success(`已发送 ${list.length} 张条码标签到打印队列`);
}
async function syncProduct(): Promise<void> {
  const first = styleSkus.value[0];
  if (!first) { toast.warning('请先生成 SKU'); return; }
  await mockPost('/api/v1/inventory/products', { name: `${currentStyle.value?.name || '服装'}（多规格）`, code: `${currentStyle.value?.code || 'SKU'}-${Date.now().toString().slice(-6)}`, price: first.price, cost: first.cost, type: 2 });
  toast.success('已同步一条多规格商品到商品档案');
}
onMounted(loadSkus);
</script>

<style scoped>
.skux-page { display: flex; flex-direction: column; gap: 14px; padding: 16px; }
.skux-stats { display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px; }
.skux-stat { border: 1px solid var(--ds-border); border-radius: 10px; padding: 14px 16px; background: var(--ds-bg-elevated); display: flex; flex-direction: column; gap: 6px; }
.skux-stat span { font-size: 12px; color: var(--ds-text-3); }
.skux-stat b { font-size: 22px; }
.skux-brand { color: var(--ds-brand); }
.skux-danger { color: var(--ds-danger); }
.skux-body { padding: 16px; display: flex; flex-direction: column; gap: 12px; }
.skux-setup { display: flex; align-items: flex-end; gap: 12px; flex-wrap: wrap; }
.skux-field { display: flex; flex-direction: column; gap: 5px; font-size: 12px; }
.skux-field--grow .ds-input { width: 220px; }
.skux-hint { font-size: 12px; color: var(--ds-text-3); }
.skux-tools { display: flex; gap: 8px; flex-wrap: wrap; }
.skux-table { width: 100%; border-collapse: collapse; font-size: 13px; }
.skux-table th, .skux-table td { padding: 9px 10px; border-bottom: 1px solid var(--ds-divider); text-align: left; }
.skux-table th { background: var(--ds-bg-soft); color: var(--ds-text-3); }
.skux-low { color: var(--ds-danger); font-weight: 700; }
.skux-empty { padding: 24px; text-align: center; color: var(--ds-text-3); }
.skux-form { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
.skux-form label { display: flex; flex-direction: column; gap: 5px; font-size: 12px; }
.skux-form .skux-hint { grid-column: 1 / -1; }
.skux-foot { display: flex; justify-content: flex-end; gap: 8px; }
@media (max-width: 1024px) { .skux-stats { grid-template-columns: repeat(2, 1fr); } .skux-table { font-size: 12px; } }
</style>
