<!-- 餐饮桌台与厨打中心：开台→点菜→厨打→结账→清台，完整状态机与营业流水 -->
<template>
  <div class="cat-page">
    <div class="cat-stats">
      <div v-for="c in stats" :key="c.label" class="cat-stat"><span>{{ c.label }}</span><b :class="c.tone">{{ c.value }}</b></div>
    </div>

    <div class="cat-main">
      <DsCard title="桌台状态" :pad="false">
        <template #extra><DsButton size="sm" @click="showTicket = true">厨打任务（{{ pendingTickets }}）</DsButton></template>
        <div class="cat-body">
          <div class="cat-tables">
            <div v-for="t in tables" :key="t.no" class="cat-table" :class="'st-' + t.status" @click="openTable(t)">
              <b>{{ t.no }}</b>
              <span class="cat-table__st">{{ statusText(t.status) }}</span>
              <span class="cat-table__meta">{{ t.status === '空闲' ? '可开台' : `${t.guests} 位 · ¥${tableAmount(t).toFixed(0)}` }}</span>
            </div>
          </div>
          <div class="cat-legend">
            <span><i class="dot st-idle"></i>空闲</span><span><i class="dot st-open"></i>已开台</span>
            <span><i class="dot st-ordered"></i>已下单</span><span><i class="dot st-billing"></i>待结账</span>
          </div>
        </div>
      </DsCard>

      <DsCard title="营业流水" :pad="false">
        <template #extra><input v-model="keyword" class="ds-input" placeholder="按桌号查询" /></template>
        <div class="cat-body">
          <table class="cat-table-grid">
            <thead><tr><th>单号</th><th>桌号</th><th>人数</th><th>应收</th><th>支付</th><th>结账时间</th></tr></thead>
            <tbody>
              <tr v-for="o in filteredOrders" :key="o.id"><td>{{ o.orderNo }}</td><td>{{ o.tableNo }}</td><td>{{ o.guests }}</td><td>¥{{ Number(o.payable).toFixed(2) }}</td><td>{{ o.payMethod }}</td><td>{{ o.createdAt }}</td></tr>
              <tr v-if="!filteredOrders.length"><td colspan="6" class="cat-empty">暂无结账记录</td></tr>
            </tbody>
          </table>
        </div>
      </DsCard>
    </div>

    <!-- 桌台详情：点菜/加菜/退菜/结账 -->
    <DsModal v-model="tableVisible" :title="`桌台 ${current?.no || ''} - ${statusText(current?.status || '空闲')}`" :width="720">
      <div v-if="current" class="cat-detail">
        <div class="cat-detail__head">
          <div class="cat-guests"><span>就餐人数</span><input v-model.number="current.guests" class="ds-input" type="number" min="1" /></div>
          <div class="cat-detail__ops">
            <DsButton v-if="current.status === '空闲'" size="sm" variant="primary" @click="openTableNow">开台</DsButton>
            <DsButton v-if="current.status !== '空闲'" size="sm" @click="switchTableVisible = true">换台</DsButton>
            <DsButton v-if="current.status !== '空闲'" size="sm" @click="clearTable">清台</DsButton>
          </div>
        </div>
        <div class="cat-menu">
          <div class="cat-menu__cats">
            <button v-for="cat in menuCats" :key="cat" class="cat-cat" :class="{ on: activeCat === cat }" @click="activeCat = cat">{{ cat }}</button>
          </div>
          <div class="cat-menu__list">
            <button v-for="d in menu.filter((m) => m.category === activeCat)" :key="d.id" class="cat-dish" @click="addDish(d)">
              <span>{{ d.name }}</span><b>¥{{ d.price }}</b>
            </button>
          </div>
        </div>
        <div class="cat-order">
          <div class="cat-order__title">已点菜品（{{ current.dishes.length }}）</div>
          <div v-for="(d, i) in current.dishes" :key="d.id" class="cat-order__line">
            <span>{{ d.name }}</span><span>¥{{ d.price }}</span>
            <div class="cat-order__qty"><button @click="dishQty(i, -1)">−</button><b>{{ d.qty }}</b><button @click="dishQty(i, 1)">+</button></div>
            <span>¥{{ (d.price * d.qty).toFixed(2) }}</span>
          </div>
          <div v-if="!current.dishes.length" class="cat-empty">尚未点菜</div>
          <div class="cat-order__sum">合计 ¥{{ tableAmount(current).toFixed(2) }}</div>
        </div>
      </div>
      <template #footer>
        <div class="cat-foot">
          <DsButton @click="sendKitchen" :disabled="!current?.dishes.length">发送厨打</DsButton>
          <DsButton variant="primary" :disabled="!current?.dishes.length" @click="checkoutVisible = true">结账</DsButton>
        </div>
      </template>
    </DsModal>

    <!-- 结账弹窗 -->
    <DsModal v-model="checkoutVisible" title="桌台结账" :width="460">
      <div v-if="current" class="cat-checkout">
        <div class="cat-checkout__row"><span>消费合计</span><b>¥{{ tableAmount(current).toFixed(2) }}</b></div>
        <label class="cat-checkout__row"><span>折扣（0.85~1）</span><input v-model.number="discount" class="ds-input" type="number" min="0.85" max="1" step="0.01" /></label>
        <label class="cat-checkout__row"><span>服务费</span><input v-model.number="serviceFee" class="ds-input" type="number" min="0" /></label>
        <div class="cat-checkout__methods">
          <button v-for="pm in payMethods" :key="pm" class="cat-pm" :class="{ on: payMethod === pm }" @click="payMethod = pm">{{ pm }}</button>
        </div>
        <label v-if="payMethod === '现金'" class="cat-checkout__row"><span>收款</span><input v-model.number="cash" class="ds-input" type="number" /></label>
        <div class="cat-checkout__row cat-checkout__total"><span>应收</span><b>¥{{ checkoutPayable.toFixed(2) }}</b></div>
        <div v-if="payMethod === '现金'" class="cat-checkout__row"><span>找零</span><b class="cat-change">¥{{ checkoutChange.toFixed(2) }}</b></div>
      </div>
      <template #footer><div class="cat-foot"><DsButton @click="checkoutVisible = false">取消</DsButton><DsButton variant="primary" @click="confirmCheckout">确认结账</DsButton></div></template>
    </DsModal>

    <!-- 换台弹窗 -->
    <DsModal v-model="switchTableVisible" title="换台" :width="380">
      <div class="cat-switch">将 <b>{{ current?.no }}</b> 换至：
        <div class="cat-switch__opts"><button v-for="t in tables.filter((x) => x.status === '空闲')" :key="t.no" class="cat-pm" @click="doSwitch(t)">{{ t.no }}</button></div>
        <div v-if="!tables.some((x) => x.status === '空闲')" class="cat-empty">暂无空闲桌台</div>
      </div>
    </DsModal>

    <!-- 厨打任务弹窗 -->
    <DsModal v-model="showTicket" title="厨打任务" :width="620">
      <div class="cat-tickets">
        <div v-for="t in tickets" :key="t.id" class="cat-ticket" :class="{ done: t.status === '已打印' }">
          <div class="cat-ticket__head"><b>{{ t.tableNo }} · {{ t.categoryName }}</b><DsTag :color="t.status === '已打印' ? 'success' : 'warning'" size="sm">{{ t.status }}</DsTag></div>
          <div v-for="d in t.dishes" :key="d.name" class="cat-ticket__line">{{ d.name }} ×{{ d.qty }}</div>
          <div class="cat-ticket__time">{{ t.createdAt }}</div>
        </div>
        <div v-if="!tickets.length" class="cat-empty">暂无厨打任务</div>
      </div>
      <template #footer><div class="cat-foot"><DsButton variant="primary" :disabled="!pendingTickets" @click="printAllTickets">全部打印</DsButton></div></template>
    </DsModal>
  </div>
</template>

<script setup lang="ts">
/** 餐饮中心：桌台状态机 + 点菜/退菜 + 厨打分单 + 折扣结账，驱动营业流水。 */
import { computed, onMounted, reactive, ref } from 'vue';
import { DsButton, DsCard, DsModal, DsTag } from '../../components';
import { mockGet, mockPost } from '../../api/mockAdapter';
import { emit, Events } from '../../utils/eventBus';
import { useToast } from '../../components/ds/toast';
import { confirm as uiConfirm } from '../../components/ds/useConfirm';

type TableStatus = '空闲' | '已开台' | '已下单' | '待结账';
interface Dish { id: number; name: string; price: number; category: string; categoryName: string; qty?: number; }
interface DiningTable { no: string; status: TableStatus; guests: number; dishes: Dish[]; }
interface KitchenTicket { id: number; tableNo: string; categoryName: string; dishes: { name: string; qty: number }[]; status: string; createdAt: string; }
interface CateringOrder { id: number; orderNo: string; tableNo: string; guests: number; payable: number; payMethod: string; createdAt: string; status: string; }

const toast = useToast();
const tables = ref<DiningTable[]>([]);
const menu: Dish[] = [
  { id: 1, name: '宫保鸡丁', price: 38, category: 'hot', categoryName: '热菜' },
  { id: 2, name: '红烧肉', price: 48, category: 'hot', categoryName: '热菜' },
  { id: 3, name: '凉拌黄瓜', price: 16, category: 'cold', categoryName: '凉菜' },
  { id: 4, name: '米饭', price: 3, category: 'staple', categoryName: '主食' },
  { id: 5, name: '可乐', price: 8, category: 'drink', categoryName: '酒水' },
  { id: 6, name: '啤酒', price: 12, category: 'drink', categoryName: '酒水' },
];
const menuCats = ['热菜', '凉菜', '主食', '酒水'];
const activeCat = ref('热菜');
const orders = ref<CateringOrder[]>([]);
const tickets = ref<KitchenTicket[]>([]);
const keyword = ref('');
const tableVisible = ref(false);
const current = ref<DiningTable | null>(null);
const checkoutVisible = ref(false);
const switchTableVisible = ref(false);
const showTicket = ref(false);
const discount = ref(1);
const serviceFee = ref(0);
const payMethods = ['现金', '微信', '支付宝'];
const payMethod = ref('微信');
const cash = ref(0);

const stats = computed(() => [
  { label: '营业中桌台', value: String(tables.value.filter((t) => t.status !== '空闲').length), tone: 'cat-stat__brand' },
  { label: '已结账', value: String(orders.value.length), tone: '' },
  { label: '今日营业额', value: `¥${orders.value.reduce((s, o) => s + Number(o.payable), 0).toFixed(2)}`, tone: 'cat-stat__brand' },
  { label: '待厨打', value: String(pendingTickets.value), tone: 'cat-stat__warn' },
]);
const pendingTickets = computed(() => tickets.value.filter((t) => t.status === '待打印').length);
const filteredOrders = computed(() => [...orders.value].reverse().filter((o) => !keyword.value.trim() || o.tableNo.includes(keyword.value.trim())));
const checkoutPayable = computed(() => {
  if (!current.value) return 0;
  const d = Math.min(1, Math.max(0.85, Number(discount.value || 1)));
  return Math.max(0, tableAmount(current.value) * d + Number(serviceFee.value || 0));
});
const checkoutChange = computed(() => Math.max(0, Number(cash.value || 0) - checkoutPayable.value));

function statusText(s: TableStatus): string { return s; }
function tableAmount(t: DiningTable): number { return (t.dishes || []).reduce((s, d) => s + d.price * (d.qty || 1), 0); }

/** 加载桌台/订单/厨打任务（真实种子数据，无演示兜底） */
async function load(): Promise<void> {
  const t: any = await mockGet('/api/v1/industry/cateringTables', { pageSize: 100 });
  const list = Array.isArray(t) ? t : t?.list || [];
  tables.value = list;
  const o: any = await mockGet('/api/v1/industry/cateringOrders', { pageSize: 200 });
  orders.value = Array.isArray(o) ? o : o?.list || [];
  const k: any = await mockGet('/api/v1/industry/kitchenTickets', { pageSize: 200 });
  tickets.value = Array.isArray(k) ? k : k?.list || [];
}
function openTable(t: DiningTable): void { current.value = reactive(t); tableVisible.value = true; activeCat.value = '热菜'; }
/** 开台：空闲 → 已开台，人数至少 1 */
async function openTableNow(): Promise<void> {
  if (!current.value) return;
  if (!current.value.guests || current.value.guests < 1) { toast.warning('请输入就餐人数'); return; }
  current.value.status = '已开台'; await persistTables(); toast.success(`${current.value.no} 已开台`);
}
function addDish(d: Dish): void {
  if (!current.value) return;
  if (current.value.status === '空闲') { toast.warning('请先开台'); return; }
  const line = current.value.dishes.find((x) => x.id === d.id);
  if (line) line.qty = (line.qty || 1) + 1;
  else current.value.dishes.push({ ...d, qty: 1 });
  if (current.value.status === '已开台') current.value.status = '已下单';
  persistTables();
}
/** 退菜：数量减到 0 则移除，并记录厨打退菜 */
function dishQty(i: number, delta: number): void {
  if (!current.value) return;
  const d = current.value.dishes[i]; d.qty = (d.qty || 1) + delta;
  if (d.qty <= 0) {
    current.value.dishes.splice(i, 1);
    mockPost('/api/v1/industry/kitchenTickets', { tableNo: current.value.no, categoryName: '退菜', dishes: [{ name: d.name, qty: 1 }], status: '待打印', createdAt: new Date().toLocaleString('zh-CN'), isReturn: true });
    toast.info(`已退菜：${d.name}`);
  }
  if (!current.value.dishes.length) current.value.status = '已开台';
  persistTables();
}
/** 厨打分单：按热菜/凉菜/酒水等类别拆成独立厨打单，便于厨房分区制作 */
async function sendKitchen(): Promise<void> {
  if (!current.value || !current.value.dishes.length) { toast.warning('请先点菜'); return; }
  const groups: Record<string, Dish[]> = {};
  for (const d of current.value.dishes) { (groups[d.categoryName] ||= []).push(d); }
  for (const [name, dishes] of Object.entries(groups)) {
    const ticket: KitchenTicket = { id: Date.now() + Math.random(), tableNo: current.value.no, categoryName: name, dishes: dishes.map((d) => ({ name: d.name, qty: d.qty || 1 })), status: '待打印', createdAt: new Date().toLocaleString('zh-CN') };
    const saved: any = await mockPost('/api/v1/industry/kitchenTickets', ticket);
    tickets.value.push({ ...ticket, id: saved?.id || ticket.id });
  }
  if (current.value.status === '已下单') current.value.status = '待结账';
  await persistTables(); emit(Events.PRINT_DONE, { type: 'KITCHEN', tableNo: current.value.no });
  toast.success(`已发送 ${Object.keys(groups).length} 张厨打单`);
}
async function printAllTickets(): Promise<void> {
  for (const t of tickets.value.filter((x) => x.status === '待打印')) { await mockPost('/api/v1/industry/kitchenTickets', { ...t, status: '已打印' }); t.status = '已打印'; }
  emit(Events.PRINT_DONE, { type: 'KITCHEN_BATCH' }); toast.success('厨打任务全部打印');
}
/** 结账：折扣/服务费/找零校验 → 生成营业订单 → 桌台复位 */
async function confirmCheckout(): Promise<void> {
  if (!current.value) return;
  if (payMethod.value === '现金' && Number(cash.value || 0) < checkoutPayable.value) { toast.warning('收款不足'); return; }
  const orderNo = `CAT${new Date().toISOString().slice(0, 10).replace(/-/g, '')}-${String(orders.value.length + 1).padStart(4, '0')}`;
  const order: CateringOrder = { id: Date.now(), orderNo, tableNo: current.value.no, guests: current.value.guests, payable: Number(checkoutPayable.value.toFixed(2)), payMethod: payMethod.value, createdAt: new Date().toLocaleString('zh-CN'), status: '已结账' };
  await mockPost('/api/v1/industry/cateringOrders', order);
  await mockPost('/api/v1/industry/cateringOrderDetails', { orderNo, tableNo: order.tableNo, dishes: current.value.dishes, discount: discount.value, serviceFee: serviceFee.value });
  orders.value.push(order);
  emit(Events.ORDER_CONFIRMED, { type: 'CATERING', total: order.payable, tableNo: order.tableNo });
  toast.success(`${order.tableNo} 结账成功 ¥${order.payable.toFixed(2)}`);
  resetTable(current.value); await persistTables();
  checkoutVisible.value = false; tableVisible.value = false;
}
function resetTable(t: DiningTable): void { t.status = '空闲'; t.guests = 0; t.dishes = []; }
async function clearTable(): Promise<void> {
  if (!current.value) return;
  if (current.value.dishes.length && !await uiConfirm(`${current.value.no} 尚未结账，确认清台？`, '清台确认')) return;
  resetTable(current.value); await persistTables(); tableVisible.value = false; toast.success('桌台已清理');
}
/** 并台：目标桌承接来源桌菜品与人数，来源桌复位 */
async function doSwitch(target: DiningTable): Promise<void> {
  if (!current.value) return;
  for (const d of current.value.dishes) {
    const line = target.dishes.find((x) => x.id === d.id);
    if (line) line.qty = (line.qty || 1) + (d.qty || 1); else target.dishes.push({ ...d });
  }
  target.guests += current.value.guests;
  if (target.status === '空闲') target.status = current.value.status;
  current.value = target; await persistTables(); switchTableVisible.value = false; toast.success('并台完成');
}
async function persistTables(): Promise<void> { for (const t of tables.value) await mockPost('/api/v1/industry/cateringTables', { ...t }); }
onMounted(load);
</script>

<style scoped>
.cat-page { display: flex; flex-direction: column; gap: 14px; padding: 16px; }
.cat-stats { display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px; }
.cat-stat { border: 1px solid var(--ds-border); border-radius: 10px; padding: 14px 16px; background: var(--ds-bg-elevated); display: flex; flex-direction: column; gap: 6px; }
.cat-stat span { font-size: 12px; color: var(--ds-text-3); }
.cat-stat b { font-size: 22px; }
.cat-stat__brand { color: var(--ds-brand); }
.cat-stat__warn { color: var(--ds-danger); }
.cat-main { display: grid; grid-template-columns: 1.1fr 1fr; gap: 14px; align-items: start; }
.cat-body { padding: 16px; display: flex; flex-direction: column; gap: 12px; }
.cat-tables { display: grid; grid-template-columns: repeat(5, 1fr); gap: 10px; }
.cat-table { border: 1px solid var(--ds-border); border-radius: 8px; padding: 12px; display: flex; flex-direction: column; gap: 4px; cursor: pointer; background: var(--ds-bg-elevated); }
.cat-table b { font-size: 15px; }
.cat-table__st { font-size: 12px; }
.cat-table__meta { font-size: 11px; color: var(--ds-text-3); }
.cat-table.st-open { border-color: var(--ds-warning); background: var(--ds-warning-soft, var(--ds-brand-soft)); }
.cat-table.st-ordered { border-color: var(--ds-brand); background: var(--ds-brand-soft); }
.cat-table.st-billing { border-color: var(--ds-danger); }
.cat-legend { display: flex; gap: 16px; font-size: 12px; color: var(--ds-text-3); }
.cat-legend .dot { display: inline-block; width: 8px; height: 8px; border-radius: 50%; margin-right: 4px; background: var(--ds-border); }
.cat-legend .st-open { background: var(--ds-warning); }
.cat-legend .st-ordered { background: var(--ds-brand); }
.cat-legend .st-billing { background: var(--ds-danger); }
.cat-table-grid { width: 100%; border-collapse: collapse; font-size: 13px; }
.cat-table-grid th, .cat-table-grid td { padding: 9px 10px; border-bottom: 1px solid var(--ds-divider); text-align: left; }
.cat-table-grid th { background: var(--ds-bg-soft); color: var(--ds-text-3); }
.cat-empty { padding: 20px; text-align: center; color: var(--ds-text-3); font-size: 12px; }
.cat-detail { display: flex; flex-direction: column; gap: 14px; }
.cat-detail__head { display: flex; justify-content: space-between; align-items: center; }
.cat-guests { display: flex; align-items: center; gap: 8px; font-size: 13px; }
.cat-guests .ds-input { width: 80px; }
.cat-detail__ops { display: flex; gap: 8px; }
.cat-menu { display: grid; grid-template-columns: 100px 1fr; gap: 12px; }
.cat-menu__cats { display: flex; flex-direction: column; gap: 6px; }
.cat-cat { border: 1px solid var(--ds-border); background: var(--ds-bg-elevated); border-radius: 6px; padding: 7px; cursor: pointer; font-size: 12px; }
.cat-cat.on { background: var(--ds-brand); color: #fff; border-color: var(--ds-brand); }
.cat-menu__list { display: grid; grid-template-columns: repeat(auto-fill, minmax(110px, 1fr)); gap: 8px; }
.cat-dish { border: 1px solid var(--ds-border); border-radius: 6px; padding: 9px; background: var(--ds-bg-elevated); cursor: pointer; display: flex; flex-direction: column; gap: 4px; text-align: left; }
.cat-dish:hover { border-color: var(--ds-brand); }
.cat-dish b { color: var(--ds-brand); }
.cat-order { border: 1px solid var(--ds-border); border-radius: 8px; padding: 12px; }
.cat-order__title { font-size: 13px; font-weight: 600; margin-bottom: 8px; }
.cat-order__line { display: grid; grid-template-columns: 1fr 70px 100px 80px; gap: 8px; align-items: center; padding: 6px 0; border-bottom: 1px solid var(--ds-divider); font-size: 13px; }
.cat-order__qty { display: flex; align-items: center; gap: 6px; }
.cat-order__qty button { width: 22px; height: 22px; border: 1px solid var(--ds-border); background: var(--ds-bg-soft); border-radius: 4px; cursor: pointer; }
.cat-order__sum { text-align: right; font-weight: 700; color: var(--ds-brand); padding-top: 8px; }
.cat-foot { display: flex; justify-content: flex-end; gap: 8px; }
.cat-checkout { display: flex; flex-direction: column; gap: 10px; }
.cat-checkout__row { display: flex; align-items: center; justify-content: space-between; font-size: 13px; }
.cat-checkout__row .ds-input { width: 140px; }
.cat-checkout__methods { display: flex; gap: 8px; }
.cat-pm { flex: 1; border: 1px solid var(--ds-border); background: var(--ds-bg-elevated); border-radius: 6px; padding: 7px; font-size: 12px; cursor: pointer; }
.cat-pm.on { border-color: var(--ds-brand); background: var(--ds-brand-soft); color: var(--ds-brand); }
.cat-checkout__total { font-size: 17px; font-weight: 700; }
.cat-checkout__total b { color: var(--ds-brand); }
.cat-change { color: var(--ds-brand); }
.cat-switch { display: flex; flex-direction: column; gap: 10px; font-size: 13px; }
.cat-switch__opts { display: grid; grid-template-columns: repeat(4, 1fr); gap: 8px; }
.cat-tickets { display: grid; grid-template-columns: repeat(2, 1fr); gap: 10px; }
.cat-ticket { border: 1px solid var(--ds-border); border-radius: 8px; padding: 10px; }
.cat-ticket.done { opacity: .6; }
.cat-ticket__head { display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px; font-size: 13px; }
.cat-ticket__line { font-size: 12px; padding: 2px 0; }
.cat-ticket__time { font-size: 11px; color: var(--ds-text-3); margin-top: 6px; }
@media (max-width: 1024px) { .cat-stats { grid-template-columns: repeat(2, 1fr); } .cat-main { grid-template-columns: 1fr; } .cat-tables { grid-template-columns: repeat(3, 1fr); } }
</style>
