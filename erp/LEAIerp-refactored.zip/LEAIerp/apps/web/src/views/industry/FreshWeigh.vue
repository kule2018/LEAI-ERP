<!-- 生鲜计重收银中心：商品档案→称重(毛重/皮重/损耗/时段价)→结账→标签打印→损耗分析 -->
<template>
  <div class="fresh-page">
    <div class="fresh-stats">
      <div v-for="c in stats" :key="c.label" class="fresh-stat"><span>{{ c.label }}</span><b :class="c.tone">{{ c.value }}</b></div>
    </div>

    <div class="fresh-layout">
      <!-- 商品档案 -->
      <DsCard title="称重商品" :pad="false">
        <template #extra><DsButton size="sm" variant="primary" @click="goodsVisible = true">新增商品</DsButton></template>
        <div class="fresh-body">
          <div class="fresh-goods">
            <button v-for="g in goods" :key="g.id" class="fresh-good" :class="{ on: current?.id === g.id }" @click="pickGood(g)">
              <span class="fresh-good__name">{{ g.name }}</span>
              <span class="fresh-good__price">¥{{ Number(g.price).toFixed(2) }}/kg</span>
              <span class="fresh-good__origin">{{ g.origin }} · 损耗{{ g.lossRate }}%</span>
            </button>
            <div v-if="!goods.length" class="fresh-empty">暂无商品，请新增</div>
          </div>
        </div>
      </DsCard>

      <!-- 称重台 -->
      <DsCard title="称重收银台" :pad="false">
        <div class="fresh-body">
          <div class="fresh-scale">
            <label><span>商品</span><input class="ds-input" :value="current?.name || '请先选择商品'" disabled /></label>
            <label><span>毛重(kg)</span><input v-model.number="gross" class="ds-input" type="number" min="0" step="0.01" /></label>
            <label><span>皮重(kg)</span><input v-model.number="tare" class="ds-input" type="number" min="0" step="0.01" /></label>
            <label><span>单价(元/kg)</span><input v-model.number="unitPrice" class="ds-input" type="number" min="0" /></label>
          </div>
          <div class="fresh-calc">
            <div><span>净重</span><b>{{ calc.netWeight.toFixed(3) }} kg</b></div>
            <div><span>损耗({{ current?.lossRate || 0 }}%)</span><b class="fresh-loss">-{{ calc.lossWeight.toFixed(3) }} kg</b></div>
            <div><span>计价重量</span><b>{{ calc.chargeWeight.toFixed(3) }} kg</b></div>
            <div><span>时段折扣</span><b>{{ periodDiscount }} 折</b></div>
            <div class="fresh-calc__total"><span>应收</span><b>¥{{ calc.amount.toFixed(2) }}</b></div>
          </div>
          <div class="fresh-pay">
            <div class="fresh-pay-methods">
              <button v-for="pm in payMethods" :key="pm" class="fresh-pm" :class="{ on: payMethod === pm }" @click="payMethod = pm">{{ pm }}</button>
            </div>
            <label v-if="payMethod === '现金'" class="fresh-cash"><span>收款</span><input v-model.number="cash" class="ds-input" type="number" /><span>找零 ¥{{ change.toFixed(2) }}</span></label>
          </div>
          <DsButton variant="primary" class="fresh-checkout" :disabled="!current" @click="checkout">计重结账</DsButton>
        </div>
      </DsCard>
    </div>

    <!-- 流水 / 损耗分析 -->
    <div class="fresh-bottom">
      <DsCard title="计重订单流水" :pad="false">
        <template #extra><input v-model="keyword" class="ds-input" placeholder="按商品查询" /></template>
        <div class="fresh-body">
          <table class="fresh-table">
            <thead><tr><th>单号</th><th>商品</th><th>净重</th><th>损耗</th><th>金额</th><th>支付</th><th>时间</th><th>操作</th></tr></thead>
            <tbody>
              <tr v-for="o in filteredOrders" :key="o.id">
                <td>{{ o.orderNo }}</td><td>{{ o.productName }}</td><td>{{ Number(o.netWeight).toFixed(3) }}kg</td>
                <td>{{ Number(o.lossWeight).toFixed(3) }}kg</td><td>¥{{ Number(o.amount).toFixed(2) }}</td>
                <td>{{ o.payMethod }}</td><td>{{ o.createdAt }}</td>
                <td class="fresh-ops">
                  <DsButton size="sm" @click="printLabel(o)">标签</DsButton>
                  <DsButton v-if="o.status !== '已退货'" size="sm" @click="refund(o)">退货</DsButton>
                  <span v-else class="fresh-comment">已退货</span>
                </td>
              </tr>
              <tr v-if="!filteredOrders.length"><td colspan="8" class="fresh-empty">暂无计重订单</td></tr>
            </tbody>
          </table>
        </div>
      </DsCard>

      <DsCard title="损耗分析" :pad="false">
        <div class="fresh-body">
          <div v-for="r in lossAnalysis" :key="r.name" class="fresh-loss-row">
            <span>{{ r.name }}</span>
            <div class="fresh-loss-bar"><i :style="{ width: r.ratio + '%' }"></i></div>
            <b>{{ r.weight.toFixed(2) }}kg / ¥{{ r.amount.toFixed(2) }}</b>
          </div>
          <div v-if="!lossAnalysis.length" class="fresh-empty">暂无损耗数据</div>
        </div>
      </DsCard>
    </div>

    <!-- 新增商品 -->
    <DsModal v-model="goodsVisible" title="新增称重商品" :width="440">
      <div class="fresh-form">
        <label><span>商品名称</span><input v-model="goodsForm.name" class="ds-input" /></label>
        <label><span>单价(元/kg)</span><input v-model.number="goodsForm.price" class="ds-input" type="number" /></label>
        <label><span>损耗率(%)</span><input v-model.number="goodsForm.lossRate" class="ds-input" type="number" /></label>
        <label><span>产地</span><input v-model="goodsForm.origin" class="ds-input" /></label>
        <label><span>批次</span><input v-model="goodsForm.batch" class="ds-input" /></label>
      </div>
      <template #footer><div class="fresh-foot"><DsButton @click="goodsVisible = false">取消</DsButton><DsButton variant="primary" @click="saveGood">保存</DsButton></div></template>
    </DsModal>
  </div>
</template>

<script setup lang="ts">
/** 生鲜计重：净重=毛重-皮重，损耗=净重×损耗率，时段折扣计价，结账落库并统计损耗。 */
import { computed, onMounted, reactive, ref } from 'vue';
import { DsButton, DsCard, DsModal, DsTag } from '../../components';
import { mockGet, mockPost } from '../../api/mockAdapter';
import { emit, Events } from '../../utils/eventBus';
import { useToast } from '../../components/ds/toast';

interface FreshGood { id: number; name: string; price: number; lossRate: number; origin: string; batch: string; }
interface WeighOrder { id: number; orderNo: string; productName: string; gross: number; tare: number; netWeight: number; lossWeight: number; chargeWeight: number; amount: number; discount: number; payMethod: string; status: string; createdAt: string; }

const toast = useToast();
const goods = ref<FreshGood[]>([]);
const current = ref<FreshGood | null>(null);
const gross = ref(0);
const tare = ref(0);
const unitPrice = ref(0);
const orders = ref<WeighOrder[]>([]);
const keyword = ref('');
const payMethods = ['现金', '微信', '支付宝'];
const payMethod = ref('微信');
const cash = ref(0);
const goodsVisible = ref(false);
const goodsForm = reactive<any>({ name: '', price: 0, lossRate: 3, origin: '', batch: '' });

/** 净重必须为正，损耗从净重中扣除，计价重量用于最终结算 */
const calc = computed(() => {
  const net = Math.max(0, Number(gross.value || 0) - Number(tare.value || 0));
  const rate = Number(current.value?.lossRate || 0) / 100;
  const loss = net * rate;
  const charge = Math.max(0, net - loss);
  const price = Number(unitPrice.value || 0);
  const amount = charge * price * periodFactor.value;
  return { netWeight: net, lossWeight: loss, chargeWeight: charge, amount };
});
/** 时段定价：早市原价、午市95折、晚市85折 */
const periodFactor = computed(() => {
  const h = new Date().getHours();
  if (h >= 8 && h < 11) return 1;
  if (h >= 11 && h < 17) return 0.95;
  return 0.85;
});
const periodDiscount = computed(() => (periodFactor.value * 10).toFixed(1));
const change = computed(() => Math.max(0, Number(cash.value || 0) - calc.value.amount));
const validOrders = computed(() => orders.value.filter((o) => o.status !== '已退货'));
const stats = computed(() => [
  { label: '今日单数', value: String(validOrders.value.length), tone: '' },
  { label: '销售净重', value: `${validOrders.value.reduce((s, o) => s + Number(o.netWeight), 0).toFixed(2)} kg`, tone: '' },
  { label: '营业额', value: `¥${validOrders.value.reduce((s, o) => s + Number(o.amount), 0).toFixed(2)}`, tone: 'fresh-brand' },
  { label: '损耗合计', value: `¥${lossAnalysis.value.reduce((s, r) => s + r.amount, 0).toFixed(2)}`, tone: 'fresh-loss-text' },
]);
const filteredOrders = computed(() => [...orders.value].reverse().filter((o) => !keyword.value.trim() || o.productName.includes(keyword.value.trim())));
const lossAnalysis = computed(() => {
  const map: Record<string, { name: string; weight: number; amount: number; price: number }> = {};
  for (const o of validOrders.value) {
    if (!map[o.productName]) map[o.productName] = { name: o.productName, weight: 0, amount: 0, price: 0 };
    map[o.productName].weight += Number(o.lossWeight);
    map[o.productName].amount += Number(o.lossWeight) * (Number(o.amount) / Math.max(0.001, Number(o.chargeWeight)));
  }
  const list = Object.values(map).filter((r) => r.weight > 0).sort((a, b) => b.amount - a.amount);
  const max = Math.max(1, ...list.map((r) => r.amount));
  return list.map((r) => ({ ...r, ratio: (r.amount / max) * 100 }));
});

async function load(): Promise<void> {
  const loadList = async (url: string) => { const r: any = await mockGet(url, { pageSize: 200 }); return Array.isArray(r) ? r : r?.list || []; };
  goods.value = await loadList('/api/v1/industry/freshProducts');
  if (!goods.value.length) {
    const seed: FreshGood[] = [
      { id: 1, name: '红富士苹果', price: 12.8, lossRate: 3, origin: '山东烟台', batch: 'B20261117' },
      { id: 2, name: '小龙虾', price: 38, lossRate: 8, origin: '湖北潜江', batch: 'B20261116' },
      { id: 3, name: '活鲜鲈鱼', price: 26, lossRate: 12, origin: '广东佛山', batch: 'B20261117' },
      { id: 4, name: '本地青菜', price: 5.6, lossRate: 5, origin: '本地农场', batch: 'B20261117' },
    ];
    for (const g of seed) await mockPost('/api/v1/industry/freshProducts', g);
    goods.value = seed;
  }
  orders.value = await loadList('/api/v1/industry/weighOrders');
}
function pickGood(g: FreshGood): void { current.value = g; unitPrice.value = g.price; }
async function saveGood(): Promise<void> {
  if (!goodsForm.name) { toast.warning('请填写商品名称'); return; }
  const g: FreshGood = { id: Date.now(), ...goodsForm };
  const saved: any = await mockPost('/api/v1/industry/freshProducts', g);
  goods.value.push({ ...g, id: saved?.id || g.id });
  goodsVisible.value = false; toast.success('商品已新增');
}
/** 结账：校验净重>0、现金收款充足，生成订单并发布销售事件 */
async function checkout(): Promise<void> {
  if (!current.value) { toast.warning('请先选择商品'); return; }
  if (calc.value.netWeight <= 0) { toast.warning('净重必须大于 0，请检查毛重与皮重'); return; }
  if (payMethod.value === '现金' && Number(cash.value || 0) < calc.value.amount) { toast.warning('收款不足'); return; }
  const orderNo = `FW${new Date().toISOString().slice(0, 10).replace(/-/g, '')}-${String(orders.value.length + 1).padStart(4, '0')}`;
  const order: WeighOrder = {
    id: Date.now(), orderNo, productName: current.value.name, gross: Number(gross.value), tare: Number(tare.value),
    netWeight: calc.value.netWeight, lossWeight: calc.value.lossWeight, chargeWeight: calc.value.chargeWeight,
    amount: Number(calc.value.amount.toFixed(2)), discount: periodFactor.value, payMethod: payMethod.value,
    status: '已完成', createdAt: new Date().toLocaleString('zh-CN'),
  };
  await mockPost('/api/v1/industry/weighOrders', order);
  orders.value.push(order);
  emit(Events.ORDER_CONFIRMED, { type: 'FRESH', total: order.amount, orderNo });
  toast.success(`计重完成 ¥${order.amount.toFixed(2)}`);
  gross.value = 0; tare.value = 0; cash.value = 0;
}
function printLabel(o: WeighOrder): void { emit(Events.PRINT_DONE, { type: 'FRESH_LABEL', order: o }); toast.success(`价格标签已打印：${o.orderNo}`); }
async function refund(o: WeighOrder): Promise<void> {
  if (o.status === '已退货') { toast.warning('该订单已退货'); return; }
  await mockPost('/api/v1/industry/freshReturns', { orderId: o.id, orderNo: o.orderNo, amount: o.amount, createdAt: new Date().toLocaleString('zh-CN') });
  await mockPost('/api/v1/industry/weighOrders', { ...o, status: '已退货' });
  o.status = '已退货'; toast.success('退货已登记');
}
onMounted(load);
</script>

<style scoped>
.fresh-page { display: flex; flex-direction: column; gap: 14px; padding: 16px; }
.fresh-stats { display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px; }
.fresh-stat { border: 1px solid var(--ds-border); border-radius: 10px; padding: 14px 16px; background: var(--ds-bg-elevated); display: flex; flex-direction: column; gap: 6px; }
.fresh-stat span { font-size: 12px; color: var(--ds-text-3); }
.fresh-stat b { font-size: 22px; }
.fresh-brand { color: var(--ds-brand); }
.fresh-loss-text { color: var(--ds-danger); }
.fresh-layout { display: grid; grid-template-columns: 0.85fr 1.15fr; gap: 14px; align-items: start; }
.fresh-bottom { display: grid; grid-template-columns: 1.4fr 1fr; gap: 14px; align-items: start; }
.fresh-body { padding: 16px; display: flex; flex-direction: column; gap: 12px; }
.fresh-goods { display: grid; grid-template-columns: repeat(2, 1fr); gap: 10px; }
.fresh-good { border: 1px solid var(--ds-border); border-radius: 8px; padding: 10px; background: var(--ds-bg-elevated); cursor: pointer; display: flex; flex-direction: column; gap: 4px; text-align: left; }
.fresh-good.on { border-color: var(--ds-brand); background: var(--ds-brand-soft); }
.fresh-good__name { font-size: 13px; font-weight: 600; }
.fresh-good__price { color: var(--ds-brand); font-weight: 700; }
.fresh-good__origin { font-size: 11px; color: var(--ds-text-3); }
.fresh-empty { padding: 24px; text-align: center; color: var(--ds-text-3); font-size: 12px; }
.fresh-scale { display: grid; grid-template-columns: repeat(2, 1fr); gap: 12px; }
.fresh-scale label { display: flex; flex-direction: column; gap: 5px; font-size: 12px; }
.fresh-calc { border: 1px solid var(--ds-border); border-radius: 8px; padding: 12px; display: flex; flex-direction: column; gap: 7px; }
.fresh-calc > div { display: flex; justify-content: space-between; font-size: 13px; }
.fresh-calc .fresh-loss { color: var(--ds-danger); }
.fresh-calc__total { font-size: 17px; font-weight: 700; }
.fresh-calc__total b { color: var(--ds-brand); }
.fresh-pay { display: flex; flex-direction: column; gap: 8px; }
.fresh-pay-methods { display: flex; gap: 8px; }
.fresh-pm { flex: 1; border: 1px solid var(--ds-border); background: var(--ds-bg-elevated); border-radius: 6px; padding: 7px; font-size: 12px; cursor: pointer; }
.fresh-pm.on { border-color: var(--ds-brand); background: var(--ds-brand-soft); color: var(--ds-brand); }
.fresh-cash { display: flex; align-items: center; gap: 8px; font-size: 13px; }
.fresh-cash .ds-input { width: 120px; }
.fresh-cash span:last-child { margin-left: auto; color: var(--ds-brand); font-weight: 600; }
.fresh-checkout { width: 100%; }
.fresh-table { width: 100%; border-collapse: collapse; font-size: 13px; }
.fresh-table th, .fresh-table td { padding: 9px 10px; border-bottom: 1px solid var(--ds-divider); text-align: left; }
.fresh-table th { background: var(--ds-bg-soft); color: var(--ds-text-3); }
.fresh-ops { display: flex; gap: 6px; }
.fresh-comment { color: var(--ds-text-3); font-size: 12px; }
.fresh-loss-row { display: grid; grid-template-columns: 90px 1fr 150px; gap: 10px; align-items: center; font-size: 12px; }
.fresh-loss-bar { height: 8px; border-radius: 4px; background: var(--ds-bg-soft); overflow: hidden; }
.fresh-loss-bar i { display: block; height: 100%; background: var(--ds-danger); }
.fresh-form { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
.fresh-form label { display: flex; flex-direction: column; gap: 5px; font-size: 12px; }
.fresh-foot { display: flex; justify-content: flex-end; gap: 8px; }
@media (max-width: 1024px) { .fresh-stats { grid-template-columns: repeat(2, 1fr); } .fresh-layout, .fresh-bottom { grid-template-columns: 1fr; } }
</style>
