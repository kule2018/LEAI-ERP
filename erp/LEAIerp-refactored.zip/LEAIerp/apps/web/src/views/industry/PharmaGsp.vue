<!-- 医药 GSP 质量管理中心：批次效期预警 / 首营审批 / 到货验收 / 温湿度养护，合规闭环 -->
<template>
  <div class="gsp-page">
    <div class="gsp-stats">
      <div v-for="c in stats" :key="c.label" class="gsp-stat"><span>{{ c.label }}</span><b :class="c.tone">{{ c.value }}</b></div>
    </div>

    <div class="gsp-tabs">
      <button v-for="t in tabs" :key="t.key" class="gsp-tab" :class="{ on: active === t.key }" @click="active = t.key">{{ t.label }}</button>
    </div>

    <!-- 批次效期 -->
    <DsCard v-if="active === 'batch'" title="药品批次效期台账" :pad="false">
      <template #extra>
        <div class="gsp-tools">
          <select v-model="levelFilter" class="ds-input"><option value="">全部效期</option><option value="已过期">已过期</option><option value="近效期">近效期(≤30天)</option><option value="关注">关注(≤90天)</option><option value="正常">正常</option></select>
          <DsButton size="sm" variant="primary" @click="batchVisible = true">新增批次</DsButton>
        </div>
      </template>
      <div class="gsp-body">
        <table class="gsp-table">
          <thead><tr><th>批号</th><th>品名</th><th>规格</th><th>生产企业</th><th>有效期至</th><th>剩余天数</th><th>数量</th><th>效期级别</th><th>销售状态</th><th>操作</th></tr></thead>
          <tbody>
            <tr v-for="b in filteredBatches" :key="b.id">
              <td>{{ b.batchNo }}</td><td>{{ b.name }}</td><td>{{ b.spec }}</td><td>{{ b.manufacturer }}</td><td>{{ b.expireDate }}</td>
              <td :class="daysClass(b)">{{ daysLeft(b) }} 天</td><td>{{ b.qty }}</td>
              <td><DsTag :color="levelColor(expireLevel(b))" size="sm">{{ expireLevel(b) }}</DsTag></td>
              <td><DsTag :color="b.saleStatus === '禁售' ? 'danger' : 'success'" size="sm">{{ b.saleStatus || '可销售' }}</DsTag></td>
              <td><DsButton v-if="b.saleStatus !== '禁售'" size="sm" @click="lockBatch(b)">锁定</DsButton><DsButton v-else size="sm" @click="unlockBatch(b)">解锁</DsButton></td>
            </tr>
            <tr v-if="!filteredBatches.length"><td colspan="10" class="gsp-empty">暂无批次数据</td></tr>
          </tbody>
        </table>
      </div>
    </DsCard>

    <!-- 首营审批 -->
    <DsCard v-if="active === 'approval'" title="首营企业 / 首营品种审批" :pad="false">
      <template #extra><DsButton size="sm" variant="primary" @click="approvalVisible = true">新增申请</DsButton></template>
      <div class="gsp-body">
        <table class="gsp-table">
          <thead><tr><th>类型</th><th>名称</th><th>证照号</th><th>证照有效期</th><th>申请人</th><th>状态</th><th>操作</th></tr></thead>
          <tbody>
            <tr v-for="a in approvals" :key="a.id">
              <td>{{ a.type }}</td><td>{{ a.name }}</td><td>{{ a.licenseNo }}</td><td>{{ a.licenseExpire }}</td><td>{{ a.applicant }}</td>
              <td><DsTag :color="approvalColor(a.status)" size="sm">{{ a.status }}</DsTag></td>
              <td class="gsp-ops">
                <template v-if="a.status === '待审'">
                  <DsButton size="sm" variant="primary" @click="reviewApproval(a, '通过')">通过</DsButton>
                  <DsButton size="sm" @click="reviewApproval(a, '驳回')">驳回</DsButton>
                </template>
                <span v-else class="gsp-comment">{{ a.comment }}</span>
              </td>
            </tr>
            <tr v-if="!approvals.length"><td colspan="7" class="gsp-empty">暂无审批申请</td></tr>
          </tbody>
        </table>
      </div>
    </DsCard>

    <!-- 到货验收 -->
    <DsCard v-if="active === 'acceptance'" title="到货验收记录" :pad="false">
      <template #extra><DsButton size="sm" variant="primary" @click="acceptanceVisible = true">新增验收</DsButton></template>
      <div class="gsp-body">
        <table class="gsp-table">
          <thead><tr><th>验收单号</th><th>药品</th><th>批号</th><th>到货数</th><th>验收数</th><th>结论</th><th>验收人</th><th>时间</th><th>操作</th></tr></thead>
          <tbody>
            <tr v-for="a in acceptances" :key="a.id">
              <td>{{ a.no }}</td><td>{{ a.name }}</td><td>{{ a.batchNo }}</td><td>{{ a.arriveQty }}</td><td>{{ a.acceptQty }}</td>
              <td><DsTag :color="a.result === '合格' ? 'success' : 'danger'" size="sm">{{ a.result }}</DsTag></td>
              <td>{{ a.checker }}</td><td>{{ a.createdAt }}</td>
              <td><DsButton v-if="a.result === '不合格' && a.status !== '已退货'" size="sm" @click="returnGoods(a)">退货处理</DsButton><span v-else class="gsp-comment">{{ a.status || '' }}</span></td>
            </tr>
            <tr v-if="!acceptances.length"><td colspan="9" class="gsp-empty">暂无验收记录</td></tr>
          </tbody>
        </table>
      </div>
    </DsCard>

    <!-- 温湿度养护 -->
    <DsCard v-if="active === 'maintenance'" title="库房温湿度养护记录" :pad="false">
      <template #extra><DsButton size="sm" variant="primary" @click="maintenanceVisible = true">新增记录</DsButton></template>
      <div class="gsp-body">
        <table class="gsp-table">
          <thead><tr><th>库房</th><th>温度(℃)</th><th>湿度(%)</th><th>判定</th><th>记录人</th><th>时间</th></tr></thead>
          <tbody>
            <tr v-for="m in maintenances" :key="m.id">
              <td>{{ m.warehouse }}</td><td>{{ m.temp }}</td><td>{{ m.humidity }}</td>
              <td><DsTag :color="m.abnormal ? 'danger' : 'success'" size="sm">{{ m.abnormal ? '异常' : '正常' }}</DsTag></td>
              <td>{{ m.recorder }}</td><td>{{ m.createdAt }}</td>
            </tr>
            <tr v-if="!maintenances.length"><td colspan="6" class="gsp-empty">暂无养护记录</td></tr>
          </tbody>
        </table>
        <div class="gsp-hint">判定标准：温度 2~25℃、湿度 35~75%；超出范围自动标记异常并生成养护任务。</div>
      </div>
    </DsCard>

    <!-- 新增批次弹窗 -->
    <DsModal v-model="batchVisible" title="新增药品批次" :width="480">
      <div class="gsp-form">
        <label><span>批号</span><input v-model="batchForm.batchNo" class="ds-input" /></label>
        <label><span>品名</span><input v-model="batchForm.name" class="ds-input" /></label>
        <label><span>规格</span><input v-model="batchForm.spec" class="ds-input" /></label>
        <label><span>生产企业</span><input v-model="batchForm.manufacturer" class="ds-input" /></label>
        <label><span>生产日期</span><DsDatePicker v-model="batchForm.produceDate" /></label>
        <label><span>有效期至</span><DsDatePicker v-model="batchForm.expireDate" /></label>
        <label><span>数量</span><input v-model.number="batchForm.qty" class="ds-input" type="number" /></label>
      </div>
      <template #footer><div class="gsp-foot"><DsButton @click="batchVisible = false">取消</DsButton><DsButton variant="primary" @click="saveBatch">保存</DsButton></div></template>
    </DsModal>

    <!-- 首营申请弹窗 -->
    <DsModal v-model="approvalVisible" title="新增首营申请" :width="440">
      <div class="gsp-form">
        <label><span>类型</span><select v-model="approvalForm.type" class="ds-input"><option>首营企业</option><option>首营品种</option></select></label>
        <label><span>名称</span><input v-model="approvalForm.name" class="ds-input" /></label>
        <label><span>证照号</span><input v-model="approvalForm.licenseNo" class="ds-input" /></label>
        <label><span>证照有效期</span><DsDatePicker v-model="approvalForm.licenseExpire" /></label>
        <label><span>申请人</span><input v-model="approvalForm.applicant" class="ds-input" /></label>
      </div>
      <template #footer><div class="gsp-foot"><DsButton @click="approvalVisible = false">取消</DsButton><DsButton variant="primary" @click="saveApproval">提交</DsButton></div></template>
    </DsModal>

    <!-- 验收弹窗 -->
    <DsModal v-model="acceptanceVisible" title="新增到货验收" :width="440">
      <div class="gsp-form">
        <label><span>药品</span><input v-model="acceptanceForm.name" class="ds-input" /></label>
        <label><span>批号</span><input v-model="acceptanceForm.batchNo" class="ds-input" /></label>
        <label><span>到货数</span><input v-model.number="acceptanceForm.arriveQty" class="ds-input" type="number" /></label>
        <label><span>验收数</span><input v-model.number="acceptanceForm.acceptQty" class="ds-input" type="number" /></label>
        <label><span>验收人</span><input v-model="acceptanceForm.checker" class="ds-input" /></label>
        <label><span>结论</span><select v-model="acceptanceForm.result" class="ds-input"><option>合格</option><option>不合格</option></select></label>
      </div>
      <template #footer><div class="gsp-foot"><DsButton @click="acceptanceVisible = false">取消</DsButton><DsButton variant="primary" @click="saveAcceptance">保存</DsButton></div></template>
    </DsModal>

    <!-- 养护弹窗 -->
    <DsModal v-model="maintenanceVisible" title="新增温湿度记录" :width="440">
      <div class="gsp-form">
        <label><span>库房</span><input v-model="maintenanceForm.warehouse" class="ds-input" /></label>
        <label><span>温度(℃)</span><input v-model.number="maintenanceForm.temp" class="ds-input" type="number" /></label>
        <label><span>湿度(%)</span><input v-model.number="maintenanceForm.humidity" class="ds-input" type="number" /></label>
        <label><span>记录人</span><input v-model="maintenanceForm.recorder" class="ds-input" /></label>
      </div>
      <template #footer><div class="gsp-foot"><DsButton @click="maintenanceVisible = false">取消</DsButton><DsButton variant="primary" @click="saveMaintenance">保存</DsButton></div></template>
    </DsModal>
  </div>
</template>

<script setup lang="ts">
/** GSP 合规：效期分级 + 首营审批(校验有效期) + 验收 + 温湿度异常判定，全部留痕。 */
import { computed, onMounted, reactive, ref } from 'vue';
import { DsButton, DsCard, DsModal, DsTag } from '../../components';
import { mockGet, mockPost } from '../../api/mockAdapter';
import { emit, Events } from '../../utils/eventBus';
import { useToast } from '../../components/ds/toast';

interface Batch { id: number; batchNo: string; name: string; spec: string; manufacturer: string; produceDate: string; expireDate: string; qty: number; saleStatus?: string; }
interface Approval { id: number; type: string; name: string; licenseNo: string; licenseExpire: string; applicant: string; status: string; comment?: string; }
interface Acceptance { id: number; no: string; name: string; batchNo: string; arriveQty: number; acceptQty: number; result: string; checker: string; createdAt: string; status?: string; }
interface Maintenance { id: number; warehouse: string; temp: number; humidity: number; abnormal: boolean; recorder: string; createdAt: string; }

const toast = useToast();
const tabs = [{ key: 'batch', label: '批次效期' }, { key: 'approval', label: '首营审批' }, { key: 'acceptance', label: '到货验收' }, { key: 'maintenance', label: '温湿度养护' }];
const active = ref('batch');
const levelFilter = ref('');
const batches = ref<Batch[]>([]);
const approvals = ref<Approval[]>([]);
const acceptances = ref<Acceptance[]>([]);
const maintenances = ref<Maintenance[]>([]);
const batchVisible = ref(false);
const approvalVisible = ref(false);
const acceptanceVisible = ref(false);
const maintenanceVisible = ref(false);

const batchForm = reactive<any>({ batchNo: '', name: '', spec: '', manufacturer: '', produceDate: '', expireDate: '', qty: 0 });
const approvalForm = reactive<any>({ type: '首营企业', name: '', licenseNo: '', licenseExpire: '', applicant: '' });
const acceptanceForm = reactive<any>({ name: '', batchNo: '', arriveQty: 0, acceptQty: 0, result: '合格', checker: '' });
const maintenanceForm = reactive<any>({ warehouse: '常温库', temp: 20, humidity: 60, recorder: '' });

/** 剩余天数：按本地日期计算，避免时区导致差一天 */
function daysLeft(b: Batch): number {
  if (!b.expireDate) return 0;
  const exp = new Date(b.expireDate + 'T00:00:00');
  const today = new Date(); today.setHours(0, 0, 0, 0);
  return Math.round((exp.getTime() - today.getTime()) / 86400000);
}
function expireLevel(b: Batch): string { const d = daysLeft(b); return d < 0 ? '已过期' : d <= 30 ? '近效期' : d <= 90 ? '关注' : '正常'; }
function levelColor(level: string): any { return { '已过期': 'danger', '近效期': 'warning', '关注': 'warning', '正常': 'success' }[level] || 'neutral'; }
function daysClass(b: Batch): string { const l = expireLevel(b); return l === '已过期' ? 'gsp-danger' : l === '近效期' ? 'gsp-warn' : ''; }
function approvalColor(s: string): any { return s === '通过' ? 'success' : s === '驳回' ? 'danger' : 'warning'; }

const filteredBatches = computed(() => [...batches.value].filter((b) => !levelFilter.value || expireLevel(b) === levelFilter.value).sort((a, b) => daysLeft(a) - daysLeft(b)));
const stats = computed(() => [
  { label: '在库批次', value: String(batches.value.length), tone: '' },
  { label: '近效期(≤30天)', value: String(batches.value.filter((b) => expireLevel(b) === '近效期').length), tone: 'gsp-warn' },
  { label: '已过期', value: String(batches.value.filter((b) => expireLevel(b) === '已过期').length), tone: 'gsp-danger' },
  { label: '待审资质', value: String(approvals.value.filter((a) => a.status === '待审').length), tone: 'gsp-brand' },
]);

async function load(): Promise<void> {
  const loadList = async (url: string) => { const r: any = await mockGet(url, { pageSize: 200 }); return Array.isArray(r) ? r : r?.list || []; };
  batches.value = await loadList('/api/v1/industry/gspBatches');
  if (!batches.value.length) {
    const seed: Batch[] = [
      { id: 1, batchNo: 'P20260901', name: '感冒灵颗粒', spec: '10g*12袋', manufacturer: '华润三九', produceDate: '2026-09-01', expireDate: '2026-12-05', qty: 120 },
      { id: 2, batchNo: 'P20260512', name: '维生素C片', spec: '100mg*100片', manufacturer: '石药集团', produceDate: '2026-05-12', expireDate: '2027-05-11', qty: 300 },
      { id: 3, batchNo: 'P20250820', name: '阿莫西林胶囊', spec: '0.25g*24粒', manufacturer: '联邦制药', produceDate: '2025-08-20', expireDate: '2026-11-15', qty: 45 },
      { id: 4, batchNo: 'P20261002', name: '布洛芬缓释胶囊', spec: '0.3g*20粒', manufacturer: '中美史克', produceDate: '2026-10-02', expireDate: '2028-04-01', qty: 200 },
      { id: 5, batchNo: 'P20260315', name: '创可贴', spec: '100片装', manufacturer: '云南白药', produceDate: '2026-03-15', expireDate: '2027-03-14', qty: 500 },
    ];
    for (const b of seed) await mockPost('/api/v1/industry/gspBatches', b);
    batches.value = seed;
  }
  approvals.value = await loadList('/api/v1/industry/gspApprovals');
  acceptances.value = await loadList('/api/v1/industry/gspAcceptances');
  maintenances.value = await loadList('/api/v1/industry/gspMaintenance');
}

/** 新增批次：有效期必须晚于生产日期，违反则拦截 */
async function saveBatch(): Promise<void> {
  if (!batchForm.batchNo || !batchForm.name) { toast.warning('请填写批号与品名'); return; }
  if (batchForm.produceDate && batchForm.expireDate && batchForm.expireDate <= batchForm.produceDate) { toast.warning('有效期必须晚于生产日期'); return; }
  const batch: Batch = { id: Date.now(), ...batchForm };
  const saved: any = await mockPost('/api/v1/industry/gspBatches', batch);
  batches.value.push({ ...batch, id: saved?.id || batch.id });
  batchVisible.value = false; toast.success('批次已新增');
}
async function lockBatch(b: Batch): Promise<void> { await mockPost('/api/v1/industry/gspBatches', { ...b, saleStatus: '禁售' }); b.saleStatus = '禁售'; toast.success(`${b.batchNo} 已锁定禁售`); }
async function unlockBatch(b: Batch): Promise<void> { await mockPost('/api/v1/industry/gspBatches', { ...b, saleStatus: '可销售' }); b.saleStatus = '可销售'; toast.success(`${b.batchNo} 已解锁`); }

/** 首营审批：证照过期直接驳回，避免合规风险 */
async function reviewApproval(a: Approval, action: '通过' | '驳回'): Promise<void> {
  let comment = '人工审核';
  if (action === '通过' && a.licenseExpire && a.licenseExpire < new Date().toISOString().slice(0, 10)) { action = '驳回'; comment = '证照已过期，不予通过'; }
  await mockPost('/api/v1/industry/gspApprovals', { ...a, status: action, comment });
  a.status = action; a.comment = comment;
  emit(Events.APPROVAL_DONE, { type: 'GSP_FIRST', name: a.name, action });
  toast[action === '通过' ? 'success' : 'warning'](`${a.name} 已${action}${comment !== '人工审核' ? '：' + comment : ''}`);
}
async function saveApproval(): Promise<void> {
  if (!approvalForm.name || !approvalForm.licenseNo) { toast.warning('请填写名称与证照号'); return; }
  const a: Approval = { id: Date.now(), ...approvalForm, status: '待审' };
  const saved: any = await mockPost('/api/v1/industry/gspApprovals', a);
  approvals.value.push({ ...a, id: saved?.id || a.id }); approvalVisible.value = false; toast.success('申请已提交');
}
async function saveAcceptance(): Promise<void> {
  if (!acceptanceForm.name) { toast.warning('请填写药品名称'); return; }
  const a: Acceptance = { id: Date.now(), no: `YS${Date.now().toString().slice(-6)}`, ...acceptanceForm, createdAt: new Date().toLocaleString('zh-CN') };
  const saved: any = await mockPost('/api/v1/industry/gspAcceptances', a);
  acceptances.value.push({ ...a, id: saved?.id || a.id });
  if (a.result === '不合格') await mockPost('/api/v1/industry/gspTasks', { type: '不合格品处理', name: a.name, batchNo: a.batchNo, createdAt: a.createdAt });
  acceptanceVisible.value = false; toast.success('验收记录已保存');
}
async function returnGoods(a: Acceptance): Promise<void> { await mockPost('/api/v1/industry/gspAcceptances', { ...a, status: '已退货' }); a.status = '已退货'; toast.success('已登记退货'); }

/** 温湿度异常：温度>25 或 湿度>75 视为异常，自动生成养护任务 */
async function saveMaintenance(): Promise<void> {
  if (!maintenanceForm.recorder) { toast.warning('请填写记录人'); return; }
  const abnormal = Number(maintenanceForm.temp) > 25 || Number(maintenanceForm.humidity) > 75;
  const m: Maintenance = { id: Date.now(), ...maintenanceForm, abnormal, createdAt: new Date().toLocaleString('zh-CN') };
  const saved: any = await mockPost('/api/v1/industry/gspMaintenance', m);
  maintenances.value.push({ ...m, id: saved?.id || m.id });
  if (abnormal) await mockPost('/api/v1/industry/gspTasks', { type: '温湿度异常养护', warehouse: m.warehouse, temp: m.temp, humidity: m.humidity, createdAt: m.createdAt });
  maintenanceVisible.value = false;
  toast[abnormal ? 'warning' : 'success'](abnormal ? '环境异常，已生成养护任务' : '记录已保存');
}
onMounted(load);
</script>

<style scoped>
.gsp-page { display: flex; flex-direction: column; gap: 14px; padding: 16px; }
.gsp-stats { display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px; }
.gsp-stat { border: 1px solid var(--ds-border); border-radius: 10px; padding: 14px 16px; background: var(--ds-bg-elevated); display: flex; flex-direction: column; gap: 6px; }
.gsp-stat span { font-size: 12px; color: var(--ds-text-3); }
.gsp-stat b { font-size: 22px; }
.gsp-brand { color: var(--ds-brand); }
.gsp-warn { color: var(--ds-warning); }
.gsp-danger { color: var(--ds-danger); }
.gsp-tabs { display: flex; gap: 8px; flex-wrap: wrap; }
.gsp-tab { border: 1px solid var(--ds-border); background: var(--ds-bg-elevated); border-radius: 6px; padding: 7px 14px; font-size: 13px; cursor: pointer; }
.gsp-tab.on { background: var(--ds-brand); color: #fff; border-color: var(--ds-brand); }
.gsp-tools { display: flex; gap: 8px; }
.gsp-body { padding: 16px; display: flex; flex-direction: column; gap: 10px; }
.gsp-table { width: 100%; border-collapse: collapse; font-size: 13px; }
.gsp-table th, .gsp-table td { padding: 9px 10px; border-bottom: 1px solid var(--ds-divider); text-align: left; }
.gsp-table th { background: var(--ds-bg-soft); color: var(--ds-text-3); }
.gsp-ops { display: flex; gap: 6px; }
.gsp-comment { color: var(--ds-text-3); font-size: 12px; }
.gsp-empty { padding: 24px; text-align: center; color: var(--ds-text-3); }
.gsp-hint { font-size: 12px; color: var(--ds-text-3); }
.gsp-form { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
.gsp-form label { display: flex; flex-direction: column; gap: 5px; font-size: 12px; }
.gsp-foot { display: flex; justify-content: flex-end; gap: 8px; }
@media (max-width: 1024px) { .gsp-stats { grid-template-columns: repeat(2, 1fr); } .gsp-table { font-size: 12px; } }
</style>
