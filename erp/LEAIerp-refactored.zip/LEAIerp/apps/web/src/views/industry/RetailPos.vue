<!-- 零售 POS 深度收银中心：选购→促销/会员→收款→小票→交班，全链路写入本地 Mock -->
<template>
  <div class="pos-page">
    <!-- 经营概览 -->
    <div class="pos-stats">
      <div v-for="c in stats" :key="c.label" class="pos-stat"><span>{{ c.label }}</span><b :class="c.tone">{{ c.value }}</b></div>
    </div>

    <div class="pos-layout">
      <!-- 左：商品选购 -->
      <DsCard title="商品选购" :pad="false" class="pos-goods-card">
        <template #extra>
          <input v-model="scanCode" class="ds-input pos-scan" placeholder="扫码/条码回车加入" @keyup.enter="scanAdd" />
        </template>
        <div class="pos-body">
          <div class="pos-cats">
            <button v-for="cat in categories" :key="cat" class="pos-cat" :class="{ on: activeCat === cat }" @click="activeCat = cat">{{ cat }}</button>
          </div>
          <div class="pos-goods">
            <button v-for="p in filteredGoods" :key="p.id" class="pos-good" @click="addGood(p)">
              <span class="pos-good__name">{{ p.name }}</span>
              <span class="pos-good__price">¥{{ Number(p.price || 0).toFixed(2) }}</span>
              <span class="pos-good__stock">库存 {{ p.stock ?? 99 }}</span>
            </button>
            <div v-if="!filteredGoods.length" class="pos-empty">该分类暂无商品</div>
          </div>
        </div>
      </DsCard>

      <!-- 右：购物车与结算 -->
      <DsCard title="当前单据" :pad="false" class="pos-cart-card">
        <template #extra><DsButton size="sm" @click="clearCart" :disabled="!cart.length">清空</DsButton></template>
        <div class="pos-body">
          <div class="pos-member">
            <input v-model="memberPhone" class="ds-input" placeholder="会员手机号（享95折+积分）" />
            <DsTag v-if="isMember" color="success" size="sm">会员 95 折</DsTag>
            <DsTag v-else color="neutral" size="sm">非会员</DsTag>
          </div>
          <div class="pos-cart">
            <div v-for="(l, i) in cart" :key="l.productId" class="pos-line">
              <span class="pos-line__name">{{ l.name }}</span>
              <div class="pos-line__qty">
                <button @click="changeQty(i, -1)">−</button><b>{{ l.qty }}</b><button @click="changeQty(i, 1)">+</button>
              </div>
              <span class="pos-line__amt">¥{{ (l.price * l.qty).toFixed(2) }}</span>
              <button class="pos-line__del" @click="cart.splice(i, 1)">✕</button>
            </div>
            <div v-if="!cart.length" class="pos-empty">购物车为空，请选购商品</div>
          </div>

          <div class="pos-settle">
            <div class="pos-amounts">
              <div><span>商品合计</span><b>¥{{ subtotal.toFixed(2) }}</b></div>
              <div v-if="promoDiscount > 0"><span>满减优惠</span><b class="minus">-¥{{ promoDiscount.toFixed(2) }}</b></div>
              <div v-if="memberDiscount > 0"><span>会员折扣</span><b class="minus">-¥{{ memberDiscount.toFixed(2) }}</b></div>
              <div class="pos-amounts__total"><span>应收</span><b>¥{{ payable.toFixed(2) }}</b></div>
            </div>
            <div class="pos-pay">
              <div class="pos-pay-methods">
                <button v-for="pm in payMethods" :key="pm" class="pos-pay-method" :class="{ on: payMethod === pm }" @click="payMethod = pm">{{ pm }}</button>
              </div>
              <label v-if="payMethod === '现金'" class="pos-cash">
                <span>收款</span><input v-model.number="cashReceived" class="ds-input" type="number" min="0" />
                <span class="pos-change">找零 ¥{{ change.toFixed(2) }}</span>
              </label>
            </div>
            <DsButton variant="primary" class="pos-checkout" :disabled="!cart.length" @click="checkout">收款结账</DsButton>
          </div>
        </div>
      </DsCard>
    </div>

    <!-- 订单流水 / 交班 -->
    <div class="pos-bottom">
      <DsCard title="POS 订单流水" :pad="false">
        <template #extra>
          <div class="pos-tools">
            <input v-model="orderKeyword" class="ds-input" placeholder="单号/手机号查询" />
            <DsButton size="sm" @click="shiftVisible = true">交接班/日结</DsButton>
          </div>
        </template>
        <div class="pos-body">
          <table class="pos-table">
            <thead><tr><th>单号</th><th>时间</th><th>金额</th><th>优惠</th><th>支付</th><th>会员</th><th>状态</th><th>操作</th></tr></thead>
            <tbody>
              <tr v-for="o in filteredOrders" :key="o.id">
                <td>{{ o.orderNo }}</td><td>{{ o.createdAt }}</td>
                <td>¥{{ Number(o.total).toFixed(2) }}</td><td>¥{{ Number(o.discount || 0).toFixed(2) }}</td>
                <td>{{ o.payMethod }}</td><td>{{ o.memberPhone || '—' }}</td>
                <td><DsTag :color="o.status === '已退款' ? 'danger' : 'success'" size="sm">{{ o.status }}</DsTag></td>
                <td class="pos-ops">
                  <DsButton v-if="o.status !== '已退款'" size="sm" @click="refund(o)">退款</DsButton>
                  <DsButton size="sm" @click="printReceipt(o)">小票</DsButton>
                </td>
              </tr>
              <tr v-if="!filteredOrders.length"><td colspan="8" class="pos-empty">暂无订单</td></tr>
            </tbody>
          </table>
        </div>
      </DsCard>
    </div>

    <!-- 交接班弹窗 -->
    <DsModal v-model="shiftVisible" title="交接班 / 日结" :width="480">
      <div class="pos-shift">
        <div class="pos-shift__row"><span>当班订单数</span><b>{{ orders.length }}</b></div>
        <div v-for="pm in payMethods" :key="pm" class="pos-shift__row"><span>{{ pm }}合计</span><b>¥{{ paySum(pm).toFixed(2) }}</b></div>
        <div class="pos-shift__row pos-shift__total"><span>营业额</span><b>¥{{ todayRevenue.toFixed(2) }}</b></div>
        <div class="pos-shift__row"><span>优惠合计</span><b>¥{{ orders.reduce((s, o) => s + Number(o.discount || 0), 0).toFixed(2) }}</b></div>
      </div>
      <template #footer><div class="pos-modal-foot"><DsButton @click="shiftVisible = false">取消</DsButton><DsButton variant="primary" @click="handOver">确认交班</DsButton></div></template>
    </DsModal>
  </div>
</template>

<script setup lang="ts">
/** 零售 POS 收银：商品选购 → 会员/促销计算 → 收款找零 → 订单落库 → 退款/交班，全链路闭环。 */
import { computed, onMounted, reactive, ref } from 'vue';
import { DsButton, DsCard, DsModal, DsTag } from '../../components';
import { mockGet, mockPost } from '../../api/mockAdapter';
import { emit, Events } from '../../utils/eventBus';
import { useToast } from '../../components/ds/toast';

interface CartLine { productId: number; name: string; price: number; qty: number; }
interface PosOrder { id: number; orderNo: string; createdAt: string; total: number; discount: number; payMethod: string; memberPhone: string; status: string; lines: CartLine[]; points?: number; }

const toast = useToast();
const scanCode = ref('');
const memberPhone = ref('');
const goods = ref<any[]>([]);
const activeCat = ref('全部');
const categories = ['全部', '食品饮料', '日用百货', '数码电子'];
const cart = ref<CartLine[]>([]);
const orders = ref<PosOrder[]>([]);
const orderKeyword = ref('');
const payMethods = ['现金', '微信', '支付宝', '银行卡'];
const payMethod = ref('现金');
const cashReceived = ref<number>(0);
const shiftVisible = ref(false);

const isMember = computed(() => /^1\d{10}$/.test(memberPhone.value.trim()));
const subtotal = computed(() => cart.value.reduce((s, l) => s + l.price * l.qty, 0));
/** 促销：满200减30、满100减10，只取最高一档，避免叠加导致亏损 */
const promoDiscount = computed(() => subtotal.value >= 200 ? 30 : subtotal.value >= 100 ? 10 : 0);
/** 会员折扣：对小计与满减后的金额再打 95 折 */
const memberDiscount = computed(() => isMember.value ? (subtotal.value - promoDiscount.value) * 0.05 : 0);
const payable = computed(() => Math.max(0, subtotal.value - promoDiscount.value - memberDiscount.value));
const change = computed(() => Math.max(0, Number(cashReceived.value || 0) - payable.value));
const today = new Date().toISOString().slice(0, 10);
const todayOrders = computed(() => orders.value.filter((o) => String(o.createdAt).startsWith(today) && o.status !== '已退款'));
const todayRevenue = computed(() => todayOrders.value.reduce((s, o) => s + Number(o.total), 0));
const stats = computed(() => [
  { label: '今日营业额', value: `¥${todayRevenue.value.toFixed(2)}`, tone: 'pos-stat__brand' },
  { label: '今日订单', value: String(todayOrders.value.length), tone: '' },
  { label: '客单价', value: `¥${todayOrders.value.length ? (todayRevenue.value / todayOrders.value.length).toFixed(2) : '0.00'}`, tone: '' },
  { label: '退款单数', value: String(orders.value.filter((o) => o.status === '已退款').length), tone: 'pos-stat__warn' },
]);
const filteredGoods = computed(() => activeCat.value === '全部' ? goods.value : goods.value.filter((p) => p.categoryName === activeCat.value));
const filteredOrders = computed(() => {
  const kw = orderKeyword.value.trim().toLowerCase();
  return [...orders.value].reverse().filter((o) => !kw || o.orderNo.toLowerCase().includes(kw) || o.memberPhone.includes(kw));
});

/** 加载商品与订单；Mock 无数据时给出演示商品，保证可立即操作 */
async function load(): Promise<void> {
  const g: any = await mockGet('/api/v1/inventory/products', { pageSize: 100 });
  const list = Array.isArray(g) ? g : g?.list || [];
  goods.value = list.length ? list.map((p: any, i: number) => ({ ...p, categoryName: p.categoryName || categories[i % 3 + 1] || '日用百货', stock: p.stock ?? 99 })) : [
    { id: 1, name: '矿泉水 550ml', price: 2.5, barcode: '690000000001', categoryName: '食品饮料', stock: 88 },
    { id: 2, name: 'A4 复印纸', price: 26, barcode: '690000000002', categoryName: '日用百货', stock: 40 },
    { id: 3, name: '中性笔', price: 3.5, barcode: '690000000003', categoryName: '日用百货', stock: 120 },
    { id: 4, name: '无线鼠标', price: 59, barcode: '690000000004', categoryName: '数码电子', stock: 15 },
  ];
  const o: any = await mockGet('/api/v1/industry/posOrders', { pageSize: 200 });
  orders.value = Array.isArray(o) ? o : o?.list || [];
}
function addGood(p: any): void {
  const line = cart.value.find((l) => l.productId === Number(p.id));
  if (line) line.qty += 1;
  else cart.value.push({ productId: Number(p.id), name: p.name, price: Number(p.price || 0), qty: 1 });
}
/** 扫码：按条码/编码匹配商品，未匹配给出明确提示 */
function scanAdd(): void {
  const code = scanCode.value.trim();
  if (!code) return;
  const p = goods.value.find((x) => x.barcode === code || x.code === code);
  if (!p) { toast.warning(`未找到条码为 ${code} 的商品`); return; }
  addGood(p); scanCode.value = '';
}
function changeQty(i: number, delta: number): void {
  const l = cart.value[i]; l.qty += delta;
  if (l.qty <= 0) cart.value.splice(i, 1);
}
function clearCart(): void { cart.value = []; cashReceived.value = 0; }

/** 结账：校验现金找零 → 生成含优惠/积分的订单 → 落库并发布事件 */
async function checkout(): Promise<void> {
  if (!cart.value.length) { toast.warning('购物车为空'); return; }
  if (payMethod.value === '现金' && Number(cashReceived.value || 0) < payable.value) { toast.warning('收款金额不足，请确认现金'); return; }
  const orderNo = `POS${today.replace(/-/g, '')}-${String(orders.value.length + 1).padStart(4, '0')}`;
  const order: PosOrder = {
    id: Date.now(), orderNo, createdAt: new Date().toLocaleString('zh-CN'),
    total: Number(payable.value.toFixed(2)), discount: Number((promoDiscount.value + memberDiscount.value).toFixed(2)),
    payMethod: payMethod.value, memberPhone: isMember.value ? memberPhone.value.trim() : '',
    status: '已完成', lines: cart.value.map((l) => ({ ...l })), points: isMember.value ? Math.floor(payable.value) : 0,
  };
  const saved: any = await mockPost('/api/v1/industry/posOrders', order);
  orders.value.push({ ...order, id: saved?.id || order.id });
  if (isMember.value) await mockPost('/api/v1/industry/posMembers', { phone: memberPhone.value, points: order.points, createdAt: order.createdAt });
  emit(Events.ORDER_CONFIRMED, { type: 'POS', total: order.total, orderNo });
  toast.success(`收款成功 ¥${order.total.toFixed(2)}${order.points ? `，积分 +${order.points}` : ''}`);
  clearCart(); memberPhone.value = '';
}
/** 退款：状态标记（不物理删除），保留审计轨迹 */
async function refund(o: PosOrder): Promise<void> {
  if (o.status === '已退款') { toast.warning('该订单已退款'); return; }
  await mockPost('/api/v1/industry/posRefunds', { orderId: o.id, orderNo: o.orderNo, amount: o.total, createdAt: new Date().toLocaleString('zh-CN') });
  // 回写订单状态，避免刷新后复原导致重复退款
  await mockPost('/api/v1/industry/posOrders', { ...o, status: '已退款' });
  o.status = '已退款'; emit(Events.ORDER_CONFIRMED, { type: 'POS_REFUND', total: o.total });
  toast.success(`已退款 ¥${Number(o.total).toFixed(2)}`);
}
function printReceipt(o: PosOrder): void {
  emit(Events.PRINT_DONE, { type: 'POS_RECEIPT', order: o });
  toast.success(`小票已发送到打印队列：${o.orderNo}`);
}
function paySum(pm: string): number { return todayOrders.value.filter((o) => o.payMethod === pm).reduce((s, o) => s + Number(o.total), 0); }
async function handOver(): Promise<void> {
  await mockPost('/api/v1/industry/posShifts', { createdAt: new Date().toLocaleString('zh-CN'), orderCount: orders.value.length, revenue: Number(todayRevenue.value.toFixed(2)), byMethod: payMethods.map((pm) => ({ pm, amount: paySum(pm) })) });
  shiftVisible.value = false; toast.success('交接班完成，当班数据已归档');
}
onMounted(load);
</script>

<style scoped>
.pos-page { display: flex; flex-direction: column; gap: 14px; padding: 16px; }
.pos-stats { display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px; }
.pos-stat { border: 1px solid var(--ds-border); border-radius: 10px; padding: 14px 16px; background: var(--ds-bg-elevated); display: flex; flex-direction: column; gap: 6px; }
.pos-stat span { font-size: 12px; color: var(--ds-text-3); }
.pos-stat b { font-size: 22px; }
.pos-stat__brand { color: var(--ds-brand); }
.pos-stat__warn { color: var(--ds-danger); }
.pos-layout { display: grid; grid-template-columns: 1.2fr 1fr; gap: 14px; align-items: start; }
.pos-body { padding: 16px; display: flex; flex-direction: column; gap: 12px; }
.pos-scan { width: 220px; }
.pos-cats { display: flex; gap: 8px; flex-wrap: wrap; }
.pos-cat { border: 1px solid var(--ds-border); background: var(--ds-bg-elevated); border-radius: 999px; padding: 5px 12px; font-size: 12px; cursor: pointer; }
.pos-cat.on { background: var(--ds-brand); color: #fff; border-color: var(--ds-brand); }
.pos-goods { display: grid; grid-template-columns: repeat(auto-fill, minmax(130px, 1fr)); gap: 10px; max-height: 320px; overflow: auto; }
.pos-good { display: flex; flex-direction: column; gap: 4px; align-items: flex-start; border: 1px solid var(--ds-border); border-radius: 8px; padding: 10px; background: var(--ds-bg-elevated); cursor: pointer; text-align: left; }
.pos-good:hover { border-color: var(--ds-brand); }
.pos-good__name { font-size: 13px; font-weight: 600; }
.pos-good__price { color: var(--ds-brand); font-weight: 700; }
.pos-good__stock { font-size: 11px; color: var(--ds-text-3); }
.pos-member { display: flex; align-items: center; gap: 8px; }
.pos-member .ds-input { flex: 1; }
.pos-cart { border: 1px solid var(--ds-border); border-radius: 8px; min-height: 140px; max-height: 240px; overflow: auto; }
.pos-line { display: flex; align-items: center; gap: 8px; padding: 8px 10px; border-bottom: 1px solid var(--ds-divider); font-size: 13px; }
.pos-line__name { flex: 1; }
.pos-line__qty { display: flex; align-items: center; gap: 6px; }
.pos-line__qty button { width: 22px; height: 22px; border: 1px solid var(--ds-border); background: var(--ds-bg-soft); border-radius: 4px; cursor: pointer; }
.pos-line__amt { width: 70px; text-align: right; }
.pos-line__del { border: 0; background: transparent; color: var(--ds-danger); cursor: pointer; }
.pos-empty { padding: 28px; text-align: center; color: var(--ds-text-3); font-size: 12px; }
.pos-settle { border-top: 1px solid var(--ds-divider); padding-top: 12px; display: flex; flex-direction: column; gap: 12px; }
.pos-amounts { display: flex; flex-direction: column; gap: 6px; }
.pos-amounts > div { display: flex; justify-content: space-between; font-size: 13px; }
.pos-amounts .minus { color: var(--ds-danger); }
.pos-amounts__total { font-size: 17px; font-weight: 700; }
.pos-amounts__total b { color: var(--ds-brand); }
.pos-pay { display: flex; flex-direction: column; gap: 8px; }
.pos-pay-methods { display: flex; gap: 8px; }
.pos-pay-method { flex: 1; border: 1px solid var(--ds-border); background: var(--ds-bg-elevated); border-radius: 6px; padding: 7px; font-size: 12px; cursor: pointer; }
.pos-pay-method.on { border-color: var(--ds-brand); background: var(--ds-brand-soft); color: var(--ds-brand); }
.pos-cash { display: flex; align-items: center; gap: 8px; font-size: 13px; }
.pos-cash .ds-input { width: 120px; }
.pos-change { margin-left: auto; color: var(--ds-brand); font-weight: 600; }
.pos-checkout { width: 100%; }
.pos-tools { display: flex; gap: 8px; }
.pos-table { width: 100%; border-collapse: collapse; font-size: 13px; }
.pos-table th, .pos-table td { padding: 9px 10px; border-bottom: 1px solid var(--ds-divider); text-align: left; }
.pos-table th { background: var(--ds-bg-soft); color: var(--ds-text-3); }
.pos-ops { display: flex; gap: 6px; }
.pos-shift { display: flex; flex-direction: column; gap: 10px; }
.pos-shift__row { display: flex; justify-content: space-between; font-size: 13px; }
.pos-shift__total { font-size: 16px; font-weight: 700; color: var(--ds-brand); }
.pos-modal-foot, .pos-shift__row + .pos-shift__total { display: flex; justify-content: flex-end; gap: 8px; }
@media (max-width: 1024px) { .pos-stats { grid-template-columns: repeat(2, 1fr); } .pos-layout { grid-template-columns: 1fr; } }
</style>
