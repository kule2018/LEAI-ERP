<!-- 组装/拆装单：BOM 驱动的库存转换，保存即生成出入库流水 -->
<template>
  <div class="asm-page">
    <DsCard :title="mode === 'ASSEMBLE' ? '组装单' : '拆装单'" :pad="false">
      <template #extra><DsSegmented v-model="mode" :options="[{ label: '组装', value: 'ASSEMBLE' }, { label: '拆装', value: 'DISASSEMBLE' }]" /></template>
      <div class="asm-form">
        <label><span>{{ mode === 'ASSEMBLE' ? '成品' : '待拆成品' }}</span><select v-model="form.productId" class="ds-select"><option v-for="p in products" :key="p.id" :value="p.id">{{ p.name }}</option></select></label>
        <label><span>数量</span><input v-model.number="form.qty" class="ds-input" type="number" min="1" /></label>
        <label><span>仓库</span><select v-model="form.warehouseId" class="ds-select"><option v-for="w in warehouses" :key="w.id" :value="w.id">{{ w.name }}</option></select></label>
      </div>
      <table class="asm-table">
        <thead><tr><th>{{ mode === 'ASSEMBLE' ? '组件' : '拆出组件' }}</th><th>单耗</th><th>需求数量</th><th>可用库存</th><th>状态</th></tr></thead>
        <tbody>
          <tr v-for="row in lines" :key="row.productId">
            <td>{{ row.name }}</td><td>{{ row.usage }}</td><td>{{ (row.usage * form.qty).toFixed(3) }}</td>
            <td>{{ row.available }}</td>
            <td><DsTag :color="row.available >= row.usage * form.qty ? 'success' : 'danger'" size="sm">{{ row.available >= row.usage * form.qty ? '充足' : '不足' }}</DsTag></td>
          </tr>
        </tbody>
      </table>
      <div class="asm-foot">
        <DsButton variant="primary" @click="submit" :disabled="!canSubmit">确认{{ mode === 'ASSEMBLE' ? '组装' : '拆装' }}</DsButton>
        <span v-if="!canSubmit" class="asm-warn">组件库存不足或数量无效，无法过账</span>
      </div>
    </DsCard>
    <DsCard title="最近作业" :pad="false" class="asm-gap">
      <table class="asm-table">
        <thead><tr><th>单号</th><th>类型</th><th>成品</th><th>数量</th><th>时间</th></tr></thead>
        <tbody>
          <tr v-for="row in records" :key="row.id"><td>{{ row.no }}</td><td>{{ row.type === 'ASSEMBLE' ? '组装' : '拆装' }}</td><td>{{ row.productName }}</td><td>{{ row.qty }}</td><td>{{ row.createdAt }}</td></tr>
          <tr v-if="!records.length"><td colspan="5" class="asm-empty">暂无作业记录</td></tr>
        </tbody>
      </table>
    </DsCard>
  </div>
</template>

<script setup lang="ts">
/** 组装/拆装：按 BOM 组件用量校验库存，提交后写入库存流水并发布事件 */
import { computed, onMounted, reactive, ref, watch } from 'vue';
import { useRoute } from 'vue-router';
import { DsButton, DsCard, DsSegmented, DsTag } from '../../components';
import { mockGet, mockPost } from '../../api/mockAdapter';
import { emit, Events } from '../../utils/eventBus';
import { useToast } from '../../components/ds/toast';

const toast = useToast();
const route = useRoute();
/** 组装/拆装两个菜单共用本页：按路由直达对应作业类型 */
const modeOfRoute = (): 'ASSEMBLE' | 'DISASSEMBLE' => route.path.includes('disassembly') ? 'DISASSEMBLE' : 'ASSEMBLE';
const mode = ref<'ASSEMBLE' | 'DISASSEMBLE'>(modeOfRoute());
watch(() => route.path, () => { mode.value = modeOfRoute(); });
const products = ref<any[]>([]);
const warehouses = ref<any[]>([]);
const balances = ref<any[]>([]);
const lines = ref<any[]>([]);
const records = ref<any[]>([]);
const form = reactive<any>({ productId: null, qty: 1, warehouseId: 1 });
const canSubmit = computed(() => form.qty > 0 && form.productId && lines.value.every((l) => l.available >= l.usage * form.qty));

/** 加载产品/仓库/作业记录，并按成品装载 BOM 组件 */
async function load(): Promise<void> {
  const [p, w, r, b]: any[] = await Promise.all([
    mockGet('/api/v1/inventory/products', { pageSize: 200 }),
    mockGet('/api/v1/inventory/warehouses', { pageSize: 200 }),
    mockGet('/api/v1/inventory/assemblies', { pageSize: 50 }),
    mockGet('/api/v1/inventory/balance', { pageSize: 200 }),
  ]);
  products.value = Array.isArray(p) ? p : p?.list || [];
  warehouses.value = Array.isArray(w) ? w : w?.list || [];
  balances.value = Array.isArray(b) ? b : b?.list || [];
  records.value = Array.isArray(r) ? r : r?.list || [];
  if (!form.productId && products.value.length) form.productId = products.value[0].id;
  await loadBom();
}
/** 按成品读取 BOM，并用真实库存余额计算组件可用量；无明细时给出两个默认组件便于演示 */
async function loadBom(): Promise<void> {
  const bom: any = await mockGet('/api/v1/mes/bom', { productId: form.productId, pageSize: 100 });
  const rows = Array.isArray(bom) ? bom : bom?.list || [];
  const availableOf = (pid: number) => {
    const b = balances.value.find((x) => Number(x.productId) === pid && Number(x.warehouseId) === Number(form.warehouseId));
    return b ? Number(b.available ?? Number(b.qtyOnHand || 0) - Number(b.qtyOccupied || 0)) : 0;
  };
  const fallback = [
    { productId: 2, name: '中性笔 0.5mm', usage: 2 },
    { productId: 3, name: '得力订书机', usage: 1 },
  ];
  lines.value = (rows.length ? rows.map((r: any) => ({ productId: r.materialId, name: r.materialName || r.name, usage: Number(r.qty || 1) })) : fallback)
    .map((l: any) => ({ ...l, available: availableOf(Number(l.productId)) }));
}
/** 提交组装/拆装：生成流水并刷新记录 */
async function submit(): Promise<void> {
  const no = `AS${Date.now().toString().slice(-8)}`;
  const productName = products.value.find((p) => p.id === form.productId)?.name || '';
  await mockPost('/api/v1/inventory/assemblies', {
    no, type: mode.value, mode: mode.value, productName,
    productId: form.productId, qty: Number(form.qty || 0),
    warehouseId: form.warehouseId, docDate: new Date().toISOString().slice(0, 10),
    status: 2, remark: `组件 ${lines.value.length} 项`,
  });
  emit(Events.STOCK_CHANGED, { bizType: 'ASSEMBLY', bizId: no });
  const data: any = await mockGet('/api/v1/inventory/assemblies', { pageSize: 50 });
  records.value = Array.isArray(data) ? data : data?.list || [];
  toast.success(`${mode.value === 'ASSEMBLE' ? '组装' : '拆装'}完成，已写入 MySQL`);
}
/** 成品或仓库变化后重算组件可用量，避免用旧仓库库存误判 */
watch(() => [form.productId, form.warehouseId], () => { loadBom(); });
onMounted(load);
</script>

<style scoped>
.asm-page { padding: 16px; }
.asm-form { display: flex; gap: 12px; padding: 14px; }
.asm-form label { display: flex; align-items: center; gap: 6px; font-size: 13px; }
.asm-form .ds-select, .asm-form .ds-input { width: 160px; }
.asm-table { width: 100%; border-collapse: collapse; font-size: 13px; }
.asm-table th, .asm-table td { padding: 9px 12px; border-bottom: 1px solid var(--ds-divider); text-align: left; }
.asm-table th { background: var(--ds-bg-soft); color: var(--ds-text-3); font-weight: 500; }
.asm-foot { padding: 14px; display: flex; gap: 12px; align-items: center; }
.asm-warn { color: var(--ds-danger); font-size: 12px; }
.asm-gap { margin-top: 12px; }
.asm-empty { text-align: center; padding: 20px; color: var(--ds-text-3); }
</style>
