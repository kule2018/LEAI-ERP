<template><RecordPage :config="page" /></template>

<script setup lang="ts">
import RecordPage from '../records/RecordPage.vue';
import type { RecordPageConfig } from '../records/records';

const page: RecordPageConfig = {
  title: '批次追踪',
  resource: 'inventory/batch-traces',
  schema: 'inventoryBatchTraces',
  filters: ['batchNo', 'productName', 'expireDate', 'status'],
  reportSource: '查询批次、有效期和批次库存',
};
</script>
