<template>
  <div class="erp-page">
    <DsCard title="创建产品">
      <form class="record-form" @submit.prevent="save">
        <label>产品名称 <input v-model.trim="form.name" class="ds-input" required maxlength="128" /></label>
        <label>产品编码 <input v-model.trim="form.code" class="ds-input" required maxlength="64" /></label>
        <label>产品类型 <select v-model.number="form.type" class="ds-select"><option :value="1">标准产品</option><option :value="2">多规格产品</option><option :value="3">序列号产品</option><option :value="4">服务型产品</option></select></label>
        <label>条形码 <input v-model.trim="form.barcode" class="ds-input" maxlength="64" /></label>
        <label>分类 <select v-model.number="form.categoryId" class="ds-select"><option :value="0">选择分类</option><option v-for="item in categories" :key="item.id" :value="item.id">{{ item.name }}</option></select></label>
        <label>单位 <select v-model.number="form.unitId" class="ds-select"><option :value="0">选择单位</option><option v-for="item in units" :key="item.id" :value="item.id">{{ item.name }}</option></select></label>
        <label>成本 <input :value="form.cost" @input="form.cost = ($event.target as HTMLInputElement).value" class="ds-input" type="number" min="0" step="0.01" required /></label>
        <label>售价 <input :value="form.price" @input="form.price = ($event.target as HTMLInputElement).value" class="ds-input" type="number" min="0" step="0.01" required /></label>
        <label>备注 <textarea v-model.trim="form.remark" class="ds-input" rows="2" /></label>
        <label class="tracking">追踪批次 <DsSwitch v-model="form.tracking" /></label>
        <div class="record-buttons form-foot">
          <RouterLink to="/inventory/products" class="ds-btn ds-btn-default ds-btn-md">返回产品列表</RouterLink>
          <DsButton type="submit" variant="primary" :loading="saving" :disabled="loading">保存产品</DsButton>
        </div>
      </form>
      <p v-if="error" class="record-error" role="alert">{{ error }}</p>
    </DsCard>
  </div>
</template>

<script setup lang="ts">
import { onMounted, reactive, ref } from 'vue';
import { useRouter } from 'vue-router';
import { DsButton, DsCard, DsSwitch } from '../../components';
import { useToast } from '../../components/ds/toast';
import { pageData, pageRows, type BusinessRow } from '../../api/pageData';

const router = useRouter();
const toast = useToast();
const categories = ref<BusinessRow[]>([]);
const units = ref<BusinessRow[]>([]);
const loading = ref(true);
const saving = ref(false);
const error = ref('');
const form = reactive({ name: '', code: '', type: 1, barcode: '', categoryId: 0, unitId: 0, cost: '0.00', price: '0.00', remark: '', tracking: false });

onMounted(async () => {
  try {
    const [categoryData, unitData] = await Promise.all([
      pageData<BusinessRow[]>('GET', '/api/v1/inventory/categories'),
      pageData<BusinessRow[]>('GET', '/api/v1/system/dicts/unit'),
    ]);
    categories.value = pageRows(categoryData);
    units.value = pageRows(unitData);
  } catch (cause) {
    error.value = cause instanceof Error ? cause.message : '分类与单位加载失败';
  } finally {
    loading.value = false;
  }
});

async function save() {
  if (saving.value || loading.value || !form.name || !form.code) return;
  saving.value = true;
  error.value = '';
  try {
    await pageData('POST', '/api/v1/inventory/products', { ...form, tracking: Number(form.tracking) });
    toast.success('产品已创建');
    await router.push({ path: '/inventory/products', query: { keyword: form.code } });
  } catch (cause) {
    error.value = cause instanceof Error ? cause.message : '产品保存失败';
  } finally {
    saving.value = false;
  }
}
</script>

<style src="../records/recordPage.css"></style>
<style scoped>
.form-foot { grid-column: 1 / -1; justify-content: flex-end; }
.tracking { align-content: start; justify-items: start; }
</style>
