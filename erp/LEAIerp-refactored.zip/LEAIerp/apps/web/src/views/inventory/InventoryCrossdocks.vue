<template>
  <div class="ip-page">
    <div class="ip-head">
      <div><h2>越库直发</h2><p>越库直发 · 业务数据管理</p></div>
      <div class="ip-actions">
        <DsButton size="sm" @click="load">刷新</DsButton>
        <DsButton size="sm" @click="exportCsv">导出</DsButton>
        <DsButton variant="primary" size="sm" @click="openForm()">＋ 新建</DsButton>
      </div>
    </div>
    <div class="ip-stats">
      <div v-for="c in statCards" :key="c.label" class="ip-stat"><span>{{ c.label }}</span><b>{{ c.value }}</b></div>
    </div>
    <DsCard :pad="false">
      <div class="ip-search">
        <input v-model="q.keyword" class="ds-input" placeholder="关键字 / 编码 / 单号" @keyup.enter="reload" />
        <select v-if="hasStatus" v-model="q.status" class="ds-input"><option value="">全部状态</option><option v-for="(label,val) in statusLabels" :key="val" :value="val">{{ label }}</option></select>
        <DsButton variant="primary" size="sm" @click="reload">查询</DsButton>
        <DsButton size="sm" @click="resetQuery">重置</DsButton>
      </div>
      <div class="ip-table-wrap">
        <table class="ds-table ip-table"><thead><tr>
          <th v-for="c in columns" :key="c.prop">{{ c.label }}</th><th class="ip-ops-th">操作</th>
        </tr></thead><tbody>
          <tr v-for="(r,i) in rows" :key="r.id ?? i">
            <td v-for="c in columns" :key="c.prop">{{ display(r, c) }}</td>
            <td class="ip-ops">
              <DsButton variant="text" size="sm" @click="openForm(r)">编辑</DsButton>
              <DsButton v-for="a in actionsOf(r)" :key="a.key" variant="text" size="sm" :style="{ color: colorOf(a) }" @click="runAction(r, a)">{{ a.label }}</DsButton>
              <DsButton variant="text" size="sm" style="color: var(--ds-danger)" @click="removeRow(r)">删除</DsButton>
            </td>
          </tr>
          <tr v-if="!rows.length"><td :colspan="columns.length + 1" class="ip-empty">暂无数据</td></tr>
        </tbody></table>
      </div>
      <div class="ip-pager"><DsPagination v-model:current-page="page" :page-size="pageSize" :total="total" layout="total, prev, pager, next" @change="load" /></div>
    </DsCard>
    <DsModal v-model="formVisible" :title="(editing ? '编辑' : '新建') + '越库直发'" :width="640">
      <div class="ip-form">
        <label v-for="f in formFields" :key="f.prop" class="ip-field">
          <span>{{ f.label }}<i v-if="f.required">*</i></span>
          <select v-if="f.type === 'select'" v-model="form[f.prop]" class="ds-input"><option :value="''">请选择</option><option v-for="o in optionsOf(f)" :key="String(o.value)" :value="o.value">{{ o.label }}</option></select>
          <textarea v-else-if="f.type === 'textarea'" v-model="form[f.prop]" class="ds-input" rows="3"></textarea>
          <input v-else :type="f.type === 'number' ? 'number' : f.type === 'date' ? 'date' : 'text'" v-model="form[f.prop]" class="ds-input" :placeholder="f.placeholder" />
        </label>
      </div>
      <template #footer><div class="ip-foot"><DsButton @click="formVisible = false">取消</DsButton><DsButton variant="primary" :loading="saving" @click="save">保存</DsButton></div></template>
    </DsModal>
  </div>
</template>

<script setup lang="ts">
import { reactive, ref, computed, onMounted } from 'vue';
import { DsButton, DsCard, DsModal, DsPagination } from '../../components';
import { mockGet, mockPost, mockPatch, mockDel } from '../../api/mockAdapter';
import { useToast } from '../../components/ds/toast';
import { confirm as uiConfirm } from '../../components/ds/useConfirm';

const toast = useToast();
const API = "/api/v1/iv/crossdocks";
const COLLECTION = "ivCrossdocks";
const STATUS_FIELD = "status";
const columns = [{"prop":"code","label":"越库单号","source":""},{"prop":"name","label":"越库说明","source":""},{"prop":"productName","label":"直发物料","source":""},{"prop":"qty","label":"直发数量","source":""},{"prop":"partner","label":"客户","source":""},{"prop":"warehouse","label":"中转仓","source":""},{"prop":"status","label":"状态","source":""}];
const formFields = [{"prop":"code","label":"越库单号","type":"text","options":null,"source":"","required":true,"placeholder":""},{"prop":"name","label":"越库说明","type":"text","options":null,"source":"","required":true,"placeholder":""},{"prop":"productName","label":"直发物料","type":"text","options":null,"source":"","required":false,"placeholder":""},{"prop":"qty","label":"直发数量","type":"number","options":null,"source":"","required":false,"placeholder":""},{"prop":"partner","label":"客户","type":"text","options":null,"source":"","required":false,"placeholder":""},{"prop":"warehouse","label":"中转仓","type":"text","options":null,"source":"","required":false,"placeholder":""},{"prop":"remark","label":"备注","type":"textarea","options":null,"source":"","required":false,"placeholder":""},{"prop":"status","label":"状态","type":"select","options":[{"label":"草稿","value":0},{"label":"待处理","value":1},{"label":"已完成","value":2},{"label":"已关闭","value":3},{"label":"已驳回","value":4},{"label":"已作废","value":9}],"source":"","required":false,"placeholder":""}];
const statusLabels: Record<string, string> = {"0":"草稿","1":"待处理","2":"已完成","3":"已关闭","4":"已驳回","9":"已作废"};
const actions = [{"key":"submit","label":"提交","variant":"primary","from":[0]},{"key":"approve","label":"审核通过","variant":"primary","from":[1]},{"key":"execute","label":"执行完成","variant":"primary","from":[2]},{"key":"void","label":"作废","variant":"danger","from":[0,1,2,3]}];
const DEFAULTS: Record<string, any> = {"status":0,"qty":0,"amount":0};
const hasStatus = Object.keys(statusLabels).length > 0;
const isReport = false;

const q = reactive<{ keyword: string; status: any }>({ keyword: '', status: '' });
const rows = ref<any[]>([]);
const total = ref(0);
const page = ref(1);
const pageSize = ref(10);
const loading = ref(false);
const saving = ref(false);
const formVisible = ref(false);
const editing = ref<any>(null);
const form = reactive<Record<string, any>>({});

const statCards = computed(() => [
  { label: '记录数', value: String(rows.value.length) },
  { label: '待处理', value: String(rows.value.filter((r) => Number(r[STATUS_FIELD] ?? 0) <= 1).length) },
  { label: '已完成', value: String(rows.value.filter((r) => Number(r[STATUS_FIELD] ?? 0) >= 3).length) },
  { label: '当前页', value: String(page.value) },
]);
function statusText(v: any): string { return statusLabels[String(v)] || String(v ?? ''); }
function display(row: any, c: any): string {
  const v = row[c.prop];
  if (c.prop === STATUS_FIELD && hasStatus) return statusText(v);
  const opts = optionsOf({ prop: c.prop, source: c.source, type: 'select' } as any);
  if (opts.length) { const hit = opts.find((o) => String(o.value) === String(v)); if (hit) return String(hit.label); }
  if (v === null || v === undefined || v === '') return '—';
  const s = String(v);
  return /^\d{4}-\d{2}-\d{2}/.test(s) ? s.slice(0, 10) : s;
}
function optionsOf(f: any): any[] {
  if (f.options) return f.options;
  return (remoteOptions as any)[f.source] || (remoteOptions as any)[f.prop] || [];
}
const remoteOptions = reactive<Record<string, any[]>>({});
async function loadRemoteOptions(): Promise<void> {
  const srcs: Record<string, string> = {
    customers: '/api/v1/crm/customers', products: '/api/v1/inventory/products', orders: '/api/v1/sales/orders',
    groups: '/api/v1/crm/customer-groups', suppliers: '/api/v1/purchase/suppliers', warehouses: '/api/v1/inventory/warehouses',
  };
  const used = formFields.filter((f) => f.source).map((f) => f.source);
  await Promise.all(used.map(async (s) => {
    if (remoteOptions[s]) return;
    try {
      const d: any = await mockGet(srcs[s] || API, { pageSize: 200 });
      const list = Array.isArray(d) ? d : d?.list || [];
      remoteOptions[s] = list.map((x: any) => ({ label: x.name || x.code || x.title || ('#' + x.id), value: x.id }));
    } catch { remoteOptions[s] = []; }
  }));
}
async function load(): Promise<void> {
  loading.value = true;
  try {
    const d: any = await mockGet(API, { page: page.value, pageSize: pageSize.value, keyword: q.keyword, status: q.status });
    rows.value = Array.isArray(d) ? d : d?.list || [];
    total.value = Number(d?.total ?? rows.value.length);
  } catch (e: any) { toast.error(e?.message || '加载失败'); rows.value = []; }
  finally { loading.value = false; }
}
function reload(): void { page.value = 1; load(); }
function resetQuery(): void { q.keyword = ''; q.status = ''; reload(); }
function resetForm(): void {
  for (const k of Object.keys(form)) delete form[k];
  for (const f of formFields) form[f.prop] = DEFAULTS[f.prop] ?? (f.type === 'number' ? 0 : '');
}
function openForm(row?: any): void {
  editing.value = row || null;
  resetForm();
  if (row) for (const f of formFields) if (row[f.prop] !== undefined) form[f.prop] = row[f.prop];
  formVisible.value = true;
}
async function save(): Promise<void> {
  for (const f of formFields) {
    if (f.required && (form[f.prop] === '' || form[f.prop] === undefined || form[f.prop] === null)) { toast.warning(`请填写「${f.label}」`); return; }
  }
  saving.value = true;
  try {
    const payload: Record<string, any> = {};
    for (const f of formFields) payload[f.prop] = form[f.prop];
    if (editing.value?.id) await mockPatch(`${API}/${editing.value.id}`, payload);
    else await mockPost(API, payload);
    toast.success(editing.value ? '已保存' : '已创建');
    formVisible.value = false;
    await load();
  } catch (e: any) { toast.error(e?.message || '保存失败'); }
  finally { saving.value = false; }
}
function actionsOf(row: any): any[] {
  return actions.filter((a) => !a.from || a.from.some((s) => Number(s) === Number(row[STATUS_FIELD])));
}
function colorOf(a: any): string {
  return a.variant === 'danger' ? 'var(--ds-danger)' : a.variant === 'warning' ? 'var(--ds-warning)' : 'var(--ds-brand)';
}
async function runAction(row: any, a: any): Promise<void> {
  if (!await uiConfirm(`确定执行「${a.label}」吗？`, '业务确认')) return;
  try {
    const res: any = await mockPost(`/_biz/action/${COLLECTION}/${row.id}/${a.key}`, { label: a.label });
    toast.success(res?.message || `${a.label}成功`);
    await load();
  } catch (e: any) { toast.error(e?.message || '操作失败'); }
}
async function removeRow(row: any): Promise<void> {
  if (!await uiConfirm(`确定删除 #${row.id} 吗？`, '删除确认')) return;
  try { await mockDel(`${API}/${row.id}`); toast.success('已删除'); await load(); }
  catch (e: any) { toast.error(e?.message || '删除失败'); }
}
function exportCsv(): void {
  const head = columns.map((c) => c.label);
  const lines = [head.join(',')].concat(rows.value.map((r) => columns.map((c) => String(display(r, c)).replace(/,/g, ' ')).join(',')));
  const blob = new Blob(['\ufeff' + lines.join('\n')], { type: 'text/csv;charset=utf-8' });
  const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = '越库直发.csv'; a.click();
}
onMounted(() => { load(); if (!isReport) loadRemoteOptions(); });
</script>

<style scoped>
.ip-page { padding: 16px; }
.ip-head { display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px; }
.ip-head h2 { margin: 0 0 4px; font-size: 18px; }
.ip-head p { margin: 0; font-size: 12px; color: var(--ds-text-3); }
.ip-actions { display: flex; gap: 8px; }
.ip-stats { display: flex; gap: 12px; margin-bottom: 12px; }
.ip-stat { flex: 1; background: var(--ds-bg-soft); border-radius: 8px; padding: 10px 14px; display: flex; flex-direction: column; gap: 4px; }
.ip-stat span { font-size: 12px; color: var(--ds-text-3); }
.ip-stat b { font-size: 20px; }
.ip-search { display: flex; gap: 8px; align-items: center; padding: 12px; flex-wrap: wrap; }
.ip-search .ds-input { width: auto; }
.ip-search input:first-child { min-width: 220px; }
.ip-table-wrap { overflow-x: auto; padding: 0 12px; }
.ip-table { width: 100%; }
.ip-ops { white-space: nowrap; }
.ip-ops-th { width: 260px; }
.ip-empty { text-align: center; color: var(--ds-text-3); padding: 24px; }
.ip-pager { padding: 12px; display: flex; justify-content: flex-end; }
.ip-form { display: grid; grid-template-columns: 1fr 1fr; gap: 14px; padding: 4px; }
.ip-field { display: flex; flex-direction: column; gap: 6px; font-size: 13px; }
.ip-field span { color: var(--ds-text-2); }
.ip-field i { color: var(--ds-danger); font-style: normal; margin-left: 2px; }
.ip-foot { display: flex; justify-content: flex-end; gap: 8px; }
</style>
