<template><RecordPage :config="page" /></template>

<script setup lang="ts">
import RecordPage from '../records/RecordPage.vue';
import type { RecordPageConfig } from '../records/records';

const page: RecordPageConfig = {
  title: '退料入库',
  resource: 'inventory/material-returns',
  schema: 'inventoryMaterialReturns',
  filters: ['workOrder', 'returnDate', 'status'],
  reportSource: '生产退料入库记录',
  metrics: ['qty'],
  link: { to: '/manufacturing/material-returns', label: '办理生产退料' },
};
</script>
