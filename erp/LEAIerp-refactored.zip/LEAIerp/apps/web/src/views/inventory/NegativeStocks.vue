<template><RecordPage :config="page" /></template>

<script setup lang="ts">
import RecordPage from '../records/RecordPage.vue';
import type { RecordPageConfig } from '../records/records';

const page: RecordPageConfig = {
  title: '负库存清单',
  resource: 'inventory/negative-stocks',
  schema: 'inventoryNegativeStocks',
  filters: ['warehouseName', 'productCode'],
  reportSource: '查询可用库存小于零的库存余额',
};
</script>
