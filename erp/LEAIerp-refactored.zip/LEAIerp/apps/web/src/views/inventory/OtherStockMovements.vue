<template><RecordPage :config="page" /></template>

<script setup lang="ts">
import RecordPage from '../records/RecordPage.vue';
import type { RecordPageConfig } from '../records/records';

const page: RecordPageConfig = {
  title: '其他出入库',
  resource: 'inventory/other-in-outs',
  schema: 'inventoryOtherInOuts',
  filters: ['type', 'warehouseName', 'bizDate'],
  reportSource: '查询其他类型的出入库记录',
  metrics: ['qty'],
  link: { to: '/inventory/ledger', label: '库存流水' },
};
</script>
