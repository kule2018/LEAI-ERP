<template>
  <div class="erp-page">
    <DsCard title="打印产品条形码">
      <form class="record-buttons" @submit.prevent="load">
        <input v-model.trim="keyword" type="search" class="ds-input" aria-label="搜索产品" placeholder="产品编码或名称" />
        <DsButton type="submit" size="sm" :loading="loading">查询</DsButton>
        <DsButton size="sm" variant="primary" :disabled="!chosen.size" @click="printLabels">打印所选 {{ chosen.size }} 项</DsButton>
      </form>
      <p v-if="error" role="alert" class="record-error">{{ error }}</p>
      <div v-if="products.length" class="record-table">
        <table class="ds-table">
          <thead><tr><th>选择</th><th>产品编码</th><th>产品名称</th><th>条形码</th><th>份数</th></tr></thead>
          <tbody>
            <tr v-for="product in products" :key="product.id">
              <td><input type="checkbox" :checked="chosen.has(product.id)" :aria-label="product.name" @change="toggle(product)" /></td>
              <td>{{ product.code }}</td><td>{{ product.name }}</td><td>{{ product.barcode || product.code }}</td>
              <td><input v-if="chosen.has(product.id)" v-model.number="chosen.get(product.id)!.copies" type="number" min="1" max="50" class="ds-input copies" :aria-label="product.name + '打印份数'" /></td>
            </tr>
          </tbody>
        </table>
      </div>
      <p v-else-if="!loading && !error">没有符合查询条件的产品</p>
    </DsCard>

    <Teleport to="body">
      <section v-if="labels.length" class="product-print-sheet">
        <article v-for="(label, index) in labels" :key="index">
          <strong>{{ label.name }}</strong><img :src="label.image" :alt="label.code" />
        </article>
      </section>
    </Teleport>
  </div>
</template>

<script setup lang="ts">
import { nextTick, onMounted, ref } from 'vue';
import bwipjs from 'bwip-js';
import { DsButton, DsCard } from '../../components';
import { pageData, pageRows, type BusinessRow } from '../../api/pageData';

const products = ref<BusinessRow[]>([]);
const keyword = ref('');
const loading = ref(false);
const error = ref('');
const chosen = ref(new Map<number, { product: BusinessRow; copies: number }>());
const labels = ref<Array<{ name: string; code: string; image: string }>>([]);

async function load() {
  if (loading.value) return;
  loading.value = true;
  error.value = '';
  try {
    products.value = pageRows(await pageData('GET', '/api/v1/inventory/products', { keyword: keyword.value, pageSize: 100 }));
  } catch (cause) {
    error.value = cause instanceof Error ? cause.message : '产品加载失败';
  } finally {
    loading.value = false;
  }
}

function toggle(product: BusinessRow) {
  if (chosen.value.has(product.id)) chosen.value.delete(product.id);
  else chosen.value.set(product.id, { product, copies: 1 });
}

async function printLabels() {
  error.value = '';
  try {
    const sheet = [];
    for (const { product, copies } of chosen.value.values()) {
      if (!Number.isInteger(copies) || copies < 1 || copies > 50) throw new Error('每种产品的打印份数须为 1–50');
      const code = String(product.barcode || product.code);
      const canvas = document.createElement('canvas');
      bwipjs.toCanvas(canvas, { bcid: 'code128', text: code, scale: 2, height: 10, includetext: true, paddingwidth: 6 });
      const image = canvas.toDataURL();
      for (let i = 0; i < copies; i++) sheet.push({ name: product.name, code, image });
    }
    labels.value = sheet;
    await nextTick();
    window.print();
  } catch (cause) {
    error.value = cause instanceof Error ? cause.message : '条形码生成失败';
  }
}

onMounted(load);
</script>

<style src="../records/recordPage.css"></style>
<style>
.product-print-sheet { display: none; }
.copies { width: 72px; }
@media print {
  body:has(.product-print-sheet) > :not(.product-print-sheet) { display: none !important; }
  .product-print-sheet { display: grid; gap: 4mm; grid-template-columns: repeat(3, 1fr); }
  .product-print-sheet article { border: 1px solid #ccc; padding: 3mm; color: #111; text-align: center; break-inside: avoid; }
  .product-print-sheet img { display: block; max-width: 100%; margin: 2mm auto 0; }
}
</style>
