<!-- 多规格 SKU 中心：属性集笛卡尔积生成 SKU，成本/价格/条码/库存独立维护 -->
<template>
  <div class="sku-page">
    <DsCard title="属性集" :pad="false">
      <div class="sku-attrs">
        <div v-for="(values, name) in attributes" :key="name" class="sku-attr">
          <b>{{ name }}</b>
          <span v-for="(v, i) in values" :key="v" class="sku-chip" @click="values.splice(i, 1)">{{ v }} ✕</span>
          <input v-model="newValue[name]" class="ds-input" :placeholder="'添加' + name + '值，回车'" @keyup.enter="addValue(name)" />
        </div>
      </div>
    </DsCard>
    <DsCard :title="`SKU 列表（${skus.length} 个）`" :pad="false" class="sku-gap">
      <template #extra><DsButton variant="primary" size="sm" @click="generate">生成 SKU</DsButton></template>
      <table class="sku-table">
        <thead><tr><th>SKU 编码</th><th>规格</th><th>条码</th><th>成本</th><th>售价</th><th>实物库存</th><th>锁定</th><th>可用</th></tr></thead>
        <tbody>
          <tr v-for="row in skus" :key="row.code">
            <td>{{ row.code }}</td><td>{{ row.spec }}</td>
            <td><input v-model="row.barcode" class="ds-input sku-cell" /></td>
            <td><input v-model.number="row.cost" class="ds-input sku-cell" type="number" /></td>
            <td><input v-model.number="row.price" class="ds-input sku-cell" type="number" /></td>
            <td><input v-model.number="row.onHand" class="ds-input sku-cell" type="number" /></td>
            <td>{{ row.locked || 0 }}</td>
            <td><b :class="{ danger: row.onHand - (row.locked || 0) < 0 }">{{ row.onHand - (row.locked || 0) }}</b></td>
          </tr>
        </tbody>
      </table>
      <div class="sku-foot"><DsButton variant="primary" @click="save">保存全部</DsButton><span>主产品库存 = 全部 SKU 汇总：{{ totalStock }}</span></div>
    </DsCard>
  </div>
</template>

<script setup lang="ts">
/** 多规格 SKU：属性笛卡尔积、独立条码/价格/库存、可用量=实物-锁定 */
import { computed, onMounted, reactive, ref } from 'vue';
import { DsButton, DsCard } from '../../components';
import { mockGet, mockPost } from '../../api/mockAdapter';
import { useToast } from '../../components/ds/toast';

const toast = useToast();
const attributes = reactive<Record<string, string[]>>({ 颜色: ['红色', '黑色'], 尺码: ['S', 'M', 'L'] });
const newValue = reactive<Record<string, string>>({ 颜色: '', 尺码: '' });
const skus = ref<any[]>([]);
const totalStock = computed(() => skus.value.reduce((sum, row) => sum + Number(row.onHand || 0), 0));

/** 添加一个属性值（去重） */
function addValue(name: string): void {
  const value = newValue[name].trim();
  if (value && !attributes[name].includes(value)) attributes[name].push(value);
  newValue[name] = '';
}
/** 笛卡尔积生成 SKU；已存在的 SKU 保留已编辑数据 */
function generate(): void {
  const names = Object.keys(attributes).filter((n) => attributes[n].length);
  if (!names.length) { toast.warning('请先添加属性值'); return; }
  const combos = names.reduce<string[][]>((acc, name) => acc.flatMap((prefix) => attributes[name].map((v) => [...prefix, v])), [[]]);
  const existing = new Map(skus.value.map((s) => [s.spec, s]));
  skus.value = combos.map((combo, i) => existing.get(combo.join(' / ')) || {
    code: `SKU-${String(i + 1).padStart(4, '0')}`, spec: combo.join(' / '),
    barcode: `690${String(Date.now()).slice(-9)}${i}`, cost: 0, price: 0, onHand: 0, locked: 0,
  });
  toast.success(`已生成 ${skus.value.length} 个 SKU`);
}
/** 保存 SKU 配置：逐条写入真实后端，ID 存在时自动更新 */
async function save(): Promise<void> {
  for (const row of skus.value) {
    await mockPost('/api/v1/inventory/skus', {
      ...(row.id ? { id: row.id } : {}),
      code: row.code,
      name: row.spec || row.code,
      spec: row.spec,
      barcode: row.barcode,
      cost: Number(row.cost || 0),
      price: Number(row.price || 0),
      onHand: Number(row.onHand || 0),
      locked: Number(row.locked || 0),
      qty: Number(row.onHand || 0),
      amount: Number(row.price || 0) * Number(row.onHand || 0),
      status: 1,
      remark: 'SKU 中心保存',
    });
  }
  const data: any = await mockGet('/api/v1/inventory/skus', { pageSize: 200 });
  const list = Array.isArray(data) ? data : data?.list || [];
  if (list.length) skus.value = list;
  toast.success('SKU 已保存到 MySQL');
}
onMounted(async () => {
  const data: any = await mockGet('/api/v1/inventory/skus', { pageSize: 200 });
  const list = Array.isArray(data) ? data : data?.list || [];
  if (list.length) skus.value = list; else generate();
});
</script>

<style scoped>
.sku-page { padding: 16px; }
.sku-attrs { padding: 14px; display: grid; gap: 12px; }
.sku-attr { display: flex; align-items: center; gap: 8px; flex-wrap: wrap; font-size: 13px; }
.sku-attr b { min-width: 40px; }
.sku-attr .ds-input { width: 160px; }
.sku-chip { padding: 3px 8px; border-radius: 4px; background: var(--ds-brand-soft); color: var(--ds-brand); cursor: pointer; }
.sku-gap { margin-top: 12px; }
.sku-table { width: 100%; border-collapse: collapse; font-size: 13px; }
.sku-table th, .sku-table td { padding: 8px 10px; border-bottom: 1px solid var(--ds-divider); text-align: left; }
.sku-table th { background: var(--ds-bg-soft); color: var(--ds-text-3); font-weight: 500; }
.sku-cell { width: 110px; }
.sku-foot { display: flex; align-items: center; gap: 16px; padding: 14px; font-size: 13px; color: var(--ds-text-3); }
.danger { color: var(--ds-danger); }
</style>
