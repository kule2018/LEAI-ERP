<template><BusinessImport :config="config" /></template>

<script setup lang="ts">
import BusinessImport from '../records/BusinessImport.vue';
import { productImport } from './productImport';

const config = productImport(true);
</script>
