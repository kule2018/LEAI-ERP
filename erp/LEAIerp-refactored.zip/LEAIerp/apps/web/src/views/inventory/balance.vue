<!-- 库存查询：Ds 自有设计系统（与通用页同款），余额/流水/预警三视图 -->
<template>
  <div class="entity-page">
    <div class="entity-stats">
      <div class="entity-stat"><span>库存品项</span><b>{{ total }}</b></div>
      <div class="entity-stat"><span>实物总量</span><b>{{ sumOnHand }}</b></div>
      <div class="entity-stat"><span>锁定总量</span><b>{{ sumOccupied }}</b></div>
      <div class="entity-stat"><span>预警品项</span><b>{{ alerts.length }}</b></div>
    </div>

    <DsCard :pad="false">
      <div class="balance-tabs">
        <button v-for="t in tabItems" :key="t.value" class="balance-tab" :class="{ on: tab === t.value }" @click="tab = t.value">{{ t.label }}</button>
      </div>
    </DsCard>

    <!-- 库存余额 -->
    <DsCard v-if="tab === 'balance'" :pad="false">
      <div class="entity-search">
        <select v-model="q.warehouseId" class="ds-select entity-search__select"><option value="">全部仓库</option><option v-for="w in warehouses" :key="w.id" :value="w.id">{{ w.name }}</option></select>
        <input v-model="q.keyword" class="ds-input entity-search__input" placeholder="搜索产品" @keyup.enter="loadBalance" />
        <DsButton variant="primary" size="sm" @click="loadBalance">查询</DsButton>
        <DsButton size="sm" @click="q.keyword = ''; q.warehouseId = ''; loadBalance()">重置</DsButton>
      </div>
      <div class="entity-table" v-loading="loading">
        <table class="ds-table">
          <thead><tr><th>产品</th><th>仓库</th><th style="width:100px">实物量</th><th style="width:100px">锁定量</th><th style="width:100px">可用量</th><th style="width:110px">加权成本</th></tr></thead>
          <tbody>
            <tr v-for="r in list" :key="r.id"><td>{{ r.productName }}</td><td>{{ r.warehouseName }}</td><td>{{ r.qtyOnHand }}</td><td>{{ r.qtyOccupied }}</td><td><b :class="{ 'text-danger': Number(r.qtyAvailable) < 0 }">{{ r.qtyAvailable }}</b></td><td>¥{{ Number(r.avgCost || 0).toFixed(2) }}</td></tr>
            <tr v-if="!list.length"><td colspan="6" class="entity-empty">暂无库存数据</td></tr>
          </tbody>
        </table>
      </div>
      <div class="entity-pager"><DsPagination v-model:current-page="page" :page-size="pageSize" :total="total" @current-change="loadBalance" /></div>
    </DsCard>

    <!-- 库存流水 -->
    <DsCard v-if="tab === 'ledger'" :pad="false">
      <div class="entity-search">
        <input v-model="lq.keyword" class="ds-input entity-search__input" placeholder="产品 / 单号" @keyup.enter="loadLedger" />
        <DsButton variant="primary" size="sm" @click="loadLedger">查询</DsButton>
      </div>
      <div class="entity-table">
        <table class="ds-table">
          <thead><tr><th style="width:160px">时间</th><th style="width:140px">单据类型</th><th>产品</th><th style="width:90px">入库</th><th style="width:90px">出库</th><th style="width:90px">结存</th><th style="width:90px">成本</th></tr></thead>
          <tbody>
            <tr v-for="r in ledger" :key="r.id"><td>{{ r.occurredAt }}</td><td>{{ voucherLabel(r.voucherType) }}</td><td>{{ r.productName }}</td><td>{{ r.qtyIn }}</td><td>{{ r.qtyOut }}</td><td>{{ r.balanceQty }}</td><td>¥{{ Number(r.cost || 0).toFixed(2) }}</td></tr>
            <tr v-if="!ledger.length"><td colspan="7" class="entity-empty">暂无流水</td></tr>
          </tbody>
        </table>
      </div>
    </DsCard>

    <!-- 库存预警 -->
    <DsCard v-if="tab === 'alerts'" :pad="false">
      <div class="entity-search">
        <DsButton variant="primary" size="sm" @click="loadAlerts">刷新预警</DsButton>
        <DsButton size="sm" @click="runForecast">生成补货建议</DsButton>
      </div>
      <div class="entity-table">
        <table class="ds-table">
          <thead><tr><th>产品</th><th>仓库</th><th style="width:100px">可用量</th><th style="width:110px">安全库存</th><th style="width:110px">状态</th></tr></thead>
          <tbody>
            <tr v-for="r in alerts" :key="r.id"><td>{{ r.productName }}</td><td>{{ r.warehouseName }}</td><td>{{ r.qtyAvailable }}</td><td>{{ r.safeQty }}</td><td><DsTag color="warning" size="sm">低于安全库存</DsTag></td></tr>
            <tr v-if="!alerts.length"><td colspan="5" class="entity-empty">暂无预警</td></tr>
          </tbody>
        </table>
        <pre v-if="forecast" class="forecast-text">{{ forecast }}</pre>
      </div>
    </DsCard>
  </div>
</template>

<script setup lang="ts">
import { reactive, ref, computed, onMounted } from 'vue';
import { DsButton, DsCard, DsPagination, DsTag } from '../../components';
import { inventoryApi, aiApi } from '../../api';
import { useToast } from '../../components/ds/toast';

const toast = useToast();
const tab = ref('balance');
const tabItems = [
  { label: '库存余额', value: 'balance' },
  { label: '库存流水', value: 'ledger' },
  { label: '库存预警', value: 'alerts' },
];
const loading = ref(false);
const list = ref<any[]>([]);
const ledger = ref<any[]>([]);
const alerts = ref<any[]>([]);
const total = ref(0);
const page = ref(1);
const pageSize = ref(10);
const forecast = ref('');
const q = reactive<{ keyword?: string; warehouseId?: any }>({});
const lq = reactive<{ keyword?: string }>({});
const warehouses = ref<any[]>([]);
const sumOnHand = computed(() => list.value.reduce((a, r) => a + Number(r.qtyOnHand || 0), 0).toFixed(0));
const sumOccupied = computed(() => list.value.reduce((a, r) => a + Number(r.qtyOccupied || 0), 0).toFixed(0));

const voucherMap: Record<string, string> = { SALE_OUT: '销售出库', SALE_RETURN: '销售退货', PURCHASE_IN: '采购入库', PURCHASE_RETURN: '采购退货', ADJUST: '库存调整', TRANSFER_IN: '调拨入库', TRANSFER_OUT: '调拨出库', FINISH_IN: '完工入库' };
function voucherLabel(v: string): string { return voucherMap[v] || v; }

async function loadBalance() {
  loading.value = true;
  try { const d: any = await inventoryApi.balance({ page: page.value, pageSize: pageSize.value, ...q }); list.value = d.list || d || []; total.value = d.total || 0; }
  catch { list.value = []; } finally { loading.value = false; }
}
async function loadLedger() { ledger.value = (await inventoryApi.ledger(lq).catch(() => [])) as any; }
async function loadAlerts() { alerts.value = (await inventoryApi.alerts().catch(() => [])) as any; }
async function runForecast() {
  await aiApi.forecastRun();
  const r: any = await aiApi.forecastResult();
  forecast.value = typeof r === 'string' ? r : JSON.stringify(r, null, 2);
  toast.success('预测完成，结果已写入 forecast_result');
}
onMounted(async () => { warehouses.value = (await inventoryApi.warehouses()) as any; loadBalance(); loadAlerts(); });
</script>

<style scoped>
.balance-tabs { display: flex; gap: 4px; padding: 8px 12px 0; border-bottom: 1px solid var(--ds-divider); }
.balance-tab { padding: 8px 16px; border: 0; background: transparent; color: var(--ds-text-2); font-size: var(--ds-font-sm); cursor: pointer; border-bottom: 2px solid transparent; }
.balance-tab:hover { color: var(--ds-brand); }
.balance-tab.on { color: var(--ds-brand); border-bottom-color: var(--ds-brand); font-weight: 600; }
.text-danger { color: var(--ds-danger); }
.forecast-text { margin: 12px; padding: 12px; background: var(--ds-bg-soft); border-radius: var(--ds-radius); font-size: 12px; white-space: pre-wrap; }
</style>
