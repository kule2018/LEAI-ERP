/** 库存仓储各页面独立配置：字段、表单、动作均按业务场景区分。 */
import type { SalesAction, SalesConfig, SalesField } from '../sales/salesConfigs';

const DOC = { '0': '草稿', '1': '待处理', '2': '已完成', '3': '已关闭', '4': '已驳回', '9': '已作废' };
const MASTER = { '0': '停用', '1': '启用' };
const docActions: SalesAction[] = [
  { key: 'submit', label: '提交', variant: 'primary', from: [0] },
  { key: 'approve', label: '审核通过', variant: 'primary', from: [1] },
  { key: 'execute', label: '执行完成', variant: 'primary', from: [2] },
  { key: 'void', label: '作废', variant: 'danger', from: [0, 1, 2, 3] },
];
const masterActions: SalesAction[] = [
  { key: 'toggle', label: '停用', variant: 'warning', from: [1] },
  { key: 'enable', label: '启用', variant: 'primary', from: [0] },
  { key: 'copy', label: '复制' },
];
const statusField = (doc: boolean): SalesField => ({
  prop: 'status', label: '状态', type: 'select',
  options: Object.entries(doc ? DOC : MASTER).map(([k, v]) => ({ label: v, value: Number(k) })),
});
const f = (prop: string, label: string, type?: SalesField['type'], required?: boolean): SalesField => ({ prop, label, type, required });

type Kind = 'master' | 'doc' | 'stock' | 'partner' | 'report';

interface Def { title: string; key: string; collection: string; kind: Kind; codeLabel: string; nameLabel: string; extra?: SalesField[]; apiKey?: string }

const DEFS: Def[] = [
  { key: 'ledger', title: '库存流水', collection: 'ivLedgers', apiKey: 'ledgers', kind: 'report', codeLabel: '流水单号', nameLabel: '流水说明', extra: [f('productName', '产品'), f('qty', '变动数量', 'number'), f('warehouse', '仓库'), f('docDate', '发生日期', 'date')] },
  { key: 'alerts', title: '库存预警', collection: 'ivAlerts', kind: 'report', codeLabel: '预警编号', nameLabel: '预警名称', extra: [f('productName', '产品'), f('qty', '当前库存', 'number'), f('warehouse', '仓库')] },
  { key: 'categories', title: '产品分类', collection: 'ivCategories', kind: 'master', codeLabel: '分类编码', nameLabel: '分类名称' },
  { key: 'brands', title: '品牌', collection: 'ivBrands', kind: 'master', codeLabel: '品牌编码', nameLabel: '品牌名称', extra: [f('partner', '所属厂商')] },
  { key: 'units', title: '计量单位', collection: 'ivUnits', kind: 'master', codeLabel: '单位编码', nameLabel: '单位名称' },
  { key: 'warehouses', title: '仓库', collection: 'ivWarehouses', kind: 'master', codeLabel: '仓库编码', nameLabel: '仓库名称', extra: [f('warehouse', '所在区域')] },
  { key: 'locations', title: '库位', collection: 'ivLocations', kind: 'master', codeLabel: '库位编码', nameLabel: '库位名称', extra: [f('warehouse', '所属仓库')] },
  { key: 'batches', title: '批次', collection: 'ivBatches', kind: 'master', codeLabel: '批次号', nameLabel: '批次名称', extra: [f('productName', '关联产品'), f('qty', '批次数量', 'number'), f('docDate', '生产日期', 'date')] },
  { key: 'serials', title: '序列号/IMEI', collection: 'ivSerials', kind: 'master', codeLabel: '序列号', nameLabel: '序列名称', extra: [f('productName', '关联产品'), f('warehouse', '所在仓库')] },
  { key: 'safe-stock', title: '安全库存', collection: 'ivSafeStock', kind: 'master', codeLabel: '规则编码', nameLabel: '规则名称', extra: [f('productName', '关联产品'), f('qty', '安全库存量', 'number'), f('warehouse', '仓库')] },
  { key: 'adjusts', title: '库存调整', collection: 'ivAdjusts', kind: 'doc', codeLabel: '调整单号', nameLabel: '调整原因', extra: [f('productName', '调整产品'), f('qty', '调整数量', 'number'), f('warehouse', '仓库'), f('docDate', '调整日期', 'date')] },
  { key: 'stocktakes', title: '库存盘点', collection: 'ivStocktakes', kind: 'doc', codeLabel: '盘点单号', nameLabel: '盘点任务', extra: [f('warehouse', '盘点仓库'), f('docDate', '盘点日期', 'date')] },
  { key: 'transfers', title: '调拨单', collection: 'ivTransfers', kind: 'doc', codeLabel: '调拨单号', nameLabel: '调拨说明', extra: [f('productName', '调拨物料'), f('qty', '调拨数量', 'number'), f('warehouse', '调出仓库'), f('partner', '调入仓库'), f('docDate', '调拨日期', 'date')] },
  { key: 'picks', title: '拣货清单', collection: 'ivPicks', kind: 'doc', codeLabel: '拣货单号', nameLabel: '拣货任务', extra: [f('productName', '拣货物料'), f('qty', '拣货数量', 'number'), f('warehouse', '仓库'), f('partner', '关联单据'), f('docDate', '拣货日期', 'date')] },
  { key: 'receipts', title: '收货入库', collection: 'ivReceipts', kind: 'doc', codeLabel: '收货单号', nameLabel: '收货说明', extra: [f('productName', '收货物料'), f('qty', '收货数量', 'number'), f('partner', '供应商'), f('warehouse', '入库仓库'), f('docDate', '收货日期', 'date')] },
  { key: 'outs', title: '销售出库', collection: 'ivOuts', kind: 'doc', codeLabel: '出库单号', nameLabel: '出库说明', extra: [f('productName', '出库产品'), f('qty', '出库数量', 'number'), f('partner', '客户/销售单'), f('warehouse', '出库仓库'), f('docDate', '出库日期', 'date')] },
  { key: 'picks-out', title: '领料出库', collection: 'ivPicksOut', kind: 'doc', codeLabel: '领料单号', nameLabel: '领料用途', extra: [f('productName', '领用物料'), f('qty', '领用数量', 'number'), f('partner', '领用部门'), f('docDate', '领料日期', 'date')] },
  { key: 'waves', title: '波次拣货', collection: 'ivWaves', kind: 'doc', codeLabel: '波次编号', nameLabel: '波次名称', extra: [f('partner', '包含单据'), f('qty', '总数量', 'number'), f('warehouse', '仓库'), f('docDate', '波次日期', 'date')] },
  { key: 'putaways', title: '上架策略', collection: 'ivPutaways', kind: 'doc', codeLabel: '上架单号', nameLabel: '上架任务', extra: [f('productName', '上架物料'), f('qty', '上架数量', 'number'), f('warehouse', '目标仓库')] },
  { key: 'crossdocks', title: '越库直发', collection: 'ivCrossdocks', kind: 'doc', codeLabel: '越库单号', nameLabel: '越库说明', extra: [f('productName', '直发物料'), f('qty', '直发数量', 'number'), f('partner', '客户'), f('warehouse', '中转仓')] },
  { key: 'disassembly', title: '拆装单', collection: 'ivDisassemblies', kind: 'doc', codeLabel: '拆装单号', nameLabel: '拆装说明', extra: [f('productName', '待拆成品'), f('qty', '拆装数量', 'number'), f('warehouse', '作业仓库'), f('partner', '拆出组件'), f('docDate', '拆装日期', 'date')] },
  { key: 'reports', title: '收发存报表', collection: 'ivReports', kind: 'report', codeLabel: '报表编号', nameLabel: '报表名称', extra: [f('productName', '产品'), f('qty', '结存数量', 'number'), f('amount', '结存金额', 'number'), f('warehouse', '仓库')] },
  { key: 'aging', title: '库龄分析', collection: 'ivAging', kind: 'report', codeLabel: '分析编号', nameLabel: '库龄区间', extra: [f('productName', '产品'), f('qty', '库存数量', 'number'), f('amount', '库存金额', 'number'), f('docDate', '入库日期', 'date')] },
  { key: 'turnover', title: '周转率', collection: 'ivTurnover', kind: 'report', codeLabel: '分析编号', nameLabel: '分析期间', extra: [f('productName', '产品'), f('qty', '销售数量', 'number'), f('amount', '销售金额', 'number')] },
  { key: 'slow', title: '呆滞料', collection: 'ivSlow', kind: 'report', codeLabel: '预警编号', nameLabel: '预警名称', extra: [f('productName', '呆滞物料'), f('qty', '呆滞数量', 'number'), f('amount', '占用金额', 'number'), f('docDate', '最后动销日', 'date')] },
  { key: 'trace', title: '序列号追溯', collection: 'ivTrace', kind: 'report', codeLabel: '追溯编号', nameLabel: '追溯主题', extra: [f('productName', '产品'), f('docDate', '业务日期', 'date')] },
];

function build(d: Def): SalesConfig {
  const isDoc = d.kind === 'doc';
  const isReport = d.kind === 'report';
  const base: SalesField[] = [f('code', d.codeLabel, undefined, true), f('name', d.nameLabel, undefined, true)];
  const extra = d.extra || [];
  const columns = [...base, ...extra, ...(isReport ? [] : [statusField(isDoc)])];
  const fields = [...base, ...extra, f('remark', '备注', 'textarea'), ...(isReport ? [] : [statusField(isDoc)])];
  return {
    title: d.title,
    api: `/api/v1/iv/${d.apiKey || d.key}`,
    collection: d.collection,
    columns,
    fields,
    statusField: 'status',
    statusLabels: isDoc ? DOC : MASTER,
    actions: isReport ? [] : (isDoc ? docActions : masterActions),
    readOnly: isReport,
    defaults: () => ({ status: isDoc ? 0 : 1, qty: 0, amount: 0 }),
  };
}

export const INVENTORY_CONFIGS: Record<string, SalesConfig> = Object.fromEntries(DEFS.map((d) => [d.key, build(d)]));
export function inventoryConfigFor(key: string): SalesConfig {
  const c = INVENTORY_CONFIGS[key];
  if (!c) throw new Error(`未知库存页面配置：${key}`);
  return c;
}
