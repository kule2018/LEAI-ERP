<!--
 * 产品列表（原型重点页）：图片/名称/编码/成本/价格/品牌/分类/合计库存/追踪标识 + 多规格展开
 * 对应文档 3.4 / 8 章；可用量 = 实物量 - 锁定量，合计库存按当前仓库筛选口径计算。
-->
<template>
  <div class="entity-page">
    <!-- 统计卡 -->
    <div class="entity-stats">
      <div class="entity-stat"><span>产品总数</span><b>{{ total }}</b></div>
      <div class="entity-stat"><span>多规格产品</span><b>{{ variantCount }}</b></div>
      <div class="entity-stat"><span>库存合计</span><b :class="{ 'qty-negative': stockTotal.lt(0) }">{{ stockTotal.toFixed(2) }}</b></div>
      <div class="entity-stat"><span>库存金额</span><b class="stat-total">¥{{ stockValue.toFixed(2) }}</b></div>
    </div>

    <!-- 查询区：类别 / 仓库 / 产品性质 / 搜索此表 -->
    <DsCard :pad="false">
      <div class="entity-search">
        <input v-model="q.keyword" class="ds-input entity-search__input" placeholder="搜索此表" @keyup.enter="reload" />
        <select v-model="q.categoryId" class="ds-select entity-search__select"><option value="">全部类别</option><option v-for="c in categories" :key="c.id" :value="c.id">{{ c.name }}</option></select>
        <select v-model="q.warehouseId" class="ds-select entity-search__select"><option value="">全部仓库</option><option v-for="w in warehouses" :key="w.id" :value="w.id">{{ w.name }}</option></select>
        <select v-model="q.type" class="ds-select entity-search__select"><option value="">全部产品性质</option><option v-for="n in natures" :key="n.value" :value="n.value">{{ n.label }}</option></select>
        <DsButton variant="primary" size="sm" @click="reload">查询</DsButton>
        <DsButton size="sm" @click="resetQuery">重置</DsButton>
        <span class="entity-search__spacer" />
        <DsButton v-perm="'inventory:product:edit'" size="sm" @click="labelVisible = true">图片识别建品</DsButton>
        <DsButton v-perm="'inventory:product:view'" size="sm" @click="router.push('/inventory/product-barcodes')">打印条码</DsButton>
        <DsButton v-perm="'inventory:product:edit'" variant="primary" size="sm" @click="router.push('/inventory/product-creates')">创建产品</DsButton>
      </div>
    </DsCard>

    <DsCard :pad="false" class="entity-gap">
      <div class="entity-table" v-loading="loading">
        <table class="ds-table">
          <thead><tr>
            <th style="width:36px"></th><th style="width:56px">图片</th><th>产品名称</th><th>产品编码</th>
            <th style="width:90px">成本</th><th style="width:90px">价格</th><th style="width:90px">品牌</th><th style="width:100px">产品分类</th>
            <th style="width:130px">合计库存</th><th style="width:110px">追踪标识</th><th style="width:330px">操作</th>
          </tr></thead>
          <tbody>
            <template v-for="s in list" :key="s.id">
              <tr>
                <td><button class="row-expand" :title="s.variants?.length ? '展开规格' : '非多规格产品'" @click="toggleExpand(s.id)">{{ expanded.includes(s.id) ? '−' : '+' }}</button></td>
                <td><DsImage v-if="s.image" :src="s.image" :width="32" :height="32" fit="cover" :preview="false" /><span v-else class="img-placeholder" title="暂无图片">图</span></td>
                <td>{{ s.name }}</td><td>{{ s.code }}</td>
                <td>¥{{ money(s.cost) }}</td><td>¥{{ money(s.price) }}</td>
                <td>{{ brandOf(s) }}</td><td>{{ categoryOf(s) }}</td>
                <td :class="{ 'qty-negative': Number(s.totalQty) < 0 }">{{ Number(s.totalQty || 0).toFixed(3) }} {{ unitOf(s) }}</td>
                <td><DsTag :color="trackColor(s)" size="sm" variant="outline">{{ trackText(s) }}</DsTag></td>
                <td>
                  <DsButton variant="text" size="sm" @click="onPick(s)">拣货</DsButton>
                  <DsButton variant="text" size="sm" @click="openView(s)">查看</DsButton>
                  <DsButton variant="text" size="sm" @click="openForm(s)">编辑</DsButton>
                  <DsButton v-perm="'inventory:product:edit'" variant="text" size="sm" @click="onCopy(s)">复制</DsButton>
                  <DsButton variant="text" size="sm" @click="openVariants(s)">多规格</DsButton>
                  <DsButton variant="text" size="sm" @click="onPrintOne(s)">条码</DsButton>
                  <DsButton variant="danger" size="sm" @click="onVoid(s)">删除</DsButton>
                </td>
              </tr>
              <tr v-if="expanded.includes(s.id)" class="expand-row">
                <td colspan="11">
                  <table v-if="s.variants?.length" class="ds-table variant-table">
                    <thead><tr><th>SKU 编码</th><th>规格</th><th>成本</th><th>价格</th><th>独立库存</th></tr></thead>
                    <tbody><tr v-for="v in s.variants" :key="v.id || v.skuCode">
                      <td>{{ v.skuCode ?? v.sku_code }}</td>
                      <td>{{ formatSpec(v.attributes) }}</td>
                      <td>¥{{ money(v.cost) }}</td><td>¥{{ money(v.price) }}</td>
                      <td>{{ Number(v.qty ?? v.totalQty ?? 0).toFixed(3) }}</td>
                    </tr></tbody>
                  </table>
                  <div v-else class="entity-empty-inline">非多规格产品，无独立 SKU 库存</div>
                </td>
              </tr>
            </template>
            <tr v-if="!list.length"><td colspan="11" class="entity-empty">暂无产品</td></tr>
          </tbody>
        </table>
      </div>
      <div class="entity-pager"><DsPagination v-model:current-page="page" :page-size="pageSize" :total="total" layout="total, sizes, prev, pager, next" @current-change="load" @change="load" /></div>
    </DsCard>

    <!-- 查看：产品全字段 -->
    <DsModal v-model="viewVisible" title="查看产品" :width="560">
      <div class="entity-form" v-if="viewing">
        <label class="entity-field"><span>产品名称</span><b>{{ viewing.name }}</b></label>
        <label class="entity-field"><span>产品编码</span><b>{{ viewing.code }}</b></label>
        <label class="entity-field"><span>品牌</span><b>{{ brandOf(viewing) }}</b></label>
        <label class="entity-field"><span>产品分类</span><b>{{ categoryOf(viewing) }}</b></label>
        <label class="entity-field"><span>成本</span><b>¥{{ money(viewing.cost) }}</b></label>
        <label class="entity-field"><span>售价</span><b>¥{{ money(viewing.price) }}</b></label>
        <label class="entity-field"><span>合计库存</span><b>{{ Number(viewing.totalQty || 0).toFixed(3) }} {{ unitOf(viewing) }}</b></label>
        <label class="entity-field"><span>追踪标识</span><b>{{ trackText(viewing) }}</b></label>
      </div>
      <template #footer><div class="entity-modal-foot"><DsButton variant="primary" @click="viewVisible = false">关闭</DsButton></div></template>
    </DsModal>

    <!-- 产品表单 -->
    <DsModal v-model="formVisible" :title="editing?.id ? '编辑产品' : '创建产品'" :width="600">
      <div class="entity-form">
        <label class="entity-field"><span>名称</span><input v-model="editing.name" class="ds-input" /></label>
        <label class="entity-field"><span>编码</span><input v-model="editing.code" class="ds-input" /></label>
        <label class="entity-field"><span>成本</span><input v-model="editing.cost" class="ds-input" type="number" /></label>
        <label class="entity-field"><span>售价</span><input v-model="editing.price" class="ds-input" type="number" /></label>
        <label class="entity-field"><span>分类</span><select v-model="editing.categoryId" class="ds-select"><option v-for="c in categories" :key="c.id" :value="c.id">{{ c.name }}</option></select></label>
        <label class="entity-field"><span>单位</span><select v-model="editing.unitId" class="ds-select"><option v-for="u in units" :key="u.id" :value="u.id">{{ u.name }}</option></select></label>
        <label class="entity-field"><span>类型</span><select v-model="editing.type" class="ds-select"><option :value="1">标准产品</option><option :value="2">多规格产品</option><option :value="3">序列号产品</option><option :value="4">服务型</option></select></label>
        <label class="entity-field"><span>批次追踪</span><DsSwitch v-model="editing.tracking" :active-value="1" :inactive-value="0" /></label>
      </div>
      <template #footer><div class="entity-modal-foot"><DsButton @click="formVisible = false">取消</DsButton><DsButton variant="primary" @click="onSave">保存</DsButton></div></template>
    </DsModal>

    <!-- 多规格 -->
    <DsModal v-model="variantVisible" title="多规格 SKU（属性集笛卡尔积）" :width="680">
      <div class="entity-hint">每行一个规格，属性如：颜色:红,尺码:S；成本/价格/库存独立维护</div>
      <table class="ds-table">
        <thead><tr><th>属性 JSON</th><th style="width:150px">SKU 编码</th><th style="width:100px">价格</th><th style="width:50px"></th></tr></thead>
        <tbody><tr v-for="(s, i) in variantRows" :key="i">
          <td><input v-model="s.attributes" class="ds-input" placeholder='{"颜色":"红"}' /></td>
          <td><input v-model="s.skuCode" class="ds-input" /></td>
          <td><input v-model="s.price" class="ds-input" type="number" /></td>
          <td><DsButton variant="text" size="sm" @click="variantRows.splice(i, 1)">删</DsButton></td>
        </tr></tbody>
      </table>
      <DsButton size="sm" class="entity-add-line" @click="addVariantRow">添加规格</DsButton>
      <template #footer><div class="entity-modal-foot"><DsButton @click="variantVisible = false">取消</DsButton><DsButton variant="primary" @click="onSaveVariants">保存规格</DsButton></div></template>
    </DsModal>

    <!-- AI 建品 -->
    <DsModal v-model="labelVisible" title="图片识别建品" :width="460">
      <textarea v-model="aiText" class="ds-input" rows="6" placeholder="粘贴商品图片 Base64，或粘贴商品描述文本" />
      <template #footer><div class="entity-modal-foot"><DsButton @click="labelVisible = false">取消</DsButton><DsButton variant="primary" @click="onAiLabel">识别</DsButton></div></template>
    </DsModal>
  </div>
</template>

<script setup lang="ts">
import { computed, reactive, ref, onMounted } from 'vue';
import { useRoute, useRouter } from 'vue-router';
import Decimal from 'decimal.js';
import {
  DsButton, DsCard, DsImage, DsModal, DsPagination, DsSwitch, DsTag,
} from '../../components';
import { inventoryApi, printApi, aiApi, sysApi } from '../../api';
import { MOCK_ENABLED } from '../../api/mockAdapter';
import { useBaseStore } from '../../store';
import { confirmVoid } from '../crud';
import { useToast } from '../../components/ds/toast';

type TagColor = 'brand' | 'success' | 'warning' | 'danger' | 'neutral';
const route = useRoute();
const router = useRouter();
const base = useBaseStore();
const toast = useToast();
const loading = ref(false);
const list = ref<any[]>([]);
const total = ref(0);
const page = ref(1);
const pageSize = ref(10);
const categories = ref<any[]>([]);
const warehouses = ref<any[]>([]);
const units = ref<any[]>([]);
const natures = ref<Array<{ label: string; value: number }>>([]);
const expanded = ref<number[]>([]);
const mockMode = MOCK_ENABLED;
const q = reactive<{ keyword?: string; categoryId?: any; warehouseId?: any; type?: any }>({ keyword: '', categoryId: '', warehouseId: '', type: '' });

const formVisible = ref(false);
const editing = ref<any>(null);
const viewVisible = ref(false);
const viewing = ref<any>(null);
const variantVisible = ref(false);
const variantProduct = ref<any>(null);
const variantRows = ref<any[]>([]);
const labelVisible = ref(false);
const aiText = ref('');

/** 金额格式化（decimal.js，避免浮点误差） */
function money(v: any): string { return new Decimal(v || 0).toFixed(2); }
/** 统计卡：多规格数量 / 可用量合计 / 库存金额 */
const variantCount = computed(() => list.value.filter((r) => Number(r.type) === 2).length);
const stockTotal = computed(() => list.value.reduce((s, r) => s.plus(new Decimal(r.totalQty || 0)), new Decimal(0)));
const stockValue = computed(() => list.value.reduce((s, r) => s.plus(new Decimal(r.cost || 0).mul(r.totalQty || 0)), new Decimal(0)));
/** 名称兜底：后端 snake_case / Mock camelCase / 本地字典三种来源 */
function nameOf(row: any, camel: string, snake: string, dict: any[]): string {
  if (row?.[camel] || row?.[snake]) return row[camel] || row[snake];
  const id = row?.[`${camel}Id`] ?? row?.[`${snake}_id`];
  if (id === undefined || id === null || id === '') return '—';
  return dict.find((d) => Number(d.id) === Number(id))?.name || '—';
}
function brandOf(row: any) { return nameOf(row, 'brandName', 'brand_name', []); }
function categoryOf(row: any) { return nameOf(row, 'categoryName', 'category_name', categories.value); }
function unitOf(row: any) {
  const direct = nameOf(row, 'unitName', 'unit_name', units.value);
  if (direct !== '—') return direct;
  const u = units.value.find((x) => Number(x.id) === Number(row?.unitId));
  return u?.name || '';
}
/** 追踪标识：多规格 / 序列号 / 批次追踪 / 标准 / 服务，按文档原型命名 */
function trackText(row: any): string {
  const t = Number(row?.type || 1);
  if (t === 2) return '多规格产品';
  if (t === 3) return '序列号产品';
  if (t === 4) return '服务型产品';
  return Number(row?.tracking || 0) === 1 ? '追踪产品' : '标准产品';
}
function trackColor(row: any): TagColor {
  const t = Number(row?.type || 1);
  if (t === 2) return 'brand';
  if (t === 3) return 'warning';
  if (Number(row?.tracking || 0) === 1) return 'success';
  return 'neutral';
}
/** 规格格式化：兼容对象 {颜色:'黑'} 与字符串 "颜色:黑,尺码:S" */
function formatSpec(attr: any): string {
  if (!attr) return '—';
  if (typeof attr === 'string') return attr;
  if (typeof attr === 'object') return Object.entries(attr).map(([k, v]) => `${k}:${v}`).join(' / ');
  return String(attr);
}
function toggleExpand(id: number): void {
  expanded.value = expanded.value.includes(id) ? expanded.value.filter((x) => x !== id) : [...expanded.value, id];
}
function addVariantRow(): void { variantRows.value.push({ attributes: '{"颜色":"","尺码":""}', skuCode: '', price: '0' }); }
function resetQuery(): void { Object.assign(q, { keyword: '', categoryId: '', warehouseId: '', type: '' }); reload(); }
function reload(): void { page.value = 1; load(); }

async function load() {
  loading.value = true;
  try {
    const [d, bal]: any[] = await Promise.all([
      inventoryApi.products({ page: page.value, pageSize: pageSize.value, ...q }),
      inventoryApi.balance({ pageSize: 500, warehouseId: q.warehouseId || undefined }).catch(() => []),
    ]);
    const balances = Array.isArray(bal) ? bal : (bal?.list || []);
    const stockOf = new Map<number, number>();
    for (const b of balances) {
      const pid = Number(b.productId ?? b.product_id);
      const available = b.qtyAvailable ?? b.qty_available ?? b.available ?? Number(b.qty_on_hand ?? b.qtyOnHand ?? 0) - Number(b.qty_occupied ?? b.qtyOccupied ?? 0);
      stockOf.set(pid, (stockOf.get(pid) || 0) + Number(available || 0));
    }
    list.value = (d.list || d || []).map((p: any) => ({
      ...p,
      totalQty: p.totalQty ?? p.total_qty ?? stockOf.get(Number(p.id)) ?? p.totalQty ?? 0,
    }));
    total.value = d.total || list.value.length;
  } catch { list.value = []; } finally { loading.value = false; }
}
function openForm(row?: any) {
  editing.value = row ? { ...row } : { name: '', code: '', cost: '0', price: '0', categoryId: null, unitId: null, type: 1, tracking: 0 };
  formVisible.value = true;
}
function openView(row: any) { viewing.value = { ...row }; viewVisible.value = true; }
async function onSave() {
  await inventoryApi.saveProduct(editing.value);
  toast.success('已保存'); formVisible.value = false; load();
}
/** 复制产品：编码加后缀保证唯一，明细字段按保存接口白名单透传 */
async function onCopy(row: any) {
  const payload: any = {
    name: `${row.name}（副本）`, code: `${row.code}-C${Date.now().toString().slice(-5)}`,
    barcode: row.barcode, categoryId: row.categoryId, brandId: row.brandId, unitId: row.unitId,
    cost: row.cost, price: row.price, type: row.type, tracking: row.tracking,
    isActive: row.isActive ?? 1, image: row.image, remark: row.remark,
  };
  try { await inventoryApi.saveProduct(payload); toast.success('已复制为新产品'); load(); } catch { /* 已提示 */ }
}
function onPick(row: any) { router.push({ path: '/inventory/picks', query: { productId: String(row.id), keyword: row.name } }); }
function openVariants(row: any) {
  variantProduct.value = row;
  variantRows.value = (row.variants || []).map((v: any) => ({ attributes: typeof v.attributes === 'string' ? v.attributes : JSON.stringify(v.attributes || {}), skuCode: v.skuCode ?? v.sku_code, price: String(v.price ?? 0) }));
  if (!variantRows.value.length) variantRows.value.push({ attributes: '{"颜色":"","尺码":""}', skuCode: '', price: '0' });
  variantVisible.value = true;
}
async function onSaveVariants() {
  await inventoryApi.saveVariants(variantProduct.value.id, { variants: variantRows.value.map((r) => ({ ...r, price: Number(r.price) })) });
  toast.success('规格已保存'); variantVisible.value = false; load();
}
function onVoid(row: any) { confirmVoid(() => inventoryApi.voidProduct(row.id), load); }
async function onPrintOne(row: any) {
  await printApi.labels({ lines: [{ productId: row.id, qty: 1 }], type: 'PRODUCT' });
  toast.success('标签任务已生成，可在打印记录查看/补打');
}
async function onAiLabel() {
  try {
    const res: any = aiApi.labelRec ? await aiApi.labelRec(aiText.value) : await aiApi.ocr(aiText.value);
    const f = res.fields || res;
    editing.value = { name: f.name || '', code: f.code || '', cost: '0', price: '0', categoryId: f.categoryId || null, unitId: null, type: f.type || 1, tracking: 0 };
    labelVisible.value = false; formVisible.value = true;
    toast[res.fallback ? 'info' : 'success'](res.fallback ? '规则引擎结果，请核对' : 'AI 识别完成，请核对');
  } catch { /* 已提示 */ }
}

onMounted(async () => {
  await base.ensure(); warehouses.value = base.warehouses;
  const [c, u, n]: any[] = await Promise.all([
    inventoryApi.categories(), sysApi.dict('unit'), sysApi.dict('product_nature'),
  ]);
  categories.value = c as any; units.value = u as any;
  natures.value = (Array.isArray(n) ? n : []).map((d: any) => ({ label: d.name, value: Number(d.code) }));
  if (route.query.keyword) q.keyword = String(route.query.keyword);
  if (route.query.categoryId) q.categoryId = String(route.query.categoryId);
  load();
});
</script>

<style scoped>
.row-expand { width: 22px; height: 22px; border: 1px solid var(--ds-border); border-radius: 4px; background: var(--ds-bg-soft); cursor: pointer; color: var(--ds-text); }
.expand-row > td { background: var(--ds-bg-soft); padding: 8px 14px; }
.variant-table { background: var(--ds-bg-elevated); }
.entity-add-line { margin-top: 10px; }
.img-placeholder { display: inline-flex; width: 32px; height: 32px; align-items: center; justify-content: center; border-radius: 4px; background: var(--ds-bg-hover); color: var(--ds-text-3); font-size: 12px; }
.stat-total { color: var(--ds-brand, #4d6bfe); }
.qty-negative { color: var(--ds-danger, #dc2626); font-weight: 600; }
.entity-field b { font-size: var(--ds-font-md); }
</style>
