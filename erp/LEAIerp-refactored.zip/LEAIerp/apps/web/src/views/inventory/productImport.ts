import { pageData, pageRows, type BusinessRow } from '../../api/pageData';
import type { ImportConfig, ImportValues } from '../records/importRows';

const resource = '/api/v1/inventory/products';
const fields = { code: '产品编码', name: '产品名称', barcode: '条形码', cost: '成本', price: '售价', remark: '备注' };

export async function findProduct(code: string): Promise<BusinessRow | undefined> {
  const pageSize = 100;
  for (let page = 1; ; page++) {
    const response = await pageData<BusinessRow[] | { total: number; list: BusinessRow[] }>('GET', resource, { keyword: code, page, pageSize });
    const rows = pageRows(response);
    const match = rows.find((row) => String(row.code).toLowerCase() === code.toLowerCase());
    if (match || Array.isArray(response) || !rows.length || page * pageSize >= response.total) return match;
  }
}

export function productImport(update: boolean): ImportConfig {
  function validate(values: ImportValues) {
    if (values.code?.length > 64 || values.name?.length > 128 || values.barcode?.length > 64) return '编码、名称或条码超出长度限制';
    const invalid = ['price', 'cost'].find((key) => values[key] && !/^\d{1,14}(?:\.\d{1,2})?$/.test(values[key]));
    return invalid ? `${fields[invalid]}须为非负金额且最多两位小数` : undefined;
  }
  return {
    title: update ? '导入更新产品' : '导入产品',
    fields,
    required: update ? ['code'] : ['code', 'name'],
    example: update ? { code: 'P0001', price: '26.00' } : { code: 'NEW-001', name: '新产品示例', cost: '12.00', price: '20.00' },
    listPath: '/inventory/products',
    listLabel: '返回产品列表',
    validate,
    async prepare(rows) {
      const counts = new Map<string, number>();
      for (const { values } of rows) {
        const code = values.code?.toLowerCase();
        if (code) counts.set(code, (counts.get(code) || 0) + 1);
      }
      for (const row of rows) {
        if (row.error) continue;
        if (counts.get(row.values.code.toLowerCase())! > 1) { row.error = '同一批次内产品编码重复'; continue; }
        const existing = await findProduct(row.values.code);
        if (update && !existing) row.error = '产品编码不存在';
        if (!update && existing) row.error = '产品编码已存在';
        if (update && !Object.keys(fields).some((field) => field !== 'code' && row.values[field])) row.error = '请至少填写一个待更新字段';
      }
    },
    async save(values) {
      const existing = await findProduct(values.code);
      const supplied = Object.fromEntries(Object.entries(values).filter(([, value]) => value !== ''));
      if (!update) {
        if (existing) throw new Error('产品编码已存在');
        return pageData('POST', resource, { ...supplied, cost: values.cost || '0', price: values.price || '0', type: 1 });
      }
      if (!existing) throw new Error('产品编码不存在');
      const current = {
        name: existing.name, code: existing.code, cost: existing.cost, price: existing.price, type: existing.type,
        categoryId: existing.categoryId ?? existing.category_id, brandId: existing.brandId ?? existing.brand_id,
        unitId: existing.unitId ?? existing.unit_id, isActive: existing.isActive ?? existing.is_active,
        tracking: existing.tracking, image: existing.image, barcode: existing.barcode, remark: existing.remark,
      };
      return pageData('POST', `${resource}/${existing.id}`, { ...current, ...supplied, code: existing.code });
    },
  };
}
