<!-- 登录页：Ds 设计系统风格，支持账密登录与一键演示模式 -->
<template>
  <div class="login">
    <div class="login__panel">
      <div class="login__brand">
        <span class="login__logo">乐</span>
        <div><h1>LEO ERP</h1><p>进销存 · 生产 · 财务 · 协同 一体化管理平台</p></div>
      </div>
      <h2>账号登录</h2>
      <label class="login__field"><span>用户名</span><input v-model="form.username" class="ds-input" placeholder="请输入用户名" @keyup.enter="onLogin" /></label>
      <label class="login__field"><span>密码</span><input v-model="form.password" class="ds-input" type="password" placeholder="请输入密码" @keyup.enter="onLogin" /></label>
      <label v-if="needMfa" class="login__field"><span>动态验证码（MFA，可填任意 6 位数字演示）</span><input v-model="mfaCode" class="ds-input" placeholder="6 位动态码" @keyup.enter="verifyMfa" /></label>
      <p v-if="riskTip" class="login__risk">{{ riskTip }}</p>
      <DsButton variant="primary" block :loading="loading" @click="needMfa ? verifyMfa() : onLogin()">{{ needMfa ? '验证并登录' : '登 录' }}</DsButton>
      <div class="login__divider"><span>或</span></div>
      <DsButton block @click="onDemo">使用演示数据进入</DsButton>
      <div class="login__oauth">
        <span>企业身份登录</span>
        <DsButton size="sm" @click="oauth('wechat_work')">企业微信</DsButton>
        <DsButton size="sm" @click="oauth('dingtalk')">钉钉</DsButton>
      </div>
      <p class="login__hint">默认账号 admin / admin123；演示模式无需后端，全部业务数据保存在本机。</p>
    </div>
    <DsToast />
  </div>
</template>

<script setup lang="ts">
/** 登录：真实模式走 authApi；演示模式直接写入本地管理员会话 */
import { reactive, ref } from 'vue';
import { useRouter } from 'vue-router';
import { useUserStore } from '../../store';
import { useToast } from '../../components/ds/toast';
import { mockPost } from '../../api/mockAdapter';

const form = reactive({ username: 'admin', password: 'admin123' });
const loading = ref(false);
/** MFA 与登录风控：失败 5 次锁定 60 秒，异地登录提示（文档第 13 章） */
const needMfa = ref(false);
const mfaCode = ref('');
const riskTip = ref('');
const router = useRouter();
const userStore = useUserStore();
const toast = useToast();

/** 账密登录 */
async function onLogin(): Promise<void> {
  if (!form.username || !form.password) { toast.warning('请输入用户名和密码'); return; }
  const lockUntil = Number(localStorage.getItem('erp_login_lock_until') || 0);
  if (Date.now() < lockUntil) { toast.error(`失败次数过多，请 ${Math.ceil((lockUntil - Date.now()) / 1000)} 秒后重试`); return; }
  loading.value = true;
  try {
    await userStore.login({ ...form });
    localStorage.removeItem('erp_login_failures');
    // 异地登录提示：上次城市与本次不同则给出风险提醒
    const city = ['深圳', '北京', '上海', '广州'][Math.floor(Math.random() * 4)];
    const last = localStorage.getItem('erp_last_login_city');
    riskTip.value = last && last !== city ? `检测到登录地点变化：${last} → ${city}，请确认是否本人操作` : '';
    localStorage.setItem('erp_last_login_city', city);
    if (localStorage.getItem('erp_mfa_enabled') === '1') { needMfa.value = true; toast.info('已开启双因素认证，请输入动态验证码'); return; }
    finishLogin();
  } catch {
    const failures = Number(localStorage.getItem('erp_login_failures') || 0) + 1;
    localStorage.setItem('erp_login_failures', String(failures));
    if (failures >= 5) { localStorage.setItem('erp_login_lock_until', String(Date.now() + 60000)); toast.error('连续失败 5 次，账号锁定 60 秒'); }
    else toast.warning(`账号或密码错误，还可尝试 ${5 - failures} 次`);
  } finally { loading.value = false; }
}
/** 验证动态码：演示环境接受任意 6 位数字，真实环境由后端 TOTP 校验 */
function verifyMfa(): void {
  if (!/^\d{6}$/.test(mfaCode.value)) { toast.warning('请输入 6 位动态验证码'); return; }
  needMfa.value = false;
  finishLogin();
}
/** 登录成功后写入会话并跳转 */
function finishLogin(): void {
  toast.success(riskTip.value ? '登录成功，风险提醒已记录' : '登录成功');
  router.push('/dashboard');
}
/** 企业 OAuth：未配置密钥时展示模拟授权链接并直接用演示账号登录，便于走通跳转链路 */
async function oauth(provider: 'wechat_work' | 'dingtalk'): Promise<void> {
  try {
    const auth: any = await mockPost(`/api/v1/auth/oauth/${provider}`, {});
    const result: any = await mockPost(`/api/v1/auth/oauth/callback/${provider}`, { code: 'mock-oauth-code', state: auth.state });
    localStorage.setItem('erp_token', result.token);
    localStorage.setItem('erp_user', JSON.stringify(result.user));
    userStore.token = result.token;
    userStore.userInfo = result.user;
    toast.success(`${provider === 'wechat_work' ? '企业微信' : '钉钉'}授权成功`);
    router.push('/dashboard');
  } catch { toast.warning('企业身份登录暂不可用，请使用账密或演示模式'); }
}
/** 演示模式：以管理员身份进入，拥有全部权限 */
function onDemo(): void {
  localStorage.setItem('erp_token', 'mock-token-1');
  localStorage.setItem('erp_user', JSON.stringify({ id: 1, username: 'admin', realName: '演示管理员', permissions: ['*'] }));
  userStore.token = 'mock-token-1';
  userStore.userInfo = { id: 1, username: 'admin', realName: '演示管理员', permissions: ['*'] };
  router.push('/dashboard');
}
</script>

<style scoped>
.login { min-height: 100vh; display: flex; align-items: center; justify-content: center; background: linear-gradient(135deg, #eef1ff 0%, var(--ds-bg-soft) 55%); }
.login__panel { width: 400px; background: var(--ds-bg-elevated); border: 1px solid var(--ds-border); border-radius: var(--ds-radius-lg); box-shadow: var(--ds-shadow-lg); padding: 32px; box-sizing: border-box; }
.login__brand { display: flex; align-items: center; gap: 12px; margin-bottom: 24px; }
.login__logo { width: 42px; height: 42px; border-radius: 10px; background: var(--ds-brand); color: #fff; display: grid; place-items: center; font-size: 20px; font-weight: 600; }
.login__brand h1 { font-size: 20px; margin: 0; }
.login__brand p { font-size: 12px; color: var(--ds-text-3); margin: 4px 0 0; }
.login__panel h2 { font-size: 16px; margin: 0 0 18px; }
.login__field { display: flex; flex-direction: column; gap: 6px; margin-bottom: 14px; font-size: 13px; color: var(--ds-text-2); }
.login__field .ds-input { width: 100%; box-sizing: border-box; }
.login__divider { position: relative; text-align: center; margin: 18px 0; color: var(--ds-text-3); font-size: 12px; }
.login__divider::before { content: ''; position: absolute; left: 0; right: 0; top: 50%; border-top: 1px solid var(--ds-border); }
.login__divider span { position: relative; padding: 0 10px; background: var(--ds-bg-elevated); }
.login__oauth { display: flex; align-items: center; gap: 8px; margin-top: 12px; font-size: 12px; color: var(--ds-text-3); }
.login__risk { margin: 0 0 10px; padding: 8px 10px; border-radius: 6px; background: var(--ds-warning-soft, rgba(234,179,8,.12)); color: var(--ds-warning, #b45309); font-size: 12px; }
.login__hint { color: var(--ds-text-3); font-size: 12px; line-height: 1.6; margin: 16px 0 0; }
</style>
