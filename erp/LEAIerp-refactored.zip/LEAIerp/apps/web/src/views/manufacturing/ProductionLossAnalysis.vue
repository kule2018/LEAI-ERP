<template><RecordPage :config="page" /></template>

<script setup lang="ts">
import RecordPage from '../records/RecordPage.vue';
import type { RecordPageConfig } from '../records/records';

const page: RecordPageConfig = {
  title: '损耗分析',
  resource: 'manufacturing/loss-analysis',
  schema: 'manufacturingLossAnalysis',
  filters: ['orderNo', 'materialName'],
  reportSource: '按工单和物料检查标准用量与实际消耗',
  metrics: ['inputQty', 'stdQty', 'actualQty'],
};
</script>
