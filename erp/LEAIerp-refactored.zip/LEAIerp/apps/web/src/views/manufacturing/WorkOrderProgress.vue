<template><RecordPage :config="page" /></template>

<script setup lang="ts">
import RecordPage from '../records/RecordPage.vue';
import type { RecordPageConfig } from '../records/records';

const page: RecordPageConfig = {
  title: '工单进度',
  resource: 'manufacturing/work-order-progress',
  schema: 'manufacturingWorkOrderProgress',
  filters: ['orderNo', 'productName', 'status'],
  reportSource: '查询计划数量、已生产数量和工单状态',
  metrics: ['planQty', 'producedQty'],
  link: { to: '/manufacturing/workorders', label: '查看生产工单' },
};
</script>
