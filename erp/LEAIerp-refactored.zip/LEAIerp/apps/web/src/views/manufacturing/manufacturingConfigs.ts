/** 生产制造各页面独立配置：MRP/BOM/工艺/计划/领料/质检/成本各有自己的字段与动作。 */
import type { SalesAction, SalesConfig, SalesField } from '../sales/salesConfigs';

const DOC = { '0': '草稿', '1': '待处理', '2': '进行中', '3': '已完成', '4': '已驳回', '9': '已作废' };
const MASTER = { '0': '停用', '1': '启用' };
const docActions: SalesAction[] = [
  { key: 'submit', label: '提交', variant: 'primary', from: [0] },
  { key: 'approve', label: '审核通过', variant: 'primary', from: [1] },
  { key: 'execute', label: '执行完成', variant: 'primary', from: [2] },
  { key: 'void', label: '作废', variant: 'danger', from: [0, 1, 2, 3] },
];
const masterActions: SalesAction[] = [
  { key: 'toggle', label: '停用', variant: 'warning', from: [1] },
  { key: 'enable', label: '启用', variant: 'primary', from: [0] },
  { key: 'copy', label: '复制' },
];
const f = (prop: string, label: string, type?: SalesField['type'], required?: boolean): SalesField => ({ prop, label, type, required });
const statusField = (doc: boolean): SalesField => ({
  prop: 'status', label: '状态', type: 'select',
  options: Object.entries(doc ? DOC : MASTER).map(([k, v]) => ({ label: v, value: Number(k) })),
});

type Kind = 'master' | 'doc' | 'report';
interface Def { key: string; title: string; collection: string; kind: Kind; codeLabel: string; nameLabel: string; extra?: SalesField[]; actions?: SalesAction[]; apiKey?: string }

const DEFS: Def[] = [
  { key: 'mrp', title: 'MRP 运算', collection: 'mfMrpRuns', apiKey: 'mrp-runs', kind: 'doc', codeLabel: '运算编号', nameLabel: '运算名称', extra: [f('productName', '需求产品'), f('qty', '需求数量', 'number'), f('docDate', '运算日期', 'date')], actions: [{ key: 'submit', label: '开始运算', variant: 'primary', from: [0] }, { key: 'approve', label: '生成建议', variant: 'primary', from: [1] }, { key: 'execute', label: '转为采购/生产单', variant: 'primary', from: [2] }, { key: 'void', label: '作废', variant: 'danger', from: [0, 1, 2] }] },
  { key: 'bom', title: '物料清单 BOM', collection: 'mfBom', kind: 'master', codeLabel: 'BOM 编号', nameLabel: 'BOM 名称', extra: [f('productName', '成品'), f('qty', '用量', 'number')] },
  { key: 'bom-versions', title: 'BOM 版本', collection: 'mfBomVersions', kind: 'doc', codeLabel: '版本编号', nameLabel: '版本名称', extra: [f('productName', '成品'), f('docDate', '生效日期', 'date')] },
  { key: 'routings', title: '工艺路线', collection: 'mfRoutings', kind: 'master', codeLabel: '路线编号', nameLabel: '路线名称', extra: [f('productName', '适用产品'), f('partner', '工序/车间'), f('qty', '标准工时', 'number')] },
  { key: 'work-centers', title: '工作中心/产线', collection: 'mfWorkCenters', kind: 'master', codeLabel: '中心编号', nameLabel: '中心名称', extra: [f('warehouse', '所属仓库'), f('qty', '日产能', 'number'), f('partner', '负责人')] },
  { key: 'demands', title: '需求汇总', collection: 'mfDemands', kind: 'doc', codeLabel: '需求编号', nameLabel: '需求名称', extra: [f('productName', '需求产品'), f('qty', '需求数量', 'number'), f('docDate', '需求日期', 'date')] },
  { key: 'issues', title: '领料单', collection: 'mfIssues', kind: 'doc', codeLabel: '领料单号', nameLabel: '领料用途', extra: [f('productName', '物料'), f('qty', '领料数量', 'number'), f('partner', '领用产线'), f('docDate', '领料日期', 'date')] },
  { key: 'material-returns', title: '退料单', collection: 'mfMaterialReturns', kind: 'doc', codeLabel: '退料单号', nameLabel: '退料原因', extra: [f('productName', '物料'), f('qty', '退料数量', 'number'), f('partner', '退料产线'), f('docDate', '退料日期', 'date')] },
  { key: 'finish-ins', title: '完工入库', collection: 'mfFinishIns', kind: 'doc', codeLabel: '入库单号', nameLabel: '入库说明', extra: [f('productName', '完工产品'), f('qty', '完工数量', 'number'), f('warehouse', '入库仓库'), f('docDate', '完工日期', 'date')] },
  { key: 'reports', title: '工时报工', collection: 'mfReports', kind: 'doc', codeLabel: '报工单号', nameLabel: '报工说明', extra: [f('productName', '产品'), f('qty', '工时', 'number'), f('partner', '报工人'), f('docDate', '报工日期', 'date')] },
  { key: 'qc', title: '质检单', collection: 'mfQc', kind: 'doc', codeLabel: '质检单号', nameLabel: '质检名称', extra: [f('productName', '送检产品'), f('qty', '送检数量', 'number'), f('docDate', '送检日期', 'date')], actions: [{ key: 'submit', label: '送检', variant: 'primary', from: [0] }, { key: 'approve', label: '质检合格', variant: 'primary', from: [1] }, { key: 'reject', label: '质检不合格', variant: 'danger', from: [1] }, { key: 'execute', label: '入库/流转', variant: 'primary', from: [2] }, { key: 'void', label: '作废', variant: 'danger', from: [0, 1, 2] }] },
  { key: 'equipments', title: '设备管理', collection: 'mfEquipments', kind: 'master', codeLabel: '设备编号', nameLabel: '设备名称', extra: [f('warehouse', '使用仓库'), f('partner', '管理部门'), f('amount', '购置金额', 'number')] },
  { key: 'capacity', title: '产能分析', collection: 'mfCapacity', kind: 'report', codeLabel: '分析编号', nameLabel: '分析名称', extra: [f('partner', '工作中心'), f('qty', '可用产能', 'number'), f('amount', '计划产出', 'number')] },
  { key: 'costs', title: '成本归集', collection: 'mfCosts', kind: 'report', codeLabel: '归集编号', nameLabel: '归集名称', extra: [f('productName', '产品'), f('qty', '完工数量', 'number'), f('amount', '归集成本', 'number'), f('docDate', '归集日期', 'date')] },
];

function build(d: Def): SalesConfig {
  const isDoc = d.kind === 'doc';
  const isReport = d.kind === 'report';
  const base = [f('code', d.codeLabel, undefined, true), f('name', d.nameLabel, undefined, true)];
  const extra = d.extra || [];
  return {
    title: d.title,
    api: `/api/v1/mf/${d.apiKey || d.key}`,
    collection: d.collection,
    columns: [...base, ...extra, ...(isReport ? [] : [statusField(isDoc)])],
    fields: [...base, ...extra, f('remark', '备注', 'textarea'), ...(isReport ? [] : [statusField(isDoc)])],
    statusField: 'status',
    statusLabels: isDoc ? DOC : MASTER,
    actions: isReport ? [] : (d.actions || (isDoc ? docActions : masterActions)),
    readOnly: isReport,
    defaults: () => ({ status: isDoc ? 0 : 1, qty: 0, amount: 0 }),
  };
}

export const MANUFACTURING_CONFIGS: Record<string, SalesConfig> = Object.fromEntries(DEFS.map((d) => [d.key, build(d)]));
export function manufacturingConfigFor(key: string): SalesConfig {
  const c = MANUFACTURING_CONFIGS[key];
  if (!c) throw new Error(`未知生产页面配置：${key}`);
  return c;
}
