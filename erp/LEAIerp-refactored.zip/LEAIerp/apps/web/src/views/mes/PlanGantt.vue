<!-- 生产计划与排产甘特：按日期展示计划条，支持状态流转与产能冲突提示（真实 APS 数据） -->
<template>
  <div class="gantt-page">
    <div class="gantt-head">
      <div><h2>生产计划与排产</h2><p>按工作中心查看未来 14 天排产，重叠任务会提示产能冲突</p></div>
      <div class="gantt-actions">
        <DsButton size="sm" @click="load">刷新</DsButton>
        <DsButton variant="primary" size="sm" @click="addPlan">新增计划</DsButton>
      </div>
    </div>
    <div class="gantt-stats">
      <div v-for="c in stats" :key="c.label" class="gantt-stat"><span>{{ c.label }}</span><b>{{ c.value }}</b></div>
    </div>
    <DsCard :pad="false">
      <div class="gantt-scroll">
        <table class="gantt-table">
          <thead>
            <tr><th class="gantt-name">计划 / 工作中心</th><th v-for="day in days" :key="day.date" class="gantt-day"><small>{{ day.label }}</small><b>{{ day.day }}</b></th></tr>
          </thead>
          <tbody>
            <tr v-for="plan in plans" :key="plan.id">
              <td class="gantt-name">
                <b>{{ plan.planName || plan.name }}</b><small>{{ plan.workCenter }} · {{ plan.qty }} 件 · {{ statusText(plan) }}</small>
                <DsButton size="sm" variant="text" @click="advance(plan)">{{ statusText(plan) }} →</DsButton>
              </td>
              <td v-for="day in days" :key="day.date" class="gantt-cell" :class="{ weekend: day.weekend, conflict: isConflict(plan, day) }">
                <div v-if="inRange(plan, day.date)" class="gantt-bar" :class="statusClass(plan)" :title="plan.planName || plan.name">{{ plan.planName || plan.name }}</div>
              </td>
            </tr>
            <tr v-if="!plans.length"><td :colspan="days.length + 1" class="gantt-empty">暂无生产计划，点击「新增计划」开始</td></tr>
          </tbody>
        </table>
      </div>
    </DsCard>
  </div>
</template>

<script setup lang="ts">
/** 排产甘特：日期轴渲染、状态推进与同日产能冲突提示，数据全部来自真实 APS 接口 */
import { computed, onMounted, ref } from 'vue';
import { DsButton, DsCard } from '../../components';
import { apsApi } from '../../api';
import { useToast } from '../../components/ds/toast';
import { prompt as uiPrompt } from '../../components/ds/usePrompt';

const toast = useToast();
const plans = ref<any[]>([]);
/** 未来 14 天日期轴 */
const days = computed(() => Array.from({ length: 14 }, (_, i) => {
  const date = new Date(); date.setDate(date.getDate() + i);
  const iso = date.toISOString().slice(0, 10);
  return { date: iso, label: ['周日', '周一', '周二', '周三', '周四', '周五', '周六'][date.getDay()], day: date.getDate(), weekend: [0, 6].includes(date.getDay()) };
}));

/** 真实 APS 状态：DRAFT/CONFIRMED/SCHEDULED/ISSUED/COMPLETED/CANCELLED */
const STATUS_TEXT: Record<string, string> = { DRAFT: '待排产', CONFIRMED: '已确认', SCHEDULED: '已排产', ISSUED: '已下达', COMPLETED: '已完成', CANCELLED: '已作废' };
const STATUS_CLASS: Record<string, string> = { DRAFT: 'planned', CONFIRMED: 'planned', SCHEDULED: 'scheduled', ISSUED: 'issued', COMPLETED: 'done', CANCELLED: 'planned' };
function statusText(plan: any): string { return STATUS_TEXT[plan.status] || plan.status || '待排产'; }
function statusClass(plan: any): string { return STATUS_CLASS[plan.status] || 'planned'; }
function dayOf(v: any): string { return v ? String(v).slice(0, 10) : ''; }
function inRange(plan: any, date: string): boolean {
  const start = dayOf(plan.planStart || plan.start), end = dayOf(plan.planEnd || plan.end);
  return !!start && !!end && date >= start && date <= end;
}
/** 同日计划数超过 2 视为产能冲突 */
function isConflict(plan: any, day: any): boolean {
  return inRange(plan, day.date) && plans.value.filter((p) => p.workCenter === plan.workCenter && inRange(p, day.date)).length > 2;
}
const stats = computed(() => [
  { label: '计划总数', value: plans.value.length },
  { label: '已排产', value: plans.value.filter((p) => ['SCHEDULED', 'ISSUED'].includes(p.status)).length },
  { label: '已完成', value: plans.value.filter((p) => p.status === 'COMPLETED').length },
  { label: '产能冲突日', value: conflictDays() },
]);
function conflictDays(): number {
  let n = 0;
  for (const day of days.value) for (const center of new Set(plans.value.map((p) => p.workCenter))) {
    if (plans.value.filter((p) => p.workCenter === center && inRange(p, day.date)).length > 2) n++;
  }
  return n;
}

async function load(): Promise<void> {
  try {
    const data: any = await apsApi.plans({ pageSize: 200 });
    plans.value = Array.isArray(data) ? data : data?.list || [];
  } catch { plans.value = []; toast.error('生产计划加载失败'); }
}

/** 状态推进：按真实状态机 confirm → schedule → issue → complete */
async function advance(plan: any): Promise<void> {
  const actionMap: Record<string, string> = { DRAFT: 'confirm', SCHEDULED: 'issue', ISSUED: 'complete' };
  if (plan.status === 'CONFIRMED') {
    toast.info('已确认计划请到「排产工作台」执行排产运算');
    return;
  }
  if (['COMPLETED', 'CANCELLED'].includes(plan.status)) { toast.info('该计划已结束，无后续状态'); return; }
  const action = actionMap[plan.status] || 'confirm';
  try {
    await apsApi.planAction(plan.id, action as any);
    toast.success(`${plan.planName || plan.name} 已推进`);
    await load();
  } catch (e: any) { toast.error(e?.message || '状态推进失败'); }
}

async function addPlan(): Promise<void> {
  const name = await uiPrompt('请输入计划名称', '新增生产计划', '新增生产计划');
  if (!name) return;
  const start = days.value[1].date;
  const end = days.value[4].date;
  try {
    await apsApi.savePlan({
      planNo: `PP${Date.now().toString().slice(-8)}`, planName: name, qty: 100,
      workCenter: '一号产线', priority: 'P3', dueDate: end, planStart: start, planEnd: end, status: 'DRAFT',
    });
    toast.success('计划已创建');
    await load();
  } catch (e: any) { toast.error(e?.message || '计划创建失败'); }
}

onMounted(load);
</script>

<style scoped>
.gantt-page { padding: 16px; }
.gantt-head { display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px; }
.gantt-head h2 { margin: 0 0 4px; font-size: 18px; }
.gantt-head p { margin: 0; font-size: 12px; color: var(--ds-text-3); }
.gantt-actions { display: flex; gap: 8px; }
.gantt-stats { display: flex; gap: 12px; margin-bottom: 12px; }
.gantt-stat { flex: 1; background: var(--ds-bg-soft); border-radius: 8px; padding: 10px 14px; display: flex; flex-direction: column; gap: 4px; }
.gantt-stat span { font-size: 12px; color: var(--ds-text-3); }
.gantt-stat b { font-size: 20px; }
.gantt-scroll { overflow-x: auto; padding: 12px; }
.gantt-table { border-collapse: collapse; font-size: 12px; min-width: 1100px; width: 100%; }
.gantt-table th, .gantt-table td { border: 1px solid var(--ds-divider); padding: 4px; height: 48px; }
.gantt-day { min-width: 64px; text-align: center; background: var(--ds-bg-soft); }
.gantt-day small { display: block; color: var(--ds-text-3); }
.gantt-name { min-width: 200px; text-align: left; }
.gantt-name b { display: block; }
.gantt-name small { color: var(--ds-text-3); }
.gantt-cell { position: relative; }
.gantt-cell.weekend { background: var(--ds-bg-soft); }
.gantt-cell.conflict { background: var(--ds-danger-soft); }
.gantt-bar { height: 24px; line-height: 24px; border-radius: 4px; padding: 0 6px; color: #fff; white-space: nowrap; overflow: hidden; font-size: 11px; }
.gantt-bar.planned { background: var(--ds-text-3); }
.gantt-bar.scheduled { background: var(--ds-brand); }
.gantt-bar.issued { background: var(--ds-warning); }
.gantt-bar.done { background: var(--ds-success); }
.gantt-empty { text-align: center; color: var(--ds-text-3); padding: 24px; }
</style>
