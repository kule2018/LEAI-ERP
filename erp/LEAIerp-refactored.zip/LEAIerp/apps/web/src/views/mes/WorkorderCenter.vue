<!-- 生产工单执行中心：下达→领料→报工→完工入库→关闭 完整状态机 -->
<template>
  <div class="erp-page">
    <div class="wo-cards">
      <div v-for="c in cards" :key="c.label" class="wo-card"><span>{{ c.label }}</span><b>{{ c.value }}</b></div>
    </div>
    <DsCard title="工单执行" :pad="false">
      <template #extra><DsButton variant="primary" size="sm" @click="openNew">新建工单</DsButton></template>
      <table class="wo-table">
        <thead><tr><th>工单号</th><th>产品</th><th>计划数量</th><th>已完工</th><th>状态</th><th>进度</th><th>操作</th></tr></thead>
        <tbody>
          <tr v-for="row in rows" :key="row.id">
            <td>{{ row.orderNo || row.code || row.id }}</td><td>{{ row.productName || row.name }}</td>
            <td>{{ row.qty || row.planQty || 0 }}</td><td>{{ row.finishedQty || 0 }}</td>
            <td><DsTag :color="statusColor(row)" size="sm">{{ statusText(row) }}</DsTag></td>
            <td><DsProgress :percentage="progress(row)" /></td>
            <td class="wo-ops">
              <DsButton v-if="stage(row) === 0" size="sm" variant="primary" @click="action(row, 'issue')">下达领料</DsButton>
              <DsButton v-if="stage(row) === 1" size="sm" variant="primary" @click="action(row, 'report')">报工</DsButton>
              <DsButton v-if="stage(row) === 2" size="sm" variant="primary" @click="action(row, 'finish')">完工入库</DsButton>
              <DsButton v-if="stage(row) === 3" size="sm" @click="action(row, 'close')">关闭</DsButton>
              <DsButton v-if="stage(row) === 4" size="sm" @click="action(row, 'reopen')">重启</DsButton>
            </td>
          </tr>
          <tr v-if="!rows.length"><td colspan="7" class="wo-empty">暂无工单</td></tr>
        </tbody>
      </table>
    </DsCard>

    <!-- 报工弹窗 -->
    <DsModal v-model="reportVisible" title="工时报工" :width="420">
      <div class="wo-form">
        <label><span>本次完成数量</span><input v-model.number="report.qty" class="ds-input" type="number" /></label>
        <label><span>工序</span><input v-model="report.process" class="ds-input" placeholder="如 组装 / 质检" /></label>
        <label><span>操作工</span><input v-model="report.worker" class="ds-input" /></label>
      </div>
      <template #footer><div class="wo-foot"><DsButton @click="reportVisible = false">取消</DsButton><DsButton variant="primary" @click="submitReport">提交报工</DsButton></div></template>
    </DsModal>
  </div>
</template>

<script setup lang="ts">
/** 生产工单中心：驱动工单全生命周期，动作写入本地 Mock 并发布库存/数据事件 */
import { computed, onMounted, reactive, ref } from 'vue';
import { DsButton, DsCard, DsModal, DsProgress, DsTag } from '../../components';
import { mockGet, mockPost } from '../../api/mockAdapter';
import { emit, Events } from '../../utils/eventBus';
import { useToast } from '../../components/ds/toast';
import { prompt as uiPrompt } from '../../components/ds/usePrompt';

const toast = useToast();
const rows = ref<any[]>([]);
const reportVisible = ref(false);
const current = ref<any>(null);
const report = reactive<any>({ qty: 1, process: '组装', worker: '' });

const cards = computed(() => [
  { label: '全部工单', value: rows.value.length },
  { label: '进行中', value: rows.value.filter((r) => stage(r) > 0 && stage(r) < 4).length },
  { label: '已完工', value: rows.value.filter((r) => stage(r) === 3).length },
  { label: '已完成', value: rows.value.filter((r) => stage(r) === 4).length },
]);

/** 状态归一化：兼容中文/英文状态值 */
function stage(row: any): number {
  const s = String(row.status || '');
  if (['CLOSED', '完成', '已关闭', '4'].includes(s)) return 4;
  if (['FINISHED', '完工', '待入库', '3'].includes(s)) return 3;
  if (['REPORTED', '已报工', '2'].includes(s)) return 2;
  if (['ISSUED', '已下达', '已领料', '生产中', '在制', '1'].includes(s)) return 1;
  return 0;
}
function statusText(row: any): string { return ['待下达', '已领料', '已报工', '待入库', '已关闭'][stage(row)]; }
function statusColor(row: any): any { return stage(row) === 4 ? 'neutral' : stage(row) === 0 ? 'warning' : 'brand'; }
function progress(row: any): number { return Math.min(100, stage(row) * 25 + (row.finishedQty ? 10 : 0)); }

/** 加载工单，演示数据为空时给出 3 条可操作样例 */
async function load(): Promise<void> {
  const data: any = await mockGet('/api/v1/mes/workorders', { pageSize: 100 });
  rows.value = Array.isArray(data) ? data : data?.list || [];
  if (!rows.value.length) {
    rows.value = [
      { id: 1, orderNo: 'MO20260001', productName: '智能温控器', qty: 200, finishedQty: 0, status: 'DRAFT' },
      { id: 2, orderNo: 'MO20260002', productName: '无线网关', qty: 100, finishedQty: 60, status: 'REPORTED' },
      { id: 3, orderNo: 'MO20260003', productName: '工控主板', qty: 50, finishedQty: 50, status: 'FINISHED' },
    ];
  }
}
/** 执行状态流转动作 */
async function action(row: any, act: string): Promise<void> {
  if (act === 'report') { current.value = row; report.qty = 1; reportVisible.value = true; return; }
  const statusMap: Record<string, string> = { issue: 'ISSUED', finish: 'FINISHED', close: 'CLOSED', reopen: 'DRAFT' };
  const res: any = await mockPost('/api/v1/mes/workorders/' + row.id + '/' + act, {});
  row.status = res?.status || statusMap[act];
  if (act === 'finish') { row.finishedQty = row.producedQty || row.finishedQty || row.qty || row.planQty; emit(Events.STOCK_CHANGED, { bizType: 'WORKORDER', bizId: row.id }); }
  emit(Events.DATA_RELOADED, { api: 'mes/workorders', id: row.id, action: act });
  toast.success(`${statusText(row)} 已完成`);
}
/** 提交报工 */
async function submitReport(): Promise<void> {
  if (!current.value || !report.qty) { toast.warning('请填写完成数量'); return; }
  await mockPost('/api/v1/mes/reports', { workorderId: current.value.id, ...report });
  current.value.finishedQty = Number(current.value.finishedQty || 0) + Number(report.qty);
  current.value.status = 'REPORTED';
  // 回写工单本体，避免刷新后报工进度与状态丢失
  await mockPost('/api/v1/mes/workorders', { ...current.value, finishedQty: current.value.finishedQty, status: 'REPORTED' });
  reportVisible.value = false;
  emit(Events.DATA_RELOADED, { api: 'mes/reports', id: current.value.id });
  toast.success('报工已提交');
}
/** 新建工单 */
async function openNew(): Promise<void> {
  const name = await uiPrompt('请输入产品名称', '', '新建工单');
  if (!name) return;
  const qty = Number(await uiPrompt('请输入计划数量', '100', '新建工单') || 100);
  const orderNo = `MO${Date.now().toString().slice(-8)}`;
  const saved: any = await mockPost('/api/v1/mes/workorders', { orderNo, productName: name, name, qty, finishedQty: 0, status: 'DRAFT' });
  rows.value.unshift({ id: saved?.id || Date.now(), orderNo, productName: name, qty, finishedQty: 0, status: 'DRAFT' });
  toast.success('工单已创建');
}
onMounted(load);
</script>

<style scoped>
.wo-cards { display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px; margin-bottom: 12px; }
.wo-card { background: var(--ds-bg-elevated); border: 1px solid var(--ds-border); border-radius: var(--ds-radius); padding: 12px 16px; display: flex; flex-direction: column; gap: 4px; }
.wo-card span { font-size: 12px; color: var(--ds-text-3); }
.wo-card b { font-size: 20px; }
.wo-table { width: 100%; border-collapse: collapse; font-size: 13px; }
.wo-table th, .wo-table td { padding: 9px 12px; border-bottom: 1px solid var(--ds-divider); text-align: left; }
.wo-table th { background: var(--ds-bg-soft); color: var(--ds-text-3); font-weight: 500; }
.wo-ops { display: flex; gap: 4px; }
.wo-empty { text-align: center; padding: 24px; color: var(--ds-text-3); }
.wo-form { display: grid; gap: 12px; }
.wo-form label { display: flex; flex-direction: column; gap: 4px; font-size: 13px; color: var(--ds-text-2); }
.wo-foot { display: flex; justify-content: flex-end; gap: 8px; }
</style>
