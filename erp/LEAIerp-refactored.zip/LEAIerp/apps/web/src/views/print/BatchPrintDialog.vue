<!--
 * 批量打印弹窗（文档第 11/24 章：批量打印 + 批量结果报告）。
 * ---------------------------------------------------------------------------
 * 入参 rows 为选中行，选择模板/份数/渠道后逐条调用 printApi.createJob，
 * 逐条展示成功与失败原因，失败或全部结果可下载 CSV 供修正后重试。
-->
<template>
  <DsModal v-model="visible" title="批量打印" :width="760">
    <div class="bp-form">
      <label>
        <span>打印模板</span>
        <select v-model="templateId" class="ds-select">
          <option v-for="t in templates" :key="t.id" :value="t.id">{{ t.name }}（{{ t.paper }}）</option>
        </select>
      </label>
      <label><span>份数</span><input v-model.number="copies" class="ds-input" type="number" min="1" /></label>
      <label>
        <span>打印渠道</span>
        <select v-model="channel" class="ds-select">
          <option value="CLIENT_SILENT">静默打印</option>
          <option value="PREVIEW">预览</option>
          <option value="SERVER_PDF">PDF</option>
        </select>
      </label>
    </div>

    <div class="bp-tip">共 {{ rows.length }} 条记录，将按所选模板逐条创建打印任务；渠道：{{ channelText }}</div>

    <div v-if="results.length" class="bp-summary">
      <span class="ok">成功 {{ successCount }}</span>
      <span class="bad">失败 {{ failedCount }}</span>
      <span>合计 {{ results.length }}</span>
    </div>

    <div class="bp-table-wrap">
      <table class="bp-table">
        <thead><tr><th style="width:56px">序号</th><th>单据号</th><th style="width:90px">状态</th><th>说明 / 失败原因</th></tr></thead>
        <tbody>
          <tr v-for="(r, i) in results" :key="i">
            <td>{{ i + 1 }}</td>
            <td>{{ r.bizNo }}</td>
            <td><span class="bp-status" :class="r.ok ? 'ok' : 'bad'">{{ r.ok ? '成功' : '失败' }}</span></td>
            <td>{{ r.reason }}</td>
          </tr>
          <tr v-if="!results.length"><td colspan="4" class="bp-empty">尚未执行，点击右下角「开始批量打印」</td></tr>
        </tbody>
      </table>
    </div>

    <template #footer>
      <div class="bp-foot">
        <DsButton size="sm" :disabled="!results.length" @click="downloadCsv(false)">下载结果 CSV</DsButton>
        <DsButton size="sm" :disabled="!failedCount" @click="downloadCsv(true)">仅下载失败明细</DsButton>
        <span class="bp-gap" />
        <DsButton size="sm" @click="visible = false">关闭</DsButton>
        <DsButton variant="primary" size="sm" :loading="running" :disabled="!templateId || !rows.length" @click="start">开始批量打印</DsButton>
      </div>
    </template>
  </DsModal>
</template>

<script setup lang="ts">
/** 批量打印：模板/份数/渠道选择 + 逐条执行 + 结果报告与 CSV 导出 */
import { computed, ref, watch, onMounted } from 'vue'
import { printApi } from '../../api'
import { useToast } from '../../components/ds/toast'

interface PrintRowResult { bizNo: string; ok: boolean; reason: string; job?: any }

const props = defineProps<{ modelValue: boolean; bizType?: string; rows: any[] }>()
const emit = defineEmits<{ (e: 'update:modelValue', value: boolean): void }>()

const toast = useToast()
const visible = ref(props.modelValue)
watch(() => props.modelValue, (v) => { visible.value = v })
watch(visible, (v) => { emit('update:modelValue', v); if (v) void loadTemplates() })

const templates = ref<any[]>([])
const templateId = ref<number | null>(null)
const copies = ref(1)
const channel = ref('CLIENT_SILENT')
const running = ref(false)
const results = ref<PrintRowResult[]>([])

const successCount = computed(() => results.value.filter((r) => r.ok).length)
const failedCount = computed(() => results.value.filter((r) => !r.ok).length)
const channelText = computed(() => ({ CLIENT_SILENT: '静默打印', PREVIEW: '预览', SERVER_PDF: 'PDF' }[channel.value] || channel.value))

/** 加载模板并优先选中与当前业务类型一致者 */
async function loadTemplates(): Promise<void> {
  try {
    const d: any = await printApi.listTemplates({ pageSize: 200 })
    templates.value = d?.list || d || []
    if (!templateId.value && templates.value.length) {
      templateId.value = templates.value.find((t: any) => t.bizType === props.bizType)?.id ?? templates.value[0].id
    }
  } catch { templates.value = [] }
}

/** 逐条创建打印任务；单条失败不影响后续行 */
async function start(): Promise<void> {
  if (!templateId.value) { toast.warning('请选择打印模板'); return }
  running.value = true
  results.value = []
  for (const row of props.rows || []) {
    const bizNo = String(row.orderNo || row.bizNo || row.no || row.code || (row.id ?? '') || '')
    try {
      const job: any = await printApi.createJob({
        bizType: props.bizType || row.bizType || '',
        bizId: row.id,
        bizNo,
        templateId: templateId.value,
        copies: Math.max(1, Number(copies.value) || 1),
        channel: channel.value,
      })
      results.value.push({ bizNo, ok: true, reason: job?.message || '打印任务已创建', job })
    } catch (e: any) {
      results.value.push({ bizNo, ok: false, reason: e?.message || '打印任务创建失败' })
    }
  }
  running.value = false
  toast.success(`批量打印完成：成功 ${successCount.value} 条，失败 ${failedCount.value} 条`)
}

/** CSV 单元格转义：统一加引号并双写内部引号 */
function cell(v: any): string { return `"${String(v ?? '').replace(/"/g, '""')}"` }

/** 导出全部结果或仅失败明细（带 BOM，Excel 可直接打开） */
function downloadCsv(onlyFailed: boolean): void {
  const rows = onlyFailed ? results.value.filter((r) => !r.ok) : results.value
  if (!rows.length) return
  const lines = ['序号,单据号,状态,说明', ...rows.map((r, i) => [i + 1, r.bizNo, r.ok ? '成功' : '失败', r.reason].map(cell).join(','))]
  const blob = new Blob(['\ufeff' + lines.join('\n')], { type: 'text/csv;charset=utf-8' })
  const link = document.createElement('a')
  link.href = URL.createObjectURL(blob)
  link.download = `${onlyFailed ? '批量打印失败明细' : '批量打印结果'}_${new Date().toISOString().slice(0, 10)}.csv`
  link.click()
  URL.revokeObjectURL(link.href)
}

onMounted(() => { void loadTemplates() })
</script>

<style scoped>
.bp-form { display: grid; grid-template-columns: 1.6fr 0.6fr 0.9fr; gap: 12px; }
.bp-form label { display: flex; flex-direction: column; gap: 4px; font-size: 13px; }
.bp-form .ds-input, .bp-form .ds-select { width: 100%; }
.bp-tip { font-size: 12px; color: var(--ds-text-3); margin: 12px 0; }
.bp-summary { display: flex; gap: 18px; font-size: 13px; margin-bottom: 8px; }
.bp-summary .ok { color: var(--ds-success); }
.bp-summary .bad { color: var(--ds-danger); }
.bp-table-wrap { max-height: 360px; overflow: auto; border: 1px solid var(--ds-border); border-radius: var(--ds-radius); }
.bp-table { width: 100%; border-collapse: collapse; font-size: 13px; }
.bp-table th, .bp-table td { padding: 8px 10px; border-bottom: 1px solid var(--ds-divider); text-align: left; }
.bp-table th { background: var(--ds-bg-soft); position: sticky; top: 0; }
.bp-status { display: inline-block; padding: 2px 8px; border-radius: 10px; font-size: 12px; }
.bp-status.ok { color: var(--ds-success); background: rgba(34, 197, 94, .12); }
.bp-status.bad { color: var(--ds-danger); background: rgba(239, 68, 68, .12); }
.bp-empty { text-align: center; color: var(--ds-text-3); padding: 24px; }
.bp-foot { display: flex; align-items: center; gap: 8px; }
.bp-gap { flex: 1; }
</style>
