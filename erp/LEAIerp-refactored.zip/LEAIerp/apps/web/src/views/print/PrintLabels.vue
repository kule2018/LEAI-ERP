
<template><div class="lb-page">
<div class="lb-head"><div><div class="lb-kicker">LABEL SHEET · 标签打印</div><h2>条码标签</h2></div><div class="lb-actions"><DsButton size="sm" @click="load">刷新</DsButton><DsButton size="sm" @click="exportCsv">导出</DsButton><DsButton variant="primary" size="sm" @click="openForm()">＋ 新建标签</DsButton></div></div>
<div class="lb-stats"><div v-for="s in statVals" :key="s.label" class="lb-stat"><span>{{s.label}}</span><b>{{s.value}}</b></div></div>
<div class="lb-search"><input v-model="q.keyword" class="ds-input" placeholder="搜索标签名称 / 编码…" @keyup.enter="reload"/><select v-model="q.status" class="ds-input"><option value="">全部状态</option><option v-for="(l,v) in statusLabels" :key="v" :value="v">{{l}}</option></select><DsButton variant="primary" size="sm" @click="reload">查询</DsButton><DsButton size="sm" @click="resetQuery">重置</DsButton></div>
<div class="lb-setup"><div class="lb-setup-title"><IconFont name="Setting" :size="14"/> 打印设置</div><label class="lb-setup-f">纸张规格 <select v-model="paper" class="ds-input"><option>A4</option><option>热敏 50×30</option><option>热敏 80×50</option></select></label><label class="lb-setup-f">每页列数 <select v-model.number="cols" class="ds-input"><option :value="2">2 列</option><option :value="3">3 列</option><option :value="4">4 列</option></select></label><div class="lb-setup-info"><IconFont name="Inbox" :size="13"/> 共 {{rows.length}} 张标签 · 打印总量 {{sumQty}} 张</div></div>
<div class="lb-sheet" :style="{gridTemplateColumns:'repeat('+cols+',minmax(0,1fr))'}">
<div v-for="r in rows" :key="r.id" class="lb-label" :class="{off:Number(r.status)===0}">
<div class="lb-label-top"><b>{{r.name||'未命名标签'}}</b><span class="lb-dot" :style="{background:Number(r.status)===1?'#10b981':'#94a3b8'}"></span></div>
<div class="lb-barcode"><span v-for="(b,i) in bars(r)" :key="i" :class="{on:b.on}" :style="{width:b.w+'px'}"></span></div>
<div class="lb-code">{{r.code}}</div>
<div class="lb-info"><div><span>关联产品</span><b>{{r.productName||'—'}}</b></div><div><span>条码规则</span><b>{{r.bizText||'—'}}</b></div><div><span>打印数量</span><b>×{{r.qty||0}}</b></div></div>
<div class="lb-label-foot"><span class="lb-state" :style="{color:Number(r.status)===1?'#10b981':'#94a3b8'}">{{statusText(r.status)}}</span><div class="lb-ops"><button title="编辑" @click="openForm(r)"><IconFont name="Edit" :size="13"/></button><button v-for="a in actionsOf(r)" :key="a.key" :title="a.label" @click="runAction(r,a)"><IconFont :name="a.key==='copy'?'File':a.key==='toggle'?'Warning':'Check'" :size="13"/></button><button title="删除" class="del" @click="removeRow(r)"><IconFont name="Close" :size="13"/></button></div></div>
</div>
<div v-if="!rows.length" class="lb-empty"><IconFont name="Inbox" :size="28"/><p>暂无标签</p></div>
</div>
<div class="lb-pager"><DsPagination v-model:current-page="page" :page-size="pageSize" :total="total" layout="total, prev, pager, next" @change="load"/></div>
<DsModal v-model="formVisible" :title="(editing?'编辑':'新建')+'条码标签'" :width="640"><div class="lb-form"><label v-for="f in formFields" :key="f.prop" class="lb-field"><span>{{f.label}}<i v-if="f.required">*</i></span><select v-if="f.type==='select'" v-model="form[f.prop]" class="ds-input"><option :value="''">请选择</option><option v-for="o in optionsOf(f)" :key="String(o.value)" :value="o.value">{{o.label}}</option></select><textarea v-else-if="f.type==='textarea'" v-model="form[f.prop]" class="ds-input" rows="3"></textarea><input v-else :type="f.type==='number'?'number':f.type==='date'?'date':'text'" v-model="form[f.prop]" class="ds-input"/></label></div><template #footer><div class="lb-foot"><DsButton @click="formVisible=false">取消</DsButton><DsButton variant="primary" :loading="saving" @click="save">保存</DsButton></div></template></DsModal>
</div></template>

<script setup lang="ts">
import IconFont from '../../components/IconFont.vue';
import { ref, reactive, computed, onMounted } from 'vue';
import { mockGet, mockPost, mockPatch, mockDel } from '../../api/mockAdapter';
import { useToast } from '../../components/ds/toast';
import { confirm as uiConfirm } from '../../components/ds/useConfirm';
const toast=useToast();
const API="/api/v1/xprint/labels";
const COLLECTION="printLabels";
const columns:any[]=[{"prop":"code","label":"标签编码","type":"text","options":null,"source":""},{"prop":"name","label":"标签名称","type":"text","options":null,"source":""},{"prop":"productName","label":"关联产品","type":"text","options":null,"source":""},{"prop":"bizText","label":"条码规则","type":"text","options":null,"source":""},{"prop":"qty","label":"打印数量","type":"number","options":null,"source":""},{"prop":"status","label":"状态","type":"select","options":[{"label":"停用","value":0},{"label":"启用","value":1}],"source":""}];
const formFields:any[]=[{"prop":"code","label":"标签编码","type":"text","options":null,"source":"","required":true,"placeholder":""},{"prop":"name","label":"标签名称","type":"text","options":null,"source":"","required":true,"placeholder":""},{"prop":"productName","label":"关联产品","type":"text","options":null,"source":"","required":false,"placeholder":""},{"prop":"bizText","label":"条码规则","type":"text","options":null,"source":"","required":false,"placeholder":""},{"prop":"qty","label":"打印数量","type":"number","options":null,"source":"","required":false,"placeholder":""},{"prop":"remark","label":"备注","type":"textarea","options":null,"source":"","required":false,"placeholder":""},{"prop":"status","label":"状态","type":"select","options":[{"label":"停用","value":0},{"label":"启用","value":1}],"source":"","required":false,"placeholder":""}];
const statusLabels:Record<string,string>={"0":"停用","1":"启用"};
const actions:any[]=[{"key":"toggle","label":"停用","variant":"warning","from":[1]},{"key":"enable","label":"启用","variant":"primary","from":[0]},{"key":"copy","label":"复制","variant":"default","from":null}];
const DEFAULTS:any={"status":1,"qty":0,"amount":0,"bizAmount":0};
const STATS:any[]=[{"label":"记录总数","expr":"rows.length","unit":""},{"label":"打印数量合计","expr":"sum('qty')","unit":""},{"label":"待处理","expr":"rows.filter(r=>Number(r.status)<=1).length","unit":""}];
const hasStatus=Object.keys(statusLabels).length>0;
const isReport=false;
const q=reactive<{keyword:string;status:any}>({keyword:'',status:''});
const rows=ref<any[]>([]);const total=ref(0);const page=ref(1);const pageSize=ref(12);
const loading=ref(false);const saving=ref(false);const formVisible=ref(false);const editing=ref<any>(null);
const form=reactive<Record<string,any>>({});
const remoteOptions=reactive<Record<string,any[]>>({});
const paper=ref('A4');const cols=ref(3);
const sumQty=computed(()=>rows.value.reduce((a,r)=>a+(Number(r.qty)||0),0));
function bars(r:any):{w:number;on:boolean}[]{const code=String(r.code||r.name||'LEAI');const out:{w:number;on:boolean}[]=[];for(let i=0;i<code.length&&out.length<48;i++){const c=code.charCodeAt(i);out.push({w:1+(c%3),on:true});out.push({w:1+((c>>3)%2),on:false});}return out;}
const statVals=computed(()=>STATS.map(s=>({label:s.label,unit:s.unit,value:evalStat(s.expr)})));
function sum(prop:string){return rows.value.reduce((a,r)=>a+(Number(r[prop])||0),0);}
function evalStat(expr:string){try{return new Function('rows','page','sum','rows_',expr)(rows.value,page.value,sum,rows.value);}catch{return 0;}}
function statusText(v:any){return statusLabels[String(v)]||String(v??'');}
function display(row:any,col:any){const v=row[col.prop];if(col.prop==='status'&&hasStatus)return statusText(v);if(col.options){const h=col.options.find((o:any)=>String(o.value)===String(v));if(h)return h.label;}const src=(remoteOptions as any)[col.source];if(src){const h=src.find((o:any)=>String(o.value)===String(v));if(h)return h.label;}if(v==null||v==='')return '—';const s=String(v);return /^\d{4}-\d{2}-\d{2}/.test(s)?s.slice(0,10):s;}
function optionsOf(f:any){return f.options||(remoteOptions as any)[f.source]||[];}
async function loadRemote(){const srcs:Record<string,string>={customers:'/api/v1/crm/customers',products:'/api/v1/inventory/products',orders:'/api/v1/sales/orders',groups:'/api/v1/crm/customer-groups',suppliers:'/api/v1/purchase/suppliers',warehouses:'/api/v1/inventory/warehouses'};const used=formFields.filter(f=>f.source).map(f=>f.source);await Promise.all(used.map(async s=>{if(remoteOptions[s])return;try{const d:any=await mockGet(srcs[s]||API,{pageSize:200});const list=Array.isArray(d)?d:d?.list||[];remoteOptions[s]=list.map((x:any)=>({label:x.name||x.code||x.title||('#'+x.id),value:x.id}));}catch{remoteOptions[s]=[];}}));}
async function load(){loading.value=true;try{const d:any=await mockGet(API,{page:page.value,pageSize:pageSize.value,keyword:q.keyword,status:q.status});rows.value=Array.isArray(d)?d:d?.list||[];total.value=Number(d?.total??rows.value.length);}catch(e:any){toast.error(e?.message||'加载失败');rows.value=[];}finally{loading.value=false;}}
function reload(){page.value=1;load();}
function resetQuery(){q.keyword='';q.status='';reload();}
function resetForm(){for(const k of Object.keys(form))delete form[k];for(const f of formFields)form[f.prop]=DEFAULTS[f.prop]??(f.type==='number'?0:'');}
function openForm(row?:any){editing.value=row||null;resetForm();if(row)for(const f of formFields)if(row[f.prop]!==undefined)form[f.prop]=row[f.prop];formVisible.value=true;}
async function save(){for(const f of formFields){if(f.required&&(form[f.prop]===''||form[f.prop]==null)){toast.warning('请填写「'+f.label+'」');return;}}saving.value=true;try{const payload:any={};for(const f of formFields)payload[f.prop]=form[f.prop];if(editing.value?.id)await mockPatch(API+'/'+editing.value.id,payload);else await mockPost(API,payload);toast.success(editing.value?'已保存':'已创建');formVisible.value=false;await load();}catch(e:any){toast.error(e?.message||'保存失败');}finally{saving.value=false;}}
function actionsOf(row:any){return actions.filter(a=>!a.from||a.from.some(s=>Number(s)===Number(row.status)));}
function colorOf(a:any){return a.variant==='danger'?'var(--ds-danger)':a.variant==='warning'?'var(--ds-warning)':'var(--ds-brand)';}
async function runAction(row:any,a:any){if(!await uiConfirm('确定执行「'+a.label+'」吗？','业务确认'))return;try{const res:any=await mockPost('/_biz/action/'+COLLECTION+'/'+row.id+'/'+a.key,{label:a.label});toast.success(res?.message||(a.label+'成功'));await load();}catch(e:any){toast.error(e?.message||'操作失败');}}
async function removeRow(row:any){if(!await uiConfirm('确定删除 #'+row.id+' 吗？','删除确认'))return;try{await mockDel(API+'/'+row.id);toast.success('已删除');await load();}catch(e:any){toast.error(e?.message||'删除失败');}}
function exportCsv(){const head=columns.map(c=>c.label);const lines=[head.join(',')].concat(rows.value.map(r=>columns.map(c=>String(display(r,c)).replace(/,/g,' ')).join(',')));const blob=new Blob(['\ufeff'+lines.join('\n')],{type:'text/csv;charset=utf-8'});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='条码标签.csv';a.click();}
onMounted(()=>{load();if(!isReport)loadRemote();});
</script>

<style scoped>
.lb-page{padding:16px}.lb-head{display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:14px}.lb-kicker{font-size:11px;letter-spacing:1px;color:#ea580c;font-weight:700;margin-bottom:4px}.lb-head h2{margin:0;font-size:20px}.lb-actions{display:flex;gap:8px}.lb-stats{display:flex;gap:12px;margin-bottom:14px}.lb-stat{flex:1;background:var(--ds-bg-soft);border-left:3px solid #ea580c;border-radius:8px;padding:10px 14px;display:flex;flex-direction:column;gap:4px}.lb-stat span{font-size:12px;color:var(--ds-text-3)}.lb-stat b{font-size:20px}.lb-search{display:flex;gap:8px;margin-bottom:12px;flex-wrap:wrap}.lb-search input{min-width:200px}.lb-pager{display:flex;justify-content:flex-end;padding:12px}.lb-form{display:grid;grid-template-columns:1fr 1fr;gap:14px}.lb-field{display:flex;flex-direction:column;gap:5px;font-size:13px}.lb-field i{color:var(--ds-danger);font-style:normal}.lb-foot{display:flex;justify-content:flex-end;gap:8px}
.lb-setup{display:flex;align-items:center;gap:16px;flex-wrap:wrap;background:var(--ds-card);border:1px solid var(--ds-divider);border-radius:10px;padding:12px 16px;margin-bottom:14px}.lb-setup-title{display:flex;align-items:center;gap:6px;font-size:13px;font-weight:700;color:var(--ds-text-1)}.lb-setup-f{display:flex;align-items:center;gap:6px;font-size:12px;color:var(--ds-text-3)}.lb-setup-f select{width:130px}.lb-setup-info{display:flex;align-items:center;gap:5px;margin-left:auto;font-size:12px;color:var(--ds-text-3)}
.lb-sheet{display:grid;gap:12px}.lb-label{background:#fff;border:1px dashed #cbd5e1;border-radius:6px;padding:12px;display:flex;flex-direction:column;gap:8px;box-shadow:0 1px 2px rgba(0,0,0,.04)}.lb-label.off{opacity:.6;background:var(--ds-bg-soft)}.lb-label-top{display:flex;justify-content:space-between;align-items:center;font-size:13px}.lb-dot{width:8px;height:8px;border-radius:50%}.lb-barcode{height:40px;display:flex;align-items:flex-end;gap:1px;overflow:hidden;background:#fff;padding:0 2px}.lb-barcode span{display:inline-block;height:100%;background:transparent;flex:none}.lb-barcode span.on{background:#111}.lb-code{text-align:center;font-family:monospace;font-size:11px;letter-spacing:1px;color:#334155}.lb-info{display:flex;flex-direction:column;gap:3px;border-top:1px dashed #e2e8f0;padding-top:7px}.lb-info div{display:flex;justify-content:space-between;font-size:11px}.lb-info span{color:var(--ds-text-3)}.lb-info b{color:var(--ds-text-1);font-weight:600;max-width:60%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.lb-label-foot{display:flex;justify-content:space-between;align-items:center;border-top:1px solid #f1f5f9;padding-top:7px}.lb-state{font-size:11px;font-weight:600}.lb-ops{display:flex;gap:2px}.lb-ops button{width:24px;height:24px;display:flex;align-items:center;justify-content:center;border:1px solid var(--ds-divider);background:var(--ds-card);border-radius:5px;cursor:pointer;color:var(--ds-text-2)}.lb-ops button:hover{border-color:#ea580c;color:#ea580c}.lb-ops button.del:hover{border-color:var(--ds-danger);color:var(--ds-danger)}
.lb-empty{grid-column:1/-1;display:flex;flex-direction:column;align-items:center;justify-content:center;color:var(--ds-text-3);padding:48px}.lb-empty p{margin:8px 0 0;font-size:13px}
</style>
