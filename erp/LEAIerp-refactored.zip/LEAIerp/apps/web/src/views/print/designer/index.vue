<template>
  <div class="page-card">
    <!-- 打印模板设计器：拖拽画布 + 套打校准 + 模板匹配条件，保存进 schema_json -->
    <DsTabs v-model="tab" :items="tabItems" />

    <!-- 模板设计 -->
    <div v-if="tab === 'design'">
      <div class="des-form">
        <label class="entity-field"><span>模板</span><DsSelect v-model="tplId" :options="templateOptions" class="des-sel-tpl" :clearable="false" @change="loadTpl" /></label>
        <label class="entity-field"><span>名称</span><input v-model="form.name" class="ds-input des-inp-name" /></label>
        <label class="entity-field"><span>单据类型</span><input v-model="form.bizType" class="ds-input des-inp-biz" /></label>
        <label class="entity-field"><span>纸张</span><DsSelect v-model="form.paper" :options="designerPaperOptions" class="des-sel-paper" :clearable="false" /></label>
        <!-- 模板匹配条件：多模板按 组织 / 业务场景 / 单据类型 / 默认 匹配 -->
        <label class="entity-field"><span>组织ID</span><DsInputNumber v-model="match.orgId" :min="0" size="sm" class="des-num-org" /></label>
        <label class="entity-field"><span>业务场景</span><DsSelect v-model="match.bizScene" :options="bizSceneOptions" class="des-sel-scene" :clearable="false" /></label>
        <label class="entity-field"><span>默认模板</span><DsSwitch v-model="match.isDefault" /></label>
        <span class="des-form-actions">
          <DsButton variant="primary" @click="saveTpl">保存新版本</DsButton>
          <DsButton @click="preview">预览</DsButton>
        </span>
      </div>
      <div class="des-columns">
        <div>
          <div class="panel-title">字段（点击插入到光标处）</div>
          <div class="field-box">
            <DsTag v-for="f in fields" :key="f.v" class="field-tag" color="brand" size="sm" @click="insert(f.v)">{{ f.label }}</DsTag>
          </div>
          <div class="panel-title">拖拽组件（拖到画布）</div>
          <div class="field-box">
            <div v-for="c in palette" :key="c.type" class="palette-item" draggable="true" @dragstart="onDragStart(c.type)">{{ c.label }}</div>
          </div>
        </div>
        <div>
          <!-- 坐标统一以 mm 显示：96dpi 下 1mm ≈ 3.78px，底层仍存 px 保持拖拽手感 -->
          <div class="panel-title">拖拽画布（坐标 mm，96dpi ≈ {{ pxPerMm.toFixed(2) }} px/mm，10mm 网格）</div>
          <div ref="canvasRef" class="canvas" @dragover.prevent @drop="onDrop">
            <div v-for="(w, i) in widgets" :key="i" class="widget" :class="{ selected: selectedIndex === i }"
                 :style="{ left: w.x + 'px', top: w.y + 'px' }"
                 @mousedown="startMove($event, i)" @click.stop="selectedIndex = i">
              <span class="widget-type">{{ w.type }}</span>{{ w.text }}
              <small class="widget-mm">{{ wMm(w, 'x') }},{{ wMm(w, 'y') }} mm</small>
            </div>
            <DsEmpty v-if="!widgets.length" description="将左侧组件拖入此处" size="sm" />
          </div>
          <!-- 元素属性：直接以 mm 编辑，写回时换算成 px -->
          <div v-if="currentWidget" class="prop-panel">
            <b>元素属性（单位 mm）</b>
            <span>类型：{{ currentWidget.type }}</span>
            <label>X(mm)<DsInputNumber :model-value="wMm(currentWidget, 'x')" @update:model-value="(v) => setWMm(currentWidget, 'x', v)" :precision="2" :step="1" size="sm" /></label>
            <label>Y(mm)<DsInputNumber :model-value="wMm(currentWidget, 'y')" @update:model-value="(v) => setWMm(currentWidget, 'y', v)" :precision="2" :step="1" size="sm" /></label>
            <label style="flex:1">内容<input v-model="currentWidget.text" class="ds-input" /></label>
            <DsButton size="sm" variant="danger" @click="removeWidget">删除</DsButton>
          </div>
          <div class="panel-title">Handlebars 模板（存 schema 列，向后兼容）</div>
          <textarea v-model="form.schema" class="ds-input" rows="6" />
        </div>
        <div>
          <div class="panel-title">预览（含 bwip-js 条码）</div>
          <iframe ref="frameRef" class="preview" />
        </div>
      </div>
    </div>

    <!-- 套打校准：底图上传 + X/Y 偏移微调 + 缩放，参数随模板保存 -->
    <div v-if="tab === 'calibration'">
      <DsAlert type="info" :closable="false" show-icon style="margin-bottom:12px"
               title="上传已印好表格的空白单据扫描件作为底图，微调偏移与缩放让元素对准格线；校准参数写入 schema JSON，打印时同参数叠加。" />
      <div class="des-columns des-columns--calib">
        <div>
          <div class="panel-title">背景底图</div>
          <input type="file" accept="image/*" @change="onBgUpload" />
          <div v-if="calibration.bgImage" class="calib-file-ok">已选择底图（已内嵌到 schema）</div>
          <div class="panel-title">偏移微调（单位 mm，可正负）</div>
          <div class="des-calib-form">
            <label class="entity-field"><span>X 偏移</span><DsInputNumber v-model="calibration.offsetX" :precision="2" :step="0.5" size="sm" /></label>
            <label class="entity-field"><span>Y 偏移</span><DsInputNumber v-model="calibration.offsetY" :precision="2" :step="0.5" size="sm" /></label>
            <label class="entity-field"><span>缩放(%)</span><DsInputNumber v-model="calibration.scale" :min="50" :max="200" :step="1" size="sm" /></label>
          </div>
          <DsButton size="sm" @click="resetCalibration">重置校准</DsButton>
        </div>
        <div style="grid-column: span 2">
          <div class="panel-title">套打缩略预览（底图 + 元素叠加）</div>
          <div class="calib-stage">
            <div class="calib-paper">
              <img v-if="calibration.bgImage" :src="calibration.bgImage" class="calib-bg" />
              <div v-else class="calib-empty">请先上传底图（如空白单据扫描件）</div>
              <div class="calib-layer" :style="calibLayerStyle">
                <div v-for="(w, i) in widgets" :key="i" class="calib-widget" :style="{ left: w.x + 'px', top: w.y + 'px' }">{{ w.text }}</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- 系统参数 -->
    <div v-if="tab === 'config'">
      <DsAlert type="info" :closable="false" title="下面的“配置键”必须与后端 sys_config.config_key 完全一致，不一致保存后不会生效" show-icon style="margin-bottom:12px" />
      <table class="ds-table">
        <thead><tr>
          <th>配置键（与 sys_config 一致）</th><th>配置值</th><th>操作</th>
        </tr></thead>
        <tbody>
          <tr v-for="row in configs" :key="row.configKey">
            <td>{{ row.configKey }}</td>
            <td><input v-model="row.configValue" class="ds-input" /></td>
            <td><DsButton size="sm" variant="primary" @click="saveOne(row)">保存</DsButton></td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</template>
<script setup lang="ts">
import { ref, reactive, computed, onMounted } from 'vue'
import {
  DsAlert, DsButton, DsEmpty, DsInputNumber, DsSelect, DsSwitch, DsTabs, DsTag,
} from '../../../components'
import { useToast } from '../../../components/ds/toast'
import bwipjs from 'bwip-js'
import { printApi, sysApi } from '../../../api'

const toast = useToast()
const tabItems = [
  { label: '模板设计', value: 'design' },
  { label: '套打校准', value: 'calibration' },
  { label: '系统参数', value: 'config' },
]
const designerPaperOptions = [
  { label: 'A4', value: 'A4' }, { label: '80mm', value: '80mm' },
  { label: '58mm', value: '58mm' }, { label: '标签', value: 'LABEL' },
]
const bizSceneOptions = [
  { label: '通用', value: 'COMMON' }, { label: '零售小票', value: 'RETAIL' },
  { label: '批发出库', value: 'WHOLESALE' }, { label: '电商发货', value: 'ECOMMERCE' }, { label: '门店自提', value: 'PICKUP' },
]
const tab = ref('design')
const templates = ref<any[]>([])
/** 原模板内 el-option（模板列表）提升为 script 数组，label 格式保持 `${name}(v${version})` */
const templateOptions = computed(() => templates.value.map((t: any) => ({ label: `${t.name}(v${t.version})`, value: t.id })))
const tplId = ref<number | null>(null)
const form = reactive<any>({ name: '', bizType: 'SALE_ORDER', paper: 'A4', schema: '' })
/** 模板匹配条件（保存时同时写入 schema JSON 与顶层字段） */
const match = reactive<any>({ orgId: 0, bizScene: 'COMMON', isDefault: false })
/** 套打校准参数 */
const calibration = reactive<any>({ bgImage: '', offsetX: 0, offsetY: 0, scale: 100 })

/** 96dpi 下每毫米对应像素数：96 / 25.4 ≈ 3.7795 */
const PX_PER_MM = 96 / 25.4
/** 缩略预览相对 210mm 宽的缩放系数 */
const PREVIEW_SCALE = 560 / (210 * PX_PER_MM)
const pxPerMm = computed(() => PX_PER_MM)
const toMm = (px: any) => Number((Number(px || 0) / PX_PER_MM).toFixed(2))
const toPx = (mm: any) => Number((Number(mm || 0) * PX_PER_MM).toFixed(2))
/** 画布元素坐标：底层 px，界面 mm */
function wMm(w: any, key: 'x' | 'y') { return toMm(w[key]) }
function setWMm(w: any, key: 'x' | 'y', val: any) { w[key] = toPx(val) }

const fields = [
  { label: '单号', v: '{{order.order_no}}' }, { label: '日期', v: '{{order.date}}' }, { label: '客户', v: '{{customer.name}}' },
  { label: '明细循环', v: '{{#each lines}}{{this.product_name}} {{this.qty}} {{this.price}} {{this.amount}}{{/each}}' },
  { label: '合计', v: '{{order.total}}' }, { label: '大写金额', v: '{{cnMoney order.total}}' }, { label: '二维码', v: '{{qrcode order.order_no}}' },
]
const palette = [{ type: '文本', label: '文本' }, { type: '字段', label: '字段' }, { type: '条码', label: '条码' }, { type: '二维码', label: '二维码' }, { type: '明细区', label: '明细循环区' }, { type: '图片', label: 'LOGO' }]
const widgets = ref<any[]>([])
const selectedIndex = ref<number | null>(null)
const currentWidget = computed(() => (selectedIndex.value != null ? widgets.value[selectedIndex.value] : null))
const dragType = ref('')
const canvasRef = ref<HTMLElement | null>(null)
const frameRef = ref<HTMLIFrameElement | null>(null)
const configs = ref<any[]>([
  { configKey: 'sys.tax_rate', configValue: '', remark: '默认税率' },
  { configKey: 'sys.amount_precision', configValue: '', remark: '金额精度' },
  { configKey: 'sys.negative_stock', configValue: '', remark: '是否允许负库存(0/1)' },
  { configKey: 'sys.currency', configValue: '', remark: '本位币' },
])

/** 校准层样式：按缩略比例平移 + 缩放，offset 以 mm 计 */
const calibLayerStyle = computed(() => ({
  transform: `translate(${(calibration.offsetX * PX_PER_MM * PREVIEW_SCALE).toFixed(2)}px, ${(calibration.offsetY * PX_PER_MM * PREVIEW_SCALE).toFixed(2)}px) scale(${(calibration.scale / 100 * PREVIEW_SCALE).toFixed(4)})`,
  transformOrigin: '0 0',
}))

function onDragStart(t: string) { dragType.value = t }
function onDrop(e: DragEvent) {
  const rect = canvasRef.value!.getBoundingClientRect()
  widgets.value.push({ type: dragType.value, text: dragType.value === '字段' ? '{{order.order_no}}' : '新' + dragType.value, x: e.clientX - rect.left, y: e.clientY - rect.top })
  selectedIndex.value = widgets.value.length - 1
}
function startMove(e: MouseEvent, i: number) {
  selectedIndex.value = i
  const w = widgets.value[i]; const sx = e.clientX; const sy = e.clientY; const ox = w.x; const oy = w.y
  const move = (ev: MouseEvent) => { w.x = ox + ev.clientX - sx; w.y = oy + ev.clientY - sy }
  const up = () => { document.removeEventListener('mousemove', move); document.removeEventListener('mouseup', up) }
  document.addEventListener('mousemove', move); document.addEventListener('mouseup', up)
}
function removeWidget() {
  if (selectedIndex.value == null) return
  widgets.value.splice(selectedIndex.value, 1)
  selectedIndex.value = null
}
function insert(v: string) { form.schema += v }
/** 底图读取为 dataURL 内嵌进 schema，刷新后仍可预览 */
function onBgUpload(e: Event) {
  const input = e.target as HTMLInputElement
  const file = input.files?.[0]
  if (!file) return
  const reader = new FileReader()
  reader.onload = () => { calibration.bgImage = String(reader.result || '') }
  reader.readAsDataURL(file)
}
function resetCalibration() { calibration.offsetX = 0; calibration.offsetY = 0; calibration.scale = 100 }

async function loadList() { const d: any = await printApi.listTemplates({ pageSize: 100 }); templates.value = d?.list || d || [] }
function loadTpl() {
  const t = templates.value.find((x) => x.id === tplId.value); if (!t) return
  form.name = t.name; form.bizType = t.bizType || t.biz_type; form.paper = t.paper; form.schema = t.schema || ''
  match.orgId = t.orgId || 0
  match.bizScene = t.bizScene || 'COMMON'
  match.isDefault = !!t.isDefault
  selectedIndex.value = null
  // 兼容旧版：schema_json 直接是数组；新版为 { widgets, calibration, match }
  let parsed: any = []
  try { parsed = JSON.parse(t.schemaJson || t.schema_json || '[]') } catch { parsed = [] }
  if (Array.isArray(parsed)) {
    widgets.value = parsed.map((w: any) => ({ ...w, xMm: toMm(w.x), yMm: toMm(w.y) }))
  } else {
    widgets.value = parsed.widgets || []
    Object.assign(calibration, { bgImage: '', offsetX: 0, offsetY: 0, scale: 100 }, parsed.calibration || {})
    Object.assign(match, { orgId: 0, bizScene: 'COMMON', isDefault: false }, parsed.match || {})
  }
}
async function saveTpl() {
  // 元素坐标同时写入 px 与 mm，便于后端/第三方按 mm 直接读取
  const widgetJson = widgets.value.map((w) => ({ ...w, xMm: toMm(w.x), yMm: toMm(w.y) }))
  const fullSchema = {
    unit: 'mm', pxPerMm: Number(PX_PER_MM.toFixed(4)),
    widgets: widgetJson,
    calibration: { bgImage: calibration.bgImage, offsetX: calibration.offsetX, offsetY: calibration.offsetY, scale: calibration.scale },
    match: { orgId: match.orgId, bizScene: match.bizScene, bizType: form.bizType, isDefault: match.isDefault },
  }
  await printApi.saveTemplate({
    name: form.name, bizType: form.bizType, paper: form.paper, schema: form.schema,
    orgId: match.orgId, bizScene: match.bizScene, isDefault: match.isDefault ? 1 : 0,
    schemaJson: JSON.stringify(fullSchema),
  })
  if (!tplId.value) { await loadList(); tplId.value = templates.value[0]?.id ?? null }
  toast.success('已保存为新版本，坐标/校准/匹配条件已写入 schema JSON'); loadList()
}
/** 预览：先用 bwip-js 生成条码/二维码，再交给后端 Handlebars 渲染 */
async function preview() {
  const sample = { order: { order_no: 'SL_0001', date: '2026-11-17', total: 982.7 }, customer: { name: '示例客户' }, lines: [{ product_name: '商品A', qty: 2, price: 10, amount: 20 }] }
  if (!tplId.value) { toast.warning('请先选择模板'); return }
  let html = (await printApi.preview(tplId.value!, { bizType: form.bizType, ...sample })).html
  // 后端标签占位可能是实体转义写法（&quot;），先把属性名去掉引号再统一匹配
  html = html.replace(/&quot;data-code&quot;|&amp;quot;data-code&amp;quot;/g, 'data-code').replace(/&quot;data-type&quot;|&amp;quot;data-type&amp;quot;/g, 'data-type')
  const codes = html.match(/<svg[^>]*data-code="[^"]+"[^>]*data-type="[^"]+"[^>]*>\s*<\/svg>/g) || []
  for (const tag of codes) {
    const code = /data-code="([^"]+)"/.exec(tag)![1]; const type = /data-type="([^"]+)"/.exec(tag)![1]
    let svg = ''
    try { svg = bwipjs.toSVG({ bcid: type === 'QRCODE' ? 'qrcode' : type === 'EAN' ? 'ean13' : 'code128', text: code, scale: 2, height: 8 }) } catch { svg = '' }
    html = html.replace(tag, `<span class="barcode">${svg}</span>`)
  }
  const doc = frameRef.value!.contentDocument!; doc.open(); doc.write(html); doc.close()
}
async function loadConfigs() {
  try {
    const remote = await sysApi.configs() as any
    configs.value = configs.value.map((c) => ({ ...c, configValue: remote?.[c.configKey] ?? remote?.find?.((r: any) => r.configKey === c.configKey)?.configValue ?? '' }))
  } catch { /* 接口返回结构不同时保留本地键名，用户照 sys_config 填写 */ }
}
async function saveOne(row: any) { await sysApi.saveConfig(row.configKey, row.configValue); toast.success('已保存 ' + row.configKey) }
onMounted(() => { loadList(); loadConfigs() })
</script>
<style scoped>
.panel-title { font-size: 13px; color: #666; margin: 8px 0 4px; }
.field-box { border: 1px solid #ebeef5; border-radius: 4px; padding: 6px; min-height: 60px; }
.field-tag { margin: 3px; cursor: pointer; }
.palette-item { padding: 6px 8px; border: 1px dashed #c0c4cc; border-radius: 4px; margin: 4px 0; cursor: grab; font-size: 13px; }
.canvas {
  position: relative; height: 260px; border: 1px solid #409eff; border-radius: 4px;
  background-color: #fafcff;
  /* 10mm 网格：10 * 3.7795 ≈ 37.8px */
  background-image: linear-gradient(to right, #d9e8fb 1px, transparent 1px), linear-gradient(to bottom, #d9e8fb 1px, transparent 1px);
  background-size: 37.795px 37.795px;
}
.widget { position: absolute; padding: 2px 6px; background: #ecf5ff; border: 1px solid #79bbff; border-radius: 4px; font-size: 12px; cursor: move; white-space: nowrap; }
.widget.selected { border-color: #f56c6c; box-shadow: 0 0 0 2px rgba(245, 108, 108, .2); }
.widget-type { color: #409eff; margin-right: 4px; }
.widget-mm { display: block; color: #909399; font-size: 10px; }
.prop-panel { display: flex; align-items: center; gap: 8px; flex-wrap: wrap; margin: 8px 0; padding: 8px; border: 1px solid #ebeef5; border-radius: 4px; font-size: 12px; }
.prop-panel b { color: #606266; }
.prop-panel label { display: inline-flex; align-items: center; gap: 4px; }
.preview { width: 100%; height: 560px; border: 1px solid #ebeef5; border-radius: 4px; }
.calib-stage { overflow: auto; max-height: 620px; border: 1px dashed #c0c4cc; border-radius: 4px; background: #f5f7fa; padding: 12px; text-align: center; }
.calib-paper { position: relative; width: 560px; height: 792px; margin: 0 auto; background: #fff; box-shadow: 0 2px 10px rgba(0, 0, 0, .08); overflow: hidden; }
.calib-bg { position: absolute; inset: 0; width: 100%; height: 100%; object-fit: contain; opacity: .85; }
.calib-empty { position: absolute; inset: 0; display: grid; place-items: center; color: #c0c4cc; font-size: 13px; }
.calib-layer { position: absolute; top: 0; left: 0; }
.calib-widget { position: absolute; padding: 1px 4px; border: 1px dashed #f56c6c; color: #f56c6c; font-size: 12px; white-space: nowrap; background: rgba(245, 108, 108, .06); }
.calib-file-ok { font-size: 12px; color: #67c23a; margin-top: 6px; }
/* 以下为替换 el-form/el-row 后新增的布局样式，原画布/校准样式保持不变 */
.des-form { display: flex; flex-wrap: wrap; align-items: center; gap: 8px 16px; margin-bottom: 12px; }
.des-form-actions { display: inline-flex; gap: 8px; }
.des-columns { display: grid; grid-template-columns: 6fr 10fr 8fr; gap: 12px; align-items: start; }
.des-columns--calib { grid-template-columns: 1fr 2fr; }
.des-calib-form { display: grid; grid-template-columns: 1fr; gap: 10px; margin: 8px 0 12px; }
.des-sel-tpl { width: 220px; }
.des-inp-name { width: 160px; }
.des-inp-biz { width: 140px; }
.des-sel-paper { width: 120px; }
.des-num-org { width: 110px; }
.des-sel-scene { width: 130px; }
</style>