<template>
  <div class="erp-page">
    <div class="entity-search">
      <input v-model="q.bizNo" class="ds-input rec-search__input" placeholder="单据号" />
      <DsButton variant="primary" size="sm" @click="load">查询</DsButton>
    </div>
    <div class="entity-table">
      <table class="ds-table">
        <thead><tr>
          <th>时间</th><th>单据类型</th><th>单据号</th><th>模板版本</th><th>份数</th>
          <th>通道</th><th>操作人</th><th>水印</th><th>操作</th>
        </tr></thead>
        <tbody>
          <tr v-for="(s, i) in list" :key="s.id ?? i">
            <td>{{ s.printedAt }}</td>
            <td>{{ s.bizType }}</td>
            <td>{{ s.bizNo }}</td>
            <td>{{ s.templateVersion }}</td>
            <td>{{ s.copies }}</td>
            <td>{{ s.channel }}</td>
            <td>{{ s.printedByName }}</td>
            <td>{{ s.watermark }}</td>
            <td>
              <DsButton variant="text" size="sm" @click="onReprint(s)">补打</DsButton>
              <DsButton v-if="s.pdfUrl" variant="text" size="sm" @click="onPdf(s)">PDF</DsButton>
            </td>
          </tr>
          <tr v-if="!list.length"><td colspan="9" class="entity-empty">暂无打印记录</td></tr>
        </tbody>
      </table>
    </div>
    <div class="entity-pager">
      <DsPagination v-model:current-page="page" :page-size="pageSize" :total="total" layout="total, prev, pager, next" @current-change="load" />
    </div>
  </div>
</template>

<script setup lang="ts">
import { reactive, ref, onMounted } from 'vue';
import { DsButton, DsPagination } from '../../components';
import { useToast } from '../../components/ds/toast';
import { printApi } from '../../api';

const toast = useToast();
const loading = ref(false);
const list = ref<any[]>([]); const total = ref(0); const page = ref(1); const pageSize = ref(10);
const q = reactive<{ bizNo?: string }>({});
async function load() {
  loading.value = true;
  try { const d: any = await printApi.records({ ...q, page: page.value, pageSize: pageSize.value }); list.value = d.list || d || []; total.value = Number(d.total || 0); }
  catch { list.value = []; } finally { loading.value = false; }
}
async function onReprint(row: any) {
  await printApi.createJob({ bizType: row.bizType, bizId: row.bizId, templateId: row.templateId, copies: 1, channel: row.channel });
  toast.success('补打任务已创建'); load();
}
function onPdf(row: any) { window.open(row.pdfUrl); }
onMounted(load);
</script>

<style scoped>
.rec-search__input { width: 150px; }
</style>