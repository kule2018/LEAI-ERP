<template>
  <div class="erp-page">
    <div class="erp-filter">
      <DsSelect v-model="q.bizType" :options="filterBizTypeOptions" placeholder="单据类型" clearable size="sm" class="tpl-filter-select" />
      <DsButton size="sm" variant="primary" @click="load">查询</DsButton>
      <span style="flex: 1" />
      <DsButton v-perm="'print:template:edit'" size="sm" variant="primary" @click="openForm()">新增模板</DsButton>
    </div>
    <div class="entity-table" v-loading="loading">
      <table class="ds-table">
        <thead><tr>
          <th>模板名称</th><th>编码</th><th>单据类型</th><th>纸张</th><th>版本</th><th>默认</th><th>操作</th>
        </tr></thead>
        <tbody>
          <tr v-for="s in list" :key="s.id">
            <td>{{ s.name }}</td>
            <td>{{ s.code }}</td>
            <td>{{ s.bizType }}</td>
            <td>{{ s.paper }}</td>
            <td>{{ s.version }}</td>
            <td><DsTag v-if="s.isDefault" color="success" size="sm">默认</DsTag></td>
            <td>
              <DsButton v-perm="'print:template:edit'" variant="text" size="sm" @click="openForm(s)">设计/编辑</DsButton>
              <DsButton variant="text" size="sm" @click="onPreview(s)">预览</DsButton>
              <DsButton variant="text" size="sm" @click="onCopy(s)">复制</DsButton>
            </td>
          </tr>
          <tr v-if="!list.length"><td colspan="7" class="entity-empty">暂无模板</td></tr>
        </tbody>
      </table>
    </div>

    <!-- 模板设计器：Handlebars 文本模式 + hiprint JSON 模式并存 -->
    <DsModal v-model="formVisible" :title="editing?.id ? '编辑模板（保存自动升版本）' : '新增模板'" :width="800">
      <div class="tpl-form entity-form">
        <label class="entity-field"><span>名称</span><input v-model="editing.name" class="ds-input" /></label>
        <label class="entity-field"><span>编码</span><input v-model="editing.code" class="ds-input" /></label>
        <label class="entity-field"><span>单据类型</span><DsSelect v-model="editing.bizType" :options="formBizTypeOptions" size="sm" :clearable="false" /></label>
        <label class="entity-field"><span>纸张</span><DsSelect v-model="editing.paper" :options="paperOptions" size="sm" :clearable="false" /></label>
      </div>
      <textarea v-model="editing.schema" class="ds-input tpl-schema" rows="16" placeholder="Handlebars 模板，以 < 开头；可粘贴 hiprint 设计器 JSON（前端按 JSON 渲染占位）" />
      <template #footer><div class="entity-modal-foot"><DsButton @click="formVisible = false">取消</DsButton><DsButton variant="primary" @click="onSave">保存</DsButton></div></template>
    </DsModal>

    <DsModal v-model="previewVisible" title="打印预览（预览 → 设计 → 静默打印 → 导出 PDF）" :width="820">
      <div ref="previewRef" v-html="previewHtml" />
      <template #footer>
        <div class="entity-modal-foot">
          <DsButton @click="previewVisible = false">关闭</DsButton>
          <DsButton @click="onSilent">本地静默打印</DsButton>
          <DsButton variant="primary" @click="onServerPdf">服务端 PDF / 记录</DsButton>
        </div>
      </template>
    </DsModal>
  </div>
</template>

<script setup lang="ts">
import { reactive, ref, onMounted } from 'vue';
import { DsButton, DsModal, DsSelect, DsTag } from '../../components';
import { useToast } from '../../components/ds/toast';
import { printApi } from '../../api';

/** 原模板内 el-option 提升为 script 选项数组（筛选区与表单区文案不同，保持原样） */
const filterBizTypeOptions = [
  { label: '销售单', value: 'SALE_ORDER' }, { label: '销售小票', value: 'SALE_RECEIPT' },
  { label: '采购单', value: 'PURCHASE_ORDER' }, { label: '条码标签', value: 'LABEL' },
];
const formBizTypeOptions = [
  { label: '销售单', value: 'SALE_ORDER' }, { label: '销售小票', value: 'SALE_RECEIPT' },
  { label: '采购单', value: 'PURCHASE_ORDER' }, { label: '标签', value: 'LABEL' },
];
const paperOptions = [
  { label: 'A4', value: 'A4' }, { label: '80mm', value: '80mm' },
  { label: '58mm', value: '58mm' }, { label: '标签 40x30', value: '40x30' },
];

const toast = useToast();
const loading = ref(false);
const list = ref<any[]>([]);
const q = reactive<{ bizType?: string }>({});
const formVisible = ref(false);
const editing = ref<any>({});
const previewVisible = ref(false);
const previewHtml = ref('');
const previewRef = ref<HTMLElement | null>(null);
const current = ref<any>(null);

async function load() {
  loading.value = true;
  try { const d: any = await printApi.templates(q); list.value = d?.list || d || []; } catch { list.value = []; } finally { loading.value = false; }
}
function openForm(row?: any) {
  editing.value = row ? { ...row } : { name: '', code: '', bizType: 'SALE_ORDER', paper: 'A4', schema: '<h1>{{order.order_no}}</h1>' };
  formVisible.value = true;
}
async function onSave() {
  await printApi.saveTemplate(editing.value);
  toast.success('已保存（模板版本化，历史单据不受影响）'); formVisible.value = false; load();
}
async function onCopy(row: any) {
  await printApi.saveTemplate({ ...row, id: undefined, name: row.name + ' 副本', isDefault: 0 });
  load();
}
async function onPreview(row: any) {
  current.value = row;
  // 预览使用示例数据；真实数据由列表页传入
  const html: any = await printApi.preview(row.id, { order: { order_no: 'SL_DEMO', date: new Date().toLocaleString() }, lines: [{ product_name: '示例商品', qty: 1, price: '10.00', amount: '10.00' }], order_total: '10.00' });
  previewHtml.value = typeof html === 'string' ? html : `<pre>${JSON.stringify(html, null, 2)}</pre>`;
  previewVisible.value = true;
}
/** 静默打印：优先本地客户端 Agent（127.0.0.1:17521），不可用时退回浏览器打印 */
async function onSilent() {
  const html = previewRef.value?.innerHTML || '';
  try {
    const resp = await fetch('http://127.0.0.1:17521/print', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ html }) });
    if (resp.ok) { toast.success('已发送至本地打印客户端'); return; }
  } catch { /* 客户端未启动，走浏览器打印 */ }
  const win = window.open('', '_blank', 'width=800,height=600');
  win?.document.open(); win?.document.write(html); win?.document.close();
  win?.print();
}
async function onServerPdf() {
  if (!current.value) return;
  await printApi.createJob({ bizType: current.value.bizType, bizId: 0, templateId: current.value.id, copies: 1, channel: 'SERVER_PDF' });
  toast.success('服务端 PDF 任务已创建，可在「打印记录」查看/下载');
}
onMounted(load);
</script>

<style scoped>
.tpl-filter-select { width: 150px; }
.tpl-form { display: grid; grid-template-columns: 1fr 1fr; gap: 10px 16px; margin-bottom: 10px; }
.tpl-schema { width: 100%; box-sizing: border-box; }
</style>