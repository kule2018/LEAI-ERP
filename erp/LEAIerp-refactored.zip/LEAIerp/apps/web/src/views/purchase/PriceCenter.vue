<!-- 采购价目中心：协议价目表 / 历史采购价 / 最高限价管控 / 价格异常预警 -->
<template>
  <div class="pc-page">
    <div class="pc-stats">
      <div v-for="c in stats" :key="c.label" class="pc-stat"><span>{{ c.label }}</span><b :class="c.tone">{{ c.value }}</b></div>
    </div>

    <div class="pc-tabs">
      <button v-for="t in tabs" :key="t.key" class="pc-tab" :class="{ on: active === t.key }" @click="active = t.key">{{ t.label }}</button>
    </div>

    <!-- 协议价目表 -->
    <DsCard v-if="active === 'priceList'" title="采购协议价目表" :pad="false">
      <template #extra><DsButton size="sm" variant="primary" @click="editVisible = true">新增协议价</DsButton></template>
      <div class="pc-body">
        <table class="pc-table">
          <thead><tr><th>供应商</th><th>产品</th><th>协议价</th><th>市场价</th><th>折扣率</th><th>生效日期</th><th>状态</th><th>操作</th></tr></thead>
          <tbody>
            <tr v-for="p in priceList" :key="p.id">
              <td>{{ p.supplierName }}</td><td>{{ p.productName }}</td>
              <td>¥{{ Number(p.price).toFixed(2) }}</td><td>¥{{ Number(p.marketPrice).toFixed(2) }}</td>
              <td>{{ (Number(p.price)/Math.max(0.01,Number(p.marketPrice))*100).toFixed(0) }}%</td>
              <td>{{ p.effectiveDate }}</td>
              <td><DsTag :color="p.isActive ? 'success' : 'neutral'" size="sm">{{ p.isActive ? '生效' : '停用' }}</DsTag></td>
              <td><DsButton size="sm" @click="toggleActive(p)">{{ p.isActive ? '停用' : '启用' }}</DsButton></td>
            </tr>
            <tr v-if="!priceList.length"><td colspan="8" class="pc-empty">暂无协议价</td></tr>
          </tbody>
        </table>
      </div>
    </DsCard>

    <!-- 历史采购价 -->
    <DsCard v-if="active === 'history'" title="历史采购价（按产品）" :pad="false">
      <div class="pc-body">
        <table class="pc-table">
          <thead><tr><th>产品</th><th>采购次数</th><th>最低价</th><th>最高价</th><th>均价</th><th>最新价</th><th>趋势</th></tr></thead>
          <tbody>
            <tr v-for="h in history" :key="h.productName">
              <td>{{ h.productName }}</td><td>{{ h.count }}</td>
              <td>¥{{ h.min.toFixed(2) }}</td><td>¥{{ h.max.toFixed(2) }}</td><td>¥{{ h.avg.toFixed(2) }}</td><td>¥{{ h.latest.toFixed(2) }}</td>
              <td><DsTag :color="h.latest > h.avg*1.1 ? 'danger' : h.latest < h.avg*0.9 ? 'success' : 'neutral'" size="sm">{{ h.latest > h.avg*1.1 ? '上涨' : h.latest < h.avg*0.9 ? '下降' : '平稳' }}</DsTag></td>
            </tr>
            <tr v-if="!history.length"><td colspan="7" class="pc-empty">暂无历史采购价（采购收货/crumb 后生成）</td></tr>
          </tbody>
        </table>
      </div>
    </DsCard>

    <!-- 价格异常预警 -->
    <DsCard v-if="active === 'alert'" title="价格异常预警" :pad="false">
      <div class="pc-body">
        <div class="pc-alert-hint">采购单明细价高于该产品历史均价 10% 时触发预警，需复核后再审批。</div>
        <table class="pc-table">
          <thead><tr><th>采购单</th><th>供应商</th><th>产品</th><th>本次单价</th><th>历史均价</th><th>偏差</th><th>建议</th></tr></thead>
          <tbody>
            <tr v-for="a in alerts" :key="a.orderNo + a.productName">
              <td>{{ a.orderNo }}</td><td>{{ a.supplierName }}</td><td>{{ a.productName }}</td>
              <td>¥{{ a.price.toFixed(2) }}</td><td>¥{{ a.avg.toFixed(2) }}</td>
              <td class="pc-danger">+{{ a.deviation.toFixed(1) }}%</td><td>核价或走询比价</td>
            </tr>
            <tr v-if="!alerts.length"><td colspan="7" class="pc-empty">暂无价格异常，采购价管控良好</td></tr>
          </tbody>
        </table>
      </div>
    </DsCard>

    <!-- 新增协议价 -->
    <DsModal v-model="editVisible" title="新增协议价" :width="480">
      <div class="pc-form">
        <label><span>供应商</span><select v-model="form.supplierId" class="ds-input"><option v-for="s in suppliers" :key="s.id" :value="s.id">{{ s.name }}</option></select></label>
        <label><span>产品</span><select v-model="form.productId" class="ds-input"><option v-for="p in products" :key="p.id" :value="p.id">{{ p.name }}</option></select></label>
        <label><span>协议价</span><input v-model.number="form.price" class="ds-input" type="number" /></label>
        <label><span>市场价</span><input v-model.number="form.marketPrice" class="ds-input" type="number" /></label>
        <label><span>生效日期</span><DsDatePicker v-model="form.effectiveDate" /></label>
      </div>
      <template #footer><div class="pc-foot"><DsButton @click="editVisible=false">取消</DsButton><DsButton variant="primary" @click="savePrice">保存</DsButton></div></template>
    </DsModal>
  </div>
</template>

<script setup lang="ts">
/** 价格管控：协议价、历史价趋势、采购价异常预警，帮助采购降本与议价。 */
import { computed, onMounted, reactive, ref } from 'vue';
import { DsButton, DsCard, DsModal, DsTag } from '../../components';
import { mockGet, mockPost } from '../../api/mockAdapter';
import { useToast } from '../../components/ds/toast';

const toast = useToast();
const KEY = '/api/v1/industry/purchasePrices';
const tabs = [{ key: 'priceList', label: '协议价目表' }, { key: 'history', label: '历史采购价' }, { key: 'alert', label: '价格异常预警' }];
const active = ref('priceList');
const priceList = ref<any[]>([]);
const orders = ref<any[]>([]);
const suppliers = ref<any[]>([]);
const products = ref<any[]>([]);
const editVisible = ref(false);
const form = reactive<any>({ supplierId: null, productId: null, price: 0, marketPrice: 0, effectiveDate: new Date().toISOString().slice(0, 10) });

/** 历史价：按产品聚合采购单明细的单价，计算最低/最高/均价/最新价 */
const history = computed(() => {
  const map: Record<string, number[]> = {};
  for (const o of orders.value) for (const l of (o.lines || [])) { (map[l.productName] ||= []).push(Number(l.unitPrice || 0)); }
  return Object.entries(map).map(([name, prices]) => {
    const avg = prices.reduce((s, p) => s + p, 0) / prices.length;
    return { productName: name, count: prices.length, min: Math.min(...prices), max: Math.max(...prices), avg, latest: prices[prices.length - 1] };
  });
});
/** 异常预警：本次单价 > 历史均价 ×1.1 */
const alerts = computed(() => {
  const out: any[] = [];
  for (const o of orders.value) for (const l of (o.lines || [])) {
    const h = history.value.find((x) => x.productName === l.productName);
    if (h && h.avg > 0 && Number(l.unitPrice) > h.avg * 1.1) out.push({ orderNo: o.orderNo, supplierName: o.supplierName, productName: l.productName, price: Number(l.unitPrice), avg: h.avg, deviation: (Number(l.unitPrice) / h.avg - 1) * 100 });
  }
  return out;
});
const stats = computed(() => [
  { label: '协议价条目', value: String(priceList.value.length), tone: '' },
  { label: '在效协议价', value: String(priceList.value.filter((p) => p.isActive).length), tone: 'pc-brand' },
  { label: '历史价产品', value: String(history.value.length), tone: '' },
  { label: '价格异常', value: String(alerts.value.length), tone: alerts.value.length ? 'pc-danger' : '' },
]);

async function load(): Promise<void> {
  const list = async (u: string) => { const r: any = await mockGet(u, { pageSize: 300 }); return Array.isArray(r) ? r : r?.list || []; };
  priceList.value = await list(KEY);
  orders.value = await list('/api/v1/industry/purchaseOrders');
  suppliers.value = await list('/api/v1/industry/suppliers');
  products.value = await list('/api/v1/inventory/products');
  if (!form.supplierId) form.supplierId = suppliers.value[0]?.id;
  if (!form.productId) form.productId = products.value[0]?.id;
}
async function savePrice(): Promise<void> {
  if (!form.productId || !form.price || form.price <= 0) { toast.warning('请选择产品并填写协议价'); return; }
  const p = { id: Date.now(), supplierId: Number(form.supplierId), supplierName: suppliers.value.find((s) => s.id === form.supplierId)?.name || '', productId: Number(form.productId), productName: products.value.find((x) => x.id === form.productId)?.name || '', price: Number(form.price), marketPrice: Number(form.marketPrice), effectiveDate: form.effectiveDate, isActive: true };
  const saved: any = await mockPost(KEY, p);
  priceList.value.push({ ...p, id: saved?.id || p.id });
  editVisible.value = false; toast.success('协议价已保存');
}
async function toggleActive(p: any): Promise<void> { p.isActive = !p.isActive; await mockPost(KEY, { ...p }); toast.success(p.isActive ? '协议价已启用' : '协议价已停用'); }
onMounted(load);
</script>

<style scoped>
.pc-page { display: flex; flex-direction: column; gap: 14px; padding: 16px; }
.pc-stats { display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px; }
.pc-stat { border: 1px solid var(--ds-border); border-radius: 10px; padding: 14px 16px; background: var(--ds-bg-elevated); display: flex; flex-direction: column; gap: 6px; }
.pc-stat span { font-size: 12px; color: var(--ds-text-3); }
.pc-stat b { font-size: 22px; }
.pc-brand { color: var(--ds-brand); }
.pc-danger { color: var(--ds-danger); }
.pc-tabs { display: flex; gap: 8px; }
.pc-tab { border: 1px solid var(--ds-border); background: var(--ds-bg-elevated); border-radius: 6px; padding: 7px 14px; font-size: 13px; cursor: pointer; }
.pc-tab.on { background: var(--ds-brand); color: #fff; border-color: var(--ds-brand); }
.pc-body { padding: 16px; display: flex; flex-direction: column; gap: 10px; }
.pc-alert-hint { font-size: 12px; color: var(--ds-text-3); }
.pc-table { width: 100%; border-collapse: collapse; font-size: 13px; }
.pc-table th, .pc-table td { padding: 9px 10px; border-bottom: 1px solid var(--ds-divider); text-align: left; }
.pc-table th { background: var(--ds-bg-soft); color: var(--ds-text-3); }
.pc-empty { padding: 24px; text-align: center; color: var(--ds-text-3); }
.pc-form { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
.pc-form label { display: flex; flex-direction: column; gap: 5px; font-size: 12px; }
.pc-foot { display: flex; justify-content: flex-end; gap: 8px; }
@media (max-width: 1024px) { .pc-stats { grid-template-columns: repeat(2, 1fr); } }
</style>
