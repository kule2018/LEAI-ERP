<template><PurchaseEntityPage :config="config" /></template>
<script setup lang="ts">
import PurchaseEntityPage from './PurchaseEntityPage.vue';
import { purchaseConfigFor } from './purchaseConfigs';
const config = purchaseConfigFor('suppliers');
</script>
