<template><RecordPage :config="page" /></template>

<script setup lang="ts">
import RecordPage from '../records/RecordPage.vue';
import type { RecordPageConfig } from '../records/records';

const page: RecordPageConfig = {
  title: '采购明细',
  resource: 'purchase/details',
  endpoint: '/api/v1/order-reports/purchase-details',
  schema: 'purchaseDetails',
  filters: ['orderNo', 'supplierName', 'productName'],
  reportSource: '采购订单行与收货数量',
  metrics: ['qty', 'receivedQty', 'amount'],
};
</script>
