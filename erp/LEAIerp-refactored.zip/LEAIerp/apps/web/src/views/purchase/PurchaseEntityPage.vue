<template><SalesEntityPage :config="config" /></template>
<script setup lang="ts">
import SalesEntityPage from '../sales/SalesEntityPage.vue';
import type { SalesConfig } from '../sales/salesConfigs';
defineProps<{ config: SalesConfig }>();
</script>
