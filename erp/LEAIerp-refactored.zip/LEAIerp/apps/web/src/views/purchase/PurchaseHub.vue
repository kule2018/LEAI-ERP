<!-- 采购供应中心：采购订单 / 供应商 / 询比价 / 收货入库 / 对账付款 / 价目 / 供应分析 七大深度业务入口 -->
<template>
  <div class="ph-page">
    <div class="ph-tabs">
      <button v-for="t in tabs" :key="t.key" class="ph-tab" :class="{ on: active === t.key }" @click="switchTab(t.key)">
        <span class="ph-tab__icon"><IconFont :name="t.icon" :size="16" /></span>{{ t.label }}
      </button>
    </div>
    <div class="ph-desc">{{ currentDesc }}</div>

    <PurchaseOrders v-if="active === 'orders'" />
    <SupplierCenter v-if="active === 'supplier'" />
    <QuotationCenter v-if="active === 'quotation'" />
    <ReceivingCenter v-if="active === 'receiving'" />
    <SettlementCenter v-if="active === 'settlement'" />
    <PriceCenter v-if="active === 'price'" />
    <SupplierAnalytics v-if="active === 'analytics'" />
  </div>
</template>

<script setup lang="ts">
/** 采购供应中心：按业务域聚合七个深度组件，通过路由 query.tab 定位，覆盖采购供应全部菜单。 */
import { computed, ref, watch } from 'vue';
import { useRoute, useRouter } from 'vue-router';
import PurchaseOrders from './PurchaseOrders.vue';
import SupplierCenter from './SupplierCenter.vue';
import QuotationCenter from './QuotationCenter.vue';
import ReceivingCenter from './ReceivingCenter.vue';
import SettlementCenter from './SettlementCenter.vue';
import PriceCenter from './PriceCenter.vue';
import SupplierAnalytics from './SupplierAnalytics.vue';

const route = useRoute();
const router = useRouter();
const tabs = [
  { key: 'orders', label: '采购订单', icon: 'List', desc: '需求→订单→审批→收货→质检→入库→应付→付款→退货 全生命周期闭环。' },
  { key: 'supplier', label: '供应商', icon: 'Box', desc: '供应商主数据、分组、资质账期、四维供货评估评分卡与黑名单管控。' },
  { key: 'quotation', label: '询比价', icon: 'File', desc: '发起询价→多供应商报价→价格/交期/账期加权比价→定标转采购单。' },
  { key: 'receiving', label: '收货入库', icon: 'Inbox', desc: '到货登记→质检判定→上架入库→批次成本确认与库存联动。' },
  { key: 'settlement', label: '对账付款', icon: 'File', desc: '应付台账→供应商对账→付款核销→会计凭证，采购资金全链路。' },
  { key: 'price', label: '采购价目', icon: 'Tag', desc: '协议价目、历史采购价趋势与价格异常预警，支撑降本议价。' },
  { key: 'analytics', label: '供应分析', icon: 'ChartBar', desc: '到货及时率、供应商供货排行与采购 ABC 分类绩效管理。' },
];
/** 菜单项到 tab 的映射：订单/收货/退货/需求/入库等归到对应深度页 */
const PATH_TAB: Record<string, string> = {
  'purchase/orders': 'orders', 'purchase/requirements': 'orders', 'purchase/returns': 'orders',
  'purchase/receipts': 'receiving', 'purchase/ins': 'receiving',
  'purchase/suppliers': 'supplier', 'purchase/supplier-groups': 'supplier', 'purchase/supplier-evaluates': 'supplier',
  'purchase/quotations': 'quotation', 'purchase/contracts': 'quotation',
  'purchase/statements': 'settlement', 'purchase/logistics': 'settlement', 'purchase/outsource': 'settlement',
  'purchase/prices': 'price', 'purchase/on-time': 'analytics',
};
function inferTab(): string {
  const q = String(route.query.tab || '');
  if (q && tabs.some((t) => t.key === q)) return q;
  return PATH_TAB[route.path.replace(/^\//, '')] || 'orders';
}
const active = ref(inferTab());
watch(() => route.query.tab, () => { active.value = inferTab(); });
watch(() => route.path, () => { active.value = inferTab(); });
const currentDesc = computed(() => tabs.find((t) => t.key === active.value)?.desc || '');
function switchTab(key: string): void {
  active.value = key;
  router.replace({ path: route.path, query: { ...route.query, tab: key } });
}
</script>

<style scoped>
.ph-page { padding: 16px; }
.ph-tabs { display: flex; gap: 8px; margin-bottom: 10px; flex-wrap: wrap; }
.ph-tab { display: flex; align-items: center; gap: 6px; border: 1px solid var(--ds-border); background: var(--ds-bg-elevated); border-radius: 999px; padding: 7px 14px; font-size: 13px; cursor: pointer; color: var(--ds-text); }
.ph-tab:hover { border-color: var(--ds-brand); }
.ph-tab.on { background: var(--ds-brand); color: #fff; border-color: var(--ds-brand); }
.ph-tab__icon { font-size: 14px; }
.ph-desc { font-size: 12px; color: var(--ds-text-3); margin-bottom: 12px; }
</style>
