<template><RecordPage :config="page" /></template>

<script setup lang="ts">
import RecordPage from '../records/RecordPage.vue';
import type { RecordPageConfig } from '../records/records';

const page: RecordPageConfig = {
  title: '采购批量导入',
  resource: 'purchase/imports',
  schema: 'purchaseImports',
  filters: ['batchNo', 'status'],
  reportSource: '采购订单批量录入结果',
  metrics: ['successRows', 'failRows'],
  link: { to: '/purchase/orders/import', label: '导入采购订单' },
};
</script>
