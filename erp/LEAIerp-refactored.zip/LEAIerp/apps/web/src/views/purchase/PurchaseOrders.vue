<!-- 采购订单中心：需求→订单→审批→收货→质检→入库→应付→付款→退货 全生命周期闭环 -->
<template>
  <div class="po-page">
    <div class="po-stats">
      <div v-for="c in stats" :key="c.label" class="po-stat"><span>{{ c.label }}</span><b :class="c.tone">{{ c.value }}</b></div>
    </div>

    <DsCard title="采购订单" :pad="false">
      <template #extra>
        <div class="po-tools">
          <input v-model="keyword" class="ds-input" placeholder="单号/供应商搜索" />
          <select v-model="statusFilter" class="ds-input"><option value="">全部状态</option><option v-for="s in STATUS_LABELS" :key="s.k" :value="s.k">{{ s.label }}</option></select>
          <DsButton size="sm" variant="primary" @click="openNew">新建采购单</DsButton>
        </div>
      </template>
      <div class="po-body">
        <table class="po-table">
          <thead><tr><th>采购单号</th><th>供应商</th><th>仓库</th><th>金额</th><th>已收/数量</th><th>状态</th><th>付款</th><th>操作</th></tr></thead>
          <tbody>
            <tr v-for="o in filteredOrders" :key="o.id">
              <td>{{ o.orderNo }}</td><td>{{ o.supplierName }}</td><td>{{ o.warehouseName }}</td>
              <td>¥{{ Number(o.totalAmount || 0).toFixed(2) }}</td>
              <td>{{ Number(o.receivedQty || 0) }} / {{ totalQty(o) }}</td>
              <td><DsTag :color="statusColor(o)" size="sm">{{ statusText(o) }}</DsTag></td>
              <td><DsTag :color="Number(o.paidAmount||0) >= Number(o.totalAmount||0) && o.totalAmount ? 'success' : 'warning'" size="sm">{{ payText(o) }}</DsTag></td>
              <td class="po-ops">
                <DsButton v-if="stage(o)===0" size="sm" @click="act(o,'submit')">提交</DsButton>
                <DsButton v-if="stage(o)===1" size="sm" variant="primary" @click="act(o,'approve')">审批</DsButton>
                <DsButton v-if="stage(o)===1" size="sm" @click="act(o,'reject')">驳回</DsButton>
                <DsButton v-if="stage(o)===2 || stage(o)===3" size="sm" variant="primary" @click="openReceive(o)">收货质检</DsButton>
                <DsButton v-if="stage(o)===4" size="sm" @click="openPay(o)">付款</DsButton>
                <DsButton v-if="stage(o)>=3" size="sm" @click="openReturn(o)">退货</DsButton>
                <DsButton size="sm" @click="viewDetail(o)">详情</DsButton>
              </td>
            </tr>
            <tr v-if="!filteredOrders.length"><td colspan="8" class="po-empty">暂无采购单，点击「新建采购单」开始</td></tr>
          </tbody>
        </table>
      </div>
    </DsCard>

    <!-- 新建采购单 -->
    <DsModal v-model="newVisible" title="新建采购单" :width="760">
      <div class="po-form">
        <div class="po-form__head">
          <label><span>供应商</span><select v-model="form.supplierId" class="ds-input"><option v-for="s in suppliers" :key="s.id" :value="s.id">{{ s.name }}</option></select></label>
          <label><span>收货仓库</span><select v-model="form.warehouseId" class="ds-input"><option v-for="w in warehouses" :key="w.id" :value="w.id">{{ w.name }}</option></select></label>
          <label><span>账期(天)</span><input v-model.number="form.payDays" class="ds-input" type="number" /></label>
          <label><span>采购员</span><input v-model="form.buyer" class="ds-input" /></label>
        </div>
        <div class="po-lines">
          <div class="po-line po-line--head"><span>产品</span><span>数量</span><span>单价</span><span>金额</span><span></span></div>
          <div v-for="(l, i) in form.lines" :key="i" class="po-line">
            <select v-model="l.productId" class="ds-input" @change="calcLine(l)"><option v-for="p in products" :key="p.id" :value="p.id">{{ p.name }}</option></select>
            <input v-model.number="l.qty" class="ds-input" type="number" @input="calcLine(l)" />
            <input v-model.number="l.unitPrice" class="ds-input" type="number" @input="calcLine(l)" />
            <span>¥{{ Number(l.amount||0).toFixed(2) }}</span>
            <button class="po-del" @click="form.lines.splice(i,1)">✕</button>
          </div>
        </div>
        <DsButton size="sm" @click="form.lines.push(blankLine())">+ 添加明细行</DsButton>
        <div class="po-total">采购总额：<b>¥{{ formTotal.toFixed(2) }}</b></div>
      </div>
      <template #footer><div class="po-foot"><DsButton @click="newVisible=false">取消</DsButton><DsButton variant="primary" @click="saveOrder">保存草稿</DsButton></div></template>
    </DsModal>

    <!-- 收货质检 -->
    <DsModal v-model="receiveVisible" title="收货与质检" :width="720">
      <div v-if="current" class="po-receive">
        <div class="po-receive__hint">{{ current.orderNo }} · 合格品入库并增加库存，拒收品冲回供应商；可部分收货。</div>
        <div v-for="(l,i) in receiveLines" :key="i" class="po-recv-line">
          <b>{{ l.productName }}</b>
          <label>订单量 <span>{{ l.qty }}</span></label>
          <label>已收 <span>{{ l.received }}</span></label>
          <label>本次实收 <input v-model.number="l.actual" class="ds-input" type="number" /></label>
          <label>质检 <select v-model="l.qc" class="ds-input"><option>合格</option><option>拒收</option><option>让步接收</option></select></label>
          <label>批号 <input v-model="l.batchNo" class="ds-input" /></label>
        </div>
      </div>
      <template #footer><div class="po-foot"><DsButton @click="receiveVisible=false">取消</DsButton><DsButton variant="primary" @click="confirmReceive">确认收货入库</DsButton></div></template>
    </DsModal>

    <!-- 付款 -->
    <DsModal v-model="payVisible" title="采购付款" :width="440">
      <div v-if="current" class="po-pay">
        <div class="po-pay__row"><span>应付金额</span><b>¥{{ payAmount.toFixed(2) }}</b></div>
        <label class="po-pay__row"><span>本次付款</span><input v-model.number="payValue" class="ds-input" type="number" /></label>
        <label class="po-pay__row"><span>支付方式</span><select v-model="payMethod" class="ds-input"><option>银行转账</option><option>现金</option><option>承兑汇票</option></select></label>
      </div>
      <template #footer><div class="po-foot"><DsButton @click="payVisible=false">取消</DsButton><DsButton variant="primary" @click="confirmPay">确认付款</DsButton></div></template>
    </DsModal>

    <!-- 退货 -->
    <DsModal v-model="returnVisible" title="采购退货" :width="460">
      <div v-if="current" class="po-pay">
        <div class="po-pay__hint">退货将冲减库存与应付，生成红字记录（不物理删除原单）。</div>
        <label class="po-pay__row"><span>退货产品</span><select v-model="returnLineId" class="ds-input"><option v-for="l in current.lines" :key="l.id" :value="l.id">{{ l.productName }}</option></select></label>
        <label class="po-pay__row"><span>退货数量</span><input v-model.number="returnQty" class="ds-input" type="number" /></label>
        <label class="po-pay__row"><span>退货原因</span><input v-model="returnReason" class="ds-input" /></label>
      </div>
      <template #footer><div class="po-foot"><DsButton @click="returnVisible=false">取消</DsButton><DsButton variant="primary" @click="confirmReturn">确认退货</DsButton></div></template>
    </DsModal>

    <!-- 详情 -->
    <DsModal v-model="detailVisible" title="采购单详情" :width="640">
      <div v-if="current" class="po-detail">
        <div class="po-detail__meta"><span>{{ current.orderNo }}</span><span>{{ current.supplierName }}</span><span>{{ current.warehouseName }}</span><span>{{ statusText(current) }}</span></div>
        <table class="po-table"><thead><tr><th>产品</th><th>订购</th><th>已收</th><th>单价</th><th>金额</th><th>质检</th></tr></thead>
          <tbody><tr v-for="l in current.lines" :key="l.id"><td>{{ l.productName }}</td><td>{{ l.qty }}</td><td>{{ l.received||0 }}</td><td>¥{{ Number(l.unitPrice).toFixed(2) }}</td><td>¥{{ Number(l.amount).toFixed(2) }}</td><td>{{ l.qc||'—' }}</td></tr></tbody>
        </table>
        <div class="po-detail__foot">总额 ¥{{ Number(current.totalAmount).toFixed(2) }} · 已付 ¥{{ Number(current.paidAmount||0).toFixed(2) }} · 账期 {{ current.payDays||0 }} 天</div>
      </div>
    </DsModal>
  </div>
</template>

<script setup lang="ts">
/** 采购订单全生命周期：草稿→待审→确认→收货→质检入库→应付→付款→退货，联动库存与事件。 */
import { computed, onMounted, reactive, ref } from 'vue';
import { DsButton, DsCard, DsModal, DsTag } from '../../components';
import { mockGet, mockPost } from '../../api/mockAdapter';
import { emit, Events } from '../../utils/eventBus';
import { useToast } from '../../components/ds/toast';

type Stage = 0 | 1 | 2 | 3 | 4 | 9;
interface POLine { id: number; productId: number; productName: string; qty: number; received: number; unitPrice: number; amount: number; qc?: string; batchNo?: string; }
interface PO { id: number; orderNo: string; supplierId: number; supplierName: string; warehouseId: number; warehouseName: string; payDays: number; buyer: string; totalAmount: number; paidAmount: number; receivedQty: number; status: string; createdAt: string; lines: POLine[]; }

const toast = useToast();
const KEY = '/api/v1/industry/purchaseOrders';
const STATUS_LABELS = [{ k: '草稿', label: '草稿' }, { k: '待审', label: '待审' }, { k: '已确认', label: '已确认' }, { k: '部分收货', label: '部分收货' }, { k: '已入库', label: '已入库' }, { k: '已作废', label: '已作废' }];
const orders = ref<PO[]>([]);
const suppliers = ref<any[]>([]);
const warehouses = ref<any[]>([]);
const products = ref<any[]>([]);
const keyword = ref('');
const statusFilter = ref('');
const current = ref<PO | null>(null);
const newVisible = ref(false);
const receiveVisible = ref(false);
const payVisible = ref(false);
const returnVisible = ref(false);
const detailVisible = ref(false);
const form = reactive<any>({ supplierId: null, warehouseId: null, payDays: 30, buyer: '', lines: [] as any[] });
const receiveLines = ref<any[]>([]);
const payValue = ref(0);
const payMethod = ref('银行转账');
const returnLineId = ref<number | null>(null);
const returnQty = ref(0);
const returnReason = ref('');

function blankLine(): any { return { productId: null, qty: 1, unitPrice: 0, amount: 0 }; }
function calcLine(l: any): void { l.amount = Number((Number(l.qty || 0) * Number(l.unitPrice || 0)).toFixed(2)); }
const formTotal = computed(() => form.lines.reduce((s: number, l: any) => s + Number(l.amount || 0), 0));

/** 状态归一化，兼容中文状态值 */
function stage(o: PO): Stage {
  const s = o.status;
  if (s === '已作废') return 9;
  if (s === '已入库') return 4;
  if (s === '部分收货') return 3;
  if (s === '已确认') return 2;
  if (s === '待审') return 1;
  return 0;
}
function statusText(o: PO): string { return o.status || '草稿'; }
function statusColor(o: PO): any { return ({ '草稿': 'neutral', '待审': 'warning', '已确认': 'brand', '部分收货': 'brand', '已入库': 'success', '已作废': 'danger' } as any)[o.status] || 'neutral'; }
function payText(o: PO): string { const paid = Number(o.paidAmount || 0), total = Number(o.totalAmount || 0); return paid >= total && total ? '已付清' : paid > 0 ? `已付¥${paid.toFixed(0)}` : '未付款'; }
function totalQty(o: PO): number { return (o.lines || []).reduce((s, l) => s + Number(l.qty), 0); }
const filteredOrders = computed(() => {
  const kw = keyword.value.trim().toLowerCase();
  return [...orders.value].reverse().filter((o) => (!kw || o.orderNo.toLowerCase().includes(kw) || o.supplierName.includes(kw)) && (!statusFilter.value || o.status === statusFilter.value));
});
const stats = computed(() => {
  const valid = orders.value.filter((o) => o.status !== '已作废');
  return [
    { label: '采购总额', value: `¥${valid.reduce((s, o) => s + Number(o.totalAmount || 0), 0).toFixed(0)}`, tone: 'po-brand' },
    { label: '待审批', value: String(valid.filter((o) => o.status === '待审').length), tone: 'po-warn' },
    { label: '待收货', value: String(valid.filter((o) => ['已确认', '部分收货'].includes(o.status)).length), tone: '' },
    { label: '待付款', value: `¥${valid.reduce((s, o) => s + Math.max(0, Number(o.totalAmount || 0) - Number(o.paidAmount || 0)), 0).toFixed(0)}`, tone: '' },
  ];
});
const payAmount = computed(() => current.value ? Math.max(0, Number(current.value.totalAmount) - Number(current.value.paidAmount || 0)) : 0);

async function load(): Promise<void> {
  const list = async (u: string) => { const r: any = await mockGet(u, { pageSize: 300 }); return Array.isArray(r) ? r : r?.list || []; };
  orders.value = await list(KEY);
  suppliers.value = await list('/api/v1/industry/suppliers');
  warehouses.value = await mockGet('/api/v1/inventory/warehouses', {});
  products.value = (await list('/api/v1/inventory/products'));
}
function openNew(): void {
  form.supplierId = suppliers.value[0]?.id || null;
  form.warehouseId = (warehouses.value as any)[0]?.id || 1;
  form.payDays = 30; form.buyer = '采购员';
  form.lines = [blankLine()];
  newVisible.value = true;
}
/** 保存草稿：校验明细，补齐供应商/仓库名称，生成单号 */
async function saveOrder(): Promise<void> {
  const lines = form.lines.filter((l: any) => l.productId);
  if (!lines.length) { toast.warning('请至少录入一行有效明细'); return; }
  if (!form.supplierId) { toast.warning('请选择供应商'); return; }
  const no = `PO${new Date().toISOString().slice(0, 10).replace(/-/g, '')}-${String(orders.value.length + 1).padStart(4, '0')}`;
  const detail: POLine[] = lines.map((l: any, i: number) => ({ id: Date.now() + i, productId: Number(l.productId), productName: products.value.find((p) => p.id === l.productId)?.name || `产品${l.productId}`, qty: Number(l.qty), received: 0, unitPrice: Number(l.unitPrice), amount: Number(l.amount) }));
  const po: PO = { id: Date.now(), orderNo: no, supplierId: Number(form.supplierId), supplierName: suppliers.value.find((s) => s.id === form.supplierId)?.name || '', warehouseId: Number(form.warehouseId), warehouseName: (warehouses.value as any).find((w: any) => w.id === form.warehouseId)?.name || '', payDays: Number(form.payDays), buyer: form.buyer, totalAmount: Number(formTotal.value.toFixed(2)), paidAmount: 0, receivedQty: 0, status: '草稿', createdAt: new Date().toLocaleString('zh-CN'), lines: detail };
  const saved: any = await mockPost(KEY, po);
  orders.value.push({ ...po, id: saved?.id || po.id });
  newVisible.value = false; toast.success(`采购单 ${no} 已保存`);
}
/** 状态流转：提交/审批/驳回。审批通过后进入可收货状态 */
async function act(o: PO, action: string): Promise<void> {
  if (action === 'submit') o.status = '待审';
  else if (action === 'approve') { o.status = '已确认'; emit(Events.APPROVAL_DONE, { type: 'PURCHASE_ORDER', id: o.id, action }); }
  else if (action === 'reject') o.status = '草稿';
  await mockPost(KEY, { ...o });
  toast.success(action === 'approve' ? '审批通过，可安排收货' : action === 'reject' ? '已驳回至草稿' : '已提交审批');
}
function openReceive(o: PO): void {
  current.value = o;
  receiveLines.value = o.lines.map((l) => ({ id: l.id, productId: l.productId, productName: l.productName, qty: l.qty, received: l.received || 0, actual: Math.max(0, l.qty - (l.received || 0)), qc: '合格', batchNo: '' }));
  receiveVisible.value = true;
}
/** 收货入库：合格/让步品累加已收数量并写库存流水；拒收品不入库。全部收满→已入库 */
async function confirmReceive(): Promise<void> {
  if (!current.value) return;
  let anyIn = false;
  let receivedAmount = 0;
  for (const r of receiveLines.value) {
    const actual = Math.max(0, Number(r.actual || 0));
    if (!actual) continue;
    const line = current.value.lines.find((l) => l.id === r.id);
    if (!line) continue;
    if (r.qc !== '拒收') {
      line.received = Number(line.received || 0) + actual;
      line.qc = r.qc; line.batchNo = r.batchNo;
      anyIn = true;
      receivedAmount += actual * Number(line.unitPrice || 0);
      // 真正过账库存：调用通用过账接口更新 balance 并写收发存流水
      await mockPost('/api/v1/industry/stock-post', { productId: r.productId, warehouseId: current.value.warehouseId, voucherType: 'PURCHASE_IN', qty: actual, cost: Number(line.unitPrice || 0), voucherId: current.value.id });
      await mockPost('/api/v1/industry/purchaseReceipts', { poId: current.value.id, orderNo: current.value.orderNo, productId: r.productId, productName: r.productName, qty: actual, qc: r.qc, batchNo: r.batchNo, warehouseId: current.value.warehouseId, createdAt: new Date().toLocaleString('zh-CN') });
      emit(Events.STOCK_CHANGED, { type: 'PURCHASE_IN', productId: r.productId, qty: actual });
    } else {
      await mockPost('/api/v1/industry/purchaseRejects', { poId: current.value.id, productId: r.productId, productName: r.productName, qty: actual, reason: '质检拒收', createdAt: new Date().toLocaleString('zh-CN') });
    }
  }
  if (!anyIn) { toast.warning('没有合格品可入库'); return; }
  current.value.receivedQty = current.value.lines.reduce((s, l) => s + Number(l.received || 0), 0);
  const allReceived = current.value.lines.every((l) => Number(l.received || 0) >= Number(l.qty));
  current.value.status = allReceived ? '已入库' : '部分收货';
  await mockPost('/api/v1/industry/payables', { poId: current.value.id, orderNo: current.value.orderNo, supplierId: current.value.supplierId, supplierName: current.value.supplierName, amount: Number(receivedAmount.toFixed(2)), paidAmount: 0, createdAt: new Date().toLocaleString('zh-CN') });
  await mockPost(KEY, { ...current.value });
  receiveVisible.value = false; toast.success(allReceived ? '全部收货完成，已生成应付账款' : '部分收货已入库');
}
function openPay(o: PO): void { current.value = o; payValue.value = payAmount.value; payVisible.value = true; }
/** 付款：累计已付金额，付清后生成凭证事件 */
async function confirmPay(): Promise<void> {
  if (!current.value) return;
  const v = Number(payValue.value || 0);
  if (v <= 0 || v > payAmount.value) { toast.warning('付款金额需在 0 与应付余额之间'); return; }
  current.value.paidAmount = Number(current.value.paidAmount || 0) + v;
  await mockPost('/api/v1/industry/purchasePayments', { poId: current.value.id, orderNo: current.value.orderNo, amount: v, method: payMethod.value, createdAt: new Date().toLocaleString('zh-CN') });
  await mockPost(KEY, { ...current.value });
  emit(Events.ORDER_CONFIRMED, { type: 'PURCHASE_PAY', total: v, orderNo: current.value.orderNo });
  payVisible.value = false; toast.success(`已付款 ¥${v.toFixed(2)}`);
}
function openReturn(o: PO): void { current.value = o; returnLineId.value = o.lines[0]?.id || null; returnQty.value = 1; returnReason.value = ''; returnVisible.value = true; }
/** 退货：冲减对应明细已收数量，生成红字退货单 */
async function confirmReturn(): Promise<void> {
  if (!current.value || !returnLineId.value) { toast.warning('请选择退货产品'); return; }
  const line = current.value.lines.find((l) => l.id === returnLineId.value);
  if (!line || Number(returnQty.value) <= 0 || Number(returnQty.value) > Number(line.received || 0)) { toast.warning('退货数量不能超过已收数量'); return; }
  line.received = Number(line.received) - Number(returnQty.value);
  // 退货真正冲减库存
  await mockPost('/api/v1/industry/stock-post', { productId: line.productId, warehouseId: current.value.warehouseId, voucherType: 'PURCHASE_RETURN', qty: -Number(returnQty.value), cost: Number(line.unitPrice || 0), voucherId: current.value.id });
  await mockPost('/api/v1/industry/purchaseReturns', { poId: current.value.id, orderNo: current.value.orderNo, productId: line.productId, productName: line.productName, qty: Number(returnQty.value), reason: returnReason.value, amount: Number((returnQty.value * line.unitPrice).toFixed(2)), createdAt: new Date().toLocaleString('zh-CN') });
  await mockPost('/api/v1/industry/payables', { poId: current.value.id, orderNo: current.value.orderNo, supplierId: current.value.supplierId, supplierName: current.value.supplierName, amount: -Number((returnQty.value * line.unitPrice).toFixed(2)), paidAmount: 0, createdAt: new Date().toLocaleString('zh-CN'), type: '退货冲减' });
  await mockPost(KEY, { ...current.value });
  emit(Events.STOCK_CHANGED, { type: 'PURCHASE_RETURN', productId: line.productId, qty: -Number(returnQty.value) });
  returnVisible.value = false; toast.success('采购退货已登记，库存与应付已冲减');
}
function viewDetail(o: PO): void { current.value = o; detailVisible.value = true; }
onMounted(load);
</script>

<style scoped>
.po-page { display: flex; flex-direction: column; gap: 14px; padding: 16px; }
.po-stats { display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px; }
.po-stat { border: 1px solid var(--ds-border); border-radius: 10px; padding: 14px 16px; background: var(--ds-bg-elevated); display: flex; flex-direction: column; gap: 6px; }
.po-stat span { font-size: 12px; color: var(--ds-text-3); }
.po-stat b { font-size: 22px; }
.po-brand { color: var(--ds-brand); }
.po-warn { color: var(--ds-warning); }
.po-tools { display: flex; gap: 8px; }
.po-body { padding: 16px; }
.po-table { width: 100%; border-collapse: collapse; font-size: 13px; }
.po-table th, .po-table td { padding: 9px 10px; border-bottom: 1px solid var(--ds-divider); text-align: left; }
.po-table th { background: var(--ds-bg-soft); color: var(--ds-text-3); }
.po-ops { display: flex; gap: 5px; flex-wrap: wrap; }
.po-empty { padding: 24px; text-align: center; color: var(--ds-text-3); }
.po-form { display: flex; flex-direction: column; gap: 12px; }
.po-form__head { display: grid; grid-template-columns: 2fr 1.2fr 0.8fr 1fr; gap: 10px; }
.po-form__head label, .po-pay__row { display: flex; flex-direction: column; gap: 5px; font-size: 12px; }
.po-lines { border: 1px solid var(--ds-border); border-radius: 8px; padding: 8px; display: flex; flex-direction: column; gap: 6px; }
.po-line { display: grid; grid-template-columns: 2fr 0.7fr 0.8fr 0.9fr 30px; gap: 8px; align-items: center; }
.po-line--head { font-size: 12px; color: var(--ds-text-3); }
.po-del { border: 0; background: transparent; color: var(--ds-danger); cursor: pointer; }
.po-total { text-align: right; font-size: 15px; }
.po-total b { color: var(--ds-brand); }
.po-foot { display: flex; justify-content: flex-end; gap: 8px; }
.po-receive { display: flex; flex-direction: column; gap: 10px; }
.po-receive__hint, .po-pay__hint { font-size: 12px; color: var(--ds-text-3); }
.po-recv-line { display: grid; grid-template-columns: 1.4fr repeat(5, 1fr); gap: 8px; align-items: end; border-bottom: 1px solid var(--ds-divider); padding-bottom: 8px; font-size: 12px; }
.po-recv-line label { display: flex; flex-direction: column; gap: 4px; }
.po-recv-line label span { font-weight: 700; }
.po-pay { display: flex; flex-direction: column; gap: 10px; }
.po-pay__row { flex-direction: row; align-items: center; justify-content: space-between; }
.po-pay__row .ds-input { width: 160px; }
.po-detail { display: flex; flex-direction: column; gap: 12px; }
.po-detail__meta { display: flex; gap: 16px; font-size: 13px; color: var(--ds-text-3); }
.po-detail__foot { text-align: right; font-size: 13px; }
@media (max-width: 1024px) { .po-stats { grid-template-columns: repeat(2, 1fr); } .po-form__head { grid-template-columns: 1fr 1fr; } }
</style>
