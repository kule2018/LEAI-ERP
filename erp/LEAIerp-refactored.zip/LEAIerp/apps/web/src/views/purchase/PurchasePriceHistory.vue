<template><RecordPage :config="page" /></template>

<script setup lang="ts">
import RecordPage from '../records/RecordPage.vue';
import type { RecordPageConfig } from '../records/records';

const page: RecordPageConfig = {
  title: '历史采购价',
  resource: 'purchase/price-history',
  endpoint: '/api/v1/order-reports/purchase-prices',
  schema: 'purchasePriceHistory',
  filters: ['supplierName', 'productName', 'purchaseDate'],
  reportSource: '按供应商和商品比较历史采购单价',
};
</script>
