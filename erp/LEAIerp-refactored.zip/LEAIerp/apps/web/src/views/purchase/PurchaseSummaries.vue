<template><RecordPage :config="page" /></template>

<script setup lang="ts">
import RecordPage from '../records/RecordPage.vue';
import type { RecordPageConfig } from '../records/records';

const page: RecordPageConfig = {
  title: '采购汇总',
  resource: 'purchase/summaries',
  endpoint: '/api/v1/order-reports/purchase-summary',
  schema: 'purchaseSummaries',
  filters: ['period', 'supplierName'],
  reportSource: '按期间和供应商查询采购汇总',
  metrics: ['orderCount', 'totalAmount', 'receivedAmount'],
};
</script>
