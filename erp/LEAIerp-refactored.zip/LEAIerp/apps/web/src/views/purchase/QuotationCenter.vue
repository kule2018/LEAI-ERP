<!-- 询比价中心：询价单→多供应商报价→比价矩阵(价格/交期/账期)→定标→生成采购订单草稿 -->
<template>
  <div class="qc-page">
    <div class="qc-stats">
      <div v-for="c in stats" :key="c.label" class="qc-stat"><span>{{ c.label }}</span><b :class="c.tone">{{ c.value }}</b></div>
    </div>

    <DsCard title="询价单" :pad="false">
      <template #extra><DsButton size="sm" variant="primary" @click="inquiryVisible = true">发起询价</DsButton></template>
      <div class="qc-body">
        <table class="qc-table">
          <thead><tr><th>询价单号</th><th>物料</th><th>数量</th><th>报价数</th><th>截止日期</th><th>状态</th><th>操作</th></tr></thead>
          <tbody>
            <tr v-for="q in inquiries" :key="q.id">
              <td>{{ q.no }}</td><td>{{ q.material }}</td><td>{{ q.qty }}</td><td>{{ quotes(q.id).length }}</td>
              <td>{{ q.deadline }}</td>
              <td><DsTag :color="q.status === '已定标' ? 'success' : q.status === '比价中' ? 'warning' : 'neutral'" size="sm">{{ q.status }}</DsTag></td>
              <td class="qc-ops">
                <DsButton size="sm" @click="openQuote(q)">录入报价</DsButton>
                <DsButton size="sm" variant="primary" @click="openCompare(q)">比价定标</DsButton>
              </td>
            </tr>
            <tr v-if="!inquiries.length"><td colspan="7" class="qc-empty">暂无询价单</td></tr>
          </tbody>
        </table>
      </div>
    </DsCard>

    <!-- 发起询价 -->
    <DsModal v-model="inquiryVisible" title="发起询价" :width="460">
      <div class="qc-form">
        <label><span>询价物料</span><input v-model="inquiryForm.material" class="ds-input" /></label>
        <label><span>需求数量</span><input v-model.number="inquiryForm.qty" class="ds-input" type="number" /></label>
        <label><span>截止日期</span><DsDatePicker v-model="inquiryForm.deadline" /></label>
        <label><span>邀请供应商</span><select v-model="inquiryForm.supplierIds" class="ds-input" multiple style="height:80px"><option v-for="s in suppliers" :key="s.id" :value="s.id">{{ s.name }}</option></select></label>
      </div>
      <template #footer><div class="qc-foot"><DsButton @click="inquiryVisible=false">取消</DsButton><DsButton variant="primary" @click="saveInquiry">发起</DsButton></div></template>
    </DsModal>

    <!-- 录入报价 -->
    <DsModal v-model="quoteVisible" title="供应商报价" :width="520">
      <div v-if="current" class="qc-quote">
        <div class="qc-quote__hint">{{ current.no }} · {{ current.material }} × {{ current.qty }}</div>
        <div v-for="s in suppliers" :key="s.id" class="qc-quote-row">
          <b>{{ s.name }}</b>
          <label>单价 <input v-model.number="quoteDraft[s.id].price" class="ds-input" type="number" /></label>
          <label>交期(天) <input v-model.number="quoteDraft[s.id].leadDays" class="ds-input" type="number" /></label>
          <label>账期(天) <input v-model.number="quoteDraft[s.id].payDays" class="ds-input" type="number" /></label>
          <DsButton size="sm" @click="submitQuote(s)">报价</DsButton>
        </div>
      </div>
    </DsModal>

    <!-- 比价定标 -->
    <DsModal v-model="compareVisible" title="比价矩阵与定标" :width="700">
      <div v-if="current" class="qc-compare">
        <div class="qc-compare__hint">综合评分 = 价格分(最低价最优40%) + 交期分(30%) + 账期分(30%)。系统标出推荐中标方，可人工选定。</div>
        <table class="qc-table">
          <thead><tr><th>供应商</th><th>报价单价</th><th>总价</th><th>交期</th><th>账期</th><th>综合分</th><th>操作</th></tr></thead>
          <tbody>
            <tr v-for="r in ranked" :key="r.supplierId" :class="{ qcBest: r.supplierId === recommended?.supplierId }">
              <td>{{ r.supplierName }}</td><td>¥{{ r.price.toFixed(2) }}</td><td>¥{{ r.total.toFixed(2) }}</td>
              <td>{{ r.leadDays }}天</td><td>{{ r.payDays }}天</td><td><b>{{ r.score.toFixed(1) }}</b></td>
              <td><DsButton v-if="current.status !== '已定标'" size="sm" variant="primary" @click="award(r)">定标</DsButton><DsTag v-else-if="r.won" color="success" size="sm">中标</DsTag></td>
            </tr>
            <tr v-if="!ranked.length"><td colspan="7" class="qc-empty">暂无报价，请先录入</td></tr>
          </tbody>
        </table>
      </div>
    </DsModal>
  </div>
</template>

<script setup lang="ts">
/** 询比价：多家供应商报价→按价格/交期/账期加权评分排序→定标并生成采购订单草稿。 */
import { computed, onMounted, reactive, ref } from 'vue';
import { DsButton, DsCard, DsModal, DsTag } from '../../components';
import { mockGet, mockPost } from '../../api/mockAdapter';
import { emit, Events } from '../../utils/eventBus';
import { useToast } from '../../components/ds/toast';

interface Inquiry { id: number; no: string; material: string; qty: number; deadline: string; status: string; supplierIds: number[]; }
interface Quote { id: number; inquiryId: number; supplierId: number; supplierName: string; price: number; leadDays: number; payDays: number; }

const toast = useToast();
const IKEY = '/api/v1/industry/inquiries';
const QKEY = '/api/v1/industry/quotes';
const inquiries = ref<Inquiry[]>([]);
const allQuotes = ref<Quote[]>([]);
const suppliers = ref<any[]>([]);
const inquiryVisible = ref(false);
const quoteVisible = ref(false);
const compareVisible = ref(false);
const current = ref<Inquiry | null>(null);
const inquiryForm = reactive<any>({ material: '', qty: 1, deadline: '', supplierIds: [] as number[] });
const quoteDraft = reactive<Record<number, any>>({});

function quotes(inquiryId: number): Quote[] { return allQuotes.value.filter((q) => q.inquiryId === inquiryId); }
const stats = computed(() => [
  { label: '询价单', value: String(inquiries.value.length), tone: '' },
  { label: '报价总数', value: String(allQuotes.value.length), tone: 'qc-brand' },
  { label: '比价中', value: String(inquiries.value.filter((i) => i.status === '比价中').length), tone: 'qc-warn' },
  { label: '已定标', value: String(inquiries.value.filter((i) => i.status === '已定标').length), tone: '' },
]);
/** 比价排名：价格40% + 交期30% + 账期30%，各维度按最优值归一化 */
const ranked = computed(() => {
  if (!current.value) return [] as any[];
  const list = quotes(current.value.id);
  if (!list.length) return [];
  const minPrice = Math.min(...list.map((q) => q.price));
  const minLead = Math.min(...list.map((q) => q.leadDays || 0)) || 1;
  const maxPay = Math.max(...list.map((q) => q.payDays || 0)) || 1;
  return list.map((q) => {
    const priceScore = (minPrice / Math.max(0.01, q.price)) * 40;
    const leadScore = (minLead / Math.max(1, q.leadDays || 0)) * 30;
    const payScore = ((q.payDays || 0) / maxPay) * 30;
    return { ...q, total: q.price * current.value!.qty, score: priceScore + leadScore + payScore };
  }).sort((a, b) => b.score - a.score);
});
const recommended = computed(() => ranked.value[0]);

async function load(): Promise<void> {
  const list = async (u: string) => { const r: any = await mockGet(u, { pageSize: 300 }); return Array.isArray(r) ? r : r?.list || []; };
  inquiries.value = await list(IKEY);
  allQuotes.value = await list(QKEY);
  suppliers.value = await list('/api/v1/industry/suppliers');
  if (!suppliers.value.length) suppliers.value = [{ id: 1, name: '得力集团' }, { id: 2, name: '晨光文具' }, { id: 3, name: '华硕电脑' }];
}
async function saveInquiry(): Promise<void> {
  if (!inquiryForm.material) { toast.warning('请填写询价物料'); return; }
  const item: Inquiry = { id: Date.now(), no: `INQ${Date.now().toString().slice(-6)}`, material: inquiryForm.material, qty: Number(inquiryForm.qty), deadline: inquiryForm.deadline, status: '比价中', supplierIds: [...inquiryForm.supplierIds] };
  const saved: any = await mockPost(IKEY, item);
  inquiries.value.push({ ...item, id: saved?.id || item.id });
  inquiryVisible.value = false; toast.success('询价单已发起');
}
function openQuote(q: Inquiry): void {
  current.value = q;
  for (const s of suppliers.value) quoteDraft[s.id] = { price: 0, leadDays: 7, payDays: 30 };
  quoteVisible.value = true;
}
async function submitQuote(s: any): Promise<void> {
  if (!current.value) return;
  const d = quoteDraft[s.id];
  if (!d.price || d.price <= 0) { toast.warning(`请填写 ${s.name} 的有效报价`); return; }
  await mockPost(QKEY, { inquiryId: current.value.id, supplierId: s.id, supplierName: s.name, price: Number(d.price), leadDays: Number(d.leadDays), payDays: Number(d.payDays) });
  allQuotes.value.push({ id: Date.now(), inquiryId: current.value.id, supplierId: s.id, supplierName: s.name, price: Number(d.price), leadDays: Number(d.leadDays), payDays: Number(d.payDays) });
  toast.success(`${s.name} 报价已录入`);
}
function openCompare(q: Inquiry): void { current.value = q; compareVisible.value = true; }
/** 定标：标记中标报价，询价单关闭，并生成一张采购订单草稿供确认 */
async function award(r: any): Promise<void> {
  if (!current.value) return;
  current.value.status = '已定标';
  await mockPost(IKEY, { ...current.value });
  await mockPost(QKEY, { ...r, won: true });
  const po = { orderNo: `PO${new Date().toISOString().slice(0, 10).replace(/-/g, '')}-INQ`, supplierId: r.supplierId, supplierName: r.supplierName, material: current.value.material, qty: current.value.qty, unitPrice: r.price, totalAmount: Number(r.total.toFixed(2)), status: '草稿', source: '询比价定标', createdAt: new Date().toLocaleString('zh-CN') };
  await mockPost('/api/v1/industry/purchaseOrders', po);
  emit(Events.APPROVAL_DONE, { type: 'QUOTATION_AWARD', supplierId: r.supplierId, supplierName: r.supplierName });
  compareVisible.value = false; toast.success(`已定标：${r.supplierName}，采购订单草稿已生成`);
}
onMounted(load);
</script>

<style scoped>
.qc-page { display: flex; flex-direction: column; gap: 14px; padding: 16px; }
.qc-stats { display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px; }
.qc-stat { border: 1px solid var(--ds-border); border-radius: 10px; padding: 14px 16px; background: var(--ds-bg-elevated); display: flex; flex-direction: column; gap: 6px; }
.qc-stat span { font-size: 12px; color: var(--ds-text-3); }
.qc-stat b { font-size: 22px; }
.qc-brand { color: var(--ds-brand); }
.qc-warn { color: var(--ds-warning); }
.qc-body { padding: 16px; }
.qc-table { width: 100%; border-collapse: collapse; font-size: 13px; }
.qc-table th, .qc-table td { padding: 9px 10px; border-bottom: 1px solid var(--ds-divider); text-align: left; }
.qc-table th { background: var(--ds-bg-soft); color: var(--ds-text-3); }
.qc-ops { display: flex; gap: 6px; }
.qc-empty { padding: 24px; text-align: center; color: var(--ds-text-3); }
.qc-form { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
.qc-form label { display: flex; flex-direction: column; gap: 5px; font-size: 12px; }
.qc-foot { display: flex; justify-content: flex-end; gap: 8px; }
.qc-quote { display: flex; flex-direction: column; gap: 10px; }
.qc-quote__hint { font-size: 12px; color: var(--ds-text-3); }
.qc-quote-row { display: grid; grid-template-columns: 1.4fr repeat(3, 1fr) 70px; gap: 8px; align-items: end; border-bottom: 1px solid var(--ds-divider); padding-bottom: 8px; font-size: 12px; }
.qc-quote-row label { display: flex; flex-direction: column; gap: 4px; }
.qc-compare { display: flex; flex-direction: column; gap: 10px; }
.qc-compare__hint { font-size: 12px; color: var(--ds-text-3); }
.qcBest { background: var(--ds-brand-soft); }
@media (max-width: 1024px) { .qc-stats { grid-template-columns: repeat(2, 1fr); } }
</style>
