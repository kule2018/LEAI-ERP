<!-- 采购收货中心：到货登记→质检(合格/拒收/让步)→入库上架→批次成本确认→库存联动 -->
<template>
  <div class="rcv-page">
    <div class="rcv-stats">
      <div v-for="c in stats" :key="c.label" class="rcv-stat"><span>{{ c.label }}</span><b :class="c.tone">{{ c.value }}</b></div>
    </div>

    <DsCard title="到货与收货单" :pad="false">
      <template #extra><DsButton size="sm" variant="primary" @click="newVisible = true">到货登记</DsButton></template>
      <div class="rcv-body">
        <table class="rcv-table">
          <thead><tr><th>收货单号</th><th>关联采购单</th><th>供应商</th><th>产品</th><th>到货数</th><th>质检</th><th>批次/效期</th><th>状态</th><th>操作</th></tr></thead>
          <tbody>
            <tr v-for="r in receipts" :key="r.id">
              <td>{{ r.no }}</td><td>{{ r.orderNo || '—' }}</td><td>{{ r.supplierName }}</td><td>{{ r.productName }}</td>
              <td>{{ r.qty }}</td>
              <td><DsTag :color="qcColor(r.qc)" size="sm">{{ r.qc }}</DsTag></td>
              <td>{{ r.batchNo || '—' }} / {{ r.expireDate || '—' }}</td>
              <td><DsTag :color="r.status === '已上架' ? 'success' : 'warning'" size="sm">{{ r.status }}</DsTag></td>
              <td><DsButton v-if="r.status !== '已上架' && r.qc !== '拒收'" size="sm" variant="primary" @click="putaway(r)">质检入库</DsButton><span v-else class="rcv-comment">{{ r.qc === '拒收' ? '已拒收' : '已上架' }}</span></td>
            </tr>
            <tr v-if="!receipts.length"><td colspan="9" class="rcv-empty">暂无收货单</td></tr>
          </tbody>
        </table>
      </div>
    </DsCard>

    <!-- 到货登记 -->
    <DsModal v-model="newVisible" title="到货登记" :width="520">
      <div class="rcv-form">
        <label><span>关联采购单</span><select v-model="form.orderNo" class="ds-input"><option value="">无（直接到货）</option><option v-for="o in orders" :key="o.id" :value="o.orderNo">{{ o.orderNo }} · {{ o.supplierName }}</option></select></label>
        <label><span>供应商</span><select v-model="form.supplierId" class="ds-input"><option v-for="s in suppliers" :key="s.id" :value="s.id">{{ s.name }}</option></select></label>
        <label><span>产品</span><select v-model="form.productId" class="ds-input"><option v-for="p in products" :key="p.id" :value="p.id">{{ p.name }}</option></select></label>
        <label><span>到货数量</span><input v-model.number="form.qty" class="ds-input" type="number" /></label>
        <label><span>批次号</span><input v-model="form.batchNo" class="ds-input" /></label>
        <label><span>有效期至</span><DsDatePicker v-model="form.expireDate" /></label>
        <label><span>质检结论</span><select v-model="form.qc" class="ds-input"><option>合格</option><option>拒收</option><option>让步接收</option></select></label>
        <label><span>仓库</span><select v-model="form.warehouseId" class="ds-input"><option v-for="w in warehouses" :key="w.id" :value="w.id">{{ w.name }}</option></select></label>
      </div>
      <template #footer><div class="rcv-foot"><DsButton @click="newVisible=false">取消</DsButton><DsButton variant="primary" @click="saveReceipt">登记</DsButton></div></template>
    </DsModal>

    <!-- 质检入库确认 -->
    <DsModal v-model="putawayVisible" title="质检入库与成本确认" :width="480">
      <div v-if="current" class="rcv-putaway">
        <div class="rcv-putaway__hint">{{ current.productName }} × {{ current.qty }} · 入库后按 weighed 加权成本公式更新库存成本。</div>
        <label class="rcv-putaway__row"><span>采购单价</span><input v-model.number="costForm.unitCost" class="ds-input" type="number" /></label>
        <label class="rcv-putaway__row"><span>入库仓库</span><select v-model="costForm.warehouseId" class="ds-input"><option v-for="w in warehouses" :key="w.id" :value="w.id">{{ w.name }}</option></select></label>
        <label class="rcv-putaway__row"><span>库位</span><input v-model="costForm.location" class="ds-input" placeholder="如 A-01-03" /></label>
        <div class="rcv-putaway__formula">入库金额 = {{ current.qty }} × {{ Number(costForm.unitCost||0).toFixed(2) }} = <b>¥{{ (current.qty * Number(costForm.unitCost||0)).toFixed(2) }}</b></div>
      </div>
      <template #footer><div class="rcv-foot"><DsButton @click="putawayVisible=false">取消</DsButton><DsButton variant="primary" @click="confirmPutaway">确认入库</DsButton></div></template>
    </DsModal>
  </div>
</template>

<script setup lang="ts">
/** 收货中心：到货登记→质检判定→上架入库→批次成本与库存联动，拒收单独记录。 */
import { computed, onMounted, reactive, ref } from 'vue';
import { DsButton, DsCard, DsModal, DsTag } from '../../components';
import { mockGet, mockPost } from '../../api/mockAdapter';
import { emit, Events } from '../../utils/eventBus';
import { useToast } from '../../components/ds/toast';

interface Receipt { id: number; no: string; orderNo: string; supplierId: number; supplierName: string; productId: number; productName: string; qty: number; batchNo: string; expireDate: string; qc: string; status: string; warehouseId: number; cost?: number; }

const toast = useToast();
const KEY = '/api/v1/industry/purchaseReceipts';
const receipts = ref<Receipt[]>([]);
const orders = ref<any[]>([]);
const suppliers = ref<any[]>([]);
const products = ref<any[]>([]);
const warehouses = ref<any[]>([]);
const newVisible = ref(false);
const putawayVisible = ref(false);
const current = ref<Receipt | null>(null);
const form = reactive<any>({ orderNo: '', supplierId: null, productId: null, qty: 1, batchNo: '', expireDate: '', qc: '合格', warehouseId: 1 });
const costForm = reactive<any>({ unitCost: 0, warehouseId: 1, location: '' });

function qcColor(qc: string): any { return qc === '合格' ? 'success' : qc === '拒收' ? 'danger' : 'warning'; }
const qualifiedCount = computed(() => receipts.value.filter((r) => r.qc !== '拒收').length);
const stats = computed(() => [
  { label: '到货批次', value: String(receipts.value.length), tone: '' },
  { label: '待上架', value: String(receipts.value.filter((r) => r.status !== '已上架' && r.qc !== '拒收').length), tone: 'rcv-warn' },
  { label: '已上架', value: String(receipts.value.filter((r) => r.status === '已上架').length), tone: 'rcv-brand' },
  { label: '拒收批次', value: String(receipts.value.filter((r) => r.qc === '拒收').length), tone: 'rcv-danger' },
]);

async function load(): Promise<void> {
  const list = async (u: string) => { const r: any = await mockGet(u, { pageSize: 300 }); return Array.isArray(r) ? r : r?.list || []; };
  receipts.value = await list(KEY);
  orders.value = (await list('/api/v1/industry/purchaseOrders')).filter((o: any) => ['已确认', '部分收货', '已入库'].includes(o.status));
  suppliers.value = await list('/api/v1/industry/suppliers');
  products.value = await list('/api/v1/inventory/products');
  warehouses.value = await mockGet('/api/v1/inventory/warehouses', {}) as any;
  if (!form.supplierId) form.supplierId = suppliers.value[0]?.id;
  if (!form.productId) form.productId = products.value[0]?.id;
}
async function saveReceipt(): Promise<void> {
  if (!form.productId || !form.qty || form.qty <= 0) { toast.warning('请选择产品并填写到货数量'); return; }
  const supplier = suppliers.value.find((s) => s.id === form.supplierId);
  const product = products.value.find((p) => p.id === form.productId);
  const r: Receipt = { id: Date.now(), no: `RCV${Date.now().toString().slice(-6)}`, orderNo: form.orderNo, supplierId: Number(form.supplierId), supplierName: supplier?.name || '', productId: Number(form.productId), productName: product?.name || '', qty: Number(form.qty), batchNo: form.batchNo, expireDate: form.expireDate, qc: form.qc, status: '待上架', warehouseId: Number(form.warehouseId) };
  const saved: any = await mockPost(KEY, r);
  receipts.value.push({ ...r, id: saved?.id || r.id });
  if (r.qc === '拒收') await mockPost('/api/v1/industry/purchaseRejects', { ...r, reason: '到货质检拒收' });
  newVisible.value = false; toast.success(r.qc === '拒收' ? '已登记拒收' : '到货已登记，待质检上架');
}
function putaway(r: Receipt): void {
  current.value = r;
  costForm.unitCost = Number(products.value.find((p) => p.id === r.productId)?.cost || 0);
  costForm.warehouseId = r.warehouseId; costForm.location = '';
  putawayVisible.value = true;
}
/** 上架入库：记录加权成本快照并发布库存变动事件（成本重算由后端采购流程执行） */
async function confirmPutaway(): Promise<void> {
  if (!current.value) return;
  const unitCost = Number(costForm.unitCost || 0);
  if (unitCost < 0) { toast.warning('采购单价不能为负'); return; }
  current.value.status = '已上架'; current.value.cost = unitCost;
  await mockPost(KEY, { ...current.value });
  await mockPost('/api/v1/industry/stockBalanceIn', { productId: current.value.productId, productName: current.value.productName, warehouseId: costForm.warehouseId, location: costForm.location, qty: current.value.qty, unitCost, amount: Number((current.value.qty * unitCost).toFixed(2)), batchNo: current.value.batchNo, createdAt: new Date().toLocaleString('zh-CN') });
  emit(Events.STOCK_CHANGED, { type: 'PURCHASE_IN', productId: current.value.productId, qty: current.value.qty, cost: unitCost });
  putawayVisible.value = false; toast.success(`${current.value.productName} 已上架入库`);
}
onMounted(load);
</script>

<style scoped>
.rcv-page { display: flex; flex-direction: column; gap: 14px; padding: 16px; }
.rcv-stats { display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px; }
.rcv-stat { border: 1px solid var(--ds-border); border-radius: 10px; padding: 14px 16px; background: var(--ds-bg-elevated); display: flex; flex-direction: column; gap: 6px; }
.rcv-stat span { font-size: 12px; color: var(--ds-text-3); }
.rcv-stat b { font-size: 22px; }
.rcv-brand { color: var(--ds-brand); }
.rcv-warn { color: var(--ds-warning); }
.rcv-danger { color: var(--ds-danger); }
.rcv-body { padding: 16px; }
.rcv-table { width: 100%; border-collapse: collapse; font-size: 13px; }
.rcv-table th, .rcv-table td { padding: 9px 10px; border-bottom: 1px solid var(--ds-divider); text-align: left; }
.rcv-table th { background: var(--ds-bg-soft); color: var(--ds-text-3); }
.rcv-comment { color: var(--ds-text-3); font-size: 12px; }
.rcv-empty { padding: 24px; text-align: center; color: var(--ds-text-3); }
.rcv-form { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
.rcv-form label { display: flex; flex-direction: column; gap: 5px; font-size: 12px; }
.rcv-foot { display: flex; justify-content: flex-end; gap: 8px; }
.rcv-putaway { display: flex; flex-direction: column; gap: 10px; }
.rcv-putaway__hint { font-size: 12px; color: var(--ds-text-3); }
.rcv-putaway__row { display: flex; align-items: center; justify-content: space-between; font-size: 13px; }
.rcv-putaway__row .ds-input { width: 180px; }
.rcv-putaway__formula { font-size: 13px; }
.rcv-putaway__formula b { color: var(--ds-brand); }
@media (max-width: 1024px) { .rcv-stats { grid-template-columns: repeat(2, 1fr); } }
</style>
