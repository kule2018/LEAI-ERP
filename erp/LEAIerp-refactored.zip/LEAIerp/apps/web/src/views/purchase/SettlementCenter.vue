<!-- 采购对账付款中心：应付台账→对账单→付款核销→凭证预览，采购资金闭环 -->
<template>
  <div class="stl-page">
    <div class="stl-stats">
      <div v-for="c in stats" :key="c.label" class="stl-stat"><span>{{ c.label }}</span><b :class="c.tone">{{ c.value }}</b></div>
    </div>

    <div class="stl-tabs">
      <button v-for="t in tabs" :key="t.key" class="stl-tab" :class="{ on: active === t.key }" @click="active = t.key">{{ t.label }}</button>
    </div>

    <!-- 应付台账 -->
    <DsCard v-if="active === 'payable'" title="应付账款台账" :pad="false">
      <template #extra><input v-model="keyword" class="ds-input" placeholder="采购单/供应商查询" /></template>
      <div class="stl-body">
        <table class="stl-table">
          <thead><tr><th>采购单</th><th>供应商</th><th>应付金额</th><th>已付</th><th>未付</th><th>账期</th><th>状态</th><th>操作</th></tr></thead>
          <tbody>
            <tr v-for="p in filteredPayables" :key="p.id">
              <td>{{ p.orderNo }}</td><td>{{ p.supplierName }}</td>
              <td>¥{{ Number(p.amount).toFixed(2) }}</td><td>¥{{ Number(p.paidAmount||0).toFixed(2) }}</td>
              <td>¥{{ Number(p.amount - Number(p.paidAmount||0)).toFixed(2) }}</td>
              <td>{{ p.payDays||30 }}天</td>
              <td><DsTag :color="Number(p.paidAmount||0) >= p.amount ? 'success' : 'warning'" size="sm">{{ Number(p.paidAmount||0) >= p.amount ? '已结清' : '未结清' }}</DsTag></td>
              <td><DsButton size="sm" variant="primary" :disabled="Number(p.paidAmount||0) >= p.amount" @click="openPay(p)">付款</DsButton></td>
            </tr>
            <tr v-if="!filteredPayables.length"><td colspan="8" class="stl-empty">暂无应付账款（采购入库后自动生成）</td></tr>
          </tbody>
        </table>
      </div>
    </DsCard>

    <!-- 对账单 -->
    <DsCard v-if="active === 'statement'" title="供应商对账单" :pad="false">
      <template #extra><DsButton size="sm" variant="primary" @click="generateStatement">生成本月对账单</DsButton></template>
      <div class="stl-body">
        <table class="stl-table">
          <thead><tr><th>对账单号</th><th>供应商</th><th>期间</th><th>单据数</th><th>应付金额</th><th>状态</th><th>操作</th></tr></thead>
          <tbody>
            <tr v-for="s in statements" :key="s.id">
              <td>{{ s.no }}</td><td>{{ s.supplierName }}</td><td>{{ s.period }}</td><td>{{ s.count }}</td>
              <td>¥{{ Number(s.amount).toFixed(2) }}</td>
              <td><DsTag :color="s.status === '已确认' ? 'success' : 'warning'" size="sm">{{ s.status }}</DsTag></td>
              <td><DsButton v-if="s.status !== '已确认'" size="sm" @click="confirmStatement(s)">确认</DsButton><span v-else class="stl-comment">已确认</span></td>
            </tr>
            <tr v-if="!statements.length"><td colspan="7" class="stl-empty">暂无对账单</td></tr>
          </tbody>
        </table>
      </div>
    </DsCard>

    <!-- 付款记录 -->
    <DsCard v-if="active === 'payment'" title="付款记录与凭证" :pad="false">
      <div class="stl-body">
        <table class="stl-table">
          <thead><tr><th>付款单号</th><th>采购单</th><th>供应商</th><th>金额</th><th>方式</th><th>时间</th><th>凭证</th></tr></thead>
          <tbody>
            <tr v-for="p in payments" :key="p.id">
              <td>{{ p.no }}</td><td>{{ p.orderNo }}</td><td>{{ p.supplierName }}</td><td>¥{{ Number(p.amount).toFixed(2) }}</td>
              <td>{{ p.method }}</td><td>{{ p.createdAt }}</td>
              <td><DsButton size="sm" @click="viewVoucher(p)">预览凭证</DsButton></td>
            </tr>
            <tr v-if="!payments.length"><td colspan="7" class="stl-empty">暂无付款记录</td></tr>
          </tbody>
        </table>
      </div>
    </DsCard>

    <!-- 付款弹窗 -->
    <DsModal v-model="payVisible" title="采购付款核销" :width="460">
      <div v-if="current" class="stl-pay">
        <div class="stl-pay__row"><span>应付余额</span><b>¥{{ balance.toFixed(2) }}</b></div>
        <label class="stl-pay__row"><span>本次付款</span><input v-model.number="payValue" class="ds-input" type="number" /></label>
        <label class="stl-pay__row"><span>支付方式</span><select v-model="payMethod" class="ds-input"><option>银行转账</option><option>现金</option><option>承兑汇票</option></select></label>
        <div class="stl-pay__voucher">凭证预览：借 应付账款 ¥{{ Number(payValue||0).toFixed(2) }} / 贷 银行存款 ¥{{ Number(payValue||0).toFixed(2) }}</div>
      </div>
      <template #footer><div class="stl-foot"><DsButton @click="payVisible=false">取消</DsButton><DsButton variant="primary" @click="confirmPay">确认付款</DsButton></div></template>
    </DsModal>

    <!-- 凭证弹窗 -->
    <DsModal v-model="voucherVisible" title="会计凭证预览" :width="480">
      <div v-if="voucher" class="stl-voucher">
        <div class="stl-voucher__title">{{ voucher.no }} · {{ voucher.createdAt }}</div>
        <table class="stl-table"><thead><tr><th>摘要</th><th>科目</th><th>借方</th><th>贷方</th></tr></thead>
          <tbody>
            <tr><td>支付采购款</td><td>应付账款</td><td>¥{{ Number(voucher.amount).toFixed(2) }}</td><td>—</td></tr>
            <tr><td>支付采购款</td><td>银行存款</td><td>—</td><td>¥{{ Number(voucher.amount).toFixed(2) }}</td></tr>
          </tbody>
        </table>
        <div class="stl-voucher__balance">借贷平衡 ✓</div>
      </div>
    </DsModal>
  </div>
</template>

<script setup lang="ts">
/** 采购资金闭环：应付台账 + 对账单 + 付款核销 + 会计凭证预览，付款回写应付余额。 */
import { computed, onMounted, reactive, ref } from 'vue';
import { DsButton, DsCard, DsModal, DsTag } from '../../components';
import { mockGet, mockPost } from '../../api/mockAdapter';
import { emit, Events } from '../../utils/eventBus';
import { useToast } from '../../components/ds/toast';

interface Payable { id: number; orderNo: string; supplierId: number; supplierName: string; amount: number; paidAmount: number; payDays: number; }

const toast = useToast();
const PKEY = '/api/v1/industry/payables';
const tabs = [{ key: 'payable', label: '应付台账' }, { key: 'statement', label: '对账单' }, { key: 'payment', label: '付款记录' }];
const active = ref('payable');
const payables = ref<Payable[]>([]);
const statements = ref<any[]>([]);
const payments = ref<any[]>([]);
const keyword = ref('');
const payVisible = ref(false);
const voucherVisible = ref(false);
const current = ref<Payable | null>(null);
const voucher = ref<any>(null);
const payValue = ref(0);
const payMethod = ref('银行转账');

const filteredPayables = computed(() => {
  const kw = keyword.value.trim().toLowerCase();
  return payables.value.filter((p) => !kw || p.orderNo.toLowerCase().includes(kw) || p.supplierName.includes(kw));
});
const balance = computed(() => current.value ? Math.max(0, Number(current.value.amount) - Number(current.value.paidAmount || 0)) : 0);
const stats = computed(() => [
  { label: '应付总额', value: `¥${payables.value.reduce((s, p) => s + Number(p.amount), 0).toFixed(0)}`, tone: 'stl-brand' },
  { label: '未付余额', value: `¥${payables.value.reduce((s, p) => s + Math.max(0, Number(p.amount) - Number(p.paidAmount || 0)), 0).toFixed(0)}`, tone: 'stl-warn' },
  { label: '付款笔数', value: String(payments.value.length), tone: '' },
  { label: '已确认对账', value: String(statements.value.filter((s) => s.status === '已确认').length), tone: '' },
]);

async function load(): Promise<void> {
  const list = async (u: string) => { const r: any = await mockGet(u, { pageSize: 300 }); return Array.isArray(r) ? r : r?.list || []; };
  payables.value = await list(PKEY);
  statements.value = await list('/api/v1/industry/purchaseStatements');
  payments.value = await list('/api/v1/industry/purchasePayments');
}
function openPay(p: Payable): void { current.value = p; payValue.value = balance.value; payVisible.value = true; }
/** 付款核销：增加已付金额并生成付款记录与凭证事件 */
async function confirmPay(): Promise<void> {
  if (!current.value) return;
  const v = Number(payValue.value || 0);
  if (v <= 0 || v > balance.value) { toast.warning('付款金额需在 0 与应付余额之间'); return; }
  current.value.paidAmount = Number(current.value.paidAmount || 0) + v;
  await mockPost(PKEY, { ...current.value });
  const pay = { id: Date.now(), no: `PAY${Date.now().toString().slice(-6)}`, orderNo: current.value.orderNo, supplierName: current.value.supplierName, amount: v, method: payMethod.value, createdAt: new Date().toLocaleString('zh-CN') };
  await mockPost('/api/v1/industry/purchasePayments', pay);
  payments.value.push(pay);
  emit(Events.ORDER_CONFIRMED, { type: 'PURCHASE_PAY', total: v, orderNo: current.value.orderNo });
  payVisible.value = false; toast.success(`付款 ¥${v.toFixed(2)} 已核销，凭证已生成`);
}
/** 按供应商汇总当前期间应付，生成对账单 */
async function generateStatement(): Promise<void> {
  const period = new Date().toISOString().slice(0, 7);
  const map: Record<string, any> = {};
  for (const p of payables.value) {
    if (!map[p.supplierName]) map[p.supplierName] = { supplierName: p.supplierName, count: 0, amount: 0 };
    map[p.supplierName].count += 1;
    map[p.supplierName].amount += Math.max(0, Number(p.amount) - Number(p.paidAmount || 0));
  }
  for (const [name, agg] of Object.entries(map)) {
    const s = { id: Date.now() + Math.random(), no: `STMT${Date.now().toString().slice(-6)}`, supplierName: name, period, count: agg.count, amount: Number(agg.amount.toFixed(2)), status: '待确认' };
    await mockPost('/api/v1/industry/purchaseStatements', s);
    statements.value.push(s);
  }
  toast.success(`已生成 ${Object.keys(map).length} 份 ${period} 对账单`);
}
async function confirmStatement(s: any): Promise<void> { s.status = '已确认'; await mockPost('/api/v1/industry/purchaseStatements', s); toast.success(`${s.supplierName} 对账单已确认`); }
function viewVoucher(p: any): void { voucher.value = { no: p.no.replace('PAY', 'VCH'), amount: p.amount, createdAt: p.createdAt }; voucherVisible.value = true; }
onMounted(load);
</script>

<style scoped>
.stl-page { display: flex; flex-direction: column; gap: 14px; padding: 16px; }
.stl-stats { display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px; }
.stl-stat { border: 1px solid var(--ds-border); border-radius: 10px; padding: 14px 16px; background: var(--ds-bg-elevated); display: flex; flex-direction: column; gap: 6px; }
.stl-stat span { font-size: 12px; color: var(--ds-text-3); }
.stl-stat b { font-size: 22px; }
.stl-brand { color: var(--ds-brand); }
.stl-warn { color: var(--ds-warning); }
.stl-tabs { display: flex; gap: 8px; }
.stl-tab { border: 1px solid var(--ds-border); background: var(--ds-bg-elevated); border-radius: 6px; padding: 7px 14px; font-size: 13px; cursor: pointer; }
.stl-tab.on { background: var(--ds-brand); color: #fff; border-color: var(--ds-brand); }
.stl-body { padding: 16px; }
.stl-table { width: 100%; border-collapse: collapse; font-size: 13px; }
.stl-table th, .stl-table td { padding: 9px 10px; border-bottom: 1px solid var(--ds-divider); text-align: left; }
.stl-table th { background: var(--ds-bg-soft); color: var(--ds-text-3); }
.stl-empty { padding: 24px; text-align: center; color: var(--ds-text-3); }
.stl-comment { color: var(--ds-text-3); font-size: 12px; }
.stl-pay { display: flex; flex-direction: column; gap: 10px; }
.stl-pay__row { display: flex; align-items: center; justify-content: space-between; font-size: 13px; }
.stl-pay__row .ds-input { width: 180px; }
.stl-pay__voucher { font-size: 12px; color: var(--ds-text-3); background: var(--ds-bg-soft); padding: 10px; border-radius: 6px; }
.stl-foot { display: flex; justify-content: flex-end; gap: 8px; }
.stl-voucher { display: flex; flex-direction: column; gap: 10px; }
.stl-voucher__title { font-size: 13px; font-weight: 600; }
.stl-voucher__balance { text-align: right; color: var(--ds-brand); font-size: 13px; }
@media (max-width: 1024px) { .stl-stats { grid-template-columns: repeat(2, 1fr); } }
</style>
