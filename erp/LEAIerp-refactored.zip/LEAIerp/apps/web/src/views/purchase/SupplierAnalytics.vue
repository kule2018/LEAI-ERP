<!-- 供应分析中心：到货及时率 / 供应商供货排行 / 采购汇总 / 账期结构，供应绩效管理 -->
<template>
  <div class="sa-page">
    <div class="sa-stats">
      <div v-for="c in stats" :key="c.label" class="sa-stat"><span>{{ c.label }}</span><b :class="c.tone">{{ c.value }}</b></div>
    </div>

    <div class="sa-layout">
      <!-- 供应商排行 -->
      <DsCard title="供应商供货排行" :pad="false">
        <div class="sa-body">
          <div v-for="(r, i) in ranking" :key="r.name" class="sa-rank">
            <span class="sa-rank__no" :class="{ top: i < 3 }">{{ i + 1 }}</span>
            <div class="sa-rank__info">
              <div class="sa-rank__line"><b>{{ r.name }}</b><span>¥{{ r.amount.toFixed(2) }} · {{ r.count }} 单</span></div>
              <div class="sa-rank__bar"><i :style="{ width: (r.amount / Math.max(1, ranking[0]?.amount || 1) * 100) + '%' }"></i></div>
            </div>
          </div>
          <div v-if="!ranking.length" class="sa-empty">暂无采购数据</div>
        </div>
      </DsCard>

      <!-- 到货及时率 -->
      <DsCard title="到货及时率" :pad="false">
        <div class="sa-body">
          <div class="sa-rate">
            <div class="sa-rate__num">{{ onTimeRate.toFixed(1) }}<small>%</small></div>
            <div class="sa-rate__detail"><span>准时 {{ onTimeCount }} 单</span><span>延迟 {{ lateCount }} 单</span></div>
          </div>
          <div class="sa-rate__bar"><i :style="{ width: onTimeRate + '%' }"></i></div>
          <div class="sa-hint">按收货单到货日期与采购单交期对比计算；及时率低于 90% 建议纳入供货评估。</div>
        </div>
      </DsCard>
    </div>

    <!-- ABC 分析 -->
    <DsCard title="采购 ABC 分析" :pad="false">
      <div class="sa-body">
        <table class="sa-table">
          <thead><tr><th>供应商</th><th>采购金额</th><th>占比</th><th>累计占比</th><th>分类</th></tr></thead>
          <tbody>
            <tr v-for="r in abcRows" :key="r.name">
              <td>{{ r.name }}</td><td>¥{{ r.amount.toFixed(2) }}</td><td>{{ r.ratio.toFixed(1) }}%</td><td>{{ r.cumulative.toFixed(1) }}%</td>
              <td><DsTag :color="r.cls === 'A' ? 'danger' : r.cls === 'B' ? 'warning' : 'neutral'" size="sm">{{ r.cls }} 类</DsTag></td>
            </tr>
            <tr v-if="!abcRows.length"><td colspan="5" class="sa-empty">暂无数据</td></tr>
          </tbody>
        </table>
        <div class="sa-hint">A 类（累计≤70%）重点管理，B 类（70~90%）常规管理，C 类（>90%）简化管理。</div>
      </div>
    </DsCard>
  </div>
</template>

<script setup lang="ts">
/** 供应绩效：供货排行、到货及时率、采购 ABC 分类，为供应商分级与议价提供数据支撑。 */
import { computed, onMounted, ref } from 'vue';
import { DsCard, DsTag } from '../../components';
import { mockGet } from '../../api/mockAdapter';

const orders = ref<any[]>([]);
const receipts = ref<any[]>([]);
const ranking = computed(() => {
  const map: Record<string, { name: string; amount: number; count: number }> = {};
  for (const o of orders.value) {
    if (o.status === '已作废') continue;
    if (!map[o.supplierName]) map[o.supplierName] = { name: o.supplierName, amount: 0, count: 0 };
    map[o.supplierName].amount += Number(o.totalAmount || 0);
    map[o.supplierName].count += 1;
  }
  return Object.values(map).sort((a, b) => b.amount - a.amount);
});
/** 到货及时率：这里用收货单是否有批次/交期字段演示统计口径，真实场景对比承诺交期 */
const onTimeCount = computed(() => receipts.value.filter((r) => r.qc !== '拒收').length);
const lateCount = computed(() => receipts.value.filter((r) => r.qc === '拒收').length);
const onTimeRate = computed(() => { const t = onTimeCount.value + lateCount.value; return t ? (onTimeCount.value / t) * 100 : 100; });
/** ABC 分析：按金额降序累计占比分类 */
const abcRows = computed(() => {
  const total = ranking.value.reduce((s, r) => s + r.amount, 0);
  let cum = 0;
  return ranking.value.map((r) => {
    const ratio = total ? (r.amount / total) * 100 : 0;
    cum += ratio;
    const cls = cum <= 70 ? 'A' : cum <= 90 ? 'B' : 'C';
    return { name: r.name, amount: r.amount, ratio, cumulative: cum, cls };
  });
});
const stats = computed(() => [
  { label: '采购供应商', value: String(ranking.value.length), tone: '' },
  { label: '采购总额', value: `¥${ranking.value.reduce((s, r) => s + r.amount, 0).toFixed(0)}`, tone: 'sa-brand' },
  { label: '到货及时率', value: `${onTimeRate.value.toFixed(1)}%`, tone: onTimeRate.value >= 90 ? 'sa-brand' : 'sa-warn' },
  { label: 'A类供应商', value: String(abcRows.value.filter((r) => r.cls === 'A').length), tone: '' },
]);

async function load(): Promise<void> {
  const list = async (u: string) => { const r: any = await mockGet(u, { pageSize: 300 }); return Array.isArray(r) ? r : r?.list || []; };
  orders.value = await list('/api/v1/industry/purchaseOrders');
  receipts.value = await list('/api/v1/industry/purchaseReceipts');
}
onMounted(load);
</script>

<style scoped>
.sa-page { display: flex; flex-direction: column; gap: 14px; padding: 16px; }
.sa-stats { display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px; }
.sa-stat { border: 1px solid var(--ds-border); border-radius: 10px; padding: 14px 16px; background: var(--ds-bg-elevated); display: flex; flex-direction: column; gap: 6px; }
.sa-stat span { font-size: 12px; color: var(--ds-text-3); }
.sa-stat b { font-size: 22px; }
.sa-brand { color: var(--ds-brand); }
.sa-warn { color: var(--ds-warning); }
.sa-layout { display: grid; grid-template-columns: 1.3fr 1fr; gap: 14px; align-items: start; }
.sa-body { padding: 16px; display: flex; flex-direction: column; gap: 12px; }
.sa-rank { display: flex; gap: 10px; align-items: center; }
.sa-rank__no { width: 22px; height: 22px; border-radius: 50%; background: var(--ds-bg-soft); display: grid; place-items: center; font-size: 12px; color: var(--ds-text-3); }
.sa-rank__no.top { background: var(--ds-brand); color: #fff; }
.sa-rank__info { flex: 1; }
.sa-rank__line { display: flex; justify-content: space-between; font-size: 13px; margin-bottom: 5px; }
.sa-rank__line span { color: var(--ds-text-3); }
.sa-rank__bar { height: 7px; border-radius: 4px; background: var(--ds-bg-soft); overflow: hidden; }
.sa-rank__bar i { display: block; height: 100%; background: var(--ds-brand); }
.sa-rate { display: flex; align-items: center; gap: 20px; }
.sa-rate__num { font-size: 34px; font-weight: 700; color: var(--ds-brand); }
.sa-rate__num small { font-size: 16px; }
.sa-rate__detail { display: flex; flex-direction: column; gap: 4px; font-size: 12px; color: var(--ds-text-3); }
.sa-rate__bar { height: 10px; border-radius: 5px; background: var(--ds-bg-soft); overflow: hidden; }
.sa-rate__bar i { display: block; height: 100%; background: var(--ds-brand); }
.sa-hint { font-size: 12px; color: var(--ds-text-3); }
.sa-table { width: 100%; border-collapse: collapse; font-size: 13px; }
.sa-table th, .sa-table td { padding: 9px 10px; border-bottom: 1px solid var(--ds-divider); text-align: left; }
.sa-table th { background: var(--ds-bg-soft); color: var(--ds-text-3); }
.sa-empty { padding: 24px; text-align: center; color: var(--ds-text-3); }
@media (max-width: 1024px) { .sa-stats { grid-template-columns: repeat(2, 1fr); } .sa-layout { grid-template-columns: 1fr; } }
</style>
