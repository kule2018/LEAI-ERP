<!-- 供应商中心：主数据 / 分组 / 资质 / 账期 / 供货评估评分卡 / 黑名单，供应侧核心 -->
<template>
  <div class="sup-page">
    <div class="sup-stats">
      <div v-for="c in stats" :key="c.label" class="sup-stat"><span>{{ c.label }}</span><b :class="c.tone">{{ c.value }}</b></div>
    </div>

    <div class="sup-layout">
      <!-- 分组 -->
      <DsCard title="供应商分组" :pad="false" class="sup-group-card">
        <div class="sup-group-body">
          <div class="sup-group" :class="{ on: activeGroup === '' }" @click="activeGroup = ''">全部分组 <span>{{ suppliers.length }}</span></div>
          <div v-for="g in groups" :key="g.id" class="sup-group" :class="{ on: activeGroup === g.name }" @click="activeGroup = g.name">
            {{ g.name }} <span>{{ suppliers.filter((s) => s.group === g.name).length }}</span>
          </div>
          <div class="sup-group-add">
            <input v-model="newGroup" class="ds-input" placeholder="新分组名称" @keyup.enter="addGroup" />
            <DsButton size="sm" @click="addGroup">+</DsButton>
          </div>
        </div>
      </DsCard>

      <!-- 供应商列表 -->
      <DsCard title="供应商档案" :pad="false">
        <template #extra>
          <div class="sup-tools">
            <input v-model="keyword" class="ds-input" placeholder="名称/编码/联系人搜索" />
            <select v-model="statusFilter" class="ds-input"><option value="">全部状态</option><option>合作中</option><option>待审核</option><option>黑名单</option></select>
            <DsButton size="sm" variant="primary" @click="openNew">新增供应商</DsButton>
          </div>
        </template>
        <div class="sup-body">
          <table class="sup-table">
            <thead><tr><th>编码</th><th>供应商</th><th>分组</th><th>联系人</th><th>账期</th><th>评分</th><th>等级</th><th>状态</th><th>操作</th></tr></thead>
            <tbody>
              <tr v-for="s in filtered" :key="s.id">
                <td>{{ s.code }}</td><td>{{ s.name }}</td><td>{{ s.group }}</td><td>{{ s.contact }} {{ s.phone }}</td>
                <td>{{ s.payDays || 0 }}天</td><td>{{ score(s).toFixed(1) }}</td>
                <td><DsTag :color="gradeColor(grade(s))" size="sm">{{ grade(s) }}</DsTag></td>
                <td><DsTag :color="s.status === '合作中' ? 'success' : s.status === '黑名单' ? 'danger' : 'warning'" size="sm">{{ s.status }}</DsTag></td>
                <td class="sup-ops">
                  <DsButton size="sm" @click="openEval(s)">供货评估</DsButton>
                  <DsButton size="sm" @click="edit(s)">编辑</DsButton>
                  <DsButton v-if="s.status !== '黑名单'" size="sm" @click="blacklist(s)">拉黑</DsButton>
                  <DsButton v-else size="sm" @click="restore(s)">恢复</DsButton>
                </td>
              </tr>
              <tr v-if="!filtered.length"><td colspan="9" class="sup-empty">暂无供应商</td></tr>
            </tbody>
          </table>
        </div>
      </DsCard>
    </div>

    <!-- 新增/编辑 -->
    <DsModal v-model="editVisible" title="供应商档案" :width="620">
      <div class="sup-form">
        <label><span>供应商名称</span><input v-model="form.name" class="ds-input" /></label>
        <label><span>分组</span><select v-model="form.group" class="ds-input"><option v-for="g in groups" :key="g.id" :value="g.name">{{ g.name }}</option></select></label>
        <label><span>联系人</span><input v-model="form.contact" class="ds-input" /></label>
        <label><span>联系电话</span><input v-model="form.phone" class="ds-input" /></label>
        <label><span>账期(天)</span><input v-model.number="form.payDays" class="ds-input" type="number" /></label>
        <label><span>付款方式</span><select v-model="form.payMethod" class="ds-input"><option>银行转账</option><option>现金</option><option>承兑汇票</option></select></label>
        <label><span>社会信用代码</span><input v-model="form.licenseNo" class="ds-input" /></label>
        <label><span>资质有效期</span><DsDatePicker v-model="form.licenseExpire" /></label>
        <label><span>开户行</span><input v-model="form.bank" class="ds-input" /></label>
        <label><span>开户账号</span><input v-model="form.bankAccount" class="ds-input" /></label>
        <label class="sup-form--full"><span>地址</span><input v-model="form.address" class="ds-input" /></label>
        <label class="sup-form--full"><span>备注</span><input v-model="form.remark" class="ds-input" /></label>
      </div>
      <template #footer><div class="sup-foot"><DsButton @click="editVisible=false">取消</DsButton><DsButton variant="primary" @click="saveSupplier">保存</DsButton></div></template>
    </DsModal>

    <!-- 供货评估 -->
    <DsModal v-model="evalVisible" title="供货评估评分卡" :width="520">
      <div v-if="evalTarget" class="sup-eval">
        <div class="sup-eval__who">{{ evalTarget.name }} · {{ evalTarget.code }}</div>
        <div class="sup-eval__hint">四维评分（0~100），综合分自动计算并分级：A(≥90) / B(≥80) / C(≥70) / D(&lt;70)。</div>
        <label class="sup-eval__row"><span>质量分</span><input v-model.number="evalForm.quality" class="ds-input" type="number" min="0" max="100" /></label>
        <label class="sup-eval__row"><span>交期分</span><input v-model.number="evalForm.delivery" class="ds-input" type="number" min="0" max="100" /></label>
        <label class="sup-eval__row"><span>价格分</span><input v-model.number="evalForm.price" class="ds-input" type="number" min="0" max="100" /></label>
        <label class="sup-eval__row"><span>服务分</span><input v-model.number="evalForm.service" class="ds-input" type="number" min="0" max="100" /></label>
        <div class="sup-eval__result">综合评分：<b>{{ evalTotal.toFixed(1) }}</b> · 等级 <DsTag :color="gradeColor(evalGrade)" size="sm">{{ evalGrade }}</DsTag></div>
        <label class="sup-eval__row"><span>评估说明</span><input v-model="evalForm.comment" class="ds-input" /></label>
      </div>
      <template #footer><div class="sup-foot"><DsButton @click="evalVisible=false">取消</DsButton><DsButton variant="primary" @click="saveEval">提交评估</DsButton></div></template>
    </DsModal>
  </div>
</template>

<script setup lang="ts">
/** 供应侧主数据：供应商档案、分组、资质校验、供货评估四维评分卡与黑名单管控。 */
import { computed, onMounted, reactive, ref } from 'vue';
import { DsButton, DsCard, DsModal, DsTag } from '../../components';
import { mockGet, mockPost } from '../../api/mockAdapter';
import { emit, Events } from '../../utils/eventBus';
import { useToast } from '../../components/ds/toast';

interface Supplier { id: number; code: string; name: string; group: string; contact: string; phone: string; payDays: number; payMethod: string; licenseNo: string; licenseExpire: string; bank: string; bankAccount: string; address: string; remark: string; status: string; evaluation?: any; }
interface Group { id: number; name: string; }

const toast = useToast();
const KEY = '/api/v1/industry/suppliers';
const suppliers = ref<Supplier[]>([]);
const groups = ref<Group[]>([]);
const activeGroup = ref('');
const keyword = ref('');
const statusFilter = ref('');
const newGroup = ref('');
const editVisible = ref(false);
const evalVisible = ref(false);
const editingId = ref<number | null>(null);
const evalTarget = ref<Supplier | null>(null);
const form = reactive<any>({ name: '', group: '', contact: '', phone: '', payDays: 30, payMethod: '银行转账', licenseNo: '', licenseExpire: '', bank: '', bankAccount: '', address: '', remark: '' });
const evalForm = reactive<any>({ quality: 85, delivery: 85, price: 80, service: 85, comment: '' });

/** 综合评分：四维等权平均；已有评估取综合分，否则按账期给基础分 */
function score(s: Supplier): number {
  if (s.evaluation) { const e = s.evaluation; return (Number(e.quality) + Number(e.delivery) + Number(e.price) + Number(e.service)) / 4; }
  return Math.max(50, 90 - Number(s.payDays || 0) / 10);
}
function grade(s: Supplier): string { const v = score(s); return v >= 90 ? 'A' : v >= 80 ? 'B' : v >= 70 ? 'C' : 'D'; }
function gradeColor(g: string): any { return ({ A: 'success', B: 'brand', C: 'warning', D: 'danger' } as any)[g]; }
const evalTotal = computed(() => (Number(evalForm.quality) + Number(evalForm.delivery) + Number(evalForm.price) + Number(evalForm.service)) / 4);
const evalGrade = computed(() => evalTotal.value >= 90 ? 'A' : evalTotal.value >= 80 ? 'B' : evalTotal.value >= 70 ? 'C' : 'D');
const filtered = computed(() => {
  const kw = keyword.value.trim().toLowerCase();
  return suppliers.value.filter((s) => (!activeGroup.value || s.group === activeGroup.value) && (!statusFilter.value || s.status === statusFilter.value) && (!kw || s.name.toLowerCase().includes(kw) || s.code.toLowerCase().includes(kw) || (s.contact || '').includes(kw)));
});
const stats = computed(() => [
  { label: '供应商总数', value: String(suppliers.value.length), tone: '' },
  { label: '合作中', value: String(suppliers.value.filter((s) => s.status === '合作中').length), tone: 'sup-brand' },
  { label: 'A级供应商', value: String(suppliers.value.filter((s) => grade(s) === 'A').length), tone: 'sup-brand' },
  { label: '黑名单', value: String(suppliers.value.filter((s) => s.status === '黑名单').length), tone: 'sup-danger' },
]);

async function load(): Promise<void> {
  const list = async (u: string) => { const r: any = await mockGet(u, { pageSize: 300 }); return Array.isArray(r) ? r : r?.list || []; };
  groups.value = await list('/api/v1/industry/supplierGroups');
  if (!groups.value.length) {
    groups.value = [{ id: 1, name: '核心供应商' }, { id: 2, name: '备选供应商' }, { id: 3, name: '临时供应商' }];
    for (const g of groups.value) await mockPost('/api/v1/industry/supplierGroups', g);
  }
  suppliers.value = await list(KEY);
  if (!suppliers.value.length) {
    const seed: Supplier[] = [
      { id: 1, code: 'SUP001', name: '得力集团有限公司', group: '核心供应商', contact: '张经理', phone: '13800138001', payDays: 30, payMethod: '银行转账', licenseNo: '91330100XXXX001', licenseExpire: '2028-12-31', bank: '工商银行', bankAccount: '6222****0001', address: '浙江杭州', remark: '办公用品主力供应商', status: '合作中' },
      { id: 2, code: 'SUP002', name: '晨光文具股份有限公司', group: '核心供应商', contact: '李经理', phone: '13800138002', payDays: 45, payMethod: '银行转账', licenseNo: '91310100XXXX002', licenseExpire: '2027-08-31', bank: '建设银行', bankAccount: '6222****0002', address: '上海', remark: '', status: '合作中' },
      { id: 3, code: 'SUP003', name: '华硕电脑科技有限公司', group: '备选供应商', contact: '王经理', phone: '13800138003', payDays: 15, payMethod: '承兑汇票', licenseNo: '91320500XXXX003', licenseExpire: '2029-03-31', bank: '中国银行', bankAccount: '6222****0003', address: '江苏苏州', remark: '数码设备', status: '合作中' },
      { id: 4, code: 'SUP004', name: '本地五金经营部', group: '临时供应商', contact: '赵老板', phone: '13800138004', payDays: 0, payMethod: '现金', licenseNo: '', licenseExpire: '', bank: '', bankAccount: '', address: '本地', remark: '临时采购', status: '待审核' },
    ];
    for (const s of seed) await mockPost(KEY, s);
    suppliers.value = seed;
  }
}
async function addGroup(): Promise<void> {
  const name = newGroup.value.trim();
  if (!name) return;
  if (groups.value.some((g) => g.name === name)) { toast.warning('分组已存在'); return; }
  const g = { id: Date.now(), name };
  await mockPost('/api/v1/industry/supplierGroups', g); groups.value.push(g); newGroup.value = ''; toast.success('分组已新增');
}
function openNew(): void {
  editingId.value = null;
  Object.assign(form, { name: '', group: groups.value[0]?.name || '', contact: '', phone: '', payDays: 30, payMethod: '银行转账', licenseNo: '', licenseExpire: '', bank: '', bankAccount: '', address: '', remark: '' });
  editVisible.value = true;
}
function edit(s: Supplier): void { editingId.value = s.id; Object.assign(form, s); editVisible.value = true; }
/** 保存档案：资质有效期早于今天给出风险提示但仍保存（由评估环节管控） */
async function saveSupplier(): Promise<void> {
  if (!form.name) { toast.warning('请填写供应商名称'); return; }
  const today = new Date().toISOString().slice(0, 10);
  const expired = form.licenseExpire && form.licenseExpire < today;
  const data: any = { ...form, id: editingId.value || Date.now(), code: form.code || `SUP${String(suppliers.value.length + 1).padStart(3, '0')}`, status: form.status || '合作中' };
  const saved: any = await mockPost(KEY, data);
  if (editingId.value) { const idx = suppliers.value.findIndex((s) => s.id === editingId.value); if (idx >= 0) suppliers.value[idx] = { ...data, id: saved?.id || data.id }; }
  else suppliers.value.push({ ...data, id: saved?.id || data.id });
  editVisible.value = false;
  toast[expired ? 'warning' : 'success'](expired ? '已保存，但资质证照已过期，请尽快更新' : '供应商已保存');
}
function openEval(s: Supplier): void {
  evalTarget.value = s;
  const e = s.evaluation || {};
  Object.assign(evalForm, { quality: e.quality ?? 85, delivery: e.delivery ?? 85, price: e.price ?? 80, service: e.service ?? 85, comment: e.comment || '' });
  evalVisible.value = true;
}
/** 供货评估落库：更新供应商评分卡并发布事件 */
async function saveEval(): Promise<void> {
  if (!evalTarget.value) return;
  const evaluation = { ...evalForm, total: Number(evalTotal.value.toFixed(1)), grade: evalGrade.value, evaluatedAt: new Date().toLocaleString('zh-CN') };
  evalTarget.value.evaluation = evaluation;
  await mockPost(KEY, { ...evalTarget.value });
  await mockPost('/api/v1/industry/supplierEvaluates', { supplierId: evalTarget.value.id, supplierName: evalTarget.value.name, ...evaluation });
  emit(Events.DATA_RELOADED, { type: 'SUPPLIER_EVAL', supplierId: evalTarget.value.id });
  evalVisible.value = false; toast.success(`评估已提交，综合分 ${evaluation.total}（${evaluation.grade}级）`);
}
async function blacklist(s: Supplier): Promise<void> { s.status = '黑名单'; await mockPost(KEY, { ...s }); toast.success(`${s.name} 已加入黑名单`); }
async function restore(s: Supplier): Promise<void> { s.status = '合作中'; await mockPost(KEY, { ...s }); toast.success(`${s.name} 已恢复合作`); }
onMounted(load);
</script>

<style scoped>
.sup-page { display: flex; flex-direction: column; gap: 14px; padding: 16px; }
.sup-stats { display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px; }
.sup-stat { border: 1px solid var(--ds-border); border-radius: 10px; padding: 14px 16px; background: var(--ds-bg-elevated); display: flex; flex-direction: column; gap: 6px; }
.sup-stat span { font-size: 12px; color: var(--ds-text-3); }
.sup-stat b { font-size: 22px; }
.sup-brand { color: var(--ds-brand); }
.sup-danger { color: var(--ds-danger); }
.sup-layout { display: grid; grid-template-columns: 220px 1fr; gap: 14px; align-items: start; }
.sup-group-body { padding: 12px; display: flex; flex-direction: column; gap: 6px; }
.sup-group { display: flex; justify-content: space-between; align-items: center; padding: 8px 10px; border-radius: 6px; font-size: 13px; cursor: pointer; }
.sup-group:hover { background: var(--ds-bg-soft); }
.sup-group.on { background: var(--ds-brand-soft); color: var(--ds-brand); font-weight: 600; }
.sup-group span { color: var(--ds-text-3); font-size: 12px; }
.sup-group-add { display: flex; gap: 6px; margin-top: 8px; }
.sup-group-add .ds-input { min-width: 0; flex: 1; }
.sup-tools { display: flex; gap: 8px; }
.sup-body { padding: 16px; }
.sup-table { width: 100%; border-collapse: collapse; font-size: 13px; }
.sup-table th, .sup-table td { padding: 9px 10px; border-bottom: 1px solid var(--ds-divider); text-align: left; }
.sup-table th { background: var(--ds-bg-soft); color: var(--ds-text-3); }
.sup-ops { display: flex; gap: 5px; flex-wrap: wrap; }
.sup-empty { padding: 24px; text-align: center; color: var(--ds-text-3); }
.sup-form { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
.sup-form label { display: flex; flex-direction: column; gap: 5px; font-size: 12px; }
.sup-form--full { grid-column: 1 / -1; }
.sup-foot { display: flex; justify-content: flex-end; gap: 8px; }
.sup-eval { display: flex; flex-direction: column; gap: 10px; }
.sup-eval__who { font-size: 14px; font-weight: 600; }
.sup-eval__hint { font-size: 12px; color: var(--ds-text-3); }
.sup-eval__row { display: flex; align-items: center; justify-content: space-between; font-size: 13px; }
.sup-eval__row .ds-input { width: 140px; }
.sup-eval__result { font-size: 15px; }
.sup-eval__result b { color: var(--ds-brand); }
@media (max-width: 1024px) { .sup-stats { grid-template-columns: repeat(2, 1fr); } .sup-layout { grid-template-columns: 1fr; } }
</style>
