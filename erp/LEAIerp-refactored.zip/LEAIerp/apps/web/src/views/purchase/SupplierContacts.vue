<template><RecordPage :config="page" /></template>

<script setup lang="ts">
import RecordPage from '../records/RecordPage.vue';
import type { RecordPageConfig } from '../records/records';

const page: RecordPageConfig = {
  title: '供应商联系人',
  resource: 'purchase/supplier-contacts',
  schema: 'purchaseSupplierContacts',
  filters: ['supplierName', 'isPrimary'],
  required: ['supplierName', 'name', 'phone'],
};
</script>
