<template><RecordPage :config="page" /></template>

<script setup lang="ts">
import RecordPage from '../records/RecordPage.vue';
import type { RecordPageConfig } from '../records/records';

const page: RecordPageConfig = {
  title: '供应商罚款',
  resource: 'purchase/fines',
  schema: 'purchaseFines',
  filters: ['supplierName', 'fineDate', 'status'],
  required: ['fineNo', 'supplierName', 'amount', 'reason', 'fineDate'],
  metrics: ['amount'],
  initialStatus: 0,
  editStatus: [0],
  actions: [
    { key: 'submit', label: '提交审核', from: [0] },
    { key: 'approve', label: '确认罚款', from: [1] },
    { key: 'void', label: '作废', from: [0, 1, 2] },
  ],
};
</script>
