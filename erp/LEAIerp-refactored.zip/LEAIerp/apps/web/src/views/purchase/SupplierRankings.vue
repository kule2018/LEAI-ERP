<template><RecordPage :config="page" /></template>

<script setup lang="ts">
import RecordPage from '../records/RecordPage.vue';
import type { RecordPageConfig } from '../records/records';

const page: RecordPageConfig = {
  title: '供货排行',
  resource: 'purchase/supplier-rankings',
  schema: 'purchaseSupplierRankings',
  filters: ['supplierName'],
  reportSource: '按供应商比较供货金额和到货及时率',
};
</script>
