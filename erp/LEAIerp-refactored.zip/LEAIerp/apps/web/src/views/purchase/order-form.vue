<template>
  <div class="entity-page">
    <DsCard title="新建采购单">
      <template #extra>
        <DsButton size="sm" @click="aiVisible = true">🤖 OCR/文档识别建单</DsButton>
        <DsButton size="sm" variant="primary" :loading="saving" @click="onSave">保存草稿</DsButton>
      </template>
      <div class="entity-search">
        <label>供应商<DsSelect v-model="form.supplierId" class="entity-search__select" :options="supplierOptions" filterable size="sm" /></label>
        <label>仓库<DsSelect v-model="form.warehouseId" class="entity-search__select" :options="warehouseOptions" size="sm" /></label>
        <label>账期(天)<input v-model="form.payDays" class="ds-input" style="width: 90px" type="number" /></label>
      </div>
      <table class="ds-table">
        <thead><tr><th>产品</th><th>数量</th><th>单价</th><th>金额</th><th></th></tr></thead>
        <tbody>
          <tr v-for="(row, i) in form.lines" :key="i">
            <td><DsSelect v-model="row.productId" :options="productOptions" filterable size="sm" /></td>
            <td><input v-model="row.qty" class="ds-input" type="number" @blur="calc(row)" /></td>
            <td><input v-model="row.unitPrice" class="ds-input" type="number" @blur="calc(row)" /></td>
            <td>{{ row.amount }}</td>
            <td><DsButton variant="text" size="sm" style="color: var(--ds-danger)" @click="form.lines.splice(i, 1)">删</DsButton></td>
          </tr>
        </tbody>
      </table>
      <DsButton size="sm" style="margin-top: 8px" @click="form.lines.push({ productId: null, qty: '1', unitPrice: '0', amount: '0' })">添加明细行</DsButton>
    </DsCard>
    <!-- 智能建单：OCR/LLM 抽取字段 → 预填 → 用户确认后落草稿（文档 12.3） -->
    <DsModal v-model="aiVisible" title="智能建单（粘贴送货单/发票文本或 JSON）" :width="480">
      <textarea v-model="aiText" class="ds-input" rows="10" />
      <template #footer><div class="entity-modal-foot"><DsButton variant="primary" @click="applyAi">识别并填入</DsButton></div></template>
    </DsModal>
  </div>
</template>

<script setup lang="ts">
import { reactive, ref, onMounted, onBeforeUnmount, watch, computed } from 'vue';
import { useRouter } from 'vue-router';
import { DsButton, DsCard, DsModal, DsSelect } from '../../components';
import { useToast } from '../../components/ds/toast';
import Decimal from 'decimal.js';
import { purchaseApi, inventoryApi, aiApi } from '../../api';
import { useBaseStore } from '../../store';
import { useUndoRedo } from '../../composables/useUndoRedo';
import { useUnsavedGuard } from '../../composables/useUnsavedGuard';

const toast = useToast();
const router = useRouter();
const base = useBaseStore();
const saving = ref(false);
const warehouses = ref<any[]>([]);
const products = ref<any[]>([]);
const suppliers = ref<any[]>([]);
const aiVisible = ref(false);
const aiText = ref('');
const form = reactive<any>({ supplierId: null, warehouseId: null, payDays: '0', lines: [{ productId: null, qty: '1', unitPrice: '0', amount: '0' }] });
const supplierOptions = computed(() => suppliers.value.map((s: any) => ({ label: s.name, value: s.id })));
const warehouseOptions = computed(() => warehouses.value.map((w: any) => ({ label: w.name, value: w.id })));
const productOptions = computed(() => products.value.map((p: any) => ({ label: p.name, value: p.id })));
/** 撤销/重做与未保存保护 */
const dirty = ref(false);
const undoStack = useUndoRedo<any>(30);
const guard = useUnsavedGuard(() => ({ ...form }), 'purchase-order-new', dirty, (draft) => Object.assign(form, draft));
let ready = false;
watch(form, () => { if (ready) dirty.value = true; }, { deep: true });

/** 响应主框架快捷键：撤销、重做与保存 */
function onShortcut(event: Event): void {
  const action = (event as CustomEvent).detail;
  if (action === 'undo') {
    const snapshot = undoStack.undo({ ...form });
    if (snapshot) { Object.assign(form, snapshot); toast.info('已撤销上一步'); }
  } else if (action === 'redo') {
    const snapshot = undoStack.redo({ ...form });
    if (snapshot) { Object.assign(form, snapshot); toast.info('已重做'); }
  } else if (action === 'save') {
    onSave();
  }
}

function calc(row: any) { row.amount = new Decimal(row.qty || 0).mul(row.unitPrice || 0).toString(); }

async function onSave() {
  undoStack.record({ ...form });
  saving.value = true;
  try {
    const res: any = await purchaseApi.create({ ...form, lines: form.lines.filter((l: any) => l.productId) });
    dirty.value = false;
    guard.clearDraft();
    toast.success('草稿已保存');
    router.push('/purchase/orders');
  } catch { /* 已提示 */ } finally { saving.value = false; }
}
async function applyAi() {
  try {
    const res: any = await aiApi.docParse(aiText.value);
    const d = res.items || res.fields || res;
    if (d.supplierId) form.supplierId = d.supplierId;
    if (Array.isArray(d.items || d.lines)) {
      form.lines = (d.items || d.lines).map((r: any) => ({ productId: (products.value.find((p) => (r.name && p.name.includes(r.name)) || p.code === r.productCode) || {}).id || null,
        qty: String(r.qty ?? 1), unitPrice: String(r.unitPrice ?? 0), amount: '0' }));
      form.lines.forEach(calc);
    }
    toast[res.fallback ? 'info' : 'success'](res.fallback ? '规则引擎解析，未配置 AI 密钥' : 'AI 解析完成，请核对');
    aiVisible.value = false;
  } catch { /* 已提示 */ }
}

onMounted(async () => {
  window.addEventListener('erp-shortcut', onShortcut);
  await base.ensure(); warehouses.value = base.warehouses;
  const p = await inventoryApi.products({ pageSize: 200 });
  products.value = (p as any).list || p || [];
  ready = true;
});
onBeforeUnmount(() => window.removeEventListener('erp-shortcut', onShortcut));
</script>