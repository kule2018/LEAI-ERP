<template>
  <div class="entity-page">
    <div class="entity-stats">
      <div class="entity-stat"><span>采购单数</span><b>{{ summary?.orderCount ?? total }}</b></div>
      <div class="entity-stat"><span>合计金额</span><b>{{ summary?.totalAmount ?? '0.00' }}</b></div>
      <div class="entity-stat"><span>已付</span><b>{{ summary?.paidAmount ?? '0.00' }}</b></div>
      <div class="entity-stat"><span>未付</span><b>{{ summary?.unpaidAmount ?? '0.00' }}</b></div>
    </div>

    <DsCard :pad="false">
      <div class="entity-search">
        <input v-model="q.keyword" class="ds-input entity-search__input" placeholder="单号/供应商" />
        <DsSelect v-model="q.status" :options="docStatusOptions" style="width: 130px" placeholder="状态" size="sm" @change="onStatusChange" />
        <DsButton variant="primary" size="sm" @click="() => { page = 1; load(); }">查询</DsButton>
        <span class="entity-search__spacer" />
        <DsButton v-perm="'purchase:order:create'" size="sm" @click="$router.push('/purchase/orders/import')">批量导入</DsButton>
        <DsButton v-perm="'purchase:order:create'" variant="primary" size="sm" @click="$router.push('/purchase/orders/new')">新建采购单</DsButton>
      </div>
    </DsCard>

    <DsCard :pad="false">
      <div class="entity-table" v-loading="loading">
        <table class="ds-table">
          <thead><tr><th>单号</th><th>供应商</th><th>日期</th><th>金额</th><th>状态</th><th>收货</th><th>操作</th></tr></thead>
          <tbody>
            <tr v-for="s in list" :key="s.id">
              <td>{{ s.orderNo }}</td>
              <td>{{ s.supplierName }}</td>
              <td>{{ s.orderDate }}</td>
              <td>{{ s.totalAmount }}</td>
              <td><DsTag :color="tagColor(statusTag(s.status))" size="sm">{{ DOC_STATUS[s.status] }}</DsTag></td>
              <td>{{ s.receivedStatus === 'DONE' ? '已收完' : (s.receivedStatus === 'PARTIAL' ? '部分' : '未收') }}</td>
              <td>
                <DsButton v-if="s.status === 0" v-perm="'purchase:order:audit'" variant="text" size="sm" @click="act(() => purchaseApi.submit(s.id), '已提交')">提交</DsButton>
                <DsButton v-if="s.status === 1" v-perm="'purchase:order:audit'" variant="text" size="sm" @click="act(() => purchaseApi.confirm(s.id), '已确认')">确认</DsButton>
                <DsButton v-if="[2, 3].includes(s.status)" v-perm="'purchase:receive'" variant="text" size="sm" @click="act(() => purchaseApi.receive(s.id), '收货入库完成')">收货</DsButton>
                <DsButton v-if="[2, 3].includes(s.status)" v-perm="'purchase:order:void'" variant="danger" size="sm" @click="onVoid(s)">作废</DsButton>
              </td>
            </tr>
            <tr v-if="!list.length"><td colspan="7" class="entity-empty">暂无采购单</td></tr>
          </tbody>
        </table>
      </div>
      <div class="entity-pager">
        <DsPagination v-model:current-page="page" :page-size="pageSize" :total="total" layout="total, prev, pager, next" @change="load" />
      </div>
    </DsCard>
  </div>
</template>

<script setup lang="ts">
import { reactive, toRefs, onMounted } from 'vue';
import { DsButton, DsCard, DsPagination, DsSelect, DsTag } from '../../components';
import { purchaseApi } from '../../api';
import { useListPage, runAction, confirmVoid, DOC_STATUS, statusTag } from '../crud';

const st = reactive(useListPage<any>(async (query) => {
  const response = await purchaseApi.list(query);
  return {
    ...response,
    summary: {
      ...response.summary,
      orderCount: response.summary?.orderCount ?? response.summary?.order_count,
      totalAmount: response.summary?.totalAmount ?? response.summary?.total_amount,
    },
    list: (response.list ?? []).map((row: any) => ({
      ...row,
      orderNo: row.orderNo ?? row.order_no,
      supplierName: row.supplierName ?? row.supplier_name,
      orderDate: String(row.orderDate ?? row.order_date ?? '').slice(0, 10),
      totalAmount: row.totalAmount ?? row.total_amount,
      receivedStatus: row.receivedStatus ?? (Number(row.status) === 4 ? 'DONE' : Number(row.status) === 3 ? 'PARTIAL' : ''),
    })),
  };
}));
const { loading, list, summary, page, pageSize, total } = toRefs(st) as any;
const q = reactive<{ keyword?: string; status?: number }>({});

/** 原 el-option 改为 DsSelect 的 options 数组，key/value 完全不变 */
const docStatusOptions = Object.entries(DOC_STATUS).map(([k, v]) => ({ label: v, value: Number(k) }));
function onStatusChange(v: any) { if (v === '') q.status = undefined; }
/** crud 的 statusTag 照旧调用，仅把 EP 色名映射到 DsTag 色名 */
function tagColor(t: string): any { return ({ primary: 'brand', info: 'neutral' } as Record<string, any>)[t] || t; }

function load() { st.load({ keyword: q.keyword, status: q.status }); }
function act(fn: () => Promise<any>, msg: string) { runAction(fn, msg, load); }
function onVoid(row: any) { confirmVoid(() => purchaseApi.void(row.id), load); }
onMounted(load);
</script>