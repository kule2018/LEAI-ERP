/** 采购供应各页面的独立字段、表单与业务动作配置。 */
import type { SalesAction, SalesConfig, SalesField } from '../sales/salesConfigs';

const DOC_STATUS = { '0': '草稿', '1': '待审批', '2': '审批通过', '3': '已完成', '4': '已驳回', '9': '已作废' };
const MASTER_STATUS = { '0': '停用', '1': '启用' };
const docActions: SalesAction[] = [
  { key: 'submit', label: '提交审批', variant: 'primary', from: [0] },
  { key: 'approve', label: '审批通过', variant: 'primary', from: [1] },
  { key: 'reject', label: '驳回', variant: 'danger', from: [1] },
  { key: 'execute', label: '执行/过账', variant: 'primary', from: [2] },
  { key: 'void', label: '作废', variant: 'danger', from: [0, 1, 2, 3] },
];
const masterActions: SalesAction[] = [
  { key: 'toggle', label: '停用', variant: 'warning', from: [1] },
  { key: 'enable', label: '启用', variant: 'primary', from: [0] },
  { key: 'copy', label: '复制' },
];
const today = () => new Date().toISOString().slice(0, 10);
const no = (p: string) => `${p}${new Date().toISOString().replace(/\D/g, '').slice(0, 12)}`;
const supplierField = (required = true): SalesField => ({ prop: 'supplierId', label: '供应商', type: 'select', source: 'suppliers', required });
const docStatusField = (): SalesField => ({ prop: 'status', label: '状态', type: 'select', options: Object.entries(DOC_STATUS).map(([k, v]) => ({ label: v, value: Number(k) })) });
const masterStatusField = (): SalesField => ({ prop: 'status', label: '状态', type: 'select', options: [{ label: '启用', value: 1 }, { label: '停用', value: 0 }] });

export const PURCHASE_CONFIGS: Record<string, SalesConfig> = {
  suppliers: {
    title: '供应商列表', api: '/api/v1/purchase/suppliers', collection: 'purchaseSuppliers',
    columns: [{ prop: 'name', label: '供应商名称' }, { prop: 'code', label: '供应商编码' }, { prop: 'phone', label: '联系电话' }, { prop: 'address', label: '地址' }, { prop: 'payDays', label: '账期(天)' }, { prop: 'status', label: '状态' }],
    fields: [
      { prop: 'name', label: '供应商名称', required: true }, { prop: 'code', label: '供应商编码', required: true },
      { prop: 'phone', label: '联系电话' }, { prop: 'address', label: '地址' },
      { prop: 'payDays', label: '账期(天)', type: 'number' }, masterStatusField(),
    ],
    statusField: 'status', statusLabels: MASTER_STATUS, actions: masterActions,
    defaults: () => ({ payDays: 30, status: 1 }),
  },
  'supplier-groups': {
    title: '供应商分组', api: '/api/v1/purchase/supplier-groups', collection: 'purchaseSupplierGroups',
    columns: [{ prop: 'name', label: '分组名称' }, { prop: 'code', label: '分组编码' }, { prop: 'remark', label: '说明' }, { prop: 'status', label: '状态' }],
    fields: [
      { prop: 'name', label: '分组名称', required: true }, { prop: 'code', label: '分组编码', required: true },
      { prop: 'remark', label: '分组说明', type: 'textarea' }, masterStatusField(),
    ],
    statusField: 'status', statusLabels: MASTER_STATUS, actions: masterActions, defaults: () => ({ status: 1 }),
  },
  'supplier-evaluates': {
    title: '供货评估', api: '/api/v1/purchase/supplier-evaluates', collection: 'purchaseSupplierEvaluates',
    columns: [{ prop: 'supplierId', label: '供应商', source: 'suppliers' }, { prop: 'period', label: '评估期间' }, { prop: 'score', label: '综合得分' }, { prop: 'qualityScore', label: '质量分' }, { prop: 'deliveryScore', label: '交期分' }, { prop: 'priceScore', label: '价格分' }, { prop: 'level', label: '等级' }, { prop: 'status', label: '状态' }],
    fields: [
      supplierField(), { prop: 'period', label: '评估期间', placeholder: '如 2026-11', required: true },
      { prop: 'qualityScore', label: '质量分', type: 'number' }, { prop: 'deliveryScore', label: '交期分', type: 'number' },
      { prop: 'priceScore', label: '价格分', type: 'number' }, { prop: 'score', label: '综合得分', type: 'number' },
      { prop: 'level', label: '等级', type: 'select', options: [{ label: 'A', value: 'A' }, { label: 'B', value: 'B' }, { label: 'C', value: 'C' }] },
      { prop: 'remark', label: '评估说明', type: 'textarea' }, docStatusField(),
    ],
    statusField: 'status', statusLabels: DOC_STATUS, actions: docActions,
    defaults: () => ({ period: today().slice(0, 7), score: 0, qualityScore: 0, deliveryScore: 0, priceScore: 0, status: 0 }),
  },
  requirements: {
    title: '采购需求', api: '/api/v1/purchase/requirements', collection: 'purchaseRequirements',
    columns: [{ prop: 'reqNo', label: '需求单号' }, { prop: 'dept', label: '申请部门' }, { prop: 'productName', label: '物料名称' }, { prop: 'qty', label: '需求数量' }, { prop: 'needDate', label: '需求日期' }, { prop: 'status', label: '状态' }],
    fields: [
      { prop: 'reqNo', label: '需求单号', required: true }, { prop: 'dept', label: '申请部门', required: true },
      { prop: 'productName', label: '物料名称', required: true }, { prop: 'qty', label: '需求数量', type: 'number', required: true },
      { prop: 'needDate', label: '需求日期', type: 'date' }, { prop: 'remark', label: '需求说明', type: 'textarea' }, docStatusField(),
    ],
    statusField: 'status', statusLabels: DOC_STATUS, actions: docActions,
    defaults: () => ({ reqNo: no('PR'), qty: 1, needDate: today(), status: 0 }),
  },
  receipts: {
    title: '采购收货', api: '/api/v1/purchase/receipts', collection: 'purchaseReceipts',
    columns: [{ prop: 'receiptNo', label: '收货单号' }, { prop: 'orderId', label: '采购单' }, { prop: 'supplierId', label: '供应商', source: 'suppliers' }, { prop: 'productName', label: '物料' }, { prop: 'qty', label: '收货数量' }, { prop: 'receiveDate', label: '收货日期' }, { prop: 'qualityStatus', label: '质检' }, { prop: 'status', label: '状态' }],
    fields: [
      { prop: 'receiptNo', label: '收货单号', required: true },
      { prop: 'orderId', label: '采购单', type: 'select', source: 'orders' }, supplierField(),
      { prop: 'productName', label: '物料', required: true }, { prop: 'qty', label: '收货数量', type: 'number', required: true },
      { prop: 'receiveDate', label: '收货日期', type: 'date' },
      { prop: 'qualityStatus', label: '质检结果', type: 'select', options: [{ label: '待检', value: '待检' }, { label: '合格', value: '合格' }, { label: '不合格', value: '不合格' }] },
      docStatusField(),
    ],
    statusField: 'status', statusLabels: DOC_STATUS,
    actions: [
      { key: 'submit', label: '提交质检', variant: 'primary', from: [0] },
      { key: 'approve', label: '质检通过', variant: 'primary', from: [1] },
      { key: 'execute', label: '生成入库', variant: 'primary', from: [2] },
      { key: 'reject', label: '质检驳回', variant: 'danger', from: [1] },
      { key: 'void', label: '作废', variant: 'danger', from: [0, 1, 2] },
    ],
    defaults: () => ({ receiptNo: no('SH'), qty: 1, receiveDate: today(), qualityStatus: '待检', status: 0 }),
  },
  ins: {
    title: '采购入库', api: '/api/v1/purchase/ins', collection: 'purchaseIns',
    columns: [{ prop: 'inNo', label: '入库单号' }, { prop: 'orderId', label: '采购单' }, { prop: 'supplierId', label: '供应商', source: 'suppliers' }, { prop: 'warehouseId', label: '仓库' }, { prop: 'amount', label: '入库金额' }, { prop: 'inDate', label: '入库日期' }, { prop: 'status', label: '状态' }],
    fields: [
      { prop: 'inNo', label: '入库单号', required: true },
      { prop: 'orderId', label: '采购单', type: 'select', source: 'orders' }, supplierField(),
      { prop: 'warehouseId', label: '仓库', type: 'select' },
      { prop: 'amount', label: '入库金额', type: 'number' }, { prop: 'inDate', label: '入库日期', type: 'date' }, docStatusField(),
    ],
    statusField: 'status', statusLabels: DOC_STATUS, actions: docActions,
    defaults: () => ({ inNo: no('RK'), amount: 0, inDate: today(), warehouseId: 1, status: 0 }),
  },
  returns: {
    title: '采购退货', api: '/api/v1/purchase/returns', collection: 'purchaseReturns',
    columns: [{ prop: 'returnNo', label: '退货单号' }, { prop: 'supplierId', label: '供应商', source: 'suppliers' }, { prop: 'productName', label: '物料' }, { prop: 'qty', label: '退货数量' }, { prop: 'amount', label: '退货金额' }, { prop: 'reason', label: '退货原因' }, { prop: 'status', label: '状态' }],
    fields: [
      { prop: 'returnNo', label: '退货单号', required: true }, supplierField(),
      { prop: 'orderId', label: '采购单', type: 'select', source: 'orders' },
      { prop: 'productName', label: '物料', required: true }, { prop: 'qty', label: '退货数量', type: 'number', required: true },
      { prop: 'amount', label: '退货金额', type: 'number' }, { prop: 'reason', label: '退货原因', type: 'textarea' }, docStatusField(),
    ],
    statusField: 'status', statusLabels: DOC_STATUS, actions: docActions,
    defaults: () => ({ returnNo: no('PT'), qty: 1, amount: 0, status: 0 }),
  },
  statements: {
    title: '采购对账单', api: '/api/v1/purchase/statements', collection: 'purchaseStatements',
    columns: [{ prop: 'statementNo', label: '对账单号' }, { prop: 'supplierId', label: '供应商', source: 'suppliers' }, { prop: 'period', label: '对账期间' }, { prop: 'amount', label: '应付金额' }, { prop: 'settledAmount', label: '已付金额' }, { prop: 'status', label: '状态' }],
    fields: [
      { prop: 'statementNo', label: '对账单号', required: true }, supplierField(),
      { prop: 'period', label: '对账期间', placeholder: '如 2026-11', required: true },
      { prop: 'amount', label: '应付金额', type: 'number', required: true }, { prop: 'settledAmount', label: '已付金额', type: 'number' }, docStatusField(),
    ],
    statusField: 'status', statusLabels: DOC_STATUS,
    actions: [
      { key: 'submit', label: '提交对账', variant: 'primary', from: [0] },
      { key: 'approve', label: '对账确认', variant: 'primary', from: [1] },
      { key: 'execute', label: '付款完成', variant: 'primary', from: [2] },
      { key: 'void', label: '作废', variant: 'danger', from: [0, 1, 2] },
    ],
    defaults: () => ({ statementNo: no('PZ'), period: today().slice(0, 7), amount: 0, settledAmount: 0, status: 0 }),
  },
  quotations: {
    title: '询比价', api: '/api/v1/purchase/quotations', collection: 'purchaseQuotations',
    columns: [{ prop: 'quoteNo', label: '询价单号' }, { prop: 'supplierId', label: '供应商', source: 'suppliers' }, { prop: 'productName', label: '物料' }, { prop: 'qty', label: '数量' }, { prop: 'price', label: '单价' }, { prop: 'amount', label: '报价金额' }, { prop: 'validUntil', label: '有效期至' }, { prop: 'status', label: '状态' }],
    fields: [
      { prop: 'quoteNo', label: '询价单号', required: true }, supplierField(),
      { prop: 'productName', label: '物料', required: true }, { prop: 'qty', label: '数量', type: 'number', required: true },
      { prop: 'price', label: '单价', type: 'number' }, { prop: 'amount', label: '报价金额', type: 'number' },
      { prop: 'validUntil', label: '有效期至', type: 'date' }, docStatusField(),
    ],
    statusField: 'status', statusLabels: DOC_STATUS,
    actions: [
      { key: 'submit', label: '提交报价', variant: 'primary', from: [0] },
      { key: 'approve', label: '比价通过', variant: 'primary', from: [1] },
      { key: 'reject', label: '比价淘汰', variant: 'danger', from: [1] },
      { key: 'execute', label: '确定供应商', variant: 'primary', from: [2] },
      { key: 'void', label: '作废', variant: 'danger', from: [0, 1, 2] },
    ],
    defaults: () => ({ quoteNo: no('PQ'), qty: 1, price: 0, amount: 0, validUntil: today(), status: 0 }),
  },
  contracts: {
    title: '采购合同', api: '/api/v1/purchase/contracts', collection: 'purchaseContracts',
    columns: [{ prop: 'contractNo', label: '合同编号' }, { prop: 'name', label: '合同名称' }, { prop: 'supplierId', label: '供应商', source: 'suppliers' }, { prop: 'amount', label: '合同金额' }, { prop: 'signDate', label: '签订日期' }, { prop: 'status', label: '状态' }],
    fields: [
      { prop: 'contractNo', label: '合同编号', required: true }, { prop: 'name', label: '合同名称', required: true },
      supplierField(), { prop: 'amount', label: '合同金额', type: 'number', required: true },
      { prop: 'signDate', label: '签订日期', type: 'date' }, { prop: 'remark', label: '合同条款', type: 'textarea' }, docStatusField(),
    ],
    statusField: 'status', statusLabels: DOC_STATUS, actions: docActions,
    defaults: () => ({ contractNo: no('PC'), amount: 0, signDate: today(), status: 0 }),
  },
  outsource: {
    title: '委外加工', api: '/api/v1/purchase/outsource', collection: 'purchaseOutsource',
    columns: [{ prop: 'orderNo', label: '委外单号' }, { prop: 'supplierId', label: '加工方', source: 'suppliers' }, { prop: 'productName', label: '加工产品' }, { prop: 'qty', label: '数量' }, { prop: 'amount', label: '加工费' }, { prop: 'planDate', label: '计划完成日' }, { prop: 'status', label: '状态' }],
    fields: [
      { prop: 'orderNo', label: '委外单号', required: true }, supplierField(),
      { prop: 'productName', label: '加工产品', required: true }, { prop: 'qty', label: '数量', type: 'number', required: true },
      { prop: 'amount', label: '加工费', type: 'number' }, { prop: 'planDate', label: '计划完成日', type: 'date' }, docStatusField(),
    ],
    statusField: 'status', statusLabels: DOC_STATUS,
    actions: [
      { key: 'submit', label: '下发委外', variant: 'primary', from: [0] },
      { key: 'approve', label: '加工确认', variant: 'primary', from: [1] },
      { key: 'execute', label: '完工入库', variant: 'primary', from: [2] },
      { key: 'void', label: '作废', variant: 'danger', from: [0, 1, 2] },
    ],
    defaults: () => ({ orderNo: no('OW'), qty: 1, amount: 0, planDate: today(), status: 0 }),
  },
  logistics: {
    title: '物流跟踪', api: '/api/v1/purchase/logistics', collection: 'purchaseLogistics',
    columns: [{ prop: 'logisticsNo', label: '物流单号' }, { prop: 'orderId', label: '采购单' }, { prop: 'carrier', label: '承运商' }, { prop: 'trackingNo', label: '运单号' }, { prop: 'shipDate', label: '发货日期' }, { prop: 'arriveDate', label: '到货日期' }, { prop: 'status', label: '状态' }],
    fields: [
      { prop: 'logisticsNo', label: '物流单号', required: true },
      { prop: 'orderId', label: '采购单', type: 'select', source: 'orders' },
      { prop: 'carrier', label: '承运商', type: 'select', options: [{ label: '顺丰速运', value: '顺丰速运' }, { label: '中通快递', value: '中通快递' }, { label: '京东物流', value: '京东物流' }] },
      { prop: 'trackingNo', label: '运单号' }, { prop: 'shipDate', label: '发货日期', type: 'date' }, { prop: 'arriveDate', label: '到货日期', type: 'date' },
      { prop: 'remark', label: '物流备注', type: 'textarea' }, docStatusField(),
    ],
    statusField: 'status', statusLabels: DOC_STATUS,
    actions: [
      { key: 'submit', label: '已发货', variant: 'primary', from: [0] },
      { key: 'approve', label: '已到货', variant: 'primary', from: [1] },
      { key: 'execute', label: '已签收', variant: 'primary', from: [2] },
      { key: 'void', label: '作废', variant: 'danger', from: [0, 1, 2] },
    ],
    defaults: () => ({ logisticsNo: no('WL'), carrier: '顺丰速运', shipDate: today(), status: 0 }),
  },
  prices: {
    title: '采购价目表', api: '/api/v1/purchase/prices', collection: 'purchasePrices',
    columns: [{ prop: 'supplierId', label: '供应商', source: 'suppliers' }, { prop: 'productId', label: '产品' }, { prop: 'productName', label: '产品名称' }, { prop: 'price', label: '采购价' }, { prop: 'minQty', label: '起订量' }, { prop: 'effectiveDate', label: '生效日期' }, { prop: 'status', label: '状态' }],
    fields: [
      supplierField(), { prop: 'productId', label: '产品', type: 'select', source: 'products', required: true },
      { prop: 'productName', label: '产品名称', required: true }, { prop: 'price', label: '采购价', type: 'number', required: true },
      { prop: 'minQty', label: '起订量', type: 'number' }, { prop: 'effectiveDate', label: '生效日期', type: 'date' }, masterStatusField(),
    ],
    statusField: 'status', statusLabels: MASTER_STATUS, actions: masterActions,
    defaults: () => ({ price: 0, minQty: 0, effectiveDate: today(), status: 1 }),
  },
  'on-time': {
    title: '到货及时率', api: '/api/v1/purchase/on-time', collection: 'purchaseOnTime', readOnly: true,
    columns: [{ prop: 'supplierName', label: '供应商' }, { prop: 'period', label: '期间' }, { prop: 'totalOrders', label: '订单数' }, { prop: 'onTimeOrders', label: '准时数' }, { prop: 'rate', label: '及时率(%)' }],
    fields: [], statusField: 'status',
  },
};

export function purchaseConfigFor(key: string): SalesConfig {
  const c = PURCHASE_CONFIGS[key];
  if (!c) throw new Error(`未知采购页面配置：${key}`);
  return c;
}
