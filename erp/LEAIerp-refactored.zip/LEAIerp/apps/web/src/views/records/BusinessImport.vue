<template>
  <div class="erp-page">
    <DsCard :title="config.title">
      <template #extra>
        <RouterLink :to="config.listPath" class="ds-btn ds-btn-default ds-btn-sm">{{ config.listLabel }}</RouterLink>
      </template>
      <p>选择 CSV 文件或粘贴 Excel 表格，校验后可提交通过的记录。</p>
      <div class="record-buttons import-tools">
        <DsButton size="sm" @click="template">下载模板</DsButton>
        <input type="file" accept=".csv,.tsv,.txt,text/csv" aria-label="选择导入文件" :disabled="busy" @change="readFile" />
      </div>
      <textarea v-model="source" class="ds-input import-text" rows="7" aria-label="导入内容" :disabled="busy" @input="onPasteEdit" />
      <div class="record-buttons import-tools">
        <DsButton size="sm" :loading="checking" :disabled="busy" @click="preview">预览和校验</DsButton>
        <DsButton size="sm" variant="primary" :loading="saving" :disabled="busy || !ready.length" @click="save">导入 {{ ready.length }} 行</DsButton>
      </div>
      <p v-if="error" class="record-error" role="alert">{{ error }}</p>
      <p v-if="finished" role="status">本次导入成功 {{ successCount }} 行，失败或未通过 {{ batch.length - successCount }} 行。</p>
      <div v-if="batch.length" class="record-table">
        <table class="ds-table">
          <thead><tr><th>行</th><th v-for="label in config.fields" :key="label">{{ label }}</th><th>结果</th></tr></thead>
          <tbody>
            <tr v-for="row in batch" :key="row.line">
              <td>{{ row.line }}</td><td v-for="key in Object.keys(config.fields)" :key="key">{{ row.values[key] }}</td>
              <td :class="{ 'record-error': row.error }">{{ row.error || (row.saved ? '已导入' : '待导入') }}</td>
            </tr>
          </tbody>
        </table>
      </div>
      <DsButton v-if="batch.some((row) => row.error)" size="sm" @click="downloadErrors">下载错误明细</DsButton>
    </DsCard>
  </div>
</template>

<script setup lang="ts">
import { computed, ref } from 'vue';
import { DsButton, DsCard } from '../../components';
import { parseImport, type ImportConfig, type ImportLine } from './importRows';
import { downloadRecords } from './records';

const { config } = defineProps<{ config: ImportConfig }>();
const source = ref('');
const filename = ref('粘贴导入');
const batch = ref<Array<ImportLine & { saved?: boolean }>>([]);
const error = ref('');
const checking = ref(false);
const saving = ref(false);
const finished = ref(false);
const busy = computed(() => checking.value || saving.value);
const ready = computed(() => finished.value ? [] : batch.value.filter((row) => !row.error && !row.saved));
const successCount = computed(() => batch.value.filter((row) => row.saved).length);
const fields = Object.keys(config.fields);

function template() {
  downloadRecords(config.title + '模板', fields, [fields.map((field) => config.example[field] ?? '')]);
}

function clearPreview() {
  batch.value = [];
  finished.value = false;
  error.value = '';
}

function onPasteEdit() {
  filename.value = '粘贴导入';
  clearPreview();
}

async function readFile(event: Event) {
  const file = (event.target as HTMLInputElement).files?.[0];
  if (!file) return;
  clearPreview();
  source.value = '';
  if (file.size > 2_000_000) { error.value = '请选择小于 2 MB 的 CSV 文件'; return; }
  filename.value = file.name;
  checking.value = true;
  try {
    source.value = await file.text();
  } catch {
    error.value = '无法读取文件';
  } finally {
    checking.value = false;
  }
}

async function preview() {
  if (busy.value) return;
  if (finished.value) { error.value = '请修改导入内容后重新校验'; return; }
  clearPreview();
  checking.value = true;
  try {
    const rows = parseImport(source.value, config);
    await config.prepare?.(rows);
    batch.value = rows;
  } catch (cause) {
    error.value = cause instanceof Error ? cause.message : '校验失败';
  } finally {
    checking.value = false;
  }
}

async function save() {
  if (busy.value || !ready.value.length) return;
  saving.value = true;
  error.value = '';
  try {
    for (const row of ready.value) {
      try {
        await config.save(row.values);
        row.saved = true;
      } catch (cause) {
        row.error = cause instanceof Error ? cause.message : '保存失败';
      }
    }
    finished.value = true;
    await config.complete?.(filename.value, successCount.value, batch.value.length - successCount.value);
  } catch (cause) {
    error.value = cause instanceof Error ? '写入导入记录失败：' + cause.message : '写入导入记录失败';
  } finally {
    saving.value = false;
  }
}

function downloadErrors() {
  downloadRecords(config.title + '错误明细', [...fields, '行', '错误'], batch.value.filter((row) => row.error).map((row) => [
    ...fields.map((field) => row.values[field] ?? ''), String(row.line), row.error!,
  ]));
}
</script>

<style src="./recordPage.css"></style>
<style scoped>
.import-tools { margin-block: 12px; }
.import-text { width: 100%; box-sizing: border-box; }
</style>
