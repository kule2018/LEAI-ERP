<template>
  <div class="erp-page record-page">
    <header class="record-header">
      <div>
        <h2>{{ config.title }}</h2>
        <p v-if="config.reportSource">{{ config.reportSource }}</p>
      </div>
      <div class="record-buttons">
        <RouterLink v-if="config.link" :to="config.link.to" class="ds-btn ds-btn-default ds-btn-sm">
          {{ config.link.label }}
        </RouterLink>
        <DsButton size="sm" @click="download" :disabled="!rows.length">导出本页</DsButton>
        <DsButton v-if="canWrite" variant="primary" size="sm" @click="openForm()">新建{{ config.title }}</DsButton>
      </div>
    </header>

    <section v-if="metrics.length" class="record-metrics" aria-label="本页统计">
      <div><span>符合条件记录</span><strong>{{ total }}</strong></div>
      <div v-for="metric in metrics" :key="metric.field.prop">
        <span>本页{{ metric.field.label }}</span><strong>{{ display(metric.field, metric.total) }}</strong>
      </div>
    </section>

    <DsCard :pad="false">
      <form class="record-filters" @submit.prevent="search">
        <label>关键字<input v-model.trim="keyword" class="ds-input" type="search" :placeholder="filterPlaceholder" /></label>
        <label v-for="field in filterFields" :key="field.prop">
          {{ field.label }}
          <select v-if="field.options?.length" v-model="filters[field.prop]" class="ds-select">
            <option value="">全部</option>
            <option v-for="option in field.options" :key="option.value" :value="String(option.value)">{{ option.label }}</option>
          </select>
          <input v-else v-model.trim="filters[field.prop]" class="ds-input" :type="field.type === 'date' ? 'date' : 'text'" />
        </label>
        <div class="record-buttons">
          <DsButton variant="primary" size="sm" type="submit">查询</DsButton>
          <DsButton size="sm" @click="reset">重置</DsButton>
        </div>
      </form>

      <div class="record-table" :aria-busy="loading">
        <table class="ds-table">
          <thead><tr><th v-for="field in fields" :key="field.prop" scope="col">{{ field.label }}</th><th scope="col">操作</th></tr></thead>
          <tbody>
            <tr v-if="loading || error || !rows.length">
              <td :colspan="fields.length + 1" class="record-empty">
                <span v-if="loading" role="status">正在加载数据…</span>
                <template v-else-if="error">
                  <span role="alert">{{ error }}</span>
                  <DsButton size="sm" @click="load">重试</DsButton>
                </template>
                <span v-else>暂无符合条件的{{ config.title }}记录</span>
              </td>
            </tr>
            <tr v-else v-for="row in rows" :key="row.id ?? (row.rankNo ? [row.rankNo, row.skuCode, row.productName].join('/') : row.period ? [row.period, row.customerName, row.supplierName].join('/') : row.name ?? row.item)">
              <td v-for="field in fields" :key="field.prop">
                <DsTag v-if="field.prop === schema?.statusField" size="sm" color="neutral">{{ display(field, row[field.prop]) }}</DsTag>
                <template v-else>{{ display(field, row[field.prop]) }}</template>
              </td>
              <td>
                <div class="record-buttons">
                  <DsButton variant="text" size="sm" @click="detail = row">详情</DsButton>
                  <DsButton v-if="canEdit(row)" variant="text" size="sm" @click="openForm(row)">编辑</DsButton>
                  <DsButton v-for="action in actionsFor(row)" :key="action.key" variant="text" size="sm"
                    :disabled="acting" @click="runAction(row, action)">{{ action.label }}</DsButton>
                </div>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
      <div class="record-pagination">
        <DsPagination v-model:current-page="page" :page-size="pageSize" :total="total" layout="total, prev, pager, next" @change="load" />
      </div>
    </DsCard>

    <DsModal :model-value="!!detail" :title="config.title + '详情'" :width="620" @update:model-value="detail = null">
      <dl v-if="detail" class="record-detail">
        <div v-for="field in detailFields" :key="field.prop"><dt>{{ field.label }}</dt><dd>{{ display(field, detail[field.prop]) }}</dd></div>
      </dl>
    </DsModal>

    <DsModal v-model="formOpen" :title="(editing ? '编辑' : '新建') + config.title" :width="620">
      <form ref="formRef" class="record-form" @submit.prevent="save">
        <label v-for="field in formFields" :key="field.prop">
          {{ field.label }}{{ config.required?.includes(field.prop) ? ' *' : '' }}
          <select v-if="field.options?.length" v-model="draft[field.prop]" class="ds-select" :required="config.required?.includes(field.prop)">
            <option value="">请选择</option>
            <option v-for="option in field.options" :key="option.value" :value="String(option.value)">{{ option.label }}</option>
          </select>
          <textarea v-else-if="field.type === 'textarea'" v-model="draft[field.prop]" class="ds-input" rows="3" :required="config.required?.includes(field.prop)" />
          <input v-else :value="draft[field.prop]" class="ds-input" :type="inputType(field)" :step="numberStep(field)" :required="config.required?.includes(field.prop)" @input="draft[field.prop] = ($event.target as HTMLInputElement).value" />
        </label>
      </form>
      <p v-if="saveError" class="record-error" role="alert">{{ saveError }}</p>
      <template #footer>
        <DsButton :disabled="saving" @click="formOpen = false">取消</DsButton>
        <DsButton variant="primary" :loading="saving" @click="save">保存</DsButton>
      </template>
    </DsModal>
  </div>
</template>

<script setup lang="ts">
import { computed, onBeforeUnmount, onMounted, reactive, ref } from 'vue';
import Decimal from 'decimal.js';
import { DsButton, DsCard, DsModal, DsPagination, DsTag } from '../../components';
import { useToast } from '../../components/ds/toast';
import { confirm } from '../../components/ds/useConfirm';
import { pageData, pageRows, type BusinessRow } from '../../api/pageData';
import { getEntitySchema, type EntityField } from '../../config/entitySchemas';
import { downloadRecords, fieldDisplay as display, type RecordAction, type RecordPageConfig } from './records';

const { config } = defineProps<{ config: RecordPageConfig }>();
const toast = useToast();
const schema = getEntitySchema(config.schema);
const allFields = config.columns ?? schema?.fields ?? [];
const fields = allFields.filter((field) => !['id', ...(config.omitFields ?? [])].includes(field.prop));
const detailFields = fields;
const filters = reactive<Record<string, string>>({});
const filterFields = allFields.filter((field) => config.filters.includes(field.prop));
const filterPlaceholder = filterFields.map((field) => field.label).join('、') || '搜索记录';
const formFields = allFields.filter((field) => field.prop !== 'id' && field.form !== false && !(config.initialStatus !== undefined && field.prop === schema?.statusField));
const canWrite = Boolean(config.required?.length);
const api = config.endpoint ?? `/api/v1/${config.resource}`;

const keyword = ref('');
const applied = ref<Record<string, string>>({});
const rows = ref<BusinessRow[]>([]);
const total = ref(0);
const pageSize = 10;
const page = ref(1);
const loading = ref(false);
const error = ref('');
const detail = ref<BusinessRow | null>(null);
const editing = ref<BusinessRow | null>(null);
const formOpen = ref(false);
const formRef = ref<HTMLFormElement | null>(null);
const draft = reactive<Record<string, string>>({});
const saving = ref(false);
const saveError = ref('');
const acting = ref(false);
let requestId = 0;

const metrics = computed(() => fields.filter((field) => config.metrics?.includes(field.prop)).map((field) => ({
  field,
  total: rows.value.reduce((sum, row) => {
    const value = row[field.prop];
    return /^-?\d+(?:\.\d+)?$/.test(String(value)) ? sum.plus(value) : sum;
  }, new Decimal(0)).toFixed(field.type === 'money' ? 2 : 3),
})));

async function load() {
  const id = ++requestId;
  loading.value = true;
  error.value = '';
  try {
    const query = { ...applied.value, page: page.value, pageSize };
    const response = await pageData<BusinessRow[] | { list: BusinessRow[]; total: number }>('GET', api, query);
    if (id !== requestId) return;
    if (!Array.isArray(response) && !Array.isArray(response?.list)) throw new Error('接口返回了无法识别的列表');
    const list = pageRows(response);
    if (Array.isArray(response)) {
      const matches = list.filter((row) => Object.entries(applied.value).every(([key, value]) => {
        if (key === 'keyword') return fields.some((field) => display(field, row[field.prop]).toLowerCase().includes(value.toLowerCase()));
        const field = allFields.find((column) => column.prop === key);
        return field?.type === 'date' ? String(row[key] ?? '').slice(0, 10) === value : String(row[key] ?? '').toLowerCase() === value.toLowerCase();
      }));
      total.value = matches.length;
      rows.value = matches.slice((page.value - 1) * pageSize, page.value * pageSize);
    } else {
      rows.value = list;
      total.value = response.total;
    }
  } catch (cause) {
    if (id !== requestId) return;
    rows.value = [];
    total.value = 0;
    error.value = cause instanceof Error ? cause.message : '加载失败，请重试';
  } finally {
    if (id === requestId) loading.value = false;
  }
}

function search() {
  applied.value = Object.fromEntries(Object.entries({ ...filters, keyword: keyword.value }).filter(([, value]) => value));
  page.value = 1;
  void load();
}

function reset() {
  keyword.value = '';
  for (const field of filterFields) filters[field.prop] = '';
  search();
}

function canEdit(row: BusinessRow) {
  return canWrite && (!config.editStatus || config.editStatus.includes(Number(row[schema?.statusField ?? 'status'])));
}

function actionsFor(row: BusinessRow) {
  return (config.actions ?? []).filter((action) => action.from.includes(Number(row[schema?.statusField ?? 'status'])));
}

function openForm(row?: BusinessRow) {
  editing.value = row ?? null;
  for (const field of formFields) {
    const value = row?.[field.prop];
    draft[field.prop] = value == null ? '' : field.type === 'date' ? String(value).slice(0, 10) : field.type === 'datetime' ? String(value).replace(' ', 'T').slice(0, 16) : String(value);
  }
  saveError.value = '';
  formOpen.value = true;
}

function inputType(field: EntityField) {
  if (field.prop.endsWith('Color')) return 'color';
  if (field.prop === 'email') return 'email';
  if (field.prop === 'callbackUrl') return 'url';
  if (field.type === 'number' || field.type === 'money') return 'number';
  if (field.type === 'datetime') return 'datetime-local';
  return field.type === 'date' ? 'date' : 'text';
}

function numberStep(field: EntityField) {
  return field.type === 'money' ? '0.01' : field.type === 'number' ? 'any' : undefined;
}

async function save() {
  if (saving.value || !canWrite) return;
  if (!formRef.value?.reportValidity()) return;
  const missing = formFields.find((field) => config.required?.includes(field.prop) && !draft[field.prop]?.trim());
  if (missing) { saveError.value = `请填写${missing.label}`; return; }
  const payload: BusinessRow = {};
  for (const field of formFields) {
    const value = draft[field.prop]?.trim();
    if (value) payload[field.prop] = field.options?.find((option) => String(option.value) === value)?.value ?? value;
    else if (editing.value && !['date', 'datetime', 'number', 'money', 'select'].includes(field.type ?? '')) payload[field.prop] = '';
  }
  if (!editing.value && config.initialStatus !== undefined) payload[schema?.statusField ?? 'status'] = config.initialStatus;
  saving.value = true;
  saveError.value = '';
  try {
    if (editing.value) await pageData('PATCH', `${api}/${editing.value.id}`, payload);
    else await pageData('POST', api, payload);
    formOpen.value = false;
    toast.success('已保存');
    await load();
  } catch (cause) {
    saveError.value = cause instanceof Error ? cause.message : '保存失败';
  } finally {
    saving.value = false;
  }
}

async function runAction(row: BusinessRow, action: RecordAction) {
  if (acting.value) return;
  acting.value = true;
  try {
    const accepted = await confirm(`确定${action.label}这条${config.title}记录？`, action.label);
    if (!accepted) return;
    await pageData('POST', `/api/v1/sales-ext/action/${config.schema}/${row.id}/${action.key}`, { label: action.label });
    toast.success(`${action.label}成功`);
    await load();
  } catch (cause) {
    toast.error(cause instanceof Error ? cause.message : '操作失败');
  } finally {
    acting.value = false;
  }
}

function download() {
  downloadRecords(config.title, fields.map((field) => field.label), rows.value.map((row) => fields.map((field) => display(field, row[field.prop]))));
}

onMounted(search);
onBeforeUnmount(() => { requestId++; });
</script>

<style src="./recordPage.css"></style>
