export type ImportValues = Record<string, string>;
export interface ImportLine { line: number; values: ImportValues; error?: string }
export interface ImportConfig {
  title: string;
  fields: Record<string, string>;
  required: string[];
  example: ImportValues;
  listPath: string;
  listLabel: string;
  validate: (values: ImportValues) => string | undefined;
  prepare?: (lines: ImportLine[]) => Promise<void>;
  save: (values: ImportValues) => Promise<unknown>;
  complete?: (file: string, success: number, failed: number) => Promise<unknown>;
}

/** 解析逗号 CSV 和 Excel 粘贴的制表符文本，保留引号内的逗号与换行。 */
export function parseImport(text: string, config: ImportConfig): ImportLine[] {
  const source = text.replace(/^\ufeff/, '').trimEnd();
  const delimiter = source.split(/\r?\n/, 1)[0].includes('\t') ? '\t' : ',';
  const rows: string[][] = [];
  let cells: string[] = [];
  let cell = '';
  let quoted = false;
  for (let i = 0; i < source.length; i++) {
    const ch = source[i];
    if (ch === '"') {
      if (quoted && source[i + 1] === '"') { cell += '"'; i++; }
      else if (quoted || !cell) quoted = !quoted;
      else cell += ch;
    } else if (!quoted && ch === delimiter) {
      cells.push(cell.trim());
      cell = '';
    } else if (!quoted && (ch === '\r' || ch === '\n')) {
      cells.push(cell.trim());
      rows.push(cells);
      cells = [];
      cell = '';
      if (ch === '\r' && source[i + 1] === '\n') i++;
    } else {
      cell += ch;
    }
  }
  if (quoted) throw new Error('文件中有未闭合的引号');
  rows.push([...cells, cell.trim()]);
  const [heads, ...body] = rows;
  const supported = Object.keys(config.fields);
  const keys = heads.map((name) => supported.find((key) => key === name || config.fields[key] === name));
  if (keys.some((key) => !key) || new Set(keys).size !== keys.length) throw new Error('表头含未知或重复的列，请使用本页模板');
  const missing = config.required.filter((key) => !keys.includes(key));
  if (missing.length) throw new Error(`缺少列：${missing.map((key) => config.fields[key]).join('、')}`);
  if (!body.some((row) => row.some(Boolean))) throw new Error('请录入至少一行数据');
  if (body.length > 200) throw new Error('每批最多导入 200 行，请拆分文件');

  return body.flatMap((row, index) => {
    if (!row.some(Boolean)) return [];
    const values = Object.fromEntries(keys.map((key, col) => [key!, row[col] ?? '']));
    const required = config.required.find((key) => !values[key]);
    const error = row.length > keys.length ? '列数超过表头'
      : required ? `${config.fields[required]}不能为空` : config.validate(values);
    return [{ line: index + 2, values, error }];
  });
}
