import { toRaw } from 'vue';
import { pageData, pageRows, type BusinessRow } from '../../api/pageData';
import { findProduct } from '../inventory/productImport';
import type { ImportConfig, ImportValues } from './importRows';

async function resolveId(path: string, value: string): Promise<number | undefined> {
  const pageSize = 100;
  for (let page = 1; ; page++) {
    const response = await pageData<BusinessRow[] | { total: number; list: BusinessRow[] }>('GET', path, { page, pageSize });
    const rows = pageRows(response);
    const match = rows.find((row) => String(row.id) === value || String(row.code || '').toLowerCase() === value.toLowerCase());
    if (match || Array.isArray(response) || !rows.length || page * pageSize >= response.total) return match?.id;
  }
}

export function orderImport(purchase: boolean): ImportConfig {
  const kind = purchase ? 'purchase' : 'sales';
  const name = purchase ? '采购' : '销售';
  const partner = purchase ? '供应商' : '客户';
  const partnerApi = purchase ? 'purchase/suppliers' : 'crm/customers';
  const fields = { partner: partner + '编码或 ID', warehouse: '仓库编码或 ID', product: '产品编码', qty: '数量', unitPrice: '单价', remark: '备注' };
  const resolved = new WeakMap<ImportValues, { partnerId: number; warehouseId: number; productId: number }>();

  return {
    title: name + '批量导入',
    fields,
    required: ['partner', 'warehouse', 'product', 'qty', 'unitPrice'],
    example: { partner: '1', warehouse: '1', product: 'P0001', qty: '10', unitPrice: '12.50' },
    listPath: `/${kind}/orders`,
    listLabel: name + '订单',
    validate(values) {
      if (!/^\d{1,12}(?:\.\d{1,3})?$/.test(values.qty) || Number(values.qty) <= 0) return '数量须大于零且最多三位小数';
      if (!/^\d{1,12}(?:\.\d{1,2})?$/.test(values.unitPrice)) return '单价须为非负金额且最多两位小数';
    },
    async prepare(rows) {
      const partners = new Map<string, number | undefined>();
      const warehouses = new Map<string, number | undefined>();
      const products = new Map<string, BusinessRow | undefined>();
      for (const row of rows) {
        if (row.error) continue;
        const { partner: partnerCode, warehouse, product } = row.values;
        if (!partners.has(partnerCode)) partners.set(partnerCode, await resolveId('/api/v1/' + partnerApi, partnerCode));
        if (!warehouses.has(warehouse)) warehouses.set(warehouse, await resolveId('/api/v1/inventory/warehouses', warehouse));
        if (!products.has(product)) products.set(product, await findProduct(product));
        const partnerId = partners.get(partnerCode);
        const warehouseId = warehouses.get(warehouse);
        const productId = products.get(product)?.id;
        if (!partnerId || !warehouseId || !productId) {
          row.error = !partnerId ? partner + '不存在' : !warehouseId ? '仓库不存在' : '产品不存在';
          continue;
        }
        if (Number(products.get(product)?.type) === 2 || Number(products.get(product)?.type) === 3) {
          row.error = '多规格或序列号产品请在订单表单中选取明细';
          continue;
        }
        resolved.set(row.values, { partnerId, warehouseId, productId });
      }
    },
    save(values) {
      const ids = resolved.get(toRaw(values));
      if (!ids) throw new Error('请重新校验主数据');
      const { partnerId, warehouseId, productId } = ids;
      return pageData('POST', `/api/v1/${kind}/orders`, {
        [purchase ? 'supplierId' : 'customerId']: partnerId,
        warehouseId,
        lines: [{ productId, warehouseId, qty: values.qty, unitPrice: values.unitPrice }],
        remark: values.remark,
      });
    },
    complete: purchase ? (fileName, successRows, failRows) => pageData('POST', '/api/v1/purchase/imports', {
      batchNo: 'IMP-' + crypto.randomUUID().slice(0, 12),
      fileName, successRows, failRows, totalRows: successRows + failRows, status: successRows ? '完成' : '失败',
    }) : undefined,
  };
}
