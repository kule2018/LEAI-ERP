import Decimal from 'decimal.js';
import type { EntityField } from '../../config/schemaOverrides/types';
import { maskField } from '../../utils/mask';

export interface RecordAction {
  key: string;
  label: string;
  from: number[];
}

export interface RecordPageConfig {
  title: string;
  resource: string;
  schema: string;
  filters: string[];
  required?: string[];
  editStatus?: number[];
  initialStatus?: string | number;
  actions?: RecordAction[];
  link?: { to: string; label: string };
  omitFields?: string[];
  metrics?: string[];
  endpoint?: string;
  columns?: EntityField[];
  reportSource?: string;
}

export function fieldDisplay(field: EntityField, raw: unknown): string {
  const value = maskField(field.prop, raw);
  if (value === undefined || value === null || value === '') return '—';
  const option = field.options?.find((item) => String(item.value) === String(value));
  if (option) return option.label;
  if (field.type === 'date') return String(value).slice(0, 10);
  if (field.type === 'money' && /^-?\d+(?:\.\d+)?$/.test(String(value))) {
    return new Decimal(value).toFixed(2);
  }
  return String(value);
}

export function downloadRecords(filename: string, header: string[], rows: string[][]): void {
  const escape = (value: string) => {
    const safe = /^[\s]*[=+@\-]/.test(value) && !/^-\d+(?:\.\d+)?$/.test(value) ? "'" + value : value;
    return '"' + safe.replaceAll('"', '""') + '"';
  };
  const csv = [header, ...rows].map((line) => line.map(escape).join(',')).join('\r\n');
  const url = URL.createObjectURL(new Blob(['\ufeff', csv], { type: 'text/csv;charset=utf-8' }));
  const link = document.createElement('a');
  link.href = url;
  link.download = `${filename}.csv`;
  link.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
