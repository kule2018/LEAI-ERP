<template><OrderForm /></template>

<script setup lang="ts">
import OrderForm from './order-form.vue';
</script>
