<template><BusinessImport :config="config" /></template>

<script setup lang="ts">
import BusinessImport from '../records/BusinessImport.vue';
import { orderImport } from '../records/orderImport';

const config = orderImport(false);
</script>
