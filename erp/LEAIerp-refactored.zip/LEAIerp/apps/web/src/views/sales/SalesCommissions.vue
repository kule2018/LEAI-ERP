<template><RecordPage :config="page" /></template>

<script setup lang="ts">
import RecordPage from '../records/RecordPage.vue';
import type { RecordPageConfig } from '../records/records';

const page: RecordPageConfig = {
  title: '佣金规则',
  resource: 'sales/commissions',
  schema: 'salesCommissions',
  filters: ['salesman', 'period', 'status'],
  required: ['name', 'salesman', 'rate', 'period'],
};
</script>
