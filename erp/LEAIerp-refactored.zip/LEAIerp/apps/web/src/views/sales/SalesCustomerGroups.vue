
<template><div class="u-page">
<div class="u-head"><div><div class="u-kicker">CARDS · 客户分组</div><h2>客户分组</h2></div><div class="u-actions"><DsButton size="sm" @click="load">刷新</DsButton><DsButton size="sm" @click="exportCsv">导出</DsButton><DsButton variant="primary" size="sm" @click="openForm()">＋ 新建</DsButton></div></div>
<div class="u-stats"><div v-for="s in statVals" :key="s.label" class="u-stat"><span>{{s.label}}</span><b>{{s.unit=== '¥'?'¥':'' }}{{s.value}}{{s.unit&&s.unit!=='¥'?s.unit:''}}</b></div></div>
<div class="u-search"><input v-model="q.keyword" class="ds-input" placeholder="搜索…" @keyup.enter="reload"/><select v-if="hasStatus" v-model="q.status" class="ds-input"><option value="">全部状态</option><option v-for="(l,v) in statusLabels" :key="v" :value="v">{{l}}</option></select><DsButton variant="primary" size="sm" @click="reload">查询</DsButton><DsButton size="sm" @click="resetQuery">重置</DsButton></div>
<div class="u-cards"><div v-for="r in rows" :key="r.id" class="u-card" @click="openForm(r)"><div class="u-card-top"><span class="u-avatar">{{ (r.name||'?').slice(0,1) }}</span><b>{{ r.name }}</b><em>{{ statusText(r.status) }}</em></div><div class="u-card-line"><small>编码</small><span>{{ r.code }}</span></div><div class="u-card-line"><small>说明</small><span>{{ display(r,{prop:'remark',label:'说明',type:'text',options:[],source:''}) }}</span></div><div class="u-card-ops"><DsButton size="sm" variant="text" @click.stop="openForm(r)">编辑</DsButton><DsButton v-for="a in actionsOf(r)" :key="a.key" size="sm" variant="text" @click.stop="runAction(r,a)">{{a.label}}</DsButton></div></div><div v-if="!rows.length" class="u-empty">暂无数据</div></div>
<div class="u-pager"><DsPagination v-model:current-page="page" :page-size="pageSize" :total="total" layout="total, prev, pager, next" @change="load"/></div>
<DsModal v-model="formVisible" :title="(editing?'编辑':'新建')+'客户分组'" :width="640"><div class="u-form"><label v-for="f in formFields" :key="f.prop" class="u-field"><span>{{f.label}}<i v-if="f.required">*</i></span><select v-if="f.type==='select'" v-model="form[f.prop]" class="ds-input"><option :value="''">请选择</option><option v-for="o in optionsOf(f)" :key="String(o.value)" :value="o.value">{{o.label}}</option></select><textarea v-else-if="f.type==='textarea'" v-model="form[f.prop]" class="ds-input" rows="3"></textarea><input v-else :type="f.type==='number'?'number':f.type==='date'?'date':'text'" v-model="form[f.prop]" class="ds-input"/></label></div><template #footer><div class="u-foot"><DsButton @click="formVisible=false">取消</DsButton><DsButton variant="primary" :loading="saving" @click="save">保存</DsButton></div></template></DsModal>
</div></template>

<script setup lang="ts">
import { ref, reactive, computed, onMounted } from 'vue';
import { mockGet, mockPost, mockPatch, mockDel } from '../../api/mockAdapter';
import { useToast } from '../../components/ds/toast';
import { confirm as uiConfirm } from '../../components/ds/useConfirm';
const toast=useToast();
const API="/api/v1/crm/customer-groups";
const COLLECTION="crmCustomerGroups";
const columns:any[]=[{"prop":"name","label":"分组名称","type":"text","options":null,"source":""},{"prop":"code","label":"分组编码","type":"text","options":null,"source":""},{"prop":"remark","label":"说明","type":"text","options":null,"source":""},{"prop":"status","label":"状态","type":"text","options":null,"source":""}];
const formFields:any[]=[{"prop":"name","label":"分组名称","type":"text","options":null,"source":"","required":true,"placeholder":""},{"prop":"code","label":"分组编码","type":"text","options":null,"source":"","required":true,"placeholder":""},{"prop":"remark","label":"分组说明","type":"textarea","options":null,"source":"","required":false,"placeholder":""},{"prop":"status","label":"状态","type":"select","options":[{"label":"启用","value":1},{"label":"停用","value":0}],"source":"","required":false,"placeholder":""}];
const statusLabels:Record<string,string>={"0":"停用","1":"启用"};
const actions:any[]=[{"key":"toggle","label":"停用","variant":"warning","from":[1]},{"key":"enable","label":"启用","variant":"primary","from":[0]},{"key":"copy","label":"复制","variant":"default","from":null}];
const DEFAULTS:any={"status":1};
const STATS:any[]=[{"label":"记录总数","expr":"rows.length","unit":""},{"label":"待处理","expr":"rows.filter(r=>Number(r.status)<=1).length","unit":""},{"label":"本页数据","expr":"page","unit":""}];
const hasStatus=Object.keys(statusLabels).length>0;
const isReport=false;
const arch="cards";
const q=reactive<{keyword:string;status:any}>({keyword:'',status:''});
const rows=ref<any[]>([]);const total=ref(0);const page=ref(1);const pageSize=ref(12);
const loading=ref(false);const saving=ref(false);const formVisible=ref(false);const editing=ref<any>(null);
const form=reactive<Record<string,any>>({});
const remoteOptions=reactive<Record<string,any[]>>({});
const statVals=computed(()=>STATS.map(s=>({label:s.label,unit:s.unit,value:evalStat(s.expr)})));
function sum(prop:string){return rows.value.reduce((a,r)=>a+(Number(r[prop])||0),0);}
function evalStat(expr:string){try{return new Function('rows','page','sum','rows_',expr)(rows.value,page.value,sum,rows.value);}catch{return 0;}}
function statusText(v:any){return statusLabels[String(v)]||String(v??'');}
function display(row:any,col:any){const v=row[col.prop];if(col.prop==='status'&&hasStatus)return statusText(v);if(col.options){const h=col.options.find((o:any)=>String(o.value)===String(v));if(h)return h.label;}const src=(remoteOptions as any)[col.source];if(src){const h=src.find((o:any)=>String(o.value)===String(v));if(h)return h.label;}if(v==null||v==='')return '—';const s=String(v);return /^\d{4}-\d{2}-\d{2}/.test(s)?s.slice(0,10):s;}
function optionsOf(f:any){return f.options||(remoteOptions as any)[f.source]||[];}
async function loadRemote(){const srcs:Record<string,string>={customers:'/api/v1/crm/customers',products:'/api/v1/inventory/products',orders:'/api/v1/sales/orders',groups:'/api/v1/crm/customer-groups',suppliers:'/api/v1/purchase/suppliers',warehouses:'/api/v1/inventory/warehouses'};const used=formFields.filter(f=>f.source).map(f=>f.source);await Promise.all(used.map(async s=>{if(remoteOptions[s])return;try{const d:any=await mockGet(srcs[s]||API,{pageSize:200});const list=Array.isArray(d)?d:d?.list||[];remoteOptions[s]=list.map((x:any)=>({label:x.name||x.code||x.title||('#'+x.id),value:x.id}));}catch{remoteOptions[s]=[];}}));}
async function load(){loading.value=true;try{const d:any=await mockGet(API,{page:page.value,pageSize:pageSize.value,keyword:q.keyword,status:q.status});rows.value=Array.isArray(d)?d:d?.list||[];total.value=Number(d?.total??rows.value.length);}catch(e:any){toast.error(e?.message||'加载失败');rows.value=[];}finally{loading.value=false;}}
function reload(){page.value=1;load();}
function resetQuery(){q.keyword='';q.status='';reload();}
function resetForm(){for(const k of Object.keys(form))delete form[k];for(const f of formFields)form[f.prop]=DEFAULTS[f.prop]??(f.type==='number'?0:'');}
function openForm(row?:any){editing.value=row||null;resetForm();if(row)for(const f of formFields)if(row[f.prop]!==undefined)form[f.prop]=row[f.prop];formVisible.value=true;}
async function save(){for(const f of formFields){if(f.required&&(form[f.prop]===''||form[f.prop]==null)){toast.warning('请填写「'+f.label+'」');return;}}saving.value=true;try{const payload:any={};for(const f of formFields)payload[f.prop]=form[f.prop];if(editing.value?.id)await mockPatch(API+'/'+editing.value.id,payload);else await mockPost(API,payload);toast.success(editing.value?'已保存':'已创建');formVisible.value=false;await load();}catch(e:any){toast.error(e?.message||'保存失败');}finally{saving.value=false;}}
function actionsOf(row:any){return actions.filter(a=>!a.from||a.from.some(s=>Number(s)===Number(row.status)));}
function colorOf(a:any){return a.variant==='danger'?'var(--ds-danger)':a.variant==='warning'?'var(--ds-warning)':'var(--ds-brand)';}
async function runAction(row:any,a:any){if(!await uiConfirm('确定执行「'+a.label+'」吗？','业务确认'))return;try{const res:any=await mockPost('/_biz/action/'+COLLECTION+'/'+row.id+'/'+a.key,{label:a.label});toast.success(res?.message||(a.label+'成功'));await load();}catch(e:any){toast.error(e?.message||'操作失败');}}
async function removeRow(row:any){if(!await uiConfirm('确定删除 #'+row.id+' 吗？','删除确认'))return;try{await mockDel(API+'/'+row.id);toast.success('已删除');await load();}catch(e:any){toast.error(e?.message||'删除失败');}}
function exportCsv(){const head=columns.map(c=>c.label);const lines=[head.join(',')].concat(rows.value.map(r=>columns.map(c=>String(display(r,c)).replace(/,/g,' ')).join(',')));const blob=new Blob(['\ufeff'+lines.join('\n')],{type:'text/csv;charset=utf-8'});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='客户分组.csv';a.click();}
onMounted(()=>{load();if(!isReport)loadRemote();});

</script>

<style scoped>
.u-page{padding:16px}.u-head{display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:14px}.u-kicker{font-size:11px;letter-spacing:1px;color:#ea580c;font-weight:700;margin-bottom:4px}.u-head h2{margin:0;font-size:20px}.u-actions{display:flex;gap:8px}.u-stats{display:flex;gap:12px;margin-bottom:14px}.u-stat{flex:1;background:var(--ds-bg-soft);border-left:3px solid #ea580c;border-radius:8px;padding:10px 14px;display:flex;flex-direction:column;gap:4px}.u-stat span{font-size:12px;color:var(--ds-text-3)}.u-stat b{font-size:20px}.u-search{display:flex;gap:8px;margin-bottom:12px;flex-wrap:wrap}.u-search input{min-width:200px}.u-pager{display:flex;justify-content:flex-end;padding:12px}.u-empty{text-align:center;color:var(--ds-text-3);padding:36px}.u-table-wrap{overflow:auto}.u-table{width:100%;border-collapse:collapse;font-size:13px}.u-table th,.u-table td{border:1px solid var(--ds-divider);padding:8px 10px;text-align:left}.u-table th{background:var(--ds-bg-soft)}.u-table-dense th,.u-table-dense td{padding:5px 8px;font-size:12px}.u-ops{white-space:nowrap}.u-form{display:grid;grid-template-columns:1fr 1fr;gap:14px}.u-field{display:flex;flex-direction:column;gap:5px;font-size:13px}.u-field i{color:var(--ds-danger);font-style:normal}.u-foot{display:flex;justify-content:flex-end;gap:8px}.u-cards{display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:12px}.u-card{background:var(--ds-bg-soft);border:1px solid var(--ds-divider);border-top:3px solid #ea580c;border-radius:10px;padding:14px;cursor:pointer}.u-card-top{display:flex;align-items:center;gap:8px;margin-bottom:10px}.u-avatar{width:34px;height:34px;border-radius:50%;background:#ea580c;color:#fff;display:flex;align-items:center;justify-content:center;font-weight:700}.u-card-top em{margin-left:auto;font-style:normal;font-size:11px;color:#ea580c}.u-card-line{display:flex;justify-content:space-between;font-size:12px;padding:3px 0}.u-card-line small{color:var(--ds-text-3)}.u-card-ops{border-top:1px solid var(--ds-divider);margin-top:8px;padding-top:6px}
</style>
