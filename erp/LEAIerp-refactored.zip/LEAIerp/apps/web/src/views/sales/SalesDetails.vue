<template><RecordPage :config="page" /></template>

<script setup lang="ts">
import RecordPage from '../records/RecordPage.vue';
import type { RecordPageConfig } from '../records/records';

const page: RecordPageConfig = {
  title: '销售明细',
  resource: 'sales/details',
  endpoint: '/api/v1/order-reports/sales-details',
  schema: 'salesDetails',
  filters: ['orderNo', 'customerName', 'productName', 'saleDate'],
  reportSource: '销售订单行汇总',
  metrics: ['qty', 'amount'],
};
</script>
