<!--
 * 业务页面渲染器：按 layout 选择完全不同的页面结构，不再所有页面共用同一张表格。
 * 数据仍全部来自 config.api -> MySQL，动作走 /_biz/action 真实落库。
-->
<template>
  <div class="page-shell" :class="'layout-' + layout">

    <!-- 1. 档案/主数据：左侧分组导航 + 右侧紧凑表格 -->
    <template v-if="layout === 'list'">
      <header class="ph-head ph-head--list">
        <div><span class="ph-kicker">MASTER DATA</span><h2>{{ config.title }}</h2></div>
        <div class="ph-head-actions"><DsButton size="sm" @click="reload">刷新</DsButton><DsButton variant="primary" size="sm" @click="openForm()">＋ 新建档案</DsButton></div>
      </header>
      <div class="master-layout">
        <aside class="master-rail">
          <div class="rail-title">档案分组</div>
          <button v-for="g in flowTabs.slice(0, 4)" :key="g.value" :class="{ on: String(q.status) === String(g.value) }" @click="setStatus(g.value)">{{ g.label }} <span>{{ g.count }}</span></button>
          <div class="rail-tip">按状态快速筛选档案</div>
        </aside>
        <section class="master-main">
          <div class="bar-search">
            <DsInput v-model="q.keyword" placeholder="搜索编码 / 名称" @keyup.enter="reload" />
            <DsButton variant="primary" size="sm" @click="reload">查询</DsButton>
            <DsButton size="sm" @click="resetQuery">重置</DsButton>
          </div>
          <DataTable v-bind="tableProps" v-on="tableEvents" />
        </section>
      </div>
    </template>

    <!-- 2. 单据流：状态流水线 + 流程摘要 + 单据表 -->
    <template v-else-if="layout === 'workflow'">
      <header class="ph-head ph-head--flow">
        <div><span class="ph-kicker">DOCUMENT FLOW</span><h2>{{ config.title }}</h2></div>
        <DsTag color="brand">{{ flowTabs.length }} 个流转节点</DsTag>
      </header>
      <div class="flow-pipeline">
        <button v-for="(s, i) in flowTabs" :key="s.value" :class="{ on: String(q.status) === String(s.value) }" @click="setStatus(s.value)">
          <i>{{ i + 1 }}</i><span>{{ s.label }}</span><b>{{ s.count }}</b>
        </button>
      </div>
      <div class="flow-summary">
        <div><span>待处理</span><b>{{ metrics.pending }}</b></div>
        <div><span>已完成</span><b>{{ countStatus(2) + countStatus(3) }}</b></div>
        <div><span>驳回</span><b>{{ countStatus(4) }}</b></div>
        <DsButton variant="primary" size="sm" @click="openForm()">＋ 新建单据</DsButton>
      </div>
      <DataTable v-bind="tableProps" v-on="tableEvents" />
    </template>

    <!-- 3. 经营分析：大指标卡 + 可视化条形 + 数据表 -->
    <template v-else-if="layout === 'analytics'">
      <header class="ph-head ph-head--analytics">
        <div><span class="ph-kicker">BUSINESS ANALYTICS</span><h2>{{ config.title }}</h2></div>
        <span class="analytics-period">数据周期：当前筛选结果</span>
      </header>
      <div class="analytics-metrics">
        <div v-for="m in metricCards" :key="m.label"><small>{{ m.label }}</small><b>{{ m.value }}</b><em>{{ m.hint }}</em></div>
      </div>
      <div class="analytics-chart">
        <div v-for="(r, i) in rows.slice(0, 6)" :key="r.id" class="chart-row">
          <span>{{ r.name || r.code || `#${r.id}` }}</span>
          <div class="chart-track"><i :style="{ width: Math.max(8, 100 - i * 13) + '%' }" /></div>
          <b>{{ Number(r.amount || 0).toFixed(0) }}</b>
        </div>
        <div v-if="!rows.length" class="chart-empty">暂无分析数据</div>
      </div>
      <div class="analytics-filter"><DsInput v-model="q.keyword" placeholder="搜索分析维度" @keyup.enter="reload" /><DsButton variant="primary" size="sm" @click="reload">刷新分析</DsButton></div>
      <DataTable v-bind="tableProps" v-on="tableEvents" />
    </template>

    <!-- 4. 仓储作业：库区概览 + 作业单表 -->
    <template v-else-if="layout === 'warehouse'">
      <header class="ph-head ph-head--warehouse"><div><span class="ph-kicker">WAREHOUSE OPERATION</span><h2>{{ config.title }}</h2></div><DsButton variant="primary" size="sm" @click="openForm()">＋ 新建作业</DsButton></header>
      <div class="zone-strip">
        <div v-for="(z, i) in ['收货区', '存储区', '拣货区', '出库区']" :key="z" :class="{ on: i === 1 }"><span>{{ z }}</span><b>{{ Math.max(0, metrics.count - i) }}</b><small>单据</small></div>
      </div>
      <div class="warehouse-note">当前作业量 {{ metrics.qty }} · 待处理 {{ metrics.pending }} 单</div>
      <DataTable v-bind="tableProps" v-on="tableEvents" />
    </template>

    <!-- 5. BOM：结构树 + 组件明细 -->
    <template v-else-if="layout === 'bom'">
      <header class="ph-head ph-head--bom"><div><span class="ph-kicker">BILL OF MATERIALS</span><h2>{{ config.title }}</h2></div><DsButton variant="primary" size="sm" @click="openForm()">＋ 新建结构</DsButton></header>
      <div class="bom-tree">
        <div class="bom-root">成品：{{ rows[0]?.name || config.title }}</div>
        <div v-for="(r, i) in rows.slice(0, 5)" :key="r.id" class="bom-node" :style="{ marginLeft: (i % 3) * 28 + 'px' }">
          <span class="bom-dot" /> {{ r.productName || r.name || r.code }} <b>× {{ r.qty || 1 }}</b>
        </div>
      </div>
      <DataTable v-bind="tableProps" v-on="tableEvents" />
    </template>

    <!-- 6. 看板：任务卡片列，不使用表格 -->
    <template v-else-if="layout === 'kanban'">
      <header class="ph-head ph-head--kanban"><div><span class="ph-kicker">TASK BOARD</span><h2>{{ config.title }}</h2></div><DsButton variant="primary" size="sm" @click="openForm()">＋ 新建任务</DsButton></header>
      <div class="kanban-board">
        <div v-for="g in kanbanGroups" :key="g.value" class="kanban-lane">
          <div class="lane-head"><span>{{ g.label }}</span><b>{{ g.rows.length }}</b></div>
          <article v-for="r in g.rows" :key="r.id" class="task-card" @click="openForm(r)">
            <small>{{ r.code || `#${r.id}` }}</small>
            <h4>{{ r.name || r.title || '未命名任务' }}</h4>
            <p>{{ r.partner || r.bizText || r.remark || '点击编辑任务详情' }}</p>
            <div class="task-card-foot"><span>{{ shortDate(r.bizDate || r.docDate) }}</span><span v-for="a in actionsOf(r).slice(0, 1)" :key="a.key" @click.stop="runAction(r, a)">{{ a.label }}</span></div>
          </article>
          <button class="lane-add" @click="openForm()">＋ 添加</button>
        </div>
      </div>
    </template>

    <!-- 7. 质检：合格/待检/不合格三栏 + 检验表 -->
    <template v-else-if="layout === 'qc'">
      <header class="ph-head ph-head--qc"><div><span class="ph-kicker">QUALITY CONTROL</span><h2>{{ config.title }}</h2></div><DsButton variant="primary" size="sm" @click="openForm()">＋ 新建送检</DsButton></header>
      <div class="qc-panels">
        <div class="qc-pass"><span>合格</span><b>{{ countStatus(2) }}</b><small>PASS</small></div>
        <div class="qc-wait"><span>待检</span><b>{{ countStatus(1) }}</b><small>WAITING</small></div>
        <div class="qc-fail"><span>不合格</span><b>{{ countStatus(4) }}</b><small>REJECTED</small></div>
      </div>
      <DataTable v-bind="tableProps" v-on="tableEvents" />
    </template>

    <!-- 8. 设备资产：资产卡片 + 台账 -->
    <template v-else-if="layout === 'equipment'">
      <header class="ph-head ph-head--equipment"><div><span class="ph-kicker">EQUIPMENT ASSET</span><h2>{{ config.title }}</h2></div><DsButton variant="primary" size="sm" @click="openForm()">＋ 登记资产</DsButton></header>
      <div class="asset-cards">
        <article v-for="r in rows.slice(0, 4)" :key="r.id" @click="openForm(r)">
          <div class="asset-icon">{{ (r.name || '资').slice(0, 1) }}</div>
          <div><b>{{ r.name || r.code }}</b><span>{{ r.code }}</span><em>{{ r.partner || r.warehouse || '—' }}</em></div>
        </article>
      </div>
      <DataTable v-bind="tableProps" v-on="tableEvents" />
    </template>

    <!-- 9. 排产进度：横向甘特条 -->
    <template v-else-if="layout === 'gantt'">
      <header class="ph-head ph-head--gantt"><div><span class="ph-kicker">PRODUCTION TIMELINE</span><h2>{{ config.title }}</h2></div><DsButton variant="primary" size="sm" @click="openForm()">＋ 新增计划</DsButton></header>
      <div class="gantt-board">
        <div class="gantt-axis"><span v-for="d in ['11/16','11/18','11/20','11/22','11/24']" :key="d">{{ d }}</span></div>
        <div v-for="(r, i) in rows.slice(0, 8)" :key="r.id" class="gantt-item">
          <span>{{ r.name || r.code }}</span>
          <div class="gantt-line"><i :style="{ left: (i * 7) + '%', width: (20 + (i * 9) % 45) + '%' }" /></div>
          <b>{{ Number(r.status || 0) >= 3 ? '完成' : '进行' }}</b>
        </div>
      </div>
      <DataTable v-bind="tableProps" v-on="tableEvents" />
    </template>

    <!-- 10. 财务账簿：借贷分栏 + 分录表 -->
    <template v-else-if="layout === 'ledger'">
      <header class="ph-head ph-head--ledger"><div><span class="ph-kicker">FINANCIAL LEDGER</span><h2>{{ config.title }}</h2></div><DsButton variant="primary" size="sm" @click="openForm()">＋ 新建分录</DsButton></header>
      <div class="ledger-columns">
        <div class="debit"><span>借方合计</span><b>{{ debitTotal }}</b><small>DEBIT</small></div>
        <div class="credit"><span>贷方合计</span><b>{{ creditTotal }}</b><small>CREDIT</small></div>
        <div class="balance"><span>期末余额</span><b>{{ metrics.amount }}</b><small>BALANCE</small></div>
      </div>
      <DataTable v-bind="tableProps" v-on="tableEvents" />
    </template>

    <!-- 11. 审批中心：漏斗 + 审批队列 -->
    <template v-else-if="layout === 'approval'">
      <header class="ph-head ph-head--approval"><div><span class="ph-kicker">APPROVAL CENTER</span><h2>{{ config.title }}</h2></div><DsButton variant="primary" size="sm" @click="openForm()">＋ 发起申请</DsButton></header>
      <div class="approval-funnel">
        <button v-for="s in approvalStats" :key="s.label" :class="{ on: String(q.status) === String(s.value) }" @click="setStatus(s.value)"><b>{{ s.count }}</b><span>{{ s.label }}</span></button>
      </div>
      <DataTable v-bind="tableProps" v-on="tableEvents" />
    </template>

    <!-- 12. 组织人事：组织树 + 人员台账 -->
    <template v-else-if="layout === 'people'">
      <header class="ph-head ph-head--people"><div><span class="ph-kicker">ORGANIZATION & PEOPLE</span><h2>{{ config.title }}</h2></div><DsButton variant="primary" size="sm" @click="openForm()">＋ 新建档案</DsButton></header>
      <div class="org-layout">
        <aside class="org-tree">
          <div class="org-root">深圳总公司</div>
          <div v-for="r in rows.slice(0, 5)" :key="r.id" class="org-node">{{ r.partner || r.name || r.code }}</div>
        </aside>
        <section class="org-main"><DataTable v-bind="tableProps" v-on="tableEvents" /></section>
      </div>
    </template>

    <!-- 13. 日程：日期条 + 当日议程 -->
    <template v-else-if="layout === 'calendar'">
      <header class="ph-head ph-head--calendar"><div><span class="ph-kicker">SCHEDULE</span><h2>{{ config.title }}</h2></div><DsButton variant="primary" size="sm" @click="openForm()">＋ 新建日程</DsButton></header>
      <div class="calendar-strip">
        <div v-for="r in rows.slice(0, 7)" :key="r.id" class="cal-day" @click="openForm(r)"><b>{{ shortDate(r.bizDate || r.docDate).slice(5) }}</b><span>{{ r.name || r.code }}</span><small>{{ r.partner || r.bizText }}</small></div>
        <div v-if="!rows.length" class="cal-empty">暂无日程</div>
      </div>
      <div class="agenda">
        <h3>近期安排</h3>
        <div v-for="r in rows" :key="r.id" class="agenda-row" @click="openForm(r)"><b>{{ shortDate(r.bizDate || r.docDate) }}</b><span>{{ r.name || r.code }}</span><em>{{ r.partner || r.bizText || '—' }}</em></div>
      </div>
    </template>

    <!-- 14. 文件档案：卡片库 -->
    <template v-else-if="layout === 'files'">
      <header class="ph-head ph-head--files"><div><span class="ph-kicker">FILE LIBRARY</span><h2>{{ config.title }}</h2></div><DsButton variant="primary" size="sm" @click="openForm()">＋ 新建档案</DsButton></header>
      <div class="file-toolbar"><DsInput v-model="q.keyword" placeholder="搜索文件名称" @keyup.enter="reload" /><DsButton size="sm" @click="reload">搜索</DsButton></div>
      <div class="file-grid">
        <article v-for="r in rows" :key="r.id" class="file-card" @click="openForm(r)">
          <div class="file-ext">{{ (r.bizText || 'FILE').slice(0, 4) }}</div>
          <b>{{ r.name || r.code }}</b>
          <span>{{ r.partner || '未分类' }}</span>
          <small>{{ r.qty || 0 }} MB · {{ shortDate(r.docDate) }}</small>
        </article>
        <div v-if="!rows.length" class="file-empty">暂无文件档案</div>
      </div>
    </template>

    <!-- 15. 协作会话：会话列表 + 消息流 -->
    <template v-else-if="layout === 'chat'">
      <header class="ph-head ph-head--chat"><div><span class="ph-kicker">COLLABORATION</span><h2>{{ config.title }}</h2></div><DsButton variant="primary" size="sm" @click="openForm()">＋ 新建会话</DsButton></header>
      <div class="chat-layout">
        <aside class="chat-list">
          <div v-for="r in rows" :key="r.id" class="chat-list-item" @click="activeChat = r"><b>{{ r.name || r.code }}</b><span>{{ r.partner || r.bizText }}</span></div>
        </aside>
        <section class="chat-room">
          <div class="chat-room-head">{{ activeChat?.name || '选择一个会话' }}</div>
          <div class="chat-messages">
            <div v-for="(r, i) in rows.slice(0, 5)" :key="r.id" class="chat-bubble" :class="{ mine: i % 2 === 0 }"><b>{{ i % 2 === 0 ? '我' : (r.partner || '对方') }}</b><span>{{ r.bizText || r.remark || r.name || '暂无消息' }}</span><small>{{ shortDate(r.docDate) }}</small></div>
          </div>
          <div class="chat-input"><DsInput v-model="chatDraft" placeholder="输入消息…" /><DsButton variant="primary" size="sm">发送</DsButton></div>
        </section>
      </div>
    </template>

    <!-- 表单弹窗：不同页面使用不同表单密度 -->
    <DsModal v-model="formVisible" :title="editing ? `编辑${config.title}` : `新建${config.title}`" :width="formWidth">
      <div class="entity-form" :class="'form-' + layout">
        <label v-for="f in config.fields" :key="f.prop" class="entity-field">
          <span>{{ f.label }}</span>
          <DsSelect v-if="f.type === 'select'" v-model="form[f.prop]" :options="optionsOf(f)" :placeholder="`请选择${f.label}`" />
          <DsDatePicker v-else-if="f.type === 'date'" v-model="form[f.prop]" />
          <DsInputNumber v-else-if="f.type === 'number'" v-model="form[f.prop]" />
          <textarea v-else-if="f.type === 'textarea'" v-model="form[f.prop]" class="ds-input" rows="3" />
          <DsInput v-else v-model="form[f.prop]" :placeholder="f.placeholder || `请输入${f.label}`" />
        </label>
      </div>
      <template #footer><div class="entity-form-foot"><DsButton @click="formVisible = false">取消</DsButton><DsButton variant="primary" :loading="saving" @click="save">保存</DsButton></div></template>
    </DsModal>
  </div>
</template>

<script setup lang="ts">
import { computed, onMounted, reactive, ref } from 'vue';
import { DsButton, DsCard, DsDatePicker, DsInput, DsInputNumber, DsModal, DsPagination, DsSelect, DsTag } from '../../components';
import DataTable from '../generic/DataTable.vue';
import { useToast } from '../../components/ds/toast';
import { confirm as uiConfirm } from '../../components/ds/useConfirm';
import { mockGet, mockPost, mockPatch, mockDel } from '../../api/mockAdapter';
import type { SalesAction, SalesConfig, SalesField } from './salesConfigs';

const props = defineProps<{ config: SalesConfig }>();
const toast = useToast();
const q = reactive<{ keyword: string; status: any }>({ keyword: '', status: '' });
const rows = ref<any[]>([]);
const total = ref(0);
const page = ref(1);
const pageSize = ref(10);
const loading = ref(false);
const saving = ref(false);
const formVisible = ref(false);
const editing = ref<any>(null);
const form = reactive<Record<string, any>>({});
const options = reactive<Record<string, any[]>>({ customers: [], products: [], orders: [], groups: [], suppliers: [], warehouses: [] });
const activeChat = ref<any>(null);
const chatDraft = ref('');

const statusOptions = computed(() => Object.entries(props.config.statusLabels || {}).map(([value, label]) => ({ label, value: Number(value) })));

type Layout = NonNullable<SalesConfig['layout']>;
function inferLayout(title: string): Layout {
  if (/毛利|分析|周转|库龄|及时率|报表|成本归集|产能|现金流|科目余额|试算平衡|明细账|预测|解读/.test(title)) return 'analytics';
  if (/凭证|账簿|会计分录|对账/.test(title)) return 'ledger';
  if (/申请|审批|公告|通知|告警|订阅/.test(title)) return 'approval';
  if (/公司|部门|岗位|雇员|员工|人事|工资|薪酬|组织/.test(title)) return 'people';
  if (/会议|请假|节假日|里程碑|日程|版本/.test(title)) return 'calendar';
  if (/文件|档案|知识库|模板管理|条码标签|Prompt/.test(title)) return 'files';
  if (/聊天|会话|客服|助理/.test(title)) return 'chat';
  if (/质检|异常|OCR/.test(title)) return 'qc';
  if (/设备|车辆|资产|MCP|集成/.test(title)) return 'equipment';
  if (/BOM|物料清单/.test(title)) return 'bom';
  if (/工单|任务|看板|执行/.test(title)) return 'kanban';
  if (/物流|进度|计划|排产/.test(title)) return 'gantt';
  if (/仓库|库位|批次|序列号|安全库存|收货|上架|拣货|调拨|调整|盘点|出库|入库|越库|商品映射/.test(title)) return 'warehouse';
  if (/列表|分组|等级|联系人|品牌|分类|单位|供应商|价目|工艺|工作中心|科目|账户|类别|岗位|字典|权限|角色/.test(title)) return 'list';
  return 'workflow';
}
const layout = computed<Layout>(() => props.config.layout || inferLayout(props.config.title));
const LAYOUT_META: Record<string, string> = {
  list: '主数据', workflow: '单据流', analytics: '经营分析', warehouse: '仓储作业', bom: 'BOM 结构',
  kanban: '看板', qc: '质量检验', equipment: '资产台账', gantt: '排产进度', ledger: '财务账簿',
  approval: '审批中心', people: '组织人事', calendar: '日程视图', files: '文件档案', chat: '协作会话',
};
const formWidth = computed(() => ['chat', 'calendar', 'files', 'kanban'].includes(layout.value) ? 520 : ['analytics', 'workflow', 'ledger'].includes(layout.value) ? 760 : 640);
const tableProps = computed(() => ({ config: props.config, rows: rows.value, loading: loading.value, total: total.value, page: page.value, pageSize: pageSize.value, q, layout: layout.value, display, actionsOf }));
const tableEvents = {
  reload, reset: resetQuery, edit: openForm, action: runAction, remove: removeRow,
  'update:page': (v: number) => { page.value = v; load(); },
};

const metrics = computed(() => ({
  count: rows.value.length,
  qty: rows.value.reduce((s, r) => s + Number(r.qty ?? 0), 0).toFixed(2),
  amount: rows.value.reduce((s, r) => s + Number(r.amount ?? 0), 0).toFixed(2),
  pending: rows.value.filter((r) => Number(r.status ?? 0) <= 1).length,
}));
const metricCards = computed(() => [
  { label: '记录数', value: String(metrics.value.count), hint: '当前筛选结果' },
  { label: '数量合计', value: metrics.value.qty, hint: '业务数量' },
  { label: '金额合计', value: metrics.value.amount, hint: '业务金额' },
  { label: '待处理', value: String(metrics.value.pending), hint: '草稿 / 待审' },
]);
const flowTabs = computed(() => [
  { label: '全部', value: '', count: rows.value.length },
  ...statusOptions.value.map((s) => ({ label: s.label, value: s.value, count: rows.value.filter((r) => Number(r.status) === Number(s.value)).length })),
]);
const kanbanGroups = computed(() => statusOptions.value.slice(0, 4).map((s) => ({ ...s, rows: rows.value.filter((r) => Number(r.status) === Number(s.value)) })));
const approvalStats = computed(() => [
  { label: '全部申请', value: '', count: rows.value.length },
  { label: '审批中', value: 1, count: countStatus(1) },
  { label: '已通过', value: 2, count: countStatus(2) + countStatus(3) },
  { label: '已驳回', value: 4, count: countStatus(4) },
]);
function countStatus(v: number): number { return rows.value.filter((r) => Number(r.status) === v).length; }
function setStatus(v: any): void { q.status = v; page.value = 1; load(); }
function shortDate(v: any): string { const s = String(v || ''); return s ? s.slice(0, 10) : '—'; }
const debitTotal = computed(() => rows.value.reduce((s, r) => s + Number(r.bizAmount || r.amount || 0), 0).toFixed(2));
const creditTotal = computed(() => rows.value.reduce((s, r) => s + Number(r.amount || 0), 0).toFixed(2));

/** 数据加载 */
async function loadOptions(): Promise<void> {
  const [customers, products, orders, groups, suppliers, warehouses]: any[] = await Promise.allSettled([
    mockGet('/api/v1/crm/customers', { pageSize: 200 }),
    mockGet('/api/v1/inventory/products', { pageSize: 200 }),
    mockGet('/api/v1/sales/orders', { pageSize: 200 }),
    mockGet('/api/v1/crm/customer-groups', { pageSize: 200 }),
    mockGet('/api/v1/purchase/suppliers', { pageSize: 200 }),
    mockGet('/api/v1/inventory/warehouses', { pageSize: 200 }),
  ]).then((rs) => rs.map((r) => r.status === 'fulfilled' ? r.value : null));
  const listOf = (d: any) => Array.isArray(d) ? d : (d?.list || []);
  options.customers = listOf(customers).map((x: any) => ({ label: x.name || x.code, value: x.id }));
  options.products = listOf(products).map((x: any) => ({ label: x.name || x.code, value: x.id }));
  options.orders = listOf(orders).map((x: any) => ({ label: x.orderNo || `#${x.id}`, value: x.id }));
  options.groups = listOf(groups).map((x: any) => ({ label: x.name || x.code, value: x.id }));
  options.suppliers = listOf(suppliers).map((x: any) => ({ label: x.name || x.code, value: x.id }));
  options.warehouses = listOf(warehouses).map((x: any) => ({ label: x.name || x.code, value: x.id }));
}
function optionsOf(f: SalesField): any[] {
  if (f.options) return f.options;
  if (f.source === 'customers' || f.prop === 'customerId') return options.customers;
  if (f.source === 'products' || f.prop === 'productId') return options.products;
  if (f.source === 'orders' || f.prop === 'orderId') return options.orders;
  if (f.prop === 'groupId') return options.groups;
  if (f.prop === 'supplierId' || f.source === 'suppliers') return options.suppliers;
  if (f.prop === 'warehouseId') return options.warehouses;
  return [];
}
async function load(): Promise<void> {
  loading.value = true;
  try {
    const d: any = await mockGet(props.config.api, { page: page.value, pageSize: pageSize.value, keyword: q.keyword, status: q.status });
    rows.value = Array.isArray(d) ? d : (d?.list || []);
    total.value = Number(d?.total ?? rows.value.length);
    if (layout.value === 'chat' && !activeChat.value && rows.value.length) activeChat.value = rows.value[0];
  } catch (e: any) { toast.error(e?.message || '加载失败'); rows.value = []; }
  finally { loading.value = false; }
}
function reload(): void { page.value = 1; load(); }
function resetQuery(): void { q.keyword = ''; q.status = ''; reload(); }
function display(row: any, f: SalesField): string {
  const v = row[f.prop];
  if (f.prop === 'status' && props.config.statusLabels) return props.config.statusLabels[String(v)] || String(v ?? '');
  const opts = optionsOf(f);
  if (opts.length) { const hit = opts.find((o) => String(o.value) === String(v)); if (hit) return String(hit.label); }
  if (v === null || v === undefined || v === '') return '—';
  const s = String(v);
  return /^\d{4}-\d{2}-\d{2}/.test(s) ? s.slice(0, 10) : s;
}
function resetForm(): void {
  for (const k of Object.keys(form)) delete form[k];
  const defaults = props.config.defaults?.() || {};
  for (const f of props.config.fields) form[f.prop] = defaults[f.prop] ?? (f.type === 'number' ? 0 : '');
}
function openForm(row?: any): void {
  editing.value = row || null;
  resetForm();
  if (row) for (const f of props.config.fields) if (row[f.prop] !== undefined) form[f.prop] = row[f.prop];
  formVisible.value = true;
}
async function save(): Promise<void> {
  for (const f of props.config.fields) {
    if (f.required && (form[f.prop] === '' || form[f.prop] === undefined || form[f.prop] === null)) { toast.warning(`请填写「${f.label}」`); return; }
  }
  saving.value = true;
  try {
    const payload: Record<string, any> = {};
    for (const f of props.config.fields) payload[f.prop] = form[f.prop];
    if (editing.value?.id) await mockPatch(`${props.config.api}/${editing.value.id}`, payload);
    else await mockPost(props.config.api, payload);
    toast.success(editing.value ? '已保存' : '已创建');
    formVisible.value = false;
    await load();
  } catch (e: any) { toast.error(e?.message || '保存失败'); }
  finally { saving.value = false; }
}
function actionsOf(row: any): SalesAction[] {
  return (props.config.actions || []).filter((a) => !a.from || a.from.some((s) => Number(s) === Number(row[props.config.statusField || 'status'])));
}
async function runAction(row: any, a: SalesAction): Promise<void> {
  if (!await uiConfirm(`确定对「${props.config.title} #${row.id}」执行「${a.label}」吗？`, '业务确认')) return;
  try {
    const res: any = await mockPost(`/_biz/action/${props.config.collection}/${row.id}/${a.key}`, { label: a.label });
    toast.success(res?.message || `${a.label}成功`);
    await load();
  } catch (e: any) { toast.error(e?.message || '操作失败'); }
}
async function removeRow(row: any): Promise<void> {
  if (!await uiConfirm(`确定删除「${props.config.title} #${row.id}」吗？`, '删除确认')) return;
  try { await mockDel(`${props.config.api}/${row.id}`); toast.success('已删除'); await load(); }
  catch (e: any) { toast.error(e?.message || '删除失败'); }
}
onMounted(() => { loadOptions(); load(); });
</script>

<style scoped>
.page-shell { padding: 16px; min-height: calc(100vh - 120px); background: var(--ds-bg-page, #f6f7f9); }
.ph-head { display: flex; align-items: flex-end; justify-content: space-between; gap: 16px; margin-bottom: 16px; padding-bottom: 12px; border-bottom: 1px solid var(--ds-border); }
.ph-head h2 { margin: 2px 0 0; font-size: 22px; letter-spacing: .5px; }
.ph-kicker { font-size: 10px; letter-spacing: 2px; color: var(--ds-text-3); }
.ph-head-actions { display: flex; gap: 8px; }
.ph-head--list { border-bottom: 3px solid #4f46e5; }
.ph-head--flow { border-bottom: 3px solid #2563eb; }
.ph-head--analytics { border-bottom: 3px solid #7c3aed; }
.ph-head--warehouse { border-bottom: 3px solid #0891b2; }
.ph-head--bom { border-bottom: 3px solid #ea580c; }
.ph-head--kanban { border-bottom: 3px solid #d97706; }
.ph-head--qc { border-bottom: 3px solid #059669; }
.ph-head--equipment { border-bottom: 3px solid #475569; }
.ph-head--gantt { border-bottom: 3px solid #0f766e; }
.ph-head--ledger { border-bottom: 3px solid #0f766e; }
.ph-head--approval { border-bottom: 3px solid #c2410c; }
.ph-head--people { border-bottom: 3px solid #be185d; }
.ph-head--calendar { border-bottom: 3px solid #4338ca; }
.ph-head--files { border-bottom: 3px solid #0369a1; }
.ph-head--chat { border-bottom: 3px solid #7e22ce; }
.analytics-period { font-size: 12px; color: var(--ds-text-3); }

.master-layout { display: grid; grid-template-columns: 190px 1fr; gap: 14px; align-items: start; }
.master-rail { padding: 12px; border: 1px solid var(--ds-border); border-radius: 10px; background: var(--ds-bg-elevated); }
.rail-title { font-size: 12px; color: var(--ds-text-3); margin-bottom: 10px; }
.master-rail button { display: flex; justify-content: space-between; width: 100%; padding: 8px 10px; margin-bottom: 6px; border: 0; border-radius: 6px; background: transparent; cursor: pointer; font-size: 13px; }
.master-rail button.on { background: rgba(79,70,229,.1); color: #4f46e5; font-weight: 600; }
.master-rail button span { color: var(--ds-text-3); }
.rail-tip { margin-top: 14px; padding-top: 10px; border-top: 1px dashed var(--ds-border); font-size: 11px; color: var(--ds-text-3); }
.master-main { min-width: 0; }
.bar-search { display: flex; gap: 8px; margin-bottom: 12px; }
.bar-search .ds-input-wrap { flex: 1; }

.flow-pipeline { display: flex; gap: 6px; overflow-x: auto; padding: 12px; border-radius: 10px; background: #eef4ff; }
.flow-pipeline button { display: flex; align-items: center; gap: 8px; flex: 0 0 auto; padding: 8px 14px; border: 1px solid #cbd5e1; border-radius: 999px; background: #fff; cursor: pointer; }
.flow-pipeline button.on { border-color: #2563eb; color: #2563eb; box-shadow: 0 0 0 2px rgba(37,99,235,.1); }
.flow-pipeline i { width: 20px; height: 20px; border-radius: 50%; background: #2563eb; color: #fff; font-size: 11px; font-style: normal; display: grid; place-items: center; }
.flow-pipeline b { font-size: 11px; color: var(--ds-text-3); }
.flow-summary { display: flex; align-items: center; gap: 12px; margin: 12px; }
.flow-summary div { flex: 1; padding: 10px 14px; border-left: 3px solid #2563eb; border-radius: 6px; background: var(--ds-bg-elevated); font-size: 12px; }
.flow-summary b { font-size: 20px; margin-left: 8px; }

.analytics-metrics { display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px; }
.analytics-metrics > div { display: flex; flex-direction: column; gap: 4px; padding: 16px; border: 1px solid var(--ds-border); border-top: 4px solid #7c3aed; border-radius: 10px; background: var(--ds-bg-elevated); }
.analytics-metrics small, .analytics-metrics em { font-size: 11px; color: var(--ds-text-3); font-style: normal; }
.analytics-metrics b { font-size: 26px; color: #7c3aed; }
.analytics-chart { margin: 12px; padding: 14px; border: 1px solid var(--ds-border); border-radius: 10px; background: var(--ds-bg-elevated); }
.chart-row { display: flex; align-items: center; gap: 10px; padding: 5px 0; font-size: 12px; }
.chart-row span { flex: 0 0 150px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.chart-track { flex: 1; height: 10px; border-radius: 999px; background: var(--ds-bg-hover); overflow: hidden; }
.chart-track i { display: block; height: 100%; background: linear-gradient(90deg,#7c3aed,#4f46e5); }
.chart-row b { flex: 0 0 70px; text-align: right; }
.chart-empty { padding: 20px; text-align: center; color: var(--ds-text-3); }
.analytics-filter { display: flex; gap: 8px; margin: 0 12px; }

.zone-strip { display: grid; grid-template-columns: repeat(4, 1fr); gap: 10px; margin-bottom: 12px; }
.zone-strip > div { display: flex; align-items: baseline; gap: 8px; padding: 14px; border: 1px solid var(--ds-border); border-radius: 10px; background: var(--ds-bg-elevated); }
.zone-strip > div.on { border-color: #0891b2; background: rgba(8,145,178,.06); }
.zone-strip b { font-size: 22px; color: #0891b2; }
.zone-strip small { color: var(--ds-text-3); }
.warehouse-note { margin: 0 12px 8px; font-size: 12px; color: var(--ds-text-3); }

.bom-tree { margin: 12px; padding: 14px; border: 1px dashed #ea580c; border-radius: 10px; background: rgba(234,88,12,.04); }
.bom-root { display: inline-block; padding: 6px 12px; border-radius: 6px; background: #ea580c; color: #fff; font-size: 13px; }
.bom-node { display: flex; align-items: center; gap: 8px; margin-top: 10px; padding: 6px 10px; border-left: 2px solid #fdba74; background: var(--ds-bg-elevated); font-size: 12px; }
.bom-dot { width: 8px; height: 8px; border-radius: 50%; background: #ea580c; }
.bom-node b { margin-left: auto; }

.kanban-board { display: grid; grid-template-columns: repeat(4, minmax(220px, 1fr)); gap: 12px; overflow-x: auto; padding-bottom: 8px; }
.kanban-lane { padding: 10px; border-radius: 12px; background: var(--ds-bg-hover); border: 1px solid var(--ds-border); }
.lane-head { display: flex; justify-content: space-between; padding: 6px 4px 10px; font-size: 13px; font-weight: 600; }
.task-card { padding: 12px; margin-bottom: 10px; border: 1px solid var(--ds-border); border-left: 3px solid #d97706; border-radius: 8px; background: var(--ds-bg-elevated); cursor: pointer; }
.task-card small { color: var(--ds-text-3); }
.task-card h4 { margin: 6px 0; font-size: 14px; }
.task-card p { margin: 0; font-size: 12px; color: var(--ds-text-2); }
.task-card-foot { display: flex; justify-content: space-between; margin-top: 10px; font-size: 11px; color: var(--ds-brand); }
.lane-add { width: 100%; padding: 8px; border: 1px dashed var(--ds-border); border-radius: 6px; background: transparent; cursor: pointer; color: var(--ds-text-3); }

.qc-panels { display: grid; grid-template-columns: repeat(3, 1fr); gap: 12px; margin-bottom: 12px; }
.qc-panels > div { display: flex; flex-direction: column; padding: 16px; border-radius: 10px; color: #fff; }
.qc-panels b { font-size: 30px; }
.qc-panels small { opacity: .7; font-size: 10px; letter-spacing: 2px; }
.qc-pass { background: #059669; } .qc-wait { background: #d97706; } .qc-fail { background: #dc2626; }

.asset-cards { display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px; margin-bottom: 12px; }
.asset-cards article { display: flex; gap: 12px; padding: 12px; border: 1px solid var(--ds-border); border-radius: 10px; background: var(--ds-bg-elevated); cursor: pointer; }
.asset-icon { width: 42px; height: 42px; display: grid; place-items: center; border-radius: 8px; background: #475569; color: #fff; font-size: 18px; }
.asset-cards b, .asset-cards span, .asset-cards em { display: block; font-size: 12px; font-style: normal; }
.asset-cards span, .asset-cards em { color: var(--ds-text-3); }

.gantt-board { margin: 12px; padding: 14px; border: 1px solid var(--ds-border); border-radius: 10px; background: var(--ds-bg-elevated); }
.gantt-axis { display: flex; justify-content: space-between; margin-left: 140px; margin-right: 50px; font-size: 11px; color: var(--ds-text-3); }
.gantt-item { display: flex; align-items: center; gap: 10px; padding: 8px 0; border-bottom: 1px dashed var(--ds-border); font-size: 12px; }
.gantt-item > span { flex: 0 0 140px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.gantt-line { flex: 1; height: 10px; border-radius: 999px; background: var(--ds-bg-hover); position: relative; }
.gantt-line i { position: absolute; top: 0; bottom: 0; border-radius: 999px; background: linear-gradient(90deg,#0f766e,#22c55e); }
.gantt-item > b { flex: 0 0 40px; text-align: right; }

.ledger-columns { display: grid; grid-template-columns: repeat(3, 1fr); gap: 12px; }
.ledger-columns > div { display: flex; flex-direction: column; padding: 16px; border-radius: 10px; color: #fff; }
.ledger-columns .debit { background: #0f766e; } .ledger-columns .credit { background: #1d4ed8; } .ledger-columns .balance { background: #334155; }
.ledger-columns b { font-size: 26px; } .ledger-columns small { opacity: .7; font-size: 10px; letter-spacing: 2px; }

.approval-funnel { display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px; }
.approval-funnel button { display: flex; flex-direction: column; align-items: center; gap: 6px; padding: 18px; border: 1px solid var(--ds-border); border-radius: 10px; background: var(--ds-bg-elevated); cursor: pointer; }
.approval-funnel button.on { border-color: #c2410c; background: rgba(194,65,12,.07); }
.approval-funnel b { font-size: 28px; color: #c2410c; }
.approval-funnel span { font-size: 12px; color: var(--ds-text-3); }

.org-layout { display: grid; grid-template-columns: 210px 1fr; gap: 14px; align-items: start; }
.org-tree { padding: 12px; border: 1px solid var(--ds-border); border-left: 3px solid #be185d; border-radius: 10px; background: var(--ds-bg-elevated); }
.org-root { padding: 8px; background: #be185d; color: #fff; border-radius: 6px; font-size: 13px; }
.org-node { padding: 8px 8px 8px 20px; border-left: 1px dashed var(--ds-border); font-size: 12px; color: var(--ds-text-2); }
.org-main { min-width: 0; }

.calendar-strip { display: grid; grid-template-columns: repeat(7, minmax(110px, 1fr)); gap: 8px; overflow-x: auto; margin-bottom: 14px; }
.cal-day { display: flex; flex-direction: column; gap: 3px; padding: 10px; border: 1px solid var(--ds-border); border-top: 3px solid #4338ca; border-radius: 8px; background: var(--ds-bg-elevated); cursor: pointer; font-size: 12px; }
.cal-day span { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.cal-day small { color: var(--ds-text-3); }
.cal-empty { padding: 20px; color: var(--ds-text-3); }
.agenda { margin: 12px; padding: 14px; border: 1px solid var(--ds-border); border-radius: 10px; background: var(--ds-bg-elevated); }
.agenda h3 { margin: 0 0 10px; font-size: 14px; }
.agenda-row { display: grid; grid-template-columns: 110px 1fr 120px; gap: 10px; padding: 9px 0; border-bottom: 1px dashed var(--ds-border); font-size: 12px; cursor: pointer; }
.agenda-row em { color: var(--ds-text-3); font-style: normal; }

.file-toolbar { display: flex; gap: 8px; margin-bottom: 12px; }
.file-toolbar .ds-input-wrap { flex: 1; }
.file-grid { display: grid; grid-template-columns: repeat(5, minmax(160px, 1fr)); gap: 12px; }
.file-card { display: flex; flex-direction: column; gap: 6px; padding: 14px; border: 1px solid var(--ds-border); border-radius: 10px; background: var(--ds-bg-elevated); cursor: pointer; }
.file-ext { align-self: flex-start; padding: 3px 8px; border-radius: 4px; background: #0369a1; color: #fff; font-size: 10px; }
.file-card b { font-size: 13px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.file-card span, .file-card small { color: var(--ds-text-3); font-size: 11px; }
.file-empty { grid-column: 1/-1; padding: 30px; text-align: center; color: var(--ds-text-3); }

.chat-layout { display: grid; grid-template-columns: 260px 1fr; gap: 14px; height: 540px; }
.chat-list { padding: 10px; border: 1px solid var(--ds-border); border-radius: 10px; background: var(--ds-bg-elevated); overflow: auto; }
.chat-list-item { display: flex; flex-direction: column; gap: 4px; padding: 10px; margin-bottom: 6px; border-radius: 8px; cursor: pointer; }
.chat-list-item:hover { background: var(--ds-bg-hover); }
.chat-list-item span { font-size: 11px; color: var(--ds-text-3); }
.chat-room { display: flex; flex-direction: column; border: 1px solid var(--ds-border); border-radius: 10px; background: var(--ds-bg-elevated); overflow: hidden; }
.chat-room-head { padding: 12px 14px; border-bottom: 1px solid var(--ds-border); font-weight: 600; }
.chat-messages { flex: 1; padding: 14px; overflow: auto; background: var(--ds-bg-hover); }
.chat-bubble { display: flex; flex-direction: column; gap: 4px; max-width: 70%; margin-bottom: 12px; padding: 10px 12px; border-radius: 10px; background: #fff; }
.chat-bubble.mine { margin-left: auto; background: #dbeafe; }
.chat-bubble small { color: var(--ds-text-3); font-size: 10px; }
.chat-input { display: flex; gap: 8px; padding: 10px; border-top: 1px solid var(--ds-border); }
.chat-input .ds-input-wrap { flex: 1; }

.entity-form { display: grid; gap: 14px; padding: 8px 2px; }
.form-list, .form-people, .form-warehouse, .form-equipment { grid-template-columns: repeat(2, minmax(0, 1fr)); }
.form-workflow, .form-ledger, .form-analytics, .form-approval { grid-template-columns: repeat(3, minmax(0, 1fr)); }
.form-chat, .form-calendar, .form-files, .form-kanban, .form-bom, .form-gantt { grid-template-columns: 1fr; }
.entity-field { display: flex; flex-direction: column; gap: 5px; font-size: 12px; color: var(--ds-text-2); }
.entity-form-foot { display: flex; justify-content: flex-end; gap: 8px; }
@media (max-width: 1100px) {
  .master-layout, .org-layout, .chat-layout { grid-template-columns: 1fr; }
  .analytics-metrics, .zone-strip, .approval-funnel, .asset-cards, .file-grid { grid-template-columns: repeat(2, minmax(0, 1fr)); }
  .kanban-board { grid-template-columns: repeat(2, minmax(220px, 1fr)); }
}
</style>
