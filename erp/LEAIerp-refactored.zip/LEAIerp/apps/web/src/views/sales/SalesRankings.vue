<template><RecordPage :config="page" /></template>

<script setup lang="ts">
import RecordPage from '../records/RecordPage.vue';
import type { RecordPageConfig } from '../records/records';

const page: RecordPageConfig = {
  title: '畅销排行',
  resource: 'sales/rankings',
  endpoint: '/api/v1/order-reports/sales-ranking',
  schema: 'salesRankings',
  omitFields: ['trend'],
  filters: ['productName', 'skuCode'],
  reportSource: '按商品查询销售数量和金额排名',
};
</script>
