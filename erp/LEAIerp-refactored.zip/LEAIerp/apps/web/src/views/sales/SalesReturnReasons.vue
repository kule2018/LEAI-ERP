<template><RecordPage :config="page" /></template>

<script setup lang="ts">
import RecordPage from '../records/RecordPage.vue';
import type { RecordPageConfig } from '../records/records';

const page: RecordPageConfig = {
  title: '退货原因',
  resource: 'sales/return-reasons',
  schema: 'salesReturnReasons',
  filters: ['type', 'status'],
  required: ['name', 'code', 'type'],
};
</script>
