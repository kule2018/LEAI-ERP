<template><RecordPage :config="page" /></template>

<script setup lang="ts">
import RecordPage from '../records/RecordPage.vue';
import type { RecordPageConfig } from '../records/records';

const page: RecordPageConfig = {
  title: '销售汇总',
  resource: 'sales/summaries',
  endpoint: '/api/v1/order-reports/sales-summary',
  schema: 'salesSummaries',
  filters: ['period', 'customerName'],
  reportSource: '按期间和客户查询销售汇总',
  omitFields: ['profit'],
  metrics: ['orderCount', 'totalAmount', 'paidAmount'],
};
</script>
