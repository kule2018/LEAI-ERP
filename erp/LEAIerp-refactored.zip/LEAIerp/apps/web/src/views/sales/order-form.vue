<template>
  <div class="entity-page">
    <DsCard>
      <template #title>{{ id ? '销售单 ' + form.orderNo : '新建销售单' }}</template>
      <template #extra>
        <!-- 智能识别：上传/粘贴即识别，仅预填草稿，需用户确认 -->
        <DsButton size="sm" @click="aiPaste">🤖 智能粘贴识别</DsButton>
        <DsButton size="sm" @click="recommend">🤖 智能推荐</DsButton>
        <DsButton size="sm" @click="applyTemplate">📋 套用常用方案</DsButton>
        <DsButton size="sm" @click="saveAsTemplate">💾 存为方案</DsButton>
        <DsButton size="sm" :disabled="!id" @click="onPrint">🖨 打印</DsButton>
        <DsButton variant="primary" size="sm" :loading="saving" :disabled="locked" @click="onSave">保存草稿</DsButton>
        <DsButton v-if="id" size="sm" :disabled="locked" @click="onSubmit">提交</DsButton>
        <DsButton v-if="id" variant="primary" size="sm" :disabled="locked" @click="onConfirm">确认</DsButton>
      </template>

      <DsForm :model="form" label-position="left" label-width="64px" size="sm"
              style="display: grid; grid-template-columns: repeat(5, minmax(0, 1fr)); gap: 12px">
        <DsFormItem label="客户">
          <DsSelect v-model="form.customerId" :options="customerOptions" :clearable="false" filterable size="sm" placeholder="客户" />
        </DsFormItem>
        <DsFormItem label="仓库">
          <DsSelect v-model="form.warehouseId" :options="warehouseOptions" :clearable="false" size="sm" placeholder="仓库" />
        </DsFormItem>
        <DsFormItem label="日期">
          <input type="datetime-local" class="ds-input" :value="orderDateInput" @input="onOrderDateInput($event)" />
        </DsFormItem>
        <DsFormItem label="币种">
          <DsSelect v-model="form.currency" :options="currencyOptions" :clearable="false" size="sm" placeholder="币种" />
        </DsFormItem>
        <DsFormItem label="优惠码">
          <input v-model="couponCode" class="ds-input" placeholder="可选" />
        </DsFormItem>
      </DsForm>

      <!-- 扫码枪连续录入：输入框保持焦点，回车自动带出品名/价格/库存并累加数量 -->
      <div class="scan-bar">
        <span>📷 扫码录入</span>
        <input v-model="scanBarcode" class="ds-input" style="width: 260px" placeholder="扫码枪扫入条码后回车（支持连续扫码累加）" @keyup.enter="onScan" />
        <span class="scan-tip">本币合计 ¥{{ baseTotal.toFixed(2) }} · 汇率 {{ currencyRate }}</span>
      </div>

      <table class="ds-table">
        <thead><tr><th>产品</th><th>数量</th><th>单价</th><th>折扣</th><th>金额</th><th>价格来源</th><th></th></tr></thead>
        <tbody>
          <tr v-for="(s, i) in form.lines" :key="i">
            <td>
              <DsSelect v-model="s.productId" :options="productOptions" :clearable="false" filterable size="sm" @change="onProduct(s)" />
            </td>
            <td><input v-model="s.qty" class="ds-input" @blur="calc(s)" /></td>
            <td><input v-model="s.unitPrice" class="ds-input" @blur="calc(s)" /></td>
            <td><input v-model="s.discount" class="ds-input" @blur="calc(s)" /></td>
            <td>{{ s.amount }}</td>
            <td><DsTag color="neutral" size="sm">{{ s.priceSource || '通用售价' }}</DsTag></td>
            <td><DsButton variant="text" size="sm" @click="form.lines.splice(i, 1)">删</DsButton></td>
          </tr>
        </tbody>
        <!-- 合计行仍由原 sumRows 方法计算，列下标/标签逻辑不变 -->
        <tfoot><tr><td v-for="(cell, ci) in summaryRow" :key="ci">{{ cell }}</td></tr></tfoot>
      </table>
      <DsButton size="sm" style="margin-top: 8px" @click="form.lines.push(blankLine())">添加明细行</DsButton>
      <div class="settle">
        <span>合计：<b>{{ total }}</b>（{{ cn(total) }}）</span>
        <span>优惠：-{{ promotion.discount.toFixed(2) }} <small>{{ promotion.source }}</small></span>
        <span>应付：<b class="payable">{{ promotion.payable.toFixed(2) }}</b> · 积分 +{{ promotion.pointsEarned }}</span>
      </div>
      <p class="settle-detail">{{ promotion.detail }}</p>
    </DsCard>

    <!-- AI 识别结果确认弹窗：可编辑后才落草稿 -->
    <DsModal v-model="aiVisible" title="AI 识别结果（请确认后填入）" :width="480">
      <textarea v-model="aiText" class="ds-input" rows="10" placeholder="粘贴文本或 JSON，如：客户：张三；产品A x2 @10" />
      <template #footer><DsButton variant="primary" @click="applyAi">填入表单</DsButton></template>
    </DsModal>
  </div>
</template>

<script setup lang="ts">
import { reactive, ref, computed, onMounted, onBeforeUnmount, watch } from 'vue';
import { useRoute, useRouter } from 'vue-router';
import { DsButton, DsCard, DsForm, DsFormItem, DsModal, DsSelect, DsTag } from '../../components';
import { useToast } from '../../components/ds/toast';
import { prompt as uiPrompt } from '../../components/ds/usePrompt';
import Decimal from 'decimal.js';
import { salesApi, inventoryApi, aiApi, printApi } from '../../api';
import { useBaseStore } from '../../store';
import { useUndoRedo } from '../../composables/useUndoRedo';
import { useUnsavedGuard } from '../../composables/useUnsavedGuard';
import { resolvePrice } from '../../utils/price';
import { currencies, rateOf } from '../../utils/currency';
import { listTemplates, saveTemplate } from '../../utils/docTemplates';
import { calcPromotion } from '../../utils/promotion';

const toast = useToast();
const route = useRoute();
const router = useRouter();
const base = useBaseStore();
const id = ref<number | null>(route.params.id ? Number(route.params.id) : null);
const saving = ref(false);
const warehouses = ref<any[]>([]);
const products = ref<any[]>([]);
const customers = ref<any[]>([]);
const aiVisible = ref(false);
const aiText = ref('');

const blankLine = () => ({ productId: null, qty: '1', unitPrice: '0', discount: '0', amount: '0' });
const form = reactive<any>({ orderNo: '', customerId: null, warehouseId: null, orderDate: new Date(), currency: 'CNY', lines: [blankLine()] });
/** 扫码枪/优惠/币种辅助状态 */
const scanBarcode = ref('');
const couponCode = ref('');
const currencyList = currencies();
const currencyRate = computed(() => rateOf(form.currency || 'CNY'));
const baseTotal = computed(() => Math.round(Number(total.value) * currencyRate.value * 100) / 100);
const promotion = computed(() => calcPromotion(Number(total.value), form.customerId, couponCode.value));
/** 撤销/重做与未保存保护 */
const dirty = ref(false);
const undoStack = useUndoRedo<any>(30);
const guard = useUnsavedGuard(() => ({ ...form }), 'sales-order-' + (id.value || 'new'), dirty, (draft) => Object.assign(form, draft));
// 表单变化标记脏数据；首次加载完成后再开启，避免回显触发提醒
let ready = false;
watch(form, () => { if (ready) dirty.value = true; }, { deep: true });
const total = computed(() => form.lines.reduce((a: Decimal.Value, r: any) => new Decimal(a).plus(r.amount || 0).toString(), '0'));
/** 已确认/已发货/已完成单据锁定编辑，防止重复保存与重复锁库存 */
const locked = computed(() => [2, 3, 4].includes(Number(form.status)) || ['CONFIRMED', 'SHIPPED', 'DONE', '已确认', '已完成'].includes(String(form.status)));

/** 原 el-option 列表改为 DsSelect 的 options 数组，数据源/字段完全不变 */
const customerOptions = computed(() => customers.value.map((c: any) => ({ label: c.name, value: c.id })));
const warehouseOptions = computed(() => warehouses.value.map((w: any) => ({ label: w.name, value: w.id })));
const productOptions = computed(() => products.value.map((p: any) => ({ label: p.name, value: p.id })));
const currencyOptions = computed(() => currencyList.map((c: any) => ({ label: c.code, value: c.code })));
/** 日期控件：form.orderDate 仍保存 Date 对象，仅换成原生 datetime-local 展示 */
const orderDateInput = computed(() => {
  const d: any = form.orderDate;
  if (!d) return '';
  const x = d instanceof Date ? d : new Date(d);
  if (Number.isNaN(x.getTime())) return '';
  const p2 = (n: number) => String(n).padStart(2, '0');
  return `${x.getFullYear()}-${p2(x.getMonth() + 1)}-${p2(x.getDate())}T${p2(x.getHours())}:${p2(x.getMinutes())}`;
});
function onOrderDateInput(e: Event) {
  const v = (e.target as HTMLInputElement).value;
  form.orderDate = v ? new Date(v) : null;
}
/** 合计行：保留 sumRows 原方法与其列下标/标签判定逻辑 */
const lineColumnsMeta = [{ label: '产品' }, { label: '数量' }, { label: '单价' }, { label: '折扣' }, { label: '金额' }, { label: '价格来源' }, { label: '' }];
const summaryRow = computed(() => sumRows({ columns: lineColumnsMeta, data: form.lines }));

/** 金额 = 数量 × 单价 − 折扣，全程 Decimal 避免浮点误差 */
function calc(row: any) {
  const p = products.value.find((x) => x.id === row.productId);
  if (p && (!row.unitPrice || row.unitPrice === '0')) row.unitPrice = p.price;
  row.amount = new Decimal(row.qty || 0).mul(row.unitPrice || 0).minus(row.discount || 0).toString();
}
/** 套用常用方案：一键载入历史商品组合到当前明细 */
async function applyTemplate(): Promise<void> {
  const templates = listTemplates('SALE');
  if (!templates.length) { toast.info('暂无常用方案，请先把当前明细存为方案'); return; }
  const picked = await uiPrompt(`选择要套用的方案（输入序号）：\n${templates.map((t, i) => `${i + 1}. ${t.name}（${t.lines.length} 行）`).join('\n')}`, '1', '套用方案');
  const index = Number(picked || 0) - 1;
  const target = templates[index];
  if (!target) return;
  form.lines = target.lines.map((l) => ({ ...l }));
  toast.success(`已套用方案「${target.name}」`);
}
/** 保存当前明细为常用方案 */
async function saveAsTemplate(): Promise<void> {
  const lines = form.lines.filter((l: any) => l.productId);
  if (!lines.length) { toast.warning('请先录入明细'); return; }
  const name = await uiPrompt('请输入方案名称', `方案 ${new Date().toLocaleDateString('zh-CN')}`, '保存为常用方案');
  if (!name) return;
  saveTemplate(name, 'SALE', lines as any);
  toast.success('已保存为常用方案');
}
/** 扫码枪录入：按条码定位产品，重复扫码自动累加数量 */
function onScan(): void {
  const code = scanBarcode.value.trim();
  if (!code) return;
  const product = products.value.find((p: any) => p.barcode === code || p.code === code || String(p.id) === code);
  if (!product) { toast.warning(`未找到条码 ${code} 对应的产品`); scanBarcode.value = ''; return; }
  const existing = form.lines.find((l: any) => Number(l.productId) === Number(product.id));
  if (existing) {
    existing.qty = String(Number(existing.qty || 0) + 1);
    calc(existing);
  } else {
    const line = blankLine();
    line.productId = product.id;
    line.qty = '1';
    onProduct(line);
    form.lines.push(line);
  }
  toast.success(`已扫码：${product.name}`);
  scanBarcode.value = '';
}
function onProduct(row: any) {
  const product = products.value.find((p: any) => Number(p.id) === Number(row.productId));
  if (product) {
    const resolved = resolvePrice(product, form.customerId, Number(row.qty || 1));
    row.unitPrice = String(resolved.price);
    row.priceSource = resolved.source;
  }
  calc(row);
}
function sumRows({ columns, data }: any) {
  return columns.map((c: any, i: number) => {
    if (i === 3) return '合计';
    if (c.label === '金额') return data.reduce((a: Decimal.Value, r: any) => new Decimal(a).plus(r.amount || 0).toString(), '0');
    return '';
  });
}
function cn(v: string) {
  const digits = '零壹贰叁肆伍陆柒捌玖'; const units = ['', '拾', '佰', '仟'];
  let n = Math.round(Number(v) * 100); const fen = n % 10; n = (n - fen) / 10; const jiao = n % 10; n = (n - jiao) / 10;
  if (n === 0 && jiao === 0 && fen === 0) return '零元整';
  let s = ''; let gi = 0;
  while (n > 0) {
    const g = n % 10000; let gs = ''; let zero = false;
    for (let i = 3; i >= 0; i--) { const d = Math.trunc(g / 10 ** i) % 10; if (d === 0) zero = true; else { if (zero && gs) gs += '零'; zero = false; gs += digits[d] + units[i]; } }
    if (gs) s = gs + ['', '万', '亿'][gi] + s; else if (s && !s.startsWith('零')) s = '零' + s;
    n = Math.trunc(n / 10000); gi++;
  }
  s += '元'; if (jiao === 0 && fen > 0) s += '零';
  if (jiao > 0) s += digits[jiao] + '角'; if (fen > 0) s += digits[fen] + '分';
  return s + '整';
}

async function onSave() {
  undoStack.record({ ...form });
  saving.value = true;
  try {
    // 将界面试算的促销后应付写回单据，避免"界面应付900、实际入账1000"
    const payload = {
      ...form,
      lines: form.lines.filter((l: any) => l.productId),
      totalAmount: Number(promotion.value.payable.toFixed(2)),
      discountAmount: Number(promotion.value.discount.toFixed(2)),
      pointsEarned: promotion.value.pointsEarned,
      currency: form.currency,
    };
    if (id.value) { await salesApi.update(id.value, payload); } else {
      const res: any = await salesApi.create(payload); id.value = res.id;
      router.replace(`/sales/orders/${res.id}`);
    }
    dirty.value = false;
    guard.clearDraft();
    toast.success('草稿已保存');
  } catch { /* 已提示 */ } finally { saving.value = false; }
}
async function onSubmit() { await onSave(); if (id.value) { await salesApi.submit(id.value); toast.success('已提交审批'); } }
async function onConfirm() { await onSave(); if (id.value) { await salesApi.confirm(id.value); toast.success('已确认，库存已锁定'); } }
async function onPrint() {
  if (!id.value) return;
  await printApi.createJob({ bizType: 'SALE_ORDER', bizId: id.value, copies: 1, channel: 'SERVER_PDF' });
  toast.success('打印任务已创建');
}

function aiPaste() { aiVisible.value = true; }
async function recommend() {
  try {
    const res: any = await aiApi.recommend({ customerId: form.customerId });
    toast.info(res.fallback ? '已使用本地推荐规则' : 'AI 推荐已返回');
    console.log('[AI 推荐]', res);
  } catch { /* 已提示 */ }
}
/** AI 文本 → 明细行：支持 JSON 数组或“名称 x数量 @单价”逐行文本；只预填，不自动保存 */
function applyAi() {
  try {
    const arr = JSON.parse(aiText.value);
    if (Array.isArray(arr)) {
      form.lines = arr.map((r: any) => ({ productId: r.productId || (products.value.find((p) => p.name === r.name || p.code === r.productCode) || {}).id || null,
        qty: String(r.qty ?? 1), unitPrice: String(r.unitPrice ?? r.price ?? 0), discount: String(r.discount ?? 0), amount: '0' }));
    } else throw new Error('非 JSON');
  } catch {
    form.lines = aiText.value.split('\n').filter(Boolean).map((line) => {
      const m = line.match(/(.+?)\s*x\s*(\d+(?:\.\d+)?)\s*@?\s*(\d+(?:\.\d+)?)?/i);
      const p = products.value.find((x) => line.includes(x.name));
      return { productId: p?.id || null, qty: m?.[2] || '1', unitPrice: m?.[3] || String(p?.price ?? 0), discount: '0', amount: '0' };
    });
  }
  form.lines.forEach(calc);
  aiVisible.value = false;
  toast.success('已填入明细，请核对后保存');
}

/** 键盘流：响应主框架派发的 erp-shortcut（N 新建行 / S 保存 / P 打印 / Ctrl+Enter 提交） */
function onShortcut(event: Event) {
  const action = (event as CustomEvent).detail;
  if (action === 'undo') {
    const snapshot = undoStack.undo({ ...form });
    if (snapshot) { Object.assign(form, snapshot); toast.info('已撤销上一步'); }
    return;
  }
  if (action === 'redo') {
    const snapshot = undoStack.redo({ ...form });
    if (snapshot) { Object.assign(form, snapshot); toast.info('已重做'); }
    return;
  }
  if (action === 'save') onSave();
  else if (action === 'submit') onSubmit();
  else if (action === 'print') onPrint();
  else if (action === 'new') form.lines.push({ productId: null, qty: '1', unitPrice: '0', discount: '0', amount: '0' });
}

onBeforeUnmount(() => window.removeEventListener('erp-shortcut', onShortcut));
onMounted(async () => {
  window.addEventListener('erp-shortcut', onShortcut);
  await base.ensure(); warehouses.value = base.warehouses;
  const [p, c] = await Promise.allSettled([inventoryApi.products({ pageSize: 200 }), salesApi.customers({ pageSize: 200 })]);
  if (p.status === 'fulfilled') products.value = (p.value as any).list || p.value || [];
  if (c.status === 'fulfilled') customers.value = ((c.value as any).list || []);
  if (id.value) {
    const d: any = await salesApi.detail(id.value);
    Object.assign(form, { orderNo: d.orderNo, customerId: d.customerId, warehouseId: d.warehouseId, orderDate: new Date(d.orderDate), status: d.status, payStatus: d.payStatus, shipStatus: d.shipStatus, paidAmount: d.paidAmount, totalAmount: d.totalAmount });
    form.lines = (d.lines || []).map((l: any) => ({ productId: l.productId, qty: String(l.qty), unitPrice: String(l.unitPrice), discount: String(l.discount), amount: String(l.amount) }));
  }
  ready = true;
});
</script>

<style scoped>
.scan-bar { display: flex; align-items: center; gap: 10px; padding: 8px 0; font-size: 13px; }
.scan-tip { color: var(--ds-text-3); }
.settle { display: flex; gap: 24px; align-items: center; margin-top: 8px; font-size: 13px; }
.settle small { color: var(--ds-text-3); }
.settle .payable { color: var(--ds-brand); font-size: 16px; }
.settle-detail { color: var(--ds-text-3); font-size: 12px; margin: 4px 0 0; }
</style>