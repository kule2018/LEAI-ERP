<!--
 * 清单销售（原型核心页）：统计卡 + 全量筛选 + 状态色 + 操作列 + 分页
 * 对应文档 3.2 / 8 章；筛选参数与后端 SalesService.list 一一对应。
-->
<template>
  <div class="entity-page">
    <!-- 顶部统计：销售单数 / 合计金额 / 已收款 / 未收款 -->
    <div class="entity-stats">
      <div class="entity-stat"><span>销售单数</span><b>{{ summary?.orderCount ?? list.length }}</b></div>
      <div class="entity-stat"><span>合计金额</span><b class="stat-total">¥{{ money(summary?.totalAmount) }}</b></div>
      <div class="entity-stat"><span>已收款</span><b class="stat-paid">¥{{ money(summary?.paidAmount) }}</b></div>
      <div class="entity-stat"><span>未收款</span><b class="stat-unpaid">¥{{ money(summary?.unpaidAmount) }}</b></div>
    </div>

    <DsCard :pad="false">
      <div class="entity-search">
        <span class="entity-date-range">
          <DsDatePicker v-model="startDate" placeholder="开始日期" />
          <span class="entity-date-sep">~</span>
          <DsDatePicker v-model="endDate" placeholder="结束日期" />
        </span>
        <DsSelect v-model="q.customerId" :options="customerOptions" placeholder="客户" clearable size="sm" style="width: 140px" />
        <DsSelect v-model="q.warehouseId" :options="warehouseOptions" placeholder="仓库" clearable size="sm" style="width: 128px" />
        <DsSelect v-model="q.status" :options="docStatusOptions" placeholder="状态" clearable size="sm" style="width: 118px" />
        <DsSelect v-model="q.payStatus" :options="payStatusOptions" placeholder="支付状态" clearable size="sm" style="width: 126px" />
        <DsSelect v-model="q.shipStatus" :options="shipStatusOptions" placeholder="发货状态" clearable size="sm" style="width: 132px" />
        <input v-model="q.keyword" class="ds-input entity-search__input" placeholder="单号/电话" @keyup.enter="reload" />
        <DsButton variant="primary" size="sm" @click="reload">查询</DsButton>
        <DsButton size="sm" @click="reset">重置</DsButton>
        <span class="entity-search__spacer" />
        <DsButton v-perm="'sales:order:create'" variant="primary" size="sm" @click="$router.push('/sales/orders/new')">新建销售单</DsButton>
        <DsButton size="sm" @click="$router.push('/sales/pos')">POS 运营中心</DsButton>
        <DsButton size="sm" @click="printList">PDF</DsButton>
        <DsButton size="sm" @click="exportExcel">EXCEL</DsButton>
        <DsButton size="sm" :disabled="!selected.length" @click="batchVisible = true">批量打印（{{ selected.length }}）</DsButton>
      </div>
    </DsCard>

    <DsCard :pad="false">
      <div class="entity-table" v-loading="loading">
        <table class="ds-table">
          <thead>
            <tr>
              <th style="width:42px">
                <input type="checkbox" :checked="list.length > 0 && selected.length === list.length" @change="toggleAllSelected(($event.target as HTMLInputElement).checked)" />
              </th>
              <th>单号</th><th>客户</th><th>日期</th><th>金额</th><th>已收</th>
              <th>状态</th><th>支付</th><th>发货</th><th style="width:300px">操作</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="s in list" :key="s.id">
              <td><input type="checkbox" :checked="selected.includes(s)" @change="toggleRowSelected(s, ($event.target as HTMLInputElement).checked)" /></td>
              <td>{{ s.orderNo }}</td>
              <td>{{ s.customerName }}</td>
              <td>{{ s.orderDate }}</td>
              <td>¥{{ money(s.totalAmount) }}</td>
              <td>¥{{ money(s.paidAmount) }}</td>
              <td><DsTag :color="statusColor(s.status)" size="sm">{{ statusText(s.status) }}</DsTag></td>
              <td><DsTag :color="payColor(s.payStatus)" size="sm">{{ payText(s.payStatus) }}</DsTag></td>
              <td><DsTag :color="shipColor(s.shipStatus)" size="sm">{{ shipText(s.shipStatus) }}</DsTag></td>
              <td>
                <DsButton variant="text" size="sm" @click="$router.push(`/sales/orders/${s.id}`)">查看</DsButton>
                <DsButton variant="text" size="sm" @click="onMonth(s)">当月累计</DsButton>
                <DsButton v-perm="'sales:order:create'" variant="text" size="sm" @click="onCopy(s)">复制</DsButton>
                <DsButton v-if="s.status === 1" v-perm="'sales:order:confirm'" variant="text" size="sm" @click="act(() => salesApi.confirm(s.id), '已确认')">确认</DsButton>
                <DsButton v-if="[2, 3].includes(s.status)" v-perm="'sales:order:ship'" variant="text" size="sm" @click="act(() => salesApi.ship(s.id), '已发货')">发货</DsButton>
                <DsButton v-if="[2, 3, 4].includes(s.status) && !s.invoiceNo" v-perm="'finance:invoice:create'" variant="text" size="sm" @click="onInvoice(s)">开票</DsButton>
                <DsButton v-if="s.status === 0" v-perm="'sales:order:edit'" variant="text" size="sm" @click="act(() => salesApi.submit(s.id), '已提交')">提交</DsButton>
                <DsButton variant="text" size="sm" @click="onPrint(s)">打印</DsButton>
                <DsButton v-perm="'sales:order:void'" variant="danger" size="sm" @click="onVoid(s)">作废</DsButton>
              </td>
            </tr>
            <tr v-if="!list.length"><td colspan="10" class="entity-empty">暂无销售单</td></tr>
          </tbody>
        </table>
      </div>
      <div class="entity-pager">
        <DsPagination v-model:current-page="page" :page-size="pageSize" :total="total" layout="total, sizes, prev, pager, next" @current-change="load" @change="load" />
      </div>
    </DsCard>

    <!-- 行操作：查看当月累计 -->
    <DsModal v-model="monthVisible" title="客户当月累计" :width="480">
      <div class="entity-form">
        <label class="entity-field"><span>客户</span><b>{{ monthCustomer }}</b></label>
        <label class="entity-field"><span>统计区间</span><b>{{ monthRange }}</b></label>
        <label class="entity-field"><span>当月单数</span><b>{{ monthData.count }}</b></label>
        <label class="entity-field"><span>当月金额</span><b>¥{{ monthData.total }}</b></label>
        <label class="entity-field"><span>已收款</span><b class="stat-paid">¥{{ monthData.paid }}</b></label>
        <label class="entity-field"><span>未收款</span><b class="stat-unpaid">¥{{ monthData.unpaid }}</b></label>
      </div>
      <template #footer><div class="entity-modal-foot"><DsButton variant="primary" @click="monthVisible = false">关闭</DsButton></div></template>
    </DsModal>

    <!-- 批量打印：选择模板/份数/渠道，逐单生成任务并输出成功失败报告 -->
    <BatchPrintDialog v-model="batchVisible" biz-type="SALE_ORDER" :rows="selected" />
  </div>
</template>

<script setup lang="ts">
import { computed, reactive, ref, toRefs, onMounted } from 'vue';
import Decimal from 'decimal.js';
import { DsButton, DsCard, DsDatePicker, DsModal, DsPagination, DsSelect, DsTag } from '../../components';
import { useToast } from '../../components/ds/toast';
import { confirm as uiConfirm } from '../../components/ds/useConfirm';
import { salesApi, printApi, inventoryApi } from '../../api';
import { useListPage, runAction, confirmVoid, PAY_STATUS, SHIP_STATUS } from '../crud';
import BatchPrintDialog from '../print/BatchPrintDialog.vue';

/** DsTag 语义色 */
type TagColor = 'brand' | 'success' | 'warning' | 'danger' | 'neutral';
/** 原型状态文案：待核 ↔ 完成，其余沿用单据状态机 */
const DOC_TEXT: Record<number, string> = { 0: '草稿', 1: '已待核', 2: '已确认', 3: '部分完成', 4: '已完成', 9: '已作废' };
/** 文档 8 章状态色：完成/已付款=绿，待核/未付款=红，进行中=蓝，作废=灰 */
const DOC_COLOR: Record<number, TagColor> = { 0: 'neutral', 1: 'danger', 2: 'brand', 3: 'brand', 4: 'success', 9: 'neutral' };
const PAY_COLOR: Record<number, TagColor> = { 0: 'danger', 1: 'warning', 2: 'success' };
const SHIP_COLOR: Record<number, TagColor> = { 0: 'neutral', 1: 'warning', 2: 'success' };

const toast = useToast();
/** useListPage 返回普通对象，必须经 reactive + toRefs 才能保持列表/分页响应式 */
const st = reactive(useListPage<any>((params) => salesApi.list(params)));
const { loading, list, summary, page, pageSize, total } = toRefs(st) as any;
const q = reactive<{ keyword?: string; customerId?: any; warehouseId?: any; status?: any; payStatus?: any; shipStatus?: any; date?: any }>({});
/** 批量打印选择集 */
const selected = ref<any[]>([]);
const batchVisible = ref(false);
const customers = ref<any[]>([]);
const warehouses = ref<any[]>([]);

/** 金额格式化：用 decimal.js 避免浮点误差，统一两位小数 */
function money(v: any): string { return new Decimal(v || 0).toFixed(2); }
function statusText(v: any) { return DOC_TEXT[Number(v)] || '草稿'; }
function statusColor(v: any): TagColor { return DOC_COLOR[Number(v)] || 'neutral'; }
function payText(v: any) { return PAY_STATUS[Number(v)] || '未付'; }
function payColor(v: any): TagColor { return PAY_COLOR[Number(v)] || 'neutral'; }
function shipText(v: any) { return SHIP_STATUS[Number(v)] || '未发货'; }
function shipColor(v: any): TagColor { return SHIP_COLOR[Number(v)] || 'neutral'; }

const toOptions = (rows: any[]) => rows.map((r) => ({ label: r.name || r.realName || String(r.id), value: r.id }));
const customerOptions = computed(() => toOptions(customers.value));
const warehouseOptions = computed(() => toOptions(warehouses.value));
const docStatusOptions = Object.entries(DOC_TEXT).map(([k, v]) => ({ label: v, value: Number(k) }));
const payStatusOptions = Object.entries(PAY_STATUS).map(([k, v]) => ({ label: v, value: Number(k) }));
const shipStatusOptions = Object.entries(SHIP_STATUS).map(([k, v]) => ({ label: v, value: Number(k) }));

/** 日期区间：q.date 仍是 [开始,结束] 数组，界面用 DsDatePicker */
const fmtDate = (v: any) => v instanceof Date
  ? `${v.getFullYear()}-${String(v.getMonth() + 1).padStart(2, '0')}-${String(v.getDate()).padStart(2, '0')}`
  : (v ? String(v).slice(0, 10) : '');
function setDate(index: number, value: string) {
  const next = Array.isArray(q.date) ? [...q.date] : [];
  next[index] = value;
  q.date = next;
}
const startDate = computed({
  get: () => fmtDate(Array.isArray(q.date) ? q.date[0] : ''),
  set: (v) => setDate(0, v),
});
const endDate = computed({
  get: () => fmtDate(Array.isArray(q.date) ? q.date[1] : ''),
  set: (v) => setDate(1, v),
});
/** 原生复选列：selected 仍为选中行对象数组，批量打印字段不变 */
function toggleRowSelected(row: any, checked: boolean) { selected.value = checked ? [...selected.value, row] : selected.value.filter((r) => r !== row); }
function toggleAllSelected(checked: boolean) { selected.value = checked ? [...list.value] : []; }

function reload() { page.value = 1; load(); }
function reset() {
  Object.assign(q, { keyword: '', customerId: undefined, warehouseId: undefined, status: undefined, payStatus: undefined, shipStatus: undefined, date: undefined });
  reload();
}
async function load() {
  const [start, end] = Array.isArray(q.date) ? q.date : [];
  await st.load({
    keyword: q.keyword, customerId: q.customerId, warehouseId: q.warehouseId,
    status: q.status, payStatus: q.payStatus, shipStatus: q.shipStatus,
    date: q.date, startDate: start, endDate: end,
  });
}
function act(fn: () => Promise<any>, msg: string) { runAction(fn, msg, load); }
async function onInvoice(row: any) {
  if (!await uiConfirm(`确定为销售单 ${row.orderNo} 开具发票吗？`, '开票确认')) return;
  runAction(() => salesApi.invoice(row.id), '开票成功并已关联发票', load);
}
function onVoid(row: any) { confirmVoid(() => salesApi.void(row.id), load); }
async function onCopy(row: any) { runAction(() => salesApi.copy(row.id), '已复制为新草稿', load); }
async function onPrint(row: any) {
  await printApi.createJob({ bizType: 'SALE_ORDER', bizId: row.id, copies: 1, channel: 'SERVER_PDF' });
  toast.success('打印任务已创建，可在打印记录中查看');
}

/** 行操作：按客户 + 本月日期区间重新查询并汇总，不依赖列表 summary（Mock 的 summary 是全量） */
const monthVisible = ref(false);
const monthCustomer = ref('');
const monthData = reactive({ count: 0, total: '0.00', paid: '0.00', unpaid: '0.00' });
const monthRange = computed(() => {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-01 ~ ${fmtDate(d)}`;
});
async function onMonth(row: any) {
  monthCustomer.value = row.customerName || '';
  Object.assign(monthData, { count: 0, total: '0.00', paid: '0.00', unpaid: '0.00' });
  monthVisible.value = true;
  try {
    const d = new Date();
    const first = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-01`;
    const today = fmtDate(d);
    const res: any = await salesApi.list({ customerId: row.customerId, pageSize: 500, date: [first, today], startDate: first, endDate: today });
    const rows: any[] = (res?.list || res || []).filter((o: any) => Number(o.customerId) === Number(row.customerId));
    const sum = (key: string) => rows.reduce((s, o) => s.plus(new Decimal(o[key] || 0)), new Decimal(0));
    const totalAmt = sum('totalAmount');
    const paidAmt = sum('paidAmount');
    Object.assign(monthData, { count: rows.length, total: totalAmt.toFixed(2), paid: paidAmt.toFixed(2), unpaid: totalAmt.minus(paidAmt).toFixed(2) });
  } catch { toast.error('当月累计查询失败'); }
}
function exportExcel() {
  const cols = ['单号', '客户', '日期', '金额', '已收', '状态', '支付', '发货'];
  const lines = [cols.join(','), ...list.value.map((s: any) => [
    s.orderNo, s.customerName, s.orderDate, money(s.totalAmount), money(s.paidAmount),
    statusText(s.status), payText(s.payStatus), shipText(s.shipStatus),
  ].map((v) => `"${String(v ?? '').replace(/"/g, '""')}"`).join(','))];
  const blob = new Blob(['\ufeff' + lines.join('\n')], { type: 'text/csv;charset=utf-8' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob); a.download = `销售单_${new Date().toISOString().slice(0, 10)}.csv`; a.click();
  URL.revokeObjectURL(a.href);
  toast.success(`已导出 ${list.value.length} 条销售单`);
}
function printList() { window.print(); }

onMounted(async () => {
  const [c, w]: any[] = await Promise.all([
    salesApi.customers({ pageSize: 500 }).catch(() => []),
    inventoryApi.warehouses().catch(() => []),
  ]);
  customers.value = Array.isArray(c) ? c : (c?.list || []);
  warehouses.value = Array.isArray(w) ? w : (w?.list || w || []);
  load();
});
</script>

<style scoped>
.entity-date-sep { color: var(--ds-text-3); flex: 0 0 auto; }
.entity-date-range { display: inline-flex; align-items: center; gap: 6px; flex: 0 0 auto; }
.entity-date-range .ds-dp { width: 138px !important; flex: 0 0 138px; }
.stat-total { color: var(--ds-brand, #4d6bfe); }
.stat-paid { color: var(--ds-success, #16a34a); }
.stat-unpaid { color: var(--ds-danger, #dc2626); }
.entity-field b { font-size: var(--ds-font-md); }
@media (max-width: 1200px) { .entity-date-range .ds-dp { width: 120px !important; flex-basis: 120px; } }
</style>
