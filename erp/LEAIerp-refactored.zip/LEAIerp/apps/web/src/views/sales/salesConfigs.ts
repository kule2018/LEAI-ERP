/** 销售客户模块 16 个页面的独立字段、表单与业务动作配置。 */
export interface SalesField {
  prop: string;
  label: string;
  type?: 'text' | 'number' | 'date' | 'select' | 'textarea';
  options?: { label: string; value: any }[];
  source?: 'customers' | 'products' | 'orders' | 'groups' | 'suppliers';
  required?: boolean;
  hidden?: boolean;
  placeholder?: string;
}

export interface SalesAction {
  key: string;
  label: string;
  variant?: 'primary' | 'warning' | 'danger' | 'default';
  from?: any[];
}

export interface SalesConfig {
  title: string;
  api: string;
  collection: string;
  columns: SalesField[];
  fields: SalesField[];
  statusField?: string;
  statusLabels?: Record<string, string>;
  actions?: SalesAction[];
  readOnly?: boolean;
  /** 页面形态：决定整体布局、操作面板和展示节奏，避免所有业务共用一个表格 */
  layout?: 'list' | 'workflow' | 'analytics' | 'warehouse' | 'bom' | 'kanban' | 'qc' | 'equipment' | 'gantt' | 'ledger' | 'approval' | 'people' | 'calendar' | 'files' | 'chat';
  defaults?: () => Record<string, any>;
}

const DOC_STATUS = { '0': '草稿', '1': '待审批', '2': '审批通过', '3': '已完成', '4': '已驳回', '9': '已作废' };
const MASTER_STATUS = { '0': '停用', '1': '启用' };
const docActions: SalesAction[] = [
  { key: 'submit', label: '提交审批', variant: 'primary', from: [0] },
  { key: 'approve', label: '审批通过', variant: 'primary', from: [1] },
  { key: 'reject', label: '驳回', variant: 'danger', from: [1] },
  { key: 'execute', label: '执行/过账', variant: 'primary', from: [2] },
  { key: 'void', label: '作废', variant: 'danger', from: [0, 1, 2, 3] },
];
const masterActions: SalesAction[] = [
  { key: 'toggle', label: '停用', variant: 'warning', from: [1] },
  { key: 'enable', label: '启用', variant: 'primary', from: [0] },
  { key: 'copy', label: '复制' },
];

const today = () => new Date().toISOString().slice(0, 10);
const no = (p: string) => `${p}${new Date().toISOString().replace(/\D/g, '').slice(0, 12)}`;

export const SALES_CONFIGS: Record<string, SalesConfig> = {
  customers: {
    title: '客户列表', api: '/api/v1/crm/customers', collection: 'crmCustomers',
    columns: [
      { prop: 'name', label: '客户名称' }, { prop: 'code', label: '客户编码' },
      { prop: 'phone', label: '联系电话' }, { prop: 'priceLevel', label: '价格级别' },
      { prop: 'creditLimit', label: '信用额度' }, { prop: 'groupName', label: '客户分组' },
      { prop: 'status', label: '状态' },
    ],
    fields: [
      { prop: 'name', label: '客户名称', required: true }, { prop: 'code', label: '客户编码', required: true },
      { prop: 'phone', label: '联系电话' }, { prop: 'address', label: '通讯地址' },
      { prop: 'priceLevel', label: '价格级别', type: 'select', options: [{ label: '普通', value: 1 }, { label: '银卡', value: 2 }, { label: '金卡', value: 3 }] },
      { prop: 'creditLimit', label: '信用额度', type: 'number' },
      { prop: 'groupId', label: '客户分组', type: 'select', source: 'groups' },
      { prop: 'status', label: '状态', type: 'select', options: [{ label: '启用', value: 1 }, { label: '停用', value: 0 }] },
    ],
    statusField: 'status', statusLabels: MASTER_STATUS, actions: masterActions,
    defaults: () => ({ priceLevel: 1, creditLimit: 0, status: 1 }),
  },
  'customer-groups': {
    title: '客户分组', api: '/api/v1/crm/customer-groups', collection: 'crmCustomerGroups',
    columns: [{ prop: 'name', label: '分组名称' }, { prop: 'code', label: '分组编码' }, { prop: 'remark', label: '说明' }, { prop: 'status', label: '状态' }],
    fields: [
      { prop: 'name', label: '分组名称', required: true }, { prop: 'code', label: '分组编码', required: true },
      { prop: 'remark', label: '分组说明', type: 'textarea' },
      { prop: 'status', label: '状态', type: 'select', options: [{ label: '启用', value: 1 }, { label: '停用', value: 0 }] },
    ],
    statusField: 'status', statusLabels: MASTER_STATUS, actions: masterActions,
    defaults: () => ({ status: 1 }),
  },
  'customer-levels': {
    title: '客户等级', api: '/api/v1/crm/customer-levels', collection: 'crmCustomerLevels',
    columns: [{ prop: 'name', label: '等级名称' }, { prop: 'discount', label: '折扣(%)' }, { prop: 'minAmount', label: '最低采购额' }, { prop: 'remark', label: '说明' }, { prop: 'status', label: '状态' }],
    fields: [
      { prop: 'name', label: '等级名称', required: true },
      { prop: 'discount', label: '折扣(%)', type: 'number', required: true },
      { prop: 'minAmount', label: '最低采购额', type: 'number' },
      { prop: 'remark', label: '等级说明', type: 'textarea' },
      { prop: 'status', label: '状态', type: 'select', options: [{ label: '启用', value: 1 }, { label: '停用', value: 0 }] },
    ],
    statusField: 'status', statusLabels: MASTER_STATUS, actions: masterActions,
    defaults: () => ({ discount: 100, minAmount: 0, status: 1 }),
  },
  contacts: {
    title: '客户联系人', api: '/api/v1/crm/contacts', collection: 'crmContacts',
    columns: [{ prop: 'name', label: '姓名' }, { prop: 'customerId', label: '所属客户', source: 'customers' }, { prop: 'position', label: '职务' }, { prop: 'phone', label: '手机' }, { prop: 'email', label: '邮箱' }, { prop: 'isPrimary', label: '主联系人' }, { prop: 'status', label: '状态' }],
    fields: [
      { prop: 'name', label: '姓名', required: true },
      { prop: 'customerId', label: '所属客户', type: 'select', source: 'customers', required: true },
      { prop: 'position', label: '职务' }, { prop: 'phone', label: '手机' }, { prop: 'email', label: '邮箱' },
      { prop: 'isPrimary', label: '主联系人', type: 'select', options: [{ label: '是', value: 1 }, { label: '否', value: 0 }] },
      { prop: 'status', label: '状态', type: 'select', options: [{ label: '启用', value: 1 }, { label: '停用', value: 0 }] },
    ],
    statusField: 'status', statusLabels: MASTER_STATUS, actions: masterActions,
    defaults: () => ({ isPrimary: 0, status: 1 }),
  },
  quotations: {
    title: '报价单', api: '/api/v1/crm/quotations', collection: 'crmQuotations',
    columns: [{ prop: 'quoteNo', label: '报价单号' }, { prop: 'customerId', label: '客户', source: 'customers' }, { prop: 'totalAmount', label: '报价金额' }, { prop: 'validUntil', label: '有效期至' }, { prop: 'status', label: '状态' }],
    fields: [
      { prop: 'quoteNo', label: '报价单号', required: true },
      { prop: 'customerId', label: '客户', type: 'select', source: 'customers', required: true },
      { prop: 'totalAmount', label: '报价金额', type: 'number', required: true },
      { prop: 'validUntil', label: '有效期至', type: 'date' },
      { prop: 'status', label: '状态', type: 'select', options: Object.entries(DOC_STATUS).map(([k, v]) => ({ label: v, value: Number(k) })) },
    ],
    statusField: 'status', statusLabels: DOC_STATUS, actions: docActions,
    defaults: () => ({ quoteNo: no('QT'), totalAmount: 0, status: 0, validUntil: today() }),
  },
  'quote-templates': {
    title: '报价模板', api: '/api/v1/crm/quote-templates', collection: 'crmQuoteTemplates',
    columns: [{ prop: 'name', label: '模板名称' }, { prop: 'lineCount', label: '明细行数' }, { prop: 'remark', label: '模板说明' }, { prop: 'status', label: '状态' }],
    fields: [
      { prop: 'name', label: '模板名称', required: true },
      { prop: 'lineCount', label: '明细行数', type: 'number' },
      { prop: 'remark', label: '模板说明', type: 'textarea' },
      { prop: 'status', label: '状态', type: 'select', options: [{ label: '启用', value: 1 }, { label: '停用', value: 0 }] },
    ],
    statusField: 'status', statusLabels: MASTER_STATUS, actions: masterActions,
    defaults: () => ({ lineCount: 0, status: 1 }),
  },
  contracts: {
    title: '销售合同', api: '/api/v1/crm/contracts', collection: 'crmContracts',
    columns: [{ prop: 'contractNo', label: '合同编号' }, { prop: 'name', label: '合同名称' }, { prop: 'customerId', label: '客户', source: 'customers' }, { prop: 'amount', label: '合同金额' }, { prop: 'signDate', label: '签订日期' }, { prop: 'status', label: '状态' }],
    fields: [
      { prop: 'contractNo', label: '合同编号', required: true },
      { prop: 'name', label: '合同名称', required: true },
      { prop: 'customerId', label: '客户', type: 'select', source: 'customers', required: true },
      { prop: 'amount', label: '合同金额', type: 'number', required: true },
      { prop: 'signDate', label: '签订日期', type: 'date' },
      { prop: 'remark', label: '合同条款', type: 'textarea' },
      { prop: 'status', label: '状态', type: 'select', options: Object.entries(DOC_STATUS).map(([k, v]) => ({ label: v, value: Number(k) })) },
    ],
    statusField: 'status', statusLabels: DOC_STATUS, actions: docActions,
    defaults: () => ({ contractNo: no('HT'), amount: 0, status: 0, signDate: today() }),
  },
  promotions: {
    title: '促销活动', api: '/api/v1/crm/promotions', collection: 'crmPromotions',
    columns: [{ prop: 'promoNo', label: '活动编号' }, { prop: 'name', label: '活动名称' }, { prop: 'type', label: '活动类型' }, { prop: 'discount', label: '折扣(%)' }, { prop: 'startDate', label: '开始日期' }, { prop: 'endDate', label: '结束日期' }, { prop: 'status', label: '状态' }],
    fields: [
      { prop: 'promoNo', label: '活动编号', required: true },
      { prop: 'name', label: '活动名称', required: true },
      { prop: 'type', label: '活动类型', type: 'select', options: [{ label: '折扣', value: '折扣' }, { label: '满减', value: '满减' }, { label: '赠品', value: '赠品' }] },
      { prop: 'discount', label: '折扣(%)', type: 'number' },
      { prop: 'startDate', label: '开始日期', type: 'date' }, { prop: 'endDate', label: '结束日期', type: 'date' },
      { prop: 'remark', label: '活动说明', type: 'textarea' },
      { prop: 'status', label: '状态', type: 'select', options: Object.entries(DOC_STATUS).map(([k, v]) => ({ label: v, value: Number(k) })) },
    ],
    statusField: 'status', statusLabels: DOC_STATUS, actions: docActions,
    defaults: () => ({ promoNo: no('CX'), type: '折扣', discount: 100, status: 0, startDate: today(), endDate: today() }),
  },
  returns: {
    title: '销售退货', api: '/api/v1/sales/returns', collection: 'salesReturns',
    columns: [{ prop: 'returnNo', label: '退货单号' }, { prop: 'customerId', label: '客户', source: 'customers' }, { prop: 'productName', label: '退货产品' }, { prop: 'qty', label: '退货数量' }, { prop: 'amount', label: '退货金额' }, { prop: 'reason', label: '退货原因' }, { prop: 'status', label: '状态' }],
    fields: [
      { prop: 'returnNo', label: '退货单号', required: true },
      { prop: 'customerId', label: '客户', type: 'select', source: 'customers', required: true },
      { prop: 'orderId', label: '原销售单', type: 'select', source: 'orders' },
      { prop: 'productName', label: '退货产品', required: true },
      { prop: 'qty', label: '退货数量', type: 'number', required: true },
      { prop: 'amount', label: '退货金额', type: 'number', required: true },
      { prop: 'reason', label: '退货原因', type: 'textarea' },
      { prop: 'status', label: '状态', type: 'select', options: Object.entries(DOC_STATUS).map(([k, v]) => ({ label: v, value: Number(k) })) },
    ],
    statusField: 'status', statusLabels: DOC_STATUS, actions: docActions,
    defaults: () => ({ returnNo: no('TH'), qty: 1, amount: 0, status: 0 }),
  },
  exchanges: {
    title: '换货单', api: '/api/v1/sales/exchanges', collection: 'salesExchanges',
    columns: [{ prop: 'exchangeNo', label: '换货单号' }, { prop: 'customerId', label: '客户', source: 'customers' }, { prop: 'oldProduct', label: '原商品' }, { prop: 'newProduct', label: '换入商品' }, { prop: 'qty', label: '数量' }, { prop: 'amount', label: '补差价' }, { prop: 'status', label: '状态' }],
    fields: [
      { prop: 'exchangeNo', label: '换货单号', required: true },
      { prop: 'customerId', label: '客户', type: 'select', source: 'customers', required: true },
      { prop: 'oldProduct', label: '原商品', required: true }, { prop: 'newProduct', label: '换入商品', required: true },
      { prop: 'qty', label: '数量', type: 'number', required: true }, { prop: 'amount', label: '补差价', type: 'number' },
      { prop: 'remark', label: '换货说明', type: 'textarea' },
      { prop: 'status', label: '状态', type: 'select', options: Object.entries(DOC_STATUS).map(([k, v]) => ({ label: v, value: Number(k) })) },
    ],
    statusField: 'status', statusLabels: DOC_STATUS, actions: docActions,
    defaults: () => ({ exchangeNo: no('HH'), qty: 1, amount: 0, status: 0 }),
  },
  shipments: {
    title: '出货单', api: '/api/v1/sales/shipments', collection: 'salesShipments',
    columns: [{ prop: 'shipmentNo', label: '出货单号' }, { prop: 'orderId', label: '销售单' }, { prop: 'customerId', label: '客户', source: 'customers' }, { prop: 'amount', label: '出货金额' }, { prop: 'shipDate', label: '出货日期' }, { prop: 'carrier', label: '承运商' }, { prop: 'trackingNo', label: '物流单号' }, { prop: 'status', label: '状态' }],
    fields: [
      { prop: 'shipmentNo', label: '出货单号', required: true },
      { prop: 'orderId', label: '销售单', type: 'select', source: 'orders' },
      { prop: 'customerId', label: '客户', type: 'select', source: 'customers', required: true },
      { prop: 'amount', label: '出货金额', type: 'number' }, { prop: 'shipDate', label: '出货日期', type: 'date' },
      { prop: 'carrier', label: '承运商', type: 'select', options: [{ label: '顺丰速运', value: '顺丰速运' }, { label: '京东物流', value: '京东物流' }, { label: '中通快递', value: '中通快递' }] },
      { prop: 'trackingNo', label: '物流单号' },
      { prop: 'status', label: '状态', type: 'select', options: Object.entries(DOC_STATUS).map(([k, v]) => ({ label: v, value: Number(k) })) },
    ],
    statusField: 'status', statusLabels: DOC_STATUS, actions: docActions,
    defaults: () => ({ shipmentNo: no('FH'), amount: 0, status: 0, shipDate: today(), carrier: '顺丰速运' }),
  },
  statements: {
    title: '客户对账单', api: '/api/v1/sales/statements', collection: 'salesStatements',
    columns: [{ prop: 'statementNo', label: '对账单号' }, { prop: 'customerId', label: '客户', source: 'customers' }, { prop: 'period', label: '对账期间' }, { prop: 'amount', label: '应收金额' }, { prop: 'settledAmount', label: '已结金额' }, { prop: 'status', label: '状态' }],
    fields: [
      { prop: 'statementNo', label: '对账单号', required: true },
      { prop: 'customerId', label: '客户', type: 'select', source: 'customers', required: true },
      { prop: 'period', label: '对账期间', required: true, placeholder: '如 2026-11' },
      { prop: 'amount', label: '应收金额', type: 'number', required: true },
      { prop: 'settledAmount', label: '已结金额', type: 'number' },
      { prop: 'status', label: '状态', type: 'select', options: Object.entries(DOC_STATUS).map(([k, v]) => ({ label: v, value: Number(k) })) },
    ],
    statusField: 'status', statusLabels: DOC_STATUS, actions: docActions,
    defaults: () => ({ statementNo: no('DZ'), period: today().slice(0, 7), amount: 0, settledAmount: 0, status: 0 }),
  },
  pos: {
    title: 'POS 收银', api: '/api/v1/sales/pos', collection: 'salesPos',
    columns: [{ prop: 'orderNo', label: 'POS 单号' }, { prop: 'totalAmount', label: '应收金额' }, { prop: 'paidAmount', label: '已收金额' }, { prop: 'payType', label: '支付方式' }, { prop: 'status', label: '状态' }],
    fields: [
      { prop: 'orderNo', label: 'POS 单号', required: true },
      { prop: 'totalAmount', label: '应收金额', type: 'number', required: true },
      { prop: 'paidAmount', label: '已收金额', type: 'number' },
      { prop: 'payType', label: '支付方式', type: 'select', options: [{ label: '微信支付', value: '微信支付' }, { label: '支付宝', value: '支付宝' }, { label: '现金', value: '现金' }, { label: '银行卡', value: '银行卡' }] },
      { prop: 'remark', label: '备注', type: 'textarea' },
      { prop: 'status', label: '状态', type: 'select', options: Object.entries(DOC_STATUS).map(([k, v]) => ({ label: v, value: Number(k) })) },
    ],
    statusField: 'status', statusLabels: DOC_STATUS,
    actions: [
      { key: 'execute', label: '确认收款', variant: 'primary', from: [1, 2] },
      { key: 'void', label: '作废', variant: 'danger', from: [0, 1, 2] },
    ],
    defaults: () => ({ orderNo: no('POS'), totalAmount: 0, paidAmount: 0, payType: '微信支付', status: 1 }),
  },
  profit: {
    title: '销售毛利分析', api: '/api/v1/sales/profit', collection: 'salesProfit', readOnly: true,
    columns: [{ prop: 'productId', label: '产品ID' }, { prop: 'productName', label: '产品名称' }, { prop: 'qty', label: '销量' }, { prop: 'revenue', label: '销售收入' }, { prop: 'cost', label: '销售成本' }, { prop: 'profit', label: '毛利' }, { prop: 'margin', label: '毛利率(%)' }, { prop: 'period', label: '期间' }],
    fields: [], statusField: 'status',
  },
  unshipped: {
    title: '未发货清单', api: '/api/v1/sales/unshipped', collection: 'salesUnshipped',
    columns: [{ prop: 'orderNo', label: '销售单号' }, { prop: 'customerId', label: '客户', source: 'customers' }, { prop: 'productName', label: '商品' }, { prop: 'qty', label: '待发数量' }, { prop: 'amount', label: '金额' }, { prop: 'status', label: '状态' }],
    fields: [
      { prop: 'orderNo', label: '销售单号', required: true },
      { prop: 'customerId', label: '客户', type: 'select', source: 'customers', required: true },
      { prop: 'productName', label: '商品', required: true },
      { prop: 'qty', label: '待发数量', type: 'number', required: true },
      { prop: 'amount', label: '金额', type: 'number' },
      { prop: 'status', label: '状态', type: 'select', options: [{ label: '待发货', value: 0 }, { label: '已安排', value: 1 }, { label: '已发货', value: 3 }] },
    ],
    statusField: 'status', statusLabels: { '0': '待发货', '1': '已安排', '3': '已发货', '9': '已作废' },
    actions: [
      { key: 'ship', label: '确认发货', variant: 'primary', from: [0, 1] },
      { key: 'void', label: '作废', variant: 'danger', from: [0, 1] },
    ],
    defaults: () => ({ qty: 1, amount: 0, status: 0 }),
  },
};

export function configFor(key: string): SalesConfig {
  const c = SALES_CONFIGS[key];
  if (!c) throw new Error(`未知销售页面配置：${key}`);
  return c;
}
