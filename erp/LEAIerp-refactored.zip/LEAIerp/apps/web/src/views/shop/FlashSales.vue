<template><RecordPage :config="page" /></template>

<script setup lang="ts">
import RecordPage from '../records/RecordPage.vue';
import type { RecordPageConfig } from '../records/records';

const page: RecordPageConfig = {
  title: '秒杀活动',
  resource: 'shop/flash-sales',
  schema: 'shopFlashSales',
  filters: ['productName', 'startTime', 'status'],
  required: ['name', 'productName', 'flashPrice', 'limitQty', 'startTime'],
};
</script>
