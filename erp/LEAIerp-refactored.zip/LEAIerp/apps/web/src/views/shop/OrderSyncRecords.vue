<template><RecordPage :config="page" /></template>

<script setup lang="ts">
import RecordPage from '../records/RecordPage.vue';
import type { RecordPageConfig } from '../records/records';

const page: RecordPageConfig = {
  title: '订单同步',
  resource: 'shop/order-syncs',
  schema: 'shopOrderSyncs',
  filters: ['platform', 'platformOrderNo', 'status'],
  reportSource: '订单同步记录',
  metrics: ['amount'],
  link: { to: '/shop/orders', label: '查看平台订单' },
};
</script>
