<template><RecordPage :config="page" /></template>

<script setup lang="ts">
import RecordPage from '../records/RecordPage.vue';
import type { RecordPageConfig } from '../records/records';

const page: RecordPageConfig = {
  title: '商品发布',
  resource: 'shop/goods-publications',
  schema: 'shopGoodsPublications',
  filters: ['platform', 'productName', 'status'],
  reportSource: '平台商品发布记录',
  link: { to: '/shop/goods-maps', label: '商品映射' },
};
</script>
