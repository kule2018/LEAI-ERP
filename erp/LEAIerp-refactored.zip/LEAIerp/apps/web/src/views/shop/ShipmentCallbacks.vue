<template><RecordPage :config="page" /></template>

<script setup lang="ts">
import RecordPage from '../records/RecordPage.vue';
import type { RecordPageConfig } from '../records/records';

const page: RecordPageConfig = {
  title: '发货回传',
  resource: 'shop/ship-callbacks',
  schema: 'shopShipCallbacks',
  filters: ['platform', 'platformOrderNo', 'status'],
  reportSource: '平台发货回传记录',
};
</script>
