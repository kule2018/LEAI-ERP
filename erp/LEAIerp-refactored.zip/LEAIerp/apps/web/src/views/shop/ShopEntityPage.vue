<template><SalesEntityPage :key="key" :config="config" /></template>
<script setup lang="ts">
import { computed } from 'vue';
import { useRoute } from 'vue-router';
import SalesEntityPage from '../sales/SalesEntityPage.vue';
import { moduleConfigFor } from '../generic/moduleConfigs';

const route = useRoute();
const key = computed(() => route.path.split('/').filter(Boolean)[1] || 'center');
const config = computed(() => moduleConfigFor('shop', key.value));
</script>
