<template><RecordPage :config="page" /></template>

<script setup lang="ts">
import RecordPage from '../records/RecordPage.vue';
import type { RecordPageConfig } from '../records/records';

const page: RecordPageConfig = {
  title: '满减活动',
  resource: 'shop/full-reductions',
  schema: 'shopFullReductions',
  filters: ['startDate', 'endDate', 'status'],
  required: ['name', 'threshold', 'discount', 'startDate', 'endDate'],
};
</script>
