<template><RecordPage :config="page" /></template>

<script setup lang="ts">
import RecordPage from '../records/RecordPage.vue';
import type { RecordPageConfig } from '../records/records';

const page: RecordPageConfig = {
  title: '价格库存同步',
  resource: 'shop/stock-syncs',
  schema: 'shopStockSyncs',
  filters: ['platform', 'syncType', 'result'],
  reportSource: '价格和库存同步记录',
};
</script>
