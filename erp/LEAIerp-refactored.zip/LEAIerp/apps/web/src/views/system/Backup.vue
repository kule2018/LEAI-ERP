<!--
 * 数据备份与恢复（文档第 32 章：定时全量 + 增量、恢复演练记录）。
 * ---------------------------------------------------------------------------
 * 演示模式备份 localStorage 中的业务数据为 JSON 文件，可下载留存；
 * 恢复时上传备份文件并二次确认，避免误操作覆盖现有数据。
 -->
<template>
  <div class="erp-page">
    <div class="bk-head"><div><h2>数据备份</h2><p>定期备份关键业务数据，支持下载与恢复演练</p></div><DsButton variant="primary" @click="create">立即备份</DsButton></div>
    <DsCard :pad="false">
      <table class="bk-table">
        <thead><tr><th>ID</th><th>备份名称</th><th>类型</th><th>数据量</th><th>创建时间</th><th>操作</th></tr></thead>
        <tbody>
          <tr v-for="b in rows" :key="b.id"><td>{{ b.id }}</td><td>{{ b.name }}</td><td>{{ b.type }}</td><td>{{ b.size }}</td><td>{{ b.createdAt }}</td>
            <td><DsButton variant="text" size="sm" @click="download(b)">下载</DsButton><DsButton variant="text" size="sm" @click="restore(b)">恢复</DsButton></td>
          </tr>
          <tr v-if="!rows.length"><td colspan="6" class="bk-empty">暂无备份，点击「立即备份」创建第一个</td></tr>
        </tbody>
      </table>
    </DsCard>
    <div class="bk-tip"><b>提示：</b>真实生产环境请使用 mysqldump 定时全量备份 + binlog 增量备份，并定期做恢复演练；本地演示备份只覆盖浏览器数据。</div>
    <input ref="fileRef" type="file" accept="application/json" style="display:none" @change="onFile" />
    <DsToast />
  </div>
</template>

<script setup lang="ts">
/** 备份管理：创建、下载、恢复本地演示数据 */
import { onMounted, ref } from 'vue';
import { mockGet, mockPost } from '../../api/mockAdapter';
import { useToast } from '../../components/ds/toast';
import { confirm as uiConfirm } from '../../components/ds/useConfirm';

const toast = useToast();
const rows = ref<any[]>([]);
const fileRef = ref<HTMLInputElement | null>(null);

async function load(): Promise<void> {
  const list: any = await mockGet('/api/v1/ux/backups', { pageSize: 100 });
  rows.value = Array.isArray(list) ? list : list?.list || [];
}
/** 创建备份快照 */
async function create(): Promise<void> {
  const raw = localStorage.getItem('erp_mock_db_v3') || '{}';
  const name = `本地演示数据_${new Date().toLocaleString('zh-CN').replace(/[/: ]/g, '-')}`;
  await mockPost('/api/v1/ux/backups', { name, type: '全量', size: `${(raw.length / 1024).toFixed(1)} KB`, createdAt: new Date().toLocaleString('zh-CN'), content: raw });
  toast.success('备份已创建'); load();
}
function download(row: any): void {
  const blob = new Blob([row.content || '{}'], { type: 'application/json' });
  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob); link.download = `${row.name}.json`; link.click(); URL.revokeObjectURL(link.href);
}
async function restore(row: any): Promise<void> {
  if (!await uiConfirm(`确定恢复备份「${row.name}」？当前本地数据将被覆盖。`, '恢复确认')) return;
  try { localStorage.setItem('erp_mock_db_v3', row.content || '{}'); toast.success('恢复完成，请刷新页面'); }
  catch { toast.error('恢复失败：备份内容无效'); }
}
function onFile(event: Event): void {
  const file = (event.target as HTMLInputElement).files?.[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = async () => {
    if (!await uiConfirm('确定用该文件恢复本地数据？', '导入确认')) return;
    try { JSON.parse(String(reader.result)); localStorage.setItem('erp_mock_db_v3', String(reader.result)); toast.success('导入成功，请刷新页面'); }
    catch { toast.error('文件格式不正确'); }
  };
  reader.readAsText(file);
}
onMounted(load);
</script>

<style scoped>
.bk-head { display: flex; justify-content: space-between; align-items: center; margin-bottom: 14px; }
.bk-head h2 { font-size: 18px; margin: 0 0 4px; }
.bk-head p { margin: 0; font-size: 12px; color: var(--ds-text-3); }
.bk-table { width: 100%; border-collapse: collapse; font-size: 13px; }
.bk-table th, .bk-table td { padding: 9px 12px; border-bottom: 1px solid var(--ds-divider); text-align: left; }
.bk-table th { background: var(--ds-bg-soft); color: var(--ds-text-3); }
.bk-empty { text-align: center; color: var(--ds-text-3); padding: 24px; }
.bk-tip { margin-top: 14px; font-size: 12px; color: var(--ds-text-3); line-height: 1.7; }
</style>
