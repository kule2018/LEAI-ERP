<!-- 版本更新日志：发布说明内置，用户可见「本次更新了什么」 -->
<template>
  <div class="erp-page">
    <div class="log-head">
      <div><h2>版本更新日志</h2><p>当前版本 v{{ current.version }} · {{ current.date }} · {{ current.title }}</p></div>
      <DsButton size="sm" @click="markRead">标记已读</DsButton>
    </div>
    <DsCard v-for="release in releases" :key="release.version" :title="'v' + release.version + ' · ' + release.title" class="log-gap">
      <template #extra><span class="log-date">{{ release.date }}</span></template>
      <div class="log-cols">
        <div><h4>新特性</h4><ul><li v-for="(item, i) in release.features" :key="i">{{ item }}</li></ul></div>
        <div><h4>优化与修复</h4><ul><li v-for="(item, i) in release.fixes" :key="i">{{ item }}</li></ul></div>
      </div>
      <p class="log-note">{{ release.note }}</p>
    </DsCard>
  </div>
</template>

<script setup lang="ts">
/** 版本日志：展示内置发布说明，支持标记已读（新特性弹窗的判定依据） */
import { computed, onMounted, ref } from 'vue';
import { DsButton, DsCard } from '../../components';
import { mockGet, mockPost } from '../../api/mockAdapter';
import { useToast } from '../../components/ds/toast';

const toast = useToast();
const releases = ref<any[]>([]);
const current = computed(() => releases.value[0] || { version: '1.0.0', date: '-', title: '初始版本' });

/** 加载发布记录，失败时使用内置数据 */
async function load(): Promise<void> {
  try {
    const data: any = await mockGet('/api/v1/ux/changelogs', { pageSize: 20 });
    releases.value = Array.isArray(data) ? data : data?.list || [];
  } catch { releases.value = []; }
  if (!releases.value.length) {
    releases.value = [
      { version: '3.2.0', date: '2026-11-17', title: '全业务闭环 + AI 增强', features: ['销售/采购/库存/财务全链路状态机', '打印中心模板设计器与批量打印', 'AI 助理 13 项能力与规则兜底'], fixes: ['修复单据状态跨级跳转', '优化列表万行渲染性能'], note: '本次更新覆盖文档第 11~35 章全部功能。' },
      { version: '3.1.0', date: '2026-10-20', title: 'UniApp 移动端', features: ['11 个移动页面与扫码开单', 'PDA 拣货与离线队列'], fixes: ['优化扫码连续录入'], note: '移动端支持 H5 / 微信小程序 / App。' },
    ];
  }
}
/** 标记已读：下次不再弹出新特性提示 */
async function markRead(): Promise<void> {
  await mockPost('/api/v1/ux/changelogs/read', { version: current.value.version });
  localStorage.setItem('erp_changelog_seen', current.value.version);
  toast.success('已标记为已读');
}
onMounted(load);
</script>

<style scoped>
.log-head { display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px; }
.log-head h2 { margin: 0 0 4px; font-size: 18px; }
.log-head p { margin: 0; color: var(--ds-text-3); font-size: 13px; }
.log-gap { margin-bottom: 12px; }
.log-date { color: var(--ds-text-3); font-size: 12px; }
.log-cols { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; font-size: 13px; }
.log-cols h4 { margin: 0 0 8px; font-size: 13px; color: var(--ds-brand); }
.log-cols ul { margin: 0; padding-left: 18px; line-height: 1.9; }
.log-note { margin: 12px 0 0; color: var(--ds-text-3); font-size: 12px; }
</style>
