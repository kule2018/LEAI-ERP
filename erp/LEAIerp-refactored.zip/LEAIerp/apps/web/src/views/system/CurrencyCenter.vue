<!-- 多语言多币种中心：语言包维护、币种与汇率管理、一键换算校验 -->
<template>
  <div class="erp-page">
    <div class="cur-tabs">
      <DsButton v-for="tab in tabs" :key="tab.key" :variant="active === tab.key ? 'primary' : 'default'" size="sm" @click="active = tab.key">{{ tab.label }}</DsButton>
    </div>

    <!-- 语言包 -->
    <DsCard v-if="active === 'lang'" title="语言包" :pad="false">
      <template #extra>
        <select v-model="locale" class="ds-select" @change="setLocale(locale)"><option value="zh-CN">简体中文</option><option value="en-US">English</option><option value="ja-JP">日本語</option></select>
      </template>
      <table class="cur-table">
        <thead><tr><th>文案 key</th><th>{{ locale === 'zh-CN' ? '简体中文' : locale === 'en-US' ? 'English' : '日本語' }}</th></tr></thead>
        <tbody>
          <tr v-for="row in languageRows" :key="row.key">
            <td>{{ row.key }}</td>
            <td><input v-model="row.text" class="ds-input" @change="saveLanguage(row)" /></td>
          </tr>
        </tbody>
      </table>
      <p class="cur-hint">修改后立即生效，缺失的文案自动回退中文。当前界面语言：{{ locale }}</p>
    </DsCard>

    <!-- 币种与汇率 -->
    <DsCard v-if="active === 'currency'" title="币种与汇率" :pad="false">
      <template #extra><DsButton variant="primary" size="sm" @click="addCurrency">新增币种</DsButton></template>
      <table class="cur-table">
        <thead><tr><th>币种</th><th>名称</th><th>符号</th><th>对 CNY 汇率</th><th>操作</th></tr></thead>
        <tbody>
          <tr v-for="row in currencyRows" :key="row.id">
            <td><input v-model="row.code" class="ds-input cur-cell" /></td>
            <td><input v-model="row.name" class="ds-input cur-cell" /></td>
            <td><input v-model="row.symbol" class="ds-input cur-cell" /></td>
            <td><input v-model.number="row.rate" class="ds-input cur-cell" type="number" /></td>
            <td><DsButton size="sm" @click="saveCurrency(row)">保存</DsButton></td>
          </tr>
        </tbody>
      </table>
    </DsCard>

    <!-- 换算校验 -->
    <DsCard v-if="active === 'calc'" title="汇率换算校验" :pad="false">
      <div class="cur-calc">
        <input v-model.number="calc.amount" class="ds-input" type="number" placeholder="金额" />
        <select v-model="calc.code" class="ds-select"><option v-for="c in currencyRows" :key="c.code" :value="c.code">{{ c.code }}</option></select>
        <span>=</span>
        <b>{{ toCny(calc.amount, calc.code).toFixed(2) }} CNY</b>
        <small>汇率 {{ rateOf(calc.code) }} · 1 原币 = {{ rateOf(calc.code) }} 人民币</small>
      </div>
      <p class="cur-hint">换算结果用于销售/采购单据的本币金额汇总；异常汇率可在 AI 助手中让 Copilot 解释。</p>
    </DsCard>
  </div>
</template>

<script setup lang="ts">
/** 多语言多币种中心：维护语言包、币种汇率并提供换算校验 */
import { onMounted, reactive, ref } from 'vue';
import { DsButton, DsCard } from '../../components';
import { useToast } from '../../components/ds/toast';
import { mockGet, mockPost } from '../../api/mockAdapter';
import { setLocale, loadLanguagePacks } from '../../i18n';
import { currencies, rateOf, toCny } from '../../utils/currency';

const toast = useToast();
const tabs = [{ key: 'lang', label: '语言包' }, { key: 'currency', label: '币种与汇率' }, { key: 'calc', label: '换算校验' }];
const active = ref('lang');
const locale = ref<'zh-CN' | 'en-US' | 'ja-JP'>('zh-CN');
const languageRows = ref<any[]>([]);
const currencyRows = ref<any[]>([]);
const calc = reactive<any>({ amount: 100, code: 'USD' });

/** 加载语言包、币种与汇率数据 */
async function load(): Promise<void> {
  const [packs, list]: any[] = await Promise.all([
    mockGet('/api/v1/system/language-packs', { pageSize: 200 }),
    mockGet('/api/v1/system/currencies', { pageSize: 200 }),
  ]);
  languageRows.value = Array.isArray(packs) ? packs : packs?.list || [];
  currencyRows.value = (Array.isArray(list) ? list : list?.list || []).length ? (Array.isArray(list) ? list : list.list) : currencies();
  loadLanguagePacks(languageRows.value.filter((r) => r.locale === locale.value));
}
/** 保存单条语言包 */
async function saveLanguage(row: any): Promise<void> {
  await mockPost('/api/v1/system/language-packs', { ...row, locale: locale.value });
  localStorage.setItem('erp_language_packs', JSON.stringify(languageRows.value));
  loadLanguagePacks(languageRows.value.filter((r) => r.locale === locale.value));
  toast.success('语言包已更新');
}
/** 新增币种 */
function addCurrency(): void { currencyRows.value.push({ id: Date.now(), code: '', name: '', symbol: '', rate: 1 }); }
/** 保存币种/汇率 */
async function saveCurrency(row: any): Promise<void> {
  if (!row.code) { toast.warning('请填写币种代码'); return; }
  await mockPost('/api/v1/system/currencies', row);
  await mockPost('/api/v1/system/exchange-rates', { code: row.code, rate: row.rate });
  toast.success('已保存');
}
onMounted(load);
</script>

<style scoped>
.cur-tabs { display: flex; gap: 8px; margin-bottom: 12px; }
.cur-table { width: 100%; border-collapse: collapse; font-size: 13px; }
.cur-table th, .cur-table td { padding: 9px 12px; border-bottom: 1px solid var(--ds-divider); text-align: left; }
.cur-table th { background: var(--ds-bg-soft); color: var(--ds-text-3); font-weight: 500; }
.cur-cell { width: 120px; }
.cur-hint { padding: 12px; color: var(--ds-text-3); font-size: 12px; }
.cur-calc { display: flex; align-items: center; gap: 12px; padding: 24px; font-size: 14px; }
.cur-calc b { font-size: 20px; color: var(--ds-brand); }
.cur-calc small { color: var(--ds-text-3); }
</style>
