<!--
 * 自定义字段（文档第 33 章：无需改代码给任意实体加字段）。
 * ---------------------------------------------------------------------------
 * 配置后写入 custom_field / custom_form 表（mock 同步），
 * 通用列表 EntityPage 会自动读取并追加这些列与表单项。
 -->
<template>
  <div class="erp-page">
    <div class="cf-head">
      <div><h2>自定义字段</h2><p>给实体加字段后，列表、表单、导入导出与打印模板自动生效</p></div>
      <DsButton variant="primary" @click="open()">新增字段</DsButton>
    </div>

    <DsCard :pad="false">
      <div class="cf-toolbar">
        <select v-model="entity" class="ds-select" @change="load"><option v-for="e in entities" :key="e" :value="e">{{ e }}</option></select>
        <span class="cf-count">共 {{ rows.length }} 个字段，启用 {{ rows.filter(r => r.isActive !== 0 && r.enabled !== false).length }} 个</span>
      </div>
      <table class="cf-table">
        <thead><tr><th>字段名称</th><th>编码</th><th>类型</th><th>必填</th><th>默认值</th><th>状态</th><th>操作</th></tr></thead>
        <tbody>
          <tr v-for="row in rows" :key="row.id">
            <td>{{ row.name || row.label }}</td><td>{{ row.code || row.field }}</td><td>{{ typeText(row.type) }}</td>
            <td>{{ row.required ? '是' : '否' }}</td><td>{{ row.defaultValue || '-' }}</td>
            <td><DsTag :color="row.isActive !== 0 && row.enabled !== false ? 'success' : 'neutral'" size="sm">{{ row.isActive !== 0 && row.enabled !== false ? '启用' : '停用' }}</DsTag></td>
            <td><DsButton variant="text" size="sm" @click="open(row)">编辑</DsButton><DsButton variant="text" size="sm" @click="remove(row)">删除</DsButton></td>
          </tr>
          <tr v-if="!rows.length"><td colspan="7" class="cf-empty">该实体还没有自定义字段</td></tr>
        </tbody>
      </table>
    </DsCard>

    <DsCard title="表单预览" class="cf-preview">
      <div class="cf-form">
        <label v-for="row in rows" :key="row.id"><span>{{ row.name || row.label }}{{ row.required ? ' *' : '' }}</span>
          <input v-if="['text', 'number', 'date'].includes(row.type)" class="ds-input" :type="row.type === 'number' ? 'number' : row.type === 'date' ? 'date' : 'text'" :placeholder="row.defaultValue || ''" />
          <select v-else class="ds-select"><option v-for="opt in (row.options || '').split(',')" :key="opt">{{ opt }}</option></select>
        </label>
        <div v-if="!rows.length" class="cf-empty">新增字段后这里会实时预览表单效果</div>
      </div>
    </DsCard>

    <DsModal v-model="formVisible" :title="editing ? '编辑字段' : '新增自定义字段'" :width="520">
      <div class="cf-form">
        <label><span>字段名称</span><input v-model="form.name" class="ds-input" /></label>
        <label><span>字段编码</span><input v-model="form.code" class="ds-input" /></label>
        <label><span>类型</span><select v-model="form.type" class="ds-select"><option value="text">文本</option><option value="number">数字</option><option value="date">日期</option><option value="select">下拉</option></select></label>
        <label><span>默认值</span><input v-model="form.defaultValue" class="ds-input" /></label>
        <label class="full"><span>下拉选项（逗号分隔，仅下拉类型需要）</span><input v-model="form.options" class="ds-input" /></label>
        <label class="checks"><input v-model="form.required" type="checkbox" /> 必填</label>
        <label class="checks"><input v-model="form.isActive" type="checkbox" /> 启用</label>
      </div>
      <template #footer><div class="cf-foot"><DsButton @click="formVisible = false">取消</DsButton><DsButton variant="primary" @click="save">保存</DsButton></div></template>
    </DsModal>
  </div>
</template>

<script setup lang="ts">
/** 自定义字段配置：按实体维护字段元数据，列表/表单自动读取 */
import { onMounted, reactive, ref } from 'vue';
import { mockGet, mockPost } from '../../api/mockAdapter';
import { useToast } from '../../components/ds/toast';
import { confirm as uiConfirm } from '../../components/ds/useConfirm';

const toast = useToast();
const entities = ['产品', '客户', '供应商', '销售单', '采购单', '雇员', '会计科目'];
const entity = ref(entities[0]);
const rows = ref<any[]>([]);
const formVisible = ref(false);
const editing = ref<any>(null);
const form = reactive<any>({});

function typeText(type: string): string {
  return { text: '文本', number: '数字', date: '日期', select: '下拉' }[type] || type;
}
/** 加载当前实体的字段 */
async function load(): Promise<void> {
  const list: any = await mockGet('/api/v1/ux/custom-fields', { entity: entity.value, pageSize: 100 });
  rows.value = Array.isArray(list) ? list : list?.list || [];
}
/** 打开表单 */
function open(row?: any): void {
  editing.value = row || null;
  Object.assign(form, row ? { ...row } : { name: '', code: '', type: 'text', defaultValue: '', options: '', required: false, isActive: 1 });
  formVisible.value = true;
}
/** 保存字段 */
async function save(): Promise<void> {
  if (!form.name || !form.code) { toast.warning('请填写字段名称与编码'); return; }
  await mockPost('/api/v1/ux/custom-fields', { ...form, entity: entity.value, id: form.id || undefined });
  formVisible.value = false; toast.success('字段已保存'); load();
}
/** 删除字段（软删除语义，mock 中直接移除） */
async function remove(row: any): Promise<void> {
  if (!await uiConfirm(`确定删除字段「${row.name}」？`, '删除确认')) return;
  await mockPost('/api/v1/ux/custom-fields/delete', { id: row.id });
  rows.value = rows.value.filter((r) => r.id !== row.id);
  toast.success('已删除');
}
onMounted(load);
</script>

<style scoped>
.cf-head { display: flex; justify-content: space-between; align-items: center; margin-bottom: 14px; }
.cf-head h2 { font-size: 18px; margin: 0 0 4px; }
.cf-head p { margin: 0; font-size: 12px; color: var(--ds-text-3); }
.cf-toolbar { display: flex; gap: 12px; align-items: center; padding: 12px; }
.cf-toolbar .ds-select { width: 180px; }
.cf-count { color: var(--ds-text-3); font-size: 12px; }
.cf-table { width: 100%; border-collapse: collapse; font-size: 13px; }
.cf-table th, .cf-table td { padding: 9px 12px; border-bottom: 1px solid var(--ds-divider); text-align: left; }
.cf-table th { background: var(--ds-bg-soft); color: var(--ds-text-3); }
.cf-empty { text-align: center; color: var(--ds-text-3); padding: 24px; }
.cf-preview { margin-top: 12px; }
.cf-form { display: grid; grid-template-columns: repeat(2, 1fr); gap: 12px; padding: 12px; }
.cf-form label { display: flex; flex-direction: column; gap: 4px; font-size: 13px; }
.cf-form .full { grid-column: 1 / -1; }
.cf-form .checks { flex-direction: row; align-items: center; gap: 6px; }
.cf-foot { display: flex; justify-content: flex-end; gap: 8px; }
</style>
