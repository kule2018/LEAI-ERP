<!--
 * 流程可视化设计器（文档 BPM 章节：拖拽节点编排审批流）。
 * ---------------------------------------------------------------------------
 * 不引入 @vue-flow/core 等新依赖：节点用绝对定位 div，连线用原生 SVG 贝塞尔曲线。
 * 节点类型：开始 / 审批 / 会签 / 或签 / 条件分支 / 抄送 / 结束；
 * 点击节点可编辑名称、审批人、条件表达式；支持保存 JSON、加载定义、模拟运行路径高亮。
-->
<template>
  <div class="erp-page fd-page">
    <div class="fd-head">
      <div>
        <h2>流程可视化设计器</h2>
        <p>拖拽节点编排审批流，原生 SVG 连线，无需额外依赖</p>
      </div>
      <div class="fd-head-ops">
        <select v-model="selectedDefId" class="ds-select fd-def-select" @change="loadDefinition">
          <option value="">选择已有流程定义…</option>
          <option v-for="d in definitions" :key="d.id" :value="d.id">{{ d.name }}</option>
        </select>
        <input v-model="def.name" class="ds-input fd-name" placeholder="流程名称" />
        <DsButton size="sm" @click="loadList">刷新列表</DsButton>
        <DsButton size="sm" @click="simulate">模拟运行</DsButton>
        <DsButton variant="primary" size="sm" :loading="saving" @click="save">保存定义</DsButton>
      </div>
    </div>

    <div class="fd-layout">
      <!-- 节点面板：点击或拖拽加入画布 -->
      <DsCard title="节点类型" :pad="false" class="fd-left">
        <div v-for="p in palette" :key="p.type" class="fd-palette" draggable="true"
             @dragstart="onPaletteDrag($event, p.type)" @click="addNode(p.type)">
          <span class="fd-dot" :class="'t-' + p.type" />{{ p.label }}
        </div>
        <div class="fd-hint fd-hint-pad">点击或拖拽到画布添加节点</div>
        <div class="fd-code">
          <b>流程编码</b>
          <input v-model="def.code" class="ds-input" placeholder="如 SALE_ORDER" />
          <b>备注</b>
          <input v-model="def.remark" class="ds-input" placeholder="流程说明" />
        </div>
      </DsCard>

      <!-- 画布：div 节点 + SVG 连线 -->
      <DsCard title="流程画布" :pad="false" class="fd-center">
        <div ref="canvasRef" class="fd-canvas" @dragover.prevent @drop="onCanvasDrop" @click.self="selectedNodeId = ''">
          <svg class="fd-lines">
            <defs>
              <marker id="fd-arrow" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse">
                <path d="M 0 0 L 10 5 L 0 10 z" fill="#94a3b8" />
              </marker>
              <marker id="fd-arrow-on" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse">
                <path d="M 0 0 L 10 5 L 0 10 z" fill="#2563eb" />
              </marker>
            </defs>
            <g v-for="e in edges" :key="e.key">
              <path :d="e.d" class="fd-path" :class="{ on: activeEdges.includes(e.key) }"
                    :marker-end="activeEdges.includes(e.key) ? 'url(#fd-arrow-on)' : 'url(#fd-arrow)'" />
              <text v-if="e.label" :x="e.lx" :y="e.ly" class="fd-edge-label">{{ e.label }}</text>
            </g>
          </svg>

          <div v-for="n in nodes" :key="n.id" class="fd-node" :class="['t-' + n.type, {
                on: activeNodes.includes(n.id), selected: selectedNodeId === n.id }]"
               :style="{ left: n.x + 'px', top: n.y + 'px' }"
               @mousedown="startDrag($event, n)" @click.stop="selectedNodeId = n.id">
            <b>{{ n.name }}</b>
            <small v-if="n.approver">审批人：{{ n.approver }}</small>
            <small v-else-if="n.condition">{{ n.condition }}</small>
            <small v-else class="fd-node-sub">{{ typeLabel(n.type) }}</small>
          </div>

          <div v-if="!nodes.length" class="fd-canvas-empty">从左侧拖入「开始」节点开始设计</div>
        </div>
        <div class="fd-canvas-bar">
          <span>节点 {{ nodes.length }} 个 / 连线 {{ edges.length }} 条</span>
          <span class="fd-gap" />
          <DsButton size="sm" @click="autoLayout">自动排列</DsButton>
          <DsButton size="sm" @click="clearAll">清空画布</DsButton>
        </div>
      </DsCard>

      <!-- 属性面板 + 模拟运行日志 -->
      <DsCard title="节点属性" :pad="false" class="fd-right">
        <div v-if="currentNode" class="fd-prop">
          <label><span>节点类型</span><input class="ds-input" :value="typeLabel(currentNode.type)" disabled /></label>
          <label><span>节点名称</span><input v-model="currentNode.name" class="ds-input" /></label>
          <label v-if="hasApprover(currentNode.type)">
            <span>审批人</span><input v-model="currentNode.approver" class="ds-input" placeholder="如：销售总监 / 角色:财务" />
          </label>
          <label v-if="currentNode.type === 'condition'">
            <span>条件表达式</span><input v-model="currentNode.condition" class="ds-input" placeholder="如：amount > 10000" />
          </label>
          <label>
            <span>下一节点</span>
            <select v-model="currentNode.next" class="ds-select">
              <option value="">无</option>
              <option v-for="n in otherNodes" :key="n.id" :value="n.id">{{ n.name }}</option>
            </select>
          </label>

          <div v-if="currentNode.type === 'condition'" class="fd-branches">
            <b>条件分支（命中第一条即走该分支，否则走「下一节点」）</b>
            <div v-for="(b, i) in currentNode.branches" :key="i" class="fd-branch">
              <input v-model="b.label" class="ds-input" placeholder="分支名" />
              <input v-model="b.condition" class="ds-input" placeholder="条件，如 amount > 10000" />
              <select v-model="b.to" class="ds-select">
                <option value="">目标节点</option>
                <option v-for="n in otherNodes" :key="n.id" :value="n.id">{{ n.name }}</option>
              </select>
              <DsButton variant="text" size="sm" @click="currentNode.branches.splice(i, 1)">删除</DsButton>
            </div>
            <DsButton size="sm" @click="addBranch">+ 添加分支</DsButton>
          </div>

          <DsButton variant="danger" size="sm" @click="removeNode">删除节点</DsButton>
        </div>
        <div v-else class="fd-empty">点击画布中的节点编辑属性</div>

        <div class="fd-runlog">
          <b>模拟运行日志</b>
          <div v-for="(l, i) in runLog" :key="i" class="fd-log" :class="{ bad: !l.ok }">{{ l.text }}</div>
          <div v-if="!runLog.length" class="fd-hint">点击顶部「模拟运行」查看路径高亮</div>
        </div>
      </DsCard>
    </div>
    <DsToast />
  </div>
</template>

<script setup lang="ts">
/** 流程设计器：节点拖拽、SVG 连线、属性编辑、JSON 保存/加载与模拟运行 */
import { computed, reactive, ref, onMounted } from 'vue'
import { mockGet, mockPost } from '../../api/mockAdapter'
import { useToast } from '../../components/ds/toast'

type NodeType = 'start' | 'approval' | 'countersign' | 'orsign' | 'condition' | 'cc' | 'end'
interface Branch { label: string; condition: string; to: string }
interface FlowNode {
  id: string; type: NodeType; name: string; approver: string; condition: string
  x: number; y: number; next: string; branches: Branch[]
}

const NODE_W = 168
const NODE_H = 68
const toast = useToast()

const palette: Array<{ type: NodeType; label: string }> = [
  { type: 'start', label: '开始' }, { type: 'approval', label: '审批' },
  { type: 'countersign', label: '会签' }, { type: 'orsign', label: '或签' },
  { type: 'condition', label: '条件分支' }, { type: 'cc', label: '抄送' }, { type: 'end', label: '结束' },
]
const TYPE_LABEL: Record<NodeType, string> = {
  start: '开始', approval: '审批', countersign: '会签', orsign: '或签', condition: '条件分支', cc: '抄送', end: '结束',
}
const typeLabel = (t: NodeType) => TYPE_LABEL[t] || t
const hasApprover = (t: NodeType) => ['approval', 'countersign', 'orsign', 'cc'].includes(t)

const nodes = ref<FlowNode[]>([])
const def = reactive<any>({ name: '新流程', code: '', remark: '' })
const definitions = ref<any[]>([])
const selectedDefId = ref<string | number>('')
const selectedNodeId = ref('')
const saving = ref(false)
const canvasRef = ref<HTMLElement | null>(null)

const currentNode = computed(() => nodes.value.find((n) => n.id === selectedNodeId.value) || null)
const otherNodes = computed(() => nodes.value.filter((n) => n.id !== selectedNodeId.value))

/** 由节点的 next / branches 派生连线；折线用三次贝塞尔平滑 */
const edges = computed(() => {
  const list: Array<{ key: string; d: string; lx: number; ly: number; label: string; from: string; to: string }> = []
  const byId = new Map(nodes.value.map((n) => [n.id, n]))
  const make = (a: FlowNode, b: FlowNode, label: string) => {
    const x1 = a.x + NODE_W, y1 = a.y + NODE_H / 2
    const x2 = b.x, y2 = b.y + NODE_H / 2
    const mx = (x1 + x2) / 2
    return { key: `${a.id}->${b.id}-${label}`, d: `M ${x1} ${y1} C ${mx} ${y1}, ${mx} ${y2}, ${x2} ${y2}`, lx: mx, ly: (y1 + y2) / 2 - 4, label, from: a.id, to: b.id }
  }
  for (const n of nodes.value) {
    if (n.type === 'condition') {
      for (const b of n.branches || []) {
        const target = b.to ? byId.get(b.to) : undefined
        if (target) list.push(make(n, target, b.label || b.condition || '分支'))
      }
      const fallback = n.next ? byId.get(n.next) : undefined
      if (fallback) list.push(make(n, fallback, '否则'))
    } else if (n.next) {
      const target = byId.get(n.next)
      if (target) list.push(make(n, target, ''))
    }
  }
  return list
})

/* ---------------- 节点增删改与拖拽 ---------------- */
let seq = 0
function makeNode(type: NodeType, x: number, y: number): FlowNode {
  return { id: 'n_' + Date.now().toString(36) + '_' + (seq++), type, name: TYPE_LABEL[type], approver: '', condition: '', x, y, next: '', branches: [] }
}
function addNode(type: NodeType): void {
  const i = nodes.value.length
  nodes.value.push(makeNode(type, 60 + (i % 5) * 200, 50 + Math.floor(i / 5) * 120))
}
function onPaletteDrag(e: DragEvent, type: NodeType): void { e.dataTransfer?.setData('text/flow-node', type) }
function onCanvasDrop(e: DragEvent): void {
  const type = e.dataTransfer?.getData('text/flow-node') as NodeType
  if (!type || !TYPE_LABEL[type] || !canvasRef.value) return
  const rect = canvasRef.value.getBoundingClientRect()
  nodes.value.push(makeNode(type, Math.max(0, e.clientX - rect.left - NODE_W / 2), Math.max(0, e.clientY - rect.top - NODE_H / 2)))
}
function startDrag(e: MouseEvent, n: FlowNode): void {
  if ((e.target as HTMLElement).tagName === 'INPUT') return
  selectedNodeId.value = n.id
  const canvas = canvasRef.value
  if (!canvas) return
  const rect = canvas.getBoundingClientRect()
  const sx = e.clientX, sy = e.clientY, ox = n.x, oy = n.y
  const move = (ev: MouseEvent) => {
    n.x = Math.max(0, Math.min(rect.width - NODE_W, ox + ev.clientX - sx))
    n.y = Math.max(0, Math.min(rect.height - NODE_H, oy + ev.clientY - sy))
  }
  const up = () => { document.removeEventListener('mousemove', move); document.removeEventListener('mouseup', up) }
  document.addEventListener('mousemove', move)
  document.addEventListener('mouseup', up)
}
function addBranch(): void {
  if (!currentNode.value) return
  currentNode.value.branches.push({ label: `分支 ${currentNode.value.branches.length + 1}`, condition: '', to: '' })
}
function removeNode(): void {
  const id = selectedNodeId.value
  if (!id) return
  nodes.value = nodes.value.filter((n) => n.id !== id)
  // 清理其他节点对本节点的引用
  for (const n of nodes.value) {
    if (n.next === id) n.next = ''
    n.branches = (n.branches || []).filter((b) => b.to !== id)
  }
  selectedNodeId.value = ''
  resetRun()
}
function clearAll(): void { nodes.value = []; selectedNodeId.value = ''; resetRun() }
/** 从开始节点 BFS 自动排列，避免手动摆放凌乱 */
function autoLayout(): void {
  const start = nodes.value.find((n) => n.type === 'start') || nodes.value[0]
  const ordered: FlowNode[] = []
  const seen = new Set<string>()
  const queue: FlowNode[] = start ? [start] : [...nodes.value]
  while (queue.length) {
    const n = queue.shift()!
    if (seen.has(n.id)) continue
    seen.add(n.id); ordered.push(n)
    const ids = [...(n.branches || []).map((b) => b.to), n.next].filter(Boolean)
    for (const id of ids) { const t = nodes.value.find((x) => x.id === id); if (t && !seen.has(t.id)) queue.push(t) }
  }
  for (const n of nodes.value) if (!seen.has(n.id)) ordered.push(n)
  ordered.forEach((n, i) => { n.x = 60 + (i % 5) * 200; n.y = 50 + Math.floor(i / 5) * 120 })
}

/* ---------------- 保存 / 加载 ---------------- */
async function loadList(): Promise<void> {
  const list: any = await mockGet('/api/v1/bpm/definitions')
  definitions.value = Array.isArray(list) ? list : list?.list || []
}
/** 兼容旧定义：无 nodes 字段时按业务编码生成一套可运行的示例流程 */
function demoNodes(code: string): FlowNode[] {
  const s = makeNode('start', 60, 160); s.name = '开始'
  const a = makeNode('approval', 280, 160); a.name = '主管审批'; a.approver = '销售主管'
  const c = makeNode('condition', 500, 160); c.name = '金额判断'; c.condition = 'amount > 10000'
  c.branches = [{ label: '大额', condition: 'amount > 10000', to: '' }]
  const cc = makeNode('cc', 720, 60); cc.name = '抄送财务'; cc.approver = '财务部'
  const e = makeNode('end', 940, 160); e.name = '结束'
  s.next = a.id; a.next = c.id; c.branches[0].to = cc.id; c.next = e.id; cc.next = e.id
  if (code === 'LEAVE') { a.name = '人事审批'; a.approver = '人事专员' }
  return [s, a, c, cc, e]
}
function normalize(n: any): FlowNode {
  return {
    id: String(n.id || 'n_' + Math.random().toString(36).slice(2, 8)),
    type: (TYPE_LABEL[n.type as NodeType] ? n.type : 'approval') as NodeType,
    name: n.name || TYPE_LABEL[n.type as NodeType] || '节点',
    approver: n.approver || '', condition: n.condition || '',
    x: Number(n.x) || 0, y: Number(n.y) || 0, next: n.next || '',
    branches: Array.isArray(n.branches) ? n.branches : [],
  }
}
function loadDefinition(): void {
  const row = definitions.value.find((d) => String(d.id) === String(selectedDefId.value))
  if (!row) { nodes.value = []; selectedNodeId.value = ''; resetRun(); return }
  def.name = row.name || ''; def.code = row.code || ''; def.remark = row.remark || ''
  const raw = row.nodes || row.schemaJson || row.schema
  let parsed: any[] = []
  try { parsed = typeof raw === 'string' ? JSON.parse(raw) : (Array.isArray(raw) ? raw : []) } catch { parsed = [] }
  nodes.value = parsed.length ? parsed.map(normalize) : demoNodes(row.code || '')
  selectedNodeId.value = ''
  resetRun()
}
async function save(): Promise<void> {
  if (!def.name.trim()) { toast.warning('请填写流程名称'); return }
  if (!nodes.value.length) { toast.warning('画布还没有节点'); return }
  saving.value = true
  const payload = {
    id: selectedDefId.value || undefined,
    code: def.code || 'FLOW_' + Date.now().toString(36).toUpperCase(),
    name: def.name, remark: def.remark, status: 1,
    nodes: nodes.value,
    edges: edges.value.map((e) => ({ from: e.from, to: e.to, label: e.label })),
  }
  try {
    const saved: any = await mockPost('/api/v1/bpm/definitions', payload)
    if (saved?.id) selectedDefId.value = saved.id
    toast.success('流程定义已保存（JSON 写入 bpm/definitions）')
    await loadList()
  } finally { saving.value = false }
}

/* ---------------- 模拟运行：条件判定 + 路径高亮 ---------------- */
const activeNodes = ref<string[]>([])
const activeEdges = ref<string[]>([])
const runLog = ref<Array<{ text: string; ok: boolean }>>([])
let timers: number[] = []
function resetRun(): void {
  timers.forEach((t) => window.clearTimeout(t)); timers = []
  activeNodes.value = []; activeEdges.value = []; runLog.value = []
}
/** 极简条件求值：支持 字段 比较符 数字；空条件视为通过；其他文本按 true/false 关键字 */
function evalCondition(expr: string, ctx: Record<string, any>): boolean {
  const s = String(expr || '').trim()
  if (!s) return true
  const m = s.match(/^([\w.]+)\s*(>=|<=|==|!=|>|<)\s*(-?\d+(?:\.\d+)?)$/)
  if (m) {
    const left = Number(ctx[m[1]] ?? NaN), right = Number(m[3])
    switch (m[2]) {
      case '>': return left > right
      case '<': return left < right
      case '>=': return left >= right
      case '<=': return left <= right
      case '==': return left === right
      case '!=': return left !== right
    }
  }
  if (/^(true|是|yes|通过)$/i.test(s)) return true
  if (/^(false|否|no|拒绝)$/i.test(s)) return false
  return true
}
function simulate(): void {
  resetRun()
  const start = nodes.value.find((n) => n.type === 'start') || nodes.value[0]
  if (!start) { toast.warning('画布为空，无法模拟'); return }
  // 演示上下文：可在条件里写 amount > 10000 / days >= 3
  const ctx = { amount: 12000, days: 5, level: 'A' }
  const path: FlowNode[] = []
  const decisions: Record<string, string> = {}
  const seen = new Set<string>()
  let cur: FlowNode | undefined = start
  let guard = 0
  while (cur && guard++ < 50 && !seen.has(cur.id)) {
    seen.add(cur.id)
    path.push(cur)
    if (cur.type === 'end') break
    let next: FlowNode | undefined
    if (cur.type === 'condition') {
      const branch = (cur.branches || []).find((b) => b.to && evalCondition(b.condition, ctx))
      if (branch) {
        decisions[cur.id] = `→ 分支「${branch.label || branch.condition || '默认'}」`
        next = nodes.value.find((n) => n.id === branch.to)
      } else {
        decisions[cur.id] = '→ 否则'
        next = nodes.value.find((n) => n.id === cur!.next)
      }
    } else {
      next = nodes.value.find((n) => n.id === cur!.next)
    }
    if (!next) { runLog.value.push({ text: `${cur.name}：无后续节点，流程结束`, ok: true }); break }
    cur = next
  }
  path.forEach((n, i) => {
    timers.push(window.setTimeout(() => {
      activeNodes.value = [...activeNodes.value, n.id]
      const prev = path[i - 1]
      if (prev) {
        const key = edges.value.find((e) => e.from === prev.id && e.to === n.id)?.key
        if (key) activeEdges.value = [...activeEdges.value, key]
      }
      runLog.value.push({ text: `第 ${i + 1} 步：${n.name}${n.approver ? '（' + n.approver + '）' : ''} ${decisions[n.id] || ''}`, ok: true })
    }, i * 420))
  })
  toast.info(`模拟完成：共经过 ${path.length} 个节点`)
}

onMounted(() => { void loadList() })
</script>

<style scoped>
.fd-head { display: flex; justify-content: space-between; align-items: center; gap: 12px; margin-bottom: 12px; flex-wrap: wrap; }
.fd-head h2 { font-size: 18px; margin: 0 0 4px; }
.fd-head p { margin: 0; font-size: 12px; color: var(--ds-text-3); }
.fd-head-ops { display: flex; gap: 8px; align-items: center; flex-wrap: wrap; }
.fd-def-select { width: 190px; }
.fd-name { width: 150px; }
.fd-layout { display: grid; grid-template-columns: 190px 1fr 280px; gap: 12px; align-items: start; }
.fd-palette { display: flex; align-items: center; gap: 8px; padding: 10px 12px; font-size: 13px; border-bottom: 1px solid var(--ds-divider); cursor: grab; }
.fd-palette:hover { background: var(--ds-brand-soft); }
.fd-dot { width: 10px; height: 10px; border-radius: 50%; flex: none; background: var(--ds-brand); }
.fd-dot.t-start, .fd-dot.t-end { background: #10b981; }
.fd-dot.t-condition { background: #f59e0b; }
.fd-dot.t-cc { background: #8b5cf6; }
.fd-hint { font-size: 12px; color: var(--ds-text-3); }
.fd-hint-pad { padding: 10px 12px; }
.fd-code { display: flex; flex-direction: column; gap: 6px; padding: 12px; border-top: 1px solid var(--ds-divider); }
.fd-code b { font-size: 12px; color: var(--ds-text-3); }
.fd-canvas {
  position: relative; height: 580px; overflow: auto;
  background-color: var(--ds-bg-soft);
  background-image: radial-gradient(var(--ds-border) 1px, transparent 1px);
  background-size: 20px 20px;
}
.fd-lines { position: absolute; inset: 0; width: 100%; height: 100%; pointer-events: none; overflow: visible; }
.fd-path { fill: none; stroke: #94a3b8; stroke-width: 2; transition: stroke .25s, stroke-width .25s; }
.fd-path.on { stroke: #2563eb; stroke-width: 3; }
.fd-edge-label { font-size: 11px; fill: var(--ds-text-3); text-anchor: middle; }
.fd-node {
  position: absolute; width: 168px; min-height: 68px; box-sizing: border-box;
  display: flex; flex-direction: column; justify-content: center; gap: 3px;
  padding: 8px 12px; border: 1px solid var(--ds-border); border-left: 4px solid var(--ds-brand);
  border-radius: var(--ds-radius); background: var(--ds-bg-elevated); box-shadow: var(--ds-shadow-sm);
  cursor: move; font-size: 13px; user-select: none; transition: box-shadow .2s, border-color .2s;
}
.fd-node b { font-size: 13px; }
.fd-node small { font-size: 11px; color: var(--ds-text-3); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.fd-node.t-start, .fd-node.t-end { border-left-color: #10b981; }
.fd-node.t-condition { border-left-color: #f59e0b; }
.fd-node.t-cc { border-left-color: #8b5cf6; }
.fd-node.selected { border-color: var(--ds-brand); box-shadow: 0 0 0 2px var(--ds-brand-soft); }
.fd-node.on { border-color: #2563eb; border-left-color: #2563eb; background: var(--ds-brand-soft); box-shadow: 0 0 0 3px rgba(37, 99, 235, .2); }
.fd-node.on b { color: #2563eb; }
.fd-node-sub { opacity: .7; }
.fd-canvas-empty { position: absolute; inset: 0; display: grid; place-items: center; color: var(--ds-text-3); font-size: 13px; }
.fd-canvas-bar { display: flex; align-items: center; gap: 8px; padding: 8px 12px; font-size: 12px; color: var(--ds-text-3); border-top: 1px solid var(--ds-divider); }
.fd-gap { flex: 1; }
.fd-prop { display: flex; flex-direction: column; gap: 10px; padding: 12px; }
.fd-prop label { display: flex; flex-direction: column; gap: 4px; font-size: 12px; }
.fd-prop label span { color: var(--ds-text-3); }
.fd-branches { display: flex; flex-direction: column; gap: 8px; border-top: 1px solid var(--ds-divider); padding-top: 10px; }
.fd-branches > b { font-size: 12px; color: var(--ds-text-3); }
.fd-branch { display: grid; grid-template-columns: 1fr 1fr; gap: 6px; padding: 8px; border: 1px dashed var(--ds-border); border-radius: var(--ds-radius); }
.fd-branch .ds-select { grid-column: 1 / -1; }
.fd-empty { text-align: center; color: var(--ds-text-3); font-size: 12px; padding: 20px 12px; }
.fd-runlog { border-top: 1px solid var(--ds-divider); padding: 12px; }
.fd-runlog > b { display: block; font-size: 12px; margin-bottom: 8px; }
.fd-log { font-size: 12px; padding: 5px 8px; margin-bottom: 4px; border-radius: var(--ds-radius-sm); background: var(--ds-brand-soft); color: var(--ds-brand); }
.fd-log.bad { background: rgba(239, 68, 68, .1); color: var(--ds-danger); }
</style>
