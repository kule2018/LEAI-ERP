<!--
 * 导入导出中心（文档第 26 章）。
 * ---------------------------------------------------------------------------
 * 导入：模板下载 → 粘贴/选文件 → 前置校验 → 预览 → 确认写库 → 错误报告；
 * 导出：按当前筛选生成后台任务，显示进度，完成后下载 CSV。
 * 大文件用任务化模拟，避免长时间阻塞页面。
 -->
<template>
  <div class="erp-page">
    <div class="ie-head">
      <div>
        <h2>导入导出中心</h2>
        <p>大文件后台处理，导入带错误报告，导出保留筛选条件</p>
      </div>
      <DsButton variant="primary" @click="createVisible = true">新建任务</DsButton>
    </div>

    <div class="ie-cards">
      <div class="ie-card"><span>导入任务</span><b>{{ imports.length }}</b></div>
      <div class="ie-card"><span>成功导入</span><b>{{ imports.reduce((s, t) => s + Number(t.successCount || 0), 0) }}</b></div>
      <div class="ie-card"><span>失败行</span><b class="danger">{{ imports.reduce((s, t) => s + Number(t.failCount || 0), 0) }}</b></div>
      <div class="ie-card"><span>导出任务</span><b>{{ exports.length }}</b></div>
    </div>

    <DsCard :pad="false">
      <DsTabs v-model="tab" :items="[{ label: '导入任务', value: 'in' }, { label: '导出任务', value: 'out' }, { label: '导入模板', value: 'tpl' }, { label: '大文件上传', value: 'file' }]" />
      <div v-if="tab === 'file'" class="ie-body ie-upload">
        <p class="ie-hint">2MB 分片上传，支持秒传与断点续传；上传完成后可到 AI 智能建单中解析文档。</p>
        <ChunkedUpload :kb-id="1" @done="onUploaded" />
      </div>
      <div v-if="tab === 'in'" class="ie-body">
        <table class="ie-table">
          <thead><tr><th>ID</th><th>实体</th><th>状态</th><th>进度</th><th>成功/失败</th><th>创建时间</th><th>操作</th></tr></thead>
          <tbody>
            <tr v-for="t in imports" :key="t.id">
              <td>{{ t.id }}</td><td>{{ t.entity }}</td>
              <td><DsTag :color="t.status === 'DONE' ? 'success' : t.status === 'FAILED' ? 'danger' : 'brand'" size="sm">{{ statusText(t.status) }}</DsTag></td>
              <td><DsProgress :percentage="Number(t.progress || 0)" /></td>
              <td>{{ t.successCount || 0 }} / {{ t.failCount || 0 }}</td>
              <td>{{ t.createdAt }}</td>
              <td>
                <DsButton variant="text" size="sm" @click="advance(t)">模拟推进</DsButton>
                <DsButton v-if="t.failCount" variant="text" size="sm" @click="errors(t)">错误报告</DsButton>
              </td>
            </tr>
            <tr v-if="!imports.length"><td colspan="7" class="ie-empty">暂无导入任务</td></tr>
          </tbody>
        </table>
      </div>
      <div v-else-if="tab === 'out'" class="ie-body">
        <table class="ie-table">
          <thead><tr><th>ID</th><th>实体</th><th>格式</th><th>状态</th><th>进度</th><th>创建时间</th><th>操作</th></tr></thead>
          <tbody>
            <tr v-for="t in exports" :key="t.id">
              <td>{{ t.id }}</td><td>{{ t.entity }}</td><td>{{ t.format }}</td>
              <td>{{ statusText(t.status) }}</td><td><DsProgress :percentage="Number(t.progress || 0)" /></td><td>{{ t.createdAt }}</td>
              <td><DsButton variant="text" size="sm" @click="advance(t)">推进</DsButton><DsButton v-if="t.status === 'DONE'" variant="text" size="sm" @click="download(t)">下载</DsButton></td>
            </tr>
            <tr v-if="!exports.length"><td colspan="7" class="ie-empty">暂无导出任务</td></tr>
          </tbody>
        </table>
      </div>
      <div v-else class="ie-body ie-tpl">
        <div v-for="e in entities" :key="e" class="ie-tpl-item"><b>{{ e }}</b><DsButton size="sm" @click="downloadTemplate(e)">下载模板</DsButton></div>
      </div>
    </DsCard>

    <DsModal v-model="createVisible" title="新建导入导出任务" :width="520">
      <div class="ie-form">
        <label><span>类型</span><select v-model="form.kind" class="ds-select"><option value="in">导入</option><option value="out">导出</option></select></label>
        <label><span>实体</span><select v-model="form.entity" class="ds-select"><option v-for="e in entities" :key="e" :value="e">{{ e }}</option></select></label>
        <label v-if="form.kind === 'out'"><span>格式</span><select v-model="form.format" class="ds-select"><option>CSV</option><option>Excel</option></select></label>
        <label class="full"><span>粘贴数据（首行为字段名，可从 Excel 直接复制）</span><textarea v-model="form.content" class="ds-input" rows="5" placeholder="name&#9;code&#9;price" /></label>
      </div>
      <template #footer><div class="ie-foot"><DsButton @click="createVisible = false">取消</DsButton><DsButton variant="primary" @click="create">创建任务</DsButton></div></template>
    </DsModal>

    <DsModal v-model="errorVisible" title="导入错误报告" :width="600">
      <table class="ie-table"><thead><tr><th>行号</th><th>字段</th><th>原因</th></tr></thead>
        <tbody><tr v-for="e in errorRows" :key="e.id"><td>{{ e.rowNo }}</td><td>{{ e.field }}</td><td>{{ e.reason }}</td></tr></tbody>
      </table>
      <template #footer><div class="ie-foot"><DsButton @click="downloadErrors">下载错误明细</DsButton><DsButton variant="primary" @click="errorVisible = false">关闭</DsButton></div></template>
    </DsModal>
  </div>
</template>

<script setup lang="ts">
/** 导入导出中心：任务化模拟、错误报告、模板下载 */
import { onMounted, reactive, ref } from 'vue';
import { mockGet, mockPost } from '../../api/mockAdapter';
import { useToast } from '../../components/ds/toast';

const toast = useToast();
const tab = ref('in');
const imports = ref<any[]>([]);
const exports = ref<any[]>([]);
const createVisible = ref(false);
const errorVisible = ref(false);
const errorRows = ref<any[]>([]);
const currentTask = ref<any>(null);
const entities = ['产品', '客户', '供应商', '销售单', '采购单', '会计科目', '雇员'];
/** 中文实体名 -> 真实 API 路径，供导入模板与导出取数使用 */
const ENTITY_API: Record<string, string> = {
  产品: 'inventory/products', 客户: 'crm/customers', 供应商: 'purchase/suppliers',
  销售单: 'sales/orders', 采购单: 'purchase/orders', 会计科目: 'finance/subjects', 雇员: 'hr/employees',
};
const form = reactive<any>({ kind: 'in', entity: '产品', format: 'CSV', content: '' });

/** 加载任务列表 */
async function load(): Promise<void> {
  imports.value = (await mockGet('/api/v1/ux/import-tasks', { pageSize: 100 })) as any[];
  exports.value = (await mockGet('/api/v1/ux/export-tasks', { pageSize: 100 })) as any[];
}
function statusText(status: string): string {
  return { PENDING: '等待中', RUNNING: '处理中', DONE: '已完成', FAILED: '失败' }[status] || status;
}

/** 创建任务：按行数估算成功失败，写入 mock */
async function create(): Promise<void> {
  const lines = form.content.split('\n').filter(Boolean);
  if (form.kind === 'in' && lines.length < 2) { toast.warning('请粘贴至少两行数据（含表头）'); return; }
  const failCount = form.kind === 'in' ? Math.max(0, lines.length - 2 - 1) : 0;
  const task: any = await mockPost(form.kind === 'in' ? '/api/v1/ux/import-tasks' : '/api/v1/ux/export-tasks', {
    entity: form.entity, status: 'PENDING', progress: 0, format: form.format,
    successCount: Math.max(0, lines.length - 1 - failCount), failCount, createdAt: new Date().toLocaleString('zh-CN'),
  });
  if (form.kind === 'in' && failCount) {
    await mockPost('/api/v1/ux/import-errors', { taskId: task.id, rowNo: lines.length, field: '格式', reason: '示例：字段格式不符合要求' });
  }
  createVisible.value = false;
  form.content = '';
  toast.success('任务已创建，可点击「模拟推进」查看进度');
  load();
}

/** 模拟后台推进：每点一次前进 35% */
async function advance(task: any): Promise<void> {
  const progress = Math.min(100, Number(task.progress || 0) + 35);
  const status = progress >= 100 ? 'DONE' : 'RUNNING';
  await mockPost(`/api/v1/ux/${task.failCount !== undefined && task.successCount !== undefined ? 'import' : 'export'}-tasks/${task.id}/progress`, { progress, status });
  task.progress = progress; task.status = status;
  toast.success(status === 'DONE' ? '任务已完成' : '处理中…');
}

/** 查看错误明细 */
async function errors(task: any): Promise<void> {
  currentTask.value = task;
  const list: any = await mockGet('/api/v1/ux/import-errors', { taskId: task.id });
  errorRows.value = Array.isArray(list) ? list : list?.list || [];
  errorVisible.value = true;
}

/** 通用 CSV 下载 */
function saveCsv(name: string, lines: string[]): void {
  const blob = new Blob(['\ufeff' + lines.join('\n')], { type: 'text/csv;charset=utf-8' });
  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob); link.download = name; link.click(); URL.revokeObjectURL(link.href);
}
function downloadErrors(): void {
  saveCsv(`导入错误_${currentTask.value?.id || 1}.csv`, ['行号,字段,原因', ...errorRows.value.map((e) => `${e.rowNo},${e.field},${e.reason}`)]);
}
/** 分片上传完成：写入导入任务记录，进入统一任务列表 */
async function onUploaded(result: any): Promise<void> {
  await mockPost('/api/v1/ux/import-tasks', { entity: '文档解析', status: 'DONE', progress: 100, successCount: 1, failCount: 0, source: result?.uploadId || 'local' });
  toast.success('上传已完成，可在导入任务中查看');
  load();
}
/** 导入模板表头：按实体 Schema 真实字段生成，不再写死示例行 */
async function downloadTemplate(entity: string): Promise<void> {
  try {
    const api = ENTITY_API[entity];
    // 先取真实数据行，用真实字段名作为模板表头（无数据时退回实体 Schema 字段）
    let cols: string[] = [];
    if (api) {
      const data: any = await mockGet(`/api/v1/${api}`, { pageSize: 1 });
      const rows = Array.isArray(data) ? data : data?.list || [];
      cols = rows.length ? Object.keys(rows[0]).filter((k) => !k.startsWith('__')) : [];
    }
    if (!cols.length) {
      const meta: any = await mockGet(`/_biz/schema/${api || entity}`);
      cols = (meta?.fields || []).filter((f: any) => f.prop !== 'id' && f.form !== false).map((f: any) => f.label || f.prop);
    }
    saveCsv(`${entity}_导入模板.csv`, [cols.join(',')]);
    toast.success('导入模板已下载（真实字段表头）');
  } catch { saveCsv(`${entity}_导入模板.csv`, ['名称,编码']); }
}
/** 导出文件带导出人/时间水印，导出真实实体数据，便于追踪泄露来源（文档第 32 章） */
async function download(task: any): Promise<void> {
  try {
    const api = ENTITY_API[task.entity];
    if (!api) { toast.warning(`暂不支持导出「${task.entity}」`); return; }
    const data: any = await mockGet(`/api/v1/${api}`, { pageSize: 1000 });
    const rows = Array.isArray(data) ? data : data?.list || [];
    const keys = rows.length ? Object.keys(rows[0]).filter((k) => !k.startsWith('__')) : [];
    const lines = [
      `# 导出水印：${task.entity} | 任务 ${task.id} | ${new Date().toLocaleString('zh-CN')} | 仅限内部使用`,
      keys.join(','),
      ...rows.map((r: any) => keys.map((k) => `"${String(r[k] ?? '').replace(/"/g, '""')}"`).join(',')),
    ];
    saveCsv(`${task.entity}_导出_${task.id}.csv`, lines);
    toast.success(`已导出 ${rows.length} 条真实数据`);
  } catch { toast.error('导出失败，请稍后重试'); }
}

onMounted(load);
</script>

<style scoped>
.ie-head { display: flex; justify-content: space-between; align-items: center; margin-bottom: 14px; }
.ie-head h2 { font-size: 18px; margin: 0 0 4px; }
.ie-head p { margin: 0; font-size: 12px; color: var(--ds-text-3); }
.ie-cards { display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px; margin-bottom: 12px; }
.ie-card { border: 1px solid var(--ds-border); border-radius: var(--ds-radius); background: var(--ds-bg-elevated); padding: 12px 16px; display: flex; flex-direction: column; gap: 4px; }
.ie-card span { font-size: 12px; color: var(--ds-text-3); }
.ie-card b { font-size: 20px; }
.ie-card .danger { color: var(--ds-danger); }
.ie-body { padding: 12px; }
.ie-table { width: 100%; border-collapse: collapse; font-size: 13px; }
.ie-table th, .ie-table td { padding: 9px 10px; border-bottom: 1px solid var(--ds-divider); text-align: left; }
.ie-table th { background: var(--ds-bg-soft); color: var(--ds-text-3); }
.ie-empty { text-align: center; color: var(--ds-text-3); padding: 24px; }
.ie-upload { padding: 24px; }
.ie-hint { margin: 0 0 14px; color: var(--ds-text-3); font-size: 13px; }
.ie-tpl { display: flex; flex-wrap: wrap; gap: 12px; }
.ie-tpl-item { display: flex; align-items: center; gap: 12px; border: 1px solid var(--ds-border); border-radius: var(--ds-radius); padding: 10px 14px; }
.ie-form { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
.ie-form label { display: flex; flex-direction: column; gap: 4px; font-size: 13px; }
.ie-form .full { grid-column: 1 / -1; }
.ie-foot { display: flex; justify-content: flex-end; gap: 8px; }
</style>
