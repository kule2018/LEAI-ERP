<!--
 * 外部集成中心（文档第 31 章：第三方集成）。
 * ---------------------------------------------------------------------------
 * 由「配置展示 + 模拟联调」升级为可走通的控制台：
 * 六组适配器（OAuth / 支付 / 物流 / 发票 / 银企 / 节假日）统一展示配置、状态、
 * 验签、回调地址、幂等策略与最近日志；授权链接、业务回调、节假日查询均真实调用
 * mock 接口并记录日志，重复事件按 requestId 幂等忽略。
-->
<template>
  <div class="erp-page">
    <div class="int-head">
      <div>
        <h2>外部集成中心</h2>
        <p>每个适配器提供「配置 → 验签 → 回调 → 幂等 → 补偿」标准契约；未配置密钥时走模拟回执。</p>
      </div>
      <DsTag color="warning">演示环境为模拟回执</DsTag>
    </div>

    <div class="int-grid">
      <DsCard v-for="a in adapters" :key="a.code" :title="a.name" class="int-card">
        <template #extra>
          <DsTag :color="a.enabled ? 'success' : 'neutral'" size="sm">{{ a.enabled ? '已启用' : '未启用' }}</DsTag>
        </template>

        <p class="int-desc">{{ a.desc }}</p>

        <!-- 统一契约：验签方式 / 回调地址 / 幂等策略 -->
        <div class="int-meta">
          <div><b>验签方式</b><span>{{ a.signature }}</span></div>
          <div>
            <b>回调地址</b><code>{{ a.callback }}</code>
            <DsButton variant="text" size="sm" @click="copy(a.callback)">复制</DsButton>
          </div>
          <div><b>幂等策略</b><span>{{ a.idempotency }}</span></div>
        </div>

        <!-- 配置字段 -->
        <div class="int-fields">
          <label v-for="f in a.fields" :key="f.key">
            <span>{{ f.label }}</span>
            <select v-if="f.options" v-model="a.config[f.key]" class="ds-select">
              <option v-for="o in f.options" :key="o.value" :value="o.value">{{ o.label }}</option>
            </select>
            <input v-else v-model="a.config[f.key]" class="ds-input" :placeholder="f.placeholder" />
          </label>
        </div>

        <!-- OAuth：生成授权链接（仅展示，不跳转） -->
        <div v-if="a.code === 'oauth'" class="int-block">
          <div class="int-block-head">
            <b>授权链接</b>
            <DsButton size="sm" variant="primary" @click="genAuthUrl(a)">生成授权链接</DsButton>
          </div>
          <template v-if="a.oauth?.authorizeUrl">
            <label class="int-kv"><span>authorizeUrl</span><input class="ds-input" :value="a.oauth.authorizeUrl" readonly /></label>
            <label class="int-kv"><span>state</span><input class="ds-input" :value="a.oauth.state" readonly /></label>
            <div class="int-tip">已生成演示链接，不会自动跳转；{{ a.oauth.tip }}</div>
          </template>
          <div v-else-if="a.oauth?.tip" class="int-warn">{{ a.oauth.tip }}</div>
          <div v-else class="int-tip">选择平台并填写密钥后点击「生成授权链接」，仅展示 authorizeUrl 与 state，不做真实跳转。</div>
        </div>

        <!-- 节假日 API：按年份查询 -->
        <div v-if="a.code === 'holidays'" class="int-block">
          <div class="int-block-head">
            <b>节假日查询</b>
            <div class="int-year">
              <input v-model.number="holidayYear" class="ds-input" type="number" min="2000" max="2100" />
              <DsButton size="sm" variant="primary" @click="queryHolidays">查询</DsButton>
            </div>
          </div>
          <div v-if="holidays.length" class="int-holidays">
            <div v-for="h in holidays" :key="h.date + h.name" class="int-holiday">
              <span class="int-hdate">{{ h.date }}</span>
              <span class="int-hname">{{ h.name }}</span>
              <DsTag size="sm" :color="h.source === '外部' ? 'success' : 'neutral'">{{ h.source }}</DsTag>
            </div>
          </div>
          <div v-else class="int-tip">输入年份后点击「查询」，展示节假日列表与来源（内置 / 外部）。</div>
        </div>

        <!-- 最近调用日志（按 provider 过滤） -->
        <div class="int-block">
          <div class="int-block-head"><b>最近调用日志</b><span class="int-muted">全局 {{ allLogs.length }} 条</span></div>
          <div v-for="(l, i) in recentLogs(a.code)" :key="i" class="int-logline">
            <span class="int-logtime">{{ l.createdAt }}</span>
            <span class="int-logact">{{ l.action }}</span>
            <DsTag size="sm" :color="l.result === '失败' ? 'danger' : 'success'">{{ l.result }}</DsTag>
          </div>
          <div v-if="!recentLogs(a.code).length" class="int-tip">暂无调用记录，可执行「联调测试」或「模拟回调」。</div>
        </div>

        <div class="int-ops">
          <DsButton size="sm" @click="toggle(a)">{{ a.enabled ? '停用' : '启用' }}</DsButton>
          <DsButton size="sm" variant="primary" @click="test(a)">联调测试</DsButton>
          <DsButton v-if="a.event" size="sm" variant="ghost" @click="simulateCallback(a)">模拟回调</DsButton>
        </div>
        <pre v-if="a.result" class="int-result">{{ a.result }}</pre>
      </DsCard>
    </div>

    <!-- 全局调用日志：时间 / provider / 动作 / 签名校验 / 耗时 / 结果 -->
    <DsCard title="调用日志" :pad="false" class="int-logs">
      <template #extra><DsButton size="sm" @click="loadLogs">刷新</DsButton></template>
      <table class="int-table">
        <thead>
          <tr><th>时间</th><th>provider</th><th>动作</th><th>签名校验</th><th>耗时</th><th>结果</th></tr>
        </thead>
        <tbody>
          <tr v-for="l in allLogs" :key="l.id">
            <td>{{ l.createdAt }}</td>
            <td>{{ l.provider }}</td>
            <td>{{ l.action }}</td>
            <td>{{ l.signature }}</td>
            <td>{{ l.costMs }}ms</td>
            <td><DsTag size="sm" :color="l.result === '失败' ? 'danger' : 'success'">{{ l.result }}</DsTag></td>
          </tr>
          <tr v-if="!allLogs.length">
            <td colspan="6" class="int-empty">暂无调用日志，点击各卡片的「联调测试」或「模拟回调」后自动记录。</td>
          </tr>
        </tbody>
      </table>
    </DsCard>
  </div>
</template>

<script setup lang="ts">
/** 外部集成控制台：配置、授权、业务回调、节假日查询与调用日志 */
import { onMounted, reactive, ref } from 'vue';
import { DsButton, DsCard, DsTag } from '../../components';
import { mockGet, mockPost } from '../../api/mockAdapter';
import { useToast } from '../../components/ds/toast';

interface AdapterField { key: string; label: string; placeholder?: string; options?: Array<{ value: string; label: string }> }
interface Adapter {
  code: string; name: string; desc: string; enabled: boolean
  signature: string; callback: string; idempotency: string
  fields: AdapterField[]; config: Record<string, any>
  result: string; event?: string; callbackPath?: string
  oauth?: { authorizeUrl: string; state: string; tip: string }
}

const toast = useToast();

/** 六组适配器：统一契约 + 各自配置字段 */
const adapters = reactive<Adapter[]>([
  {
    code: 'oauth', name: '办公平台 OAuth（企业微信 / 钉钉）',
    desc: '组织架构同步与免登：生成授权链接、校验 state，回调换取用户身份。',
    enabled: false, signature: 'state 防重放 + HMAC-SHA256', callback: '/api/v1/auth/oauth/callback',
    idempotency: 'state 一次性消费（5 分钟有效）',
    fields: [
      { key: 'provider', label: '平台', options: [{ value: 'wechat_work', label: '企业微信' }, { value: 'dingtalk', label: '钉钉' }] },
      { key: 'corpId', label: '企业 ID / CorpID', placeholder: 'ww...' },
      { key: 'appKey', label: '应用 AppKey（钉钉）', placeholder: 'ding...' },
      { key: 'redirectUri', label: '回调地址', placeholder: 'https://erp.example.com/oauth/callback' },
    ],
    config: { provider: 'wechat_work', corpId: '', appKey: '', redirectUri: 'https://erp.example.com/oauth/callback' },
    result: '',
  },
  {
    code: 'payment', name: '支付（微信 / 支付宝 / 聚合）',
    desc: '收款回调验签、支付状态回写与退款；支持多通道路由。',
    enabled: false, signature: '微信 V3 RSA-SHA256 / 支付宝 RSA2', callback: '/api/v1/callback/payment',
    idempotency: 'out_trade_no + 5 分钟缓存',
    fields: [
      { key: 'wxAppId', label: '微信 AppID', placeholder: 'wx...' },
      { key: 'mchId', label: '商户号', placeholder: '190...' },
      { key: 'aliAppId', label: '支付宝 AppID', placeholder: '2021...' },
      { key: 'channel', label: '默认通道', options: [{ value: 'WECHAT', label: '微信' }, { value: 'ALIPAY', label: '支付宝' }, { value: 'AGGREGATE', label: '聚合' }] },
      { key: 'bizNo', label: '演示业务单号', placeholder: 'SO20261117-0002' },
    ],
    config: { wxAppId: '', mchId: '', aliAppId: '', channel: 'WECHAT', bizNo: 'SO20261117-0002' },
    result: '', event: 'payment.success', callbackPath: '/api/v1/callback/payment',
  },
  {
    code: 'logistics', name: '物流（顺丰 / 圆通）',
    desc: '电子面单、轨迹订阅与发货状态回写，回调按运单号去重。',
    enabled: false, signature: 'HMAC-SHA256', callback: '/api/v1/callback/logistics',
    idempotency: 'waybillNo + eventType 联合键',
    fields: [
      { key: 'carrier', label: '承运商', options: [{ value: 'SF', label: '顺丰' }, { value: 'YTO', label: '圆通' }] },
      { key: 'customerCode', label: '客户编码', placeholder: 'SF...' },
      { key: 'apiKey', label: 'API Key', placeholder: '请输入密钥' },
      { key: 'bizNo', label: '演示业务单号', placeholder: 'SO20261116-0001' },
    ],
    config: { carrier: 'SF', customerCode: '', apiKey: '', bizNo: 'SO20261116-0001' },
    result: '', event: 'logistics.shipped', callbackPath: '/api/v1/callback/logistics',
  },
  {
    code: 'invoice', name: '电子发票',
    desc: '开票申请、进项查验、红冲与归档；发票号码唯一去重。',
    enabled: false, signature: '税务数字证书签名', callback: '/api/v1/callback/invoice',
    idempotency: 'invoiceCode + invoiceNo',
    fields: [
      { key: 'taxNo', label: '纳税人识别号', placeholder: '9133...' },
      { key: 'sellerCode', label: '开票方编码', placeholder: '请输入' },
      { key: 'apiKey', label: 'API Key', placeholder: '请输入密钥' },
      { key: 'bizNo', label: '演示业务单号', placeholder: 'SO20261116-0001' },
    ],
    config: { taxNo: '', sellerCode: '', apiKey: '', bizNo: 'SO20261116-0001' },
    result: '', event: 'invoice.issued', callbackPath: '/api/v1/callback/invoice',
  },
  {
    code: 'bank', name: '银企直连',
    desc: '银行流水导入、回单匹配与收付款凭证联动，按银行流水号去重。',
    enabled: false, signature: '银行证书签名 + 双向 mTLS', callback: '/api/v1/callback/bank',
    idempotency: 'bankSeq + 日终对账',
    fields: [
      { key: 'bankCode', label: '银行编码', options: [{ value: 'ICBC', label: '工商银行' }, { value: 'CMB', label: '招商银行' }, { value: 'BOC', label: '中国银行' }] },
      { key: 'accountNo', label: '账号', placeholder: '6222...' },
      { key: 'certId', label: '证书编号', placeholder: '请输入' },
      { key: 'bizNo', label: '演示业务单号', placeholder: 'PAY20261117-0001' },
    ],
    config: { bankCode: 'ICBC', accountNo: '', certId: '', bizNo: 'PAY20261117-0001' },
    result: '', event: 'bank.transaction', callbackPath: '/api/v1/callback/bank',
  },
  {
    code: 'holidays', name: '节假日 API',
    desc: '按年份拉取法定节假日与调休安排，用于营业日与账期计算。',
    enabled: false, signature: '外部源 HMAC-SHA256', callback: '主动拉取（无回调）',
    idempotency: 'year + 24 小时缓存',
    fields: [
      { key: 'source', label: '数据源', options: [{ value: 'BUILTIN', label: '内置' }, { value: 'EXTERNAL', label: '外部 API' }] },
      { key: 'apiKey', label: '外部 API Key', placeholder: '使用外部源时填写' },
    ],
    config: { source: 'BUILTIN', apiKey: '' },
    result: '',
  },
]);

/** 全局调用日志与节假日结果 */
const allLogs = ref<any[]>([]);
const holidays = ref<any[]>([]);
const holidayYear = ref(new Date().getFullYear());
/** 已处理的事件键：用于演示幂等（同一业务单号重复回调会被忽略） */
const seenEvents = new Set<string>();

/** 当前时间字符串 */
function now(): string { return new Date().toISOString().slice(0, 19).replace('T', ' '); }

/** 复制文本：优先 Clipboard API，失败回退 textarea */
function copy(text: string): void {
  const ok = () => toast.success('已复制到剪贴板');
  if (navigator.clipboard?.writeText) {
    navigator.clipboard.writeText(text).then(ok).catch(() => fallbackCopy(text, ok));
  } else { fallbackCopy(text, ok); }
}
function fallbackCopy(text: string, ok: () => void): void {
  const ta = document.createElement('textarea');
  ta.value = text; document.body.appendChild(ta); ta.select();
  try { document.execCommand('copy'); ok(); } catch { toast.warning('复制失败，请手动选择文本'); }
  document.body.removeChild(ta);
}

/** 按 provider 取最近 3 条日志 */
function recentLogs(code: string): any[] { return allLogs.value.filter((l) => l.provider === code).slice(0, 3); }

/** 写调用日志：真实落库到 /integrations/logs，失败不影响主流程 */
async function writeLog(entry: any): Promise<void> {
  try {
    const row: any = await mockPost('/api/v1/integrations/logs', { ...entry, createdAt: now() });
    if (row?.id) allLogs.value = [row, ...allLogs.value.filter((l) => l.id !== row.id)];
  } catch { /* 日志写入失败静默降级 */ }
}

/** 加载日志：过滤掉 mock 通用兜底生成的无 provider 记录 */
async function loadLogs(): Promise<void> {
  try {
    const data: any = await mockGet('/api/v1/integrations/logs', { pageSize: 100 });
    const rows = Array.isArray(data) ? data : data?.list || [];
    allLogs.value = rows.filter((r: any) => !!r.provider).sort((a: any, b: any) => Number(b.id || 0) - Number(a.id || 0));
  } catch { allLogs.value = []; }
}

/** 兼容旧版保存的启用状态与配置（office 映射为 oauth） */
async function load(): Promise<void> {
  try {
    const data: any = await mockGet('/api/v1/ux/integrations', { pageSize: 100 });
    const alias: Record<string, string> = { office: 'oauth' };
    for (const row of (Array.isArray(data) ? data : data?.list || [])) {
      const target = adapters.find((a) => a.code === (alias[row.code] || row.code));
      if (target) { target.enabled = !!row.enabled; Object.assign(target.config, row.config || {}); }
    }
  } catch { /* 首次进入使用默认配置 */ }
}

/** 启用/停用：沿用原接口，保留已有能力 */
async function toggle(a: Adapter): Promise<void> {
  a.enabled = !a.enabled;
  await mockPost('/api/v1/ux/integrations', { code: a.code, enabled: a.enabled, config: a.config });
  await writeLog({ provider: a.code, action: a.enabled ? '启用适配器' : '停用适配器', signature: '-', costMs: 12, result: '成功' });
  toast.success(`${a.name} 已${a.enabled ? '启用' : '停用'}`);
}

/** 联调测试：保留原标准契约回执，并落日志 */
async function test(a: Adapter): Promise<void> {
  const started = performance.now();
  await mockPost('/api/v1/ux/integration-tests', { code: a.code, config: a.config });
  const cost = Math.max(1, Math.round(performance.now() - started));
  a.result = JSON.stringify({
    adapter: a.code,
    handshake: a.enabled ? 'SUCCESS' : 'DRY_RUN',
    signature: a.signature + ' verified',
    idempotency: a.idempotency,
    callback: a.callback,
    compensation: 'retry 3 times with backoff',
    timestamp: now(),
  }, null, 2);
  await writeLog({ provider: a.code, action: '联调测试', signature: a.signature, costMs: cost, result: a.enabled ? '成功' : '成功（DRY_RUN）' });
  toast.success('联调完成');
}

/**
 * OAuth：调用 mockPost('/auth/oauth/{provider}') 登记授权请求，
 * authorizeUrl 按平台规则在本地拼装；无密钥时给明确提示且不跳转。
 */
async function genAuthUrl(a: Adapter): Promise<void> {
  const provider = String(a.config.provider || 'wechat_work');
  const credential = provider === 'wechat_work' ? a.config.corpId : a.config.appKey;
  if (!credential) {
    a.oauth = { authorizeUrl: '', state: '', tip: `未配置${provider === 'wechat_work' ? '企业 CorpID' : '钉钉 AppKey'}，无法生成授权链接；请在上方配置字段填写后重试。` };
    toast.warning(a.oauth.tip);
    return;
  }
  const state = Math.random().toString(36).slice(2) + Date.now().toString(36);
  const redirect = encodeURIComponent(a.config.redirectUri || 'https://erp.example.com/oauth/callback');
  const authorizeUrl = provider === 'wechat_work'
    ? `https://open.weixin.qq.com/connect/oauth2/authorize?appid=${encodeURIComponent(credential)}&redirect_uri=${redirect}&response_type=code&scope=snsapi_base&state=${state}#wechat_redirect`
    : `https://open.dingtalk.com/dingding/orglogin?appkey=${encodeURIComponent(credential)}&redirect_uri=${redirect}&state=${state}`;
  const resp: any = await mockPost(`/api/v1/auth/oauth/${provider}`, { provider, corpId: credential, redirectUri: a.config.redirectUri, state });
  a.oauth = { authorizeUrl, state, tip: `已登记授权请求（记录 ID ${resp?.id || '-'}），state 仅一次有效。` };
  a.result = JSON.stringify(resp, null, 2);
  await writeLog({ provider: a.code, action: `生成授权链接（${provider}）`, signature: 'state 防重放', costMs: 18, result: '成功' });
  toast.success('授权链接已生成（仅展示，不跳转）');
}

/** 根据事件类型给出业务回写提示 */
function writeBackText(event: string, bizNo: string): string {
  if (event === 'payment.success') return `销售单 ${bizNo} 收款状态已更新为「已支付」，财务收款单已生成`;
  if (event === 'logistics.shipped') return `销售单 ${bizNo} 发货状态已同步，运单号已回写`;
  if (event === 'invoice.issued') return `发票已归档，业务单 ${bizNo} 开票状态已更新`;
  if (event === 'bank.transaction') return `银行流水已匹配，${bizNo} 收付款记录已生成凭证`;
  return '未知事件，仅记录未回写';
}

/** 业务回调模拟：构造事件 → mockPost → 幂等判定 → 业务回写提示 */
async function simulateCallback(a: Adapter): Promise<void> {
  if (!a.event || !a.callbackPath) return;
  const bizNo = String(a.config.bizNo || '').trim() || `DEMO-${Date.now()}`;
  const eventId = `${a.event}:${bizNo}`;
  const duplicated = seenEvents.has(eventId);
  const payload = {
    event: a.event, eventId, bizNo, provider: a.code,
    data: { amount: 12800, currency: 'CNY', status: 'SUCCESS', carrier: a.config.carrier, bankCode: a.config.bankCode },
    signature: a.signature, signedAt: now(),
  };
  const started = performance.now();
  const resp: any = await mockPost(a.callbackPath, payload);
  const cost = Math.max(1, Math.round(performance.now() - started));
  if (!duplicated) seenEvents.add(eventId);
  a.result = JSON.stringify({
    event: a.event, eventId,
    idempotency: duplicated ? 'DUPLICATE_IGNORED（幂等命中，未重复回写）' : 'PROCESSED（首次处理）',
    verify: 'SIGNATURE_OK',
    writeBack: duplicated ? '无需回写（已处理过该事件）' : writeBackText(a.event, bizNo),
    responseId: resp?.id, timestamp: now(),
  }, null, 2);
  await writeLog({
    provider: a.code, action: `模拟回调 ${a.event}`, signature: '通过', costMs: cost,
    result: duplicated ? '重复忽略（幂等）' : '成功',
  });
  toast[duplicated ? 'warning' : 'success'](duplicated ? '重复回调已按幂等策略忽略' : '回调已处理并回写业务单据');
}

/** 内置节假日数据：外部接口无有效数据时回退 */
function builtinHolidays(year: number): any[] {
  const base = [
    ['01-01', '元旦'], ['02-17', '春节'], ['04-05', '清明节'], ['05-01', '劳动节'],
    ['06-19', '端午节'], ['09-25', '中秋节'], ['10-01', '国庆节'],
  ];
  return base.map(([date, name]) => ({ date: `${year}-${date}`, name, type: '法定节假日', source: '内置' }));
}

/** 节假日查询：调用 mockGet('/integrations/holidays')，有效外部数据优先，否则用内置 */
async function queryHolidays(): Promise<void> {
  const year = Number(holidayYear.value) || new Date().getFullYear();
  const started = performance.now();
  const resp: any = await mockGet('/api/v1/integrations/holidays', { year });
  const rows = Array.isArray(resp) ? resp : resp?.list || [];
  const external = rows.filter((r: any) => r.date || r.holidayDate || r.holiday);
  if (external.length) {
    holidays.value = external.map((r: any) => ({
      date: r.date || r.holidayDate || r.holiday, name: r.name || r.title || '节假日', type: r.type || '法定节假日', source: '外部',
    }));
  } else {
    holidays.value = builtinHolidays(year);
  }
  const cost = Math.max(1, Math.round(performance.now() - started));
  await writeLog({
    provider: 'holidays', action: `查询 ${year} 年节假日`, signature: '外部源 HMAC-SHA256', costMs: cost,
    result: `${holidays.value.length} 条（${holidays.value[0]?.source || '内置'}）`,
  });
  toast.success(`已加载 ${holidays.value.length} 条节假日（${holidays.value[0]?.source || '内置'}）`);
}

onMounted(() => { void load(); void loadLogs(); });
</script>

<style scoped>
.int-head { display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px; }
.int-head h2 { margin: 0 0 4px; font-size: 18px; }
.int-head p { margin: 0; font-size: 13px; color: var(--ds-text-3); }
.int-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 12px; }
.int-desc { font-size: 13px; color: var(--ds-text-2); line-height: 1.6; margin: 0 0 10px; }
.int-meta { display: grid; gap: 6px; padding: 10px; background: var(--ds-bg-soft); border-radius: var(--ds-radius); margin-bottom: 10px; }
.int-meta > div { display: flex; align-items: center; gap: 8px; font-size: 12px; min-width: 0; }
.int-meta b { color: var(--ds-text-3); font-weight: 500; min-width: 64px; }
.int-meta code { color: var(--ds-brand); word-break: break-all; }
.int-fields { display: grid; grid-template-columns: repeat(2, 1fr); gap: 8px; margin: 10px 0; }
.int-fields label { display: flex; flex-direction: column; gap: 4px; font-size: 12px; color: var(--ds-text-3); }
.int-fields .ds-input, .int-fields .ds-select { width: 100%; }
.int-block { margin: 10px 0; padding: 10px; border: 1px solid var(--ds-divider); border-radius: var(--ds-radius); }
.int-block-head { display: flex; justify-content: space-between; align-items: center; gap: 8px; margin-bottom: 8px; }
.int-block-head b { font-size: 13px; }
.int-muted { font-size: 11px; color: var(--ds-text-3); }
.int-kv { display: grid; gap: 4px; margin-bottom: 6px; font-size: 12px; color: var(--ds-text-3); }
.int-tip { font-size: 12px; color: var(--ds-text-3); line-height: 1.5; }
.int-warn { font-size: 12px; color: var(--ds-warning); background: var(--ds-warning-soft); padding: 8px; border-radius: var(--ds-radius-sm); }
.int-year { display: flex; gap: 6px; align-items: center; }
.int-year .ds-input { width: 96px; }
.int-holidays { display: grid; gap: 4px; max-height: 160px; overflow: auto; }
.int-holiday { display: flex; align-items: center; gap: 10px; font-size: 12px; padding: 4px 0; border-bottom: 1px solid var(--ds-divider); }
.int-hdate { color: var(--ds-brand); font-variant-numeric: tabular-nums; }
.int-hname { flex: 1; }
.int-logline { display: flex; align-items: center; gap: 10px; font-size: 12px; padding: 4px 0; border-bottom: 1px solid var(--ds-divider); }
.int-logtime { color: var(--ds-text-3); font-variant-numeric: tabular-nums; }
.int-logact { flex: 1; }
.int-ops { display: flex; gap: 8px; flex-wrap: wrap; margin-top: 10px; }
.int-result { margin: 10px 0 0; padding: 10px; background: var(--ds-bg-soft); border-radius: 6px; font-size: 11px; max-height: 180px; overflow: auto; }
.int-logs { margin-top: 12px; }
.int-table { width: 100%; border-collapse: collapse; font-size: 13px; }
.int-table th, .int-table td { padding: 9px 12px; text-align: left; border-bottom: 1px solid var(--ds-divider); }
.int-table th { background: var(--ds-bg-soft); color: var(--ds-text-3); font-size: 12px; }
.int-empty { text-align: center; color: var(--ds-text-3); padding: 24px; }
</style>
