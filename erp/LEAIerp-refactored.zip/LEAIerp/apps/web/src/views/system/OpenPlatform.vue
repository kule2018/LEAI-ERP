<!--
 * 开放平台（文档第 31 章：OpenAPI + Webhook + 签名校验 + 调用日志）。
 * ---------------------------------------------------------------------------
 * API Key 与密钥只展示一次（演示模式存 mock）；Webhook 支持事件订阅与重试；
 * 调用日志可追溯时间、路径、耗时与结果。
 -->
<template>
  <div class="erp-page">
    <div class="op-head"><div><h2>开放平台</h2><p>对外提供受控 API，单据变更通过 Webhook 推送</p></div><DsButton variant="primary" @click="keyVisible = true">创建 API Key</DsButton></div>

    <DsCard title="API Key 管理" :pad="false">
      <table class="op-table">
        <thead><tr><th>名称</th><th>Access Key</th><th>权限范围</th><th>状态</th><th>最后调用</th><th>操作</th></tr></thead>
        <tbody>
          <tr v-for="k in keys" :key="k.id"><td>{{ k.name }}</td><td><code>{{ k.accessKey }}</code></td><td>{{ k.scope }}</td>
            <td><DsTag :color="k.enabled !== false ? 'success' : 'neutral'" size="sm">{{ k.enabled !== false ? '启用' : '禁用' }}</DsTag></td>
            <td>{{ k.lastUsed || '-' }}</td>
            <td><DsButton variant="text" size="sm" @click="toggle(k)">{{ k.enabled !== false ? '禁用' : '启用' }}</DsButton><DsButton variant="text" size="sm" @click="copy(k.accessKey)">复制</DsButton></td>
          </tr>
          <tr v-if="!keys.length"><td colspan="6" class="op-empty">还没有 API Key</td></tr>
        </tbody>
      </table>
    </DsCard>

    <DsCard title="Webhook 订阅" :pad="false" class="op-gap">
      <div class="op-toolbar"><DsButton size="sm" @click="hookVisible = true">新增订阅</DsButton></div>
      <table class="op-table">
        <thead><tr><th>名称</th><th>推送地址</th><th>订阅事件</th><th>状态</th><th>操作</th></tr></thead>
        <tbody>
          <tr v-for="h in hooks" :key="h.id"><td>{{ h.name }}</td><td><code>{{ h.url }}</code></td><td>{{ h.events }}</td>
            <td>{{ h.enabled !== false ? '启用' : '停用' }}</td><td><DsButton size="sm" variant="text" @click="dispatch(h)">测试推送</DsButton></td>
          </tr>
          <tr v-if="!hooks.length"><td colspan="5" class="op-empty">暂无订阅</td></tr>
        </tbody>
      </table>
    </DsCard>

    <RouterLink to="/system/webhooks" class="ds-btn ds-btn-default ds-btn-sm op-gap">查看 Webhook 日志</RouterLink>

    <DsModal v-model="keyVisible" title="创建 API Key" :width="440">
      <div class="op-form"><label><span>名称</span><input v-model="keyForm.name" class="ds-input" /></label>
        <label><span>权限范围</span><select v-model="keyForm.scope" class="ds-select"><option>read</option><option>read:write</option><option>all</option></select></label></div>
      <template #footer><div class="op-foot"><DsButton @click="keyVisible = false">取消</DsButton><DsButton variant="primary" @click="createKey">生成</DsButton></div></template>
    </DsModal>

    <DsModal v-model="hookVisible" title="新增 Webhook 订阅" :width="480">
      <div class="op-form"><label><span>名称</span><input v-model="hookForm.name" class="ds-input" /></label>
        <label><span>推送地址</span><input v-model="hookForm.url" class="ds-input" placeholder="https://example.com/webhook" /></label>
        <label class="full"><span>订阅事件（逗号分隔）</span><input v-model="hookForm.events" class="ds-input" /></label></div>
      <template #footer><div class="op-foot"><DsButton @click="hookVisible = false">取消</DsButton><DsButton variant="primary" @click="createHook">保存</DsButton></div></template>
    </DsModal>
    <DsToast />
  </div>
</template>

<script setup lang="ts">
/** 开放平台：密钥、Webhook 与调用日志 */
import { onMounted, reactive, ref } from 'vue';
import { mockGet, mockPost } from '../../api/mockAdapter';
import { pageRows } from '../../api/pageData';
import { useToast } from '../../components/ds/toast';

const toast = useToast();
const keys = ref<any[]>([]);
const hooks = ref<any[]>([]);
const keyVisible = ref(false);
const hookVisible = ref(false);
const keyForm = reactive<any>({ name: '', scope: 'read' });
const hookForm = reactive<any>({ name: '', url: '', events: 'order:confirmed,stock:changed' });

async function load(): Promise<void> {
  try {
    const [keyData, hookData] = await Promise.all([
      mockGet('/api/v1/ux/openapi-keys', { pageSize: 100 }),
      mockGet('/api/v1/ux/webhooks', { pageSize: 100 }),
    ]);
    keys.value = pageRows(keyData).map((key) => ({
      ...key, accessKey: key.accessKey ?? key.app_key, enabled: key.enabled ?? Number(key.status) !== 0,
      scope: key.scope ?? key.scopes, lastUsed: key.lastUsed ?? key.last_used,
    }));
    hooks.value = pageRows(hookData).map((hook) => ({ ...hook, events: hook.events ?? hook.event, enabled: hook.enabled ?? Number(hook.status) !== 0 }));
  } catch (error) {
    toast.error(error instanceof Error ? error.message : '开放平台加载失败');
  }
}
async function createKey(): Promise<void> {
  if (!keyForm.name) { toast.warning('请填写名称'); return; }
  const accessKey = 'ak_' + Math.random().toString(36).slice(2, 10);
  await mockPost('/api/v1/ux/openapi-keys', { ...keyForm, accessKey, enabled: true, createdAt: new Date().toLocaleString('zh-CN') });
  keyVisible.value = false; keyForm.name = ''; toast.success(`已生成：${accessKey}`); load();
}
async function toggle(k: any): Promise<void> {
  await mockPost('/api/v1/ux/openapi-keys', { ...k, enabled: k.enabled === false });
  k.enabled = k.enabled === false;
}
function copy(value: string): void {
  navigator.clipboard?.writeText(value).then(() => toast.success('已复制'));
}
async function createHook(): Promise<void> {
  if (!hookForm.name || !hookForm.url) { toast.warning('请填写名称与地址'); return; }
  await mockPost('/api/v1/ux/webhooks', { ...hookForm, enabled: true });
  hookVisible.value = false; hookForm.name = ''; hookForm.url = ''; toast.success('订阅已保存'); load();
}
async function dispatch(h: any): Promise<void> {
  try {
    const res: any = await mockPost('/api/v1/ux/webhooks/dispatch', { id: h.id, url: h.url, event: 'test' });
    toast.success(res?.response || '已写入模拟推送日志');
  } catch (error) {
    toast.error(error instanceof Error ? error.message : '测试推送失败');
  }
}
onMounted(load);
</script>

<style scoped>
.op-head { display: flex; justify-content: space-between; align-items: center; margin-bottom: 14px; }
.op-head h2 { font-size: 18px; margin: 0 0 4px; }
.op-head p { margin: 0; font-size: 12px; color: var(--ds-text-3); }
.op-gap { margin-top: 12px; }
.op-toolbar { padding: 10px 12px; }
.op-table { width: 100%; border-collapse: collapse; font-size: 13px; }
.op-table th, .op-table td { padding: 9px 12px; border-bottom: 1px solid var(--ds-divider); text-align: left; }
.op-table th { background: var(--ds-bg-soft); color: var(--ds-text-3); }
.op-table code { font-size: 12px; color: var(--ds-text-2); }
.op-empty { text-align: center; color: var(--ds-text-3); padding: 24px; }
.op-form { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
.op-form label { display: flex; flex-direction: column; gap: 4px; font-size: 13px; }
.op-form .full { grid-column: 1 / -1; }
.op-foot { display: flex; justify-content: flex-end; gap: 8px; }
</style>
