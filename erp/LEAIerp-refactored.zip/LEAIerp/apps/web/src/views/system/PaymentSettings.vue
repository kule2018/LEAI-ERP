<template><RecordPage :config="page" /></template>

<script setup lang="ts">
import RecordPage from '../records/RecordPage.vue';
import type { RecordPageConfig } from '../records/records';

const page: RecordPageConfig = {
  title: '支付配置',
  resource: 'system/pay-configs',
  schema: 'systemPayConfigs',
  filters: ['channel', 'status'],
  required: ['channel', 'merchantId', 'appId', 'callbackUrl'],
};
</script>
