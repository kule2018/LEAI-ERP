<!--
 * 插件市场（文档第 17、33 章：行业插件按开关启用，不用的功能不占界面）。
 * ---------------------------------------------------------------------------
 * 每个插件对应后端的 module_enabled 开关；关闭后对应菜单隐藏，
 * 重启后端即可卸载，不影响其他模块。
 -->
<template>
  <div class="erp-page">
    <div class="pm-head"><div><h2>插件市场</h2><p>按需启用扩展域，关闭的模块不会出现在菜单中</p></div><DsButton @click="save">保存配置</DsButton></div>
    <div class="pm-grid">
      <div v-for="p in plugins" :key="p.code" class="pm-card" :class="{ off: !p.enabled }">
        <div class="pm-top"><span class="pm-icon"><IconFont :name="p.icon" :size="20" /></span><b>{{ p.name }}</b><DsSwitch v-model="p.enabled" /></div>
        <p>{{ p.desc }}</p>
        <div class="pm-meta"><span>模块：{{ p.code }}</span><span>{{ p.enabled ? '已启用' : '未启用' }}</span></div>
      </div>
    </div>
    <p class="pm-note">提示：前端菜单在保存后刷新页面生效；后端模块需按 PLUGINS.md 中的说明调整 app.module.ts 后重启。</p>
    <DsToast />
  </div>
</template>

<script setup lang="ts">
/** 插件市场：维护模块开关并同步到本地配置 */
import { onMounted, reactive } from 'vue';
import { mockPost } from '../../api/mockAdapter';
import { useToast } from '../../components/ds/toast';

const toast = useToast();
const plugins = reactive([
  { code: 'BPM', name: '审批流引擎', icon: 'Connection', desc: '流程定义、金额阈值路由、会签或签与待办跟踪', enabled: true },
  { code: 'BI', name: '经营看板与自定义报表', icon: 'ChartBar', desc: 'ECharts 看板、拖拽报表设计与订阅推送', enabled: true },
  { code: 'CRM', name: '客户关系深化', icon: 'Users', desc: '线索评分、商机阶段、跟进记录与智能报价', enabled: true },
  { code: 'WMS', name: '仓储管理深化', icon: 'Home', desc: '波次拣货、上架策略、盘点盈亏与越库直发', enabled: true },
  { code: 'MES', name: '生产制造深化', icon: 'Box', desc: '工艺路线、MRP 运算、工单、质检与设备管理', enabled: true },
  { code: 'SHOP', name: '商城渠道集成', icon: 'Inbox', desc: '多平台店铺、商品映射、订单同步与发货回传', enabled: true },
  { code: 'MOBILE', name: '移动端服务', icon: 'Phone', desc: '扫码、离线盘点批量提交与移动审批接口', enabled: true },
  { code: 'INDUSTRY_RETAIL', name: '零售行业插件', icon: 'Home', desc: '门店、收银、会员积分与小票打印', enabled: false },
  { code: 'INDUSTRY_PHARMA', name: '医药行业插件', icon: 'Box', desc: 'GSP 批次效期管理与正反向追溯', enabled: false },
  { code: 'INDUSTRY_FOOD', name: '生鲜计重插件', icon: 'Tag', desc: '称重计重、损耗与临期预警', enabled: false },
]);

/** 读取已保存的开关 */
onMounted(() => {
  try {
    const saved = JSON.parse(localStorage.getItem('erp_module_enabled') || '{}');
    for (const p of plugins) if (saved[p.code] !== undefined) p.enabled = saved[p.code];
  } catch { /* 使用默认配置 */ }
});

/** 保存开关并写入 mock 配置 */
async function save(): Promise<void> {
  const config: Record<string, boolean> = {};
  for (const p of plugins) config[p.code] = p.enabled;
  localStorage.setItem('erp_module_enabled', JSON.stringify(config));
  for (const p of plugins) await mockPost('/api/v1/system/configs', { cfgKey: `module_enabled.${p.code}`, cfgValue: p.enabled ? '1' : '0' });
  toast.success('插件配置已保存，刷新页面后菜单生效');
}
</script>

<style scoped>
.pm-head { display: flex; justify-content: space-between; align-items: center; margin-bottom: 14px; }
.pm-head h2 { font-size: 18px; margin: 0 0 4px; }
.pm-head p { margin: 0; font-size: 12px; color: var(--ds-text-3); }
.pm-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 12px; }
.pm-card { background: var(--ds-bg-elevated); border: 1px solid var(--ds-border); border-radius: var(--ds-radius); padding: 16px; }
.pm-card.off { opacity: .6; }
.pm-top { display: flex; align-items: center; gap: 10px; }
.pm-top b { flex: 1; font-size: 14px; }
.pm-icon { font-size: 20px; }
.pm-card p { font-size: 12px; color: var(--ds-text-2); line-height: 1.6; min-height: 40px; }
.pm-meta { display: flex; justify-content: space-between; font-size: 11px; color: var(--ds-text-3); }
.pm-note { font-size: 12px; color: var(--ds-text-3); margin-top: 16px; }
@media (max-width: 1000px) { .pm-grid { grid-template-columns: 1fr 1fr; } }
</style>
