<!--
 * 自定义报表设计器（文档第 15 章：拖拽取数 / 自定义维度指标）。
 * ---------------------------------------------------------------------------
 * 左侧维度与指标池，点击或拖拽加入画布，右侧即时预览表格；
 * 保存后写入 rpt_definition，可在经营看板固定显示。
 -->
<template>
  <div class="erp-page">
    <div class="rd-head">
      <div><h2>报表设计器</h2><p>选择维度与指标，即时生成报表；无需编写 SQL</p></div>
      <div><DsButton @click="preview">刷新预览</DsButton><DsButton variant="primary" @click="save">保存报表</DsButton></div>
    </div>
    <div class="rd-layout">
      <DsCard title="可用字段" :pad="false" class="rd-left">
        <b class="rd-group">维度</b>
        <div v-for="d in dimensions" :key="d.code" class="rd-field" draggable="true" @dragstart="drag(d, 'dim')" @click="add(d, 'dim')">▦ {{ d.name }}</div>
        <b class="rd-group">指标</b>
        <div v-for="m in measures" :key="m.code" class="rd-field measure" draggable="true" @dragstart="drag(m, 'measure')" @click="add(m, 'measure')">∑ {{ m.name }}</div>
      </DsCard>

      <DsCard title="画布" :pad="false" class="rd-center">
        <div class="rd-drop" @dragover.prevent @drop.prevent="drop">
          <div class="rd-zone"><b>行维度</b><span v-for="(d, i) in selectedDims" :key="d.code" class="rd-chip">{{ d.name }} <em @click="selectedDims.splice(i, 1)">×</em></span><small v-if="!selectedDims.length">拖入或点击左侧维度</small></div>
          <div class="rd-zone"><b>指标</b><span v-for="(m, i) in selectedMeasures" :key="m.code" class="rd-chip primary">{{ m.name }} <em @click="selectedMeasures.splice(i, 1)">×</em></span><small v-if="!selectedMeasures.length">拖入或点击左侧指标</small></div>
        </div>
        <div class="rd-preview">
          <b>预览结果 <small class="rd-source">{{ sourceNote }}</small></b>
          <table class="rd-table">
            <thead><tr><th v-for="c in previewCols" :key="c">{{ c }}</th></tr></thead>
            <tbody>
              <tr v-for="(row, i) in previewRows" :key="i"><td v-for="c in previewCols" :key="c">{{ row[c] }}</td></tr>
              <tr v-if="!previewRows.length"><td :colspan="Math.max(1, previewCols.length)" class="rd-empty">请先选择维度与指标</td></tr>
            </tbody>
          </table>
        </div>
      </DsCard>

      <DsCard title="已保存报表" :pad="false" class="rd-right">
        <div v-for="r in reports" :key="r.id" class="rd-report" @click="loadReport(r)">
          <b>{{ r.name }}</b><small>{{ r.dims?.length || 0 }} 维度 / {{ r.measures?.length || 0 }} 指标</small>
        </div>
        <div v-if="!reports.length" class="rd-empty">暂无保存的报表</div>
      </DsCard>
    </div>

    <!-- 报表订阅：周期日报/周报/月报，指定接收人与推送渠道 -->
    <DsCard title="报表订阅（定时推送）" class="rd-sub">
      <div class="rd-sub-form">
        <label><span>报表</span>
          <select v-model="sub.reportId" class="ds-select">
            <option value="">选择报表</option>
            <option v-for="r in reports" :key="r.id" :value="r.id">{{ r.name }}</option>
          </select>
        </label>
        <label><span>周期</span>
          <select v-model="sub.cycle" class="ds-select">
            <option value="DAILY">日报</option><option value="WEEKLY">周报</option><option value="MONTHLY">月报</option>
          </select>
        </label>
        <label><span>接收人</span><input v-model="sub.receivers" class="ds-input" placeholder="多个用逗号分隔" /></label>
        <label><span>推送渠道</span>
          <select v-model="sub.channel" class="ds-select">
            <option>站内信</option><option>邮件</option><option>企业微信</option><option>钉钉</option>
          </select>
        </label>
        <DsButton variant="primary" size="sm" @click="saveSubscription">保存订阅</DsButton>
      </div>
      <div v-if="subscriptions.length" class="rd-sub-list">
        <div v-for="s in subscriptions" :key="s.id" class="rd-sub-row">
          {{ cycleText(s.cycle) }} · {{ s.reportName || s.reportId }} · {{ s.receivers }} · {{ s.channel }}
        </div>
      </div>
    </DsCard>
    <DsToast />
  </div>
</template>

<script setup lang="ts">
/** 报表设计器：维度指标选择、拖放、预览与保存 */
import { computed, onMounted, reactive, ref } from 'vue';
import { mockGet, mockPost } from '../../api/mockAdapter';
import { biApi } from '../../api/ext';
import { useToast } from '../../components/ds/toast';

interface Field { name: string; code: string }
const toast = useToast();
const dimensions: Field[] = [{ name: '客户', code: 'customer' }, { name: '产品', code: 'product' }, { name: '月份', code: 'month' }, { name: '仓库', code: 'warehouse' }, { name: '业务员', code: 'salesman' }];
const measures: Field[] = [{ name: '销售额', code: 'saleAmount' }, { name: '采购额', code: 'purchaseAmount' }, { name: '毛利', code: 'profit' }, { name: '库存量', code: 'stockQty' }];
const selectedDims = ref<Field[]>([{ name: '月份', code: 'month' }]);
const selectedMeasures = ref<Field[]>([{ name: '销售额', code: 'saleAmount' }]);
const previewRows = ref<any[]>([]);
const reports = ref<any[]>([]);
const currentId = ref<number | null>(null);
const sourceNote = ref('');
/** 预览列：真实取数按返回字段名，演示数据按所选维度/指标名 */
const previewCols = computed<string[]>(() => {
  if (previewRows.value.length) return Object.keys(previewRows.value[0]);
  return [...selectedDims.value.map((d) => d.name), ...selectedMeasures.value.map((m) => m.name)];
});
/** 订阅表单与列表 */
const sub = reactive<any>({ reportId: '', cycle: 'DAILY', receivers: '', channel: '邮件' });
const subscriptions = ref<any[]>([]);
/** 拖拽中的字段与类型 */
let dragging: { field: Field; kind: string } | null = null;

function drag(field: Field, kind: string): void { dragging = { field, kind }; }
function drop(): void { if (dragging) add(dragging.field, dragging.kind); dragging = null; }
function add(field: Field, kind: string): void {
  const list = kind === 'dim' ? selectedDims.value : selectedMeasures.value;
  if (!list.some((f) => f.code === field.code)) list.push(field);
}
/** 预览：未保存时按当前画布维度指标实时取数；保存后按报表 ID 取数。无演示数据。 */
async function preview(): Promise<void> {
  try {
    let rows: any[] = [];
    if (currentId.value) {
      const data: any = await biApi.run(Number(currentId.value), {});
      rows = Array.isArray(data) ? data : data?.list || [];
    } else if (selectedDims.value.length && selectedMeasures.value.length) {
      // 未保存报表：把当前画布配置作为临时定义交给 BI 引擎聚合
      const data: any = await mockPost('/api/v1/bi/preview-run', {
        dims: selectedDims.value, measures: selectedMeasures.value,
      });
      rows = Array.isArray(data) ? data : data?.list || [];
    }
    previewRows.value = rows;
    sourceNote.value = rows.length ? '数据来源：真实业务单据（销售单/库存实时聚合）' : '暂无匹配数据，请调整维度指标';
    if (rows.length) toast.success('预览已刷新（实时数据）');
  } catch {
    previewRows.value = [];
    sourceNote.value = '取数失败，请稍后重试';
  }
}
async function save(): Promise<void> {
  if (!selectedDims.value.length || !selectedMeasures.value.length) { toast.warning('请至少选择一个维度和一个指标'); return; }
  const name = `${selectedDims.value.map((d) => d.name).join('×')} - ${selectedMeasures.value.map((m) => m.name).join('、')}`;
  const saved: any = await mockPost('/api/v1/bi/reports', { name, dims: selectedDims.value, measures: selectedMeasures.value });
  toast.success('报表已保存');
  await load();
  if (saved?.id) { currentId.value = saved.id; await preview(); }
}
async function load(): Promise<void> {
  const list: any = await mockGet('/api/v1/bi/reports', { pageSize: 100 });
  reports.value = Array.isArray(list) ? list : list?.list || [];
  if (!sub.reportId && reports.value.length) sub.reportId = reports.value[0].id;
}
function loadReport(row: any): void {
  currentId.value = row.id || null;
  selectedDims.value = row.dims || []; selectedMeasures.value = row.measures || [];
  void preview();
}
/** 订阅：写入 /api/v1/bi/subscriptions（周期、接收人、渠道） */
async function loadSubscriptions(): Promise<void> {
  const list: any = await mockGet('/api/v1/bi/subscriptions');
  subscriptions.value = Array.isArray(list) ? list : list?.list || [];
}
async function saveSubscription(): Promise<void> {
  if (!sub.reportId || !sub.receivers.trim()) { toast.warning('请选择报表并填写接收人'); return; }
  const report = reports.value.find((r) => String(r.id) === String(sub.reportId));
  await mockPost('/api/v1/bi/subscriptions', {
    ...sub, reportId: Number(sub.reportId), reportName: report?.name || '',
    receivers: sub.receivers.split(/[,，]/).map((s: string) => s.trim()).filter(Boolean),
  });
  toast.success('订阅已保存');
  await loadSubscriptions();
}
const cycleText = (c: string): string => ({ DAILY: '日报', WEEKLY: '周报', MONTHLY: '月报' }[c] || c);
onMounted(() => { void load(); void preview(); void loadSubscriptions(); });
</script>

<style scoped>
.rd-head { display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px; }
.rd-head h2 { font-size: 18px; margin: 0 0 4px; }
.rd-head p { margin: 0; font-size: 12px; color: var(--ds-text-3); }
.rd-head > div:last-child { display: flex; gap: 8px; }
.rd-layout { display: grid; grid-template-columns: 180px 1fr 220px; gap: 12px; }
.rd-group { display: block; font-size: 12px; color: var(--ds-text-3); padding: 10px 12px 4px; }
.rd-field { padding: 8px 12px; font-size: 13px; cursor: pointer; border-bottom: 1px solid var(--ds-divider); }
.rd-field:hover { background: var(--ds-brand-soft); }
.rd-field.measure { color: var(--ds-brand); }
.rd-drop { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; padding: 12px; }
.rd-zone { min-height: 78px; border: 1px dashed var(--ds-border); border-radius: var(--ds-radius); padding: 8px; }
.rd-zone b { display: block; font-size: 12px; color: var(--ds-text-3); margin-bottom: 6px; }
.rd-zone small { color: var(--ds-text-3); font-size: 12px; }
.rd-chip { display: inline-flex; align-items: center; gap: 4px; padding: 3px 8px; margin: 0 4px 4px 0; border-radius: 12px; background: var(--ds-bg-soft); font-size: 12px; }
.rd-chip.primary { background: var(--ds-brand-soft); color: var(--ds-brand); }
.rd-chip em { cursor: pointer; font-style: normal; }
.rd-preview { padding: 0 12px 12px; }
.rd-preview > b { font-size: 13px; }
.rd-table { width: 100%; border-collapse: collapse; font-size: 13px; margin-top: 6px; }
.rd-table th, .rd-table td { border: 1px solid var(--ds-border); padding: 7px 10px; text-align: left; }
.rd-table th { background: var(--ds-bg-soft); }
.rd-report { padding: 9px 12px; border-bottom: 1px solid var(--ds-divider); cursor: pointer; display: flex; flex-direction: column; gap: 2px; }
.rd-report:hover { background: var(--ds-brand-soft); }
.rd-report b { font-size: 13px; }
.rd-report small { font-size: 11px; color: var(--ds-text-3); }
.rd-source { font-size: 11px; font-weight: 400; color: var(--ds-text-3); margin-left: 8px; }
.rd-sub { margin-top: 12px; }
.rd-sub-form { display: grid; grid-template-columns: 1.2fr 0.7fr 1.3fr 0.9fr auto; gap: 12px; align-items: end; padding: 4px 0; }
.rd-sub-form label { display: flex; flex-direction: column; gap: 4px; font-size: 13px; }
.rd-sub-form label span { color: var(--ds-text-3); font-size: 12px; }
.rd-sub-list { margin-top: 12px; border-top: 1px solid var(--ds-divider); padding-top: 8px; }
.rd-sub-row { font-size: 12px; padding: 5px 0; color: var(--ds-text-2); }
.rd-empty { text-align: center; color: var(--ds-text-3); padding: 20px; font-size: 12px; }
</style>
