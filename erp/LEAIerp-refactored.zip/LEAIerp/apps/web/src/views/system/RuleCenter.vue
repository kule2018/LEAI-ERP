<!--
 * 业务规则中心（文档第 33 章：预警阈值 / 审批路由 / 价格策略 / 编码规则可视化配置）。
 * 规则修改后写 mock 规则表，前端列表与预警读取同一份配置，立即生效。
 -->
<template>
  <div class="erp-page">
    <div class="rc-head">
      <div><h2>业务规则中心</h2><p>不写代码即可调整阈值、审批路由与编码策略</p></div>
      <DsButton variant="primary" @click="open()">新建规则</DsButton>
    </div>
    <div class="rc-tabs">
      <DsSegmented v-model="type" :options="[{ label: '全部', value: '' }, { label: '预警阈值', value: 'ALERT' }, { label: '审批路由', value: 'APPROVAL' }, { label: '价格策略', value: 'PRICE' }, { label: '编码规则', value: 'SEQUENCE' }]" />
    </div>
    <DsCard :pad="false">
      <table class="rc-table">
        <thead><tr><th>规则名称</th><th>类型</th><th>适用对象</th><th>条件</th><th>动作</th><th>影响金额/优先级</th><th>推送渠道</th><th>状态</th><th>操作</th></tr></thead>
        <tbody>
          <tr v-for="row in filtered" :key="row.id">
            <td>{{ row.name }}</td><td>{{ typeText(row.type) }}</td><td>{{ row.target }}</td>
            <td>{{ row.condition }}</td><td>{{ row.action }}</td>
            <td>¥{{ row.impactAmount || 0 }} / <DsTag :color="priorityColor(row)" size="sm">{{ priorityText(row) }}</DsTag></td>
            <td>{{ row.channels || '站内信' }}<small v-if="row.dedupMinutes"> · {{ row.dedupMinutes }} 分钟去重</small></td>
            <td><DsTag :color="row.enabled !== false ? 'success' : 'neutral'" size="sm">{{ row.enabled !== false ? '启用' : '停用' }}</DsTag></td>
            <td><DsButton variant="text" size="sm" @click="open(row)">编辑</DsButton><DsButton variant="text" size="sm" @click="test(row)">测试</DsButton></td>
          </tr>
          <tr v-if="!filtered.length"><td colspan="9" class="rc-empty">暂无规则</td></tr>
        </tbody>
      </table>
    </DsCard>

    <DsModal v-model="formVisible" :title="editing ? '编辑规则' : '新建规则'" :width="520">
      <div class="rc-form">
        <label><span>规则名称</span><input v-model="form.name" class="ds-input" /></label>
        <label><span>类型</span><select v-model="form.type" class="ds-select"><option value="ALERT">预警阈值</option><option value="APPROVAL">审批路由</option><option value="PRICE">价格策略</option><option value="SEQUENCE">编码规则</option></select></label>
        <label><span>适用对象</span><input v-model="form.target" class="ds-input" placeholder="如 库存 / 销售单 / 客户等级" /></label>
        <label><span>条件</span><input v-model="form.condition" class="ds-input" placeholder="如 可用量 < 安全库存" /></label>
        <label class="full"><span>动作</span><input v-model="form.action" class="ds-input" placeholder="如 生成补货提醒 / 转总监审批" /></label>
        <label><span>影响金额（元）</span><input v-model.number="form.impactAmount" class="ds-input" type="number" /></label>
        <label><span>去重窗口（分钟）</span><input v-model.number="form.dedupMinutes" class="ds-input" type="number" placeholder="如 30 分钟内不重复告警" /></label>
        <label class="full"><span>推送渠道（逗号分隔）</span><input v-model="form.channels" class="ds-input" placeholder="站内信,邮件,短信,企业微信,钉钉" /></label>
        <label class="checks"><input v-model="form.enabled" type="checkbox" /> 启用</label>
      </div>
      <template #footer><div class="rc-foot"><DsButton @click="formVisible = false">取消</DsButton><DsButton variant="primary" @click="save">保存</DsButton></div></template>
    </DsModal>
    <DsToast />
  </div>
</template>

<script setup lang="ts">
/** 业务规则中心：规则 CRUD 与模拟命中测试 */
import { computed, onMounted, reactive, ref } from 'vue';
import { mockGet, mockPost } from '../../api/mockAdapter';
import { useToast } from '../../components/ds/toast';

const toast = useToast();
const rows = ref<any[]>([]);
const type = ref('');
const formVisible = ref(false);
const editing = ref<any>(null);
const form = reactive<any>({});

/** 按影响金额与紧急度排序：金额大的优先展示（文档第 29 章） */
const filtered = computed(() => (type.value ? rows.value.filter((r) => r.type === type.value) : rows.value)
  .slice().sort((a, b) => Number(b.impactAmount || 0) - Number(a.impactAmount || 0)));
/** 优先级：影响金额 ≥ 10 万为高，≥ 1 万为中，其余为低 */
function priorityText(row: any): string { const amount = Number(row.impactAmount || 0); return amount >= 100000 ? '高' : amount >= 10000 ? '中' : '低'; }
function priorityColor(row: any): any { return priorityText(row) === '高' ? 'danger' : priorityText(row) === '中' ? 'warning' : 'neutral'; }
function typeText(value: string): string {
  return { ALERT: '预警阈值', APPROVAL: '审批路由', PRICE: '价格策略', SEQUENCE: '编码规则' }[value] || value;
}
async function load(): Promise<void> {
  const list: any = await mockGet('/api/v1/ux/alert-rules', { pageSize: 100 });
  rows.value = Array.isArray(list) ? list : list?.list || [];
}
function open(row?: any): void {
  editing.value = row || null;
  Object.assign(form, row ? { ...row } : { name: '', type: 'ALERT', target: '', condition: '', action: '', impactAmount: 0, dedupMinutes: 30, channels: '站内信', enabled: true });
  formVisible.value = true;
}
async function save(): Promise<void> {
  if (!form.name || !form.condition) { toast.warning('请填写规则名称与条件'); return; }
  await mockPost('/api/v1/ux/alert-rules', { ...form, id: form.id || undefined });
  formVisible.value = false; toast.success('规则已保存'); load();
}
/** 模拟规则测试：给出命中结论，方便配置时验证 */
function test(row: any): void {
  const hit = row.enabled !== false;
  const message = hit
    ? `规则「${row.name}」已命中，优先级 ${priorityText(row)}，推送至 ${row.channels || '站内信'}，执行：${row.action}${row.dedupMinutes ? `（${row.dedupMinutes} 分钟内去重）` : ''}`
    : `规则「${row.name}」已停用，不会触发`;
  toast[hit ? 'success' : 'warning'](message);
}
onMounted(load);
</script>

<style scoped>
.rc-head { display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px; }
.rc-head h2 { font-size: 18px; margin: 0 0 4px; }
.rc-head p { margin: 0; font-size: 12px; color: var(--ds-text-3); }
.rc-tabs { margin-bottom: 12px; }
.rc-table { width: 100%; border-collapse: collapse; font-size: 13px; }
.rc-table th, .rc-table td { padding: 9px 12px; border-bottom: 1px solid var(--ds-divider); text-align: left; }
.rc-table th { background: var(--ds-bg-soft); color: var(--ds-text-3); }
.rc-empty { text-align: center; color: var(--ds-text-3); padding: 24px; }
.rc-form { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
.rc-form label { display: flex; flex-direction: column; gap: 4px; font-size: 13px; }
.rc-form .full { grid-column: 1 / -1; }
.rc-form .checks { flex-direction: row; align-items: center; }
.rc-foot { display: flex; justify-content: flex-end; gap: 8px; }
</style>
